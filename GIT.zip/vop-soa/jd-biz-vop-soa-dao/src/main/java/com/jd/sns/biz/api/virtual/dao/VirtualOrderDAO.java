package com.jd.sns.biz.api.virtual.dao;

import com.jd.sns.biz.api.virtual.domain.VirtualOrder;
import com.jd.sns.biz.api.virtual.query.VirtualOrderQuery;
import java.util.List;

/**
 * 数据访问对象接口
 * @since 2014-08-22
 */
public interface VirtualOrderDAO {

    /**
     * 插入数据
     * @param virtualOrder
     * @return 插入数据的主键
     */
    public Long insertVirtualOrder(VirtualOrder virtualOrder);

    /**
     * 统计记录数
     * @param virtualOrder
     * @return 查出的记录数
     */
    public Integer countVirtualOrderByExample(VirtualOrderQuery virtualOrderQuery);


    /**
     * 更新记录
     * @param virtualOrder
     * @return 受影响的行数
     */
    public Integer updateVirtualOrder(VirtualOrder virtualOrder);

    /**
     * 获取对象列表
     * @param virtualOrder
     * @return 对象列表
     */
    public List<VirtualOrder> findListByExample(VirtualOrderQuery virtualOrderQuery);

    /**
     * 根据主键获取virtualOrderDO
     * @param id
     * @return virtualOrderDO
     */
    public VirtualOrder findVirtualOrderByPrimaryKey(Long id);

    /**
     * 删除记录
     * @param id
     * @return 受影响的行数
     */
    public Integer deleteVirtualOrderByPrimaryKey(Long id);

}