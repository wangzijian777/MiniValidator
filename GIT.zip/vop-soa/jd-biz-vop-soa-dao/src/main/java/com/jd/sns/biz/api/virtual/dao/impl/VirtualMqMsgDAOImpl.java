package com.jd.sns.biz.api.virtual.dao.impl;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.jd.sns.biz.api.virtual.dao.VirtualMqMsgDAO;
import com.jd.sns.biz.api.virtual.domain.VirtualMqMsg;
import com.jd.sns.biz.api.virtual.query.VirtualMqMsgQuery;

/**
 * 数据访问对象实现类
 * @since 2014-08-22
 */
public class VirtualMqMsgDAOImpl extends SqlMapClientDaoSupport implements VirtualMqMsgDAO {

    /**
     * 插入数据
     * @param virtualMqMsg
     * @return 插入数据的主键
     */
    public Long insertVirtualMqMsg(VirtualMqMsg virtualMqMsg) {
        Object obj = getSqlMapClientTemplate().insert("VirtualMqMsg.insert", virtualMqMsg);
        Long id = (Long)obj;
        virtualMqMsg.setId(id);
        return id;
    }

    /**
     * 统计记录数
     * @param virtualMqMsgQuery
     * @return 查出的记录数
     */
    public Integer countVirtualMqMsgQueryByExample(VirtualMqMsgQuery virtualMqMsgQuery) {
        Integer count = (Integer) getSqlMapClientTemplate().queryForObject("VirtualMqMsg.countByQueryExample", virtualMqMsgQuery);
        return count;
    }

    /**
     * 更新记录
     * @param virtualMqMsg
     * @return 受影响的行数
     */
    public Integer updateVirtualMqMsg(VirtualMqMsg virtualMqMsg) {
        int result = getSqlMapClientTemplate().update("VirtualMqMsg.update", virtualMqMsg);
        return result;
    }

    /**
     * 获取对象列表
     * @param virtualMqMsgQuery
     * @return 对象列表
     */
    @SuppressWarnings("unchecked")
    public List<VirtualMqMsg> findListByExample(VirtualMqMsgQuery virtualMqMsgQuery) {
        List<VirtualMqMsg> list = getSqlMapClientTemplate().queryForList("VirtualMqMsg.findListByQuery", virtualMqMsgQuery);
        return list;
    }

    /**
     * 根据主键获取virtualMqMsgDO
     * @param id
     * @return virtualMqMsgDO
     */
    public VirtualMqMsg findVirtualMqMsgByPrimaryKey(Integer id) {
        VirtualMqMsg virtualMqMsg = (VirtualMqMsg) getSqlMapClientTemplate().queryForObject("VirtualMqMsg.findByPrimaryKey", id);
        return virtualMqMsg;
    }

    /**
     * 删除记录
     * @param id
     * @return 受影响的行数
     */
    public Integer deleteVirtualMqMsgByPrimaryKey(Integer id) {
        Integer rows = (Integer) getSqlMapClientTemplate().delete("VirtualMqMsg.deleteByPrimaryKey", id);
        return rows;
    }

}