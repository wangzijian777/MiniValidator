package com.jd.sns.biz.api.virtual.dao.impl;

import com.jd.sns.biz.api.virtual.dao.VirtualRechargeTaskDAO;
import com.jd.sns.biz.api.virtual.domain.VirtualRechargeTask;
import com.jd.sns.biz.api.virtual.query.VirtualRechargeTaskQuery;
import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

/**
 * 数据访问对象实现类
 * @since 2014-08-22
 */
public class VirtualRechargeTaskDAOImpl extends SqlMapClientDaoSupport implements VirtualRechargeTaskDAO {

    /**
     * 插入数据
     * @param virtualRechargeTask
     * @return 插入数据的主键
     */
    public Long insertVirtualRechargeTask(VirtualRechargeTask virtualRechargeTask) {
        Object obj = getSqlMapClientTemplate().insert("VirtualRechargeTask.insert", virtualRechargeTask);
        Long id = (Long)obj;
        virtualRechargeTask.setId(id);
        return id;
    }

    /**
     * 统计记录数
     * @param virtualRechargeTaskQuery
     * @return 查出的记录数
     */
    public Integer countVirtualRechargeTaskQueryByExample(VirtualRechargeTaskQuery virtualRechargeTaskQuery) {
        Integer count = (Integer) getSqlMapClientTemplate().queryForObject("VirtualRechargeTask.countByQueryExample", virtualRechargeTaskQuery);
        return count;
    }

    /**
     * 更新记录
     * @param virtualRechargeTask
     * @return 受影响的行数
     */
    public Integer updateVirtualRechargeTask(VirtualRechargeTask virtualRechargeTask) {
        int result = getSqlMapClientTemplate().update("VirtualRechargeTask.update", virtualRechargeTask);
        return result;
    }

    /**
     * 获取对象列表
     * @param virtualRechargeTaskQuery
     * @return 对象列表
     */
    @SuppressWarnings("unchecked")
    public List<VirtualRechargeTask> findListByExample(VirtualRechargeTaskQuery virtualRechargeTaskQuery) {
        List<VirtualRechargeTask> list = getSqlMapClientTemplate().queryForList("VirtualRechargeTask.findListByQuery", virtualRechargeTaskQuery);
        return list;
    }

    /**
     * 根据主键获取virtualRechargeTaskDO
     * @param id
     * @return virtualRechargeTaskDO
     */
    public VirtualRechargeTask findVirtualRechargeTaskByPrimaryKey(Long id) {
        VirtualRechargeTask virtualRechargeTaskDO = (VirtualRechargeTask) getSqlMapClientTemplate().queryForObject("VirtualRechargeTask.findByPrimaryKey", id);
        return virtualRechargeTaskDO;
    }

    /**
     * 删除记录
     * @param id
     * @return 受影响的行数
     */
    public Integer deleteVirtualRechargeTaskByPrimaryKey(Long id) {
        Integer rows = (Integer) getSqlMapClientTemplate().delete("VirtualRechargeTask.deleteByPrimaryKey", id);
        return rows;
    }

}