package com.jd.sns.biz.api.virtual.dao.impl;

import com.jd.sns.biz.api.virtual.dao.VirtualSkuDAO;
import com.jd.sns.biz.api.virtual.domain.VirtualSku;
import com.jd.sns.biz.api.virtual.query.VirtualSkuQuery;
import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

/**
 * 数据访问对象实现类
 *
 * @since 2014-08-22
 */
public class VirtualSkuDAOImpl extends SqlMapClientDaoSupport implements VirtualSkuDAO {

	/**
	 * 插入数据
	 *
	 * @param virtualSku
	 * @return 插入数据的主键
	 */
	public Long insertVirtualSku(VirtualSku virtualSku) {
		Object obj = getSqlMapClientTemplate().insert("VirtualSku.insert", virtualSku);

		Long id = (Long) obj;
		// 新插入都将id设置回去
		virtualSku.setId(id);
		return id;
	}

	/**
	 * 统计记录数
	 *
	 * @param virtualSkuQuery
	 * @return 查出的记录数
	 */
	public Integer countVirtualSkuByExample(VirtualSkuQuery virtualSkuQuery) {
		Integer count = (Integer) getSqlMapClientTemplate().queryForObject("VirtualSku.countByQueryExample",
				virtualSkuQuery);
		return count;
	}

	/**
	 * 更新记录
	 *
	 * @param virtualSku
	 * @return 受影响的行数
	 */
	public Integer updateVirtualSku(VirtualSku virtualSku) {
		int result = getSqlMapClientTemplate().update("VirtualSku.update", virtualSku);
		return result;
	}

	/**
	 * 获取对象列表
	 *
	 * @param virtualSkuQuery
	 * @return 对象列表
	 */
	@SuppressWarnings("unchecked")
	public List<VirtualSku> findListByExample(VirtualSkuQuery virtualSkuQuery) {
		List<VirtualSku> list = getSqlMapClientTemplate().queryForList("VirtualSku.findListByQuery", virtualSkuQuery);
		return list;
	}

	/**
	 * 根据主键获取virtualSkuDO
	 *
	 * @param id
	 * @return virtualSkuDO
	 */
	public VirtualSku findVirtualSkuByPrimaryKey(Long id) {
		VirtualSku virtualSkuDO = (VirtualSku) getSqlMapClientTemplate().queryForObject("VirtualSku.findByPrimaryKey",
				id);
		return virtualSkuDO;
	}

	/**
	 * 删除记录
	 *
	 * @param id
	 * @return 受影响的行数
	 */
	public Integer deleteVirtualSkuByPrimaryKey(Long id) {
		Integer rows = (Integer) getSqlMapClientTemplate().delete("VirtualSku.deleteByPrimaryKey", id);
		return rows;
	}

}