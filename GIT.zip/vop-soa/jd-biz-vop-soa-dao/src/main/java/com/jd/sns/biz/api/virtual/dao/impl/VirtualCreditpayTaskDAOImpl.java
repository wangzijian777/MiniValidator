package com.jd.sns.biz.api.virtual.dao.impl;

import com.jd.sns.biz.api.virtual.dao.VirtualCreditpayTaskDAO;
import com.jd.sns.biz.api.virtual.domain.VirtualCreditpayTask;
import com.jd.sns.biz.api.virtual.query.VirtualCreditpayTaskQuery;
import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

/**
 * 数据访问对象实现类
 *
 * @since 2014-08-22
 */
public class VirtualCreditpayTaskDAOImpl extends SqlMapClientDaoSupport implements VirtualCreditpayTaskDAO {

	/**
	 * 插入数据
	 *
	 * @param virtualCreditpayTask
	 * @return 插入数据的主键
	 */
	public Long insertVirtualCreditpayTask(VirtualCreditpayTask virtualCreditpayTask) {
		Object obj = getSqlMapClientTemplate().insert("VirtualCreditpayTask.insert", virtualCreditpayTask);
		Long id = (Long) obj;
		virtualCreditpayTask.setId(id);
		return id;
	}

	/**
	 * 统计记录数
	 *
	 * @param virtualCreditpayTaskQuery
	 * @return 查出的记录数
	 */
	public Integer countVirtualCreditpayTaskQueryByExample(VirtualCreditpayTaskQuery virtualCreditpayTaskQuery) {
		Integer count = (Integer) getSqlMapClientTemplate().queryForObject("VirtualCreditpayTask.countByQueryExample",
				virtualCreditpayTaskQuery);
		return count;
	}

	/**
	 * 更新记录
	 *
	 * @param virtualCreditpayTask
	 * @return 受影响的行数
	 */
	public Integer updateVirtualCreditpayTask(VirtualCreditpayTask virtualCreditpayTask) {
		int result = getSqlMapClientTemplate().update("VirtualCreditpayTask.update", virtualCreditpayTask);
		return result;
	}

	/**
	 * 获取对象列表
	 *
	 * @param virtualCreditpayTaskQuery
	 * @return 对象列表
	 */
	@SuppressWarnings("unchecked")
	public List<VirtualCreditpayTask> findListByExample(VirtualCreditpayTaskQuery virtualCreditpayTaskQuery) {
		List<VirtualCreditpayTask> list = getSqlMapClientTemplate().queryForList(
				"VirtualCreditpayTask.findListByQuery", virtualCreditpayTaskQuery);
		return list;
	}

	/**
	 * 根据主键获取virtualCreditpayTaskDO
	 *
	 * @param id
	 * @return virtualCreditpayTaskDO
	 */
	public VirtualCreditpayTask findVirtualCreditpayTaskByPrimaryKey(Long id) {
		VirtualCreditpayTask virtualCreditpayTask = (VirtualCreditpayTask) getSqlMapClientTemplate().queryForObject(
				"VirtualCreditpayTask.findByPrimaryKey", id);
		return virtualCreditpayTask;
	}

	/**
	 * 删除记录
	 *
	 * @param id
	 * @return 受影响的行数
	 */
	public Integer deleteVirtualCreditpayTaskByPrimaryKey(Long id) {
		Integer rows = (Integer) getSqlMapClientTemplate().delete("VirtualCreditpayTask.deleteByPrimaryKey", id);
		return rows;
	}

}