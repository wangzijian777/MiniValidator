package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizOrderPriceSnapDao;
import com.jd.sns.biz.api.domain.BizOrderPriceSnap;

/**
 * 
 * @author cdwangzijian
 *
 */
public class BizOrderPriceSnapDaoImpl extends BaseDao implements
		BizOrderPriceSnapDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<BizOrderPriceSnap> getAll() {
		return (List<BizOrderPriceSnap>)super.queryForList("BizOrderPriceSnap.getAll");
	}

	@Override
	public void insertSnap(BizOrderPriceSnap priceSnap) {
		super.insert("BizOrderPriceSnap.insertSnap", priceSnap);
	}

}
