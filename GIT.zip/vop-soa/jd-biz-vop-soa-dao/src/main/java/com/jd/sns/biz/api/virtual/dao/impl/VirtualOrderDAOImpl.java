package com.jd.sns.biz.api.virtual.dao.impl;

import com.jd.sns.biz.api.virtual.dao.VirtualOrderDAO;
import com.jd.sns.biz.api.virtual.domain.VirtualOrder;
import com.jd.sns.biz.api.virtual.query.VirtualOrderQuery;
import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

/**
 * 数据访问对象实现类
 * @since 2014-08-22
 */
public class VirtualOrderDAOImpl extends SqlMapClientDaoSupport implements VirtualOrderDAO {

    /**
     * 插入数据
     * @param virtualOrder
     * @return 插入数据的主键
     */
    public Long insertVirtualOrder(VirtualOrder virtualOrder) {
        Object obj = getSqlMapClientTemplate().insert("VirtualOrder.insert", virtualOrder);
        Long id = (Long) obj;
        virtualOrder.setId(id);
        return id;
    }

    /**
     * 统计记录数
     * @param virtualOrderQuery
     * @return 查出的记录数
     */
    public Integer countVirtualOrderByExample(VirtualOrderQuery virtualOrderQuery) {
        Integer count = (Integer) getSqlMapClientTemplate().queryForObject("VirtualOrder.countByQueryExample", virtualOrderQuery);
        return count;
    }

    /**
     * 更新记录
     * @param virtualOrder
     * @return 受影响的行数
     */
    public Integer updateVirtualOrder(VirtualOrder virtualOrder) {
        int result = getSqlMapClientTemplate().update("VirtualOrder.update", virtualOrder);
        return result;
    }

    /**
     * 获取对象列表
     * @param virtualOrderQuery
     * @return 对象列表
     */
    @SuppressWarnings("unchecked")
    public List<VirtualOrder> findListByExample(VirtualOrderQuery virtualOrderQuery) {
        List<VirtualOrder> list = getSqlMapClientTemplate().queryForList("VirtualOrder.findListByQuery", virtualOrderQuery);
        return list;
    }

    /**
     * 根据主键获取virtualOrderDO
     * @param id
     * @return virtualOrderDO
     */
    public VirtualOrder findVirtualOrderByPrimaryKey(Long id) {
        VirtualOrder virtualOrder = (VirtualOrder) getSqlMapClientTemplate().queryForObject("VirtualOrder.findByPrimaryKey", id);
        return virtualOrder;
    }

    /**
     * 删除记录
     * @param id
     * @return 受影响的行数
     */
    public Integer deleteVirtualOrderByPrimaryKey(Long id) {
        Integer rows = (Integer) getSqlMapClientTemplate().delete("VirtualOrder.deleteByPrimaryKey", id);
        return rows;
    }

}