package com.jd.sns.biz.api.dao;



import com.jd.sns.biz.api.domain.CreditPayTask;


public interface CreditPayTaskDao {

	void insertCreditPayTask(CreditPayTask creditPayTask);
	
	void deleteCreditPayTaskById(Long id);
	
	int updateCreditPayTask(CreditPayTask creditPayTask);
	
	CreditPayTask selectByJdOrderId(long jdOrderId);
	int updateTaskForRepay(CreditPayTask creditPayTask);
}
