package com.jd.sns.biz.api.redis.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

//import org.apache.log4j.Logger;

import com.jd.jim.cli.driver.types.StringTuple;
import com.jd.sns.biz.api.redis.JdCacheUtils;

/**
 * 缓存代理
 * @author cdgaoqing
 *
 */
public class JdRedisUtilsProxyImpl implements JdCacheUtils {

//	private static final Logger LOGGER=Logger.getLogger("CACHE_LOG");
	
//	private RedisUtils redisUtilsOld;
	
	private JdCacheUtils jdCouldRedisUtils;
	
	
	@Override
	public boolean set(String key, String value) {
		return jdCouldRedisUtils.set(key, value);
	}
	
	
	@Override
	public String get(String key) {
//		String value = jdCouldRedisUtils.get(key);
//		if(null == value){
//			LOGGER.error("get 向云缓存没有获取到数据，开始从老redis获取。key=" + key);
//			value = redisUtilsOld.get(key);
//			if(null != value){
//				LOGGER.error("get 向云缓存写入数据开始，key=" + key+",value="+value);
//				Long seconds = redisUtilsOld.ttl(key);
//				LOGGER.error("get 向云缓存写入数据有效时间，seconds="+seconds);
//				if(-1 == seconds){
//					jdCouldRedisUtils.set(key, value);
//					LOGGER.error("get 向云缓存写入永久性数据，key=" + key+",value="+value);
//				}else{
//					jdCouldRedisUtils.setStringByExpire(key, value, seconds, TimeUnit.SECONDS);
//					LOGGER.error("get 向云缓存写入临时数据，key=" + key+",value="+value+" ,seconds="+seconds);
//				}
//				LOGGER.error("get 向云缓存写入数据结束");
//			}else{
//				LOGGER.error("get 老redis没有获取到数据，key=" + key);
//			}
//		}else{
//			LOGGER.error("get 云缓存获取到数据!key=" + key+",value="+value);
//		}
		return jdCouldRedisUtils.get(key);
	}
	
	@Override
	public long del(String key) {
//		LOGGER.error("del 从老redis删除数据，key=" + key);
//		redisUtilsOld.del(key);
//		LOGGER.error("del 从云缓存删除数据，key=" + key);
        return jdCouldRedisUtils.del(key);
	}
	
	@Override
	public boolean exists(String key) {
//		if(!jdCouldRedisUtils.exists(key)){ //云缓存没有
//			if(redisUtilsOld.exists(key)){ //老缓存缓存有
//				String value = redisUtilsOld.get(key);
//				LOGGER.error("exists 向云缓存写入数据开始，key=" + key+",value="+value);
//				Long seconds = redisUtilsOld.ttl(key);
//				LOGGER.error("exists 向云缓存写入数据有效时间，seconds="+seconds);
//				jdCouldRedisUtils.setStringByExpire(key, value, seconds, TimeUnit.SECONDS);
//				LOGGER.error("exists 向云缓存写入数据结束");
//				return jdCouldRedisUtils.exists(key);
//			}else{
//				LOGGER.error("exists 老redis不存在缓存数据，key=" + key);
//			}
//		}else{
//			return true;
//		}
		return jdCouldRedisUtils.exists(key);
	}
	
	@Override
	public long ttl(String key) {
		return jdCouldRedisUtils.ttl(key);
	}
	

	@Override
	public Boolean setNx(String key, String value) {
		return jdCouldRedisUtils.setNx(key, value);
	}
	
	@Override
	public boolean setStringByExpire(String key, String value, long seconds,
			TimeUnit timeUnit) {
		return jdCouldRedisUtils.setStringByExpire(key, value, seconds, timeUnit);
	}
	
	@Override
	public boolean addToListHead(String key, Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object getFromListTail(String key, Class<?> clazz) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> List<T> getListInfo(String key, Class<T> clazz) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getListSize(String key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean setObject(String key, Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	

	@Override
	public <T> T getObject(String key, Class<T> clazz) {
		// TODO Auto-generated method stub
		return null;
	}


	

	@Override
	public Long addToSet(String key, Object object) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> List<T> getSortSetInfo(String key, Class<T> clazz) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> List<T> getSetInfo(String key, Class<T> clazz) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T getFromSortSetByIndex(String key, Class<T> clazz, long index) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delFromSortSet(String key, Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delFromSortSetByScore(String key, long start, long end) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long getSortSetSize(String key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long incrString(String key) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public boolean setHset(String tableName, String key, String value) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean setMset(String tableName, Map<String, String> map) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getHsetValue(String tableName, String key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<String> getHkeys(String tableName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hdel(String tableName, String... key) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Long zcard(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	
//	public void setRedisUtilsOld(RedisUtils redisUtilsOld) {
//		this.redisUtilsOld = redisUtilsOld;
//	}


	public void setJdCouldRedisUtils(JdCacheUtils jdCouldRedisUtils) {
		this.jdCouldRedisUtils = jdCouldRedisUtils;
	}


	@Override
	public <T> T getPersistentData(String id) {
		// TODO Auto-generated method stub
		return null;
	}




	@Override
	public boolean setObjectByExpire(String key, Object object, long seconds,
			TimeUnit timeUnit) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean expire(String key, long seconds, TimeUnit timeUnit) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public Boolean addToSortSet(String key, double score, Object object) {
		// TODO Auto-generated method stub
		return null;
	}




	@Override
	public Long batchAddToSortSet(String key, Set<StringTuple> skuMap) {
		// TODO Auto-generated method stub
		return null;
	}




	@Override
	public Boolean expireAt(String key, Date unixTime) {
		// TODO Auto-generated method stub
		return null;
	}


	
}
