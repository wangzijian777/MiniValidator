package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.NotSubmitOrderTask;

/**
 * 未确定订单任务表dao层接口
 * @author cdgaoqing
 *
 */
public interface NotSubmitOrderTaskDao {
	/**
	 * 获取7天内未确定的订单任务列表
	 * @param orderTask
	 * @return
	 */
	public List<NotSubmitOrderTask> selectUnexectuedTask(NotSubmitOrderTask orderTask);
	
	/**
	 * 根据订单id获取7天未确定订单任务
	 * @param orderId
	 * @return
	 */
	public NotSubmitOrderTask selectTaskByOrderId(long orderId);
	
	/**
	 * 更新任务状态为执行
	 * @param orderTask
	 * @return
	 */
	public int updateTaskState2Exectued(long id);
	
	/**
	 * 新增未确定订单任务
	 * @param orderTask
	 */
	public void insertOrderTask(NotSubmitOrderTask orderTask);
}
