package com.jd.sns.biz.api.dao.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizOrderDao;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.CheckOrderPage;
import com.jd.sns.biz.order.domain.BizOrderQuery;

public class BizOrderDaoImpl extends BaseDao implements BizOrderDao {

	@Override
	public Long submitOrder(BizOrder bizOrder) {
		return (Long)super.insert("BizOrder.submitOrder", bizOrder);
	}

	@Override
	public int updateOrderState(BizOrder bizOrder) {
		return super.update("BizOrder.updateOrderState", bizOrder);
	}

	@Override
	public BizOrder selectJdOrder(BizOrder bizOrder) {
		return (BizOrder)super.queryForObject("BizOrder.selectJdOrder", bizOrder);
	}
	
	public BizOrder selectBizOrderByQuery(BizOrderQuery bizOrderQuery) {
		return (BizOrder)super.queryForObject("BizOrder.selectBizOrderByQuery", bizOrderQuery);
	}

	@Override
	public BizOrder selectParentJdOrderByThirdOrder(BizOrderQuery bizOrderQuery) {
		return (BizOrder)super.queryForObject("BizOrder.selectParentJdOrderByThirdOrder", bizOrderQuery);
	}

	@Override
	public int checkThirdOrderExist(BizOrder bizOrder) {
		return (Integer)super.queryForObject("BizOrder.checkThirdOrderExist", bizOrder);
	}

	@Override
	public List<BizOrder> selectChildJdOrder(BizOrder bizOrder) {
		return super.queryForList("BizOrder.selectChildJdOrder", bizOrder);
	}

	@Override
	public int checkDemandOrderExist(BizOrder bizOrder) {
		return (Integer)super.queryForObject("BizOrder.checkDemandOrderExist", bizOrder);
	}

	@Override
	public int checkBizOrderExistByClientIdAndOrderId(BizOrder bizOrder) {
		return (Integer)super.queryForObject("BizOrder.checkBizOrderExistByClientIdAndOrderId", bizOrder);
	}
	
	@Override
	public int getTotalNumByCreateDateAndState(CheckOrderPage page) {
		return (Integer)super.queryForObject("BizOrder.getTotalNumByCreateDateAndState", page);
	}
	
	@Override
	public List getBizOrderByCreateDateAndPageAndState(CheckOrderPage page) {
		return super.queryForList("BizOrder.getBizOrderByCreateDateAndPageAndState", page);
	}
	
	@Override
	public int getTotalNumByTrackDateAndState(CheckOrderPage page) {
		return (Integer)super.queryForObject("BizOrder.getTotalNumByTrackDateAndState", page);
	}

	@Override
	public List getBizOrderByTrackDateAndPageAndState(CheckOrderPage page) {
		return super.queryForList("BizOrder.getBizOrderByTrackDateAndPageAndState", page);
	}
	
	@Override
	public int getTotalNumByInvoiceState(CheckOrderPage page) {
		return (Integer)super.queryForObject("BizOrder.getTotalNumByInvoiceState", page);
	}

	@Override
	public List getBizOrderByInvoiceState(CheckOrderPage page) {
		return super.queryForList("BizOrder.getBizOrderByInvoiceState", page);
	}

	@Override
	public List getBizOrderByHangUpState(String client_id) {
		return super.queryForList("BizOrder.getBizOrderByHangUpState", client_id);
	}
	
	@Override
	public int updateHangUpState(BizOrder bizOrder) {
		return super.update("BizOrder.updateHangUpState", bizOrder);
	}
	
	@Override
	public int updateSubmitOrderStateById(BizOrder bizOrder) {
		return super.update("BizOrder.updateSubmitOrderStateById", bizOrder);
	}
	
	@Override
	public int confirmSubmitOrder(BizOrder bizOrder) {
		return super.update("BizOrder.confirmSubmitOrder", bizOrder);
	}

	@Override
	public int updateOneOrderState(BizOrder bizOrder) {
		return super.update("BizOrder.updateOneOrderState", bizOrder);
	}

	@Override
	public List<BizOrder> selectJdOrderListByThirdOrder(String thirdOrder, String clientId) {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setThirdOrder(thirdOrder);
		bizOrder.setClientId(clientId);
		return super.queryForList("BizOrder.selectJdOrderListByThirdOrder", bizOrder);
	}

	@Override
	public List<BizOrder> selectBizOrderListByThirdOrder(
			BizOrderQuery bizOrderQuery) {
		return super.queryForList("BizOrder.selectBizOrderListByThirdOrder", bizOrderQuery);
	}
	
	public List<BizOrder> selectChildOrderListByOrderQuery(BizOrderQuery bizOrderQuery) {
		return super.queryForList("BizOrder.selectChildOrderListByOrderQuery", bizOrderQuery);
	}

	/**
	 * 通过jdOrderId及（client_id或者pin）更新bizOrder中不为空的属性
	 * @param bizOrder
	 * @return
	 */
	public int updateOrderByJdOrderId(BizOrder bizOrder) {
		return super.update("BizOrder.updateOrderByJdOrderId", bizOrder);
	}
	
	
	/**
	 * 通过query对象查询指定用户下的订单总数
	 * @param bizOrderQuery
	 * @return
	 */
	public int selectOrderCountByQuery(BizOrderQuery bizOrderQuery) {
		return (Integer)super.queryForObject("BizOrder.selectOrderCountByQuery", bizOrderQuery);
	}

	/**
	 * 通过bizOrderQuery对象，分页查询指定用户下的订单列表
	 * @param bizOrderQuery
	 * @return
	 */
	public List<BizOrder> selectOrderListByQueryAndPage(BizOrderQuery bizOrderQuery) {
		return super.queryForList("BizOrder.selectOrderListByQueryAndPage", bizOrderQuery);
	}
	
	
	/**
	 * 查询时间范围内（jdOrderState限定），用户pin限定的订单列表总数
	 * @param bizOrderQuery
	 * @return
	 */
	public int selectBizOrderCountByDate(BizOrderQuery bizOrderQuery) {
		return (Integer)super.queryForObject("BizOrder.selectBizOrderCountByDate", bizOrderQuery);
	}

	/**
	 * 查询时间范围内（jdOrderState限定），用户pin限定的订单列表
	 * @param bizOrderQuery
	 * @param containSku 
	 * 			是否包含sku信息（封装sku相关的信息）
	 * @return
	 */
	public List<BizOrder> selectBizOrderListByDateAndPage(BizOrderQuery bizOrderQuery) {
		return super.queryForList("BizOrder.selectBizOrderListByDateAndPage", bizOrderQuery);
	}
	
	/**
	 * 查询日期范围内（jdOrderState限定），用户pin的订单总金额
	 * @param bizOrderQuery
	 * @return
	 */
	public BigDecimal countBizOrderAmountByState(BizOrderQuery bizOrderQuery) {
		return (BigDecimal) super.queryForObject("BizOrder.countBizOrderAmountByState",bizOrderQuery);
	}
	

	/**
	 * 通过jdOrderIds 批量查询订单列表
	 * @param jdOrderIds
	 * @return
	 */
	public List<BizOrder> getBizOrderDetailByJdOrderIds(List<Long> jdOrderIds) {
		return super.queryForList("BizOrder.getBizOrderDetailByJdOrderIds", jdOrderIds);
	}
	
	@Override
	public int getTotalNumByTrackAndState(CheckOrderPage page) {
		return (Integer)super.queryForObject("BizOrder.getTotalNumByTrackAndState", page);
	}

	@Override
	public List getBizOrderByTrackAndPageAndState(CheckOrderPage page) {
		return super.queryForList("BizOrder.getBizOrderByTrackAndPageAndState", page);
	}
	
	@Override
	public int updateOrderRemarkById(BizOrder bizOrder) {
		return super.update("BizOrder.updateOrderRemarkById", bizOrder);
	}
}
