package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizOrderTaskDao;
import com.jd.sns.biz.api.domain.BizOrderTask;

public class BizOrderTaskDaoImpl extends BaseDao implements BizOrderTaskDao {
	private static final String NAME_SPACE = "BizOrderTask.";
	
	@Override
	public void insertBizOrderTask(BizOrderTask bizOrderTask) {
		insert(NAME_SPACE + "insertBizOrderTask", bizOrderTask);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BizOrderTask> selectUnexectuedTask(BizOrderTask bizOrderTask) {
		return queryForList(NAME_SPACE + "selectUnexectuedTask", bizOrderTask);
	}

	@Override
	public void updateTaskStateExectued(BizOrderTask bizOrderTask) {
		update(NAME_SPACE + "updateTaskStateExectued", bizOrderTask);
	}

	@Override
	public void updateFailureCount(long id) {
		update(NAME_SPACE + "updateFailureCount", id);
	}

	@Override
	public void delExectuedTask(BizOrderTask orderTask) {
		delete(NAME_SPACE + "delExectuedTask", orderTask);
	}

	@Override
	public BizOrderTask selectTaskByOrderId(BizOrderTask orderTask) {
		@SuppressWarnings("unchecked")
		List<BizOrderTask> tasks = queryForList(NAME_SPACE+"selectTaskByOrderId", orderTask);
		if(tasks.isEmpty()){
			return null;
		}
		return tasks.get(0);
	}

    @Override
    public Long countBizOrderTask(BizOrderTask bizOrderTask) {
        return (Long) this.queryForObject(NAME_SPACE + "countTask", bizOrderTask);
    }

}
