package com.jd.sns.biz.api.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.CheckOrderPage;
import com.jd.sns.biz.order.domain.BizOrderQuery;

public interface BizOrderDao {

	
	public Long submitOrder(BizOrder bizOrder);
	
	
	
	public int updateOrderState(BizOrder bizOrder);
	

	public BizOrder selectJdOrder(BizOrder bizOrder);

	
	public BizOrder selectBizOrderByQuery(BizOrderQuery bizOrderQuery);
	
	
	public BizOrder selectParentJdOrderByThirdOrder(BizOrderQuery bizOrderQuery);
	
	public int checkThirdOrderExist(BizOrder bizOrder);
	
	public List<BizOrder> selectChildJdOrder(BizOrder bizOrder);
	
	public int checkDemandOrderExist(BizOrder bizOrder);
	
	public int checkBizOrderExistByClientIdAndOrderId(BizOrder bizOrder);
	
	/**
	 * 获得某一日期下所有新创建订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByCreateDateAndState(CheckOrderPage page);
	
	/**
	 * 获得某一日期下所有新创建订单分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByCreateDateAndPageAndState(CheckOrderPage page);
	
	/**
	 * 获得某一日期下所有妥投或者拒收订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByTrackDateAndState(CheckOrderPage page);
	
	/**
	 * 获得某一日期下所有妥投或者拒收的分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByTrackDateAndPageAndState(CheckOrderPage page);
	
	/**
	 * 获得某天之前的所有未开发票的订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByInvoiceState(CheckOrderPage page);
	
	/**
	 * 获得某天之前的所有未开发票的订单分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByInvoiceState(CheckOrderPage page);
	
	/**
	 * 获得所有被挂起订单接口
	 * @param client_id
	 * @return
	 */
	public List getBizOrderByHangUpState(String client_id);
	
	/**
	 * 挂起订单
	 * @param clientId
	 * @param jdOrderId
	 * @param hangUpState
	 * @return
	 */
	public int updateHangUpState(BizOrder bizOrder);
	
	/**
	 * 更改订单信息
	 * @param bizOrder
	 * @return
	 */
	public int updateSubmitOrderStateById(BizOrder bizOrder);
	/**
	 * 确认订单
	 * @param bizOrder
	 * @return
	 */
	public int confirmSubmitOrder(BizOrder bizOrder);
	
	
	
	
	
	
	
	//---------admin--------------
	
	
	public int updateOneOrderState(BizOrder bizOrder);

	/**
	 * 根据第三方订单单号和订单状态查询订单
	 * 
	 * @param thirdOrder
	 * @param clientId
	 */
	public List<BizOrder> selectJdOrderListByThirdOrder(String thirdOrder, String clientId);

	
	/**
	 * 根据第三方订单号和其它限制条件，查询订单信息
	 * @param bizOrderQuery
	 * @return list
	 */
	public List<BizOrder> selectBizOrderListByThirdOrder(
			BizOrderQuery bizOrderQuery);

	/**
	 * 查询本地子单（OrderState = 0 or 1，取消和有效订单，不查询二次拆单类型订单）
	 * @param bizOrderQuery
	 * @return
	 */
	public List<BizOrder> selectChildOrderListByOrderQuery(BizOrderQuery bizOrderQuery);

	/**
	 * 通过jdOrderId及（client_id或者pin）更新bizOrder中不为空的属性
	 * @param bizOrder
	 * @return
	 */
	public int updateOrderByJdOrderId(BizOrder bizOrder);



		
	/**
	 * 通过query对象查询指定用户下的订单总数
	 * @param bizOrderQuery
	 * @return
	 */
	public int selectOrderCountByQuery(BizOrderQuery bizOrderQuery);

	/**
	 * 通过bizOrderQuery对象，分页查询指定用户下的订单列表
	 * @param bizOrderQuery
	 * @return
	 */
	public List<BizOrder> selectOrderListByQueryAndPage(BizOrderQuery bizOrderQuery);



		
	/**
	 * 查询时间范围内（jdOrderState限定），用户pin限定的订单列表总数
	 * @param bizOrderQuery
	 * @return
	 */
	public int selectBizOrderCountByDate(BizOrderQuery bizOrderQuery);

	/**
	 * 查询时间范围内（jdOrderState限定），用户pin限定的订单列表
	 * @param bizOrderQuery
	 * @param containSku 
	 * 			是否包含sku信息（封装sku相关的信息）
	 * @return
	 */
	public List<BizOrder> selectBizOrderListByDateAndPage(BizOrderQuery bizOrderQuery);



	public BigDecimal countBizOrderAmountByState(BizOrderQuery bizOrderQuery);


	/**
	 * 通过jdOrderIds 批量查询订单列表
	 * @param jdOrderIds
	 * @return
	 */
	public List<BizOrder> getBizOrderDetailByJdOrderIds(List<Long> jdOrderIds);
	
	/**
	 * 根据订单状态变更日期和状态查询所有订单状态的数量
	 * @param page
	 * @return
	 */
	public int getTotalNumByTrackAndState(CheckOrderPage page);
	
	/**
	 * 查询订单状态变更日期间指定状态的分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByTrackAndPageAndState(CheckOrderPage page);
	
	/**
	 * 更改订单备注信息
	 * @param bizOrder
	 * @return
	 */
	public int updateOrderRemarkById(BizOrder bizOrder);
}
