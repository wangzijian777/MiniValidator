package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.NotSubmitOrderTaskDao;
import com.jd.sns.biz.api.domain.NotSubmitOrderTask;

/**
 * 未确定订单任务表dao层实现
 * @author cdgaoqing
 *
 */
public class NotSubmitOrderTaskDaoImpl extends BaseDao implements
		NotSubmitOrderTaskDao {
	
	private static final String NAME_SPACE = "NotSubmitOrderTask.";

	@SuppressWarnings("unchecked")
	@Override
	public List<NotSubmitOrderTask> selectUnexectuedTask(
			NotSubmitOrderTask orderTask) {
		return (List<NotSubmitOrderTask>)super.queryForList(NAME_SPACE+"selectUnexectuedTask", orderTask);
	}

	@Override
	public int updateTaskState2Exectued(long id) {
		return super.update(NAME_SPACE+"updateTaskState2Exectued", id);
	}

	@Override
	public NotSubmitOrderTask selectTaskByOrderId(long orderId) {
		return (NotSubmitOrderTask) super.queryForObject(NAME_SPACE+"selectTaskByOrderId", orderId);
	}

	@Override
	public void insertOrderTask(NotSubmitOrderTask orderTask) {
		super.insert(NAME_SPACE+"insertOrderTask", orderTask);
	}

}
