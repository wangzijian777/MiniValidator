package com.jd.sns.biz.api.virtual.dao;

import com.jd.sns.biz.api.virtual.domain.VirtualSku;
import com.jd.sns.biz.api.virtual.query.VirtualSkuQuery;
import java.util.List;

/**
 * 数据访问对象接口
 * @since 2014-08-22
 */
public interface VirtualSkuDAO {

    /**
     * 插入数据
     * @param virtualSku
     * @return 插入数据的主键
     */
    public Long insertVirtualSku(VirtualSku virtualSku);

    /**
     * 统计记录数
     * @param virtualSkuQuery
     * @return 查出的记录数
     */
    public Integer countVirtualSkuByExample(VirtualSkuQuery virtualSkuQuery);

    /**
     * 更新记录
     * @param virtualSku
     * @return 受影响的行数
     */
    public Integer updateVirtualSku(VirtualSku virtualSku);

    /**
     * 获取对象列表
     * @param virtualSku
     * @return 对象列表
     */
    public List<VirtualSku> findListByExample(VirtualSkuQuery virtualSkuQuery);

    /**
     * 根据主键获取virtualSkuDO
     * @param id
     * @return virtualSkuDO
     */
    public VirtualSku findVirtualSkuByPrimaryKey(Long id);

    /**
     * 删除记录
     * @param id
     * @return 受影响的行数
     */
    public Integer deleteVirtualSkuByPrimaryKey(Long id);

}