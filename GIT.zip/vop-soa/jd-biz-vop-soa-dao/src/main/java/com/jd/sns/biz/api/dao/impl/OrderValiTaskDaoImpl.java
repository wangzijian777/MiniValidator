package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.OrderValiTaskDao;
import com.jd.sns.biz.api.domain.OrderValiTask;

/**
 * 订单校验任务dao层实现
 * @author cdgaoqing
 *
 */
public class OrderValiTaskDaoImpl extends BaseDao implements OrderValiTaskDao {
	
	private static final String NAME_SPACE = "OrderValiTask.";
	
	@SuppressWarnings("unchecked")
	@Override
	public List<OrderValiTask> selectUnexectuedTask() {
		return (List<OrderValiTask>)super.queryForList(NAME_SPACE+"selectUnexectuedTask");
	}

	@Override
	public int updateTaskState2Exectued(OrderValiTask orderTask) {
		return super.update(NAME_SPACE+"updateTaskState2Exectued", orderTask);
	}

	@Override
	public int updateFailtureCount(OrderValiTask orderTask) {
		return super.update(NAME_SPACE+"updateFailureCount", orderTask);
	}

	@Override
	public Long addOrderValiTask(OrderValiTask orderValiTask) {
		return (Long) super.insert(NAME_SPACE+"addOrderValiTask", orderValiTask);
	}

	
}
