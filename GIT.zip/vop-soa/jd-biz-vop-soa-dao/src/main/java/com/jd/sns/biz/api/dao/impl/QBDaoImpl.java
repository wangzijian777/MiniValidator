package com.jd.sns.biz.api.dao.impl;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.QBDao;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class QBDaoImpl extends BaseDao implements QBDao {

	@Override
	public BigDecimal getQBPrice(String facePrice, String clientId) {
		Map<String,String> params=new HashMap<String,String>();
		params.put("facePrice", facePrice);
		params.put("clientId", clientId);
		return (BigDecimal)super.queryForObject("QBPrice.getQBPrice", params);
	}

	@Override
	public int getQBUserState(String clientId) {
		Map<String,String> params=new HashMap<String,String>();
		params.put("type","2");//Q币充值为2
		params.put("clientId", clientId);
		return (Integer)super.queryForObject("QBPrice.getQBUserStateCount", params);
	}



}
