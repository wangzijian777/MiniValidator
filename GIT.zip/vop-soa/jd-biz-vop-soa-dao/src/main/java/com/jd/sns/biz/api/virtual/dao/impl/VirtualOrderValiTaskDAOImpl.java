package com.jd.sns.biz.api.virtual.dao.impl;

import com.jd.sns.biz.api.virtual.dao.VirtualOrderValiTaskDAO;
import com.jd.sns.biz.api.virtual.domain.VirtualOrderValiTask;
import com.jd.sns.biz.api.virtual.query.VirtualOrderValiTaskQuery;
import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

/**
 * 数据访问对象实现类
 * @since 2014-08-22
 */
public class VirtualOrderValiTaskDAOImpl extends SqlMapClientDaoSupport implements VirtualOrderValiTaskDAO {

    /**
     * 插入数据
     * @param virtualOrderValiTask
     * @return 插入数据的主键
     */
    public Long insertVirtualOrderValiTask(VirtualOrderValiTask virtualOrderValiTask) {
        Object obj = getSqlMapClientTemplate().insert("VirtualOrderValiTask.insert", virtualOrderValiTask);
        Long id = (Long) obj;
        // 新插入都将id设置回去
        virtualOrderValiTask.setId(id);
        return id;
    }

    /**
     * 统计记录数
     * @param virtualOrderValiTaskQuery
     * @return 查出的记录数
     */
    public Integer countVirtualOrderValiTaskQueryByExample(VirtualOrderValiTaskQuery virtualOrderValiTaskQuery) {
        Integer count = (Integer) getSqlMapClientTemplate().queryForObject("VirtualOrderValiTask.countByQueryExample", virtualOrderValiTaskQuery);
        return count;
    }

    /**
     * 更新记录
     * @param virtualOrderValiTask
     * @return 受影响的行数
     */
    public Integer updateVirtualOrderValiTask(VirtualOrderValiTask virtualOrderValiTask) {
        int result = getSqlMapClientTemplate().update("VirtualOrderValiTask.update", virtualOrderValiTask);
        return result;
    }

    /**
     * 获取对象列表
     * @param virtualOrderValiTaskQuery
     * @return 对象列表
     */
    @SuppressWarnings("unchecked")
    public List<VirtualOrderValiTask> findListByExample(VirtualOrderValiTaskQuery virtualOrderValiTaskQuery) {
        List<VirtualOrderValiTask> list = getSqlMapClientTemplate().queryForList("VirtualOrderValiTask.findListByQuery", virtualOrderValiTaskQuery);
        return list;
    }

    /**
     * 根据主键获取virtualOrderValiTaskDO
     * @param id
     * @return virtualOrderValiTaskDO
     */
    public VirtualOrderValiTask findVirtualOrderValiTaskByPrimaryKey(Long id) {
        VirtualOrderValiTask virtualOrderValiTask = (VirtualOrderValiTask) getSqlMapClientTemplate().queryForObject("VirtualOrderValiTask.findByPrimaryKey", id);
        return virtualOrderValiTask;
    }

    /**
     * 删除记录
     * @param id
     * @return 受影响的行数
     */
    public Integer deleteVirtualOrderValiTaskByPrimaryKey(Long id) {
        Integer rows = (Integer) getSqlMapClientTemplate().delete("VirtualOrderValiTask.deleteByPrimaryKey", id);
        return rows;
    }

}