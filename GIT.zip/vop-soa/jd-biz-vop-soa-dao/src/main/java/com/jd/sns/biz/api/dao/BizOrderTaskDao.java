package com.jd.sns.biz.api.dao;

import java.util.List;
import com.jd.sns.biz.api.domain.BizOrderTask;

/**
 * 订单任务Dao层，
 * 一般的逻辑为：下单时新增一条任务，
 * 使用worker查询为处理任务进行处理，
 * 如果成功则回写状态，如果失败则给失败次数+1
 * 最后有个worker将会定期删除已经执行成功的任务
 * @author cdwangzijian
 *
 */
public interface BizOrderTaskDao {
	
	/**
	 * 新增一条订单任务
	 * @param bizOrderTask
	 */
	public void insertBizOrderTask(BizOrderTask bizOrderTask);
	
	/**
	 * 查询未执行通过的任务
	 * 
	 * @param bizOrderTask
	 * 		查询中会用到对象中的created的属性和type属性
	 * @return
	 */
	public List<BizOrderTask> selectUnexectuedTask(BizOrderTask bizOrderTask);
	
	/**
	 * 更新任务状态为已经执行
	 * @param bizOrderTask
	 * @return
	 */
	public void updateTaskStateExectued(BizOrderTask bizOrderTask);
	
	/**
	 * 更新失败执行次数+1
	 * @param id
	 * @return
	 */
	public void updateFailureCount(long id);
	
	/**
	 * 删除一定日期后已经执行的任务
	 * @param orderTask
	 * 		根据type和created进行删除
	 */
	public void delExectuedTask(BizOrderTask orderTask);
	
	/**
	 * 根据orderId和类型查出任务
	 * orderId没有做外键关联，没有做唯一索引，目前使用业务逻辑保证唯一性的
	 * @param orderTask
	 * 		使用orderId和type作为查询参数
	 * @return
	 */
	public BizOrderTask selectTaskByOrderId(BizOrderTask orderTask);
	
	public Long countBizOrderTask(BizOrderTask bizOrderTask);
	
}
