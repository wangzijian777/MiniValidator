package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.OrderValiTask;


/**
 * 未确定订单任务表dao层接口
 * @author cdgaoqing
 *
 */
public interface OrderValiTaskDao {
	/**
	 * 获取7天内未确定的订单任务列表
	 * @param orderTask
	 * @return
	 */
	public List<OrderValiTask> selectUnexectuedTask();
	
	/**
	 * 更新任务状态为执行
	 * @param id
	 * @return
	 */
	public int updateTaskState2Exectued(OrderValiTask orderTask);
	
	/**
	 * 更新任务失败次数
	 * @param orderTask
	 * @return
	 */
	public int updateFailtureCount(OrderValiTask orderTask);

	/**
	 * 插入一条记录
	 * @param orderValiTask
	 * @return
	 */
	public Long addOrderValiTask(OrderValiTask orderValiTask);
}
