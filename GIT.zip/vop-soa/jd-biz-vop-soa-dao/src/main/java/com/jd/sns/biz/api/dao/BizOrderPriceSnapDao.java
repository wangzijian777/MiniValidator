package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.BizOrderPriceSnap;


/**
 * Order Price Service Snap
 * @author cdwangzijian
 *
 */
public interface BizOrderPriceSnapDao {
	
	/**
	 * @return
	 */
	public List<BizOrderPriceSnap> getAll();
	
	/**
	 * 插入一条快照，因为是自增主键，不用给id赋值
	 * @param priceSnap
	 * @return
	 */
	public void insertSnap(BizOrderPriceSnap priceSnap);
}
