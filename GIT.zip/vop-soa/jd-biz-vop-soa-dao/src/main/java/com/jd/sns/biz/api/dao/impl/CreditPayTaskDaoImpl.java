package com.jd.sns.biz.api.dao.impl;



import java.util.List;

import org.springframework.util.CollectionUtils;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.CreditPayTaskDao;
import com.jd.sns.biz.api.domain.CreditPayTask;

public class CreditPayTaskDaoImpl extends BaseDao implements CreditPayTaskDao {

	@Override
	public void deleteCreditPayTaskById(Long id) {
		super.delete("CreditPayTask.deleteCreditPayTaskById", id);
	}

	@Override
	public void insertCreditPayTask(CreditPayTask creditPayTask) {
		super.insert("CreditPayTask.insertCreditPayTask", creditPayTask);
	}
	
	@Override
	public int updateCreditPayTask(CreditPayTask creditPayTask) {
		return super.update("CreditPayTask.updateCreditPayTask", creditPayTask);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public CreditPayTask selectByJdOrderId(long jdOrderId) {
		List list = super.queryForList("CreditPayTask.selectByJdOrderId", jdOrderId);
		if(CollectionUtils.isEmpty(list)){
			return null;
		}
		return (CreditPayTask)list.get(0);
	}
	@Override
	public int updateTaskForRepay(CreditPayTask creditPayTask) {
		return super.update("CreditPayTask.updateTaskForRepay", creditPayTask);
	}


	
	
}
