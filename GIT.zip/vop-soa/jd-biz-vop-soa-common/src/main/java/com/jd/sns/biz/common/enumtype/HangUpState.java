package com.jd.sns.biz.common.enumtype;

/**
 * 挂起状态
 * @author zhangshibin
 * 
 */
public enum HangUpState {
	
	NO_HANG_UP(0, "未挂起"),
	YES_HANG_UP(1, "挂起");

	private final int type;
	private final String typeName;

	private HangUpState(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static HangUpState getType(int type) {
		for (HangUpState t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
