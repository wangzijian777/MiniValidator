package com.jd.sns.biz.common.enumtype.confirm;
/**
 * 确认接口返回错误码
 * @file ConfirmErrorCode.java
 * @author wangyong
 * @time 2015年6月17日上午10:17:28
 */
public enum ConfirmErrorCode {
	PARAM_ERR("PARAM_ERR", "参数校验未通过"),
	NOT_CONSIST_ERR("NOT_CONSIST_ERR", "本地子单与ERP不一致"),//可创建确认任务
	ALL_IS_CONFIRM_ERR("ALL_IS_CONFIRM_ERR", "订单对应子单已确认无需再确认"),
	CAN_NOT_CONFIRM_ERR("CAN_NOT_CONFIRM_ERR", "子单或原始单不能进行确认"),
	LOCAL_CHILDREN_NOT_GET_ERR("LOCAL_CHILDREN_NOT_GET_ERR", "未查询到本地子单"),
	EXE_CONFIRM_ERR("EXE_CONFIRM_ERR", "执行确认错误");//可创建确认任务
	
	
	private String errorCode;
	private String desc;
	
	private ConfirmErrorCode(String errorCode, String desc) {
		this.errorCode = errorCode;
		this.desc = desc;
	}

	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
