package com.jd.sns.biz.common.enumtype.invoice;

/**
 * 发票抬头
 * 	4个人，5单位
 * @author bjhuming
 */
public enum SelectedInvoiceTitle {

	PERSONAL(4, "个人"),
	COMPANY(5, "单位");

	private final int type;
	private final String typeName;

	private SelectedInvoiceTitle(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static SelectedInvoiceTitle getType(int type) {
		for (SelectedInvoiceTitle t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
