package com.jd.sns.biz.api.common.utils;


public enum ResultCodeConstants {
	
		SUCCESS("0","成功"), 
		NET_ERROR("6000","网络异常，请稍后重试"),
		ERROR_PARAM("6001","参数不正确"),
		
		INVALID_ORDER("6002","该订单不存在"), 
		NOT_COMMIT_ORDER("6003","该订单未确认提交"),
		NOT_CHILD_ORDER("6004","该订单不是子订单"),
		
		NOT_ONE_STATE_ORDER("6005","该订单未妥投"), 
		NOT_NORMAL_ORDER("6006","该订单不是正常订单"),
		NOT_SKUID_ORDER("6007","订单没有该商品编号"),
		
		NOT_SUCCESS_ORDER("6008","该订单是未完成订单"),
		ERROR("555","失败"),
		
		NOT_APPLAY_CREATE("6009", "订单中某商品不可以提交售后服务"),
		OVER_SKU_NUM("6010", "数量超过订单商品数量"),
		NOT_JD_PICKARE("6011", "不属于商品返回京东方式"),
		NOT_APPLAY_EXPECT("6012", "不属于支持的服务类型"),
		
		NOT_VERIFIED_AFS("6013", "服务单未通过审核");

		private String resultCode;
		private String resultMessage;
		private ResultCodeConstants(String resultCode,String resultMessage) {
			this.resultCode = resultCode;
			this.resultMessage=resultMessage;

		}

		public String getResultCode() {
			return resultCode;
		}

		public String getResultMessage() {
			return resultMessage;
		}
}