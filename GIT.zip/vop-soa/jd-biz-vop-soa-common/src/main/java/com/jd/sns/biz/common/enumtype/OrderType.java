package com.jd.sns.biz.common.enumtype;

public enum OrderType {
	NOMAL(1, "普通商品", 0),
	BIG_ITEM(2, "大家电", 0),
	GIFTCARD(3, "实物礼品卡", 49),
	AF_ORDER(4, "售后换新单", 15);

	private final int type;
	private final String typeName;
	private final int jdOrderType;

	private OrderType(int type, String typeName, int jdOrderType) {
		this.type = type;
		this.typeName = typeName;
		this.jdOrderType = jdOrderType;
	}

	public static OrderType getType(int type) {
		for (OrderType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
	
	public int getJdOrderType() {
		return this.jdOrderType;
	}
	
}
