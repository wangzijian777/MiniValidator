package com.jd.sns.util.virtual;


import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 该类是余额支付给的，为了创建dataSign使用
 * @author bjhuming
 */
public class MD5 {
	public static String getMD5Code(String str) throws NoSuchAlgorithmException {
		byte unencoded[] = null;
		try {
			unencoded = str.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		MessageDigest md5 = null;

		md5 = MessageDigest.getInstance("MD5");

		md5.update(unencoded);
		byte encoded[] = md5.digest();
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < encoded.length; i++) {
			if ((encoded[i] & 255) < 16)
				buf.append("0");
			buf.append(Long.toString(encoded[i] & 255, 16));
		}

		return buf.toString().toUpperCase();
	}
}

