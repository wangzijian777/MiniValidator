package com.jd.sns.biz.common.enumtype.confirm;
/**
 * 确认接口返回错误码
 * @file ConfirmErrorCode.java
 * @author wangyong
 * @time 2015年6月17日上午10:17:28
 */
public enum ConfirmResultKey {	
	QUERY_ORDER("bizOrderQuery", "查询条件"),
	FATHER_ORDER("fatherOrder", "父订单对象"),
	LOCAL_CHILD_ORDERS("localChildOrders", "本地子单列表"),
	ERP_CHILD_ORDERS("erpChildOrders", "ERP子单列表");
	
	
	private String key;
	private String desc;
	
	private ConfirmResultKey(String key, String desc) {
		this.key = key;
		this.desc = desc;
	}

	public String getKey() {
		return key;
	}


	public void setKey(String key) {
		this.key = key;
	}


	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
