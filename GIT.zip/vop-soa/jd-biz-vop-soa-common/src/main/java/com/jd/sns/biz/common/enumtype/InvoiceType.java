package com.jd.sns.biz.common.enumtype;

/**
 * 发票类型
 *   1, "普票"  2, "增票"
 * @author bjtt
 */
public enum InvoiceType {

	INVOICE_TYPE_PP(1, "普票"),
	INVOICE_TYPE_ZP(2, "增票");
	
	private final int type;
	private final String typeName;

	private InvoiceType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static InvoiceType getType(int type) {
		for (InvoiceType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
