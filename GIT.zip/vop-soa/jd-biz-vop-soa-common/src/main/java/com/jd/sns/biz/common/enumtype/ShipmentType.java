package com.jd.sns.biz.common.enumtype;

/**
 * 配送方式
 * 	该字段枚举值参考{@link com.jd.vertical.trade.sdk.export.shipment.dict.ShipmentTypeDict}
 * @author bjhuming
 */
public enum ShipmentType {

	ZITI(64, "自提"),
	JD(65, "京东配送"),
	DISANFANG(66, "第三方配送");

	private final int type;
	private final String typeName;

	private ShipmentType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static ShipmentType getType(int type) {
		for (ShipmentType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
