package com.jd.sns.biz.common.enumtype;

/**
 * 开票方式
 * 0, "订单预借"  1, "随货开票"  2, "集中开票"
 * @author bjtt
 */
public enum DoInvoiceType {

	DO_INVOICE_JZKP(2, "集中开票"),
	DO_INVOICE_DDYJ(0, "订单预借"),
	DO_INVOICE_SHKP(1, "随货开票");
	
	private final int type;
	private final String typeName;

	private DoInvoiceType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static DoInvoiceType getType(int type) {
		for (DoInvoiceType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
