package com.jd.sns.biz.api.constant;

import com.jd.sns.biz.common.enumtype.InvoiceState;
import com.jd.sns.biz.common.enumtype.IsUseBalance;
import com.jd.sns.biz.common.enumtype.PaymentType;
import com.jd.sns.biz.common.enumtype.SubmitState;



public class OrderConstants {

	/** 激活状态 - 未激活(预占库存)**/
	public static final int UNACTIVE = SubmitState.DELAY.getType();
	/** 激活状态 - 已激活(直接发货)**/
	public static final int ACTIVEED = SubmitState.ACTIVE.getType();
	
	/** 拆单状态 - 原始订单 **/
	public static final int UNSPLIT = 0;
	/** 拆单状态 - 拆单后为父订单 **/
	public static final int SPLITED_PARENT = 1;
	/** 拆单状态 - 拆单后为子订单 **/
	public static final int SPLITED_CHILD = 2;
	/** 拆单状态 - 二次拆单 **/
	public static final int SPLITED_SECOND = 3;
	
	/** 定时任务状态(金融支付，金融支付失败任务)  - 未处理 **/
	public static final int WAIT_PROCESS = 0	;
	/** 定时任务状态 (金融支付，金融支付失败任务)  - 已处理 **/
	public static final int PROCESSED = 1;
	
	
	/** 定时任务状态 (订单校验，7天未确认任务) - 未处理 **/
	public static final int TASK_WAIT_PROCESS = 1;
	/** 定时任务状态 (订单校验，7天未确认任务)  - 已处理 **/
	public static final int TASK_PROCESSED = 2;
	
	public static final String SKU_STOCK_CHECK="vop_order_sku_stock_check";
	public static final String SKU_AREA_LIMIT="vop_order_sku_area_limit";	
	
	/** 支付方式 - 月结 **/
	public static final int PAYMENT_MONTHLY = PaymentType.YUEJIE.getType();
	/** 支付方式 - 在线支付 **/
	public static final int PAYMENT_ONLINE = PaymentType.ZAIXIANZHIFU.getType();
	
	/**
	 * 订单组订单状态说明页面：
	 * 	http://cf.360buy-develop.com/pages/viewpage.action?pageId=2722914
	 */
	/** 订单状态 - 新订单 **/
	public static final int ORDERSTATE_NEW = 1;
	/** 订单状态 - 等待付款 **/
	public static final int ORDERSTATE_WAITED_PAY = 2;
	/** 订单状态 - 暂停 **/
	public static final int ORDERSTATE_PAUSE = 5;
	/** 订单状态 - 等待出库 **/
	public static final int ORDERSTATE_OUTSTOCK = 8;
	/** 订单状态 - 确认收货 **/
	public static final int ORDERSTATE_RECEIVED = 16;
	/** 订单状态 - 完成 **/
	public static final int ORDERSTATE_FINISH = 19;
	
	/** 是否开发票 - 否 **/
	public static final int ORDER_NO_INVOICE = InvoiceState.NO_INVOICE.getType();
	/** 是否开发票 - 是 **/
	public static final int ORDER_YES_INVOICE = InvoiceState.YES_INVOICE.getType();
	
	
	
	/** 是否使用余额 - 是 **/
	public static final int ORDER_USED_BALANCE = IsUseBalance.USED_BALANCE.getType();
	/** 是否使用余额 - 否 **/
	public static final int ORDER_UNUSED_BALANCE = IsUseBalance.NOT_USED_BALANCE.getType();
	
	
	
	
	/** 订单状态 - 无效(订单已被取消) **/
	public static final int ORDER_UNAVAILABLE = 0;
	/** 订单状态 - 有效(订单生产) **/
	public static final int ORDER_AVAILABLE = 1;
	/** 订单状态 - 二次拆单 **/
	public static final int ORDER_SPLIT_TWICE = 2;
	
	
	
	/** 订单物流状态 - 0 下单默认 **/
	public static final int ORDER_SHIP_STATE_DEFAULT = 0;
	/** 订单物流状态 - 1 妥投 **/
	public static final int ORDER_SHIP_STATE_DELIVERD = 1;
	/** 订单物流状态 - 2 拒收 **/
	public static final int ORDER_SHIP_STATE_REJECT = 2;

	
	
	
	
	/** Q币商品三级分类 **/
	public static final int QB_CATEGORY = 4709;
	
	
	
	
	/**
	 * 标准的是否属性，1是，0否
	 */
	public static final int STD_YES_NO_YES=1;
	public static final int STD_YES_NO_NO=0;
	
	/**
	 * remark字段最大长度
	 */
	public static final int REMARK_MAX_LEGTH = 150;
	
	// 订单拆单前缀
	public static final String SPLITED_ORDER_PREFIX = "vop_splited_order_prefix_";
	
	// 分隔符
	public static final String AREA_SPLIT = "-";
	
	public static final int REPEAT_ORDER_SOURCE_TYPE = 100;
	
	public static final String PAY_FLAG_VOP = "flag_vop";
	
	public static final int MAX_PAGE_SIZE = 1000;
	
}
