
/**
 * 工具类
 * @ClassName: package-info
 * @Description:
 * @author heguang
 * @date 2014年8月28日 下午3:07:36
 */
package com.jd.sns.util;