package com.jd.sns.biz.api.constant;

public class OrderQueryConstant {
	
	/**
	 * 基本属性
	 */
	public static final String BASE="base";
	
	/**
	 * 子订单
	 */
	public static final String CHILD="child";
	
	/**
	 * 发票信息
	 */
	public static final String INVOICE="invoice";
	
	
	/**
	 * sku信息
	 */
	public static final String SKULIST="skuList";
	
	/**
	 * sku详细信息
	 */
	public static final String SKUDETAIL="skuDetail";

	
}
