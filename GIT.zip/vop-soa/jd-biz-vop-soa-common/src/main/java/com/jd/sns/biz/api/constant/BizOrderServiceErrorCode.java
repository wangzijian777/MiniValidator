package com.jd.sns.biz.api.constant;

/**
 * 订单服务错误响应码
 * @author zhangshibin
 * @since 2014-09-11
 *
 */
public class BizOrderServiceErrorCode {
	
	public static final String 	CODE_EXCEPTION="EXCEPTION";	//服务异常，请重新下单
	public static final String 	CODE_PARAM_NOT_NULL="PARAM_NOT_NULL";	//订单参数不能为空
	public static final String 	CODE_PARAM_VALUE_ERROR="PARAM_VALUE_ERROR";	//订单参数值不正确
	public static final String 	CODE_PRODUCT_NOT_EXISTS="PRODUCT_NOT_EXISTS";	//下单商品不存在
	public static final String 	CODE_SUBMIT_ORDER_FAIL="SUBMIT_ORDER_FAIL";	//下单失败或订单组返回错误信息
	public static final String 	CODE_PRUDUCT_NO_STOCK="PRUDUCT_NO_STOCK";	//编号为${skuId}的商品无货
	public static final String 	CODE_MONTHLY_LOCKED="MONTHLY_LOCKED";	//您的配额不足或者已被锁定，请联系客服
	public static final String 	CODE_LACK_MONEY="LACK_MONEY";	//支付余额不足
	public static final String 	CODE_STOCK_AREA_LIMIT="STOCK_AREA_LIMIT";	//商品库存和商品区域限制
	public static final String 	CODE_BIG_ELE_GOODS_LIMIT="BIG_ELE_GOODS_LIMIT";	//大家电后款预占库存限制
	public static final String     CODE_BIG_SKU_IS_52="BIG_SKU_IS_52"; //大家电后款预占为52号仓商品
    public static final String    CODE_DISTINGUISH_SKU = "DISTINGUISH_SKU";   //区分大家电中小件商品
    public static final String    CODE_BIG_SKU_NOT_COD = "BIG_NOT_COD";   //大家电不支持货到付款
    public static final String    CODE_BIG_STOCK_AREA_LIMIT ="STOCK_BIG_AREA_LIMIT";//大家电商品区域限制接口

	public static final String 	CODE_FAST_SUBMIT_SAME_ORDER="FAST_SUBMIT_SAME_ORDER";	//短时间提交重复订单
	public static final String 	CODE_THIRD_ORDER_ID_USED="THIRD_ORDER_ID_USED";	//第三方订单单号已被使用
	
	public static final String CODE_BIZ_ORDER_ALREADY_CANCEL = "BIZ_ORDER_ALREADY_CANCEL"; //订单已经被取消
	public static final String CODE_BIZ_ORDER_NOT_EXISTS = "BIZ_ORDER_NOT_EXISTS"; //订单不存在
	public static final String CODE_BIZ_ORDER_ALREADY_SUBMIT = "BIZ_ORDER_ALREADY_SUBMIT"; //订单已经确认
	public static final String CODE_CANNOT_ACTIVE_CHILD_ORDER = "CANNOT_ACTIVE_CHILD_ORDER"; //不能单独激活子订单
	public static final String CODE_BIZ_ORDER_AREADY_OUT = "BIZ_ORDER_AREADY_OUT"; //订单已进入生产
	public static final String CODE_CANNOT_CANCEL_UNACTIVE_ORDER = "CANNOT_CANCEL_UNACTIVE_ORDER";  //不能取消未激活的订单
	public static final String CODE_CANNOT_CANCEL_PARENT_ORDER = "CANNOT_CANCEL_PARENT_ORDER";  //不能取消父订单
	public static final String CODE_CANNOT_CANCEL_ACTIVED_ORDER = "CANNOT_CANCEL_ACTIVED_ORDER "; //不能取消已经激活的订单
 	public static final String CODE_CANNOT_CANCEL_CHILD_ORDER = "CANNOT_CANCEL_CHILD_ORDER";   //不能取消子订单
	public static final String CODE_ACTIVE_ORDER_ERROR = "ACTIVE_ORDER_ERROR";  //激活订单失败
	public static final String CODE_OOM_SERVICE_EXCEPTION = "OOM_SERVICE_EXCEPTION";	//调用订单中间件失败
	public static final String CODE_GET_SPLITORDER_EXCEPTION = "GET_SPLITORDER_EXCEPTION"; //获取拆单信息失败
	public static final String CODE_BIZ_ORDER_CANCEL_ERROR = "BIZ_ORDER_CANCEL_ERROR"; 	//取消订单操作失败
	public static final String CODE_PROMOTION_ERROR = "PROMOTION_ERROR"; //查询商品出现信息错误
	public static final String CODE_TOO_MANY_SKU = "TOO_MANY_SKU";  //商品数量太多
	public static final String CODE_NOT_COD="NOT_COD_ORDER"; //不能进行货到付款下单
	public static final String CODE_CANNOT_GET_ADDRESS_INFO="CAN_NOT_GET_ADDRESS_INFO"; //无法获取到地址信息
	public static final String CODE_INTERFACE_EXCEPTION="CODE_INTERFACE_EXCEPTION"; //接口调用异常
	
	public static final String CODE_HUODAOHUKUAN_SKU_UNSUPPORT="SKU_HUODAOFUKUAN_UNSUPPORT"; //商品货到付款不支持
	public static final String CODE_HUODAOHUKUAN_ADDRESS_UNSUPPORT="ADDRESS_HUODAOFUKUAN_UNSUPPORT"; //地址货到付款不支持
	public static final String BALANCE_UNSUPPORT="BALANCE_UNSUPPORT"; //不支持余额
	public static final String ORDER_TYPE_UNSUPPORT="ORDER_TYPE_UNSUPPORT"; //不支持订单类型
	public static final String MIXED_SKU="MIXED_SKU";
	public static final String SKUTYPE_NOT_SUPPORT_INVOICE_TYPE="SKUTYPE_NOT_SUPPORT_INVOICE_TYPE";
}
