package com.jd.sns.biz.common.enumtype;

/**
 * 订单来源
 * 1-API;2-大客户平台;3-后台;4-vsp活动;24-vsp所有
 */
public enum SourceType {

	ORDER_VOP(1, "企销开放平台"),
	ORDER_VSP(2, "大客户服务平台"),
	ORDER_ADMIN(3,"后台管理系统"),
	ORDER_VSP_ACTIVITY(4, "VSP活动"),
	ORDER_VSP_ALL(24, "VSP所有"),
	ORDER_VOP_AFS(5, "售后换新订单");
	
	
	private final int type;
	private final String typeName;

	private SourceType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static SourceType getType(int type) {
		for (SourceType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}