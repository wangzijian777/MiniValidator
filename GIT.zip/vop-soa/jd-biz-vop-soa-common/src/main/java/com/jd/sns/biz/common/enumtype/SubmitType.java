package com.jd.sns.biz.common.enumtype;

/**
 * 是否预占库存限定
 *  0为预占库存下单、1为非预占库存下单
 * @author bjhuming
 */
public enum SubmitType {

	PRE_OCCUPY(0, "预占库存下单"),
	NOT_PRE_OCCUPY(1, "非预占库存下单");

	private final int type;
	private final String typeName;

	private SubmitType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static SubmitType getType(int type) {
		for (SubmitType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
