package com.jd.sns.biz.common.enumtype;

/**
 * 0协议价 1京东价 2阶梯价 3单品优惠
 * 
 * @author bjhuming
 */
public enum PriceType {

	XIEYI(0, "协议价"),
	JINGDONG(1, "京东价"),
	JIETI(2, "阶梯价"),
	DANPINYOUHUI(3, "单品优惠");

	private final int type;
	private final String typeName;

	private PriceType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static PriceType getType(int type) {
		for (PriceType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
