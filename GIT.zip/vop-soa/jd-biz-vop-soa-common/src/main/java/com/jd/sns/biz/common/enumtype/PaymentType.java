package com.jd.sns.biz.common.enumtype;

public enum PaymentType {

	HUODAOFUKUAN(1, "货到付款"),
	YOUJUFUKUAN(2, "邮局付款"),
	ZAIXIANZHIFU(4, "在线支付"),
	GONGSIZHUANZHANG(5, "公司转账"),
	YINHANGZHUANZHANG(6, "银行转账"),
	WANGYINQIANBAO(7, "网银钱包"),
	YUEJIE(12, "月结"),
	JINRONGZHIFU(101, "金融支付");

	private final int type;
	private final String typeName;

	private PaymentType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static PaymentType getType(int type) {
		for (PaymentType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
