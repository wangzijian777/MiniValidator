package com.jd.sns.biz.common.enumtype.invoice;

/**
 * 发票类型 
 * 	1普通发票 2增值税发票
 * @author bjhuming
 */
public enum SelectInvoiceType {

	NORMAL(1, "普通发票"),
	VAT(2, "增值税发票");

	private final int type;
	private final String typeName;

	private SelectInvoiceType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static SelectInvoiceType getType(int type) {
		for (SelectInvoiceType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
