package com.jd.sns.biz.common.enumtype;

/**
 * 是否开发票
 * 0-不开发票；1-开发票
 * @author bjhuming
 */
public enum InvoiceState {

	NO_INVOICE(0, "不开发票"),
	YES_INVOICE(1, "开发票");

	private final int type;
	private final String typeName;

	private InvoiceState(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static InvoiceState getType(int type) {
		for (InvoiceState t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
