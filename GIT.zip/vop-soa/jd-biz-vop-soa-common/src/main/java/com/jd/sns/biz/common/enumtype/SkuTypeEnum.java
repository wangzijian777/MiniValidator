package com.jd.sns.biz.common.enumtype;

/**
 * SKU类型
 * 0-普通;1-附件;2-赠品
 */
public enum SkuTypeEnum {

	NORMAL_SKU(0, "普通sku"),
	ANNEX_SKU(1, "附件sku"),
	GIFT_SKU(2, "赠品sku");
	
	
	private final int type;
	private final String typeName;

	private SkuTypeEnum(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static SkuTypeEnum getType(int type) {
		for (SkuTypeEnum t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}