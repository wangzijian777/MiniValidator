package com.jd.sns.biz.common.enumtype;

import java.util.HashMap;
import java.util.Map;

/**
 * 金采接口调用返回码
 * @author cdwangyong3
 *
 */
public enum JinCaiReturnCode {
	REQUEST_SUCCESS("0000","请求成功"),
	USER_FORBIDEN("0200","用户已禁用"),
	USER_INSUFFICIENT("0201","用户额度不足"),
	USER_NOT_FOUND("0202","没找到此用户"),
	BALANCE_NOT_ACTIVE("0203","授信未生效"),
	BALANCE_EXPIRED("0204","授信已过期"),
	BALANCE_NOT_AVAILABLE("0205","授信不可用"),
	USER_CANCEL("0206","用户已注销"),
	REPEAT_TRANSACTION("0004","重复交易"),
	PARAMETERS_ILLEGAL("0006","参数非法")//SEE：还有其他错误码，详见返回码
	;
	private JinCaiReturnCode(String responseCode,String descrption){
		this.responseCode = responseCode;
		this.descrption = descrption;
	}	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getDescrption() {
		return descrption;
	}
	public void setDescrption(String descrption) {
		this.descrption = descrption;
	}

	private String responseCode;
	private String descrption;
	
	public static final Map<String,String> codeMap = new HashMap<String,String>();
	static{
		codeMap.put("0000", "请求成功");
		codeMap.put("0200", "用户已禁用");
		codeMap.put("0201", "用户额度不足");
		codeMap.put("0202", "没找到此用户");
		codeMap.put("0203", "授信未生效");
		codeMap.put("0204", "授信已过期");
		codeMap.put("0205", "授信不可用");
		codeMap.put("0206", "用户已注销");
	}
	

}
