package com.jd.sns.biz.api.constant;

public class CacheConstant {

	
	
	/** 缓存时间 30天*/
	public static final int CACHE_ONE_MONTH = 60*60*24*30; 
	
	public static final String ORDER_CHECK_REPEAT="order_check_repeat_";

	/**
	 * 忽略订单数量校验
	 */
	public static final String IGNORE_ORDER_NUM_CHECK_KEY = "ignore_order_num_check_key";
	
	/**
	 * 需要赠品的client对应key
	 */
	public static final String WITH_GIFT_CLIENT_KEY = "with_gift_client_key";
	
	/**
	 * 获取订单
	 * @return
	 */
	public static String getOrderCheckRepeatCacheKey(String param){
		return ORDER_CHECK_REPEAT+param;
	}
	
}
