package com.jd.sns.biz.common.enumtype;

/**
 * 订单物流状态
 * @author zhangshibin
 *0订单默认状态，1妥投，2拒收
 */
public enum State {
	
	ORDER_SHIPMENT_DEFAULT(0, "默认"),
	ORDER_SHIPMENT_DLOK(1, "妥投"),
	ORDER_SHIPMENT_REFUSE(2,"拒收");
	
	private final int type;
	private final String typeName;

	private State(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static State getType(int type) {
		for (State t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
