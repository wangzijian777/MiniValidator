package com.jd.sns.biz.common.enumtype;

/**
 * 是否激活生产
 *  0为暂停、1为确认发货
 * @author bjhuming
 */
public enum SubmitState {

	DELAY(0, "延迟发货"),
	ACTIVE(1, "激活生产");

	private final int type;
	private final String typeName;

	private SubmitState(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static SubmitState getType(int type) {
		for (SubmitState t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
