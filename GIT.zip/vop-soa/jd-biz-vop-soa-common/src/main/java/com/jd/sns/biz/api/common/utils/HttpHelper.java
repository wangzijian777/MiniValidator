/* 
 * @FileName HttpHelper.java  
 * @Package com.jd.sns.biz.api.common.utils  
 * @Description TODO 
 * @date 2014-6-18 上午09:13:43  
 * @version V1.0   
 *  
 * Copyright (c) 2014 京东(www.jd.com)-版权所有
 */
package com.jd.sns.biz.api.common.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;

import org.apache.log4j.Logger;

/**
 * http相关操作工具类
 *
 * @ClassName HttpHelper
 * @author yanhuajian@jd.com
 * @date 2014-6-18 上午09:13:43
 * @version V1.0
 *
 */
public class HttpHelper {
	
	private static final Logger logger = Logger.getLogger(HttpHelper.class);
	
	public static final String APPLICATION_JSON = "application/json";
	public static final String CONTENT_TYPE_TEXT_JSON = "text/json";
	
	/**
	 * http post方式提交数据，并返回响应数据
	 *
	 * @Title doHttpPost
	 * @param urlPath
	 * @param data
	 * @param contentType
	 * @param charset
	 * @return
	 * @author yanhuajian@jd.com 2014-6-18 上午09:59:10
	 */
	public static String doHttpPost(String urlPath, String data, String contentType, String charset) {
		try {
			// 创建http连接
			URL url = new URL(urlPath);
			URLConnection conn = url.openConnection();
			// 设置连接相关参数，请求头
			conn.setDoOutput(true);
			conn.setDoInput(true);    		    
			conn.setUseCaches(false); 
			conn.setRequestProperty("Content-Type", contentType);
			// 设置连接超时
			conn.setConnectTimeout(20000);
			conn.setReadTimeout(20000);

			// POST请求
			OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
			out.write(new String(data.getBytes(charset)));
			out.flush();
			out.close();
			
			// 读取响应
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), charset));
			StringBuilder builder = new StringBuilder();
			String line = null;
			while ((line = br.readLine()) != null) {
				builder.append(line);
			}
			return builder.toString();
		} catch (IOException e) {
			logger.error("连接url" + urlPath + "失败，" + e.getMessage(), e);
		}
		return null;
	}
	
	/**
	 * http post方式提交数据，并返回响应数据，默认contentType为json格式，charset为utf-8
	 *
	 * @Title doHttpPost
	 * @param urlPath
	 * @param data
	 * @return
	 * @author yanhuajian@jd.com 2014-6-18 上午09:59:52
	 */
	public static String doHttpPost(String urlPath, String data) {
		return doHttpPost(urlPath, data, APPLICATION_JSON, "utf-8");
	}
	
	public static void main(String[] args) {
		String url = "http://auto.afs.360buy.com/services/paipaiServiceApply/createAfsApply";
		String str = "{\"afsApplyDetailDtos\":[{\"afsDetailType\":10,\"expandTag\":null,\"payPrice\":0,\"wareBrand\":\"\",\"wareDescribe\":\"\",\"wareId\":352651,\"wareName\":\"奥克斯（AUX）KFR-26GW/BPSSD-3 大1匹挂式家用冷暖变频空调（白色）江波\",\"wareNum\":1}],\"changeSku\":0,\"createName\":\"创建者\",\"customerDto\":{\"customerContactName\":\"曹丽颖\",\"customerEmail\":\"\",\"customerGrade\":0,\"customerMobilePhone\":\"15210417230\",\"customerName\":\"\",\"customerPin\":\"\",\"customerPostcode\":\"\",\"customerTel\":\"01067898768\"},\"customerExpect\":20,\"invoiceCode\":\"\",\"invoiceTime\":null,\"isHasInvoice\":false,\"isHasPackage\":false,\"isNeedDetectionReport\":false,\"orderId\":40320177679,\"orderType\":0,\"packageDesc\":10,\"pickwareDto\":{\"pickwareAddress\":\"江波测试\",\"pickwareCity\":72,\"pickwareCounty\":2839,\"pickwareProvince\":1,\"pickwareType\":40,\"pickwareVillage\":0,\"reserveDateBegin\":null,\"reserveDateEnd\":null,\"reserveDateStr\":\"\"},\"platformSrc\":209,\"questionDesc\":\"setQuestionDesc\",\"questionPic\":\"\",\"questionTypeCid1\":10,\"questionTypeCid2\":0,\"refundDto\":{\"bankAccountHolder\":\"testUser\",\"bankCity\":\"\",\"bankCode\":\"123456\",\"bankName\":\"\",\"bankProvince\":\"\",\"branchBankAddress\":\"testAddress\",\"refundType\":30},\"returnwareDto\":{\"returnwareAddress\":\"江波测试\",\"returnwareCity\":72,\"returnwareCounty\":2839,\"returnwareProvince\":1,\"returnwareType\":10,\"returnwareVillage\":0}}";
		try {
			String result = doHttpPost(url, str, APPLICATION_JSON, "utf-8");
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
