package com.jd.sns.biz.common.enumtype;
/**
 * 任务执行状态
 * @author Administrator
 *
 */
public enum TaskStateEnum {
	NOT_EXE(1, "未处理"),	
	EXE(2, "已处理"); // 推送订单给发票系统
	private int type;
	private String desc;
	
	TaskStateEnum(int type, String desc){
		this.type = type;
		this.desc = desc;
	}

	public int getType() {
		return type;
	}

	public String getDesc() {
		return desc;
	}
}
