/**
 * 专门存放虚拟订单相关工具类
 * @ClassName: package-info
 * @Description:
 * @author heguang
 * @date 2014年8月28日 下午3:07:55
 */
package com.jd.sns.util.virtual;