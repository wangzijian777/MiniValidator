package com.jd.sns.biz.common.enumtype;

public enum TaskTypeEnum {
	CANCEL_TRANSFER_NOPAY(1, "公司转账7天未支付订单取消任务"),
	
	ORDER_PUSH_TASK(2, "订单推送任务"), // 推送订单给发票系统
	ORDER_SPLIT_MONITOR_TASK(4, "订单拆单监控任务"), // 拆单监控任务，验证下单成功支付后一天内未拆单的并发送告警
	DELIVERY_CHECK_TASK(5, "投递检查任务"), // 拆单监控任务，验证下单成功支付后一天内未拆单的并发送告警
	ORDER_CONFIRM_TASK(9,"订单确认任务"),
	ORDER_PRODUCT_NOTIFY_TASK(30, "订单生产通知任务");
	private int type;
	private String desc;
	
	TaskTypeEnum(int type, String desc){
		this.type = type;
		this.desc = desc;
	}

	public int getType() {
		return type;
	}

	public String getDesc() {
		return desc;
	}
}
