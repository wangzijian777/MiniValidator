package com.jd.sns.biz.common.enumtype;

/**
 * 1只工作日送货(双休日、假日不用送) 2只双休日、假日送货(工作日不用送) 3工作日、双休日与假日均可送货
 * @author bjhuming
 */
public enum ShipmentTimeType {

	WORKDAY(1, "只工作日送货(双休日、假日不用送)"),
	WEEKEND(2, "只双休日、假日送货(工作日不用送)"),
	EVERYDAY(3, "工作日、双休日与假日均可送货");

	private final int type;
	private final String typeName;

	private ShipmentTimeType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static ShipmentTimeType getType(int type) {
		for (ShipmentTimeType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
