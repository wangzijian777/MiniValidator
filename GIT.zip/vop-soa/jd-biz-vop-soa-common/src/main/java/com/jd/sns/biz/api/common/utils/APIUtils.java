package com.jd.sns.biz.api.common.utils;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.sns.biz.api.common.log.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


public class APIUtils {
	private static final Logger log = LoggerFactory.getLogger(APIUtils.class);
	
	public static String parseObject2Json(Object value){
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.API_UTILS_PARSE2JSON, true, true);
		try {
			return JsonUtils.writeValue(value);
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"json转化失败！");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
	
	public static <T>T parseJson2Object(String value, Class<T> valueType){
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.API_UTILS_PARSE2OBJECT, true, true);
		try {
			return JsonUtils.readValue(value, valueType);
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"json解析失败！");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
	
    public static BigDecimal calculateTaxPrice(BigDecimal price, BigDecimal tax){
        //计算税额（价格/(1+税率)）*税率
        BigDecimal taxValue = tax.divide(new BigDecimal(100));
        BigDecimal result = price.divide(new BigDecimal(1).add(taxValue), 2, BigDecimal.ROUND_HALF_UP).multiply(taxValue);
        return result.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

}
