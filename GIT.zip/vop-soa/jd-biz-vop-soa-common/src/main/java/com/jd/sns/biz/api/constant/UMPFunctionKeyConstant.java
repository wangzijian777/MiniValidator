package com.jd.sns.biz.api.constant;

/**
 * UMP方法监控
 * @author cdwangyong3
 *
 */
public final class UMPFunctionKeyConstant {
	/**********内部方法监控key*************/

	/** vxp订单-提交订单*/
	public static final String ORDER_COMMON_SUBMITORDER="vop-soa.BizOrderCommonService.submitOrder";
	/** vxp订单-确认预占库存订单*/
	public static final String ORDER_COMMON_CONFIRMORDER="vop-soa.BizOrderCommonService.confirmOrder";
	/** vxp订单-取消已经确认订单*/
	public static final String ORDER_COMMON_CANCELCONFIRMEDORDER="vop-soa.BizOrderCommonService.cancelConfirmedOrder";
	/** vxp订单-取消未确认订单*/
	public static final String ORDER_COMMON_CANCELUNCONFIRMEDORDER="vop-soa.BizOrderCommonService.cancelUnconfirmedOrder";
	/** vxp订单-查询订单详情*/
	public static final String ORDER_COMMON_GETBIZORDERDETAIL="vop-soa.BizOrderCommonService.getBizOrderDetail";
	/** vxp订单-通过第三方订单号查询订单*/
	public static final String ORDER_COMMON_SELECTJDORDERLISTBYTHIRDORDER="vop-soa.BizOrderCommonService.selectJdOrderListByThirdOrder";
	
	/** 通用批量确认接口 **/
	public static final String COMMON_BATCH_CONFIRM ="vop-soa.BizOrderCommonService.doConfirmOrder";
	
	/** vxp订单-下单成功后支付*/
	public static final String ORDER_COMMON_PAY_AFTER_ORDERING="vop-soa.BizOrderCommonService.payAfterOrdering";
	
	/** vxp对账及列表查询-新建的订单列表*/
	public static final String ORDER_RECON_CHECKNEWORDER="vop-soa.BizOrderReconciliationService.checkNewOrder";
	/** vxp对账及列表查询-妥投的订单列表*/
	public static final String ORDER_RECON_CHECKDLOKORDER="vop-soa.BizOrderReconciliationService.checkDlokOrder";
	/** vxp对账及列表查询-拒收的订单列表*/
	public static final String ORDER_RECON_CHECKREFUSEORDER="vop-soa.BizOrderReconciliationService.checkRefuseOrder";
	/** vxp对账及列表查询-挂起的订单列表*/
	public static final String ORDER_RECON_CHECKHANGUPORDER="vop-soa.BizOrderReconciliationService.checkHangUpOrder";
	/** vxp对账及列表查询-激活的订单列表*/
	public static final String ORDER_RECON_SELECTACTIVEBIZORDERBYMYORDER="vop-soa.BizOrderReconciliationService.selectActiveBizOrderByMyOrder";
	/** vxp对账及列表查询-未激活的订单列表*/
	public static final String ORDER_RECON_SELECTUNACTIVEBIZORDERBYMYORDER="vop-soa.BizOrderReconciliationService.selectUnActiveBizOrderByMyOrder";
	/** vxp对账及列表查询-根据订单状态查询*/
	public static final String ORDER_RECON_SELECTCHILDACCBIZORDERBYSTATE="vop-soa.BizOrderReconciliationService.selectChildAccBizOrderByState";
	/** vxp对账及列表查询-订单状态查询子账户的总额*/
	public static final String ORDER_RECON_COUNTCHILDACCBIZORDERAMOUNTBYSTATE="vop-soa.BizOrderReconciliationService.countChildAccBizOrderAmountByState";
	/** vxp对账及列表查询-根据订单状态查询*/
	public static final String ORDER_RECON_SELECTORDERLISTBYQUERY="vop-soa.BizOrderReconciliationService.selectOrderListByQuery";
	/** vxp对账及列表查询-通过jdOrderIds批量查询*/
	public static final String ORDER_RECON_GETBIZORDERDETAILBYJDORDERIDS="vop-soa.BizOrderReconciliationService.getBizOrderDetailByJdOrderIds";	
	
	
	
	public static final String CHECK_REPEAT_SUBMIT_ORDER="vop-soa.BizOrderUtils.checkRepeatSubmitOrder";
	public static final String CHECK_REPEAT_THIRD_SUBMIT_ORDER="vop-soa.BizOrderUtils.checkRepeatThirdSubmitOrder";
	public static final String CHECK_VISIT_LOGIN_PAGE_PARAMS="vop-soa.Oauth2ServiceImpl.checkVisitLoginPageParams";
	public static final String CHECK_GET_TOKEN_PARAM="vop-soa.Oauth2ServiceImpl.checkGetTokenParam";
	public static final String CREATE_ACCESS_TOKEN="vop-soa.Oauth2ServiceImpl.createAccessToken";
	public static final String CHECK_TOKEN="vop-soa.Oauth2ServiceImpl.checkToken";
	public static final String GET_ACCESS_TOKEN_BY_REFRESH_TOKEN="vop-soa.Oauth2ServiceImpl.getAccessTokenByRefreshToken";
	
	public static final String PRE_ORDER="vop-soa.AbstractSubmitOrderService.preOrder";
	public static final String DO_ORDER="vop-soa.AbstractSubmitOrderService.doOrder";
	public static final String POST_ORDER="vop-soa.AbstractSubmitOrderService.postOrder";
	
	public static final String REFRESH_TOKEN="vop-soa.Oauth2ServiceImpl.refreshToken";
	public static final String CREATE_USER="vop-soa.UserServiceImpl.createUser";
	public static final String DEL_USER="vop-soa.UserServiceImpl.delUser";
	public static final String UPDATE_USER="vop-soa.UserServiceImpl.updateUser";
	public static final String GET_USER_BY_CLIENT_ID_AND_CACHE="vop-soa.UserServiceImpl.getUserByClientIdAndCache";
	/**
	 * 库存接口
	 */
	public static final String GET_STOCK_BY_IDS="vop-soa.StockStateServiceImpl.getStockByIds";
	/**
	 * 新库存接口
	 */
	public static final String GET_NEW_STOCK_BY_IDS="vop-soa.StockStateServiceImpl.getNewStockByIds";
	public static final String SELECT_PAGE_NUM_BY_CLIENT_ID="vop-soa.ProductServiceImpl.selectPageNumByClientId";
	public static final String SELECT_SKUIDS_BY_CLIENT_ID_AND_PAGE_NUM="vop-soa.ProductServiceImpl.selectSkuIdsByClientIdAndPageNum";
	public static final String GET_DETAIL="vop-soa.ProductServiceImpl.getDetail";
	public static final String SKU_STATE="vop-soa.ProductServiceImpl.skuState";
	public static final String SKU_IMAGE="vop-soa.ProductServiceImpl.skuImage";
	
	/**
	 * vop区域限制查询接口
	 */
	public static final String AREA_LIMIT="vop-soa.BizCommonQueryService.checkSkusAreasLimit";
	
	public static final String API_UTILS_PARSE2JSON = "vop-soa.APIUtils.parseObject2Json";
	
	public static final String API_UTILS_PARSE2OBJECT = "vop-soa.APIUtils.parseJson2Object";
	
	/**
	 * vop区域限制查询接口
	 */
	public static final String AREA_PROMOTION="vop-soa.BizCommonQueryService.querySkuPromotion";
	
	public static final String YANBAO_INFO = "vop-soa.BizCommonQueryService.getYanBaoInfo";
	
	
	public static final String GET_PRODUCT_COMMENT_SUMMARYS="vop-soa.ProductServiceImpl.getProductCommentSummarys";
	/**
	 * 预占库存下单
	 */
	public static final String SUBMIT_ORDER="vop-soa.OccupyStockBizOrderServiceImpl.submitOrder";
	public static final String CONFIRM_ORDER="vop-soa.OccupyStockBizOrderServiceImpl.confirmOrder";
	public static final String CANCEL="vop-soa.OccupyStockBizOrderServiceImpl.cancel";
	/**
	 * 协议价格批量查询
	 */
	public static final String BATCH="vop-soa.JdPriceServiceImpl.batch";
	/**
	 * 京东价格批量查询
	 */
	public static final String JD_PRICE_BATCH_FROM_POOL="vop-soa.JdPriceServiceImpl.jdPriceBatchFromPool";
	/**
	 * 根据skuId获取协议价
	 */
	public static final String GET_PRICE_BY_SKU_ID="vop-soa.JdPriceServiceImpl.getPriceBySkuId";
	/**
	 * 根据skuId获取协议价
	 */
	public static final String GET_JDPRICE_BY_SKU_ID="vop-soa.JdPriceServiceImpl.getJdPriceBySkuId";
	/**
	 * 根据skuId获取协议价
	 */
	public static final String SELECT_BALANCE="vop-soa.JdPriceServiceImpl.selectBalance";
	/**
	 * 获取省份信息
	 */
	public static final String GET_PROVINCES="vop-soa.JdAreaServiceImpl.getProvinces";
	/**
	 * 获取城市
	 */
	public static final String GET_CITYS="vop-soa.JdAreaServiceImpl.getCitys";
	/**
	 * 获取县
	 */
	public static final String GET_COUNTYS="vop-soa.JdAreaServiceImpl.getCountys";
	/**
	 * 获取县
	 */
	public static final String GET_COUNTYS_OUTLINE="vop-soa.outline.AreaServiceImpl.getCountys";
	
	/**
	 * 获取乡镇
	 */
	public static final String GET_TOWNS="vop-soa.JdAreaServiceImpl.getTowns";
	/**
	 * 获取乡镇
	 */
	public static final String GET_TOWNS_OUTLINE="vop-soa.outline.AreaServiceImpl.getTowns";
	/**
	 * 获取发票信息
	 */
	public static final String GET_INVOICE_INFO="vop-soa.InvoiceServiceImpl.getInvoiceInfo";
	/**
	 * 金采授信额度接口监控
	 */
	public static final String JINCAI_QUERY="vop-soa.outline.GeiousLimitServiceRpc.creditLimit";
	
	
	public static final String INSERT_JD_DEMAND_ORDER="vop-soa.DemandOrderServiceImpl.insertJdDemandOrder";
	public static final String CANCEL_JD_DEMAND_ORDER="vop-soa.DemandOrderServiceImpl.cancelJdDemandOrder";
	public static final String SELECT_DEMAND_ORDER_BY_ID="vop-soa.DemandOrderServiceImpl.selectDemandOrderById";
	public static final String CHECK_THIRD_ORDER_EXIST="vop-soa.DemandOrderServiceImpl.checkThirdOrderExist";
	public static final String CHECK_HANG_UP_ORDER="vop-soa.CheckOrderServiceImpl.checkHangUpOrder";
	public static final String CHECK_ORDER_BY_STATE="vop-soa.CheckOrderServiceImpl.checkOrderByState";
	public static final String GET_QB_PRICE="vop-soa.BizQBServiceImpl.getQBPrice";
	
	public static final String QB_ORDER="vop-soa.BizQBServiceImpl.qBOrder";
	public static final String QUERY_QB_ORDER_BY_ORDER_ID="vop-soa.BizQBServiceImpl.queryQBOrderByOrderid";
	public static final String QUERY_QB_ORDER_BY_THIRD_ID="vop-soa.BizQBServiceImpl.queryQBOrderByThirdid";
	
	/**
	 * 需求单形式的下订单接口
	 */
	public static final String BIZQBSERVICEIMPL_SUBMIT_ORDER="vop-soa.BizOrderServiceImpl.submitOrder";
	/**
	 * 需求单形式的取消订单
	 */
	public static final String BIZQBSERVICEIMPL_CANCEL_JD_ORDER="vop-soa.BizOrderServiceImpl.cancelJdOrder";
	/**
	 * 需求单形式的选择订单
	 */
	public static final String BIZQBSERVICEIMPL_SELECT_JD_ORDER="vop-soa.BizOrderServiceImpl.selectJdOrder";
	
	/**
	 * 需求单形式的订单跟踪
	 */
	public static final String BIZQBSERVICEIMPL_ORDER_TRACK="vop-soa.BizOrderServiceImpl.orderTrack";

	public static final String SELECT_JD_ORDER_LIST_BY_THIRD_ORDER="vop-soa.BizOrderServiceImpl.selectJdOrderListByThirdOrder";

	public static final String SELECT_BIZ_ORDER_BY_THIRD_ORDER="vop-soa.BizOrderServiceImpl.selectBizOrderByThirdOrder";
	public static final String BIZ_ORDER_FLOW_SERVICEIMPL_SUBMIT="vop-soa.BizOrderFlowServiceImpl.submit";
	public static final String BIZ_ORDER_FLOW_SERVICEIMPL_SELECT="vop-soa.BizOrderFlowServiceImpl.select";
	public static final String BIZ_ORDER_FLOW_SERVICEIMPL_CANCEL="vop-soa.BizOrderFlowServiceImpl.cancel";
	
	public static final String INSERT_BIZORDER_DIFFERENCE="vop-soa.BizOrderDifferenceServiceImpl.insertBizOrderDifference";
	
	public static final String GET_MESSAGE="vop-soa.BizMessageServiceImpl.getMessage";	
	public static final String DEL_MESSAGE="vop-soa.BizMessageServiceImpl.delMessage";
	
	public static final String BIZ_INVOICE_SERVICEIMPL_SUBMIT="vop-soa.BizInvoiceServiceImpl.submit";
	public static final String BIZ_INVOICE_SERVICEIMPL_SELECT="vop-soa.BizInvoiceServiceImpl.select";
	
	public static final String BUY="vop-soa.BizGiftcarOrderServiceImpl.buy";
	public static final String SELECT_GIFT_CARDS_BY_JD_ORDER_ID="vop-soa.BizGiftcarOrderServiceImpl.selectGiftcardsByJdOrderId";
	public static final String SELECT_JD_ORDER_BY_THIRD_ORDER="vop-soa.BizGiftcarOrderServiceImpl.selectJdOrderByThirdOrder";
	
	public static final String CHECK_SKU_LIST_EXIST="vop-soa.BaseOrderServiceImpl.checkSkuListExist";
	
	
	
	
	
	
	/**********外部接口监控key*************/
	public static final String JDPRODUCTSERVICE_QUERYPRODUCTBASE="vop-soa.outline.jdProductService.queryProductBase";
	public static final String JDPRODUCTSERVICE_QUERYBIGFIELD="vop-soa.outline.jdProductService.queryBigField";
	
	/** 商品查询接口，查询商品扩展属性 */
	public static final String JDPRODUCTSERVICE_QUERYPRODUCTEXTEND="vop-soa.outline.jdProductService.queryProductExtend";
	/** 商品区域限制 **/
	public static final String JDPRODUCTSERVICE_QUERYLIMITAREA="vop-soa.outline.jdProductService.queryLimitArea";
	
	public static final String GET_SKU_AREA_DCID_SID = "vop-soa.outline.getSkuAreaDcidSid";
    public static final String GET_LA_SKU_IS_COD = "vop-soa.outline.laAppConfigService.getLAJdCodConfig";//大家电是否支持货到付款
    public static final String GET_DCID_SID_BY_AREA = "vop-soa.outline.stockService.getDcidSidByArea";  

	/** 余额，查询用户余额	 */
	public static final String MONTHLYQUOTASERVICE_GETBALANCE="vop-soa.outline.monthlyQuotaService.getBalance";
	/** 月结，锁定额度占用	 */
	public static final String MONTHLYQUOTASERVICE_LOCKMONTHLYQUOTA="vop-soa.outline.monthlyQuotaService.lockMonthlyQuota";
	/** 月结，解锁额度占用	 */
	public static final String MONTHLYQUOTASERVICE_UNLOCKMONTHLYQUOTA="vop-soa.outline.monthlyQuotaService.unlockMonthlyQuota";
	/** 月结，确认额度占用	 */
	public static final String MONTHLYQUOTASERVICE_COMPLETEORDER="vop-soa.outline.monthlyQuotaService.completeOrder";

	
	public static final String SUBMITORDEREXPORT_SUBMITORDER="vop-soa.outline.submitOrderExport.submitOrder";
	public static final String SUBMITORDEREXPORT_DEAL_WITH_GIFT="vop-soa.outline.submitOrderExport.dealWithGift";
	public static final String JDSTOCKSTATESERVICE_QUERYSTOCKSTATELISTBYAREA="vop-soa.outline.jdStockStateService.queryStockStateListByArea";
	public static final String ORDERINFOEXPORT_GETORDERID="vop-soa.outline.orderInfoExport.getOrderId";
	public static final String MONTHLYPAYMENTSERVICE_QUERYBIZPAYFIRSTCARDS="vop-soa.outline.monthlyPaymentService.queryBizPayFirstCards";
	public static final String AFTERSALESERVICE_GETAVAILABLENUMBERCOMP="vop-soa.outline.afterSaleService.getAvailableNumberComp";
	public static final String AFTERSALESERVICE_GETCUSTOMEREXPECTCOMP="vop-soa.outline.afterSaleService.getCustomerExpectComp";
	public static final String AFTERSALESERVICE_GETWARERETURNJDCOMP="vop-soa.outline.afterSaleService.getWareReturnJdComp";
	public static final String AFTERSALESERVICE_CREATEAFSAPPLY="vop-soa.outline.afterSaleService.createAfsApply";
	public static final String GET_DCID_SID = "vop-soa.outline.stockService.getDcIdSid";
	public static final String AFTERSALESERVICE_UPDATESENDSKU="vop-soa.outline.afterSaleService.updateSendSku";
	public static final String AFTERSALESERVICE_GETSERVICELISTPAGE="vop-soa.outline.afterSaleService.getServiceListPage";
	public static final String AFTERSALESERVICE_GETSERVICEDETAILINFO="vop-soa.outline.afterSaleService.getServiceDetailInfo";
	public static final String PROMOINFOSERVICE_FINDGIFTINFOBYSKUIDS="vop-soa.outline.promoInfoService.findGiftInfoBySkuIds";
	public static final String STRIKEPRICEREDISSERVICE_GETSTRIKEPRICES="vop-soa.outline.strikePriceRedisService.getStrikePrices";
	public static final String STRIKEPRICESERVICE_GETSTRIKEPRICE="vop-soa.outline.strikePriceService.getStrikePrice";
	
	/**orderServiceSoap监控 */
	public static final String ORDER_SERVICE_ACTIVEJDORDER="vop-soa.outline.orderServiceSoap.activeJdOrder";
	public static final String ORDER_SERVICE_CANCELJDORDER="vop-soa.outline.orderServiceSoap.cancelJdOrder";
	public static final String ORDER_SERVICE_GETCHILDORDERIDBYJDORDERID="vop-soa.outline.orderServiceSoap.getChildOrderIdByJdOrderId";
	public static final String ORDER_SERVICE_GETSPLITORDERIDSBYPOID = "vop-soa.outline.orderServiceSoap.getSplitOrderIdsByParentOrderId";

	/**
	 * 商品池服务监控
	 */
	public static final String GET_SKUS_BY_CLIENTID_BIZID="vop-soa.outline.skuPoolQueryService.getSkusByClientIdAndBizId";
	public static final String CHECK_SKUS_IN_POOL_BY_CLIENTID="vop-soa.outline.skuPoolQueryService.checkSkusInPoolByClientId";
	public static final String CHECK_SKU_IN_POOL_BY_CLIENTID="vop-soa.outline.skuPoolQueryService.checkSkuInPoolByClientId";
	public static final String CHECK_SKUID_EXIST="vop-soa.outline.skuPoolQueryService.checkSkuIdExist";
	public static final String GET_CLIENTIDS_BY_SKUID="vop-soa.outline.skuPoolQueryService.getClientIdsBySkuId";
	public static final String GET_SKU_POOLS_BY_CLIENTID="vop-soa.outline.skuPoolQueryService.getSkuPoolsByClientId";
	
	/**
	 * 账户余额接口
	 */
	public static final String BALANCESERVICE_GETBALANCE="vop-soa.outline.balanceService.getbalance";
	/**
	 * 货到付款地址判断相关接口
	 */
	public static final String PROMISEOPCONFIG_GETZXJJDCODCONFIG="vop-soa.outline.promiseOpConfigService.getZxjJdCodConfig";
	
	/** 大家电商品区域限制 **/
    public static final String BIG_ITEM_AREA_LIMIT = "vop-soa.outline.largeAppliancesService.getLACalendarList";    
	
	/*********************** 系统警告***********************/
	
	/** 解锁月结额度失败*/
	public static final String ALARM_UNLOCKMONTHLYQUOTA_FAIL = "vop-soa.BizOrderCommonService.alarm_unlockmonthlyquota_fail";
	
	/** 确认子订单（但子订单已经拆单）失败*/
	public static final String ALARM_CONFIRM_CHILD_BUT_SPLIT = "vop-soa.BizOrderCommonService.alarm.confirmChildButSplit";
	
	/** 取消子订单（但子订单已经拆单）失败*/
	public static final String ALARM_CANCEL_CHILD_BUT_SPLIT = "vop-soa.BizOrderCommonService.alarm.cancelChildButSplit";
	
	
	public static final String STOCK_STATE_QUERY_BY_AREA ="vop-soa.outline.StockStateServiceAdaptor.queryStockStateListByArea";
	
	/** 调用支付中心监控 */
	public static final String CALL_PAYSERVICE_PAY = "vop-soa.out.BizPayService.pay";
	public static final String BIZ_ORDER_QUERY_SPLIT_FUNCTION = "vop-soa.outline.getSplitOrders";
}
