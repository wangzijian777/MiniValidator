package com.jd.sns.biz.api.common.utils;

public class ApiConstants {
	public static class returnValue{
		//返回成功
		public static String OK = "OK";
		//client_id 不存在
		public static String APPID_ERROR = "client_id不正确";
		//response_type 值不正确
		public static String RESPONSE_TYPE_ERROR = "response_type不正确";
		//redirect_uri 不正确
		public static String REDIRECT_URI_ERROR = "redirect_uri不正确";
		//client_secret不正确
		public static String CLIENT_SECRET_ERROR = "client_secret不正确";
		//grand_type不正确
		public static String GRAND_TYPE_ERROR = "grand_type不正确";
	}
	
}
