package com.jd.sns.biz.common.enumtype;

/**
 * 订单状态枚举
 * @author cdgaoqing
 *
 */
public enum OrderStateEnum {
	CANCEL_STATE(0,"无效订单"),
	VALID_STATE(1,"有效订单"),
	TWICE_SPLIT(2,"二次拆单（无效订单）");
	
	private int type;
	private String desc;
	
	OrderStateEnum(int type, String desc){
		this.type = type;
		this.desc = desc;
	}
	
	public static String getValueName(int type) {
		for (OrderStateEnum t : OrderStateEnum.values()) {
			if (type == t.getType()) {
				return t.getDesc();
			}
		}
		return "";
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
}
