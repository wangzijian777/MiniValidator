package com.jd.sns.biz.common.enumtype;

public enum VirtualOrderState {

	ORDERING(0, "正在下单"),
	PAYING(1, "正在支付"),
	PAY_FAILED(2, "支付失败"),
	RECHARGING(3, "支付完成,正在充值"),
	RECHARGE_SUCCESS(4, "充值成功"),
	RECHARGE_FAILED(5, "充值失败,正在退款"),
	REFUND_SUCCESS(6, "退款成功"),
	REFUND_FAILED(7, "退款失败");

	private final int type;
	private final String typeName;

	private VirtualOrderState(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static VirtualOrderState getType(int type) {
		for (VirtualOrderState t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
