package com.jd.sns.biz.common.enumtype.invoice;

/**
 * 发票内容类型：
 * 	1:明细；
 * 	3:电脑配件；
 * 	19:耗材；
 * 	22:办公用品
 * @author bjhuming
 */
public enum InvoiceContentType {

	DETAIL(1, "明细"),
	COMPUTER(3, "电脑配件"),
	WASTE(19, "耗材"),
	OFFICE(22, "办公用品");

	private final int type;
	private final String typeName;

	private InvoiceContentType(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static InvoiceContentType getType(int type) {
		for (InvoiceContentType t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}