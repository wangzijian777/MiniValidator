package com.jd.sns.biz.common.enumtype;

/**
 * 是否使用余额支付
 * 0-不使用余额；1-使用余额支付
 * @author bjhuming
 */
public enum IsUseBalance {

	NOT_USED_BALANCE(0, "不使用余额"),
	USED_BALANCE(1, "使用余额支付");

	private final int type;
	private final String typeName;

	private IsUseBalance(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static IsUseBalance getType(int type) {
		for (IsUseBalance t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
