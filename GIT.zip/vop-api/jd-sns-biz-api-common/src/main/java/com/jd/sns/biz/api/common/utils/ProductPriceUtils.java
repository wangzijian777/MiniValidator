package com.jd.sns.biz.api.common.utils;

import java.math.BigDecimal;

import com.jd.common.util.Money;

/**
 * 商品价格工具类
 * @author zhangshibin
 *
 */
public class ProductPriceUtils {

	/**
	 * 计算加上费率后的价格=原价*(10000+费率)/10000
	 * @param price
	 * @param feeRate
	 * @return
	 */
	public static BigDecimal calcCreditFeePrice(BigDecimal price,int feeRate){
		/*		if(feeRate==0){
			return price;
		}
		*/
		int serviceRate = feeRate + 10000; 
        BigDecimal PriceFeePerent = new BigDecimal(serviceRate).divide(new BigDecimal(10000));
        return PriceFeePerent.multiply(price).setScale(2, BigDecimal.ROUND_HALF_UP);
	}
	
	
	public static void main(String[] args) {
		Money money=new Money(99.815);
		System.out.println(calcCreditFeePrice(new BigDecimal(money.toString()),0));
	}
	
}
