package com.jd.sns.biz.api.common.exception;

/**
 * 外部接口调用失败产生的异常
 * 
 * @author chenxiaoming 2014-7-9
 */
public class ExternalException extends Exception {
    
    private static final long serialVersionUID = 4866281922749008481L;
    
    public ExternalException() {
        super();
    }
    
    public ExternalException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public ExternalException(String message) {
        super(message);
    }
    
    public ExternalException(Throwable cause) {
        super(cause);
    }
    
}
