package com.jd.sns.biz.api.common.utils;

import java.math.BigDecimal;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


public class APIUtils {
	private static final Logger log = LoggerFactory.getLogger(APIUtils.class);
	
	public static String parseObject2Json(Object value){
		try {
			return JsonUtils.writeValue(value);
		} catch (Exception e) {
			log.error("", e);
		}
		return null;
	}
	
	public static <T>T parseJson2Object(String value, Class<T> valueType){
		try {
			return JsonUtils.readValue(value, valueType);
		} catch (Exception e) {
			log.error("", e);
		}
		return null;
	}
	
	public static String getClientId(){
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		return request.getAttribute("client_id").toString();
	}
	
	public static String getPin(){
		HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
		return request.getAttribute("pin").toString();
	}

    public static BigDecimal calculateTaxPrice(BigDecimal price, BigDecimal tax){
        //计算税额（价格/(1+税率)）*税率
        BigDecimal taxValue = tax.divide(new BigDecimal(100));
        BigDecimal result = price.divide(new BigDecimal(1).add(taxValue), 2, BigDecimal.ROUND_HALF_UP).multiply(taxValue);
        return result.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

}
