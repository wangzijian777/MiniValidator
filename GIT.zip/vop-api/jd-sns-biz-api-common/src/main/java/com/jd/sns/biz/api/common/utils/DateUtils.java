package com.jd.sns.biz.api.common.utils;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
	private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
	public static final String DEFAULT_DATE_FORMATE = "yyyy-MM-dd";

	/**
	 * 取得某日期时间的特定表示格式的字符串
	 *
	 * @param format 时间格式
	 * @param date   某日期（Date）
	 * @return 某日期的字符串
	 */
	public static synchronized String getDate2Str(String format, Date date) {
		simpleDateFormat.applyPattern(format);
		return simpleDateFormat.format(date);
	}
	
	/**
	 * 将特定格式的时间字符串转化为Date类型
	 *
	 * @param format 时间格式
	 * @param str    某日期的字符串
	 * @return 某日期（Date）
	 */
	public static synchronized Date getStrToDate(String format, String str) {
		simpleDateFormat.applyPattern(format);
		ParsePosition parseposition = new ParsePosition(0);
		return simpleDateFormat.parse(str, parseposition);
	}
	
	public static String format(Date date) {
		return getDate2Str(DEFAULT_DATE_FORMATE, date);
	}
	
	public static String format(Date date, String format) {
		return getDate2Str(format, date);
	}
	
	public static Date parse(String str) {
		return getStrToDate(DEFAULT_DATE_FORMATE, str);
	}
	
}
