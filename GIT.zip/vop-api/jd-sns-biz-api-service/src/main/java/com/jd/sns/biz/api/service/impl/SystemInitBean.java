package com.jd.sns.biz.api.service.impl;

import org.springframework.beans.factory.InitializingBean;

import com.jd.ump.profiler.proxy.Profiler;

public class SystemInitBean implements InitializingBean {

	private String systemLiveKey;
	private String jvmKey;
	
	public void afterPropertiesSet() throws Exception {
	   Profiler.InitHeartBeats(systemLiveKey);
	   Profiler.registerJVMInfo(jvmKey);
	}

	public void setSystemLiveKey(String systemLiveKey) {
		this.systemLiveKey = systemLiveKey;
	}

	public void setJvmKey(String jvmKey) {
		this.jvmKey = jvmKey;
	}
}

