package com.jd.sns.biz.api.service;

import com.jd.sns.biz.api.domain.BizGiftcardOrder;

public interface BizGiftcarOrderService {
	/**
	 * 购买礼品卡
	 * @param giftcard
	 * @return
	 */
	String buy(BizGiftcardOrder giftcard);
	
	/**
	 * 根据订单号查询礼品卡详细信息
	 * @param jdOrderId
	 * @return
	 */
	String selectGiftcardsByJdOrderId(String jdOrderId);
	
	/**
	 * 根据第三方订单号获取订单信息
	 * @param thirdOrder
	 * @return
	 */
	String selectJdOrderByThirdOrder(String thirdOrder);
	/**
	 * 礼品卡短信补发接口
	 * @param jdOrderId
	 * @param mobile
	 * @param pin
	 * @param clientId 
	 * @return
	 */
	String sendSms(String jdOrderId, String mobile, String pin, String clientId);
}
