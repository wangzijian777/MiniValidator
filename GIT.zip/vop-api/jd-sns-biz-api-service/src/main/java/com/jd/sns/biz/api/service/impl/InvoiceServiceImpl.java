package com.jd.sns.biz.api.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.dao.BizOrderInvoiceDao;
import com.jd.sns.biz.api.domain.AbstractInvoiceInfo;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.BizOrderInvoice;
import com.jd.sns.biz.api.domain.IVatQualification;
import com.jd.sns.biz.api.enumtype.InvoiceType;
import com.jd.sns.biz.api.order.exception.BizOrderServiceException;
import com.jd.sns.biz.api.service.InvoiceService;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.ws.invoice.QualificationWebService;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service("invoiceService")
public class InvoiceServiceImpl implements InvoiceService {
//    private final static Log        log = LogFactory.getLog("submitOrderLog");
    @Resource
    private QualificationWebService qualificationWebService;

    @Resource
    private BizOrderInvoiceDao      bizOrderInvoiceDao;

    /**
     * 获取用户增票信息
     */
    @Override
    public String getInvoiceInfo(String pin) {
    	CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_INVOICE_INFO,false,true);
        MapResult result = new MapResult();
        result.setSuccess(false);
        try {
            // update yz 统一调用findInvoiceInfo方法，获取有效的增票资质
            IVatQualification qualification = findInvoiceInfo(pin);
            Map<String, Object> params = new HashMap<String, Object>();
            if (qualification != null) {
                String taxId = qualification.getTaxId();
                // 税号
                params.put("taxId", taxId);
                // 公司名称】
                String company = qualification.getCompany();
                params.put("company", company);
                // 电话
                String phone = qualification.getPhone();
                params.put("phone", phone);
                String bank = qualification.getBank();
                // 开户银行名称
                params.put("bank", bank);
                String account = qualification.getAccount();
                // 开户银行账户
                params.put("account", account);
                // 注册地址
                String address = qualification.getAddress();
                params.put("address", address);
                result.setSuccess(true);
            }
            if (!result.isSuccess()) {
                result.setResultMessage("增票资质不存在或审核未通过");
            }
            result.setResult(params);
        } catch (Exception e) {
            LogTypeEnum.DEFAULT.error(e,"查询发票信息异常");
            result.setSuccess(false);
            result.setResultMessage("服务异常，请重试");
            Profiler.functionError(callerInfo);
        }finally{
        	Profiler.registerInfoEnd(callerInfo);
        }
        return APIUtils.parseObject2Json(result);
    }

    @Override
	public IVatQualification findInvoiceInfo(String pin) {
		CallerInfo callerInfo = Profiler.registerInfo(UMPFunctionKeyConstant.GET_INVOICE_INFO, false, true);
		try {
			List<com.jd.sns.biz.ws.invoice.VatQualification> vatQualifications = qualificationWebService.findQualificationByMemberName(pin);
			// update yz 判断vatQualifications是否为null
			if (vatQualifications == null || vatQualifications.isEmpty()) {
				return null;
			}
			for (IVatQualification qualification : vatQualifications) {
				if (qualification.getValid() != null && qualification.getValid() == 1) {
					return qualification;
				}
			}
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"查询发票信息异常");
			Profiler.functionError(callerInfo);
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}

    
    @Override
    public IVatQualification orderCheck(BizOrder order,AbstractInvoiceInfo invoiceInfo) throws BizOrderServiceException{
        //update yz 增加收票人的信息验证
        LogTypeEnum.DEFAULT.error("收票人信息:{}",invoiceInfo);
        try {
         // update yz 统一调用findInvoiceInfo方法，获取有效的增票资质
            IVatQualification qualification = findInvoiceInfo(order.getPin());
            if(qualification != null){
                return qualification;
            }
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e,"下单查询发票信息异常");
            throw new BizOrderServiceException("服务异常，请重试");
        }
        return null;
    }

    @Override
    public BizOrderInvoice findByOrderId(Long orderId) {
        return bizOrderInvoiceDao.findByOrderId(orderId);
    }

    @Override
    public void insertInvoice(BizOrderInvoice invoice) {
        bizOrderInvoiceDao.insertInvoice(invoice);
    }

}
