package com.jd.sns.biz.api.service;

public interface BizJincaiQueryService {
	/**
	 * 查询用户授信额度
	 * @param jdOrderId
	 * @return
	 */
	
	public String queryCreditLimit(String pin);
}
