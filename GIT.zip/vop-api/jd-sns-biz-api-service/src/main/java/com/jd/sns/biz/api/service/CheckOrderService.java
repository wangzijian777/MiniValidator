package com.jd.sns.biz.api.service;

public interface CheckOrderService {
	
	public String checkHangUpOrder();
	
	/**
	 * 获取订单对账列表
	 * @param date 日期
	 * @param page 页码
	 * @param state state=0代表新创建未妥投或拒收的订单 1为妥投 2为拒收
	 * @param type 查询类型，1为查询新创建订单列表 2为为妥投或者拒收类型 3为未开发票
	 * @return
	 */
	public String checkOrderByState(String date, String page, int state, int type);
	
	
	/**
	 * 获取新建订单对账列表
	 * @param date 日期
	 * @param page 页码
	 * @param type 查询类型，1为查询新创建订单列表 2为为妥投  3为拒收类型
	 * @return
	 */
	String checkOrderByType(String date, String page, int type) ;
	
}
