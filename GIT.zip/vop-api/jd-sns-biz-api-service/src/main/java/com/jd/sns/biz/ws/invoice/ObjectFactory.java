
package com.jd.sns.biz.ws.invoice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.jd.sns.biz.ws.invoice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _FindCustomerAddress_QNAME = new QName("http://www.360buy.com", "findCustomerAddress");
    private final static QName _AddQualification_QNAME = new QName("http://www.360buy.com", "addQualification");
    private final static QName _AddQualificationFileResponse_QNAME = new QName("http://www.360buy.com", "addQualificationFileResponse");
    private final static QName _FindCustomerAddressResponse_QNAME = new QName("http://www.360buy.com", "findCustomerAddressResponse");
    private final static QName _DelQualification_QNAME = new QName("http://www.360buy.com", "delQualification");
    private final static QName _AddQualificationResponse_QNAME = new QName("http://www.360buy.com", "addQualificationResponse");
    private final static QName _FindQualificationFileByVatIdResponse_QNAME = new QName("http://www.360buy.com", "findQualificationFileByVatIdResponse");
    private final static QName _FindQualificationFileByVatId_QNAME = new QName("http://www.360buy.com", "findQualificationFileByVatId");
    private final static QName _AddQualificationFileBatchResponse_QNAME = new QName("http://www.360buy.com", "addQualificationFileBatchResponse");
    private final static QName _FindMemberByOutLink_QNAME = new QName("http://www.360buy.com", "findMemberByOutLink");
    private final static QName _AddQualificationFile_QNAME = new QName("http://www.360buy.com", "addQualificationFile");
    private final static QName _FindQualificationByMemberNameResponse_QNAME = new QName("http://www.360buy.com", "findQualificationByMemberNameResponse");
    private final static QName _DeleteQualificationFileResponse_QNAME = new QName("http://www.360buy.com", "deleteQualificationFileResponse");
    private final static QName _DeleteQualificationFile_QNAME = new QName("http://www.360buy.com", "deleteQualificationFile");
    private final static QName _AddQualificationFileBatch_QNAME = new QName("http://www.360buy.com", "addQualificationFileBatch");
    private final static QName _ManageCustomerAddressResponse_QNAME = new QName("http://www.360buy.com", "manageCustomerAddressResponse");
    private final static QName _FindMemberByOutLinkResponse_QNAME = new QName("http://www.360buy.com", "findMemberByOutLinkResponse");
    private final static QName _ManageCustomerAddress_QNAME = new QName("http://www.360buy.com", "manageCustomerAddress");
    private final static QName _UpdateQualificationResponse_QNAME = new QName("http://www.360buy.com", "updateQualificationResponse");
    private final static QName _FindQualificationByMemberName_QNAME = new QName("http://www.360buy.com", "findQualificationByMemberName");
    private final static QName _DelQualificationResponse_QNAME = new QName("http://www.360buy.com", "delQualificationResponse");
    private final static QName _UpdateQualification_QNAME = new QName("http://www.360buy.com", "updateQualification");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.jd.sns.biz.ws.invoice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ManageCustomerAddressResponse }
     * 
     */
    public ManageCustomerAddressResponse createManageCustomerAddressResponse() {
        return new ManageCustomerAddressResponse();
    }

    /**
     * Create an instance of {@link FindMemberByOutLinkResponse }
     * 
     */
    public FindMemberByOutLinkResponse createFindMemberByOutLinkResponse() {
        return new FindMemberByOutLinkResponse();
    }

    /**
     * Create an instance of {@link ManageCustomerAddress }
     * 
     */
    public ManageCustomerAddress createManageCustomerAddress() {
        return new ManageCustomerAddress();
    }

    /**
     * Create an instance of {@link UpdateQualificationResponse }
     * 
     */
    public UpdateQualificationResponse createUpdateQualificationResponse() {
        return new UpdateQualificationResponse();
    }

    /**
     * Create an instance of {@link FindQualificationByMemberName }
     * 
     */
    public FindQualificationByMemberName createFindQualificationByMemberName() {
        return new FindQualificationByMemberName();
    }

    /**
     * Create an instance of {@link DelQualificationResponse }
     * 
     */
    public DelQualificationResponse createDelQualificationResponse() {
        return new DelQualificationResponse();
    }

    /**
     * Create an instance of {@link UpdateQualification }
     * 
     */
    public UpdateQualification createUpdateQualification() {
        return new UpdateQualification();
    }

    /**
     * Create an instance of {@link FindMemberByOutLink }
     * 
     */
    public FindMemberByOutLink createFindMemberByOutLink() {
        return new FindMemberByOutLink();
    }

    /**
     * Create an instance of {@link AddQualificationFile }
     * 
     */
    public AddQualificationFile createAddQualificationFile() {
        return new AddQualificationFile();
    }

    /**
     * Create an instance of {@link FindQualificationByMemberNameResponse }
     * 
     */
    public FindQualificationByMemberNameResponse createFindQualificationByMemberNameResponse() {
        return new FindQualificationByMemberNameResponse();
    }

    /**
     * Create an instance of {@link DeleteQualificationFileResponse }
     * 
     */
    public DeleteQualificationFileResponse createDeleteQualificationFileResponse() {
        return new DeleteQualificationFileResponse();
    }

    /**
     * Create an instance of {@link DeleteQualificationFile }
     * 
     */
    public DeleteQualificationFile createDeleteQualificationFile() {
        return new DeleteQualificationFile();
    }

    /**
     * Create an instance of {@link AddQualificationFileBatch }
     * 
     */
    public AddQualificationFileBatch createAddQualificationFileBatch() {
        return new AddQualificationFileBatch();
    }

    /**
     * Create an instance of {@link FindQualificationFileByVatIdResponse }
     * 
     */
    public FindQualificationFileByVatIdResponse createFindQualificationFileByVatIdResponse() {
        return new FindQualificationFileByVatIdResponse();
    }

    /**
     * Create an instance of {@link FindQualificationFileByVatId }
     * 
     */
    public FindQualificationFileByVatId createFindQualificationFileByVatId() {
        return new FindQualificationFileByVatId();
    }

    /**
     * Create an instance of {@link AddQualificationFileBatchResponse }
     * 
     */
    public AddQualificationFileBatchResponse createAddQualificationFileBatchResponse() {
        return new AddQualificationFileBatchResponse();
    }

    /**
     * Create an instance of {@link AddQualification }
     * 
     */
    public AddQualification createAddQualification() {
        return new AddQualification();
    }

    /**
     * Create an instance of {@link FindCustomerAddress }
     * 
     */
    public FindCustomerAddress createFindCustomerAddress() {
        return new FindCustomerAddress();
    }

    /**
     * Create an instance of {@link AddQualificationFileResponse }
     * 
     */
    public AddQualificationFileResponse createAddQualificationFileResponse() {
        return new AddQualificationFileResponse();
    }

    /**
     * Create an instance of {@link FindCustomerAddressResponse }
     * 
     */
    public FindCustomerAddressResponse createFindCustomerAddressResponse() {
        return new FindCustomerAddressResponse();
    }

    /**
     * Create an instance of {@link AddQualificationResponse }
     * 
     */
    public AddQualificationResponse createAddQualificationResponse() {
        return new AddQualificationResponse();
    }

    /**
     * Create an instance of {@link DelQualification }
     * 
     */
    public DelQualification createDelQualification() {
        return new DelQualification();
    }

    /**
     * Create an instance of {@link VatQualification }
     * 
     */
    public VatQualification createVatQualification() {
        return new VatQualification();
    }

    /**
     * Create an instance of {@link ReturnInfo }
     * 
     */
    public ReturnInfo createReturnInfo() {
        return new ReturnInfo();
    }

    /**
     * Create an instance of {@link QualificationFile }
     * 
     */
    public QualificationFile createQualificationFile() {
        return new QualificationFile();
    }

    /**
     * Create an instance of {@link CustomerAddress }
     * 
     */
    public CustomerAddress createCustomerAddress() {
        return new CustomerAddress();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindCustomerAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "findCustomerAddress")
    public JAXBElement<FindCustomerAddress> createFindCustomerAddress(FindCustomerAddress value) {
        return new JAXBElement<FindCustomerAddress>(_FindCustomerAddress_QNAME, FindCustomerAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQualification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "addQualification")
    public JAXBElement<AddQualification> createAddQualification(AddQualification value) {
        return new JAXBElement<AddQualification>(_AddQualification_QNAME, AddQualification.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQualificationFileResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "addQualificationFileResponse")
    public JAXBElement<AddQualificationFileResponse> createAddQualificationFileResponse(AddQualificationFileResponse value) {
        return new JAXBElement<AddQualificationFileResponse>(_AddQualificationFileResponse_QNAME, AddQualificationFileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindCustomerAddressResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "findCustomerAddressResponse")
    public JAXBElement<FindCustomerAddressResponse> createFindCustomerAddressResponse(FindCustomerAddressResponse value) {
        return new JAXBElement<FindCustomerAddressResponse>(_FindCustomerAddressResponse_QNAME, FindCustomerAddressResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DelQualification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "delQualification")
    public JAXBElement<DelQualification> createDelQualification(DelQualification value) {
        return new JAXBElement<DelQualification>(_DelQualification_QNAME, DelQualification.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQualificationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "addQualificationResponse")
    public JAXBElement<AddQualificationResponse> createAddQualificationResponse(AddQualificationResponse value) {
        return new JAXBElement<AddQualificationResponse>(_AddQualificationResponse_QNAME, AddQualificationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindQualificationFileByVatIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "findQualificationFileByVatIdResponse")
    public JAXBElement<FindQualificationFileByVatIdResponse> createFindQualificationFileByVatIdResponse(FindQualificationFileByVatIdResponse value) {
        return new JAXBElement<FindQualificationFileByVatIdResponse>(_FindQualificationFileByVatIdResponse_QNAME, FindQualificationFileByVatIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindQualificationFileByVatId }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "findQualificationFileByVatId")
    public JAXBElement<FindQualificationFileByVatId> createFindQualificationFileByVatId(FindQualificationFileByVatId value) {
        return new JAXBElement<FindQualificationFileByVatId>(_FindQualificationFileByVatId_QNAME, FindQualificationFileByVatId.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQualificationFileBatchResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "addQualificationFileBatchResponse")
    public JAXBElement<AddQualificationFileBatchResponse> createAddQualificationFileBatchResponse(AddQualificationFileBatchResponse value) {
        return new JAXBElement<AddQualificationFileBatchResponse>(_AddQualificationFileBatchResponse_QNAME, AddQualificationFileBatchResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindMemberByOutLink }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "findMemberByOutLink")
    public JAXBElement<FindMemberByOutLink> createFindMemberByOutLink(FindMemberByOutLink value) {
        return new JAXBElement<FindMemberByOutLink>(_FindMemberByOutLink_QNAME, FindMemberByOutLink.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQualificationFile }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "addQualificationFile")
    public JAXBElement<AddQualificationFile> createAddQualificationFile(AddQualificationFile value) {
        return new JAXBElement<AddQualificationFile>(_AddQualificationFile_QNAME, AddQualificationFile.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindQualificationByMemberNameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "findQualificationByMemberNameResponse")
    public JAXBElement<FindQualificationByMemberNameResponse> createFindQualificationByMemberNameResponse(FindQualificationByMemberNameResponse value) {
        return new JAXBElement<FindQualificationByMemberNameResponse>(_FindQualificationByMemberNameResponse_QNAME, FindQualificationByMemberNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteQualificationFileResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "deleteQualificationFileResponse")
    public JAXBElement<DeleteQualificationFileResponse> createDeleteQualificationFileResponse(DeleteQualificationFileResponse value) {
        return new JAXBElement<DeleteQualificationFileResponse>(_DeleteQualificationFileResponse_QNAME, DeleteQualificationFileResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteQualificationFile }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "deleteQualificationFile")
    public JAXBElement<DeleteQualificationFile> createDeleteQualificationFile(DeleteQualificationFile value) {
        return new JAXBElement<DeleteQualificationFile>(_DeleteQualificationFile_QNAME, DeleteQualificationFile.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddQualificationFileBatch }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "addQualificationFileBatch")
    public JAXBElement<AddQualificationFileBatch> createAddQualificationFileBatch(AddQualificationFileBatch value) {
        return new JAXBElement<AddQualificationFileBatch>(_AddQualificationFileBatch_QNAME, AddQualificationFileBatch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ManageCustomerAddressResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "manageCustomerAddressResponse")
    public JAXBElement<ManageCustomerAddressResponse> createManageCustomerAddressResponse(ManageCustomerAddressResponse value) {
        return new JAXBElement<ManageCustomerAddressResponse>(_ManageCustomerAddressResponse_QNAME, ManageCustomerAddressResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindMemberByOutLinkResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "findMemberByOutLinkResponse")
    public JAXBElement<FindMemberByOutLinkResponse> createFindMemberByOutLinkResponse(FindMemberByOutLinkResponse value) {
        return new JAXBElement<FindMemberByOutLinkResponse>(_FindMemberByOutLinkResponse_QNAME, FindMemberByOutLinkResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ManageCustomerAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "manageCustomerAddress")
    public JAXBElement<ManageCustomerAddress> createManageCustomerAddress(ManageCustomerAddress value) {
        return new JAXBElement<ManageCustomerAddress>(_ManageCustomerAddress_QNAME, ManageCustomerAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateQualificationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "updateQualificationResponse")
    public JAXBElement<UpdateQualificationResponse> createUpdateQualificationResponse(UpdateQualificationResponse value) {
        return new JAXBElement<UpdateQualificationResponse>(_UpdateQualificationResponse_QNAME, UpdateQualificationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindQualificationByMemberName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "findQualificationByMemberName")
    public JAXBElement<FindQualificationByMemberName> createFindQualificationByMemberName(FindQualificationByMemberName value) {
        return new JAXBElement<FindQualificationByMemberName>(_FindQualificationByMemberName_QNAME, FindQualificationByMemberName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DelQualificationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "delQualificationResponse")
    public JAXBElement<DelQualificationResponse> createDelQualificationResponse(DelQualificationResponse value) {
        return new JAXBElement<DelQualificationResponse>(_DelQualificationResponse_QNAME, DelQualificationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateQualification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.360buy.com", name = "updateQualification")
    public JAXBElement<UpdateQualification> createUpdateQualification(UpdateQualification value) {
        return new JAXBElement<UpdateQualification>(_UpdateQualification_QNAME, UpdateQualification.class, null, value);
    }

}
