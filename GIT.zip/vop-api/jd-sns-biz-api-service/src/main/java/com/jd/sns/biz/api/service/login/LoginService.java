package com.jd.sns.biz.api.service.login;

import com.jd.common.web.result.Result;
import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.service.domain.MapResult;

/**
 * @auth lsg
 * @version 1.0.0
 */
public interface LoginService {
	/**
	 * 打开登录页面，判断用户输入参数
	 * @param client_id	对应用户appid
	 * @param response_type	固定是code
	 * @param redirect_uri	用户回调url
	 * @param ip	用户访问ip
	 * @return
	 */
	public Result checkLoginParam(User user);
	
	public String getAuthorizationCode(String pin);
	
	public Result loginService(String pin, String password, Result result, String ip);
	/**
	 * 根据code获取token
	 * @param user
	 * @param code
	 * @return
	 */
	public Result getToken(User user, String code);
	/**
	 * 根据账号密码获取access_token
	 * @param user
	 * @param code
	 * @param username
	 * @param password
	 * @param ip
	 * @return
	 */
	public MapResult getToken(User user, String username, String password, String ip, String valid, String time);
	
	public Result refreshToken(String client_id, String client_secret, String refresh_token);
	
//	public Result checkVisitLoginPageParams(String client_id, String response_type, String redirect_uri, Result result);
}
