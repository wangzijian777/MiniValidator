package com.jd.sns.biz.api.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.jd.biz.invoice.apply.domain.InvoiceBatchApi;
import com.jd.biz.invoice.apply.domain.InvoiceDetail;
import com.jd.biz.invoice.apply.domain.common.InvoiceResult;
import com.jd.biz.invoice.apply.service.rpc.InvoiceOrderSafService;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.InvoiceUMPFunctionKeyConstant;
import com.jd.sns.biz.api.constant.OrderConstants;
import com.jd.sns.biz.api.domain.BizDoInvoice;
import com.jd.sns.biz.api.domain.BizInvoiceDetail;
import com.jd.sns.biz.api.enumtype.ErrorCodeEnum;
import com.jd.sns.biz.api.service.DoInvoiceService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.domain.ResultBase;
import com.jd.sns.biz.api.service.domain.StringResult;
import com.jd.sns.biz.api.service.utils.ErrorCodeUtils;
import com.jd.sns.biz.api.service.utils.InvoiceConvertUtils;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


/**
 * 发票相关接口service
 * 
 * @author bjtt
 * 
 */
@Service(value="doInvoiceService")
public class DoInvoiceServiceImpl implements DoInvoiceService{

	@Resource InvoiceOrderSafService invoiceOrderSafService;
	
	@Override
	public String submitInvoice(BizDoInvoice bizDoInvoice) {
		CallerInfo callerInfoSubmitInvoice = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.SUBMIT_INVOICE,false,true);
		BooleanResult result = new BooleanResult();
		result.setSuccess(true);
		result.setResult(true);
		InvoiceResult invoiceResult = null;
		InvoiceBatchApi invoiceBatchApi = null;
		try {
			//1.参数校验（判空）
			result = (BooleanResult) checkParam(bizDoInvoice, result);
			if(!result.isSuccess()){
				return APIUtils.parseObject2Json(result);
			}
			try {
				//2.参数转换
				invoiceBatchApi = InvoiceConvertUtils.convertToInvoiceBatchApi(bizDoInvoice);
			} catch (Exception e) {
				result.setResultCode(ErrorCodeEnum.PARAM_FORMAT_ERROR.getType());
				result.setResultMessage("参数转换出错!");
				result.setResult(false);
				result.setSuccess(false);
				LogTypeEnum.INVOICE_LOG.error(e,"参数转换出错,markId:{}",bizDoInvoice.getMarkId());
				return APIUtils.parseObject2Json(result);
			}
			//3.调用发票系统开票接口
			CallerInfo callerInfoApply = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.SUBMIT_INVOICE_APPLY,false,true);
			try {
				invoiceResult = invoiceOrderSafService.submitInvoiceApply(invoiceBatchApi);
			} catch (Exception e) {
				LogTypeEnum.INVOICE_LOG.error(e,"调用开票接口异常，markId:{}",bizDoInvoice.getMarkId());
				Profiler.functionError(callerInfoApply);
				throw e;
			}finally{
				Profiler.registerInfoEnd(callerInfoApply);
			}
			//返回空或者false
			if(invoiceResult==null || !invoiceResult.getSuccess()){ //返回失败
				result.setResult(false);
				return dealWithFailResult(result, invoiceResult,bizDoInvoice.getMarkId());
			}
			result.setResultCode(ErrorCodeEnum.INVOICE_APPLY_SUCCESS.getType());
			result.setResultMessage(ErrorCodeEnum.INVOICE_APPLY_SUCCESS.getTypeName());
			return APIUtils.parseObject2Json(result);
		} catch (Exception e) {
			result.setResultCode(ErrorCodeEnum.SYSTEM_ERROR.getType());
			result.setResultMessage(ErrorCodeEnum.SYSTEM_ERROR.getTypeName());
			result.setSuccess(false);
			result.setSuccess(false);
			LogTypeEnum.INVOICE_LOG.error(e,"开票异常，markId:{}",bizDoInvoice.getMarkId());
			Profiler.functionError(callerInfoSubmitInvoice);
			return APIUtils.parseObject2Json(result);
		}finally{
			Profiler.registerInfoEnd(callerInfoSubmitInvoice);
		}
	}
	
	@Override
	public String selectInvoice(String markId) {
		CallerInfo callerInfoSelectInvoice = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.SELECT_INVOICE,false,true);
		StringResult result = new StringResult();
		result.setSuccess(true);
		InvoiceResult invoiceResult = null;
		try {
			String pin = APIUtils.getPin();
			String clientId = APIUtils.getClientId();
			if(StringUtils.isBlank(markId)){
				result.setSuccess(false);
				result.setResultMessage("markId不能为空");
				result.setResultCode(ErrorCodeEnum.PARAM_NULL.getType());
				return APIUtils.parseObject2Json(result);
			}
			//1.调用发票系统查询发票状态接口
			CallerInfo callerInfoApply = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.SELECT_INVOICE_STATE,false,true);
			try {
				invoiceResult = invoiceOrderSafService.getInvoiceApplyState(markId, pin, clientId);
			} catch (Exception e) {
				LogTypeEnum.INVOICE_LOG.error(e,"调用发票状态查询接口异常，markId:{}",markId);
				Profiler.functionError(callerInfoApply);
				throw e;
			}finally{
				Profiler.registerInfoEnd(callerInfoApply);
			}
			//2.部分开票和全部开票会返回true  其余返回false
			if(invoiceResult==null || !invoiceResult.getSuccess()){ //返回失败
				return dealWithFailResult(result, invoiceResult,markId);
			}
			//3.说明部分开票和全部开票，再调用获取发票详情接口
			CallerInfo callerInfoDetail = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.SELECT_INVOICE_DETAIL,false,true);
			try {
				invoiceResult = invoiceOrderSafService.getInvoiceApplyDetatil(markId, pin, clientId);
			} catch (Exception e) {
				LogTypeEnum.INVOICE_LOG.error(e,"调用发票详情查询接口异常，markId:{}",markId);
				Profiler.functionError(callerInfoDetail);
				throw e;
			}finally{
				Profiler.registerInfoEnd(callerInfoDetail);
			}
			//返回空或者false
			if(invoiceResult==null || !invoiceResult.getSuccess() ){ //返回失败
				return dealWithFailResult(result, invoiceResult,markId);
			}
			List<InvoiceDetail> list = (List<InvoiceDetail>)invoiceResult.get(OrderConstants.INVOICE_DATA_KEY);
			if(!CollectionUtils.isEmpty(list)){ //放入result中
				result.setResult(APIUtils.parseObject2Json(InvoiceConvertUtils.converToBizInvoiceDetailList(list)));
			}
			result.setResultCode(ErrorCodeUtils.getErrcode(invoiceResult.getResultCode()));
			result.setResultMessage(invoiceResult.getResultMessage());
			return APIUtils.parseObject2Json(result);
		} catch (Exception e) {
			result.setResultCode(ErrorCodeEnum.SYSTEM_ERROR.getType());
			result.setResultMessage(ErrorCodeEnum.SYSTEM_ERROR.getTypeName());
			result.setSuccess(false);
			LogTypeEnum.INVOICE_LOG.error(e,"查询发票信息异常，markId:{}",markId);
			Profiler.functionError(callerInfoSelectInvoice);
			return APIUtils.parseObject2Json(result);
		}finally{
			Profiler.registerInfoEnd(callerInfoSelectInvoice);
		}
	}
	
	@Override
	public String cancel(String markId) {
		CallerInfo callerInfoSelectInvoice = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.CANCEL_INVOICE,false,true);
		BooleanResult result = new BooleanResult();
		result.setSuccess(true);
		result.setResult(true);
		InvoiceResult invoiceResult = null;
		try {
			String pin = APIUtils.getPin();
			String clientId = APIUtils.getClientId();
			if(StringUtils.isBlank(markId)){
				result.setResult(false);
				result.setSuccess(false);
				result.setResultMessage("markId不能为空");
				result.setResultCode(ErrorCodeEnum.PARAM_NULL.getType());
				return APIUtils.parseObject2Json(result);
			}
			//1.调用发票系统查询发票状态接口
			CallerInfo callerInfoApply = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.CANCEL_INVOICE_APPLY,false,true);
			try {
				invoiceResult = invoiceOrderSafService.repealInvoiceApply(markId, pin, clientId);
			} catch (Exception e) {
				LogTypeEnum.INVOICE_LOG.error(e,"调用取消开票接口异常，markId:{}",markId);
				Profiler.functionError(callerInfoApply);
				throw e;
			}finally{
				Profiler.registerInfoEnd(callerInfoApply);
			}
			//2.部分开票和全部开票会返回true  其余返回false
			if(invoiceResult==null || !invoiceResult.getSuccess()){ //返回失败
				result.setResult(false);
				return dealWithFailResult(result, invoiceResult,markId);
			}
			result.setResultCode(ErrorCodeEnum.CANCEL_INVOICE_SUCCESS.getType());
			result.setResultMessage(ErrorCodeEnum.CANCEL_INVOICE_SUCCESS.getTypeName());
			return APIUtils.parseObject2Json(result);
		} catch (Exception e) {
			result.setResultCode(ErrorCodeEnum.SYSTEM_ERROR.getType());
			result.setResultMessage(ErrorCodeEnum.SYSTEM_ERROR.getTypeName());
			result.setResult(false);
			result.setSuccess(false);
			LogTypeEnum.INVOICE_LOG.error(e,"取消开票异常，markId:{}",markId);
			Profiler.functionError(callerInfoSelectInvoice);
			return APIUtils.parseObject2Json(result);
		}finally{
			Profiler.registerInfoEnd(callerInfoSelectInvoice);
		}
	}

	/**
	 * 发票系统返回false，对错误码转码 返回提示信息
	 * @param result
	 * @param invoiceResult
	 * @return
	 */
	private String dealWithFailResult(ResultBase result,InvoiceResult invoiceResult, String markId){
		if(invoiceResult == null){
			result.setResultMessage(ErrorCodeEnum.RETURN_NULL_VALUE.getTypeName());
			result.setResultCode(ErrorCodeEnum.RETURN_NULL_VALUE.getType());
			result.setSuccess(false);
			LogTypeEnum.INVOICE_LOG.error("调用发票系统接口返回为空，markId:{}",markId);
			return APIUtils.parseObject2Json(result);
		}
		if(!invoiceResult.isSuccess()){
			//错误码转换
			LogTypeEnum.INVOICE_LOG.error("调用发票系统接口返回失败，markId:{},resultCode:{},resultMessage:{}",markId,invoiceResult.getResultCode(),invoiceResult.getResultMessage());
			result.setResultCode(ErrorCodeUtils.getErrcode(invoiceResult.getResultCode()));
			result.setResultMessage(invoiceResult.getResultMessage());
			result.setSuccess(false);
			return APIUtils.parseObject2Json(result);
		}
		return null;
	}
	
	/**
	 * 输入参数校验
	 * @param bizDoInvoice
	 * @param result
	 * @return
	 */
	private ResultBase checkParam(BizDoInvoice bizDoInvoice, ResultBase result){
		result.setSuccess(false);
		result.setResultCode(ErrorCodeEnum.PARAM_NULL.getType());
		if(StringUtils.isBlank(bizDoInvoice.getSupplierOrder())){
			result.setResultMessage("supplierOrder不能为空");
			return result;
		}
		if(StringUtils.isBlank(bizDoInvoice.getMarkId())){
			result.setResultMessage("markId不能为空");
			return result;
		}
		if(StringUtils.isBlank(bizDoInvoice.getSettlementId())){
			result.setResultMessage("settlementId不能为空");
			return result;
		}
		if(bizDoInvoice.getInvoiceType()== null){
			result.setResultMessage("invoiceType不能为空");
			return result;
		}
		if(bizDoInvoice.getInvoiceOrg() == null){
			result.setResultMessage("invoiceOrg不能为空");
			return result;
		}
		if(bizDoInvoice.getBizInvoiceContent()==null){
			result.setResultMessage("bizInvoiceContent不能为空");
			return result;
		}
		if(bizDoInvoice.getInvoiceDate()==null){
			result.setResultMessage("invoiceDate不能为空");
			return result;
		}
		if(StringUtils.isBlank(bizDoInvoice.getTitle())){
			result.setResultMessage("title不能为空");
			return result;
		}
		if(bizDoInvoice.getInvoiceNakedPrice()==null){
			result.setResultMessage("invoiceNakedPrice不能为空");
			return result;
		}
		if(bizDoInvoice.getInvoiceTaxPrice()==null){
			result.setResultMessage("invoiceTaxPrice不能为空");
			return result;
		}
		if(bizDoInvoice.getInvoicePrice()==null){
			result.setResultMessage("invoicePrice不能为空");
			return result;
		}
		if(bizDoInvoice.getCurrentBatch()==null){
			result.setResultMessage("currentBatch不能为空");
			return result;
		}
		if(bizDoInvoice.getTotalBatch()==null){
			result.setResultMessage("totalBatch不能为空");
			return result;
		}
		if(bizDoInvoice.getTotalBatchInvoiceNakedAmount()==null){
			result.setResultMessage("totalBatchInvoiceNakedAmount不能为空");
			return result;
		}
		if(bizDoInvoice.getTotalBatchInvoiceTaxAmount()==null){
			result.setResultMessage("totalBatchInvoiceTaxAmount不能为空");
			return result;
		}
		if(bizDoInvoice.getTotalBatchInvoiceAmount()==null){
			result.setResultMessage("totalBatchInvoiceAmount不能为空");
			return result;
		}
		if(bizDoInvoice.getSupplierOrder().split(OrderConstants.SPILT_CODE_D).length > 500){
			result.setResultMessage("supplierOrder包含子订单数目不大于500");
			result.setResultCode(ErrorCodeEnum.PARAM_VALUE_ERROR.getType());
			return result;
		}
		result.setSuccess(true);
		return result;
	}

}
