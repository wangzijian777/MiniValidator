package com.jd.sns.biz.api.service.domain;

import java.util.List;

public class PageNumResult extends ResultBase {
	private int totalPage;
	private List<ProductPageNum> PageList;
	public List<ProductPageNum> getPageList() {
		return PageList;
	}
	public void setPageList(List<ProductPageNum> pageList) {
		PageList = pageList;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	
}
