package com.jd.sns.biz.api.service.utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


import com.jd.common.util.StringUtils;
import com.jd.fastjson.JSON;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.domain.AbstractInvoiceInfo;
import com.jd.sns.biz.api.domain.BaseSku;
import com.jd.sns.biz.api.domain.BaseSkuList;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.BizSku;
import com.jd.sns.biz.api.domain.BizSkuList;
import com.jd.sns.biz.api.domain.IVatQualification;
import com.jd.sns.biz.api.domain.Sku;
import com.jd.sns.biz.api.domain.SkuList;
import com.jd.sns.biz.api.enumtype.SkuTypeEnum;
import com.jd.sns.biz.common.enumtype.ShipmentTimeType;
import com.jd.sns.biz.common.enumtype.ShipmentType;
import com.jd.sns.biz.common.enumtype.SourceType;
import com.jd.sns.biz.order.domain.BizOrderSku;
import com.jd.sns.biz.order.domain.Order;
import com.jd.sns.biz.order.domain.OrderInfo;
import com.jd.sns.biz.order.domain.OrderInvoiceInfo;
import com.jd.stock.domain.SkuNum;


public class OrderConvertUtils {
	
	public static OrderInfo convertBizOrder(BizOrder bizOrder){
		OrderInfo orderInfo = new OrderInfo();
		orderInfo.setThirdOrderId(bizOrder.getThirdOrder());
		orderInfo.setPin(bizOrder.getPin());
		orderInfo.setProvince(bizOrder.getProvince());
		orderInfo.setCity(bizOrder.getCity());
		orderInfo.setCounty(bizOrder.getCounty());
		orderInfo.setTown(bizOrder.getTown());
		orderInfo.setOrderPrice(bizOrder.getOrderPrice()); //可以不计算，soa接口会计算
		orderInfo.setPayMoney(bizOrder.getOrderPrice()); //应付金额，vsp才有
		orderInfo.setIsUseBalance(bizOrder.getIsUseBalance());
		orderInfo.setFreight(new BigDecimal(0));//运费默认传0
		orderInfo.setPaymentType(bizOrder.getPaymentType());
		orderInfo.setPriceType(bizOrder.getPriceType());
		orderInfo.setShipmentType(ShipmentType.JD.getType());  //传默认值
		orderInfo.setShipmentTimeType(ShipmentTimeType.EVERYDAY.getType()); //传默认值
		orderInfo.setSubmitState(bizOrder.getSubmitState());
		orderInfo.setName(bizOrder.getName());
		orderInfo.setAddress(bizOrder.getAddress());
		orderInfo.setZip(bizOrder.getZip());
		orderInfo.setPhone(bizOrder.getPhone());
		orderInfo.setMobile(bizOrder.getMobile());
		orderInfo.setEmail(bizOrder.getEmail());
		orderInfo.setRemark(bizOrder.getRemark());
		orderInfo.setIp(bizOrder.getIp());
		orderInfo.setInvoiceState(bizOrder.getInvoiceState());
		orderInfo.setClientId(bizOrder.getClientId());
		orderInfo.setSourceType(SourceType.ORDER_VOP.getType());
//		orderInfo.setServiceRate();
//		orderInfo.setSkuList();
//		orderInfo.setOrderInvoiceInfo();
		return orderInfo;
	}
	
	public static List<BizOrderSku> convertSkuList(SkuList skuList){
		List<BizOrderSku> list = new ArrayList<BizOrderSku>();
		List<Sku> listSku = skuList.getSku();
		for(Sku sku: listSku){
			BizOrderSku orderSku = new BizOrderSku();
			orderSku.setSkuId(sku.getSkuId());
			orderSku.setNum(sku.getNum());
			orderSku.setCategory(sku.getCategory());
			orderSku.setPrice(sku.getPrice());
			orderSku.setName(sku.getName());
			orderSku.setTax(sku.getTax());
			orderSku.setTaxPrice(sku.getTaxPrice());
			orderSku.setNakedPrice(sku.getNakedPrice());
			orderSku.setSkuPrice(sku.getPrice());//与price传一样值
			orderSku.setbNeedAnnex(sku.getbNeedAnnex());
			orderSku.setbNeedGift(sku.getbNeedGift());
			orderSku.setType(sku.getType());
			list.add(orderSku);
		}
		return list;
	}
	
	public static OrderInvoiceInfo convertOrderInvoiceInfo(BizOrder order, AbstractInvoiceInfo info,IVatQualification qualification ) {
		//发票信息
		OrderInvoiceInfo orderInvoicInfo = new OrderInvoiceInfo();
		//设置订单id还没插入数据库,soa接口处理
//		orderInvoice.setOrderId(dbBizOrder.getId());
		//订单发票类型
		orderInvoicInfo.setInvoiceType(order.getInvoiceType());
		//pin
		orderInvoicInfo.setPin(order.getPin());
	
		//普通发票
		if(order.getInvoiceType()!=null&&order.getInvoiceType()==1)
		{
			//订单发票内容类型
			orderInvoicInfo.setInvoiceContentType(order.getInvoiceContent());
			//抬头 公司还是个人
			orderInvoicInfo.setSelectedInvoiceTitle(order.getSelectedInvoiceTitle());
			//订单公司名称
			orderInvoicInfo.setCompanyName(order.getCompanyName());
		}
		//增票
		if (order.getInvoiceType()!=null&&order.getInvoiceType().intValue() == 2) {
			//公司名称
			orderInvoicInfo.setVatCompanyName(qualification.getCompany());
			// 纳税人标识号
			orderInvoicInfo.setCode(qualification.getTaxId());
			//注册地址			
			orderInvoicInfo.setRegAddr(qualification.getAddress());
			//注册电话
			orderInvoicInfo.setRegPhone(qualification.getPhone());
			//注册银行
			orderInvoicInfo.setRegBank(qualification.getBank());
			//注册银行
			orderInvoicInfo.setRegBankAccount(qualification.getAccount());
			
			orderInvoicInfo.setInvoiceContentType(1);
			
			//收票人	信息
			//姓名
			orderInvoicInfo.setConsigneeName(info.getInvoiceName());
			//电话
			orderInvoicInfo.setPhone(info.getInvoicePhone());
			//省
			orderInvoicInfo.setProvinceId(info.getInvoiceProvice());
			//市
			orderInvoicInfo.setCityId(info.getInvoiceCity());
			//县
			orderInvoicInfo.setCountyId(info.getInvoiceCounty());
			//镇
			orderInvoicInfo.setTownId(info.getInvoiceTown());
			//地址
			orderInvoicInfo.setAddress(info.getInvoiceAddress());	
			
		}
		return orderInvoicInfo;
	}
	
	public static Map<String, Object> returnSubmitOrderSuccess(OrderInfo orderInfo, boolean isMmbType, boolean isUseOldGift){
        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("jdOrderId", orderInfo.getJdOrderId());
        resultMap.put("orderPrice", orderInfo.getOrderPrice());
        resultMap.put("orderNakedPrice" , null);
        resultMap.put("orderTaxPrice" , null);
        if(isMmbType){
        	resultMap.put("freight" , orderInfo.getFreight());
        }
        if(isUseOldGift){ //原逻辑  不返回sku类型
        	dealWithOutGift(orderInfo, resultMap);
        }else{ //新逻辑，需要返回sku类型
        	dealWithGift(orderInfo, resultMap);
        }
        return resultMap;
    }
	
	private static void dealWithGift(OrderInfo orderInfo, Map<String, Object> resultMap){
		List<BizOrderSku> orderSkuList=orderInfo.getSkuList();
        List<BizSku> list=OrderConvertUtils.convertBizSkuList(orderSkuList);
        resultMap.put("sku", list);
        dealWithPrice(list, resultMap);
	}

	private static void dealWithOutGift(OrderInfo orderInfo, Map<String, Object> resultMap){
		List<BizOrderSku> orderSkuList=orderInfo.getSkuList();
        List<BaseSku> list=OrderConvertUtils.convertBizOrderSkuList(orderSkuList);
        resultMap.put("sku", list);
        dealWithPrice(list, resultMap);
	}
	
	/**
	 * 对sku中的价格组装订单orderNakedPrice和orderTaxPrice
	 *    下单返回结果和订单查询需要使用
	 * @param <T>  Sku不含type；BizSku含type
	 * @param list
	 * @param resultMap
	 */
	public static<T> void dealWithPrice(List<T>list, Map<String, Object> resultMap){
		BigDecimal orderNakedPrice = new BigDecimal(0);
        BigDecimal orderTaxPrice = new BigDecimal(0);
        for (int i=0;i<list.size();i++){
            BaseSku one = (BaseSku) list.get(i);
            if(one.getTax() == null){
            	one.setTax(new BigDecimal(0));
            	one.setNakedPrice(one.getPrice());
            	one.setTaxPrice(new BigDecimal(0));
            }
            orderNakedPrice = orderNakedPrice.add(one.getNakedPrice().multiply(new BigDecimal(one.getNum())));
            orderTaxPrice = orderTaxPrice.add(one.getTaxPrice().multiply(new BigDecimal(one.getNum())));
        }
        resultMap.put("orderNakedPrice" , orderNakedPrice);
        resultMap.put("orderTaxPrice" , orderTaxPrice);
	}

	/**
	 * 订单查询返回结果处理（不含赠品）
	 * @param order
	 * @param resultMap
	 */
	public static void dealWithOutGift(Order order, Map<String, Object> resultMap){
		List<BaseSku> skuListDb = parsingBaseSkuList(order.getSku()).getSku();
		//把价格为0的sku去掉
		List<BaseSku> skuList = cutOffGiftSku(skuListDb);
		resultMap.put("jdOrderId", order.getJdOrderId());
		resultMap.put("sku", skuList);
		dealWithPrice(skuList, resultMap);
	}
	
	/**
	 * 订单查询返回结果处理（含赠品）
	 * @param order
	 * @param resultMap
	 */
	public static void dealWithGift(Order order, Map<String, Object> resultMap){
		List<BizSku> skuList = parsingBizSkuList(order.getSku()).getSku();
		resultMap.put("jdOrderId", order.getJdOrderId());
		resultMap.put("sku", skuList);
		dealWithPrice(skuList, resultMap);
	}
	
	private static List<BaseSku> convertBizOrderSkuList(List<BizOrderSku> orderSkuList) {
		List<BaseSku> list = new ArrayList<BaseSku>(orderSkuList.size());
		for(BizOrderSku orderSku: orderSkuList){
			if(orderSku.getPrice().compareTo(BigDecimal.ZERO) > 0){//非赠品，金额>0
				BaseSku sku = new BaseSku();
				sku.setSkuId(orderSku.getSkuId());
				sku.setNum(orderSku.getNum());
				sku.setCategory(orderSku.getCategory());
				sku.setPrice(orderSku.getPrice());
				sku.setName(orderSku.getName());
				sku.setTax(orderSku.getTax());
				sku.setTaxPrice(orderSku.getTaxPrice());
				sku.setNakedPrice(orderSku.getNakedPrice());
				list.add(sku);
			}
		}
		return list;
	}
	
	private static List<BizSku> convertBizSkuList(List<BizOrderSku> orderSkuList) {
		List<BizSku> list = new ArrayList<BizSku>(orderSkuList.size());
		for(BizOrderSku orderSku: orderSkuList){
			BizSku sku = new BizSku();
			sku.setSkuId(orderSku.getSkuId());
			sku.setNum(orderSku.getNum());
			sku.setCategory(orderSku.getCategory());
			sku.setPrice(orderSku.getPrice());
			sku.setName(orderSku.getName());
			sku.setTax(orderSku.getTax());
			sku.setTaxPrice(orderSku.getTaxPrice());
			sku.setNakedPrice(orderSku.getNakedPrice());
			sku.setType(orderSku.getType());
			sku.setOid(orderSku.getOid());
			list.add(sku);
		}
		return list;
	}
	
	/**
     * 转化为SkuList格式
     *
     * @param sku
     * @return
     */
    public static SkuList parsingSkuList(String sku) {
        try {
            String skuString = "{\"sku\":" + sku + "}";
            SkuList skuList = APIUtils.parseJson2Object(skuString, SkuList.class);
            // 对延保sku进行特殊处理
            List<Sku> yanbaoSkus = new ArrayList<Sku>();
            for (Sku skuItem : skuList.getSku()) {
				if(!StringUtils.isBlank(skuItem.getYanbao())){
					// 不为空才计算延保sku
					List<Sku> skus = JSON.parseArray(skuItem.getYanbao(), Sku.class);
					for (Sku s : skus) {
						s.setbNeedAnnex(false);
						s.setbNeedGift(false);
						s.setNum(skuItem.getNum());
						s.setType(SkuTypeEnum.YANBAO_SKU.getType());
						yanbaoSkus.add(s);
					}
				}
			}
            if(!yanbaoSkus.isEmpty()){
            	 skuList.getSku().addAll(yanbaoSkus);
            }
           
            return skuList;
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e,"BaseOrderServiceImpl.parsingSkuList -ERROR");
            return null;
        }
    }
    
    /**
     * 转化为SkuList格式
     *
     * @param sku
     * @return
     */
    private static BizSkuList parsingBizSkuList(String sku) {
        try {
            String skuString = "{\"sku\":" + sku + "}";
            return APIUtils.parseJson2Object(skuString, BizSkuList.class);
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e,"BaseOrderServiceImpl.parsingSkuList -ERROR");
            return null;
        }
    }
    
    /**
     * 转化为SkuList格式
     *
     * @param sku
     * @return
     */
    private static BaseSkuList parsingBaseSkuList(String sku) {
        try {
            String skuString = "{\"sku\":" + sku + "}";
            return APIUtils.parseJson2Object(skuString, BaseSkuList.class);
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e,"BaseOrderServiceImpl.parsingSkuList -ERROR");
            return null;
        }
    }
    
    /**
	 * 过滤skuList  把价格为0的sku去掉(即把赠品去掉)
	 * @param bizOrder
	 * @return
	 */
	private static List<BaseSku> cutOffGiftSku(List<BaseSku> skuList){
		List<BaseSku> list = new ArrayList<BaseSku>();
		for(BaseSku sku : skuList){
			if(sku.getPrice().compareTo(new BigDecimal(0))>0){ //>0
				list.add(sku);
			}
		}
		return list;
	}
	/**
     * 将skuIds转换为set
     * @param skuIds
     * @return
     */
    public static Set<Long> skuIdsToSet(String[] skuIds){
    	Set<Long> skuIdSet=new HashSet<Long>();
    	for (String skuId : skuIds) {
    		skuId=skuId.replace("J_", "");
			skuIdSet.add(Long.valueOf(skuId));
		}
    	
		return skuIdSet;
    }
    
    public static Set<Long> skuNumsListToSet(List<LinkedHashMap<String,Object>> skuNumList) {
    	Set<Long> skuIdSet=new HashSet<Long>();
    	for(LinkedHashMap<String,Object> e:skuNumList){	
			Integer skuId=Integer.valueOf(e.get("skuId").toString());
			skuIdSet.add(Long.valueOf(skuId));
    	}
		return skuIdSet;
    }
    
    
    /**
	 * 从主数据合同属性字段中获取是否有赠品权限  giftType:0无赠品 1有赠品
	 * @param contractAttribute
	 * @return
	 */
	public static Integer getGiftType(String contractAttribute){ 
		//accountMode:0^invoiceType:0^invoiceMode:0^specialType:0^takeDays:6^giftType:0 
		if (StringUtils.isNotBlank(contractAttribute)) {
			String[] str = (contractAttribute).split("\\^");
			for(int i=0;i<str.length;i++) {
				String[]stringlist=str[i].split(":");
				if (stringlist[0].equals("giftType")) {
					if(stringlist.length>1){
						try {
							return Integer.parseInt(stringlist[1]);
						} catch (Exception e) {
							LogTypeEnum.SUBMIT_ORDER_LOG.error("从主数据获取是否有赠品权限出错：contractAttribute:{}",contractAttribute);
							return 0;
						}
					}
				}
			}
		}
		return 0;
	}
}
