package com.jd.sns.biz.api.service;

public interface BizOrderService {
	/**
	 * 取消订单
	 * @param jdOrderId
	 * @return
	 */
	public String cancelJdOrder(String jdOrderId);

	/**
	 * 查询订单
	 * @param jdOrderId
	 * @return
	 */
	public String selectJdOrder(String jdOrderId);
	
	public String orderTrack(String jdOrderId);

	/**
	 * 根据第三方订单编号查出企业订单列表
	 * 
	 * @param thirdOrder
	 * @return
	 */
	public String selectJdOrderListByThirdOrder(String thirdOrder);
	/**
	 * 根据第三方订单号获取父订单信息
	 * @param thirdOrder
	 * @return
	 */
	public String selectBizOrderByThirdOrder(String thirdOrder);
	
	/**
	 * 发起支付
	 * @param jdOrderId
	 * @return
	 */
	String doPay(long jdOrderId);
}
