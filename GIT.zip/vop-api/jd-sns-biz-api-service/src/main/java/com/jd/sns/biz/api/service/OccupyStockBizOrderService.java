package com.jd.sns.biz.api.service;

import com.jd.sns.biz.api.domain.AbstractInvoiceInfo;
import com.jd.sns.biz.api.domain.BizOrder;

/**
 * 预占库存提交订单方式
 * @author yujianming
 *
 */
public interface OccupyStockBizOrderService {
	/**
	 * 提交订单
	 * @return
	 */
	public String submitOrder(BizOrder bizOrder,AbstractInvoiceInfo invoiceInfo);
	/**
	 * 确认提交订单
	 * @param jdOrderId
	 * @return
	 */
	public String confirmOrder(String jdOrderId);
	/**
	 * 取消预占库存订单
	 * @param jdOrderId
	 * @return
	 */
	public String cancel(String jdOrderId);
}
