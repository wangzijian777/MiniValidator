package com.jd.sns.biz.api.service.utils;

import java.util.HashSet;
import java.util.Set;

import com.jd.common.util.StringUtils;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.enumtype.InvoiceStateNew;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.common.enumtype.PaymentType;

/**
 * 下单验证类：验证支付方式，发票种类
 * @author bjtt
 * @date 2014-08-29
 *
 */
public class OrderValidateUtils {

	//主数据结算信息：公司转账 0， 企业余额充值 1 ，支票 2 ，账期 3 ，货到付款 4 ，金融支付 5 
	private final static String PAY_GSZZ = "0";
	private final static String PAY_QYYECZ = "1";
	private final static String PAY_ZP = "2";
	private final static String PAY_ZQ = "3";
	private final static String PAY_HDFK = "4";
	private final static String PAY_JRZF = "5";
	private final static String PAY_WYQB = "6";
	
	//主数据发票种类：普票 0，增票 1
	private final static String INVOICE_PP = "0";
	private final static String INVOICE_ZP = "1";
	
	//主数据开票方式
	public final static String  INVOICE_MODE_SHKP = "0"; //随货开票 
	public final static String  INVOICE_MODE_JZKP = "1"; //集中开票
	public final static String  INVOICE_MODE_DDYJ = "2"; //订单预借
	public final static String  INVOICE_MODE_KDYJ = "3"; //款到预借
	
	//预占库存权限
	private final static String SPECIAL_TYPE_YZKC = "0";
	
	private final static String SPLIT_CODE = ",";
	
	public static void validatePaymentType(String accountMode,BizOrder bizOrder,MapResult result){
		if(StringUtils.isBlank(accountMode)){//支付方式
			result.setResultMessage("根据clientId获取支付方式为空!");
			result.setSuccess(false);
		}
		
		Set<String> set = convertToList(accountMode);
		//金融支付相关校验，逻辑与原vop一样
//		if(!set.contains(PAY_JRZF)){//如果没有金融支付权限
//			if(bizOrder.getPaymentType()==PaymentType.JINRONGZHIFU.getType()){ 
//				result.setSuccess(false);
//				result.setResultMessage("您没有金融支付权限，但是选择了金融支付");
//				return ;
//			}
//		} else{  //有金融支付权限 TODO 待确认
//			if(bizOrder.getPaymentType()!=PaymentType.JINRONGZHIFU.getType()){
//				result.setSuccess(false);
//				result.setResultMessage("您只能选择金融支付进行支付!");
//				return;
//			}else{
//				if(bizOrder.getSubmitState()!=0){
//					result.setSuccess(false);
//					result.setResultMessage("金融支付只能使用预占库存方式!");
//					return;
//				}
//			}
//		} 
		
		//金融支付
		if(bizOrder.getPaymentType() == PaymentType.JINRONGZHIFU.getType() ){ //金融支付
			if(!set.contains(PAY_JRZF)){//如果没有金融支付权限
				result.setSuccess(false);
				result.setResultMessage("您没有金融支付权限，但是选择了金融支付!");
				return ;
			} 
		}
		
				
		//月结
		if(bizOrder.getPaymentType() == PaymentType.YUEJIE.getType() ){ //月结
			if(!set.contains(PAY_ZQ)){//如果没有账期权限
				result.setSuccess(false);
				result.setResultMessage("您没有月结支付权限，但是选择了月结支付方式！");
				return ;
			} 
		}
		
		//公司转账
		if(bizOrder.getPaymentType() == PaymentType.GONGSIZHUANZHANG.getType()){ 
			if(!set.contains(PAY_GSZZ)){//如果没有公司转账权限
				result.setSuccess(false);
				result.setResultMessage("您没有公司转账权限权限，但是选择了公司转账方式！") ;
				return ;
			} 
		}
		
		//银行转账
		if(bizOrder.getPaymentType() == PaymentType.YINHANGZHUANZHANG.getType()){ 
			if(!set.contains(PAY_GSZZ)){//如果没有银行转账权限
				result.setSuccess(false);
				result.setResultMessage("您没有银行转账权限权限，但是选择了银行转账方式！");
				return ;
			} 
		}
		
		//货到付款
		if(bizOrder.getPaymentType() == PaymentType.HUODAOFUKUAN.getType()){ 
			if(!set.contains(PAY_HDFK)){//如果没有货到付款权限
				result.setSuccess(false);
				result.setResultMessage("您没有货到付款权限权限，但是选择了货到付款方式！");
				return ;
			} 
		}
		
		// ZAIXIANZHIFU(4, "在线支付"), 
		if(bizOrder.getPaymentType() == PaymentType.ZAIXIANZHIFU.getType()){ 
			if(!set.contains(PAY_QYYECZ)){//如果没有在线支付权限
				result.setSuccess(false);
				result.setResultMessage("您没有在线支付权限权限，但是选择了在线支付方式！");
				return ;
			} 
		}
		
		if(bizOrder.getPaymentType() == PaymentType.WANGYINQIANBAO.getType()){ 
			if(!set.contains(PAY_WYQB)){//如果没有网银钱包支付权限
				result.setSuccess(false);
				result.setResultMessage("您没有网银钱包支付权限权限，但是选择了网银钱包支付方式！");
				return ;
			} 
		}
	}
	
	
	public static void validateInvoiceTypeInfo(String invoiceType,BizOrder bizOrder,MapResult result){
		if(bizOrder.getInvoiceType() != null && bizOrder.getInvoiceType() == 2){ //选择增票
			if(StringUtils.isBlank(invoiceType)){  
				result.setSuccess(false);
				result.setResultMessage("您没有增票权限，但是选择了增票!");
			}else{
				Set<String> set = convertToList(invoiceType);
				if(!set.contains(INVOICE_ZP)){
					result.setSuccess(false);
					result.setResultMessage("您没有增票权限，但是选择了增票!");
				}
			}
		}
	}
	
	
	public static void validateInvoiceMode(String invoiceMode,BizOrder bizOrder ,MapResult result){
		Set<String> set = convertToList(invoiceMode);
		if(bizOrder.getInvoiceState()!=null){
			if(bizOrder.getInvoiceState() == InvoiceStateNew.SUIHUO_INVOICE.getType()){
				if(!set.contains(INVOICE_MODE_SHKP)){ 
					//选择了开票
					result.setSuccess(false);
					result.setResultMessage("选择随货开票，但合同不含此权限!");
				}
			}else if(bizOrder.getInvoiceState() == InvoiceStateNew.JIZHONG_INVOICE.getType()){
				if(!set.contains(INVOICE_MODE_JZKP)){ 
					//选择了开票
					result.setSuccess(false);
					result.setResultMessage("选择集中开票，但合同不含此权限!");
				}
			}else if(bizOrder.getInvoiceState() == InvoiceStateNew.YUJIE_INVOICE.getType()){
				if(!set.contains(INVOICE_MODE_DDYJ)){ 
					//选择了开票
					result.setSuccess(false);
					result.setResultMessage("选择订单预借，但合同不含此权限!");
				}
			}
		}
	}
	
	public static void validateSubmitStateInfo(String specialType,BizOrder bizOrder,MapResult result){
		//预占库存相关校验
		if(bizOrder.getSubmitState() != null && bizOrder.getSubmitState() == 0){ //选择预占库存
			if(StringUtils.isBlank(specialType)){  
				result.setSuccess(false);
				result.setResultMessage("您没有预占库存权限，但是选择了预占库存!");
			}else{
				Set<String> set = convertToList(specialType);
				if(!set.contains(SPECIAL_TYPE_YZKC)){
					result.setSuccess(false);
					result.setResultMessage("您没有预占库存权限，但是选择了预占库存!");
				}
			}
		}
	}
	
	public static void setBizOrderInvoiceInfo(BizOrder dbBizOrder, BizOrder bizOrder){
		if(bizOrder.getInvoiceState() != null){
			dbBizOrder.setInvoiceState(bizOrder.getInvoiceState());//开发票
			dbBizOrder.setInvoiceType(bizOrder.getInvoiceType());//发票类型
			dbBizOrder.setSelectedInvoiceTitle(bizOrder.getSelectedInvoiceTitle());//个人还是单位
			dbBizOrder.setCompanyName(bizOrder.getCompanyName());//发票抬头
			dbBizOrder.setInvoiceContent(bizOrder.getInvoiceContent());//明细啥的
		}
	}
	
	public static Set<String> convertToList(String str){
		String[] array = str.split(SPLIT_CODE);
		Set<String> set = new HashSet<String>();
		for(String s: array){
			set.add(s);
		}
		return set;
	}
	
}
