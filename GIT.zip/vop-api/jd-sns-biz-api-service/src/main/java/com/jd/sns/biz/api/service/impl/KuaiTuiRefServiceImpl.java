package com.jd.sns.biz.api.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jd.fce.orb.domain.CancelOrderDetail;
import com.jd.fce.orb.service.OrderRefundService;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.service.KuaiTuiRefService;

@Service("kuaiTuiRefService")
public class KuaiTuiRefServiceImpl implements KuaiTuiRefService{
	@Resource(name = "orderRefundService")
	private OrderRefundService orderRefundService;
	
	public CancelOrderDetail queryCancelStepsByOrderId(long jdOrderId, String pin){
		if(jdOrderId <= 0){
			throw new IllegalArgumentException("京东订单号不能为空!");
		}
		
		if(!StringUtils.hasText(pin)){
			throw new IllegalArgumentException("用户pin不能为空!");
		}
		try {
			CancelOrderDetail detail = orderRefundService.getCancelOrderDetail(jdOrderId, pin, String.valueOf(42));
			return detail;
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"快退进度查询错误: jdOrderId = {}, pin = {}" , jdOrderId, pin);
			throw new RuntimeException(e);
		}
		
	}
}
