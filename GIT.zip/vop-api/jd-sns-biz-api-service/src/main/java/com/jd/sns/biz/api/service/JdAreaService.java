package com.jd.sns.biz.api.service;

/**
 * 地址服务
 * @author yujianming
 *
 */
public interface JdAreaService {
	/**
	 * 获取省json列表(1级地址)
	 * @return
	 */
	public String getProvinces();
	/**
	 * 根据省id，获取市id json 列表(2级地址)
	 * @param provinceId
	 * @return
	 */
	public String getCitys(String provinceId);
	
	/**
	 * 根据市id，获取区县级信息json列表 (3级地址)
	 */
	public String getCountys(String cityId);
	
	/**
	 * 根据区id，获取乡镇级信息json列表 (4级地址)
	 * @param countyId
	 * @return
	 */
	public String getTowns(String countyId);
}
