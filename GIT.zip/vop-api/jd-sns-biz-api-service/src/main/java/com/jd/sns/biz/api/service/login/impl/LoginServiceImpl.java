package com.jd.sns.biz.api.service.login.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.stereotype.Service;

import call.common.SoaCallException;

import com.jd.common.util.StringUtils;
import com.jd.common.web.result.Result;
import com.jd.ka.user.soa.domain.ClientInfo;
import com.jd.ka.user.soa.domain.ErpContractInfo;
import com.jd.ka.user.soa.exception.BizUserSoaException;
import com.jd.ka.user.soa.service.clientInfo.ClientInfoService;
import com.jd.sns.biz.api.common.utils.ApiConstants;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.common.utils.MD5Util;
import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.manager.oauth2.Oauth2Manager;
import com.jd.sns.biz.api.redis.JdCacheUtils;
import com.jd.sns.biz.api.service.UserService;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.login.LoginService;
import com.jd.sns.biz.api.service.oauth2.Oauth2Service;
import com.jd.sns.biz.api.service.utils.Profiles;
import com.jd.uic.soa.rpc.JiceUserInfoPassport;
import com.jd.uic.soa.rpc.RpcJdUserServicePrx;
import com.jd.user.rpc.dubbo.DubboUserInfoUpdateService;


/**
 * @auth yujianming
 * @version 1.0.0
 */
@Service(value = "loginService")
public class LoginServiceImpl implements LoginService {
//	private static final Logger log = LoggerFactory.getLogger(LoginServiceImpl.class);
	
	private RpcJdUserServicePrx rpcJdUserService;
	private Oauth2Service oauth2Service;
	private UserService userService;
    private Oauth2Manager oauth2Manager;
    private DubboUserInfoUpdateService dubboUserInfoUpdateService;
    private ClientInfoService clientInfoService;
    
	private JdCacheUtils redisUtils;
	@Override
	public Result checkLoginParam(User user) {
		Result result = new Result();
		try{
			result.setSuccess(false);
			//判断前台参数是否为空
			if(StringUtils.isBlank(user.getClient_id())){
				result.setResultCode(ApiConstants.returnValue.APPID_ERROR);
				return result;
			}
			if(!"code".equals(user.getResponse_type())){
				result.setResultCode(ApiConstants.returnValue.RESPONSE_TYPE_ERROR);
				return result;
			}
			if(StringUtils.isBlank(user.getRedirect_uri())){
				result.setResultCode(ApiConstants.returnValue.REDIRECT_URI_ERROR);
				return result;
			}
			
			result = oauth2Service.checkVisitLoginPageParams(user, result);
			if(result.isSuccess()){
				result.setSuccess(true);
				return result;
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "LoginServiceImpl.checkLoginParam -ERROR");
			result.setSuccess(false);
			result.setResultCode("exception");
		}
		return result;
	}

	@Override
	public String getAuthorizationCode(String pin) {
		String code = RandomStringUtils.random(25, true, true);
		try {
			//有效期是10分钟
//			redisUtils.setex("code-"+code, 600, pin);
			redisUtils.setStringByExpire("code-"+code, pin, 600, TimeUnit.SECONDS);
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"LoginServiceImpl.getAuthorizationCode -ERROR");
		}
		return code;
	}

	@Override
	public Result loginService(String pin, String password, Result result, String ip) {
		result.setSuccess(false);
		try {
			JiceUserInfoPassport userinfo = rpcJdUserService.login(pin, MD5Util.md5Hex(password), ip);
			LogTypeEnum.DEFAULT.error("userinfo.uregtype={},pin={}",userinfo!=null?userinfo.uregtype:null,pin);
			//TODO 有问题，有开启和关闭的类型
			if(userinfo != null && userinfo.uregtype == 120){
				result.setSuccess(true);
				result.setResultCode(ApiConstants.returnValue.OK);
				result.addDefaultModel("pin", pin);
				return result;
			}
		} catch (SoaCallException e) {
			LogTypeEnum.DEFAULT.error( e, "");
			if(e.resultCode == 202 && e.msg.equals("ERROR_USER_PWD_NOT_EFFECT")){
				result.setSuccess(false);
				result.setResultCode("账号或者密码错误！");
				return result;
			}
			if(e.resultCode == 200 && e.msg.equals("ERROR_USER_NOT_EXIST")){
				result.setSuccess(false);
				result.setResultCode("账号或者密码错误！");
				return result;
			}
			
			result.setSuccess(false);
			result.setResultCode("网络超时，请重新登录！");
			return result;
		}
		result.setSuccess(false);
		result.setResultCode("账号或者密码错误！");
		return result;
	}

	//通过authorization_code方式获取access_token
	@Override
	public Result getToken(User user, String code) {
		Result result = new Result();
		result.setSuccess(false);

		if(!("authorization_code".equals(user.getGrant_type()))){
			result.setResultCode(ApiConstants.returnValue.GRAND_TYPE_ERROR);
			return result;
		}
		result = oauth2Service.checkGetTokenParam(user, result);
		if(!result.isSuccess() || !this.checkAuthorizationCode(user, code, result).isSuccess()){
			return result;
		}
		try {
			result.addDefaultModel("token" , oauth2Service.createAccessToken(user, result.get("pin").toString()));
		} catch (Exception e) {
			result.setSuccess(false);
			result.setResultCode("exception");
			LogTypeEnum.DEFAULT.error(e, "oauth2Service.createAccessToken -ERROR");
			return result;
		}
		result.setSuccess(true);
		result.setResultCode(ApiConstants.returnValue.OK);
		return result;
	}
	
	/**
	 * 通过用户账号密码，client_id和client_secret直接获取access_token
	 * @param user
	 * @param username
	 * @param password
	 * @return
	 */
	@Override
	public MapResult getToken(User user, String username, String password, String ip, String sign, String timestamp) {
		MapResult mapResult = new MapResult();
		mapResult.setSuccess(false);
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = sdf.parse(timestamp);
			Date now = new Date();
			if(Math.abs(now.getTime()-date.getTime()) > 1800000){
				mapResult.setResultMessage("时间不正确，误差必须在30分钟以内，您的请求时间为："+sdf.format(date) + "，京东时间为："+sdf.format(now));
				return mapResult;
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "LoginServiceImpl.getToken -ERROR");
			mapResult.setResultMessage("时间格式不正确，参考值：2014-01-01 01:01:01");
			return mapResult;
		}
		if(StringUtils.isBlank(sign)){
			mapResult.setResultMessage("sign不能为空");
			return mapResult;
		}

		if(StringUtils.isBlank(username)){
			mapResult.setResultMessage("用户名不能为空");
			return mapResult;
		}
		if(StringUtils.isBlank(password)){
			mapResult.setResultMessage("密码不能为空");
			return mapResult;
		}
		if(!("access_token".equals(user.getGrant_type()))){
			mapResult.setResultMessage(ApiConstants.returnValue.GRAND_TYPE_ERROR);
			return mapResult;
		}

        if(StringUtils.isBlank(user.getClient_id())){
            mapResult.setResultCode(ApiConstants.returnValue.APPID_ERROR);
            return mapResult;
        }
        //判断前台参数，是否正确
//        User dbUser = oauth2Manager.getUser(user.getClient_id());
//        if(dbUser == null){
//            mapResult.setResultCode(ApiConstants.returnValue.APPID_ERROR);
//            return mapResult;
//        }
        //查client信息，之前是在user表中查找
        ClientInfo clientInfo = null;
        try {
        	clientInfo = clientInfoService.queryClientInfoByClientId(user.getClient_id());
		} catch ( BizUserSoaException e) {
			mapResult.setResultMessage(ApiConstants.returnValue.CLIENT_PIN_ERROR);
			LogTypeEnum.DEFAULT.error(e,"权限验证失败---根据clientId查询clientInfo信息出错!ClientId:{},pin:{}" ,user.getClient_id(), username);
			return mapResult;
		} catch (Exception e) {
			mapResult.setResultMessage(ApiConstants.returnValue.CLIENT_PIN_ERROR);
			LogTypeEnum.DEFAULT.error("权限验证失败---查询用户client出异常,ClientId:{},pin:{}" ,user.getClient_id(), username);	
			return mapResult;
		}
        if(clientInfo == null){
			mapResult.setResultMessage(ApiConstants.returnValue.APPID_ERROR);
			LogTypeEnum.DEFAULT.error("权限验证失败---查询用户client不存在,ClientId:{},pin:{}" , user.getClient_id() , username);	
			return mapResult;
		}
		
		StringBuilder sb = new StringBuilder();
        sb.append(clientInfo.getClientSecret());
		sb.append(timestamp);
		sb.append(user.getClient_id());
		sb.append(username);
		sb.append(password);
		sb.append(user.getGrant_type());
        if(StringUtils.isNotBlank(user.getScope())){
            sb.append(user.getScope());
        }
		sb.append(clientInfo.getClientSecret());
		LogTypeEnum.DEFAULT.error("加密前字符串为：{} 加密后字符串为：{}" , sb.toString() , MD5Util.md5Hex(sb.toString()).toUpperCase());
		if(!MD5Util.md5Hex(sb.toString()).toUpperCase().equals(sign)){
			mapResult.setResultMessage("sign值不正确");
			return mapResult;
		}		
		
		ErpContractInfo erpContractInfo =  null ;
		try {
			erpContractInfo = clientInfoService.queryUserClientIdFlag(user.getClient_id(), username);
		} catch ( BizUserSoaException e) {
			mapResult.setResultMessage(ApiConstants.returnValue.CLIENT_PIN_ERROR);
			LogTypeEnum.DEFAULT.error(e,"权限验证失败---根据clientId查询合同权限信息出错!ClientId:{},pin:{}" ,user.getClient_id(), username);
			return mapResult;
		} catch (Exception e) {
			mapResult.setResultMessage(ApiConstants.returnValue.CLIENT_PIN_ERROR);
			LogTypeEnum.DEFAULT.error("权限验证失败---查询用户权限出异常,ClientId:{},pin:{}",user.getClient_id(),username);	
			return mapResult;
		}
		if(erpContractInfo == null){
			mapResult.setResultMessage(ApiConstants.returnValue.CLIENT_PIN_FALSE);
			LogTypeEnum.DEFAULT.error("权限验证失败---查询用户权限不存在,ClientId:{},pin:{}",user.getClient_id(),username);	
			return mapResult;
		}
		
		//判断用户名密码是否匹配
		try {
			if(Profiles.isTest()){ //测试环境
				mapResult.setResult(oauth2Service.createAccessToken(user, username));
				mapResult.setSuccess(true);
				return mapResult;
			}else{ //线上需要验证
//				String md5passpord1=MD5Util.getMD5Str(password);
//				JiceUserInfoPassport userinfo = rpcJdUserService.login(username, md5passpord1, ip);		
				JiceUserInfoPassport userinfo = rpcJdUserService.login(username, password, ip);	
				//TODO 有问题，有开启和关闭的类型
				if(userinfo != null ){
					//打标签，增加限制前台登陆
					if(userinfo.uregtype != 120 ){
						int result=dubboUserInfoUpdateService.updateRegistType(userinfo.pin, 120);
						LogTypeEnum.DEFAULT.error("username:"+username+'\t'+"用户品pin:"+userinfo.pin+'\t'+"修改用户结果为:"+result);
						if(result!=1){
							mapResult.setResultMessage("网络超时，请重试");
							return mapResult;
						}
					}
					//生成新的access_token
					mapResult.setResult(oauth2Service.createAccessToken(user, username));
					mapResult.setSuccess(true);
					return mapResult;
				}else{
					mapResult.setResultMessage("用户名或者密码错误");
					return mapResult;
				}
			}

		} catch (SoaCallException e) {
			if(e.resultCode == 202 && e.msg.equals("ERROR_USER_PWD_NOT_EFFECT")){
				mapResult.setResultMessage("用户名密码不正确");
				return mapResult;
			}
			if(e.resultCode == 200 && e.msg.equals("ERROR_USER_NOT_EXIST")){
				mapResult.setResultMessage("用户名密码不正确");
				return mapResult;
			}
			LogTypeEnum.DEFAULT.error(e,"LoginServiceImpl.getToken -ERROR");
			mapResult.setResultMessage("网络超时，请重试");
			return mapResult;
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "LoginServiceImpl.getToken -ERROR");
			mapResult.setResultMessage("网络超时，请重试");
			return mapResult;
		}
		
	}
	
	@Override
	public Result refreshToken(String client_id, String client_secret, String refresh_token) {
		Result result = new Result();
		result.setSuccess(false);
		if(StringUtils.isBlank(client_id)){
			result.setResultCode(ApiConstants.returnValue.APPID_ERROR);
			return result;
		}
		if(StringUtils.isBlank( client_secret)){
			result.setResultCode(ApiConstants.returnValue.CLIENT_SECRET_ERROR);
			return result;
		}
		if(StringUtils.isBlank(refresh_token)){
			result.setResultCode("refresh_token不能为空");
			return result;
		}
		
		try{
//			User user = userService.getUserByClientId(client_id);
//			if(user == null){
//				result.setResultCode(ApiConstants.returnValue.APPID_ERROR);
//				return result;
//			}
//			
//			if(!client_secret.equals(user.getClient_secret())){
//				result.setResultCode(ApiConstants.returnValue.CLIENT_SECRET_ERROR);
//				return result;
//			}
			
			//查client信息，之前是在user表中查找
	        ClientInfo clientInfo = null;
	        try {
	        	clientInfo = clientInfoService.queryClientInfoByClientId(client_id);
			} catch ( BizUserSoaException e) {
				result.setResultCode(ApiConstants.returnValue.CLIENT_PIN_ERROR);
				LogTypeEnum.DEFAULT.error(e,"权限验证失败---根据clientId查询clientInfo信息出错!ClientId:{}" ,client_id);
				return result;
			} catch (Exception e) {
				result.setResultCode(ApiConstants.returnValue.CLIENT_PIN_ERROR);
				LogTypeEnum.DEFAULT.error("权限验证失败---查询用户client出异常,ClientId:{}",client_id);	
				return result;
			}
	        if(clientInfo == null){
	        	result.setResultCode(ApiConstants.returnValue.APPID_ERROR);
	        	LogTypeEnum.DEFAULT.error("权限验证失败---查询用户client不存在,ClientId:{}",client_id);	
				return result;
			}
	        if(!client_secret.equals(clientInfo.getClientSecret())){
				result.setResultCode(ApiConstants.returnValue.CLIENT_SECRET_ERROR);
				LogTypeEnum.DEFAULT.error("权限验证失败---client_secret错误!client_secret:{},ClientSecret:{}",client_secret,clientInfo.getClientSecret());	
				return result;
			}
			
	        
			AccessToken at = oauth2Service.getAccessTokenByRefreshToken(refresh_token);
			if(at == null){
				result.setResultCode("refresh_token不正确");
				return result;
			}
			
			ErpContractInfo erpContractInfo =  null ;
			try {
				erpContractInfo = clientInfoService.queryUserClientIdFlag(client_id, at.getPin());
			} catch ( BizUserSoaException e) {
				result.setResultCode(ApiConstants.returnValue.CLIENT_PIN_ERROR);
				LogTypeEnum.DEFAULT.error(e,"权限验证失败---根据clientId查询合同权限信息出错!ClientId:{}" ,client_id);
				return result;
			} catch (Exception e) {
				result.setResultCode(ApiConstants.returnValue.CLIENT_PIN_ERROR);
				LogTypeEnum.DEFAULT.error("权限验证失败---查询用户权限出异常,ClientId:{},pin:{}",client_id,at.getPin());	
				return result;
			}
			if(erpContractInfo == null){
				result.setResultCode(ApiConstants.returnValue.CLIENT_PIN_FALSE);
				LogTypeEnum.DEFAULT.error("权限验证失败---查询用户权限不存在,ClientId:{},pin:{}",client_id,at.getPin());	
				return result;
			}
			
			Map<String, Object> token = oauth2Service.refreshToken(at);
			if(at != null){
				result.setSuccess(true);
				result.setResultCode(ApiConstants.returnValue.OK);
				result.addDefaultModel("token", token);
				return result;
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"LoginServiceImpl.refreshToken -ERROR");
		}
		result.setResultCode("系统异常，请重试");
		return result;
	}
	
	private Result checkAuthorizationCode(User user, String code, Result result){
		String value = "";
		try {
			value = redisUtils.get("code-" + code);
		} catch (Exception e) {
			result.setSuccess(false);
			result.setResultCode("网络异常，请重试");
			return result;
		}
		if(StringUtils.isNotBlank(value)){
			try {
				//TODO 这个key视乎有问题,后续跟踪
				redisUtils.del(code);
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e,"LoginServiceImpl.checkAuthorizationCode -ERROR");
			}
			result.setSuccess(true);
			result.addDefaultModel("pin", value);
			return result;
		}
		result.setSuccess(false);
		result.setResultCode("code值不正确");
		return result;
	}
	
	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

	public void setOauth2Service(Oauth2Service oauth2Service) {
		this.oauth2Service = oauth2Service;
	}

	public void setRpcJdUserService(RpcJdUserServicePrx rpcJdUserService) {
		this.rpcJdUserService = rpcJdUserService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

    public void setOauth2Manager(Oauth2Manager oauth2Manager) {
        this.oauth2Manager = oauth2Manager;
    }

	public void setDubboUserInfoUpdateService(
			DubboUserInfoUpdateService dubboUserInfoUpdateService) {
		this.dubboUserInfoUpdateService = dubboUserInfoUpdateService;
	}

	public void setClientInfoService(ClientInfoService clientInfoService) {
		this.clientInfoService = clientInfoService;
	}
    
}
