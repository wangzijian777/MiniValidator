package com.jd.sns.biz.api.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jd.common.util.StringUtils;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizInvoice;
import com.jd.sns.biz.api.manager.BizInvoiceManager;
import com.jd.sns.biz.api.service.BizInvoiceService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="bizInvoiceService")
public class BizInvoiceServiceImpl implements BizInvoiceService {
//	private static final Logger log = LoggerFactory.getLogger(BizInvoiceServiceImpl.class);
	private BizInvoiceManager bizInvoiceManager;

	@Override
	public String submit(BizInvoice bizInvoice) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BIZ_INVOICE_SERVICEIMPL_SUBMIT,false,true);
		BooleanResult result = new BooleanResult();		
		try{
			result = this.checkParam(bizInvoice, result);
			if(!result.isSuccess()){
				return APIUtils.parseObject2Json(result);
			}
			
			BizInvoice dbBizInvoice = bizInvoiceManager.selectBizInvoiceByMarkId(APIUtils.getClientId(), bizInvoice.getMarkId());
			if(dbBizInvoice != null){
				result.setSuccess(false);
				result.setResult(false);
				result.setResultMessage("请勿重复提交发票");
				return APIUtils.parseObject2Json(result);
			}
			bizInvoice.setYn(1);
			bizInvoice.setState(0);
			bizInvoice.setPin(APIUtils.getPin());
			bizInvoiceManager.insertBizInvoice(bizInvoice);
			result.setSuccess(true);
			result.setResult(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"BizInvoiceServiceImpl.submit 提交发票-ERROR");
			result.setSuccess(true);
			result.setResult(true);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	@Override
	public String select(String markId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BIZ_INVOICE_SERVICEIMPL_SELECT,false,true);
		MapResult result = new MapResult();
		try{
			if(StringUtils.isBlank(markId)){
				result.setSuccess(false);
				result.setResultMessage("markId不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			BizInvoice bizInvoice = bizInvoiceManager.selectBizInvoiceByMarkId(APIUtils.getClientId(), markId);
			if(bizInvoice == null){
				result.setSuccess(false);
				result.setResultMessage("markId2不存在");
				return APIUtils.parseObject2Json(result);
			}
			
			Map map = new HashMap();
			map.put("invoiceId", bizInvoice.getInvoiceId());
			map.put("success", bizInvoice.getState() == 2 ? true:false);//2为完全开完发票，订单表中的 invoice_state字段也变为1了
			result.setResult(map);
			
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"BizInvoiceServiceImpl.select -ERROR");
			result.setSuccess(true);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	public void setBizInvoiceManager(BizInvoiceManager bizInvoiceManager) {
		this.bizInvoiceManager = bizInvoiceManager;
	}

	private BooleanResult checkParam(BizInvoice bizInvoice, BooleanResult result){
		if(StringUtils.isBlank(bizInvoice.getJdOrder())){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("jdOrder不能为空");
			return result;
		}
		if(bizInvoice.getJdOrder().length() > 10000){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("jdOrder长度过长，请控制在10000字以内");
			return result;
		}
		
		if(StringUtils.isBlank(bizInvoice.getMarkId())){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("markId不能为空");
			return result;
		}
		if(bizInvoice.getMarkId().length() > 100){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("markId长度过长，请控制在100字以内");
			return result;
		}
		
		if(bizInvoice.getInvoiceType() != 1 && bizInvoice.getInvoiceType() != 2 && bizInvoice.getInvoiceType() != 4){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("invoiceType不正确，必须为1、2、4(1代表普通2代表增值税、3代表营业税)");
			return result;
		}
		
		if(bizInvoice.getInvoiceOrg() != 544 && bizInvoice.getInvoiceOrg() != 6 && bizInvoice.getInvoiceOrg() != 3
				&& bizInvoice.getInvoiceOrg() != 10 && bizInvoice.getInvoiceOrg() != 4 && bizInvoice.getInvoiceOrg() != 600 && bizInvoice.getInvoiceOrg() != 611){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("invoiceOrg不正确，开票机构  544(京东信息)  6(总公司) 3(上海)   10(广州)  4(成都)   600(武汉) 611(沈阳)");
			return result;
		}
		
		if(StringUtils.isBlank(bizInvoice.getBizInvoiceContent()) || (!"明细".equals(bizInvoice.getBizInvoiceContent()) && !"办公用品".equals(bizInvoice.getBizInvoiceContent())
				&& !"电脑配件".equals(bizInvoice.getBizInvoiceContent()) && !"耗材".equals(bizInvoice.getBizInvoiceContent()))){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("bizInvoiceContent不正确， 开票内容：    明细  办公用品  电脑配件  耗材  ");
			return result;
		}
		if(StringUtils.isBlank(bizInvoice.getTitle())){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("title不能为空");
			return result;
		}
		
		if(bizInvoice.getTitle().length() > 100){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("title过长，不能大于100字");
			return result;
		}
		
		if(bizInvoice.getInvoiceDate() == null){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("invoiceDate格式不正确");
			return result;
		}
		
		if(bizInvoice.getRepaymentDate() == null){
			result.setResult(false);
			result.setSuccess(false);
			result.setResultMessage("repaymentDate格式不正确");
			return result;
		}
		
		result.setSuccess(true);
		return result;
	}
}
