package com.jd.sns.biz.api.domain;


public class InvoiceInfo implements AbstractInvoiceInfo {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//收票人
	private String invoiceName;
	//电话号码
	private String invoicePhone;
	//省
	private Integer invoiceProvice;
	//市
	private Integer invoiceCity;
	//县
	private Integer invoiceCounty;	
	//镇
	private Integer invoiceTown ;
	//详细地址
	private String invoiceAddress;
	public String getInvoiceName() {
		return invoiceName;
	}
	public void setInvoiceName(String invoiceName) {
		this.invoiceName = invoiceName;
	}
	public String getInvoicePhone() {
		return invoicePhone;
	}
	public void setInvoicePhone(String invoicePhone) {
		this.invoicePhone = invoicePhone;
	}
	public Integer getInvoiceProvice() {
		return invoiceProvice;
	}
	public void setInvoiceProvice(Integer invoiceProvice) {
		this.invoiceProvice = invoiceProvice;
	}
	public Integer getInvoiceCity() {
		return invoiceCity;
	}
	public void setInvoiceCity(Integer invoiceCity) {
		this.invoiceCity = invoiceCity;
	}
	public Integer getInvoiceCounty() {
		return invoiceCounty;
	}
	public void setInvoiceCounty(Integer invoiceCounty) {
		this.invoiceCounty = invoiceCounty;
	}
	public Integer getInvoiceTown() {
		return invoiceTown;
	}
	public void setInvoiceTown(Integer invoiceTown) {
		this.invoiceTown = invoiceTown;
	}
	public String getInvoiceAddress() {
		return invoiceAddress;
	}
	public void setInvoiceAddress(String invoiceAddress) {
		this.invoiceAddress = invoiceAddress;
	}
	
	
	
	

	
	
	
	
}
