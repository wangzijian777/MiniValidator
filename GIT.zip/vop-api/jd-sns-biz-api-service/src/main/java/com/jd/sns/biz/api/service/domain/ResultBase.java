package com.jd.sns.biz.api.service.domain;

public class ResultBase {
	/**
	 * 返回是否成功
	 */
	private boolean success;
	/**
	 * 中文返回
	 */
	private String resultMessage = "";
	/**
	 * 返回码
	 */
	private String resultCode;
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getResultMessage() {
		return resultMessage;
	}
	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	
}
