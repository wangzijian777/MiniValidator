package com.jd.sns.biz.api.service.domain;

import java.util.Map;

import com.jd.sns.biz.api.service.domain.ResultBase;

public class AreaResult extends ResultBase{
	private Map<String, Integer> result;

	public Map<String, Integer> getResult() {
		return result;
	}

	public void setResult(Map<String, Integer> result) {
		this.result = result;
	}

}
