package com.jd.sns.biz.api.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jd.catagory.pbim.pbia.dubbo.service.ProductService;
import com.jd.common.util.StringUtils;
import com.jd.ka.user.soa.service.clientInfo.ClientInfoService;
import com.jd.ka.price.soa.sdk.service.GetJdPriceService;
import com.jd.ka.price.soa.sdk.service.GetRTPriceService;
import com.jd.ka.price.soa.sdk.service.GetRedisPriceService;
import com.jd.ka.price.soa.sdk.vo.request.QRTPriceReqVO;
import com.jd.ka.price.soa.sdk.vo.request.QRTPricesReqVO;
import com.jd.ka.price.soa.sdk.vo.request.QRedisPricesReqVO;
import com.jd.ka.price.soa.sdk.vo.response.KaPriceResult;
import com.jd.ka.price.soa.sdk.vo.response.QRTPriceRespVO;
import com.jd.ka.price.soa.sdk.vo.response.QRTPricesRespVO;
import com.jd.ka.price.soa.sdk.vo.response.QRedisPricesRespVO;
import com.jd.ka.price.soa.sdk.vo.response.RTPriceVO;
import com.jd.ka.price.soa.sdk.vo.response.RedisPriceVO;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.JincaiCredit;
import com.jd.sns.biz.api.enumtype.ErrorCodeEnum;
import com.jd.sns.biz.api.manager.BizPoolSkuManager;
import com.jd.sns.biz.api.service.JdPriceService;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.service.domain.ObjectResult;
import com.jd.sns.biz.api.service.domain.StringResult;
import com.jd.sns.biz.api.service.pay.BizPayService;
import com.jd.sns.biz.api.service.utils.OrderConvertUtils;
import com.jd.sns.biz.pay.enumtype.PayTypeEnum;
import com.jd.sns.biz.pay.exception.BizPayException;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


/**
 * 价格服务
 *
 * @author yujianming
 */
@Service(value = "jdPriceService")
public class JdPriceServiceImpl implements JdPriceService {
    private BizPoolSkuManager bizPoolSkuManager;
    private BizPayService bizPayService;
    private com.jd.catagory.pbim.pbia.dubbo.service.ProductService jdProductService;
    // update by wangzijian start, update the price interface to price service
    private GetRedisPriceService getRedisPriceService;
    private GetRTPriceService getRTPriceService;
    
    // update by wangzijian end
    
    //yz 添加京东价
    private GetJdPriceService getJdPriceService;

    private ClientInfoService clientInfoService;
    
    /**
     * 批量协议价格查询（包含商品池商品）
     */
    @Override
    public String batch(String skuids, String containsTax) {
    	CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.BATCH,false,true);
        ListResult result = new ListResult();
        result.setSuccess(false);

        if (StringUtils.isBlank(skuids)) {
            result.setResultMessage("参数不能为空");
            return APIUtils.parseObject2Json(result);
        }

        String[] arr = skuids.split(",");
        if (arr.length > 100) {
            result.setResultMessage("sku数量过多，目前最大支持100个商品");
            return APIUtils.parseObject2Json(result);
        }
     
        CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.STRIKEPRICEREDISSERVICE_GETSTRIKEPRICES,false,true);
        try {
        	Set<Long> skuIdSet=OrderConvertUtils.skuIdsToSet(arr);
        	QRedisPricesReqVO reqVo = new QRedisPricesReqVO();
            reqVo.setPin(APIUtils.getPin());
            reqVo.setSkuSet(skuIdSet);
        	KaPriceResult<QRedisPricesRespVO> kaPriceResult = getRedisPriceService.getSellPrices(reqVo);
        	LogTypeEnum.DEFAULT.error("价格查询调用价格服务接口:{}", APIUtils.parseObject2Json(kaPriceResult));
        	if(!kaPriceResult.isSuccess()){
        		LogTypeEnum.DEFAULT.error("获取价格接口异常	skuIds={}", skuids);
                result.setResultMessage("从价格服务获取价格异常");
        		return APIUtils.parseObject2Json(result);
        	}
        	
        	List<RedisPriceVO> redisPriceVOList = kaPriceResult.getModel().getPriceList();
        	
            Map<Long, BigDecimal> taxInfosMap = null;
            if("1".equals(containsTax)){
                taxInfosMap = this.getTaxInfos(arr);
            }
            
            List<Long> illegalSkus = bizPoolSkuManager.checkCanBySkuIds(skuIdSet, APIUtils.getClientId());
            Set<Long> iSkuSets = new HashSet<Long>(illegalSkus);
		    
            if(CollectionUtils.isNotEmpty(redisPriceVOList)){
            	List showList = new ArrayList();
                for (RedisPriceVO redisPriceVO : redisPriceVOList) {
                    long skuId = redisPriceVO.getSkuId();
                    if (!iSkuSets.contains(skuId)) { //不包含
                        BigDecimal bizPrice=redisPriceVO.getPrice();
                        // add by wangzijian 修改价格获取为调用价格服务，为了保证尽量不影响原来的逻辑，
                        Profiler.registerInfoEnd(callerInfo);
                        if (bizPrice == null || bizPrice.doubleValue() < 0 || redisPriceVO.getJdPrice().doubleValue() < 0) {
                            result.setResultMessage(result.getResultMessage() + skuId + "没有协议价，");
                            continue;
                        }
                        bizPrice = bizPrice.setScale(2, BigDecimal.ROUND_UP); //只保留2位小数
                        
                        Map<String, Object> priceMap = new HashMap<String, Object>();
                        // add by wangzijian end
                        priceMap.put("skuId", skuId);
                        priceMap.put("price", bizPrice);
                        priceMap.put("jdPrice", redisPriceVO.getJdPrice());
                        if(taxInfosMap != null){
                            BigDecimal tax = taxInfosMap.get(skuId);//税率
                            if (tax != null) {
                                BigDecimal taxPrice = APIUtils.calculateTaxPrice(bizPrice, tax);
                                priceMap.put("tax", tax);//税率
                                priceMap.put("taxPrice", taxPrice);//税额
                                priceMap.put("nakedPrice", bizPrice.subtract(taxPrice));//裸价
                            }
                        }

                        showList.add(priceMap);
                    } else {
                        result.setResultMessage(result.getResultMessage() + skuId + "不在您的商品池中，");
                    }
                }
                result.setResult(showList);
                result.setSuccess(true);
                result.setResultMessage(result.getResultMessage() + "价格为null或者小于0时，为暂无报价");
            } else {
                result.setResultMessage("未找到该商品价格，请检查参数是否正确");
            }
            Profiler.registerInfoEnd(callerInfo2);
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e,"获取价格接口异常	skuIds={}", skuids);
            result.setResultMessage("服务异常，请检查参数后重试");
            Profiler.functionError(callerInfo2);
        }

        return APIUtils.parseObject2Json(result);
    }

	private Map<Long, BigDecimal> getTaxInfos(String[] skuIds) {
        Set<Long> skuIdSet = new HashSet<Long>();
        for (int i = 0; i < skuIds.length; i++) {
            skuIdSet.add(Long.parseLong(skuIds[i].replace("J_", "")));
        }

        Set<String> base = new HashSet<String>();
        base.add("taxInfo");
        CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDPRODUCTSERVICE_QUERYPRODUCTBASE, false, true);
        Map<Long, Map<String, String>> map=null;
		try {
			map = jdProductService.queryProductBase(skuIdSet, base);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"jdProductService.queryProductBase -ERROR");
			throw new RuntimeException(e);
		}
        Profiler.registerInfoEnd(callerInfo);
        Map<Long, BigDecimal> resultMap = new HashMap<Long, BigDecimal>();

        for (int i = 0; i < skuIds.length; i++) {
            Long skuId = Long.parseLong(skuIds[i].replace("J_", ""));
            Map<String, String> skuMap = map.get(skuId);
            if(skuMap != null){
                String taxInfo = skuMap.get("taxInfo");
                if (StringUtils.isNotBlank(taxInfo)) {
                    String[] a = taxInfo.split(",");
                    if (a != null && a.length == 3) {
                        String outputVAT = a[1];
                        String[] outputVATArr = outputVAT.split(":");
                        if (outputVATArr != null && outputVATArr.length == 2) {
                        	// 13M是图书13%免税规则，因此税率为0
		                	if("13M".equals(outputVATArr[1])){
		                		resultMap.put(skuId, new BigDecimal(0));
		                	}else{
		                		resultMap.put(skuId, new BigDecimal(outputVATArr[1]));
		                	}
                            
                        }
                    }
                }
            }
        }
        return resultMap;
    }

    /**
     * 批量京东价查询，包含商品池商品
     *
     * @param skuids
     * @return
     */
    @Override
    public String jdPriceBatchFromPool(String skuids) {
    	CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JD_PRICE_BATCH_FROM_POOL,false,true);
        ListResult result = new ListResult();
        result.setSuccess(false);

        if (StringUtils.isBlank(skuids)) {
            result.setResultMessage("参数不能为空");
            return APIUtils.parseObject2Json(result);
        }

        String[] arr = skuids.split(",");
        if (arr.length > 100) {
            result.setResultMessage("sku数量过多，目前最大支持100个商品");
            return APIUtils.parseObject2Json(result);
        }        
        
        
        try {
            Set<Long> skuIdSet=OrderConvertUtils.skuIdsToSet(arr);
            QRTPricesReqVO  reqVo = new QRTPricesReqVO();
            reqVo.setPin(APIUtils.getPin());
            reqVo.setSkuSet(skuIdSet);
            KaPriceResult<QRTPricesRespVO> kaPriceResult = getJdPriceService.getJdPrices(reqVo);
            LogTypeEnum.DEFAULT.error("价格查询调用价格服务接口:{}", APIUtils.parseObject2Json(kaPriceResult));
            List<RTPriceVO> redisPriceVOList = kaPriceResult.getModel().getPriceList();            

            List<Long> illegalSkus = bizPoolSkuManager.checkCanBySkuIds(skuIdSet, APIUtils.getClientId());
            Set<Long> iSkuSets = new HashSet<Long>(illegalSkus);
		    
            if (redisPriceVOList != null && redisPriceVOList.size() > 0) {
                List<Map<String, Object>> showList = new ArrayList<Map<String, Object>>();
                for (RTPriceVO priceVO:redisPriceVOList) {
//                    if (priceVO.getPrice().compareTo(BigDecimal.valueOf(-1))==0) {
//                        continue;
//                    }
                    long skuId= priceVO.getSkuId();
                    if (!iSkuSets.contains(skuId) ) {//不包含
                        BigDecimal price = priceVO.getPrice();
                        Map<String, Object> priceMap = new HashMap<String, Object>();
                        priceMap.put("skuId", skuId);
                        priceMap.put("jdPrice",price);
                        showList.add(priceMap);
                    } else {
                        result.setResultMessage(result.getResultMessage() + skuId + "不在您的商品池中，");
                    }
                }
                result.setResult(showList);
                result.setSuccess(true);
                result.setResultMessage(result.getResultMessage() + "价格为null或者小于0时，为暂无报价");
            } else {
                result.setResultMessage("未找到该商品价格，请检查参数是否正确");
            }
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e, "获取价格接口异常	skuIds={}" , skuids);
            result.setResultMessage("服务异常，请检查参数后重试");
            Profiler.functionError(callerInfo);
        }finally{
        	Profiler.registerInfoEnd(callerInfo);
        }
        return APIUtils.parseObject2Json(result);
    }

    
    
    /**
     * 通过skuId获取协议价, 获取的协议价为计算过费率之后的价格
     */
    @Override
    public BigDecimal getPriceBySkuId(long skuId,List<QRTPriceRespVO> respVos) {
    	CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.GET_PRICE_BY_SKU_ID,false,true);
    	BigDecimal bizPrice=null;
    	CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.STRIKEPRICESERVICE_GETSTRIKEPRICE,false,true);
    	try {
			QRTPriceReqVO repVo = new QRTPriceReqVO();
			repVo.setPin(APIUtils.getPin());
			repVo.setSkuId(skuId);
			//放入价格快照
			QRTPriceRespVO model = getRTPriceService.getSellPrice(repVo).getModel();
			if(respVos != null){
				respVos.add(model);
			}
			if(model == null || model.getPrice().doubleValue() < 0){
				return null;
			}
			bizPrice = model.getPrice();
			LogTypeEnum.DEFAULT.info("价格服务:通过价格服务获得的价格为：{}",bizPrice);
			// add by wangzijian end
			if(bizPrice != null){
				bizPrice = bizPrice.setScale(2, BigDecimal.ROUND_UP); //只保留2位小数
			}
			Profiler.registerInfoEnd(callerInfo);
		} catch (Exception e) {
			Profiler.functionError(callerInfo2);
			LogTypeEnum.DEFAULT.error(e,"JdPriceServiceImpl.getPriceBySkuId -ERROR");
			throw new RuntimeException(e);
		}finally{
			 Profiler.registerInfoEnd(callerInfo2);
		}        
        return bizPrice;
    }

    @Override
    public BigDecimal getJdPriceBySkuId(long skuId,List<QRTPriceRespVO> respVos) {
        BigDecimal bizPrice=null;
    	CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_JDPRICE_BY_SKU_ID,false,true);
        try {
            QRTPriceReqVO repVo = new QRTPriceReqVO();
            repVo.setPin(APIUtils.getPin());
            repVo.setSkuId(skuId);
            //放入价格快照
            QRTPriceRespVO model = getJdPriceService.getJdPrice(repVo).getModel();
            if(respVos != null){
                respVos.add(model);
            }
            if(model == null || model.getPrice().doubleValue() < 0){
                return null;
            }
            bizPrice = model.getPrice();
            
            LogTypeEnum.DEFAULT.info("价格服务:通过价格服务获得的价格为：{}",bizPrice);
            if(bizPrice != null){
                bizPrice = bizPrice.setScale(2, BigDecimal.ROUND_UP); //只保留2位小数
            }
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"JdPriceServiceImpl..getPriceBySkuId 价格服务器获取京东价失败 -ERROR");
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
        return bizPrice;
    }

    @Override
    public String selectBalance(String pin, int paymentType) {
    	CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.SELECT_BALANCE,false,true);
        StringResult result = new StringResult();
        result.setSuccess(true);
        try {
        	BigDecimal balance = bizPayService.getBalance(pin, paymentType);
            if (balance == null) {
                result.setResult("0");
                return APIUtils.parseObject2Json(result);
            }
            result.setResult(balance.toString());
            return APIUtils.parseObject2Json(result);
        } catch (BizPayException e){
        	LogTypeEnum.DEFAULT.error(e, "获取余额业务异常。");
            result.setSuccess(false);
            result.setResultMessage(e.getMessage());
            result.setResult("");
            return APIUtils.parseObject2Json(result);
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e, "获取余额异常。");
            result.setSuccess(false);
            result.setResultMessage("服务异常，请稍后重试");
            result.setResult("");
            Profiler.functionError(callerInfo);
            return APIUtils.parseObject2Json(result);
        }finally{
        	Profiler.registerInfoEnd(callerInfo);
        }
    }
    
    public String getJincaiCredit(String pin){
    	CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_JINCAI_CREDIT,false,true);
    	ObjectResult result = new ObjectResult();
        result.setSuccess(true);
        try {
        	JincaiCredit jincaiCredit = bizPayService.getJincaiCredit(pin);
            result.setResult(jincaiCredit);
            return APIUtils.parseObject2Json(result);
        } catch (BizPayException e){
        	LogTypeEnum.DEFAULT.error(e, "获取金彩额度业务异常。");
            result.setSuccess(false);
            result.setResultMessage(e.getReturnMessage());
            result.setResult("");
            return APIUtils.parseObject2Json(result);
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e, "代码执行异常-CodeExcepiton 获取金彩额度异常。");
            result.setSuccess(false);
            result.setResultCode(ErrorCodeEnum.AUTHORITY_JINCAI.getType());
            result.setResultMessage("服务异常，请稍后重试");
            result.setResult("");
            Profiler.functionError(callerInfo);
            return APIUtils.parseObject2Json(result);
        }finally{
        	Profiler.registerInfoEnd(callerInfo);
        }
    }

    private Integer getServiceRate(String clientId){
    	Integer serviceRate = null;
    	CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.QUERY_SERVICE_RATE,false,true);
		try {
			serviceRate = clientInfoService.queryServiceRateByClientId(clientId);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"获取服务费率异常	clientId=" + clientId);
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return serviceRate;
    }
    
    public static void main(String[] args) {
//		ObjectMapper om = new ObjectMapper();
//		String result = HttpUtils.httpGetData("http://p.3.cn/prices/gets", "type=1&skuid=J_"+4016750+"&area="+1, null);	
//		List list  = APIUtils.parseJson2Object(result, List.class);
//		for(int i = 0 ; i < list.size() ; i ++){
//			Map<String, Object> map = (Map)list.get(i);
//			System.out.println(map);
//		}

        JdPriceServiceImpl s = new JdPriceServiceImpl();
//		System.out.println(s.batch("J_"+4016750+",J_"+4016750, ""));
        System.out.println(new BigDecimal("-1").equals(BigDecimal.valueOf(-1.0)));
        System.out.println(new BigDecimal("-1").compareTo(BigDecimal.valueOf(-1.0)));
    }

    public void setBizPoolSkuManager(BizPoolSkuManager bizPoolSkuManager) {
        this.bizPoolSkuManager = bizPoolSkuManager;
    }

    public void setJdProductService(ProductService jdProductService) {
        this.jdProductService = jdProductService;
    }

	public void setClientInfoService(ClientInfoService clientInfoService) {
		this.clientInfoService = clientInfoService;
	}
    
	public void setGetRedisPriceService(GetRedisPriceService getRedisPriceService) {
		this.getRedisPriceService = getRedisPriceService;
	}

	public void setGetRTPriceService(GetRTPriceService getRTPriceService) {
		this.getRTPriceService = getRTPriceService;
	}




    public void setGetJdPriceService(GetJdPriceService getJdPriceService) {
        this.getJdPriceService = getJdPriceService;
    }

	public void setBizPayService(BizPayService bizPayService) {
		this.bizPayService = bizPayService;
	}
	
	
	
	
}
