package com.jd.sns.biz.api.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.jd.common.util.StringUtils;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.CheckOrderConstants;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.BizOrderFlow;
import com.jd.sns.biz.api.domain.CheckOrderPage;
import com.jd.sns.biz.api.entity.service.BizOrderReconciliationService;
import com.jd.sns.biz.api.manager.BizOrderFlowManager;
import com.jd.sns.biz.api.manager.BizOrderManager;
import com.jd.sns.biz.api.order.exception.BizOrderServiceException;
import com.jd.sns.biz.api.service.CheckOrderService;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.common.enumtype.SourceType;
import com.jd.sns.biz.order.domain.BizOrderQuery;
import com.jd.sns.biz.order.domain.Order;
import com.jd.sns.biz.order.domain.Pagination;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="checkOrderService")
public class CheckOrderServiceImpl implements CheckOrderService {
//	private static final Logger log = LoggerFactory.getLogger(CheckOrderServiceImpl.class);
	
	private BizOrderFlowManager bizOrderFlowManager;
	private BizOrderManager bizOrderManager;
	private BizOrderReconciliationService bizOrderReconciliationService;
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final int count = 20;
	
	@Override
	public String checkOrderByType(String date, String page, int type) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_ORDER_BY_TYPE,false,true);
		MapResult result = new MapResult();
		result.setSuccess(false);
		try{
			//传入日期处理
			if(StringUtils.isBlank(date)){
				result.setSuccess(false);
				result.setResultMessage("date不能为空");
				return APIUtils.parseObject2Json(result);
			}
			Date searchDate = null;
			try {
				searchDate = sdf.parse(date);
				Calendar c = Calendar.getInstance();
				c.setTime(new Date());
				Date now = sdf.parse(c.get(Calendar.YEAR)+"-"+(c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH));
				
				if(searchDate.after(now)){
					result.setSuccess(false);
					result.setResultMessage("日期错误，必须在当前日期之前");
					Profiler.registerInfoEnd(callerInfo);
					return APIUtils.parseObject2Json(result);
				}
				
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e,"date格式：{}",date);
				result.setSuccess(false);
				result.setResultMessage("date格式不正确");
				Profiler.registerInfoEnd(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			//传入页数处理
			int curPage;
			if(StringUtils.isBlank(page)){
				curPage = 1;
			}else {
				try{
					curPage = Integer.parseInt(page);
				}catch (Exception e) {
					LogTypeEnum.DEFAULT.error("page="+page, e);
					result.setSuccess(false);
					result.setResultMessage("page格式不正确");
					return APIUtils.parseObject2Json(result);
				}
			}
			if(curPage<=0){
				curPage = 1;
			}
			
			String clientId = APIUtils.getClientId(); 
			BizOrderQuery bizOrderQuery = new BizOrderQuery();
			bizOrderQuery.setStartDate(searchDate);
			bizOrderQuery.setEndDate(new Date(searchDate.getTime()+(60*60*24*1000)));
			bizOrderQuery.setPageSize(count);
			bizOrderQuery.setPage(curPage);
			bizOrderQuery.setSourceType(SourceType.ORDER_VOP.getType());
			bizOrderQuery.setClientId(clientId);
			
			Pagination<Order> list = null;
			try {
				if(type == CheckOrderConstants.ORDER_CHECK_NEW){
					list = bizOrderReconciliationService.checkNewOrder(bizOrderQuery);
				}else if(type == CheckOrderConstants.ORDER_CHECK_DLOK){
					list = bizOrderReconciliationService.checkDlokOrder(bizOrderQuery);
				}else if(type == CheckOrderConstants.ORDER_CHECK_REFUSE){
					list = bizOrderReconciliationService.checkRefuseOrder(bizOrderQuery);
				}
			}catch (BizOrderServiceException e) {
				LogTypeEnum.DEFAULT.error(e,"");
				result.setResultMessage(e.getReturnMessage());
				Profiler.functionError(callerInfo);
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e,"");
				result.setResultMessage("服务异常，请稍后重试");
				Profiler.functionError(callerInfo);
			}
			
			if(list == null || CollectionUtils.isEmpty(list.getDataList()) ){
				result.setSuccess(false);
				result.setResultMessage("没有数据");
				Profiler.registerInfoEnd(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			
			Map resultMap = new HashMap();
			List resultList = new ArrayList();
			for(int i=0;i<list.getDataList().size();i++){
				Map one = new HashMap();
				Order bizOrder = list.getDataList().get(i);
				one.put("jdOrderId", bizOrder.getJdOrderId());
				one.put("state", bizOrder.getState());
				one.put("hangUpState", bizOrder.getHangUpState());
				one.put("invoiceState", bizOrder.getInvoiceState());
				one.put("orderPrice", bizOrder.getOrderPrice());
				one.put("time", sdf2.format(bizOrder.getCreated()));
				resultList.add(one);
			}
			resultMap.put("orders", resultList);
			resultMap.put("total", list.getTotalItem());
			resultMap.put("totalPage", list.getPageCount());
			resultMap.put("curPage", curPage);
			result.setResult(resultMap);
			result.setSuccess(true);
			Profiler.registerInfoEnd(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}
		
		return APIUtils.parseObject2Json(result);
	}

	@Override
	public String checkHangUpOrder() {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_HANG_UP_ORDER,false,true);
		ListResult result = new ListResult();
		
		try{
			List<BizOrder> bizOrderList = bizOrderManager.getBizOrderByHangUpState(APIUtils.getClientId());
			if(bizOrderList == null || bizOrderList.size() == 0){
				result.setSuccess(false);
				result.setResultMessage("没有挂起的订单");
				return APIUtils.parseObject2Json(result);
			}
			List resultList = new ArrayList();
			for(int i=0 ; i < bizOrderList.size() ; i++){
				BizOrder bizOrder = bizOrderList.get(i);
				BizOrderFlow bof = bizOrderFlowManager.getBizOrderFlowByOrderId(APIUtils.getClientId(), bizOrder.getJdOrderId());
				if(bof == null){
					LogTypeEnum.DEFAULT.error("发现一笔订单挂起状态为1，但是挂起表中无记录的数据	订单号：{}",bizOrder.getJdOrderId());
					continue;
				}
				Map map = new HashMap();
				map.put("jdOrderId", bizOrder.getJdOrderId());
				map.put("state", bof.getStatus());
				resultList.add(map);
			}
			if(resultList.size() == 0){
				result.setSuccess(false);
				result.setResultMessage("没有挂起的订单");
				return APIUtils.parseObject2Json(result);
			}
			result.setSuccess(true);
			result.setResult(resultList);
		}catch (Exception e) {
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试");
			LogTypeEnum.DEFAULT.error(e,"获取挂起数据异常");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}		
		return APIUtils.parseObject2Json(result);
	}
	
	@Override
	public String checkOrderByState(String date, String page, int state, int type) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_ORDER_BY_STATE,false,true);
		MapResult result = new MapResult();
		result.setSuccess(false);
		try{
			if(StringUtils.isBlank(date)){
				result.setSuccess(false);
				result.setResultMessage("date不能为空");
				return APIUtils.parseObject2Json(result);
			}
			Date searchDate = null;
			try {
				searchDate = sdf.parse(date);
				Calendar c = Calendar.getInstance();
				c.setTime(new Date());
				Date now = sdf.parse(c.get(Calendar.YEAR)+"-"+(c.get(Calendar.MONTH)+1) + "-" + c.get(Calendar.DAY_OF_MONTH));
				
				if(searchDate.after(now)){
					result.setSuccess(false);
					result.setResultMessage("日期错误，必须在当前日期之前");
					return APIUtils.parseObject2Json(result);
				}
				
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e,"date格式：{}",date);
				result.setSuccess(false);
				result.setResultMessage("date格式不正确");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			
			int count = 20;
			
			CheckOrderPage checkOrderPage = new CheckOrderPage();
			checkOrderPage.setStartDate(searchDate);
			checkOrderPage.setEndDate(new Date(searchDate.getTime()+(60*60*24*1000)));
			checkOrderPage.setState(state);
			checkOrderPage.setCount(count);
			checkOrderPage.setClientId(APIUtils.getClientId());
			int total = 0;
			if(type == 1){//获取某天所有新创建订单的总数
				total = this.bizOrderManager.getTotalNumByCreateDateAndState(checkOrderPage);
			}else if(type == 2){//获取某天所有妥投或者拒收的总数
				total = this.bizOrderManager.getTotalNumByTrackDateAndState(checkOrderPage);
			}else{//获取某日前前所有未开发票信息的总数
				total = this.bizOrderManager.getTotalNumByInvoiceState(checkOrderPage);
			}
			
			int totalPage = total/count + 1;
			int curPage = 0;
			if(StringUtils.isBlank(page)){
				curPage = 1;
			}
			if(StringUtils.isNotBlank(page)){
				try{
					curPage = Integer.parseInt(page);
				}catch (Exception e) {
					LogTypeEnum.DEFAULT.error(e,"page={}",page);
					result.setSuccess(false);
					result.setResultMessage("page格式不正确");
					Profiler.functionError(callerInfo);
					return APIUtils.parseObject2Json(result);
				}
			}
			if(curPage <= 0){
				curPage = 1;
			}
			if(curPage > totalPage){
				curPage = totalPage;
			}
			
			checkOrderPage.setStartNum((curPage-1) * count);
			
			List<BizOrder> list = null;
			if(type == 1){
				list = this.bizOrderManager.getBizOrderByCreateDateAndPageAndState(checkOrderPage);
			}else if(type==2){
				list = this.bizOrderManager.getBizOrderByTrackDateAndPageAndState(checkOrderPage);
			}else{
				list = this.bizOrderManager.getBizOrderByInvoiceState(checkOrderPage);
			}
			
			if(list == null || list.size() == 0){
				result.setSuccess(false);
				result.setResultMessage("没有数据");
				return APIUtils.parseObject2Json(result);
			}
			Map resultMap = new HashMap();
			List resultList = new ArrayList();
			for(int i=0;i<list.size();i++){
				Map one = new HashMap();
				BizOrder bizOrder = list.get(i);
				one.put("jdOrderId", bizOrder.getJdOrderId());
				one.put("state", bizOrder.getState());
				one.put("hangUpState", bizOrder.getHangUpState());
				one.put("invoiceState", bizOrder.getInvoiceState());
				one.put("orderPrice", bizOrder.getOrderPrice());
				one.put("time", sdf2.format(bizOrder.getCreated()));
				resultList.add(one);
			}
			resultMap.put("orders", resultList);
			resultMap.put("total", total);
			resultMap.put("totalPage", totalPage);
			resultMap.put("curPage", curPage);
			result.setResult(resultMap);
			result.setSuccess(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"CheckOrderServiceImpl.checkOrderByState -ERROR");
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}
	
	public void setBizOrderFlowManager(BizOrderFlowManager bizOrderFlowManager) {
		this.bizOrderFlowManager = bizOrderFlowManager;
	}

	public void setBizOrderManager(BizOrderManager bizOrderManager) {
		this.bizOrderManager = bizOrderManager;
	}

	public void setBizOrderReconciliationService(
			BizOrderReconciliationService bizOrderReconciliationService) {
		this.bizOrderReconciliationService = bizOrderReconciliationService;
	}

}
