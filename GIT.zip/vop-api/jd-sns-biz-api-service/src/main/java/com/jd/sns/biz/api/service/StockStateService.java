package com.jd.sns.biz.api.service;

import com.jd.sns.biz.api.service.domain.MapResult;

public interface StockStateService {
	public String getStockByIds(String sku,String area);
	
	public MapResult checkSkuStock(String skuString, String area, MapResult result);
	
	/**
	 * 根据sku和商品数量信息查询库存状态
	 * @param skuNums eg:[{skuId:569172,num:101},{skuId:102194,num:5}]
	 * @param area eg:1_0_0
	 * @return
	 */
	public String getNewStockByIds(String skuNums, String area, String appId);
}
