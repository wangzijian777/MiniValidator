package com.jd.sns.biz.api.service.impl;

import org.springframework.stereotype.Service;

import com.jd.common.util.StringUtils;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizOrderDifference;
import com.jd.sns.biz.api.manager.BizOrderDifferenceManager;
import com.jd.sns.biz.api.manager.BizOrderManager;
import com.jd.sns.biz.api.service.BizOrderDifferenceService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="bizOrderDifferenceService")
public class BizOrderDifferenceServiceImpl implements BizOrderDifferenceService {
//	private static final Logger log = LoggerFactory.getLogger(BizOrderDifferenceServiceImpl.class);
	
	private BizOrderDifferenceManager bizOrderDifferenceManager;
	private BizOrderManager bizOrderManager;
	@Override
	public String insertBizOrderDifference(String jdOrderId, String content) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.INSERT_BIZORDER_DIFFERENCE,false,true);
		BooleanResult result = new BooleanResult();
		result.setSuccess(false);
		result.setResult(false);
		try{
			if(StringUtils.isBlank(content)){
				result.setResultMessage("content不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			if(content.length() > 1000){
				result.setResultMessage("content字数过长，不能超过1000字");
				return APIUtils.parseObject2Json(result);
			}
			
			if(StringUtils.isBlank(jdOrderId)){
				result.setResultMessage("jdOrderId不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			long orderId = 0l;
			try{
				orderId = Long.parseLong(jdOrderId);
			}catch (Exception e) {
				result.setResultMessage("jdOrderId格式不正确");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			
			if(bizOrderManager.checkBizOrderExistByClientIdAndOrderId(APIUtils.getClientId(), orderId) <= 0){
				result.setResultMessage("订单不存在");
				return APIUtils.parseObject2Json(result);
			}
			
			BizOrderDifference dif = new BizOrderDifference();
			dif.setContent(content);
			dif.setJdOrderId(orderId);
			dif.setClientId(APIUtils.getClientId());
			dif.setState(1);
			dif.setYn(1);
			bizOrderDifferenceManager.insertBizOrderDifference(dif);
			result.setSuccess(true);
			result.setResult(true);
		}catch (Exception e) {
			result.setResultMessage("服务异常，请稍后重试");
			LogTypeEnum.DEFAULT.error(e,"BizOrderDifferenceServiceImpl.insertBizOrderDifference -ERROR");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}
	public void setBizOrderDifferenceManager(
			BizOrderDifferenceManager bizOrderDifferenceManager) {
		this.bizOrderDifferenceManager = bizOrderDifferenceManager;
	}
	public void setBizOrderManager(BizOrderManager bizOrderManager) {
		this.bizOrderManager = bizOrderManager;
	}
	
}
