package com.jd.sns.biz.api.service;

import java.math.BigDecimal;
import java.util.List;

import com.jd.ka.price.soa.sdk.vo.response.QRTPriceRespVO;
import com.jd.ka.price.soa.sdk.vo.response.RTPriceVO;
import com.jd.sns.biz.api.domain.SkuList;
import com.jd.sns.biz.api.service.domain.MapResult;

public interface BaseOrderService {
	/**
	 * 计算订单总金额
	 * @param skuString
	 * @return
	 */
	public BigDecimal calculateOrderPrice(String skuString);
	public BigDecimal calculateOrderPrice(SkuList skuList);
	/**
	 * 判断商品是否在商品池中
	 * @param skuString
	 * @param result
	 * @return
	 */
	public MapResult checkSkuListExist(String skuString, MapResult result);
	
	public MapResult assembleSkuPrice(int payType, SkuList skuList, MapResult result, List<RTPriceVO> respVos);
	
	public String createOrderguid(String clientId);

}
