package com.jd.sns.biz.api.service.impl;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.stereotype.Service;

import com.jd.common.util.StringUtils;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.CacheConstant;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.manager.UserManager;
import com.jd.sns.biz.api.redis.JdCacheUtils;
import com.jd.sns.biz.api.service.UserService;
import com.jd.sns.biz.api.service.domain.ResultBase;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="userService")
public class UserServiceImpl implements UserService {
//	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
	
	private UserManager userManager;
	
	private JdCacheUtils redisUtils;
	
	
	@Override
	public List selectAllUser(User user) {
		return userManager.selectAllUser(user);
	}

	@Override
	public User getUserById(int id) {
		return userManager.getUserById(id);
	}

	@Override
	public ResultBase createUser(User user) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CREATE_USER,false,true);
		ResultBase result = new ResultBase();
		result.setSuccess(false);
		try{
			result = this.checkUpdateParams(user, result);
			if(!result.isSuccess()){
			return result;
			}		
			user.setClient_id(RandomStringUtils.random(10, true, true));
			user.setClient_secret(RandomStringUtils.random(10, true, true));
			this.userManager.createUser(user);
			result.setSuccess(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"UserServiceImpl.createUser -ERROR");
			result.setResultMessage("exception");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return result;
	}

	@Override
	public ResultBase delUser(int id) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.DEL_USER,false,true);
		ResultBase rb = new ResultBase();
		try {
			rb.setSuccess(false);
			int result = userManager.delUser(id);
			if(result == 1){
				rb.setSuccess(true);
			}
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"UserServiceImpl.delUser -ERROR");
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return rb;
	}

	@Override
	public ResultBase updateUser(User user) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.UPDATE_USER,false,true);
		ResultBase result = new ResultBase();
		result.setSuccess(false);
		
//		if(id == 0 || StringUtils.isBlank(pool_name) || StringUtils.isBlank(sku_ids)){
//			result.setResultMessage("参数不能为空");
//			return result;
//		}
		try{
			result = this.checkUpdateParams(user, result);
			if(!result.isSuccess()){
				return result;
			}		
			user.setUpdated(new Date());
			if(this.userManager.updateUser(user) == 1){
				result.setSuccess(true);
				result.setResultMessage("修改成功");
			}else{
				result.setSuccess(false);
				result.setResultMessage("修改未成功，请重试");
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"UserServiceImpl.updateUser -ERROR");
			result.setResultMessage("网络异常，请重试");
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return result;
	}
	
	@Override
	public User getUserByClientId(String client_id) {
		return userManager.getUserByClientId(client_id);
	}
	
	
	/**
	 * 优先从缓存中获取用户信息，缓存半小时
	 * @param client_id
	 * @return
	 */
	public User getUserByClientIdAndCache(String client_id) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_USER_BY_CLIENT_ID_AND_CACHE,false,true);
		User user=null;
		try {
			String key=CacheConstant.getUserClientCacheKey(client_id);
			user = null;
			try {
				String usrJson=redisUtils.get(key);
				if(usrJson!=null){
					user=APIUtils.parseJson2Object(usrJson, User.class);
				}
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e,"从redis获取:{}用户信息失败", key);
			}
			
			if(user==null){
				user=getUserByClientId(client_id);
				if(user!=null){
					try {
//						redisUtils.setex(key, CacheConstant.HALF_HOUR, APIUtils.parseObject2Json(user));
						redisUtils.setStringByExpire(key, APIUtils.parseObject2Json(user), CacheConstant.HALF_HOUR, TimeUnit.SECONDS);
					} catch (Exception e) {
						LogTypeEnum.DEFAULT.error(e,"从redis设置:{}用户信息失败", key);
					}
				}
			}
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"UserServiceImpl.getUserByClientIdAndCache -ERROR");
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return user;
	}

	
	
	
	public void setUserManager(UserManager userManager) {
		this.userManager = userManager;
	}
	
	private ResultBase checkUpdateParams(User user, ResultBase result){
		result.setSuccess(false);
		if(StringUtils.isBlank(user.getRedirect_uri())){
			result.setResultMessage("redirect_uri不能为空");
			return result;
		}
		if(StringUtils.isBlank(user.getName())){
			result.setResultMessage("name不能为空");
			return result;
		}
//		if(StringUtils.isBlank(user.getImg())){
//			result.setResultMessage("img不能为空");
//			return result;
//		}
		if(StringUtils.isBlank(user.getDomain())){
			result.setResultMessage("domain不能为空");
			return result;
		}
		
		if(StringUtils.isBlank(user.getScope())){
			result.setResultMessage("scope不能为空");
			return result;
		}
		result.setSuccess(true);
		return result;
	}

	private ResultBase checkCreateParams(User user, ResultBase result){
		result.setSuccess(false);
		if(StringUtils.isBlank(user.getClient_id())){
			result.setResultMessage("client_id不能为空");
			return result;
		}
		if(StringUtils.isBlank(user.getClient_secret())){
			result.setResultMessage("client_secret不能为空");
			return result;
		}
		return this.checkUpdateParams(user, result);
	}

	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}


}
