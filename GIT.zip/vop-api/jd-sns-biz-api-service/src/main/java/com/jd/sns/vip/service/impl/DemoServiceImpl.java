package com.jd.sns.vip.service.impl;

import org.apache.commons.lang.StringUtils;

import com.jd.sns.vip.manager.DemoManager;
import com.jd.sns.vip.service.DemoService;

import commons.exception.LogicRuntimeException;


/**
 * @auth lsg
 * @version 1.0.0
 */
public class DemoServiceImpl implements DemoService {
	
	private DemoManager demoManager;
	
	
	public void setDemoManager(DemoManager demoManager) {
		this.demoManager = demoManager;
	}

	@Override
	public String getName(String pin) {
		return demoManager.getName(pin);
	}

}
