package com.jd.sns.biz.api.service.impl;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;

import com.jd.jr.geious.saf.api.domain.LimitRequest;
import com.jd.jr.geious.saf.api.domain.LimitResponse;
import com.jd.jr.geious.saf.api.service.GeiousLimitService;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.JinCaiReturnCode;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.service.BizJincaiQueryService;
import com.jd.sns.biz.api.service.domain.StringResult;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

public class BizJincaiQueryServiceImpl implements BizJincaiQueryService {
	@Resource
	private GeiousLimitService geiousLimitServiceRpc;
	/** 金采token **/
	private String jcToken;
	/** 金采交易来源 **/
	private String jcTxtSource;

	@Override
	public String queryCreditLimit(String pin) {
		CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.QUERY_CREDIT_LIMIT,false,true);
		StringResult result = new StringResult();
		result.setSuccess(false);		
		try {
			LimitRequest limitQuery = new LimitRequest();
			limitQuery.setJdPin(pin);
			limitQuery.setToken(jcToken);
			limitQuery.setTxnSource(jcTxtSource);
			LimitResponse limitInfo = geiousLimitServiceRpc.creditLimit(limitQuery);
			if (null == limitInfo) {
				LogTypeEnum.DEFAULT.error("查询金采授信额度接口失败，pin={},custInfo={}",pin,APIUtils.parseObject2Json(limitInfo));	
				result.setResultMessage("金采用户服务异常，请稍后重试！");
				return APIUtils.parseObject2Json(result);
			}else if(!JinCaiReturnCode.REQUEST_SUCCESS.getResponseCode().equals(limitInfo.getResponseCode())){
				LogTypeEnum.DEFAULT.error("查询金采授信额度接口失败，pin={},custInfo={}",pin,APIUtils.parseObject2Json(limitInfo));						
				String failDesc = JinCaiReturnCode.codeMap.get(limitInfo.getResponseCode());
				if(StringUtils.isNotBlank(failDesc)){
					result.setResultMessage(failDesc);
					return APIUtils.parseObject2Json(result);
				}else{
					result.setResultMessage("金采用户错误码:"+limitInfo.getResponseCode());
					return APIUtils.parseObject2Json(result);
				}
			}
			if(null == limitInfo.getRemainLimit()){
				LogTypeEnum.DEFAULT.error("未查询到授信额度余额，pin={},custInfo={}",pin,APIUtils.parseObject2Json(limitInfo));	
				result.setResultMessage("未查询到授信额度余额！");
				return APIUtils.parseObject2Json(result);
			}			
			//2.成功对象返回
			result.setResultCode(limitInfo.getResponseCode());
			result.setResult(APIUtils.parseObject2Json(limitInfo));			
			result.setSuccess(true);
			return APIUtils.parseObject2Json(result);
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"查询用户授信失败,pin={}",pin);
			result.setSuccess(false);
			result.setResultMessage("查询用户授信失败！");
			Profiler.functionError(callerInfo2);
		}finally{
			Profiler.registerInfoEnd(callerInfo2);
		}
		return APIUtils.parseObject2Json(result);
	}

	public String getJcToken() {
		return jcToken;
	}

	public void setJcToken(String jcToken) {
		this.jcToken = jcToken;
	}

	public String getJcTxtSource() {
		return jcTxtSource;
	}

	public void setJcTxtSource(String jcTxtSource) {
		this.jcTxtSource = jcTxtSource;
	}
}
