package com.jd.sns.biz.api.service.domain;

import java.util.List;

public class ListResult extends ResultBase {
	private List result;

	public List getResult() {
		return result;
	}

	public void setResult(List result) {
		this.result = result;
	}
	
}
