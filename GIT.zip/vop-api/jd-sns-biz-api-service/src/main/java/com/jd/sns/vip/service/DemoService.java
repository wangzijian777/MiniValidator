package com.jd.sns.vip.service;

/**
 * @auth lsg
 * @version 1.0.0
 */
public interface DemoService {
	
	public String getName(String pin);
	
}
