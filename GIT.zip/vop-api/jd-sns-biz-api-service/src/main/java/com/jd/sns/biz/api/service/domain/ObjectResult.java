package com.jd.sns.biz.api.service.domain;

public class ObjectResult extends ResultBase {
	private Object result;

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}
}
