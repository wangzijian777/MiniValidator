package com.jd.sns.biz.api.service.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.redis.JdCacheUtils;
import com.jd.sns.biz.api.service.impl.BaseOrderServiceImpl;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="bizOrderUtils")
public class BizOrderUtils {
	private final static Log log = LogFactory.getLog("submitOrderLog");
	private String key = "api_check_repeat_";
	private JdCacheUtils redisUtils;
	
	/**
	 * 订单防重
	 * @param bizOrder
	 * @return
	 */
	public synchronized boolean checkRepeatSubmitOrder(BizOrder bizOrder){
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_REPEAT_SUBMIT_ORDER,false,true);
		String checkKey = key + bizOrder.getPin() + "_" + bizOrder.getName();
		Map<String, String> map = new HashMap<String, String>();
		map.put("name", bizOrder.getName());
		map.put("address", bizOrder.getAddress());
		try {
			String value = redisUtils.get(checkKey);
			if(StringUtils.isNotBlank(value)){
				Map<String, String> valueMap = APIUtils.parseJson2Object(value, Map.class);
				if(map.get("name").equalsIgnoreCase(valueMap.get("name")) && map.get("address").equalsIgnoreCase(valueMap.get("address"))){
					return true;
				}
			}else{
//				redisUtils.setex(checkKey, 1, APIUtils.parseObject2Json(map));
				redisUtils.setStringByExpire(checkKey, APIUtils.parseObject2Json(map), 1, TimeUnit.SECONDS);
			}
			
		} catch (Exception e) {
			log.error("订单防重redis发生异常", e);
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return false;
	}

	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

	
	
}
