package com.jd.sns.biz.api.service;

public interface BizMessageService {
	public String getMessage(String type, String del);
	public String delMessage(String ids);
}
