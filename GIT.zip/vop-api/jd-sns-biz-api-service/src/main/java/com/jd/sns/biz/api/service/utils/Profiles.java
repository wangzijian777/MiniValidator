/**
 * 
 */
package com.jd.sns.biz.api.service.utils;

/**
 * pom.xml文件中profiles节点定义，提供setter通过spring注入<br />
 * 注意，通过setter注入时，setter不能为static，否则报错
 * 
 *
 */
public class Profiles {
	
	/**
	 * 环境，上线或开发
	 */
	public static String evnMode;
	
	
	/**
	 * 是否测试或开发环境
	 * @return
	 */
	public static boolean isTest() {
		if("develop".equalsIgnoreCase(evnMode) || "test".equalsIgnoreCase(evnMode)){
			return true;
		}
		return false;
	}



	public static String getEvnMode() {
		return evnMode;
	}


	public  void setEvnMode(String evnMode) {
		Profiles.evnMode = evnMode;
	}
	
}
