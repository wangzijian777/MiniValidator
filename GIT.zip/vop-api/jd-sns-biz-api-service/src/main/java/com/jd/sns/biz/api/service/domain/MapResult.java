package com.jd.sns.biz.api.service.domain;

import java.util.Map;

public class MapResult extends ResultBase {
	private Map result;

	public Map getResult() {
		return result;
	}

	public void setResult(Map result) {
		this.result = result;
	}
}
