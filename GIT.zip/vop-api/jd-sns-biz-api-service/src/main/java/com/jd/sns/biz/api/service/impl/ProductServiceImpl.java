package com.jd.sns.biz.api.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Resource;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Service;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jd.catagory.pbim.pbia.dubbo.model.Brand;
import com.jd.catagory.pbim.pbia.dubbo.model.Image;
import com.jd.catagory.pbim.pbia.dubbo.model.bigfield.ProductBigField;
import com.jd.catagory.pbim.pbia.dubbo.service.BookVideoService;
import com.jd.catagory.pbim.pbia.dubbo.service.BrandService;
import com.jd.catagory.pbim.pbia.dubbo.service.ImageService;
import com.jd.common.util.StringUtils;
import com.jd.ka.user.soa.domain.ErpContractInfo;
import com.jd.ka.user.soa.exception.BizUserSoaException;
import com.jd.ka.user.soa.service.clientInfo.ClientInfoService;
import com.jd.platform.saf.domain.yanbao.YanBaoRelations;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.BizOrderServiceErrorCode;
import com.jd.sns.biz.api.constant.CacheConstant;
import com.jd.sns.biz.api.constant.OrderConstants;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizPoolSku;
import com.jd.sns.biz.api.domain.Sku;
import com.jd.sns.biz.api.entity.service.BizCommonQueryService;
import com.jd.sns.biz.api.manager.BizPoolManager;
import com.jd.sns.biz.api.manager.BizPoolSkuManager;
import com.jd.sns.biz.api.order.exception.BizOrderServiceException;
import com.jd.sns.biz.api.service.ProductService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.domain.StringResult;
import com.jd.sns.biz.api.service.utils.OrderConvertUtils;
import com.jd.sns.biz.api.service.utils.OrderDownDealUtils;
import com.jd.sns.biz.api.service.utils.ProductFieldsWrap;
import com.jd.sns.biz.order.domain.BizOrderSku;
import com.jd.sns.biz.order.domain.OrderInfo;
import com.jd.sns.club.soa.api.ClubIceRpcServicePrx;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="productService")
public class ProductServiceImpl implements ProductService {
	private final int AREA_CHECK=0;//区域限制校验
	private ImageService productImageService;
	private com.jd.catagory.pbim.pbia.dubbo.service.ProductService jdProductService;
	private BookVideoService bookVideoService;
	private BizPoolSkuManager bizPoolSkuManager;
	private BizPoolManager bizPoolManager;
	private ClubIceRpcServicePrx clubIceRpcClient;
	
	@Resource
	private BrandService brandService;

	@Resource
	private BizCommonQueryService bizCommonQueryService;
	
	@Resource 
	private ClientInfoService clientInfoService; 
	
	@Resource 
	private OrderDownDealUtils orderDownDealUtils;	
	
	@Override
	public String selectPageNumByClientId(String clientId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.SELECT_PAGE_NUM_BY_CLIENT_ID,false,true);
		ListResult result = new ListResult();
		try{
			List list = bizPoolManager.selectPageNumByClientId(clientId);
			if(list == null || list.size() == 0){
				result.setSuccess(false);
				result.setResultMessage("商品池为空");
				return APIUtils.parseObject2Json(result);
			}
			result.setResult(list);
			result.setSuccess(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"ProductServiceImpl.selectPageNumByClientId -ERROR");
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试");
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	@Override
	public String selectSkuIdsByClientIdAndPageNum(String clientId, String pageNum) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.SELECT_SKUIDS_BY_CLIENT_ID_AND_PAGE_NUM,false,true);		
		StringResult result = new StringResult();
		try{
			int poolId = 0;
			try{
				poolId = Integer.parseInt(pageNum);
			}catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e,"page_num={}",pageNum);
				result.setSuccess(false);
				result.setResultMessage("pageNum格式不正确");
				return APIUtils.parseObject2Json(result);
			}
			BizPoolSku bizPoolSku = new BizPoolSku();
			bizPoolSku.setClientId(clientId);
			bizPoolSku.setPoolId(poolId);
			List list = bizPoolSkuManager.selectSkuIdsByClientIdAndPageNum(bizPoolSku);
			if(list == null || list.size() == 0){
				result.setSuccess(false);
				result.setResultMessage("pageNum不存在");
				return APIUtils.parseObject2Json(result);
			}
			String skuIds = "";
			for(int i=0;i<list.size() ; i++){
				skuIds += list.get(i).toString() + ",";
			}
			if(StringUtils.isNotBlank(skuIds)){
				skuIds = skuIds.substring(0, skuIds.length() - 1);
			}
			result.setResult(skuIds);
			result.setSuccess(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"ProductServiceImpl.selectSkuIdsByClientIdAndPageNum -ERROR");
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试");
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	@Override
	public String getDetail(String sku) {
		CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.GET_DETAIL,false,true);			
		MapResult result = new MapResult();
		try{
			result.setSuccess(false);
			if(StringUtils.isBlank(sku)){
				result.setSuccess(false);
				result.setResultMessage("参数不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			long skuId = 0;
			try{
				skuId = Long.parseLong(sku);
			}catch (Exception e) {
				result.setSuccess(false);
				result.setResultMessage("参数格式不正确");
				return APIUtils.parseObject2Json(result);
			}
			
//			if(bizPoolSkuManager.checkSkuIdExistByClientID(APIUtils.getClientId(), skuId) <= 0){
//				result.setSuccess(false);
//				result.setResultMessage("您的商品池中，没有该商品信息");
//				return APIUtils.parseObject2Json(result);
//			}
			
			Map<String, Object> resultMap = new HashMap<String, Object>();
			Map<String, String> baseInfo = getBaseInfo(skuId);
			LogTypeEnum.DEFAULT.error(APIUtils.parseObject2Json(baseInfo));
			if(baseInfo == null || baseInfo.get("category") == null){
				result.setSuccess(false);
				result.setResultMessage("该商品不存在");
				return APIUtils.parseObject2Json(result);
			}
			if(isBook(skuId)){
				fillBookInfo(resultMap, sku, baseInfo);
			}else{
				fillCommonSkuInfo(resultMap, skuId, baseInfo);
			}
			
			fillEleGift(resultMap, skuId);
			
			if(resultMap.isEmpty()){
				result.setSuccess(false);
				result.setResultMessage("该商品不存在");
				return APIUtils.parseObject2Json(result);
			}
			result.setResult(resultMap);
			result.setSuccess(true);
			Profiler.registerInfoEnd(callerInfo2);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"ProductServiceImpl.getDetail -ERROR");
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo2);
		}finally{
			Profiler.registerInfoEnd(callerInfo2);
		}
		return APIUtils.parseObject2Json(result);
	}
	
	/**
	 * 增加礼品卡字段
	 * @param resultMap
	 * @param skuId
	 */
	private void fillEleGift(Map<String, Object> resultMap, long skuId) {
		Set<Long> skuSet = new HashSet<Long>();
		skuSet.add(skuId);
		Set<String> extend = new HashSet<String>();                                      
		extend.add(OrderConstants.EXTEND_ELEGIFT);  //是否加收偏远运费
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDPRODUCTSERVICE_QUERYEXTEND,false,true);
		Map<Long, Map<String, String>> map = null;
		try{
			map = jdProductService.queryExtend(skuSet, extend); //调接口获取商品扩展属性（是否加收偏远运费）
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"查询商品扩展信息失败");
			Profiler.functionError(callerInfo);
			throw new RuntimeException();
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		
		if(map != null && map.get(skuId) != null && "4".equals(map.get(skuId).get(OrderConstants.EXTEND_ELEGIFT))){
			resultMap.put("eleGift", "4");
		}
	}
	
	private void fillBookInfo(Map<String, Object> resultMap, String sku, Map<String, String> baseInfo) {
		Set<Integer> skuIds = new HashSet<Integer>();
		Integer skuId = Integer.parseInt(sku);
        skuIds.add(skuId);
        Set<String> baseFields = null;
        Set<String> bigFields = null;
        if(baseInfo.get("category").startsWith("1713")){
        	LogTypeEnum.DEFAULT.error("{}为图书", skuId);
        	baseFields = ProductFieldsWrap.getBookBaseFields();
        	bigFields = ProductFieldsWrap.getBookBigFields();
        }else if(baseInfo.get("category").startsWith("405")){
        	LogTypeEnum.DEFAULT.error("{}为音像", skuId);
        	baseFields = ProductFieldsWrap.getVedioBaseFields();
        	bigFields = ProductFieldsWrap.getVedioBigFields();
        }else{
            LogTypeEnum.DEFAULT.error("{}长度为8，但既不是图书，也不是音像", skuId);
        	return;
        }
        
        
        Map<Integer,Map<String,String>> baseMap = bookVideoService.queryBookVideo(skuIds,baseFields);
        LogTypeEnum.DEFAULT.error("查到的商品信息：" + JSON.toJSONString(baseMap));
        if(baseMap == null || baseMap.get(skuId) == null){
			return;
		}
        
        Map<Integer,Map<String,String>> bigMap = bookVideoService.queryBookVideoBigField(skuIds, bigFields);
        LogTypeEnum.DEFAULT.error("查到的商品大字段信息：" + JSON.toJSONString(bigMap));
        
        resultMap.put("sku", skuId);
        if(baseInfo.get("category").startsWith("1713")){
        	resultMap.put("skuType", "book");
        	ProductFieldsWrap.setBookFields(resultMap, skuId, baseMap.get(skuId), bigMap);
        }else{
        	resultMap.put("skuType", "vedio");
        	ProductFieldsWrap.setVedioFields(resultMap, skuId, baseMap.get(skuId), bigMap);
        }
	}
	
	private Map<String, String> getBaseInfo(long skuId){
		Set<Long> skuIdSet = new HashSet<Long>();
		skuIdSet.add(skuId);
		Set<String> base = ProductFieldsWrap.getCommonBaseFields();
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDPRODUCTSERVICE_QUERYPRODUCTBASE, false, true);
		Map<Long, Map<String, String>> map=null;
		try {
			map = jdProductService.queryProductBase(skuIdSet, base);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"jdProductService.queryProductBase -ERROR,sku={}",skuId);
			throw new RuntimeException(e);
		}
		Profiler.registerInfoEnd(callerInfo);
		if(map == null || map.get(skuId) == null){
			return null;
		}
		
		return map.get(skuId);
	}
	
	public Map<Long, Map<String, String>> getExtendInfo(List<Sku> skus){
		Set<Long> skuSet = new HashSet<Long>();
		for(Sku sku : skus){
			skuSet.add(sku.getSkuId());
		}
		Set<String> extend = new HashSet<String>();                                      
		extend.add(OrderConstants.FARAWAY_QUERY);  //是否加收偏远运费
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDPRODUCTSERVICE_QUERYEXTEND,false,true);
		Map<Long, Map<String, String>> map = null;
		try{
			map = jdProductService.queryExtend(skuSet, extend); //调接口获取商品扩展属性（是否加收偏远运费）
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"查询商品扩展信息失败");
			Profiler.functionError(callerInfo);
			throw new RuntimeException();
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return map;
	}
	
	private void fillCommonSkuInfo(Map<String, Object> resultMap, long skuId, Map<String, String> skuMap) {
		Set<Long> skuIdSet = new HashSet<Long>();
		skuIdSet.add(skuId);
		
		resultMap.put("sku", skuId);
		resultMap.put("weight", skuMap.get("weight"));
		resultMap.put("imagePath", skuMap.get("imagePath"));
		resultMap.put("state", skuMap.get("state"));
		Brand brand = null;
		try {
			brand = brandService.queryBrand(Integer.valueOf(skuMap.get("brandId")));
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "调用品牌服务获取品牌信息失败，skuId={},resultMap={}", skuId,resultMap);
		}
		if(null != brand && StringUtils.isNotEmpty(brand.getName())){
			resultMap.put("brandName", brand.getName());
		}else{
			resultMap.put("brandName", skuMap.get("brandName"));
		}
		resultMap.put("name", skuMap.get("name"));
		resultMap.put("productArea", skuMap.get("productArea"));
		resultMap.put("upc", skuMap.get("upc"));
		resultMap.put("saleUnit", skuMap.get("saleUnit"));
		resultMap.put("category", skuMap.get("category"));
		
		
		List<String> list = new ArrayList<String>();
		list.add("wareQD");//包装清单
		list.add("propCode");  //规格参数 
		list.add("wdis");  //商品介绍
		CallerInfo info=Profiler.registerInfo(UMPFunctionKeyConstant.JDPRODUCTSERVICE_QUERYBIGFIELD, false, true);
		ProductBigField productBigField = jdProductService.queryBigField(Long.toString(skuId), list);
		Profiler.registerInfoEnd(info);
		resultMap.put("introduction", productBigField.getWdis());//详细介绍
		resultMap.put("param", productBigField.getPropCode());//规格参数
		resultMap.put("wareQD", productBigField.getWareQD());//清单
	}

	/**
	 * 8位sku，非电子虚拟类(300,600开头)
	 * @param skuId
	 * @param string 
	 * @return
	 */
	private boolean isBook(long skuId) {
		String sku = Long.toString(skuId);
		if(sku.length() == 8 && !sku.startsWith("300") && !sku.startsWith("600")){
			return true;
		}
		return false;
	}
	
	@Override
	public String skuState(String sku) {
		CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.SKU_STATE,false,true);
		ListResult result = new ListResult();
		result.setSuccess(false);
		try{
			if(StringUtils.isBlank(sku)){
				result.setResultMessage("sku不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			Set<Long> set = new HashSet<Long>();
			String [] skuIds = sku.split(",");
			if(skuIds.length > 100){
				result.setResultMessage("sku数量过多，目前最大支持100个商品");
				return APIUtils.parseObject2Json(result);
			}
			
			//先判断商品sku格式是否正确，不再校验商品池
			result = checkSkus(skuIds, result);
			if(!result.isSuccess()){
				return APIUtils.parseObject2Json(result);
			}
			
			for(int i = 0 ;i < skuIds.length; i++){
				try{
					long skuId = Long.parseLong(skuIds[i]);
					/*if(bizPoolSkuManager.checkSkuIdExistByClientID(APIUtils.getClientId(), skuId) > 0){*/
						set.add(skuId);
					/*}else{
						result.setResultMessage("sku中包含不在您的商品池中的商品，请核对后重试");
						return APIUtils.parseObject2Json(result);
					}*/
				}catch (Exception e) {
					LogTypeEnum.DEFAULT.error(e,"ProductServiceImpl.skuState -ERROR");
					result.setResult(null);
					result.setResultMessage("参数格式不正确，必须为纯数字，以,分割");
					return APIUtils.parseObject2Json(result);
				}
			}
			
			Set<String> baseSet = new HashSet<String>();
			baseSet.add("state");
			CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDPRODUCTSERVICE_QUERYPRODUCTBASE, false, true);
			Map<Long, Map<String, String>> map=null;
			try {
				map = jdProductService.queryProductBase(set, baseSet);
			} catch (Exception e) {
				Profiler.functionError(callerInfo);
				LogTypeEnum.DEFAULT.error(e,"jdProductService.queryProductBase -ERROR");
				throw new RuntimeException(e);
			}
			Profiler.registerInfoEnd(callerInfo);
			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			Map<String, Object> resultMap = null;
			for(int i = 0 ;i < skuIds.length; i++){
				Map<String, String> oneMap = map.get(Long.parseLong(skuIds[i]));
				if(oneMap != null && oneMap.size() > 0 && oneMap.get("state") != null){
					resultMap = new HashMap<String, Object>();
					resultMap.put("sku", Long.parseLong(skuIds[i]));
					resultMap.put("state", Integer.parseInt(oneMap.get("state")) == 1 ? 1:0);
					list.add(resultMap);
				}
			}
			if(list.size()!=0){
				result.setSuccess(true);
				result.setResult(list);
			}else{
				result.setResultMessage("未找到对应商品信息");
			}
			Profiler.registerInfoEnd(callerInfo2);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"ProductServiceImpl.skuState -ERROR");
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo2);
		}finally{
			Profiler.registerInfoEnd(callerInfo2);
		}
		return APIUtils.parseObject2Json(result);
	}

	@Override
	public String skuImage(String sku) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.SKU_IMAGE,false,true);
		MapResult result = new MapResult();
		result.setSuccess(false);
		try{
			if(StringUtils.isBlank(sku)){
				result.setResultMessage("sku不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			Set<Integer> set = new HashSet<Integer>();
			String [] skuIds = sku.split(",");
			
			if(skuIds.length > 100){
				result.setResultMessage("sku数量过多，目前最大支持100个商品");
				return APIUtils.parseObject2Json(result);
			}
			
			for(int i = 0 ;i < skuIds.length; i++){
				try{
					Long.parseLong(skuIds[i]);
//					if(bizPoolSkuManager.checkSkuIdExistByClientID(APIUtils.getClientId() ,Long.parseLong(skuIds[i])) > 0){
						set.add(Integer.parseInt(skuIds[i]));
//					}else{
//						result.setResultMessage("sku中包含不在您的商品池中的商品，请核对后重试");
//						return APIUtils.parseObject2Json(result);
//					}
				}catch (Exception e) {
					LogTypeEnum.DEFAULT.error(e,"bizPoolSkuManager.checkSkuIdExistByClientID -ERROR");
					result.setResult(null);
					result.setResultMessage("参数格式不正确，必须为纯数字，以,分割");
					return APIUtils.parseObject2Json(result);
				}
			}
			Map<Integer,List<Image>> imageMap  =  this.productImageService.queryImage(set);
			if(imageMap == null){
				result.setResultMessage("未找到对应商品信息");
				return APIUtils.parseObject2Json(result);
			}			
			result.setResult(imageMap);
			result.setSuccess(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"ProductServiceImpl.skuImage");
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}
	
	@Override
	public String getProductCommentSummarys(String sku) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_PRODUCT_COMMENT_SUMMARYS,false,true);
		ListResult result = new ListResult();
		try{
			result.setSuccess(false);
			if(StringUtils.isBlank(sku)){
				result.setResultMessage("sku不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			String [] skuArr = sku.split(",");
			if(skuArr.length > 50){
				result.setResultMessage("sku数量过多，目前最大支持50个商品");
				return APIUtils.parseObject2Json(result);
			}
			
			//先判断商品格式是否正确，不再校验商品池
			result = checkSkus(skuArr, result);
			if(!result.isSuccess()){
				return APIUtils.parseObject2Json(result);
			}
			
			//{"productIds":"207983,207985,207986"}
			String param = "{\"productIds\":\""+sku+"\"}";
			String commentResult = clubIceRpcClient.getProductCommentSummarys(param);
			if(StringUtils.isBlank(commentResult)){
				result.setResultMessage("服务异常，请稍后重试");
				return APIUtils.parseObject2Json(result);
			}
			Map summarysMap = APIUtils.parseJson2Object(commentResult, Map.class);
			if(summarysMap == null){
				result.setResultMessage("服务异常，请稍后重试");
				return APIUtils.parseObject2Json(result);
			}
			
			if(Boolean.parseBoolean(summarysMap.get("success").toString())){
				Map map = (Map)summarysMap.get("result");
				List list = (List)map.get("commentSummaries");
				if(list == null || list.size() == 0){
					result.setSuccess(true);
					result.setResultMessage("暂无评价");
					return APIUtils.parseObject2Json(result);
				}
				List<Map> resultList = new ArrayList<Map>();
				for(int i =0;i<list.size() ;i++){
					Map<String, Object> resultMap = new HashMap<String, Object>();
					Map one = (Map)list.get(i);
					if(one == null || one.size() == 0){
						continue;
					}
					//平均分（总星数）
					int averageScore = Integer.parseInt(one.get("averageScore").toString());
					//好评率
					double goodRate = Double.parseDouble(one.get("goodRate").toString());
					//中评率
					double generalRate = Double.parseDouble(one.get("generalRate").toString());
					//差评率
					double poorRate = Double.parseDouble(one.get("poorRate").toString());
					resultMap.put("skuId", Long.parseLong(one.get("skuId").toString()));
					resultMap.put("averageScore", averageScore);
					resultMap.put("goodRate", goodRate);
					resultMap.put("generalRate", generalRate);
					resultMap.put("poorRate", poorRate);
					resultList.add(resultMap);
				}
				result.setSuccess(true);
				result.setResult(resultList);
				return APIUtils.parseObject2Json(result);
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"ProductServiceImpl.getProductCommentSummarys -ERROR");
			Profiler.functionError(callerInfo);
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}		
		result.setResultMessage("服务异常，请稍后重试");
		return APIUtils.parseObject2Json(result);
	}
	
	private ListResult checkSkus(String[] skuArr, ListResult result) throws Exception{
		result.setSuccess(true);
		for(String sku : skuArr){
			try{
				Long.parseLong(sku);
			}catch (Exception e) {
				result.setSuccess(false);
				result.setResultMessage(result.getResultMessage() + "sku="+sku+"的格式不正确，");
				continue;
			}
//			if(bizPoolSkuManager.checkSkuIdExistByClientID(clientId, skuId) <= 0){
//				result.setSuccess(false);
//				result.setResultMessage(result.getResultMessage() + sku+"不在商品池中，");
//			}
		}
		return result;
	}
	
	@Override
	public Map<Long, List<String>> getProductAreaLimit(Set<Long> skuIds){
		Map<Long, List<String>>  resultMap = null;
		if(!CollectionUtils.isEmpty(skuIds)){
			//0:购买区域限制;1:以旧换新支持;2:支持大家电区域
			try {
				resultMap = jdProductService.queryLimitArea(skuIds, AREA_CHECK);
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e, "调用商品服务获取商品受限制的区域失败！传入的skuIds={}", APIUtils.parseObject2Json(skuIds));
			}
			LogTypeEnum.DEFAULT.error("调用商品服务获取商品受限制的区域返回结果={}",APIUtils.parseObject2Json(resultMap));
		}
		return resultMap;
	}

	@Override
	public String getProductName(Long skuId) {
		String name=null;
		Set<Long> ids = new HashSet<Long>();
		ids.add(skuId);
		Set<String> base = new HashSet<String>();
		base.add("name");
		try {
			Map<Long, Map<String, String>> map = jdProductService.queryProductBase(ids, base);
			if(null!=map && !map.isEmpty()){
				name=map.get(skuId).get("name");
			}
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "调用商品基本接口失败！ids={},base={}", APIUtils.parseObject2Json(ids),APIUtils.parseObject2Json(base));
		}
		return name;
	}
	
	
	public String isSupportHuoDaoFuKuan(String skuIds, String province, String city, String county, String town) {
		CallerInfo info = Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_HUO_DAO_FU_KUAN, false, true);
		BooleanResult result = new BooleanResult();
		result.setSuccess(false);
		result.setResult(false);
		try {
			OrderInfo orderInfo = builderOrderInfo(skuIds, province, city, county, town);
			boolean isCould = bizCommonQueryService.checkNonCODOrder(orderInfo);
			result.setResult(isCould);
			result.setSuccess(true);
		} catch (BizOrderServiceException e) {
			LogTypeEnum.DEFAULT.error(e, "货到付款查询-不支持货到付款!");
			result.setSuccess(true);
			result.setResultCode(StringUtils.isNotEmpty(e.getReturnCode()) ? e.getReturnCode() : BizOrderServiceErrorCode.CODE_EXCEPTION);
			result.setResultMessage(e.getReturnMessage());
		} catch (Exception e) {
			Profiler.functionError(info);
			LogTypeEnum.DEFAULT.error(e, "货到付款查询失败!");
			result.setResultCode(BizOrderServiceErrorCode.CODE_EXCEPTION);
			result.setResultMessage("网络异常，请稍后重试");
		} finally {
			Profiler.registerInfoEnd(info);
		}
		return APIUtils.parseObject2Json(result);
	}
	
	private OrderInfo builderOrderInfo(String skuIds, String province, String city, String county, String town)
			throws BizOrderServiceException, Exception {
		int lProvince = NumberUtils.toInt(province, -1);
		if (lProvince == -1) {
			throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_PARAM_NOT_NULL, "province为空或非法");
		}
		int lCity = NumberUtils.toInt(city, -1);
		if (lCity == -1) {
			throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_PARAM_NOT_NULL, "city为空或非法");
		}
		int lCounty = NumberUtils.toInt(county, -1);
		if (lCounty == -1) {
			throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_PARAM_NOT_NULL, "county为空或非法");
		}
		int lTown = NumberUtils.toInt(town, 0);

		if (StringUtils.isEmpty(skuIds)) {
			throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_PARAM_NOT_NULL, "sku为空或非法");
		}

		String[] skuArray = skuIds.split(",");
		List<BizOrderSku> skuList = new ArrayList<BizOrderSku>();
		BizOrderSku orderSku = null;
		long tempSku = -1;
		for (String sku : skuArray) {
			tempSku = NumberUtils.toLong(sku, -1);
			if (tempSku == -1) {
				throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_PARAM_VALUE_ERROR, "sku格式非法");
			}

//			if (bizPoolSkuManager.checkSkuIdExistByClientID(APIUtils.getClientId(), tempSku) <= 0) {
//				throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_PARAM_VALUE_ERROR, "商品[" + sku + "]不在商品池中!");
//			}
			orderSku = new BizOrderSku();
			orderSku.setSkuId(tempSku);

			skuList.add(orderSku);
		}

		if (skuList.isEmpty()) {
			throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_PARAM_VALUE_ERROR, "sku信息为空");
		} else if (skuList.size() > 50) {
			throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_PARAM_VALUE_ERROR, "sku长度超过允许最大值50");
		}

		OrderInfo orderInfo = new OrderInfo();
		orderInfo.setClientId(APIUtils.getClientId());
		orderInfo.setPin(APIUtils.getPin());
		orderInfo.setProvince(lProvince);
		orderInfo.setCity(lCity);
		orderInfo.setCounty(lCounty);
		orderInfo.setTown(lTown);
		orderInfo.setSkuList(skuList);
		return orderInfo;
	}
	

	@Override
	public String getSkuGift(Long skuId, Integer province, Integer city, Integer county, Integer town) {
		CallerInfo info = Profiler.registerInfo(UMPFunctionKeyConstant.GET_SKU_GIFTS, false, true);
		StringResult result = new StringResult();
		result.setSuccess(false);
		try {
			return  bizCommonQueryService.querySkuPromotion(skuId, province, city, county, town, getBQueryGift());
		} catch (Exception e) {
			Profiler.functionError(info);
			LogTypeEnum.DEFAULT.error(e, "代码执行异常-CodeExcepiton, 查询赠品附件信息失败!");
			result.setResultCode(BizOrderServiceErrorCode.CODE_EXCEPTION);
			result.setResultMessage("网络异常，请稍后重试");
		} finally {
			Profiler.registerInfoEnd(info);
		}

		return APIUtils.parseObject2Json(result);
	}
	
	private boolean getBQueryGift(){
		String clientId = APIUtils.getClientId();
		String pin = APIUtils.getPin();
		ErpContractInfo erpContractInfo = null;
		boolean bQueryGift = false;
		CallerInfo callerInfoErpContract =Profiler.registerInfo(UMPFunctionKeyConstant.QUERY_ERP_CONTRACT_GIFT_INFO,false,true);
		try {
			//查询合同相关权限信息
			String keyErpContract = CacheConstant.getClientContractCacheKey(clientId); //获取合同缓存key
			erpContractInfo = orderDownDealUtils.getObjectAndRestore(keyErpContract, ErpContractInfo.class);
			if(erpContractInfo == null){//缓存没查到，则调接口获取
				erpContractInfo = clientInfoService.queryUserClientIdFlag( clientId, pin);
				//将合同信息放入redis
				orderDownDealUtils.saveObjectToRedis(erpContractInfo, keyErpContract,false);
			}
			if(erpContractInfo != null){
				//返回是否有赠品权限
				bQueryGift = OrderConvertUtils.getGiftType(erpContractInfo.getContractAttribute()) == 1; //giftType 0无赠品   1有赠品
			}
		}catch ( BizUserSoaException e) {
			LogTypeEnum.GIFT_LOG.error(e,"权限验证失败---根据clientId查询合同权限信息出错!clientId:{},pin:{}",clientId,pin);
		} catch (Exception e) {
			LogTypeEnum.GIFT_LOG.error(e,"代码执行异常-CodeExcepiton 权限验证异常---根据clientId查询合同权限信息出错!clientId:{},pin:{}",clientId,pin);
			Profiler.functionError(callerInfoErpContract);
		}finally{
			Profiler.registerInfoEnd(callerInfoErpContract);
		}
		return bQueryGift;
	}

	@Override
	public String getYanbaoSku(List<Long> skuList) {
		String yanbao = null;
		CallerInfo callerInfo =Profiler.registerInfo(UMPFunctionKeyConstant.QUERY_ERP_CONTRACT_GIFT_INFO,false,true);
		try{
			yanbao = bizCommonQueryService.getYanBaoInfo(skuList);
			JSONObject yanbaoMap = JSON.parseObject(yanbao);
//			{"133802":[{"classifyId":1,"classifyName":"延长保修","directionTips":"延长机器保修时间","imgUrl":"fuwu/jfs/t1693/34/509909728/1852/5db56e58/55a6386fNee93520a.jpg","mainSkuId":133802,"sequenceId":2,"subRelation":[{"classifyId":2,"classifyName":"延长保修1年","price":"29.00","sequenceId":11,"yanBaoSkuId":853926},{"classifyId":3,"classifyName":"延长保修2年","price":"49.00","sequenceId":12,"yanBaoSkuId":1100448}]},{"classifyId":19,"classifyName":"特惠","directionTips":"精选特惠服务供您选择。","imgUrl":"fuwu/jfs/t1507/285/877726015/1865/bf22f1af/55b05721N6c5b68cc.jpg","mainSkuId":133802,"sequenceId":1,"subRelation":[{"classifyId":20,"classifyName":"特惠延长保修1年","price":"15.90","sequenceId":2,"yanBaoSkuId":1105622}]},{"classifyId":8,"classifyName":"只换不修","directionTips":"用换新机代替维修！","imgUrl":"fuwu/jfs/t1342/349/990111447/1819/58500984/55b05783Nd2fd3663.jpg","mainSkuId":133802,"sequenceId":4,"subRelation":[{"classifyId":126,"classifyName":"特惠只换不修2年","price":"39.00","sequenceId":4,"yanBaoSkuId":1526971},{"classifyId":119,"classifyName":"只换不修1年","price":"29.00","sequenceId":5,"yanBaoSkuId":1526989},{"classifyId":120,"classifyName":"只换不修2年","price":"49.00","sequenceId":6,"yanBaoSkuId":1527011}]}]}
			Map<Long, List<YanBaoRelations>> yanbaoMap = JSON.parseObject(yanbao, Map<Long, List<YanBaoRelations>>);
			for (Long skuId : yanbaoMap.keySet()) {
				 List<YanBaoRelations> relations = yanbaoMap.get(skuId);
				 reSetPrice(relations);
			}
			yanbao = JSON.toJSONString(yanbaoMap);
		} catch (Exception e){
			LogTypeEnum.DEFAULT.error(e, "CODE_EXCEPTION 调用延保信息SOA服务失败");
			Profiler.functionError(callerInfo);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
		
		LogTypeEnum.DEFAULT.error("得到延保信息：" + yanbao);
		return yanbao;
	}
	public void setBizPoolManager(BizPoolManager bizPoolManager) {
		this.bizPoolManager = bizPoolManager;
	}
	
	public void setJdProductService(
			com.jd.catagory.pbim.pbia.dubbo.service.ProductService jdProductService) {
		this.jdProductService = jdProductService;
	}
	
	public void setProductImageService(ImageService productImageService) {
		this.productImageService = productImageService;
	}

	public void setBizPoolSkuManager(BizPoolSkuManager bizPoolSkuManager) {
		this.bizPoolSkuManager = bizPoolSkuManager;
	}

	public void setClubIceRpcClient(ClubIceRpcServicePrx clubIceRpcClient) {
		this.clubIceRpcClient = clubIceRpcClient;
	}

	public void setBookVideoService(BookVideoService bookVideoService) {
		this.bookVideoService = bookVideoService;
	}

	public void setBizCommonQueryService(BizCommonQueryService bizCommonQueryService) {
		this.bizCommonQueryService = bizCommonQueryService;
	}
}