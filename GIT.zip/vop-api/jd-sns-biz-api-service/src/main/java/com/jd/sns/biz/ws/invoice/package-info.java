@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.360buy.com")
package com.jd.sns.biz.ws.invoice;
