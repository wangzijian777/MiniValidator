package com.jd.sns.biz.api.service;

import java.beans.DesignMode;
import java.math.BigDecimal;
import java.util.List;

import com.jd.ka.price.soa.sdk.vo.response.QRTPriceRespVO;
import com.jd.sns.biz.api.domain.JincaiCredit;

/**
 * 地址服务
 * @author yujianming
 *
 */
public interface JdPriceService {
	/**
	 * 批量协议价查询
	 * @param skuids
	 * @param area
	 * @return
	 */
	public String batch(String skuids, String containsTax);
	/**
	 * 单个查询京东协议价（包含在商品池中）
	 * update by wangzijian, 增加MapResult 参数，为了保存价格快照
	 * @param skuId
	 * @param respVos 
	 * @return
	 */
	public BigDecimal getPriceBySkuId(long skuId, List<QRTPriceRespVO> respVos);
	
	/**
	 * 批量京东价查询，包含商品池商品
	 * @param skuids
	 * @return
	 */
	public String jdPriceBatchFromPool(String skuids);
	/**
	 * 单个查询京东价格商品（包含在商品池中）
	 * 2015-4-23 yz 修改为调用价格服务京东价，不在调用前台京东价
	 * @param skuId
	 * @return
	 */
	public BigDecimal getJdPriceBySkuId(long skuId,List<QRTPriceRespVO> respVos);
	
	/**
	 * 查询用户余额
	 * @param pin
	 * @return
	 */
	public String selectBalance(String pin, int paymentType);
	
	
	/**
	 * 查询用户金彩额度
	 * @param pin
	 * @return
	 */
	public String getJincaiCredit(String pin);
	
}
