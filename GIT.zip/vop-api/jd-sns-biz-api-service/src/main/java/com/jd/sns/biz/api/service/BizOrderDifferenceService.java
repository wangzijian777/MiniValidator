package com.jd.sns.biz.api.service;

import java.util.List;

import com.jd.sns.biz.api.domain.BizOrderDifference;

public interface BizOrderDifferenceService {
	
	public String insertBizOrderDifference(String jdOrderId, String content);
}
