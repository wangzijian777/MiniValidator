package com.jd.sns.biz.api.service;

import java.util.List;

import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.service.domain.ResultBase;

public interface UserService {
	public List selectAllUser(User user);
	
	public User getUserById(int id);
	
	public ResultBase createUser(User user);
	
	public ResultBase delUser(int id);
	
	public ResultBase updateUser(User user);	
	
	public User getUserByClientId(String client_id);

	/**
	 * 优先从缓存中获取用户信息，缓存半小时
	 * @param client_id
	 * @return
	 */
	public User getUserByClientIdAndCache(String client_id);

}
