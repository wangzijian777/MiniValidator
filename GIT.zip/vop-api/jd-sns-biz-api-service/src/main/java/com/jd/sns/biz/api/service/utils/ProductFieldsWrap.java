package com.jd.sns.biz.api.service.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ProductFieldsWrap {
	private final static Set<String> commonBase = new HashSet<String>();
	private final static List<String> commonBig = new ArrayList<String>();
	private final static Set<String> bookBase = new HashSet<String>();
	private final static Set<String> bookBig = new HashSet<String>();
	private final static Set<String> vedioBase = new HashSet<String>();
	private final static Set<String> vedioBig = new HashSet<String>();
	
	public static Set<String> getCommonBaseFields(){
		//yz 修改一下之前实例重启,查询接口就会报错,不知道是不是final影响到了虚拟化,先每次创建对象;
		Set<String> commonBase = new HashSet<String>();
		if(commonBase.isEmpty()){
			commonBase.add("weight");			// 重量
			commonBase.add("imagePath");		// 主图地址
			commonBase.add("state");			// 上下架状态
			commonBase.add("brandName");		// 品牌
			commonBase.add("brandId");			// 品牌ID
			commonBase.add("name");				// 商品名称
			commonBase.add("productArea");		// 产地
			commonBase.add("upc");				// 条形码
			commonBase.add("saleUnit");			// 销售单位
			commonBase.add("category");			// 商品一级分类
		}
		return commonBase;
	}
	
	public static List<String> getCommonBigFields(){
		if(commonBig.isEmpty()){
			commonBig.add("wareQD");	//包装清单
			commonBig.add("propCode");  //规格参数 
			commonBig.add("wdis");  	//商品介绍
		}
		return commonBig;
	}
	
	public static Set<String> getBookBaseFields(){
		if(bookBase.isEmpty()){
			bookBase.add("Author");		// 著者
			bookBase.add("Editer");		// 编者
			bookBase.add("Transfer");	// 译者
			bookBase.add("Drawer");		// 绘者
			bookBase.add("Proofreader");// 校对
	        bookBase.add("ISBN");		// ISBN
	        bookBase.add("Publishers");	// 出版社
	        bookBase.add("Sheet");		// 开本
	        bookBase.add("Pages");		// 页数
	        bookBase.add("Package");	// 包装
	        bookBase.add("PublishTime");// 出版时间
	        bookBase.add("BatchNo");	// 版次
	        bookBase.add("PrintTime");	// 印刷时间
	        bookBase.add("PrintNo");	// 印次
	        bookBase.add("PackNum");	// 套装数量
	        bookBase.add("Language");	// 正文语言
	        bookBase.add("Papers");		// 用纸
	        bookBase.add("Brand");		// 品牌
		}
		return bookBase;
	}
	
	public static Set<String> getBookBigFields(){
		if(bookBig.isEmpty()){
			bookBig.add("comments");		// 媒体评论	
			bookBig.add("image");			// 插图
			bookBig.add("contentDesc");		// 内容摘要
			bookBig.add("relatedProducts");	// 产品描述
			bookBig.add("editerDesc");		// 编辑推荐
			bookBig.add("catalogue");		// 目录
			bookBig.add("bookAbstract");	// 精彩摘要
			bookBig.add("authorDesc");		// 作者简介
			bookBig.add("introduction");	// 前言
		}
		return bookBig;
	}
	
	public static Set<String> getVedioBaseFields(){
		if(vedioBase.isEmpty()){
			vedioBase.add("Actor");			// 演员
	        vedioBase.add("Director");		// 导演
	        vedioBase.add("Singer");		// 演奏者
	        vedioBase.add("Performer");		// 演唱者
	        vedioBase.add("Authors");		// 作词
	        vedioBase.add("Compose");		// 作曲
	        vedioBase.add("Screenwriter");	// 编剧
	        vedioBase.add("Language_Pronunciation");	// 主讲人
	        vedioBase.add("Voiceover");		// 解说
	        vedioBase.add("Foreignname");	// 外文名
	        vedioBase.add("Aka");			// 又名
	        vedioBase.add("Publishing_Company");	// 发行公司
	        // 发品公司
	        vedioBase.add("Soundtrack");	// 碟数
	        vedioBase.add("Media");			// 介质
	           // 来源
	        vedioBase.add("Package");		// 包装
	        vedioBase.add("Dregion");		// 地区
	        vedioBase.add("Episode");		// 集数
	        vedioBase.add("Brand");			// 厂牌
	        vedioBase.add("Length");		// 片长
	        vedioBase.add("Region");		// 区码
	        vedioBase.add("Press");			// 出版社
	        vedioBase.add("Production_Company");	// 出品公司
	        vedioBase.add("ReleaseDate");	// 上映日期
	        vedioBase.add("Copyright");		// 版权提供
	        vedioBase.add("Mvd_Wxjz");		// 文像进字
	        // 产品评级
	        vedioBase.add("Audio_Encoding_Chinese");	// 音频格式
	        vedioBase.add("Language_Dubbed");			// 配音语言
	        vedioBase.add("Language_Subtitled");		// 字幕语言
	        vedioBase.add("Screen_Ratio");				// 屏幕比例
	        // 录音模式
	        vedioBase.add("Format");		// 画面色彩
	        vedioBase.add("ISRC"); 			// ISRC
		}
		return vedioBase;
	}
	
	public static  Set<String> getVedioBigFields(){
		if(vedioBig.isEmpty()){
			vedioBig.add("comments");		// 评论
			vedioBig.add("image");			// 商品描述
			vedioBig.add("contentDesc");	// 内容摘要
			vedioBig.add("editerDesc");		// 编辑推荐
			vedioBig.add("catalogue");		// 目录
			vedioBig.add("box_Contents");	// 包装清单
			vedioBig.add("material_Description"); // 特殊说明
			vedioBig.add("manual");			// 说明书
		}
		return vedioBig;
	}

	public static void setBookFields(Map<String, Object> resultMap,
			Integer skuId, Map<String, String> baseMap,
			Map<Integer, Map<String, String>> bigMap) {
		for (String key : bookBase) {
			if(baseMap.containsKey(key)){
				resultMap.put(key, baseMap.get(key));
			}
			
		}
        // 加入大字段
        if(bigMap == null || bigMap.get(skuId) == null){
        	return;
        }
        for (String key : bookBig) {
        	if(bigMap.get(skuId).containsKey(key)){
        		resultMap.put(key, bigMap.get(skuId).get(key));
        	}
		}
	}

	public static void setVedioFields(Map<String, Object> resultMap,
			Integer skuId, Map<String, String> baseMap,
			Map<Integer, Map<String, String>> bigMap) {
		for (String key : vedioBase) {
			if(baseMap.containsKey(key)){
				resultMap.put(key, baseMap.get(key));
			}
		}
        // 加入大字段
        if(bigMap == null || bigMap.get(skuId) == null){
        	return;
        }
        for (String key : vedioBig) {
        	if(bigMap.get(skuId).containsKey(key)){
        		resultMap.put(key, bigMap.get(skuId).get(key));
        	}
		}
	}
}
