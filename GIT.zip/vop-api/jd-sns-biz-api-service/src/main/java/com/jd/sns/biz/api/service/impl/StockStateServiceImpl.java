package com.jd.sns.biz.api.service.impl;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.jd.service.rpc.RpcContext;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.Sku;
import com.jd.sns.biz.api.domain.SkuList;
import com.jd.sns.biz.api.entity.service.BizCommonQueryService;
import com.jd.sns.biz.api.manager.BizPoolSkuManager;
import com.jd.sns.biz.api.service.StockStateService;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.domain.StringResult;
import com.jd.sns.biz.api.service.utils.OrderConvertUtils;
import com.jd.stock.domain.AreaStockStateWithNum;
import com.jd.stock.domain.SkuNum;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="stockStateService")
public class StockStateServiceImpl implements StockStateService{

	//private com.jd.stock.dubbo.api.StockStateService jdStockStateService;
	private BizCommonQueryService jdStockStateService;
//	private static final Logger log = LoggerFactory.getLogger(StockStateServiceImpl.class);
	private static String token = null;
	private static Integer MAX_SERACH_NUM=100;
	private BizPoolSkuManager bizPoolSkuManager;
	
	private String seed;
	private String content;
	
	@Override
	public String getStockByIds(String sku,String area) {
		CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.GET_STOCK_BY_IDS,false,true);
		StringResult result = new StringResult();
		result.setSuccess(false);
		try{
			if(StringUtils.isBlank(sku) || StringUtils.isBlank(area)){
				result.setResultMessage("参数不正确，sku或者area不能为空");
				return APIUtils.parseObject2Json(result);
			}
			SkuNum skuNum = null;
			List<SkuNum> list = new ArrayList<SkuNum>();
			String [] idsArr = sku.split(",");
			if(idsArr.length > MAX_SERACH_NUM){
				result.setResultMessage("sku数量过多，目前最大支持"+MAX_SERACH_NUM+"个商品");
				return APIUtils.parseObject2Json(result);
			}
			Set<Long> skuIdSet = OrderConvertUtils.skuIdsToSet(idsArr);
			List<Long> illegalSkus = bizPoolSkuManager.checkCanBySkuIds(skuIdSet, APIUtils.getClientId());
            Set<Long> iSkuSets = new HashSet<Long>(illegalSkus);
            
			for(int i=0;i<idsArr.length;i++){
				if(!iSkuSets.contains(Long.parseLong(idsArr[i]))){ //商品池中有该sku
					skuNum = new SkuNum();
					skuNum.setNum(1);
					skuNum.setSkuId(Integer.parseInt(idsArr[i]));
					list.add(skuNum);
				}else{
					result.setResultMessage(result.getResultMessage() + idsArr[i] +"不在您的商品池中");
				}
			}
			
			result.setSuccess(true);
			RpcContext.getContext().setAttachment("token", getToken());
			if(list.size() > 0){
				CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDSTOCKSTATESERVICE_QUERYSTOCKSTATELISTBYAREA, false, true);
				result.setResult(jdStockStateService.queryStockStateListByArea(list, area, "bizapi"));
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "获取库存状态接口异常	sku={} 	area={}",sku ,area);
			result.setResult(null);
			result.setResultMessage("服务异常，请稍后重试");
		}finally{
			Profiler.registerInfoEnd(callerInfo2);
		}
		Profiler.registerInfoEnd(callerInfo2);
		return APIUtils.parseObject2Json(result);
	}
	
	@Override
	public String getNewStockByIds(String skuNums, String area, String appId) {
		CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.GET_NEW_STOCK_BY_IDS,false,true);
		StringResult result = new StringResult();
		result.setSuccess(false);		
		try {
			//0.参数校验
			if(StringUtils.isBlank(skuNums) || StringUtils.isBlank(area)){
				result.setResultMessage("参数不正确，skuNums或者area不能为空");
				return APIUtils.parseObject2Json(result);
			}		
			List<LinkedHashMap<String,Object>> skuNumList=APIUtils.parseJson2Object(skuNums, List.class);			
			List<SkuNum> skuNumsList=new ArrayList<SkuNum>();
			if(CollectionUtils.isEmpty(skuNumList)){
				result.setResultMessage("参数不正确，输入的参数skuNums格式不正确");
				return APIUtils.parseObject2Json(result);
			}
			if(skuNumList.size()>MAX_SERACH_NUM){
				result.setResultMessage("sku数量过多，目前最大支持"+MAX_SERACH_NUM+"个商品");
				return APIUtils.parseObject2Json(result);
			}
			
			Set<Long> skuIdSet = OrderConvertUtils.skuNumsListToSet(skuNumList);
			List<Long> illegalSkus = bizPoolSkuManager.checkCanBySkuIds(skuIdSet, APIUtils.getClientId());
            Set<Long> iSkuSets = new HashSet<Long>(illegalSkus);
            
			for(LinkedHashMap<String,Object> e:skuNumList){	
				Integer skuId=Integer.valueOf(e.get("skuId").toString());
				Integer num=Integer.valueOf(e.get("num").toString());
				//skuId和num校验
				if(skuId==null || num==null ||num<1){
					result.setResultMessage(result.getResultMessage()+e.get("skuId").toString()+" skuId或num输入非法：非整数或商品数量小于1");
					continue;
				}				
				if(iSkuSets.contains(Long.valueOf(skuId))){
					result.setResultMessage(result.getResultMessage() +skuId +"不在您的商品池中 ");
					continue;					
				}else{
					SkuNum skuNum=new SkuNum();
					skuNum.setSkuId(skuId);
					skuNum.setNum(num);
					skuNumsList.add(skuNum);
				}				
			}
			//2.调用库存组接口
			if (CollectionUtils.isNotEmpty(skuNumsList)) {
				List<AreaStockStateWithNum> stockList=new ArrayList<AreaStockStateWithNum>();
				CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDSTOCKSTATESERVICE_QUERYSTOCKSTATELISTBYAREA,false,true);
				String stockResult=null;
				try {
					RpcContext.getContext().setAttachment("token", getToken());
					stockResult = jdStockStateService.queryStockStateListByAreaNew(skuNumsList, area, appId/*CLIENT_TOKEN*/);
				} catch (Exception e1) {
					Profiler.functionError(callerInfo);
					LogTypeEnum.DEFAULT.error(e1,"");
					throw new RuntimeException(e1);
				}
				Profiler.registerInfoEnd(callerInfo);
				if(StringUtils.isNotBlank(stockResult)){
					stockList=convertResult(stockResult);
				}
				result.setSuccess(true);
				result.setResult(APIUtils.parseObject2Json(stockList));
			}
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"调用skuId和num获取库存状态错误");
			result.setSuccess(false);
			result.setResultMessage("调用skuId和num获取库存状态错误");
			Profiler.functionError(callerInfo2);
		}finally{
			Profiler.registerInfoEnd(callerInfo2);
		}
		return APIUtils.parseObject2Json(result);
	}	
	
	/**
	 * 封装业务方需要的结果
	 * @param result
	 * @return
	 */
	private List<AreaStockStateWithNum> convertResult(String result){
		List<AreaStockStateWithNum> stockList=new ArrayList<AreaStockStateWithNum>();
		List<Map<String,String>> resultList=APIUtils.parseJson2Object(result, List.class);
		if(CollectionUtils.isNotEmpty(resultList)){
			for(Map<String,String> elem:resultList){
				Integer skuId=Integer.valueOf(elem.get("sku"));
				Integer stockStateId=Integer.valueOf(elem.get("state"));
				Integer remainNum=Integer.valueOf(elem.get("rNum"));				
				AreaStockStateWithNum stockState=new AreaStockStateWithNum();
				stockState.setSkuId(skuId);
				stockState.setAreaId(elem.get("area"));
				stockState.setStockStateId(stockStateId);
				stockState.setStockStateDesc(elem.get("desc"));
				stockState.setRemainNum(remainNum);
				stockList.add(stockState);
			}			
		}
		return stockList;
	}

	
	/**
	  	33		有货	现货-下单立即发货
		39		有货	在途-正在内部配货，预计2~6天到达本仓库
		40		有货	可配货-下单后从有货仓库配货
		36		预订
		34		无货
	 */
	@Override
	public MapResult checkSkuStock(String skuString, String area, MapResult result) {
		List<SkuNum> listNum = new ArrayList<SkuNum>();
		SkuNum skuNum = null;
		SkuList skuList = APIUtils.parseJson2Object("{\"sku\":"+skuString+"}", SkuList.class);
		List<Sku> list = skuList.getSku();
		for(int i = 0;i< list.size();i++){
			Sku sku = list.get(i);
			skuNum = new SkuNum();
			skuNum.setNum(sku.getNum());
			skuNum.setSkuId(((int)sku.getSkuId()));
			listNum.add(skuNum);
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDSTOCKSTATESERVICE_QUERYSTOCKSTATELISTBYAREA, false, true);
		String stockResult=null;
		try {
			RpcContext.getContext().setAttachment("token", getToken());
			stockResult = jdStockStateService.queryStockStateListByArea(listNum, area, "bizapi");
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"jdStockStateService.queryStockStateListByArea -ERROR");
			throw new RuntimeException(e);
		}
		Profiler.registerInfoEnd(callerInfo);
		List listResult = APIUtils.parseJson2Object(stockResult, List.class);
		result.setSuccess(true);
		for(int i=0;i< listResult.size() ; i++){
			Map map = (Map)listResult.get(i);
			if("34".equals(map.get("state").toString())){
				result.setSuccess(false);
				result.setResultMessage(result.getResultMessage()+map.get("sku").toString()+"无货,");
			}
		}		
		return result;
	}
	
	private String getToken() {
		if(StringUtils.isNotBlank(token)){
			return token;
		}
		String result = "";
		if (!"".equals(seed) && !"".equals(content)) {
			try {
				MessageDigest md = MessageDigest.getInstance("MD5");
				md.update((content + "-" + seed).getBytes());
				byte b[] = md.digest();
				result = new String(new sun.misc.BASE64Encoder().encode(b));
				token = result;
			} catch (NoSuchAlgorithmException e) {
			}
		}
		return result;
	}
	public void setJdStockStateService(BizCommonQueryService jdStockStateService) {
		this.jdStockStateService = jdStockStateService;
	}

	public void setSeed(String seed) {
		this.seed = seed;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setBizPoolSkuManager(BizPoolSkuManager bizPoolSkuManager) {
		this.bizPoolSkuManager = bizPoolSkuManager;
	}

}
