package com.jd.sns.biz.api.service.oauth2.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jd.common.util.StringUtils;
import com.jd.common.web.result.Result;
import com.jd.service.user.uid.UserUidService;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.ApiConstants;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.manager.oauth2.Oauth2Manager;
import com.jd.sns.biz.api.redis.JdCacheUtils;
import com.jd.sns.biz.api.service.oauth2.Oauth2Service;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="oauth2Service")
public class Oauth2ServiceImpl implements Oauth2Service {
	private static final Logger log = LoggerFactory.getLogger(Oauth2ServiceImpl.class);
	
	private Oauth2Manager oauth2Manager;
	private JdCacheUtils redisUtils;
	private UserUidService userUidService;

	@Override
	public Result checkVisitLoginPageParams(User user, Result result) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_VISIT_LOGIN_PAGE_PARAMS,false,true);
		try {
			User dbUser = oauth2Manager.getUser(user.getClient_id());
			if(dbUser == null){
				result.setSuccess(false);
				result.setResultCode(ApiConstants.returnValue.APPID_ERROR);			
				return result;
			}
			
			if(!dbUser.getRedirect_uri().equals(user.getRedirect_uri())){
				result.setSuccess(false);
				result.setResultCode(ApiConstants.returnValue.REDIRECT_URI_ERROR);
				return result;
			}
			
			result.setSuccess(true);
			result.setResultCode(ApiConstants.returnValue.OK);
			result.addDefaultModel("user", dbUser);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			log.error("Oauth2ServiceImpl.checkVisitLoginPageParams -ERROR", e);
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return result;
	}

	@Override
	public Result checkGetTokenParam(User user, Result result) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_GET_TOKEN_PARAM,false,true);
		result.setSuccess(false);
		try {
			if(StringUtils.isBlank(user.getClient_id())){
				result.setResultCode(ApiConstants.returnValue.APPID_ERROR);
				return result;
			}
			if(StringUtils.isBlank(user.getClient_secret())){
				result.setResultCode(ApiConstants.returnValue.CLIENT_SECRET_ERROR);
				return result;
			}		
			//判断前台参数，是否正确
			User dbUser = oauth2Manager.getUser(user.getClient_id());
			if(dbUser == null){
				result.setSuccess(false);
				result.setResultCode(ApiConstants.returnValue.APPID_ERROR);
				return result;
			}
			if(StringUtils.isNotBlank(user.getRedirect_uri()) && !"1".equals(user.getRedirect_uri()) && !user.getRedirect_uri().equals(dbUser.getRedirect_uri())){
				result.setSuccess(false);
				result.setResultCode(ApiConstants.returnValue.REDIRECT_URI_ERROR);
				return result;
			}
			if(!dbUser.getClient_id().equals(user.getClient_id())){
				result.setSuccess(false);
				result.setResultCode(ApiConstants.returnValue.CLIENT_SECRET_ERROR);
				return result;
			}
			if(!dbUser.getClient_secret().equals(user.getClient_secret())){
				result.setSuccess(false);
				result.setResultCode(ApiConstants.returnValue.CLIENT_SECRET_ERROR);
				return result;
			}
			result.setSuccess(true);
			result.setResultCode(ApiConstants.returnValue.OK);
			result.addDefaultModel("user", dbUser);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			log.error("Oauth2ServiceImpl.checkGetTokenParam -ERROR", e);
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return result;
	}
	
	public void setOauth2Manager(Oauth2Manager oauth2Manager) {
		this.oauth2Manager = oauth2Manager;
	}

	@Override
	public Map<String, Object> createAccessToken(User user, String pin) throws Exception {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CREATE_ACCESS_TOKEN,false,true);
		Map<String, Object> result=null;
		try {
			Long current = System.currentTimeMillis();
			result = new HashMap<String, Object>();
			AccessToken at = new AccessToken();
			at.setClient_id(user.getClient_id());
			at.setCreated(new Date(current));
			at.setExpires_in(86400);//access_token的过期时间时24小时
			at.setGrant_type(user.getGrant_type());
			at.setPin(pin);
			at.setScope(user.getScope());
			// 获取用户uid
			at.setUid(this.getUidByPin(pin));
			
			at.setRefresh_token_expires(new Date(current+15724800000l));
			at.setAccess_token(this.createAccessToken(at));
			at.setRefresh_token(this.createRefreshToken(at));
			oauth2Manager.createAccessToken(at);
			
			//将access_token和refresh_token放入缓存中
			this.putInRedis(at);
			result.put("uid", at.getUid());
			result.put("access_token", at.getAccess_token());
			result.put("refresh_token", at.getRefresh_token());
			result.put("time", current);
			result.put("expires_in", at.getExpires_in());
			result.put("refresh_token_expires", at.getRefresh_token_expires().getTime());
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			log.error("Oauth2ServiceImpl.createAccessToken -ERROR", e);
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return result;
	}
	
	@Override
	public AccessToken checkToken(String token) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_TOKEN,false,true);
		if(StringUtils.isBlank(token)){
			return null;
		}
		try {
			String redisToken = redisUtils.get("access_token_"+token);
			if(StringUtils.isBlank(redisToken)){
				return null;
			}
			AccessToken at = APIUtils.parseJson2Object(redisToken, AccessToken.class);
			return at;
		} catch (Exception e) {
			log.error("Oauth2ServiceImpl.checkToken -ERROR", e);
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}

	@Override
	public AccessToken getAccessTokenByRefreshToken(String refreshToken) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_ACCESS_TOKEN_BY_REFRESH_TOKEN,false,true);
		try {
			if(StringUtils.isBlank(refreshToken)){
				return null;
			}		
			String redisToken = redisUtils.get("refresh_token_"+refreshToken);
			if(StringUtils.isNotBlank(redisToken)){
				return APIUtils.parseJson2Object(redisToken, AccessToken.class);
			}
			return oauth2Manager.getAccessToken(refreshToken);
		} catch (Exception e) {
			log.error("Oauth2ServiceImpl.getAccessTokenByRefreshToken -ERROR", e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
	
	@Override
	public Map<String, Object> refreshToken(AccessToken at) throws Exception {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.REFRESH_TOKEN,false,true);
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			try {
				at.setAccess_token(this.createAccessToken(at));
			} catch (Exception e) {
				log.error("Oauth2ServiceImpl.refreshToken -ERROR", e);
				Profiler.functionError(callerInfo);
				return null;
			}
			
			Long current = System.currentTimeMillis();
			result.put("uid", at.getUid());
			result.put("access_token", at.getAccess_token());
			result.put("refresh_token", at.getRefresh_token());
			result.put("time", current);
			result.put("expires_in", at.getExpires_in());
			result.put("refresh_token_expires", at.getRefresh_token_expires().getTime());
			
			putInRedis(at);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			log.error("Oauth2ServiceImpl.refreshToken -ERROR", e);
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return result;
	}
	
	/**
	 * 将access token 放进缓存中
	 * @param at
	 * @param isRefresh 是否是刷新access token ，如果是的话，不刷新refresh 的redis
	 * @throws Exception
	 */
	private void putInRedis(AccessToken at) throws Exception{
//		redisUtils.setex("access_token_" + at.getAccess_token(), at.getExpires_in(), APIUtils.parseObject2Json(at));
		redisUtils.setStringByExpire("access_token_" + at.getAccess_token(), APIUtils.parseObject2Json(at), at.getExpires_in(), TimeUnit.SECONDS);
		try{
			//refresh_token在redis里面存放30天
//			redisUtils.setex("refresh_token_" + at.getRefresh_token(), 60*60*24*30, APIUtils.parseObject2Json(at));
			redisUtils.setStringByExpire("refresh_token_" + at.getRefresh_token(), APIUtils.parseObject2Json(at), 60*60*24*30, TimeUnit.SECONDS);
		}catch (Exception e) {
			log.error("Oauth2ServiceImpl.putInRedis -ERROR", e);
		}
	}
	
	private synchronized String createAccessToken(AccessToken at) throws Exception{
		String key = RandomStringUtils.random(25, true, true);
		while(redisUtils.exists("access_token_"+key)){
			key = RandomStringUtils.random(25, true, true);
			//TODO 加一个UMP监控。进这里面就立即报警
		}
		return key;
	}
	
	private synchronized String createRefreshToken(AccessToken at) throws Exception{
		String value = RandomStringUtils.random(40, true, true);
		while(redisUtils.exists("refresh_token_"+value)){
			value = RandomStringUtils.random(40, true, true);
			//TODO 加一个UMP监控。进这里面就立即报警
		}
		return value;
	}
	
	private String getUidByPin(String pin){
		return userUidService.getUidByPin(pin);
	}


	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

	public void setUserUidService(UserUidService userUidService) {
		this.userUidService = userUidService;
	}

}
