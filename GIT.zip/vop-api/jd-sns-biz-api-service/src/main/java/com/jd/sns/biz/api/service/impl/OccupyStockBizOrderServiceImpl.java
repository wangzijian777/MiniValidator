package com.jd.sns.biz.api.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;



import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jd.bigcustomer.corelog.api.KaCorelog;
import com.jd.common.util.StringUtils;
import com.jd.ka.price.soa.sdk.enums.PriceType;
import com.jd.ka.price.soa.sdk.vo.response.QRTPriceRespVO;
import com.jd.ka.price.soa.sdk.vo.response.RTPriceVO;
import com.jd.ka.user.soa.Refer.Refer;
import com.jd.ka.user.soa.domain.ContractInfo;
import com.jd.ka.user.soa.domain.ErpContractInfo;
import com.jd.ka.user.soa.exception.BizUserSoaException;
import com.jd.ka.user.soa.service.clientInfo.ClientInfoService;
import com.jd.ka.user.soa.service.contractInfo.ContractInfoService;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.JsonUtils;
import com.jd.sns.biz.api.common.utils.LogBusinessIdUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.CacheConstant;
import com.jd.sns.biz.api.constant.KaLogConstants;
import com.jd.sns.biz.api.constant.OrderConstants;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.AbstractInvoiceInfo;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.IVatQualification;
import com.jd.sns.biz.api.domain.Sku;
import com.jd.sns.biz.api.domain.SkuList;
import com.jd.sns.biz.api.entity.service.BizOrderCommonService;
import com.jd.sns.biz.api.enumtype.ErrorCodeEnum;
import com.jd.sns.biz.api.enumtype.InvoiceStateNew;
import com.jd.sns.biz.api.enumtype.InvoiceType;
import com.jd.sns.biz.api.order.exception.BizOrderServiceException;
import com.jd.sns.biz.api.redis.JdCacheUtils;
import com.jd.sns.biz.api.service.BaseOrderService;
import com.jd.sns.biz.api.service.InvoiceService;
import com.jd.sns.biz.api.service.OccupyStockBizOrderService;
import com.jd.sns.biz.api.service.ProductService;
import com.jd.sns.biz.api.service.UserService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.utils.GiftCheckUtils;
import com.jd.sns.biz.api.service.utils.MmbTypeCheckUtils;
import com.jd.sns.biz.api.service.utils.OrderConvertUtils;
import com.jd.sns.biz.api.service.utils.OrderDownDealUtils;
import com.jd.sns.biz.api.service.utils.OrderValidateUtils;
import com.jd.sns.biz.common.enumtype.SourceType;
import com.jd.sns.biz.order.domain.BizOrderQuery;
import com.jd.sns.biz.order.domain.BizOrderSku;
import com.jd.sns.biz.order.domain.OrderInfo;
import com.jd.sns.biz.order.domain.OrderInvoiceInfo;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="occupyStockBizOrderService")
public class OccupyStockBizOrderServiceImpl implements OccupyStockBizOrderService{
	private BaseOrderService baseOrderService;
	private JdCacheUtils redisUtils;
	private InvoiceService invoiceService;
	/**用户信息service*/
	private UserService userService;
	private ClientInfoService clientInfoService;
	private ContractInfoService contractInfoService;
	private OrderDownDealUtils orderDownDealUtils;	
	//新下单接口 vxp
	private BizOrderCommonService bizOrderCommonService;
	private String rule;
	private Pattern pattern;
	private MmbTypeCheckUtils mmbTypeCheckUtils;
	private ProductService productService;
	private GiftCheckUtils giftCheckUtils;
	
	@Override
	public String submitOrder(BizOrder bizOrder,AbstractInvoiceInfo invoiceInfo) {
		CallerInfo callerInfoSubmitOrder=Profiler.registerInfo(UMPFunctionKeyConstant.SUBMIT_ORDER,false,true);
		MapResult result = new MapResult();
		result.setSuccess(true);
		try {
			//1.获取clientId、pin
			String clientId= APIUtils.getClientId();
			String pin = bizOrder.getPin();
			boolean isUseOldGift = giftCheckUtils.isUseOldGift(clientId); //true 代表客户还没替换赠品下单接口， false代表已替换赠品下单接口
			
			//2、判断输入参数是否正确
			result = this.checkSubimeParam(bizOrder, result);
			if (!result.isSuccess()) {
				return APIUtils.parseObject2Json(result);
			}
			
			//3、判断了sku是否在商品池中
			result = checkSkuListExist(bizOrder, result);
			if (!result.isSuccess()) {
				return APIUtils.parseObject2Json(result);
			}
			
			//4、增票信息获取
			IVatQualification qualification= getQualification(result, bizOrder, invoiceInfo, clientId, pin);
			if (!result.isSuccess()) {
				return APIUtils.parseObject2Json(result);
			}
			
			//5、获取并转换skulist、并获取sku价格
			List<RTPriceVO> priceSnapRespVos = new ArrayList<RTPriceVO>();
			SkuList skuList = getSkuList(result, bizOrder , priceSnapRespVos);
			if (!result.isSuccess()) {
				return APIUtils.parseObject2Json(result);
			}
			

			//6、合同权限相关校验 			
			ErpContractInfo erpContractInfo = checkWithContract(result, clientId, pin, bizOrder, isUseOldGift, skuList);
			if (!result.isSuccess()) {
				return APIUtils.parseObject2Json(result);
			}
			
			//7、组装要提交的bizOrder
			BizOrder dbBizOrder = getDbOrder(bizOrder);
			
			//8、计算订单金额
			BigDecimal orderPrice = baseOrderService.calculateOrderPrice(skuList);
			dbBizOrder.setOrderPrice(orderPrice); 
			
			//9、组装下单需要参数，含运费计算
			// TODO 延保产品是否要算运费
			OrderInfo orderInfo = getOrderParam(dbBizOrder, invoiceInfo, qualification, erpContractInfo, skuList);
			
			//10、调用vop-soa下单接口
			OrderInfo orderInfoResult = submitOrderToSoa(result, orderInfo, priceSnapRespVos, dbBizOrder);
			if (!result.isSuccess()) {
				return APIUtils.parseObject2Json(result);
			}
			if(orderInfoResult == null){
				result.setResultMessage("下单失败，请重新下单");
				result.setSuccess(false);
				LogTypeEnum.SUBMIT_ORDER_LOG.error("下单时调用订单接口异常!clientId:{},pin:{},thirdOrder:{}",clientId,pin,bizOrder.getThirdOrder());
				return APIUtils.parseObject2Json(result);
			}
			
			//11、将订单信息放缓存
			try{
				//将订单信息放在缓存中
				redisUtils.setStringByExpire("order-"+orderInfoResult.getJdOrderId(), "ok", 60*60*24*30, TimeUnit.SECONDS);
			}catch (Exception e) {
				LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"将订单信息放在缓存中出错	订单号：{}",orderInfoResult.getJdOrderId());
			}
			
			//12、重复下单提示
			if(orderInfoResult.getSourceType() == 100){ //重复下单
				LogTypeEnum.SUBMIT_ORDER_LOG.error("{}重复下单了！",bizOrder.getThirdOrder() );
				result.setResult(OrderConvertUtils.returnSubmitOrderSuccess(orderInfoResult,mmbTypeCheckUtils.isNeedFreight(clientId), isUseOldGift));
				result.setResultMessage("下订单失败，原因：重复下单");
				result.setSuccess(false);
				result.setResultCode(ErrorCodeEnum.REPEAT_SUBMIT.getType());
				return APIUtils.parseObject2Json(result);
			}
			
			//13、下单成功信息返回
			result.setResult(OrderConvertUtils.returnSubmitOrderSuccess(orderInfoResult,mmbTypeCheckUtils.isNeedFreight(clientId),isUseOldGift));
			result.setResultMessage("下单成功！");
			LogTypeEnum.SUBMIT_ORDER_LOG.info("下单成功,orderId:{},pin:{},sku:{}",orderInfoResult.getJdOrderId(),bizOrder.getPin(),bizOrder.getSku());
			KaCorelog.event(KaLogConstants.KA_LOG_KEY,bizOrder.getThirdOrder(),KaLogConstants.KA_LOG_BUSSINESS_ORDER_END,KaLogConstants.KA_LOG_CALLER,"业务标示ID:"+LogBusinessIdUtils.getCurBusinessId()+",下单成功，订单号:"+orderInfoResult.getJdOrderId());
			result.setSuccess(true);
			return APIUtils.parseObject2Json(result);
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"下订单异常,pin:{},sku:{}"+bizOrder.getPin(),bizOrder.getSku());
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfoSubmitOrder);
		}finally{
			Profiler.registerInfoEnd(callerInfoSubmitOrder);
		}
		result.setSuccess(false);
		return APIUtils.parseObject2Json(result);

	}
	
	private BigDecimal getFrieght(List<Sku> skus, BizOrder bizOrder){
		//非买卖宝类客户运费直接返回null
		if(!mmbTypeCheckUtils.isNeedFreight(bizOrder.getClientId())){
			return null;
		}
		BigDecimal freight = getBaseFreight(bizOrder);
		freight = freight.add(getFarawayFreight(skus, bizOrder));
		return freight;
	}
	
	/**
	 * 基本运费
	 * @param bizOrder
	 * @return
	 */
	private BigDecimal getBaseFreight(BizOrder bizOrder){
		//金额小于59,收运费5元
		if( bizOrder.getOrderPrice().compareTo(BigDecimal.valueOf(mmbTypeCheckUtils.getFreightFree())) < 0 ){ 
			return BigDecimal.valueOf(mmbTypeCheckUtils.getBaseFreight());
		}
		return BigDecimal.ZERO;
	}
	
	/**
	 * 偏远地区运费
	 * @param skus
	 * @param bizOrder
	 * @return
	 */
	private BigDecimal getFarawayFreight(List<Sku> skus, BizOrder bizOrder){
		BigDecimal freight = BigDecimal.ZERO;
		//判断是否偏远地区
		if(!mmbTypeCheckUtils.isNeedFarawayFreight(bizOrder.getProvince(), bizOrder.getCity(), bizOrder.getCounty(), bizOrder.getTown())){
			return freight;
		}
		//查询sku是否加收偏远运费
		Map<Long, Map<String, String>> map = productService.getExtendInfo(skus);
		if(map==null || map.size()==0){//map为空
			LogTypeEnum.SUBMIT_ORDER_LOG.error("没有查询到偏远地区运费信息!clientId:{},pin:{},thirdOrder:{}",bizOrder.getClientId(),bizOrder.getPin(),bizOrder.getThirdOrder());
			return freight;
		}
		//计算订单应收偏远运费金额
		for(Sku sku : skus){
			if(map.containsKey(sku.getSkuId()) && "1".equals(map.get(sku.getSkuId()).get(OrderConstants.FARAWAY_QUERY))){
				freight = freight.add(BigDecimal.valueOf(sku.getNum()).multiply(BigDecimal.valueOf(mmbTypeCheckUtils.getFarAwayFreight())));
			}else{
				LogTypeEnum.SUBMIT_ORDER_LOG.error("sku没有偏远地区运费属性!clientId:{},pin:{},thirdOrder:{}，sku={}",bizOrder.getClientId(),bizOrder.getPin(),bizOrder.getThirdOrder(),sku.getSkuId());
			}
		}
		return freight;
	}
	
	private OrderInfo submitOrderToSoa(MapResult result, OrderInfo orderInfo, List<RTPriceVO> priceSnapRespVos, BizOrder dbBizOrder) throws Exception{
		OrderInfo orderInfoResult = null;
		CallerInfo callerInfoVxpSubmit =Profiler.registerInfo(UMPFunctionKeyConstant.VXP_SUBMIT_ORDER,false,true);
		try {
			String orderPriceSnap=null;
			if(CollectionUtils.isNotEmpty(priceSnapRespVos)){
				orderPriceSnap=JsonUtils.writeValue(priceSnapRespVos);
			}
			orderInfoResult = bizOrderCommonService.submitOrder(orderInfo,orderPriceSnap);
		} catch (BizOrderServiceException e) {
			result.setResultMessage(e.getReturnMessage());
			result.setSuccess(false);
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"下单时调用订单接口出现业务异常!clientId:{},pin:{},thirdOrder:{}",dbBizOrder.getClientId(),dbBizOrder.getPin(),dbBizOrder.getThirdOrder());
			return null;
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"下单时调用订单接口异常!clientId:{},pin:{},thirdOrder:{}",dbBizOrder.getClientId(),dbBizOrder.getPin(),dbBizOrder.getThirdOrder());
			throw e;
		}finally{
			Profiler.registerInfoEnd(callerInfoVxpSubmit);
		}
		return orderInfoResult;
	}
	
	/**
	 * 组装erp下单参数
	 * @param dbBizOrder
	 * @param invoiceInfo
	 * @param qualification
	 * @param erpContractInfo
	 * @param skuList
	 * @return
	 * @throws Exception
	 */
	private OrderInfo getOrderParam(BizOrder dbBizOrder, AbstractInvoiceInfo invoiceInfo,IVatQualification qualification, ErpContractInfo erpContractInfo,SkuList skuList) throws Exception{
		OrderInfo orderInfo = null;
		OrderInvoiceInfo orderInvoiceInfo = null;
		try {
			orderInvoiceInfo = OrderConvertUtils.convertOrderInvoiceInfo(dbBizOrder, invoiceInfo, qualification);
			List<BizOrderSku> listSku = OrderConvertUtils.convertSkuList(skuList);
			//转换为soa接口需要的orderInfo参数
			orderInfo = OrderConvertUtils.convertBizOrder(dbBizOrder);
			orderInfo.setSkuList(listSku); //skulist
			orderInfo.setOrderInvoiceInfo(orderInvoiceInfo); //invoiceInfo
			orderInfo.setServiceRate(erpContractInfo.getServiceRate());//服务费率
			//added by bjtt 2014-11-10
			orderInfo.setEnterpriseNumber(erpContractInfo.getEnterpriseNumber());//企业编号
			orderInfo.setIsUseOld(false); //是否使用老接口
			BigDecimal freight = getFrieght(skuList.getSku(), dbBizOrder); //运费
			if(freight!=null && freight.compareTo(BigDecimal.ZERO) > 0){
				orderInfo.setFreight(freight);
			}
		} catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"组装下单参数异常!clientId:{},pin:{}",dbBizOrder.getClientId(),dbBizOrder.getPin());
			throw e;
		}
		return orderInfo;
	}
	
	/**
	 * 获取并转换skulist、并获取sku价格
	 * @param result
	 * @param bizOrder
	 * @param priceSnapRespVos
	 * @return
	 * @throws Exception
	 */
	private SkuList getSkuList(MapResult result, BizOrder bizOrder, List<RTPriceVO> priceSnapRespVos) throws Exception{
		SkuList skuList = null;
		try {
			skuList = OrderConvertUtils.parsingSkuList(bizOrder.getSku()); 
			baseOrderService.assembleSkuPrice( bizOrder.getPriceType(), skuList, result,priceSnapRespVos);
			//yizhao 添加获取价格成功判断，未成功返回错误信息；
			if(!result.isSuccess()){	
				return null;
			}
		} catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"获取skulist和价格异常:{},用户->{}",e.getMessage(),bizOrder.getPin());
			throw e;
		}
		return skuList;
	}
	
	/***
	 * 获取增票资质
	 * @param result
	 * @param bizOrder
	 * @param invoiceInfo
	 * @param clientId
	 * @param pin
	 * @return
	 */
	private IVatQualification getQualification(MapResult result, BizOrder bizOrder,AbstractInvoiceInfo invoiceInfo, String clientId, String pin){
		IVatQualification qualification=null;
		// 如果发票不是增票
        if (bizOrder.getInvoiceType() == null ||  bizOrder.getInvoiceType() != InvoiceType.INVOICE_TYPE_ZP.getType()) {
            return null;
        }  
		String key = CacheConstant.getClientQualificationCacheKey(clientId,pin); //获取合同缓存key
		//下单前增票相关功能检查
		try{
			qualification=invoiceService.orderCheck(bizOrder,invoiceInfo);
			if(qualification == null){
				LogTypeEnum.SUBMIT_ORDER_LOG.error("无有效增票资质，用户->{}",bizOrder.getPin());
				result.setSuccess(false);
				result.setResultMessage("无有效增票资质，下单失败");
				return null;
			}
		}catch(BizOrderServiceException e){
			//从缓存读取
			qualification = orderDownDealUtils.getObjectAndRestore(key, com.jd.sns.biz.ws.invoice.VatQualification.class);
			if(qualification == null){
				LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"下订单查检用户增票信息异常:{},用户->{}",e.getMessage(),bizOrder.getPin());
				result.setSuccess(false);
				result.setResultMessage(e.getMessage());
				return qualification;
			}
			return qualification;
		}
		// 设置为null，否则json转实体类会报错
		if(qualification != null){
			qualification.setCreateDate(null);
			qualification.setStartTime(null);
			qualification.setEndTime(null);
			qualification.setUpdateDate(null);
		}
		//缓存增票信息
		orderDownDealUtils.saveObjectToRedis(qualification, key, false);
		return qualification;
	}
	
	/**
	 * 拼装数据库存bizorder
	 * @param bizOrder
	 * @return
	 */
	private BizOrder getDbOrder(BizOrder bizOrder){
		//组装要提交的bizOrder
		BizOrder dbBizOrder = new BizOrder();
		dbBizOrder.setAddress(bizOrder.getAddress());
		dbBizOrder.setCity(bizOrder.getCity());
		dbBizOrder.setClientId(APIUtils.getClientId());
		dbBizOrder.setCounty(bizOrder.getCounty());
		Date now = new Date();
		dbBizOrder.setCreated(now);
		dbBizOrder.setCreateOrderTime(now);//创建订单的时间
		if(bizOrder.getSubmitState() != null && bizOrder.getSubmitState() == 1){
			dbBizOrder.setSubmitOrderTime(now);
		}
		dbBizOrder.setEmail(bizOrder.getEmail());
		dbBizOrder.setJdDemandOrder(bizOrder.getJdDemandOrder());
		dbBizOrder.setMobile(bizOrder.getMobile());
		dbBizOrder.setName(bizOrder.getName()); 
//		dbBizOrder.setOrderPrice(orderPrice); //soa接口计算
		dbBizOrder.setOrderState(0);//0为取消订单 ，1 是正常订单   先在我们的数据库中，下成功一个订单，真正下单成功以后，再把这个字段改为1。代表下单成功
		dbBizOrder.setPhone(bizOrder.getPhone());
		dbBizOrder.setParentId(0); //父订单是0
		dbBizOrder.setPin(APIUtils.getPin());
		dbBizOrder.setProvince(bizOrder.getProvince());
		if(StringUtils.isNotBlank(bizOrder.getRemark()) && bizOrder.getRemark().length() < 100){
			dbBizOrder.setRemark(bizOrder.getRemark());
		}
//		dbBizOrder.setSku(sku); //sku单独进行转换
		dbBizOrder.setState(0); //0 是新下订单	1是妥投 2是拒收
		dbBizOrder.setThirdOrder(bizOrder.getThirdOrder());
		dbBizOrder.setTown(bizOrder.getTown());
		dbBizOrder.setType(2);//下单默认为子订单
		dbBizOrder.setZip(bizOrder.getZip());
		if(StringUtils.isNotBlank(bizOrder.getIp()) && bizOrder.getIp().length() < 20){
			dbBizOrder.setIp(bizOrder.getIp());
		}
		dbBizOrder.setHangUpState(0);//默认不挂起      
		
		dbBizOrder.setSubmitState(bizOrder.getSubmitState());//真正提交订单状态，0为预占库存状态，1为真正下单状态
//		dbBizOrder.setOrderguid(this.createOrderguid(APIUtils.getClientId()));//创建唯一订单唯一标识
		//价格类型，0为协议价，1为京东价
		dbBizOrder.setPriceType(bizOrder.getPriceType());
		//发票信息
		OrderValidateUtils.setBizOrderInvoiceInfo(dbBizOrder, bizOrder);
		
		dbBizOrder.setIsUseBalance(bizOrder.getIsUseBalance());
		dbBizOrder.setPaymentType(bizOrder.getPaymentType());
		
		return dbBizOrder;
	}
	
	/**
	 * 主数据合同权限相关信息校验
	 * @param result
	 * @param clientId
	 * @param pin
	 * @param bizOrder
	 * @return
	 * @throws Exception
	 */
	private ErpContractInfo checkWithContract(MapResult result, String  clientId, String  pin, BizOrder bizOrder,boolean isUseOldGift, SkuList skuList) throws Exception{
		ErpContractInfo erpContractInfo = null;
		CallerInfo callerInfoErpContract =Profiler.registerInfo(UMPFunctionKeyConstant.QUERY_ERP_CONTRACT_INFO,false,true);
		String keyErpContract = CacheConstant.getClientContractCacheKey(clientId); //获取合同缓存key
		try {
			//查询合同相关权限信息
			erpContractInfo = clientInfoService.queryUserClientIdFlag( clientId, pin);
		}catch ( BizUserSoaException e) {
			result.setResultMessage(e.getReturnMessage());
			result.setSuccess(false);
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"权限验证失败---根据clientId查询合同权限信息出错!clientId:{},pin:{}",clientId,pin);
			return null;
		} catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"权限验证失败---根据clientId查询合同权限信息出错!clientId:{},pin:{}",clientId,pin);
			Profiler.functionError(callerInfoErpContract);
			//从缓存获取
			erpContractInfo = orderDownDealUtils.getObjectAndRestore(keyErpContract, ErpContractInfo.class);
			if(erpContractInfo == null){ //获取不到抛异常
				throw e;
			}
		}finally{
			Profiler.registerInfoEnd(callerInfoErpContract);
		}
		
		if(erpContractInfo == null){
			result.setResultMessage("账户权限不足，无法下单，请联系京东!");
			result.setSuccess(false);
			LogTypeEnum.SUBMIT_ORDER_LOG.error("权限验证失败---根据clientId查询权限信息为空!clientId:{}，pin:{}",clientId,pin);
			return null;
		}
		//将合同信息放入redis
		orderDownDealUtils.saveObjectToRedis(erpContractInfo, keyErpContract,false);
		
		// 验证价格类型
		ContractInfo info =  null;
		CallerInfo callerInfoContract =Profiler.registerInfo(UMPFunctionKeyConstant.QUERY_CONTRACT_INFO,false,true);
		String keyContract = CacheConstant.getNumberContractCacheKey(erpContractInfo.getContractNumber()); //获取合同缓存key
		try{
			info = contractInfoService.queryContractInfo(erpContractInfo.getContractNumber(), new Refer());
		}catch ( BizUserSoaException e) {
			result.setResultMessage(e.getReturnMessage());
			result.setSuccess(false);
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"权限验证失败---查询合同信息出错!clientId:{},pin:{}",clientId,pin);
			return null;
		}catch (Exception e){
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e, "验证价格类型异常：{}", pin);
			Profiler.functionError(callerInfoContract);
			//从缓存获取，获取成功则对缓存再保存一次
			info = orderDownDealUtils.getObjectAndRestore(keyContract,ContractInfo.class);
			if(info == null){
				throw e;
			}
		}finally{
			Profiler.registerInfoEnd(callerInfoContract);
		}
		
		if(info == null){
			result.setResultMessage("账户权限不足，无法下单，请联系京东!");
			result.setSuccess(false);
			LogTypeEnum.SUBMIT_ORDER_LOG.error("权限验证失败---根据clientId查询合同信息为空!clientId:{}，pin:{}",clientId,pin);
			return null;
		}
		//将合同信息放入redis
		orderDownDealUtils.saveObjectToRedis(info, keyContract, false);
		
		Integer priceType = info.getOrderPriceType();
		if(priceType == null){
			LogTypeEnum.DEFAULT.error("主数据中价格类型不存在，合同号:{}, 下单接口:{}, 主数据:{}",erpContractInfo.getContractNumber(), bizOrder.getPriceType(), priceType);
			result.setResultMessage("您没有配置所选价格类型权限");
			result.setSuccess(false);
			return null;
		}
		if((bizOrder.getPriceType() == PriceType.JD_PRICE.getType() && priceType != PriceType.JD_PRICE.getType())
				|| (bizOrder.getPriceType() != PriceType.JD_PRICE.getType() && priceType == PriceType.JD_PRICE.getType())){
			// 下单传过来的参数只有两种，一种是京东价下单，一种是协议价下单
			// 京东价下单，要求价格类型必须为京东价，也就是主数据中为1
			// 协议价下单，要求价格类型必须为协议价，也就是主数据中为0,2
			LogTypeEnum.DEFAULT.error("价格类型验证没通过，合同号:{},下单接口:{}, 主数据:{}",erpContractInfo.getContractNumber(), bizOrder.getPriceType(), priceType);
			result.setResultMessage("价格类型验证没通过，您没有所选价格类型下单的权限");
			result.setSuccess(false);
			return null;
		}
		
		bizOrder.setPriceType(priceType);
		
		//校验支付方式
		OrderValidateUtils.validatePaymentType(erpContractInfo.getAccountMode(), bizOrder, result);
		if(!result.isSuccess()){
			result.setResultMessage("支付验证未通过："+result.getResultMessage());
			LogTypeEnum.SUBMIT_ORDER_LOG.error("权限验证失败---支付验证未通过：{},clientId:{},pin:{}",result.getResultMessage(),clientId,pin);
			return null;
		}
		
		//校验发票类型
		OrderValidateUtils.validateInvoiceTypeInfo(erpContractInfo.getInvoiceType(), bizOrder, result);
		if(!result.isSuccess()){
			result.setResultMessage("增票验证未通过："+result.getResultMessage());
			LogTypeEnum.SUBMIT_ORDER_LOG.error("权限验证失败---增票验证未通过：{},clientId:{},pin:{}",result.getResultMessage(),clientId,pin);
			return null;
		}
		
		//校验开票方式
		OrderValidateUtils.validateInvoiceMode(erpContractInfo.getInvoiceMode(), bizOrder, result);
		if(!result.isSuccess()){
			result.setResultMessage("开票方式验证未通过："+result.getResultMessage());
			LogTypeEnum.SUBMIT_ORDER_LOG.error("权限验证失败---开票方式验证未通过：{},clientID:{},pin:{}",result.getResultMessage(),clientId,pin);
			return null;
		}
		
		//校验预占库存权限
		OrderValidateUtils.validateSubmitStateInfo(erpContractInfo.getSpecialType(), bizOrder, result);
		if(!result.isSuccess()){
			result.setResultMessage("预占库存验证未通过："+result.getResultMessage());
			LogTypeEnum.SUBMIT_ORDER_LOG.error("权限验证失败---预占库存验证未通过：{},clientId:{},pin:{}",result.getResultMessage(),clientId,pin);
			return null;
		}
		
		//赠品相关校验
		Integer giftType = OrderConvertUtils.getGiftType(erpContractInfo.getContractAttribute());
		if(isUseOldGift){ //如果客户还没替换接口，直接用主数据配置的是否需要赠品
			if(giftType == 1){
				for(Sku sku: skuList.getSku()){
					sku.setbNeedGift(true);//客户没传，但配置了的 默认需要赠品
				}
			}
		}else{ //使用新接口需要赠品，但是没有主数据权限
			if(giftType == 0){ 
				for(Sku sku: skuList.getSku()){
					if(sku.getbNeedGift()){
						result.setSuccess(false);
						result.setResultMessage("您没有赠品权限，但是选择了需要赠品!");
						LogTypeEnum.SUBMIT_ORDER_LOG.error("权限验证失败---没有赠品权限，但传入需要赠品：{},clientID:{},skuId:{}",result.getResultMessage(),clientId,sku.getSkuId());
						return null;
					}
				}
			}
		}
		
		return erpContractInfo;
	}
	
	@Override
	public String confirmOrder(String jdOrderId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CONFIRM_ORDER,false,true);

		BooleanResult result = new BooleanResult();
		result.setResult(false);
		result.setSuccess(false);
		
		long orderId = 0;
		try{
			orderId = Long.parseLong(jdOrderId);
		}catch (Exception e) {
			result.setResultMessage("jdOrderId格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		
		try{
			String clientId = APIUtils.getClientId();
			BizOrderQuery bizOrderQuery = new BizOrderQuery();
			bizOrderQuery.setJdOrderId(orderId);
			bizOrderQuery.setClientId(clientId);
			bizOrderQuery.setSourceType(SourceType.ORDER_VOP.getType());
			
			boolean flag = bizOrderCommonService.confirmOrder(bizOrderQuery);
			
			if(flag == true){
				LogTypeEnum.SUBMIT_ORDER_LOG.error("确认下单成功	订单号：{}",jdOrderId);
				result.setSuccess(true);
				result.setResult(true);
				result.setResultMessage("确认下单成功");
			}else{
				LogTypeEnum.SUBMIT_ORDER_LOG.error("确认下单最终失败	订单号：{}",jdOrderId);
				result.setResultMessage("确认下单最终失败，请重新取消订单");
			}
			Profiler.registerInfoEnd(callerInfo);
		}catch (BizOrderServiceException e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"");
			result.setResultMessage(e.getReturnMessage());
			Profiler.functionError(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"确认下单接口异常	订单号：{}",jdOrderId);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}
	
	
	/**
	 * 取消未确认预留库存订单
	 */
	@Override
	public String cancel(String jdOrderId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CANCEL,false,true);
		BooleanResult result = new BooleanResult();
		result.setSuccess(false);
		result.setResult(false);
		
		long orderId = 0;
		try{
			orderId = Long.parseLong(jdOrderId);
		}catch (Exception e) {
			result.setResultMessage("jdOrderId格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		
		try{
			String clientId = APIUtils.getClientId();
			BizOrderQuery bizOrderQuery = new BizOrderQuery();
			bizOrderQuery.setJdOrderId(orderId);
			bizOrderQuery.setClientId(clientId);
			bizOrderQuery.setSourceType(SourceType.ORDER_VOP.getType());
//			bizOrderQuery.setPin(APIUtils.getPin());
			
			boolean flag = bizOrderCommonService.cancelUnconfirmedOrder(bizOrderQuery);
			if(flag == true){
				LogTypeEnum.SUBMIT_ORDER_LOG.error("取消订单成功	订单号：{}",jdOrderId);
				result.setSuccess(true);
				result.setResult(true);
				result.setResultMessage("取消订单成功");
			}else{
				LogTypeEnum.SUBMIT_ORDER_LOG.error("取消订单最终失败	订单号：{}",jdOrderId);
				result.setResultMessage("取消订单失败，请重新取消订单");
			}
			Profiler.registerInfoEnd(callerInfo);
		}catch (BizOrderServiceException e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"取消订单出错 订单号：{}",jdOrderId);
			result.setResultMessage(e.getReturnMessage());
			Profiler.functionError(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"取消订单出错 订单号：{}",jdOrderId);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}
		LogTypeEnum.SUBMIT_ORDER_LOG.error("预占库存取消订单流程：订单号{}---------------end----------------",jdOrderId);
		return APIUtils.parseObject2Json(result);
	}
	
	
	private MapResult checkSubimeParam(BizOrder bizOrder, MapResult result) {
		//TODO  cr yz 拆分
		result.setSuccess(false);
		if (StringUtils.isBlank(bizOrder.getThirdOrder())) {
			result.setResultMessage("thirdOrder不能为空");
			return result;
		}
		
		if(bizOrder.getThirdOrder().length() > 100){
			result.setResultMessage("thirdOrder长多过长，必须在100以内");
			return result;
		}
		
		if (StringUtils.isBlank(bizOrder.getSku())) {
			result.setResultMessage("sku不能为空");
			return result;
		}
		if (StringUtils.isBlank(bizOrder.getName())) {
			result.setResultMessage("name不能为空");
			return result;
		}		
		
		if(bizOrder.getName().length() > 20){
			result.setResultMessage("name字数过长");
			return result;
		}
		
		if (bizOrder.getProvince() == 0 || bizOrder.getCity() == 0
				|| bizOrder.getCounty() == 0) {
			result.setResultMessage("地址信息不正确");
			return result;
		}
		if (StringUtils.isBlank(bizOrder.getAddress())) {
			result.setResultMessage("address不能为空");
			return result;
		}
		
		if(bizOrder.getAddress().length() >= 100){
			result.setResultMessage("address长度超常，必须在100以内");
			return result;
		}

//		if (StringUtils.isBlank(bizOrder.getZip())) {
//			result.setResultMessage("zip不能为空");
//			return result;
//		}
		
		if(StringUtils.isNotBlank(bizOrder.getZip()) && bizOrder.getZip().length() > 20){
			result.setResultMessage("zip长度异常");
			return result;
		}

		if (StringUtils.isBlank(bizOrder.getPhone())
				&& StringUtils.isBlank(bizOrder.getMobile())) {
			result.setResultMessage("请填写收货人电话或手机号码");
			return result;
		}
		
		if(StringUtils.isNotBlank(bizOrder.getPhone())){
			if(bizOrder.getPhone().length() > 20){
				result.setResultMessage("phone长度异常");
				return result;
			}
		}
		
		if(StringUtils.isNotBlank(bizOrder.getMobile())){
			if(bizOrder.getMobile().length() > 20){
				result.setResultMessage("mobile长度异常");
				return result;
			}
		}
		
		
		if (StringUtils.isBlank(bizOrder.getEmail())) {
			result.setResultMessage("邮箱不能为空");
			return result;
		}
		
		StringBuffer validContent=new StringBuffer();
		validContent.append(bizOrder.getName()).append(bizOrder.getAddress())
				.append(bizOrder.getCompanyName()).append(bizOrder.getRemark());		
		//特殊字符校验
		String checkResult=hasSpacialChar(validContent.toString());
		if(StringUtils.isNotEmpty(checkResult)){
			result.setResultMessage("下单参数name、address、remark、companyName中含有特殊字符,特殊字符="+checkResult);
			return result;
		}		
		//支付方式 (1：货到付款，2：邮局付款，4：在线支付，5：公司转账，6：银行转账，7 网银钱包  12：月结, 101:金融支付)
		if(bizOrder.getPaymentType() == null || (bizOrder.getPaymentType() != 4 && bizOrder.getPaymentType() != 12 && bizOrder.getPaymentType() != 1
				&& bizOrder.getPaymentType() != 2 && bizOrder.getPaymentType() != 5 && bizOrder.getPaymentType() != 6 && bizOrder.getPaymentType() != 7 && bizOrder.getPaymentType()!=101)){
			result.setResultMessage("支付类型不正确！");
			return result;
		}
		//TODO:bug 若为货到付款下单，则无需进行该校验
		if(bizOrder.getIsUseBalance() == null || (bizOrder.getIsUseBalance() != 0 && bizOrder.getIsUseBalance() !=1)){
			result.setResultMessage("isUseBalance不正确！");
			return result;
		}
		if(bizOrder.getIsUseBalance() == 1 && bizOrder.getPaymentType() == 12){
			result.setResultMessage("支付类型不正确，月结用户不能使用余额下单");
			return result;
		}
		//如果开发票的话
		//if(bizOrder.getInvoiceState() != null && bizOrder.getInvoiceState() == 1)
		if(needToCheckInvoice(bizOrder)){
			List<Integer> invoiceTypes=new ArrayList<Integer>();
			//普票
			invoiceTypes.add(1);
			//增票
			invoiceTypes.add(2);
			if(!invoiceTypes.contains(bizOrder.getInvoiceType())){
				result.setResultMessage("invoiceType不正确，您只能开普通发或增质税发票");
				return result;
			}
			//普通发票
			if(bizOrder.getInvoiceType()==1)
			{
				if(bizOrder.getSelectedInvoiceTitle() == null || (bizOrder.getSelectedInvoiceTitle() != 4 && bizOrder.getSelectedInvoiceTitle() != 5)){
					result.setResultMessage("selectedInvoiceTitle不正确");
					return result;	
				}
				
				if(bizOrder.getSelectedInvoiceTitle() == 5 && StringUtils.isBlank(bizOrder.getCompanyName())){
					result.setResultMessage("发票抬头不能为空");
					return result;	
				}
				
				if(bizOrder.getInvoiceContent() == null || (bizOrder.getInvoiceContent() != 1 && bizOrder.getInvoiceContent() != 3 && bizOrder.getInvoiceContent() != 19
						&& bizOrder.getInvoiceContent() != 22)){
					result.setResultMessage("invoiceContent值不正确");
					return result;	
				}
			}
		}

		result.setSuccess(true);
		return result;
		
	}
	
	private String hasSpacialChar(String content) {
		String result=null;		
		String newRule=redisUtils.get(CacheConstant.CACHE_KEY_SPECIAL_CHAR);
		if(StringUtils.isNotEmpty(newRule)){
			if(!newRule.equals(rule)){
				rule = newRule;
				pattern = Pattern.compile(newRule,Pattern.CASE_INSENSITIVE);
			}
			Matcher matcher = pattern.matcher(content);
			if(matcher.find()){
				 result=matcher.group(0);			 
			}
		}
		return result;
	}
	

	private boolean needToCheckInvoice(BizOrder bizOrder){
		if(bizOrder.getInvoiceState() == null){
			return false;
		}
		//新方式
		if(bizOrder.getInvoiceState() == InvoiceStateNew.SUIHUO_INVOICE.getType()){ 
			//随货
			return true;
		}
		else if(bizOrder != null && bizOrder.getInvoiceType()!=null && bizOrder.getInvoiceType() == 2){
			//集中和预借，且增票
			return true;
		}
		return false;
	}
	
	private MapResult checkSkuListExist(BizOrder bizOrder, MapResult result) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OccupyStockBizOrderServiceImpl.checkSkuListExist", true, true);
		try {
			result = baseOrderService.checkSkuListExist(bizOrder.getSku(), result);
		} catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"checkSkuListExist fail！sku:{}",bizOrder.getSku());
			Profiler.functionError(info);
		}finally{
			Profiler.registerInfoEnd(info);
		}
		
		if (!result.isSuccess()) {
			return result;
		}

		result.setSuccess(true);
		return result;
	}
	

	public void setBaseOrderService(BaseOrderService baseOrderService) {
		this.baseOrderService = baseOrderService;
	}

	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void setInvoiceService(InvoiceService invoiceService) {
		this.invoiceService = invoiceService;
	}

	public void setClientInfoService(ClientInfoService clientInfoService) {
		this.clientInfoService = clientInfoService;
	}
	
	public void setBizOrderCommonService(BizOrderCommonService bizOrderCommonService) {
		this.bizOrderCommonService = bizOrderCommonService;
	}

	
	public void setOrderDownDealUtils(OrderDownDealUtils orderDownDealUtils) {
		this.orderDownDealUtils = orderDownDealUtils;
	}

	public void setContractInfoService(ContractInfoService contractInfoService) {
		this.contractInfoService = contractInfoService;
	}


	public String getRule() {
		return rule;
	}


	public void setRule(String rule) {
		this.rule = rule;
	}


	public Pattern getPattern() {
		return pattern;
	}


	public void setPattern(Pattern pattern) {
		this.pattern = pattern;
	}

	public void setMmbTypeCheckUtils(MmbTypeCheckUtils mmbTypeCheckUtils) {
		this.mmbTypeCheckUtils = mmbTypeCheckUtils;
	}

	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	public void setGiftCheckUtils(GiftCheckUtils giftCheckUtils) {
		this.giftCheckUtils = giftCheckUtils;
	}

}
