package com.jd.sns.biz.api.service.utils;

import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.CacheConstant;
import com.jd.sns.biz.api.redis.JdCacheUtils;

/**
 * 下单降级处理工具类
 * 目前针对 主数据合同 、 主数据erp合同、增票信息
 * @author bjtt
 * @date 2015-4-15
 *
 */

@Service(value="orderDownDealUtils")
public class OrderDownDealUtils {
	private JdCacheUtils redisUtils;
	
	public <T> T getObjectAndRestore(String key, Class<T> clazz){
		T obj = null;
		try {
			if(redisUtils.exists(key)){
				//获取
				obj = redisUtils.getObject(key,clazz);
				LogTypeEnum.SUBMIT_ORDER_LOG.error("读取缓存合同信息成功---key:{}",key);
				//保存
				saveObjectToRedis(obj, key,true);
			}
		} catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"getObjectAndRestore读取缓存信息失败 key:{}",key);
		}
		return obj;
	}

	
	public void saveObjectToRedis(Object obj, String key, boolean force){
		try {
			if(obj!= null && (force || !redisUtils.exists(key))){
				if(redisUtils.setObjectByExpire(key, obj, CacheConstant.TEN_MINUTES, TimeUnit.SECONDS)){
					LogTypeEnum.SUBMIT_ORDER_LOG.error("缓存信息成功---key:{}",key);;
				}
			}
		} catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"缓存信息失败---key:{}",key);
		}
	}
	
	
	
	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

		
	
}
