package com.jd.sns.biz.api.service.utils;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.CacheConstant;
import com.jd.sns.biz.api.redis.JdCacheUtils;


@Service(value = "giftCheckUtils")
public class GiftCheckUtils {	
	@Resource
	private JdCacheUtils redisUtils;
	
	private String value;
	
	public boolean isUseOldGift(String clientId)throws Exception{
		try {
			String value = "," + redisUtils.get(CacheConstant.CACHE_GIFT_USE_OLD_) + ",";
			this.value = value;
			String query = "," + clientId + ",";
			if(value.contains(query)){
				return true;
			}
			return false;
		} catch (Exception e) {
			//读redis出异常，则从内存获取
			return isUseOldGiftFromLocal(clientId);
		}
		
	}

	private boolean isUseOldGiftFromLocal(String clientId){
		LogTypeEnum.SUBMIT_ORDER_LOG.error("从内存中获取是否需要赠品,clientId:{},value:{}",clientId,value);
		String query = "," + clientId + ",";
		if(this.value.contains(query)){
			return true;
		}
		return false;
	}
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
