package com.jd.sns.biz.api.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jd.primitive.client.address.bean.AreaListBeanVO;
import com.jd.primitive.client.address.result.GetAreaListResultVO;
import com.jd.primitive.client.address.service.AreaService;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.service.JdAreaService;
import com.jd.sns.biz.api.service.domain.AreaResult;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


/**
 * 地址服务
 * @author yujianming
 *
 */
@Service(value="jdAreaService")
public class JdAreaServiceImpl implements JdAreaService {
//	private static final Logger log = LoggerFactory.getLogger(JdAreaServiceImpl.class);
	
	private AreaService areaService;
	
	@Override
	public String getProvinces() {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_PROVINCES,false,true);
		AreaResult ar = new AreaResult();
		try{
			GetAreaListResultVO vo = areaService.getProvinces();
			if(vo != null && vo.isSuccess()){
				ar.setSuccess(true);
				ar.setResult(this.Arealist2Map(vo.getAreaList()));
			}else{
				ar.setSuccess(false);
				ar.setResult(null);
				ar.setResultMessage("未找到省级ip列表");
			}
		}catch (Exception e) {
			ar.setSuccess(false);
			ar.setResult(null);
			ar.setResultMessage("网络异常，请重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(ar);
	}
	
	@Override
	public String getCitys(String provinceId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_CITYS,false,true);
		AreaResult ar = new AreaResult();
		int provinceIdInt = 0;
		try{
			provinceIdInt = Integer.parseInt(provinceId);
		}catch (Exception e) {
			ar.setSuccess(false);
			ar.setResultMessage("参数格式不正确");
			return APIUtils.parseObject2Json(ar);
		}
		try{
			GetAreaListResultVO vo = areaService.getCitys(provinceIdInt);
			if(vo != null && vo.isSuccess()){
				ar.setSuccess(true);
				ar.setResult(this.Arealist2Map(vo.getAreaList()));
			}else{
				ar.setSuccess(false);
				ar.setResult(null);
				ar.setResultMessage("根据1级地址id，未查询到2级地址id列表");
			}
		}catch (Exception e) {
			ar.setSuccess(false);
			ar.setResult(null);
			ar.setResultMessage("网络异常，请重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}		
		return APIUtils.parseObject2Json(ar);
	}
	
	@Override
	public String getCountys(String cityId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_COUNTYS,false,true);
		AreaResult ar = new AreaResult();
		int cityIdInt = 0;
		try{
			cityIdInt = Integer.parseInt(cityId);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"JdAreaServiceImpl.getCountys -ERROR");
			ar.setSuccess(false);
			ar.setResult(null);
			ar.setResultMessage("参数格式不正确");
			Profiler.registerInfoEnd(callerInfo);
			return APIUtils.parseObject2Json(ar);
		}
		try{
			GetAreaListResultVO vo = areaService.getCountys(cityIdInt);
			if(vo != null && vo.isSuccess()){
				ar.setSuccess(true);
				ar.setResult(this.Arealist2Map(vo.getAreaList()));
			}else{
				ar.setSuccess(false);
				ar.setResult(null);
				ar.setResultMessage("根据2级地址id列表。未能获取到3级地址id列表");
			}
		}catch (Exception e) {
			ar.setSuccess(false);
			ar.setResult(null);
			ar.setResultMessage("网络异常，请重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}		
		return APIUtils.parseObject2Json(ar);
	}

	@Override
	public String getTowns(String countyId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_TOWNS,false,true);
		AreaResult ar = new AreaResult();		
		int countyIdInt = 0;
		try{
			countyIdInt = Integer.parseInt(countyId);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"JdAreaServiceImpl.getTowns -ERROR");
			ar.setSuccess(false);
			ar.setResult(null);
			ar.setResultMessage("参数格式不正确");
			Profiler.functionError(callerInfo);
			return APIUtils.parseObject2Json(ar);
		}		
		try{
			GetAreaListResultVO vo = areaService.getTowns(countyIdInt);
			if(vo != null && vo.isSuccess()){
				ar.setSuccess(true);
				ar.setResult(this.Arealist2Map(vo.getAreaList()));
			}else{
				ar.setSuccess(false);
				ar.setResult(null);
				ar.setResultMessage("根据3级地址id列表。未能获取到4级地址id列表");
			}
		}catch (Exception e) {
			ar.setSuccess(false);
			ar.setResult(null);
			ar.setResultMessage("网络异常，请重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}		
		return APIUtils.parseObject2Json(ar);
	}
	
	private Map<String, Integer> Arealist2Map(List<AreaListBeanVO> list){
		Map<String, Integer> map = new HashMap<String, Integer>();
		AreaListBeanVO area = null;
		for(int i=0;i<list.size();i++){
			area = list.get(i);
			map.put(area.getName(), area.getId());
		}
		return map;
	}

	public void setAreaService(AreaService areaService) {
		this.areaService = areaService;
	}

}
