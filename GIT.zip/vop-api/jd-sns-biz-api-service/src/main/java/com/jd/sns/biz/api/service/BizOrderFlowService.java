package com.jd.sns.biz.api.service;

public interface BizOrderFlowService {
	public String submit(String jdOrderId, String workType, String workInfo);
	
	public String select(String jdOrderId);
	
	public String cancel(String jdOrderId);
}
