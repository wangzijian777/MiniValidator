package com.jd.sns.biz.api.service;

import com.jd.fce.orb.domain.CancelOrderDetail;

public interface KuaiTuiRefService {
	CancelOrderDetail queryCancelStepsByOrderId(long jdOrderId, String pin);
}
