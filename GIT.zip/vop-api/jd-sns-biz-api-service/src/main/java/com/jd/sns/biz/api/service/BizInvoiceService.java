package com.jd.sns.biz.api.service;

import com.jd.sns.biz.api.domain.BizInvoice;

public interface BizInvoiceService {
	public String submit(BizInvoice bizInvoice);
	
	public String select(String markId);
}
