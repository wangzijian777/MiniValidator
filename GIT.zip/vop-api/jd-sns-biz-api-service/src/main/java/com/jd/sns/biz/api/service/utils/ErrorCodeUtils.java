package com.jd.sns.biz.api.service.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * 错误码转换工具类
 */
public class ErrorCodeUtils {
	/**
	 * key 发票系统错误码
	 * value vop对外提供错误码
	 *
	 */
	private final static Map<Integer,String> errorCodeMap = new HashMap<Integer,String>();
	
	 static {
		errorCodeMap.put(200, "0000"); //200操作成功
		errorCodeMap.put(2001, "1004"); //2001 第三方申请单号重复
		errorCodeMap.put(2002, "1004"); //2002 同一第三方申请单号下的批次号重复
		errorCodeMap.put(2003, "1004"); //2003 订单号重复
		errorCodeMap.put(2004, "3301"); //2004 传输中
		errorCodeMap.put(2005, "3301"); //2005 待确认
		errorCodeMap.put(2006, "3303"); //2006 审核中 
		errorCodeMap.put(2007, "3302"); //2007 驳回
		errorCodeMap.put(2008, "0010"); //2008 没有可查阅的发票数据
		errorCodeMap.put(2009, "0005"); //2009 部分发票可查阅
		errorCodeMap.put(2010, "0004"); //2010 全部发票可查阅 
		errorCodeMap.put(2011, "0008");//2011,"当前第三方申请单已经传输完成"
		errorCodeMap.put(9000, "1001"); //9000 参数不能为空
		errorCodeMap.put(9001, "3304"); //9001第三方申请单不存在
		errorCodeMap.put(9002, "2001"); //9002 企业pin不一致
		errorCodeMap.put(9003, "2001"); //9003 没有操作权限
		errorCodeMap.put(9999, "5001"); //9999系统错误
	}
	
	public static String getErrcode(Integer key){
		if(errorCodeMap.containsKey(key)){
			return errorCodeMap.get(key);
		}
		return "5002";
	}
	
}
