package com.jd.sns.biz.api.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import com.jd.cart.client.domain.CartVO;
import com.jd.cart.client.domain.ProductSetVO;
import com.jd.cart.client.domain.SkuVO;
import com.jd.common.util.Money;
import com.jd.giftcardErpSoa.client.MonthlyPaymentService;
import com.jd.giftcardErpSoa.client.Result;
import com.jd.giftcardErpSoa.vo.GiftCard;
import com.jd.ka.user.soa.service.clientInfo.ClientInfoService;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.DESUtil;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.BizOrderServiceErrorCode;
import com.jd.sns.biz.api.constant.OrderConstants;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizGiftcardOrder;
import com.jd.sns.biz.api.domain.BizPayTask;
import com.jd.sns.biz.api.domain.Sku;
import com.jd.sns.biz.api.domain.SkuList;
import com.jd.sns.biz.api.manager.BizGiftcardOrderManager;
import com.jd.sns.biz.api.order.exception.BizOrderServiceException;
import com.jd.sns.biz.api.service.BaseOrderService;
import com.jd.sns.biz.api.service.BizGiftcarOrderService;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.domain.StringResult;
import com.jd.sns.biz.api.service.pay.BizPayService;
import com.jd.sns.biz.api.service.utils.OrderConvertUtils;
import com.jd.sns.biz.pay.enumtype.PayTypeEnum;
import com.jd.sns.biz.pay.enumtype.PayWayEnum;
import com.jd.sns.biz.pay.exception.BizPayException;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.vertical.trade.sdk.export.SubmitOrderExport;
import com.jd.vertical.trade.sdk.export.address.param.AddressParam;
import com.jd.vertical.trade.sdk.export.common.ClientInfo;
import com.jd.vertical.trade.sdk.export.common.dict.IgnoreStepDict;
import com.jd.vertical.trade.sdk.export.invoice.param.InvoiceParam;
import com.jd.vertical.trade.sdk.export.order.param.OrderParam;
import com.jd.vertical.trade.sdk.export.order.param.SubmitOrderNecessary;
import com.jd.vertical.trade.sdk.export.order.result.SubmitOrderResult;
import com.jd.vertical.trade.sdk.export.payment.param.CombinationPaymentParam;
import com.jd.vertical.trade.sdk.export.shipment.param.CombinationShipmentParam;
import com.jd.vertical.trade.sdk.export.shipment.param.ShipmentParam;

@Service(value="bizGiftcarOrderService")
public class BizGiftcarOrderServiceImpl implements BizGiftcarOrderService {
//	private final static Log log = LogFactory.getLog("submitGiftcardOrderLog");
	
	private static Map<BigDecimal, Long> giftcardSkuMap = new HashMap<BigDecimal, Long>();
	
	private BaseOrderService baseOrderService;
	private SubmitOrderExport submitOrderExport;
	private BizGiftcardOrderManager bizGiftcardOrderManager;
	private BizPayService bizPayService;
	private MonthlyPaymentService monthlyPaymentService;
	private ClientInfoService clientInfoService;
	static {
//		giftcardSkuMap.put(new BigDecimal(10), 1179303l);	
//		giftcardSkuMap.put(new BigDecimal(20), 1179258l);
//		giftcardSkuMap.put(new BigDecimal(50), 1107851l);//线上
//		giftcardSkuMap.put(new BigDecimal(50), 100934l);//测试
//		giftcardSkuMap.put(new BigDecimal(100), 1107845l);
//		giftcardSkuMap.put(new BigDecimal(200), 1107847l);
//		giftcardSkuMap.put(new BigDecimal(300), 1107846l);
//		giftcardSkuMap.put(new BigDecimal(500), 1107843l);
//		giftcardSkuMap.put(new BigDecimal(800), 1107833l);
//		giftcardSkuMap.put(new BigDecimal(1000), 1107842l);
		
		//新加sku
		giftcardSkuMap.put(new BigDecimal(1),1445997l);
		giftcardSkuMap.put(new BigDecimal(2),1445999l);
		giftcardSkuMap.put(new BigDecimal(3),1446002l);
		giftcardSkuMap.put(new BigDecimal(4),1446007l);
		giftcardSkuMap.put(new BigDecimal(5),1446003l);
		giftcardSkuMap.put(new BigDecimal(6),1446009l);
		giftcardSkuMap.put(new BigDecimal(7),1446010l);
		giftcardSkuMap.put(new BigDecimal(8),1446004l);
		giftcardSkuMap.put(new BigDecimal(9),1446016l);
		giftcardSkuMap.put(new BigDecimal(10),1446017l);
		giftcardSkuMap.put(new BigDecimal(11),1446026l);
		giftcardSkuMap.put(new BigDecimal(12),1446027l);
		giftcardSkuMap.put(new BigDecimal(13),1446031l);
		giftcardSkuMap.put(new BigDecimal(14),1446028l);
		giftcardSkuMap.put(new BigDecimal(15),1446029l);
		giftcardSkuMap.put(new BigDecimal(16),1446035l);
		giftcardSkuMap.put(new BigDecimal(17),1446041l);
		giftcardSkuMap.put(new BigDecimal(18),1446046l);
		giftcardSkuMap.put(new BigDecimal(19),1446047l);
		giftcardSkuMap.put(new BigDecimal(20),1446051l);
		giftcardSkuMap.put(new BigDecimal(21),1446045l);
		giftcardSkuMap.put(new BigDecimal(22),1446052l);
		giftcardSkuMap.put(new BigDecimal(23),1446061l);
		giftcardSkuMap.put(new BigDecimal(24),1446062l);
		giftcardSkuMap.put(new BigDecimal(25),1446067l);
		giftcardSkuMap.put(new BigDecimal(26),1446063l);
		giftcardSkuMap.put(new BigDecimal(27),1446068l);
		giftcardSkuMap.put(new BigDecimal(28),1446055l);
		giftcardSkuMap.put(new BigDecimal(29),1446077l);
		giftcardSkuMap.put(new BigDecimal(30),1446094l);
		giftcardSkuMap.put(new BigDecimal(31),1446330l);
		giftcardSkuMap.put(new BigDecimal(32),1446147l);
		giftcardSkuMap.put(new BigDecimal(33),1446106l);
		giftcardSkuMap.put(new BigDecimal(34),1446111l);
		giftcardSkuMap.put(new BigDecimal(35),1446116l);
		giftcardSkuMap.put(new BigDecimal(36),1446118l);
		giftcardSkuMap.put(new BigDecimal(37),1446103l);
		giftcardSkuMap.put(new BigDecimal(38),1446122l);
		giftcardSkuMap.put(new BigDecimal(39),1446148l);
		giftcardSkuMap.put(new BigDecimal(40),1446152l);
		giftcardSkuMap.put(new BigDecimal(41),1446144l);
		giftcardSkuMap.put(new BigDecimal(42),1446156l);
		giftcardSkuMap.put(new BigDecimal(43),1446150l);
		giftcardSkuMap.put(new BigDecimal(44),1446155l);
		giftcardSkuMap.put(new BigDecimal(45),1446166l);
		giftcardSkuMap.put(new BigDecimal(46),1446167l);
		giftcardSkuMap.put(new BigDecimal(47),1446175l);
		giftcardSkuMap.put(new BigDecimal(48),1446170l);
		giftcardSkuMap.put(new BigDecimal(49),1446187l);
		giftcardSkuMap.put(new BigDecimal(50),1446023l);
		giftcardSkuMap.put(new BigDecimal(51),1446030l);
		giftcardSkuMap.put(new BigDecimal(52),1446037l);
		giftcardSkuMap.put(new BigDecimal(53),1446034l);
		giftcardSkuMap.put(new BigDecimal(54),1446025l);
		giftcardSkuMap.put(new BigDecimal(55),1446042l);
		giftcardSkuMap.put(new BigDecimal(56),1446038l);
		giftcardSkuMap.put(new BigDecimal(57),1446039l);
		giftcardSkuMap.put(new BigDecimal(58),1446040l);
		giftcardSkuMap.put(new BigDecimal(59),1446032l);
		giftcardSkuMap.put(new BigDecimal(60),1446022l);
		giftcardSkuMap.put(new BigDecimal(61),1446024l);
		giftcardSkuMap.put(new BigDecimal(62),1446036l);
		giftcardSkuMap.put(new BigDecimal(63),1446033l);
		giftcardSkuMap.put(new BigDecimal(64),1446048l);
		giftcardSkuMap.put(new BigDecimal(65),1446049l);
		giftcardSkuMap.put(new BigDecimal(66),1446050l);
		giftcardSkuMap.put(new BigDecimal(67),1446056l);
		giftcardSkuMap.put(new BigDecimal(68),1445974l);
		giftcardSkuMap.put(new BigDecimal(69),1445983l);
		giftcardSkuMap.put(new BigDecimal(70),1445992l);
		giftcardSkuMap.put(new BigDecimal(71),1445996l);
		giftcardSkuMap.put(new BigDecimal(72),1446001l);
		giftcardSkuMap.put(new BigDecimal(73),1445998l);
		giftcardSkuMap.put(new BigDecimal(74),1446000l);
		giftcardSkuMap.put(new BigDecimal(75),1446006l);
		giftcardSkuMap.put(new BigDecimal(76),1446008l);
		giftcardSkuMap.put(new BigDecimal(77),1446011l);
		giftcardSkuMap.put(new BigDecimal(78),1446188l);
		giftcardSkuMap.put(new BigDecimal(79),1446194l);
		giftcardSkuMap.put(new BigDecimal(80),1446202l);
		giftcardSkuMap.put(new BigDecimal(81),1446198l);
		giftcardSkuMap.put(new BigDecimal(82),1446209l);
		giftcardSkuMap.put(new BigDecimal(83),1446005l);
		giftcardSkuMap.put(new BigDecimal(84),1446021l);
		giftcardSkuMap.put(new BigDecimal(85),1446012l);
		giftcardSkuMap.put(new BigDecimal(86),1446013l);
		giftcardSkuMap.put(new BigDecimal(87),1446014l);
		giftcardSkuMap.put(new BigDecimal(88),1446015l);
		giftcardSkuMap.put(new BigDecimal(89),1446018l);
		giftcardSkuMap.put(new BigDecimal(90),1446019l);
		giftcardSkuMap.put(new BigDecimal(91),1446020l);
		giftcardSkuMap.put(new BigDecimal(92),1446044l);
		giftcardSkuMap.put(new BigDecimal(93),1446057l);
		giftcardSkuMap.put(new BigDecimal(94),1446059l);
		giftcardSkuMap.put(new BigDecimal(95),1446060l);
		giftcardSkuMap.put(new BigDecimal(96),1446053l);
		giftcardSkuMap.put(new BigDecimal(97),1446054l);
		giftcardSkuMap.put(new BigDecimal(98),1446069l);
		giftcardSkuMap.put(new BigDecimal(99),1446070l);
		giftcardSkuMap.put(new BigDecimal(100),1446071l);
		giftcardSkuMap.put(new BigDecimal(101),1446072l);
		giftcardSkuMap.put(new BigDecimal(102),1446064l);
		giftcardSkuMap.put(new BigDecimal(103),1446079l);
		giftcardSkuMap.put(new BigDecimal(104),1446073l);
		giftcardSkuMap.put(new BigDecimal(105),1446080l);
		giftcardSkuMap.put(new BigDecimal(106),1446086l);
		giftcardSkuMap.put(new BigDecimal(107),1446088l);
		giftcardSkuMap.put(new BigDecimal(108),1446091l);
		giftcardSkuMap.put(new BigDecimal(109),1446205l);
		giftcardSkuMap.put(new BigDecimal(110),1446211l);
		giftcardSkuMap.put(new BigDecimal(111),1446220l);
		giftcardSkuMap.put(new BigDecimal(112),1446241l);
		giftcardSkuMap.put(new BigDecimal(113),1446246l);
		giftcardSkuMap.put(new BigDecimal(114),1446233l);
		giftcardSkuMap.put(new BigDecimal(115),1446235l);
		giftcardSkuMap.put(new BigDecimal(116),1446244l);
		giftcardSkuMap.put(new BigDecimal(117),1446104l);
		giftcardSkuMap.put(new BigDecimal(118),1446114l);
		giftcardSkuMap.put(new BigDecimal(119),1446126l);
		giftcardSkuMap.put(new BigDecimal(120),1446127l);
		giftcardSkuMap.put(new BigDecimal(121),1446128l);
		giftcardSkuMap.put(new BigDecimal(122),1446129l);
		giftcardSkuMap.put(new BigDecimal(123),1446130l);
		giftcardSkuMap.put(new BigDecimal(124),1446074l);
		giftcardSkuMap.put(new BigDecimal(125),1446065l);
		giftcardSkuMap.put(new BigDecimal(126),1446087l);
		giftcardSkuMap.put(new BigDecimal(127),1446082l);
		giftcardSkuMap.put(new BigDecimal(128),1446075l);
		giftcardSkuMap.put(new BigDecimal(129),1446090l);
		giftcardSkuMap.put(new BigDecimal(130),1446099l);
		giftcardSkuMap.put(new BigDecimal(131),1446329l);
		giftcardSkuMap.put(new BigDecimal(132),1446085l);
		giftcardSkuMap.put(new BigDecimal(133),1446108l);
		giftcardSkuMap.put(new BigDecimal(134),1446115l);
		giftcardSkuMap.put(new BigDecimal(135),1446136l);
		giftcardSkuMap.put(new BigDecimal(136),1446133l);
		giftcardSkuMap.put(new BigDecimal(137),1446251l);
		giftcardSkuMap.put(new BigDecimal(138),1446256l);
		giftcardSkuMap.put(new BigDecimal(139),1446253l);
		giftcardSkuMap.put(new BigDecimal(140),1446250l);
		giftcardSkuMap.put(new BigDecimal(141),1446182l);
		giftcardSkuMap.put(new BigDecimal(142),1446184l);
		giftcardSkuMap.put(new BigDecimal(143),1446186l);
		giftcardSkuMap.put(new BigDecimal(144),1446192l);
		giftcardSkuMap.put(new BigDecimal(145),1446112l);
		giftcardSkuMap.put(new BigDecimal(146),1446102l);
		giftcardSkuMap.put(new BigDecimal(147),1446120l);
		giftcardSkuMap.put(new BigDecimal(148),1446121l);
		giftcardSkuMap.put(new BigDecimal(149),1446113l);
		giftcardSkuMap.put(new BigDecimal(150),1446123l);
		giftcardSkuMap.put(new BigDecimal(151),1446124l);
		giftcardSkuMap.put(new BigDecimal(152),1446105l);
		giftcardSkuMap.put(new BigDecimal(153),1446125l);
		giftcardSkuMap.put(new BigDecimal(154),1446131l);
		giftcardSkuMap.put(new BigDecimal(155),1446190l);
		giftcardSkuMap.put(new BigDecimal(156),1446255l);
		giftcardSkuMap.put(new BigDecimal(157),1446196l);
		giftcardSkuMap.put(new BigDecimal(158),1446197l);
		giftcardSkuMap.put(new BigDecimal(159),1446203l);
		giftcardSkuMap.put(new BigDecimal(160),1446208l);
		giftcardSkuMap.put(new BigDecimal(161),1446262l);
		giftcardSkuMap.put(new BigDecimal(162),1446260l);
		giftcardSkuMap.put(new BigDecimal(163),1446272l);
		giftcardSkuMap.put(new BigDecimal(164),1446141l);
		giftcardSkuMap.put(new BigDecimal(165),1446137l);
		giftcardSkuMap.put(new BigDecimal(166),1446138l);
		giftcardSkuMap.put(new BigDecimal(167),1446139l);
		giftcardSkuMap.put(new BigDecimal(168),1446140l);
		giftcardSkuMap.put(new BigDecimal(169),1446146l);
		giftcardSkuMap.put(new BigDecimal(170),1446142l);
		giftcardSkuMap.put(new BigDecimal(171),1446134l);
		giftcardSkuMap.put(new BigDecimal(172),1446143l);
		giftcardSkuMap.put(new BigDecimal(173),1446151l);
		giftcardSkuMap.put(new BigDecimal(174),1446281l);
		giftcardSkuMap.put(new BigDecimal(175),1446282l);
		giftcardSkuMap.put(new BigDecimal(176),1446217l);
		giftcardSkuMap.put(new BigDecimal(177),1446218l);
		giftcardSkuMap.put(new BigDecimal(178),1446214l);
		giftcardSkuMap.put(new BigDecimal(179),1446227l);
		giftcardSkuMap.put(new BigDecimal(180),1446231l);
		giftcardSkuMap.put(new BigDecimal(181),1446230l);
		giftcardSkuMap.put(new BigDecimal(182),1446161l);
		giftcardSkuMap.put(new BigDecimal(183),1446163l);
		giftcardSkuMap.put(new BigDecimal(184),1446160l);
		giftcardSkuMap.put(new BigDecimal(185),1446172l);
		giftcardSkuMap.put(new BigDecimal(186),1446173l);
		giftcardSkuMap.put(new BigDecimal(187),1446176l);
		giftcardSkuMap.put(new BigDecimal(188),1446174l);
		giftcardSkuMap.put(new BigDecimal(189),1446177l);
		giftcardSkuMap.put(new BigDecimal(190),1446181l);
		giftcardSkuMap.put(new BigDecimal(191),1446178l);
		giftcardSkuMap.put(new BigDecimal(192),1446149l);
		giftcardSkuMap.put(new BigDecimal(193),1446145l);
		giftcardSkuMap.put(new BigDecimal(194),1446153l);
		giftcardSkuMap.put(new BigDecimal(195),1446157l);
		giftcardSkuMap.put(new BigDecimal(196),1446158l);
		giftcardSkuMap.put(new BigDecimal(197),1446162l);
		giftcardSkuMap.put(new BigDecimal(198),1446159l);
		giftcardSkuMap.put(new BigDecimal(199),1446171l);
		giftcardSkuMap.put(new BigDecimal(200),1446165l);
		giftcardSkuMap.put(new BigDecimal(201),1446168l);
		giftcardSkuMap.put(new BigDecimal(202),1446237l);
		giftcardSkuMap.put(new BigDecimal(203),1446243l);
		giftcardSkuMap.put(new BigDecimal(204),1446247l);
		giftcardSkuMap.put(new BigDecimal(205),1446234l);
		giftcardSkuMap.put(new BigDecimal(206),1446283l);
		giftcardSkuMap.put(new BigDecimal(207),1446288l);
		giftcardSkuMap.put(new BigDecimal(208),1446278l);
		giftcardSkuMap.put(new BigDecimal(209),1446285l);
		giftcardSkuMap.put(new BigDecimal(210),1446185l);
		giftcardSkuMap.put(new BigDecimal(211),1446191l);
		giftcardSkuMap.put(new BigDecimal(212),1446189l);
		giftcardSkuMap.put(new BigDecimal(213),1446193l);
		giftcardSkuMap.put(new BigDecimal(214),1446195l);
		giftcardSkuMap.put(new BigDecimal(215),1446206l);
		giftcardSkuMap.put(new BigDecimal(216),1446207l);
		giftcardSkuMap.put(new BigDecimal(217),1446204l);
		giftcardSkuMap.put(new BigDecimal(218),1446210l);
		giftcardSkuMap.put(new BigDecimal(219),1446199l);
		giftcardSkuMap.put(new BigDecimal(220),1446299l);
		giftcardSkuMap.put(new BigDecimal(221),1446294l);
		giftcardSkuMap.put(new BigDecimal(222),1446304l);
		giftcardSkuMap.put(new BigDecimal(223),1446295l);
		giftcardSkuMap.put(new BigDecimal(224),1446271l);
		giftcardSkuMap.put(new BigDecimal(225),1446268l);
		giftcardSkuMap.put(new BigDecimal(226),1446265l);
		giftcardSkuMap.put(new BigDecimal(227),1446269l);
		giftcardSkuMap.put(new BigDecimal(228),1446270l);
		giftcardSkuMap.put(new BigDecimal(229),1446277l);
		giftcardSkuMap.put(new BigDecimal(230),1446274l);
		giftcardSkuMap.put(new BigDecimal(231),1446286l);
		giftcardSkuMap.put(new BigDecimal(232),1446287l);
		giftcardSkuMap.put(new BigDecimal(233),1446306l);
		giftcardSkuMap.put(new BigDecimal(234),1446308l);
		giftcardSkuMap.put(new BigDecimal(235),1446310l);
		giftcardSkuMap.put(new BigDecimal(236),1446223l);
		giftcardSkuMap.put(new BigDecimal(237),1446225l);
		giftcardSkuMap.put(new BigDecimal(238),1446215l);
		giftcardSkuMap.put(new BigDecimal(239),1446219l);
		giftcardSkuMap.put(new BigDecimal(240),1446228l);
		giftcardSkuMap.put(new BigDecimal(241),1446232l);
		giftcardSkuMap.put(new BigDecimal(242),1446242l);
		giftcardSkuMap.put(new BigDecimal(243),1446321l);
		giftcardSkuMap.put(new BigDecimal(244),1446325l);
		giftcardSkuMap.put(new BigDecimal(245),1446569l);
		giftcardSkuMap.put(new BigDecimal(246),1446570l);
		giftcardSkuMap.put(new BigDecimal(247),1446573l);
		giftcardSkuMap.put(new BigDecimal(248),1446577l);
		giftcardSkuMap.put(new BigDecimal(249),1446578l);
		giftcardSkuMap.put(new BigDecimal(250),1446575l);
		giftcardSkuMap.put(new BigDecimal(251),1446221l);
		giftcardSkuMap.put(new BigDecimal(252),1446212l);
		giftcardSkuMap.put(new BigDecimal(253),1446222l);
		giftcardSkuMap.put(new BigDecimal(254),1446582l);
		giftcardSkuMap.put(new BigDecimal(255),1446583l);
		giftcardSkuMap.put(new BigDecimal(256),1446298l);
		giftcardSkuMap.put(new BigDecimal(257),1446301l);
		giftcardSkuMap.put(new BigDecimal(258),1446300l);
		giftcardSkuMap.put(new BigDecimal(259),1446245l);
		giftcardSkuMap.put(new BigDecimal(260),1446257l);
		giftcardSkuMap.put(new BigDecimal(261),1446258l);
		giftcardSkuMap.put(new BigDecimal(262),1446261l);
		giftcardSkuMap.put(new BigDecimal(263),1446259l);
		giftcardSkuMap.put(new BigDecimal(264),1446266l);
		giftcardSkuMap.put(new BigDecimal(265),1446264l);
		giftcardSkuMap.put(new BigDecimal(266),1446273l);
		giftcardSkuMap.put(new BigDecimal(267),1446276l);
		giftcardSkuMap.put(new BigDecimal(268),1446302l);
		giftcardSkuMap.put(new BigDecimal(269),1446303l);
		giftcardSkuMap.put(new BigDecimal(270),1446311l);
		giftcardSkuMap.put(new BigDecimal(271),1446309l);
		giftcardSkuMap.put(new BigDecimal(272),1446305l);
		giftcardSkuMap.put(new BigDecimal(273),1446316l);
		giftcardSkuMap.put(new BigDecimal(274),1446327l);
		giftcardSkuMap.put(new BigDecimal(275),1446328l);
		giftcardSkuMap.put(new BigDecimal(276),1446289l);
		giftcardSkuMap.put(new BigDecimal(277),1446279l);
		giftcardSkuMap.put(new BigDecimal(278),1446280l);
		giftcardSkuMap.put(new BigDecimal(279),1446284l);
		giftcardSkuMap.put(new BigDecimal(280),1446657l);
		giftcardSkuMap.put(new BigDecimal(281),1446290l);
		giftcardSkuMap.put(new BigDecimal(282),1446291l);
		giftcardSkuMap.put(new BigDecimal(283),1446296l);
		giftcardSkuMap.put(new BigDecimal(284),1446292l);
		giftcardSkuMap.put(new BigDecimal(285),1446293l);
		giftcardSkuMap.put(new BigDecimal(286),1446297l);
		giftcardSkuMap.put(new BigDecimal(287),1446585l);
		giftcardSkuMap.put(new BigDecimal(288),1446606l);
		giftcardSkuMap.put(new BigDecimal(289),1446602l);
		giftcardSkuMap.put(new BigDecimal(290),1446608l);
		giftcardSkuMap.put(new BigDecimal(291),1446603l);
		giftcardSkuMap.put(new BigDecimal(292),1446609l);
		giftcardSkuMap.put(new BigDecimal(293),1446599l);
		giftcardSkuMap.put(new BigDecimal(294),1446611l);
		giftcardSkuMap.put(new BigDecimal(295),1446617l);
		giftcardSkuMap.put(new BigDecimal(296),1446618l);
		giftcardSkuMap.put(new BigDecimal(297),1446624l);
		giftcardSkuMap.put(new BigDecimal(298),1446647l);
		giftcardSkuMap.put(new BigDecimal(299),1446634l);
		giftcardSkuMap.put(new BigDecimal(300),1446643l);
		giftcardSkuMap.put(new BigDecimal(301),1446652l);
		giftcardSkuMap.put(new BigDecimal(302),1446662l);
		giftcardSkuMap.put(new BigDecimal(303),1446663l);
		giftcardSkuMap.put(new BigDecimal(304),1446672l);
		giftcardSkuMap.put(new BigDecimal(305),1446664l);
		giftcardSkuMap.put(new BigDecimal(306),1446684l);
		giftcardSkuMap.put(new BigDecimal(307),1446692l);
		giftcardSkuMap.put(new BigDecimal(308),1446695l);
		giftcardSkuMap.put(new BigDecimal(309),1446690l);
		giftcardSkuMap.put(new BigDecimal(310),1446701l);
		giftcardSkuMap.put(new BigDecimal(311),1446699l);
		giftcardSkuMap.put(new BigDecimal(312),1446703l);
		giftcardSkuMap.put(new BigDecimal(313),1446707l);
		giftcardSkuMap.put(new BigDecimal(314),1446717l);
		giftcardSkuMap.put(new BigDecimal(315),1446722l);
		giftcardSkuMap.put(new BigDecimal(316),1446678l);
		giftcardSkuMap.put(new BigDecimal(317),1446655l);
		giftcardSkuMap.put(new BigDecimal(318),1446671l);
		giftcardSkuMap.put(new BigDecimal(319),1446667l);
		giftcardSkuMap.put(new BigDecimal(320),1446668l);
		giftcardSkuMap.put(new BigDecimal(321),1446676l);
		giftcardSkuMap.put(new BigDecimal(322),1446665l);
		giftcardSkuMap.put(new BigDecimal(323),1446681l);
		giftcardSkuMap.put(new BigDecimal(324),1446682l);
		giftcardSkuMap.put(new BigDecimal(325),1446669l);
		giftcardSkuMap.put(new BigDecimal(326),1446574l);
		giftcardSkuMap.put(new BigDecimal(327),1446596l);
		giftcardSkuMap.put(new BigDecimal(328),1446592l);
		giftcardSkuMap.put(new BigDecimal(329),1446588l);
		giftcardSkuMap.put(new BigDecimal(330),1446594l);
		giftcardSkuMap.put(new BigDecimal(331),1446589l);
		giftcardSkuMap.put(new BigDecimal(332),1446601l);
		giftcardSkuMap.put(new BigDecimal(333),1446739l);
		giftcardSkuMap.put(new BigDecimal(334),1446729l);
		giftcardSkuMap.put(new BigDecimal(335),1446730l);
		giftcardSkuMap.put(new BigDecimal(336),1446746l);
		giftcardSkuMap.put(new BigDecimal(337),1446747l);
		giftcardSkuMap.put(new BigDecimal(338),1446748l);
		giftcardSkuMap.put(new BigDecimal(339),1446735l);
		giftcardSkuMap.put(new BigDecimal(340),1446744l);
		giftcardSkuMap.put(new BigDecimal(341),1446753l);
		giftcardSkuMap.put(new BigDecimal(342),1446758l);
		giftcardSkuMap.put(new BigDecimal(343),1446787l);
		giftcardSkuMap.put(new BigDecimal(344),1446700l);
		giftcardSkuMap.put(new BigDecimal(345),1446605l);
		giftcardSkuMap.put(new BigDecimal(346),1446600l);
		giftcardSkuMap.put(new BigDecimal(347),1446616l);
		giftcardSkuMap.put(new BigDecimal(348),1446621l);
		giftcardSkuMap.put(new BigDecimal(349),1446622l);
		giftcardSkuMap.put(new BigDecimal(350),1446623l);
		giftcardSkuMap.put(new BigDecimal(351),1446613l);
		giftcardSkuMap.put(new BigDecimal(352),1446628l);
		giftcardSkuMap.put(new BigDecimal(353),1446631l);
		giftcardSkuMap.put(new BigDecimal(354),1446636l);
		giftcardSkuMap.put(new BigDecimal(355),1446705l);
		giftcardSkuMap.put(new BigDecimal(356),1446716l);
		giftcardSkuMap.put(new BigDecimal(357),1447847l);
		giftcardSkuMap.put(new BigDecimal(358),1447858l);
		giftcardSkuMap.put(new BigDecimal(359),1447852l);
		giftcardSkuMap.put(new BigDecimal(360),1447848l);
		giftcardSkuMap.put(new BigDecimal(361),1447788l);
		giftcardSkuMap.put(new BigDecimal(362),1447784l);
		giftcardSkuMap.put(new BigDecimal(363),1447778l);
		giftcardSkuMap.put(new BigDecimal(364),1447785l);
		giftcardSkuMap.put(new BigDecimal(365),1447796l);
		giftcardSkuMap.put(new BigDecimal(366),1447794l);
		giftcardSkuMap.put(new BigDecimal(367),1447797l);
		giftcardSkuMap.put(new BigDecimal(368),1447798l);
		giftcardSkuMap.put(new BigDecimal(369),1447844l);
		giftcardSkuMap.put(new BigDecimal(370),1447839l);
		giftcardSkuMap.put(new BigDecimal(371),1447781l);
		giftcardSkuMap.put(new BigDecimal(372),1447777l);
		giftcardSkuMap.put(new BigDecimal(373),1447782l);
		giftcardSkuMap.put(new BigDecimal(374),1447787l);
		giftcardSkuMap.put(new BigDecimal(375),1447783l);
		giftcardSkuMap.put(new BigDecimal(376),1447790l);
		giftcardSkuMap.put(new BigDecimal(377),1447791l);
		giftcardSkuMap.put(new BigDecimal(378),1447792l);
		giftcardSkuMap.put(new BigDecimal(379),1447793l);
		giftcardSkuMap.put(new BigDecimal(380),1447838l);
		giftcardSkuMap.put(new BigDecimal(381),1447835l);
		giftcardSkuMap.put(new BigDecimal(382),1447754l);
		giftcardSkuMap.put(new BigDecimal(383),1447748l);
		giftcardSkuMap.put(new BigDecimal(384),1447755l);
		giftcardSkuMap.put(new BigDecimal(385),1447758l);
		giftcardSkuMap.put(new BigDecimal(386),1447759l);
		giftcardSkuMap.put(new BigDecimal(387),1447760l);
		giftcardSkuMap.put(new BigDecimal(388),1447761l);
		giftcardSkuMap.put(new BigDecimal(389),1447768l);
		giftcardSkuMap.put(new BigDecimal(390),1447764l);
		giftcardSkuMap.put(new BigDecimal(391),1447772l);
		giftcardSkuMap.put(new BigDecimal(392),1447804l);
		giftcardSkuMap.put(new BigDecimal(393),1447807l);
		giftcardSkuMap.put(new BigDecimal(394),1447808l);
		giftcardSkuMap.put(new BigDecimal(395),1447816l);
		giftcardSkuMap.put(new BigDecimal(396),1447817l);
		giftcardSkuMap.put(new BigDecimal(397),1447814l);
		giftcardSkuMap.put(new BigDecimal(398),1447821l);
		giftcardSkuMap.put(new BigDecimal(399),1447833l);
		giftcardSkuMap.put(new BigDecimal(400),1447834l);
		giftcardSkuMap.put(new BigDecimal(401),1447718l);
		giftcardSkuMap.put(new BigDecimal(402),1447719l);
		giftcardSkuMap.put(new BigDecimal(403),1447728l);
		giftcardSkuMap.put(new BigDecimal(404),1447767l);
		giftcardSkuMap.put(new BigDecimal(405),1447730l);
		giftcardSkuMap.put(new BigDecimal(406),1447725l);
		giftcardSkuMap.put(new BigDecimal(407),1447738l);
		giftcardSkuMap.put(new BigDecimal(408),1447769l);
		giftcardSkuMap.put(new BigDecimal(409),1447765l);
		giftcardSkuMap.put(new BigDecimal(410),1447749l);
		giftcardSkuMap.put(new BigDecimal(411),1447736l);
		giftcardSkuMap.put(new BigDecimal(412),1447737l);
		giftcardSkuMap.put(new BigDecimal(413),1447831l);
		giftcardSkuMap.put(new BigDecimal(414),1447841l);
		giftcardSkuMap.put(new BigDecimal(415),1447799l);
		giftcardSkuMap.put(new BigDecimal(416),1447832l);
		giftcardSkuMap.put(new BigDecimal(417),1447800l);
		giftcardSkuMap.put(new BigDecimal(418),1447744l);
		giftcardSkuMap.put(new BigDecimal(419),1447747l);
		giftcardSkuMap.put(new BigDecimal(420),1447752l);
		giftcardSkuMap.put(new BigDecimal(421),1447829l);
		giftcardSkuMap.put(new BigDecimal(422),1447825l);
		giftcardSkuMap.put(new BigDecimal(423),1447710l);
		giftcardSkuMap.put(new BigDecimal(424),1447720l);
		giftcardSkuMap.put(new BigDecimal(425),1447721l);
		giftcardSkuMap.put(new BigDecimal(426),1447722l);
		giftcardSkuMap.put(new BigDecimal(427),1447715l);
		giftcardSkuMap.put(new BigDecimal(428),1447727l);
		giftcardSkuMap.put(new BigDecimal(429),1447729l);
		giftcardSkuMap.put(new BigDecimal(430),1447731l);
		giftcardSkuMap.put(new BigDecimal(431),1447679l);
		giftcardSkuMap.put(new BigDecimal(432),1447683l);
		giftcardSkuMap.put(new BigDecimal(433),1447688l);
		giftcardSkuMap.put(new BigDecimal(434),1447689l);
		giftcardSkuMap.put(new BigDecimal(435),1447680l);
		giftcardSkuMap.put(new BigDecimal(436),1447691l);
		giftcardSkuMap.put(new BigDecimal(437),1447690l);
		giftcardSkuMap.put(new BigDecimal(438),1447696l);
		giftcardSkuMap.put(new BigDecimal(439),1447826l);
		giftcardSkuMap.put(new BigDecimal(440),1447827l);
		giftcardSkuMap.put(new BigDecimal(441),1447694l);
		giftcardSkuMap.put(new BigDecimal(442),1447695l);
		giftcardSkuMap.put(new BigDecimal(443),1447703l);
		giftcardSkuMap.put(new BigDecimal(444),1447706l);
		giftcardSkuMap.put(new BigDecimal(445),1447707l);
		giftcardSkuMap.put(new BigDecimal(446),1447711l);
		giftcardSkuMap.put(new BigDecimal(447),1447705l);
		giftcardSkuMap.put(new BigDecimal(448),1447712l);
		giftcardSkuMap.put(new BigDecimal(449),1447819l);
		giftcardSkuMap.put(new BigDecimal(450),1447820l);
		giftcardSkuMap.put(new BigDecimal(451),1447822l);
		giftcardSkuMap.put(new BigDecimal(452),1447823l);
		giftcardSkuMap.put(new BigDecimal(453),1447828l);
		giftcardSkuMap.put(new BigDecimal(454),1447824l);
		giftcardSkuMap.put(new BigDecimal(455),1447815l);
		giftcardSkuMap.put(new BigDecimal(456),1447830l);
		giftcardSkuMap.put(new BigDecimal(457),1447836l);
		giftcardSkuMap.put(new BigDecimal(458),1447837l);
		giftcardSkuMap.put(new BigDecimal(459),1447685l);
		giftcardSkuMap.put(new BigDecimal(460),1447692l);
		giftcardSkuMap.put(new BigDecimal(461),1447686l);
		giftcardSkuMap.put(new BigDecimal(462),1447678l);
		giftcardSkuMap.put(new BigDecimal(463),1447650l);
		giftcardSkuMap.put(new BigDecimal(464),1447642l);
		giftcardSkuMap.put(new BigDecimal(465),1447643l);
		giftcardSkuMap.put(new BigDecimal(466),1447644l);
		giftcardSkuMap.put(new BigDecimal(467),1447662l);
		giftcardSkuMap.put(new BigDecimal(468),1447645l);
		giftcardSkuMap.put(new BigDecimal(469),1447666l);
		giftcardSkuMap.put(new BigDecimal(470),1447671l);
		giftcardSkuMap.put(new BigDecimal(471),1447812l);
		giftcardSkuMap.put(new BigDecimal(472),1447813l);
		giftcardSkuMap.put(new BigDecimal(473),1447810l);
		giftcardSkuMap.put(new BigDecimal(474),1447676l);
		giftcardSkuMap.put(new BigDecimal(475),1447677l);
		giftcardSkuMap.put(new BigDecimal(476),1447673l);
		giftcardSkuMap.put(new BigDecimal(477),1447674l);
		giftcardSkuMap.put(new BigDecimal(478),1447681l);
		giftcardSkuMap.put(new BigDecimal(479),1447682l);
		giftcardSkuMap.put(new BigDecimal(480),1447675l);
		giftcardSkuMap.put(new BigDecimal(481),1447667l);
		giftcardSkuMap.put(new BigDecimal(482),1447774l);
		giftcardSkuMap.put(new BigDecimal(483),1447775l);
		giftcardSkuMap.put(new BigDecimal(484),1447750l);
		giftcardSkuMap.put(new BigDecimal(485),1447786l);
		giftcardSkuMap.put(new BigDecimal(486),1447795l);
		giftcardSkuMap.put(new BigDecimal(487),1447801l);
		giftcardSkuMap.put(new BigDecimal(488),1447806l);
		giftcardSkuMap.put(new BigDecimal(489),1447802l);
		giftcardSkuMap.put(new BigDecimal(490),1447803l);
		giftcardSkuMap.put(new BigDecimal(491),1447763l);
		giftcardSkuMap.put(new BigDecimal(492),1447771l);
		giftcardSkuMap.put(new BigDecimal(493),1447770l);
		giftcardSkuMap.put(new BigDecimal(494),1447776l);
		giftcardSkuMap.put(new BigDecimal(495),1447773l);
		giftcardSkuMap.put(new BigDecimal(496),1447639l);
		giftcardSkuMap.put(new BigDecimal(497),1447640l);
		giftcardSkuMap.put(new BigDecimal(498),1447651l);
		giftcardSkuMap.put(new BigDecimal(499),1447654l);
		giftcardSkuMap.put(new BigDecimal(500),1447724l);
		giftcardSkuMap.put(new BigDecimal(501),1447732l);
		giftcardSkuMap.put(new BigDecimal(502),1447739l);
		giftcardSkuMap.put(new BigDecimal(503),1447733l);
		giftcardSkuMap.put(new BigDecimal(504),1447742l);
		giftcardSkuMap.put(new BigDecimal(505),1447734l);
		giftcardSkuMap.put(new BigDecimal(506),1447735l);
		giftcardSkuMap.put(new BigDecimal(507),1447746l);
		giftcardSkuMap.put(new BigDecimal(508),1447756l);
		giftcardSkuMap.put(new BigDecimal(509),1447766l);
		giftcardSkuMap.put(new BigDecimal(510),1447612l);
		giftcardSkuMap.put(new BigDecimal(511),1447618l);
		giftcardSkuMap.put(new BigDecimal(512),1447622l);
		giftcardSkuMap.put(new BigDecimal(513),1447619l);
		giftcardSkuMap.put(new BigDecimal(514),1447623l);
		giftcardSkuMap.put(new BigDecimal(515),1447631l);
		giftcardSkuMap.put(new BigDecimal(516),1447627l);
		giftcardSkuMap.put(new BigDecimal(517),1447628l);
		giftcardSkuMap.put(new BigDecimal(518),1447633l);
		giftcardSkuMap.put(new BigDecimal(519),1447629l);
		giftcardSkuMap.put(new BigDecimal(520),1447687l);
		giftcardSkuMap.put(new BigDecimal(521),1447697l);
		giftcardSkuMap.put(new BigDecimal(522),1447698l);
		giftcardSkuMap.put(new BigDecimal(523),1447693l);
		giftcardSkuMap.put(new BigDecimal(524),1447701l);
		giftcardSkuMap.put(new BigDecimal(525),1447699l);
		giftcardSkuMap.put(new BigDecimal(526),1447700l);
		giftcardSkuMap.put(new BigDecimal(527),1447716l);
		giftcardSkuMap.put(new BigDecimal(528),1447717l);
		giftcardSkuMap.put(new BigDecimal(529),1447709l);
		giftcardSkuMap.put(new BigDecimal(530),1447638l);
		giftcardSkuMap.put(new BigDecimal(531),1447630l);
		giftcardSkuMap.put(new BigDecimal(532),1447641l);
		giftcardSkuMap.put(new BigDecimal(533),1447663l);
		giftcardSkuMap.put(new BigDecimal(534),1447664l);
		giftcardSkuMap.put(new BigDecimal(535),1447668l);
		giftcardSkuMap.put(new BigDecimal(536),1447669l);
		giftcardSkuMap.put(new BigDecimal(537),1447672l);
		giftcardSkuMap.put(new BigDecimal(538),1447670l);
		giftcardSkuMap.put(new BigDecimal(539),1447665l);
		giftcardSkuMap.put(new BigDecimal(540),1447659l);
		giftcardSkuMap.put(new BigDecimal(541),1447660l);
		giftcardSkuMap.put(new BigDecimal(542),1447661l);
		giftcardSkuMap.put(new BigDecimal(543),1447620l);
		giftcardSkuMap.put(new BigDecimal(544),1447614l);
		giftcardSkuMap.put(new BigDecimal(545),1447615l);
		giftcardSkuMap.put(new BigDecimal(546),1447632l);
		giftcardSkuMap.put(new BigDecimal(547),1447625l);
		giftcardSkuMap.put(new BigDecimal(548),1447634l);
		giftcardSkuMap.put(new BigDecimal(549),1447637l);
		giftcardSkuMap.put(new BigDecimal(550),1447626l);
		giftcardSkuMap.put(new BigDecimal(551),1447624l);
		giftcardSkuMap.put(new BigDecimal(552),1447636l);
		giftcardSkuMap.put(new BigDecimal(553),1447635l);
		giftcardSkuMap.put(new BigDecimal(554),1447646l);
		giftcardSkuMap.put(new BigDecimal(555),1447647l);
		giftcardSkuMap.put(new BigDecimal(556),1447653l);
		giftcardSkuMap.put(new BigDecimal(557),1447655l);
		giftcardSkuMap.put(new BigDecimal(558),1447657l);
		giftcardSkuMap.put(new BigDecimal(559),1447658l);
		giftcardSkuMap.put(new BigDecimal(560),1447225l);
		giftcardSkuMap.put(new BigDecimal(561),1447220l);
		giftcardSkuMap.put(new BigDecimal(562),1447231l);
		giftcardSkuMap.put(new BigDecimal(563),1447236l);
		giftcardSkuMap.put(new BigDecimal(564),1447228l);
		giftcardSkuMap.put(new BigDecimal(565),1447232l);
		giftcardSkuMap.put(new BigDecimal(566),1447241l);
		giftcardSkuMap.put(new BigDecimal(567),1447296l);
		giftcardSkuMap.put(new BigDecimal(568),1447294l);
		giftcardSkuMap.put(new BigDecimal(569),1447285l);
		giftcardSkuMap.put(new BigDecimal(570),1447244l);
		giftcardSkuMap.put(new BigDecimal(571),1447251l);
		giftcardSkuMap.put(new BigDecimal(572),1447250l);
		giftcardSkuMap.put(new BigDecimal(573),1447253l);
		giftcardSkuMap.put(new BigDecimal(574),1447255l);
		giftcardSkuMap.put(new BigDecimal(575),1447257l);
		giftcardSkuMap.put(new BigDecimal(576),1447265l);
		giftcardSkuMap.put(new BigDecimal(577),1447198l);
		giftcardSkuMap.put(new BigDecimal(578),1447199l);
		giftcardSkuMap.put(new BigDecimal(579),1447219l);
		giftcardSkuMap.put(new BigDecimal(580),1447192l);
		giftcardSkuMap.put(new BigDecimal(581),1447184l);
		giftcardSkuMap.put(new BigDecimal(582),1447185l);
		giftcardSkuMap.put(new BigDecimal(583),1447196l);
		giftcardSkuMap.put(new BigDecimal(584),1447202l);
		giftcardSkuMap.put(new BigDecimal(585),1447203l);
		giftcardSkuMap.put(new BigDecimal(586),1447211l);
		giftcardSkuMap.put(new BigDecimal(587),1447240l);
		giftcardSkuMap.put(new BigDecimal(588),1447234l);
		giftcardSkuMap.put(new BigDecimal(589),1447247l);
		giftcardSkuMap.put(new BigDecimal(590),1447246l);
		giftcardSkuMap.put(new BigDecimal(591),1447249l);
		giftcardSkuMap.put(new BigDecimal(592),1447235l);
		giftcardSkuMap.put(new BigDecimal(593),1447256l);
		giftcardSkuMap.put(new BigDecimal(594),1447261l);
		giftcardSkuMap.put(new BigDecimal(595),1447264l);
		giftcardSkuMap.put(new BigDecimal(596),1447258l);
		giftcardSkuMap.put(new BigDecimal(597),1447186l);
		giftcardSkuMap.put(new BigDecimal(598),1447183l);
		giftcardSkuMap.put(new BigDecimal(599),1447188l);
		giftcardSkuMap.put(new BigDecimal(600),1447215l);
		giftcardSkuMap.put(new BigDecimal(601),1447197l);
		giftcardSkuMap.put(new BigDecimal(602),1447218l);
		giftcardSkuMap.put(new BigDecimal(603),1447221l);
		giftcardSkuMap.put(new BigDecimal(604),1447223l);
		giftcardSkuMap.put(new BigDecimal(605),1447224l);
		giftcardSkuMap.put(new BigDecimal(606),1447226l);
		giftcardSkuMap.put(new BigDecimal(607),1447227l);
		giftcardSkuMap.put(new BigDecimal(608),1447243l);
		giftcardSkuMap.put(new BigDecimal(609),1447238l);
		giftcardSkuMap.put(new BigDecimal(610),1447149l);
		giftcardSkuMap.put(new BigDecimal(611),1447166l);
		giftcardSkuMap.put(new BigDecimal(612),1447171l);
		giftcardSkuMap.put(new BigDecimal(613),1447164l);
		giftcardSkuMap.put(new BigDecimal(614),1447168l);
		giftcardSkuMap.put(new BigDecimal(615),1447165l);
		giftcardSkuMap.put(new BigDecimal(616),1447177l);
		giftcardSkuMap.put(new BigDecimal(617),1447178l);
		giftcardSkuMap.put(new BigDecimal(618),1447217l);
		giftcardSkuMap.put(new BigDecimal(619),1447213l);
		giftcardSkuMap.put(new BigDecimal(620),1447187l);
		giftcardSkuMap.put(new BigDecimal(621),1447189l);
		giftcardSkuMap.put(new BigDecimal(622),1447193l);
		giftcardSkuMap.put(new BigDecimal(623),1447194l);
		giftcardSkuMap.put(new BigDecimal(624),1447201l);
		giftcardSkuMap.put(new BigDecimal(625),1447204l);
		giftcardSkuMap.put(new BigDecimal(626),1447207l);
		giftcardSkuMap.put(new BigDecimal(627),1447208l);
		giftcardSkuMap.put(new BigDecimal(628),1447155l);
		giftcardSkuMap.put(new BigDecimal(629),1447159l);
		giftcardSkuMap.put(new BigDecimal(630),1447137l);
		giftcardSkuMap.put(new BigDecimal(631),1447133l);
		giftcardSkuMap.put(new BigDecimal(632),1447158l);
		giftcardSkuMap.put(new BigDecimal(633),1447160l);
		giftcardSkuMap.put(new BigDecimal(634),1447150l);
		giftcardSkuMap.put(new BigDecimal(635),1447162l);
		giftcardSkuMap.put(new BigDecimal(636),1447172l);
		giftcardSkuMap.put(new BigDecimal(637),1447173l);
		giftcardSkuMap.put(new BigDecimal(638),1447170l);
		giftcardSkuMap.put(new BigDecimal(639),1447176l);
		giftcardSkuMap.put(new BigDecimal(640),1447141l);
		giftcardSkuMap.put(new BigDecimal(641),1447146l);
		giftcardSkuMap.put(new BigDecimal(642),1447126l);
		giftcardSkuMap.put(new BigDecimal(643),1447123l);
		giftcardSkuMap.put(new BigDecimal(644),1447124l);
		giftcardSkuMap.put(new BigDecimal(645),1447125l);
		giftcardSkuMap.put(new BigDecimal(646),1447120l);
		giftcardSkuMap.put(new BigDecimal(647),1447128l);
		giftcardSkuMap.put(new BigDecimal(648),1447131l);
		giftcardSkuMap.put(new BigDecimal(649),1447136l);
		giftcardSkuMap.put(new BigDecimal(650),1447104l);
		giftcardSkuMap.put(new BigDecimal(651),1447108l);
		giftcardSkuMap.put(new BigDecimal(652),1447114l);
		giftcardSkuMap.put(new BigDecimal(653),1447116l);
		giftcardSkuMap.put(new BigDecimal(654),1447109l);
		giftcardSkuMap.put(new BigDecimal(655),1447110l);
		giftcardSkuMap.put(new BigDecimal(656),1447139l);
		giftcardSkuMap.put(new BigDecimal(657),1447130l);
		giftcardSkuMap.put(new BigDecimal(658),1447134l);
		giftcardSkuMap.put(new BigDecimal(659),1447140l);
		giftcardSkuMap.put(new BigDecimal(660),1447106l);
		giftcardSkuMap.put(new BigDecimal(661),1447102l);
		giftcardSkuMap.put(new BigDecimal(662),1447117l);
		giftcardSkuMap.put(new BigDecimal(663),1447175l);
		giftcardSkuMap.put(new BigDecimal(664),1447191l);
		giftcardSkuMap.put(new BigDecimal(665),1447122l);
		giftcardSkuMap.put(new BigDecimal(666),1447098l);
		giftcardSkuMap.put(new BigDecimal(667),1447111l);
		giftcardSkuMap.put(new BigDecimal(668),1447112l);
		giftcardSkuMap.put(new BigDecimal(669),1447113l);
		giftcardSkuMap.put(new BigDecimal(670),1447076l);
		giftcardSkuMap.put(new BigDecimal(671),1447077l);
		giftcardSkuMap.put(new BigDecimal(672),1447068l);
		giftcardSkuMap.put(new BigDecimal(673),1447074l);
		giftcardSkuMap.put(new BigDecimal(674),1447075l);
		giftcardSkuMap.put(new BigDecimal(675),1447080l);
		giftcardSkuMap.put(new BigDecimal(676),1447091l);
		giftcardSkuMap.put(new BigDecimal(677),1447082l);
		giftcardSkuMap.put(new BigDecimal(678),1447090l);
		giftcardSkuMap.put(new BigDecimal(679),1447085l);
		giftcardSkuMap.put(new BigDecimal(680),1447084l);
		giftcardSkuMap.put(new BigDecimal(681),1447094l);
		giftcardSkuMap.put(new BigDecimal(682),1447095l);
		giftcardSkuMap.put(new BigDecimal(683),1447097l);
		giftcardSkuMap.put(new BigDecimal(684),1447107l);
		giftcardSkuMap.put(new BigDecimal(685),1447099l);
		giftcardSkuMap.put(new BigDecimal(686),1447057l);
		giftcardSkuMap.put(new BigDecimal(687),1447063l);
		giftcardSkuMap.put(new BigDecimal(688),1447059l);
		giftcardSkuMap.put(new BigDecimal(689),1447060l);
		giftcardSkuMap.put(new BigDecimal(690),1447052l);
		giftcardSkuMap.put(new BigDecimal(691),1447054l);
		giftcardSkuMap.put(new BigDecimal(692),1447055l);
		giftcardSkuMap.put(new BigDecimal(693),1447056l);
		giftcardSkuMap.put(new BigDecimal(694),1447061l);
		giftcardSkuMap.put(new BigDecimal(695),1447062l);
		giftcardSkuMap.put(new BigDecimal(696),1447058l);
		giftcardSkuMap.put(new BigDecimal(697),1447092l);
		giftcardSkuMap.put(new BigDecimal(698),1447088l);
		giftcardSkuMap.put(new BigDecimal(699),1447083l);
		giftcardSkuMap.put(new BigDecimal(700),1447043l);
		giftcardSkuMap.put(new BigDecimal(701),1447044l);
		giftcardSkuMap.put(new BigDecimal(702),1447053l);
		giftcardSkuMap.put(new BigDecimal(703),1447066l);
		giftcardSkuMap.put(new BigDecimal(704),1447071l);
		giftcardSkuMap.put(new BigDecimal(705),1447072l);
		giftcardSkuMap.put(new BigDecimal(706),1447067l);
		giftcardSkuMap.put(new BigDecimal(707),1447078l);
		giftcardSkuMap.put(new BigDecimal(708),1447079l);
		giftcardSkuMap.put(new BigDecimal(709),1447034l);
		giftcardSkuMap.put(new BigDecimal(710),1447014l);
		giftcardSkuMap.put(new BigDecimal(711),1447046l);
		giftcardSkuMap.put(new BigDecimal(712),1447026l);
		giftcardSkuMap.put(new BigDecimal(713),1447022l);
		giftcardSkuMap.put(new BigDecimal(714),1447024l);
		giftcardSkuMap.put(new BigDecimal(715),1447028l);
		giftcardSkuMap.put(new BigDecimal(716),1447042l);
		giftcardSkuMap.put(new BigDecimal(717),1447065l);
		giftcardSkuMap.put(new BigDecimal(718),1447047l);
		giftcardSkuMap.put(new BigDecimal(719),1447051l);
		giftcardSkuMap.put(new BigDecimal(720),1447032l);
		giftcardSkuMap.put(new BigDecimal(721),1447030l);
		giftcardSkuMap.put(new BigDecimal(722),1447036l);
		giftcardSkuMap.put(new BigDecimal(723),1447037l);
		giftcardSkuMap.put(new BigDecimal(724),1447035l);
		giftcardSkuMap.put(new BigDecimal(725),1447041l);
		giftcardSkuMap.put(new BigDecimal(726),1446995l);
		giftcardSkuMap.put(new BigDecimal(727),1447010l);
		giftcardSkuMap.put(new BigDecimal(728),1447016l);
		giftcardSkuMap.put(new BigDecimal(729),1447021l);
		giftcardSkuMap.put(new BigDecimal(730),1447000l);
		giftcardSkuMap.put(new BigDecimal(731),1447002l);
		giftcardSkuMap.put(new BigDecimal(732),1447003l);
		giftcardSkuMap.put(new BigDecimal(733),1446992l);
		giftcardSkuMap.put(new BigDecimal(734),1447004l);
		giftcardSkuMap.put(new BigDecimal(735),1446993l);
		giftcardSkuMap.put(new BigDecimal(736),1447006l);
		giftcardSkuMap.put(new BigDecimal(737),1447017l);
		giftcardSkuMap.put(new BigDecimal(738),1447029l);
		giftcardSkuMap.put(new BigDecimal(739),1447018l);
		giftcardSkuMap.put(new BigDecimal(740),1446994l);
		giftcardSkuMap.put(new BigDecimal(741),1447008l);
		giftcardSkuMap.put(new BigDecimal(742),1447012l);
		giftcardSkuMap.put(new BigDecimal(743),1447009l);
		giftcardSkuMap.put(new BigDecimal(744),1447013l);
		giftcardSkuMap.put(new BigDecimal(745),1447027l);
		giftcardSkuMap.put(new BigDecimal(746),1447023l);
		giftcardSkuMap.put(new BigDecimal(747),1446990l);
		giftcardSkuMap.put(new BigDecimal(748),1446999l);
		giftcardSkuMap.put(new BigDecimal(749),1447001l);
		giftcardSkuMap.put(new BigDecimal(750),1446981l);
		giftcardSkuMap.put(new BigDecimal(751),1446978l);
		giftcardSkuMap.put(new BigDecimal(752),1446979l);
		giftcardSkuMap.put(new BigDecimal(753),1446980l);
		giftcardSkuMap.put(new BigDecimal(754),1446975l);
		giftcardSkuMap.put(new BigDecimal(755),1446987l);
		giftcardSkuMap.put(new BigDecimal(756),1447005l);
		giftcardSkuMap.put(new BigDecimal(757),1447007l);
		giftcardSkuMap.put(new BigDecimal(758),1447015l);
		giftcardSkuMap.put(new BigDecimal(759),1447011l);
		giftcardSkuMap.put(new BigDecimal(760),1446985l);
		giftcardSkuMap.put(new BigDecimal(761),1446996l);
		giftcardSkuMap.put(new BigDecimal(762),1446988l);
		giftcardSkuMap.put(new BigDecimal(763),1446997l);
		giftcardSkuMap.put(new BigDecimal(764),1446989l);
		giftcardSkuMap.put(new BigDecimal(765),1446998l);
		giftcardSkuMap.put(new BigDecimal(766),1446969l);
		giftcardSkuMap.put(new BigDecimal(767),1446970l);
		giftcardSkuMap.put(new BigDecimal(768),1446965l);
		giftcardSkuMap.put(new BigDecimal(769),1446976l);
		giftcardSkuMap.put(new BigDecimal(770),1446971l);
		giftcardSkuMap.put(new BigDecimal(771),1446972l);
		giftcardSkuMap.put(new BigDecimal(772),1446973l);
		giftcardSkuMap.put(new BigDecimal(773),1446977l);
		giftcardSkuMap.put(new BigDecimal(774),1446982l);
		giftcardSkuMap.put(new BigDecimal(775),1446974l);
		giftcardSkuMap.put(new BigDecimal(776),1446983l);
		giftcardSkuMap.put(new BigDecimal(777),1446986l);
		giftcardSkuMap.put(new BigDecimal(778),1446984l);
		giftcardSkuMap.put(new BigDecimal(779),1446991l);
		giftcardSkuMap.put(new BigDecimal(780),1446948l);
		giftcardSkuMap.put(new BigDecimal(781),1446951l);
		giftcardSkuMap.put(new BigDecimal(782),1446943l);
		giftcardSkuMap.put(new BigDecimal(783),1446945l);
		giftcardSkuMap.put(new BigDecimal(784),1446958l);
		giftcardSkuMap.put(new BigDecimal(785),1446960l);
		giftcardSkuMap.put(new BigDecimal(786),1446962l);
		giftcardSkuMap.put(new BigDecimal(787),1446966l);
		giftcardSkuMap.put(new BigDecimal(788),1446955l);
		giftcardSkuMap.put(new BigDecimal(789),1446964l);
		giftcardSkuMap.put(new BigDecimal(790),1446956l);
		giftcardSkuMap.put(new BigDecimal(791),1446950l);
		giftcardSkuMap.put(new BigDecimal(792),1446959l);
		giftcardSkuMap.put(new BigDecimal(793),1446961l);
		giftcardSkuMap.put(new BigDecimal(794),1446963l);
		giftcardSkuMap.put(new BigDecimal(795),1446952l);
		giftcardSkuMap.put(new BigDecimal(796),1446967l);
		giftcardSkuMap.put(new BigDecimal(797),1446953l);
		giftcardSkuMap.put(new BigDecimal(798),1446954l);
		giftcardSkuMap.put(new BigDecimal(799),1446947l);
		giftcardSkuMap.put(new BigDecimal(800),1446930l);
		giftcardSkuMap.put(new BigDecimal(801),1446938l);
		giftcardSkuMap.put(new BigDecimal(802),1446933l);
		giftcardSkuMap.put(new BigDecimal(803),1446934l);
		giftcardSkuMap.put(new BigDecimal(804),1446935l);
		giftcardSkuMap.put(new BigDecimal(805),1446942l);
		giftcardSkuMap.put(new BigDecimal(806),1446939l);
		giftcardSkuMap.put(new BigDecimal(807),1446940l);
		giftcardSkuMap.put(new BigDecimal(808),1446946l);
		giftcardSkuMap.put(new BigDecimal(809),1446944l);
		giftcardSkuMap.put(new BigDecimal(810),1446918l);
		giftcardSkuMap.put(new BigDecimal(811),1446923l);
		giftcardSkuMap.put(new BigDecimal(812),1446910l);
		giftcardSkuMap.put(new BigDecimal(813),1446919l);
		giftcardSkuMap.put(new BigDecimal(814),1446926l);
		giftcardSkuMap.put(new BigDecimal(815),1446927l);
		giftcardSkuMap.put(new BigDecimal(816),1446925l);
		giftcardSkuMap.put(new BigDecimal(817),1446928l);
		giftcardSkuMap.put(new BigDecimal(818),1446932l);
		giftcardSkuMap.put(new BigDecimal(819),1446937l);
		giftcardSkuMap.put(new BigDecimal(820),1446871l);
		giftcardSkuMap.put(new BigDecimal(821),1446872l);
		giftcardSkuMap.put(new BigDecimal(822),1446873l);
		giftcardSkuMap.put(new BigDecimal(823),1446874l);
		giftcardSkuMap.put(new BigDecimal(824),1446867l);
		giftcardSkuMap.put(new BigDecimal(825),1446868l);
		giftcardSkuMap.put(new BigDecimal(826),1446875l);
		giftcardSkuMap.put(new BigDecimal(827),1446881l);
		giftcardSkuMap.put(new BigDecimal(828),1446869l);
		giftcardSkuMap.put(new BigDecimal(829),1446882l);
		giftcardSkuMap.put(new BigDecimal(830),1446807l);
		giftcardSkuMap.put(new BigDecimal(831),1446812l);
		giftcardSkuMap.put(new BigDecimal(832),1446809l);
		giftcardSkuMap.put(new BigDecimal(833),1446816l);
		giftcardSkuMap.put(new BigDecimal(834),1446821l);
		giftcardSkuMap.put(new BigDecimal(835),1446886l);
		giftcardSkuMap.put(new BigDecimal(836),1446891l);
		giftcardSkuMap.put(new BigDecimal(837),1446892l);
		giftcardSkuMap.put(new BigDecimal(838),1446888l);
		giftcardSkuMap.put(new BigDecimal(839),1446890l);
		giftcardSkuMap.put(new BigDecimal(840),1446806l);
		giftcardSkuMap.put(new BigDecimal(841),1446906l);
		giftcardSkuMap.put(new BigDecimal(842),1446840l);
		giftcardSkuMap.put(new BigDecimal(843),1446830l);
		giftcardSkuMap.put(new BigDecimal(844),1446845l);
		giftcardSkuMap.put(new BigDecimal(845),1446784l);
		giftcardSkuMap.put(new BigDecimal(846),1446793l);
		giftcardSkuMap.put(new BigDecimal(847),1446797l);
		giftcardSkuMap.put(new BigDecimal(848),1446803l);
		giftcardSkuMap.put(new BigDecimal(849),1446800l);
		giftcardSkuMap.put(new BigDecimal(850),1446837l);
		giftcardSkuMap.put(new BigDecimal(851),1446790l);
		giftcardSkuMap.put(new BigDecimal(852),1446792l);
		giftcardSkuMap.put(new BigDecimal(853),1446791l);
		giftcardSkuMap.put(new BigDecimal(854),1446785l);
		giftcardSkuMap.put(new BigDecimal(855),1446794l);
		giftcardSkuMap.put(new BigDecimal(856),1446838l);
		giftcardSkuMap.put(new BigDecimal(857),1446796l);
		giftcardSkuMap.put(new BigDecimal(858),1446801l);
		giftcardSkuMap.put(new BigDecimal(859),1446799l);
		giftcardSkuMap.put(new BigDecimal(860),1446761l);
		giftcardSkuMap.put(new BigDecimal(861),1446763l);
		giftcardSkuMap.put(new BigDecimal(862),1446755l);
		giftcardSkuMap.put(new BigDecimal(863),1446766l);
		giftcardSkuMap.put(new BigDecimal(864),1446767l);
		giftcardSkuMap.put(new BigDecimal(865),1446773l);
		giftcardSkuMap.put(new BigDecimal(866),1446781l);
		giftcardSkuMap.put(new BigDecimal(867),1446825l);
		giftcardSkuMap.put(new BigDecimal(868),1446831l);
		giftcardSkuMap.put(new BigDecimal(869),1446820l);
		giftcardSkuMap.put(new BigDecimal(870),1446862l);
		giftcardSkuMap.put(new BigDecimal(871),1446884l);
		giftcardSkuMap.put(new BigDecimal(872),1446885l);
		giftcardSkuMap.put(new BigDecimal(873),1446579l);
		giftcardSkuMap.put(new BigDecimal(874),1446870l);
		giftcardSkuMap.put(new BigDecimal(875),1446878l);
		giftcardSkuMap.put(new BigDecimal(876),1446879l);
		giftcardSkuMap.put(new BigDecimal(877),1446826l);
		giftcardSkuMap.put(new BigDecimal(878),1446750l);
		giftcardSkuMap.put(new BigDecimal(879),1446752l);
		giftcardSkuMap.put(new BigDecimal(880),1446757l);
		giftcardSkuMap.put(new BigDecimal(881),1446776l);
		giftcardSkuMap.put(new BigDecimal(882),1446774l);
		giftcardSkuMap.put(new BigDecimal(883),1446834l);
		giftcardSkuMap.put(new BigDecimal(884),1446823l);
		giftcardSkuMap.put(new BigDecimal(885),1446819l);
		giftcardSkuMap.put(new BigDecimal(886),1446852l);
		giftcardSkuMap.put(new BigDecimal(887),1446847l);
		giftcardSkuMap.put(new BigDecimal(888),1446857l);
		giftcardSkuMap.put(new BigDecimal(889),1446858l);
		giftcardSkuMap.put(new BigDecimal(890),1446859l);
		giftcardSkuMap.put(new BigDecimal(891),1446814l);
		giftcardSkuMap.put(new BigDecimal(892),1446810l);
		giftcardSkuMap.put(new BigDecimal(893),1446815l);
		giftcardSkuMap.put(new BigDecimal(894),1446742l);
		giftcardSkuMap.put(new BigDecimal(895),1446749l);
		giftcardSkuMap.put(new BigDecimal(896),1446743l);
		giftcardSkuMap.put(new BigDecimal(897),1446751l);
		giftcardSkuMap.put(new BigDecimal(898),1446756l);
		giftcardSkuMap.put(new BigDecimal(899),1446745l);
		giftcardSkuMap.put(new BigDecimal(900),1446762l);
		giftcardSkuMap.put(new BigDecimal(901),1446718l);
		giftcardSkuMap.put(new BigDecimal(902),1446853l);
		giftcardSkuMap.put(new BigDecimal(903),1446854l);
		giftcardSkuMap.put(new BigDecimal(904),1446855l);
		giftcardSkuMap.put(new BigDecimal(905),1446833l);
		giftcardSkuMap.put(new BigDecimal(906),1446844l);
		giftcardSkuMap.put(new BigDecimal(907),1446798l);
		giftcardSkuMap.put(new BigDecimal(908),1446795l);
		giftcardSkuMap.put(new BigDecimal(909),1446808l);
		giftcardSkuMap.put(new BigDecimal(910),1446813l);
		giftcardSkuMap.put(new BigDecimal(911),1446849l);
		giftcardSkuMap.put(new BigDecimal(912),1446702l);
		giftcardSkuMap.put(new BigDecimal(913),1446680l);
		giftcardSkuMap.put(new BigDecimal(914),1446706l);
		giftcardSkuMap.put(new BigDecimal(915),1446711l);
		giftcardSkuMap.put(new BigDecimal(916),1446712l);
		giftcardSkuMap.put(new BigDecimal(917),1446709l);
		giftcardSkuMap.put(new BigDecimal(918),1446721l);
		giftcardSkuMap.put(new BigDecimal(919),1446723l);
		giftcardSkuMap.put(new BigDecimal(920),1446726l);
		giftcardSkuMap.put(new BigDecimal(921),1446710l);
		giftcardSkuMap.put(new BigDecimal(922),1446713l);
		giftcardSkuMap.put(new BigDecimal(923),1446725l);
		giftcardSkuMap.put(new BigDecimal(924),1446727l);
		giftcardSkuMap.put(new BigDecimal(925),1446731l);
		giftcardSkuMap.put(new BigDecimal(926),1446736l);
		giftcardSkuMap.put(new BigDecimal(927),1446737l);
		giftcardSkuMap.put(new BigDecimal(928),1446728l);
		giftcardSkuMap.put(new BigDecimal(929),1446732l);
		giftcardSkuMap.put(new BigDecimal(930),1446734l);
		giftcardSkuMap.put(new BigDecimal(931),1446771l);
		giftcardSkuMap.put(new BigDecimal(932),1446772l);
		giftcardSkuMap.put(new BigDecimal(933),1446770l);
		giftcardSkuMap.put(new BigDecimal(934),1446782l);
		giftcardSkuMap.put(new BigDecimal(935),1446775l);
		giftcardSkuMap.put(new BigDecimal(936),1446786l);
		giftcardSkuMap.put(new BigDecimal(937),1446842l);
		giftcardSkuMap.put(new BigDecimal(938),1446788l);
		giftcardSkuMap.put(new BigDecimal(939),1446835l);
		giftcardSkuMap.put(new BigDecimal(940),1446856l);
		giftcardSkuMap.put(new BigDecimal(941),1446691l);
		giftcardSkuMap.put(new BigDecimal(942),1446693l);
		giftcardSkuMap.put(new BigDecimal(943),1446694l);
		giftcardSkuMap.put(new BigDecimal(944),1446689l);
		giftcardSkuMap.put(new BigDecimal(945),1446696l);
		giftcardSkuMap.put(new BigDecimal(946),1446698l);
		giftcardSkuMap.put(new BigDecimal(947),1446836l);
		giftcardSkuMap.put(new BigDecimal(948),1446839l);
		giftcardSkuMap.put(new BigDecimal(949),1446759l);
		giftcardSkuMap.put(new BigDecimal(950),1446754l);
		giftcardSkuMap.put(new BigDecimal(951),1446629l);
		giftcardSkuMap.put(new BigDecimal(952),1446637l);
		giftcardSkuMap.put(new BigDecimal(953),1446641l);
		giftcardSkuMap.put(new BigDecimal(954),1446642l);
		giftcardSkuMap.put(new BigDecimal(955),1446646l);
		giftcardSkuMap.put(new BigDecimal(956),1446632l);
		giftcardSkuMap.put(new BigDecimal(957),1446677l);
		giftcardSkuMap.put(new BigDecimal(958),1446679l);
		giftcardSkuMap.put(new BigDecimal(959),1446670l);
		giftcardSkuMap.put(new BigDecimal(960),1446686l);
		giftcardSkuMap.put(new BigDecimal(961),1446811l);
		giftcardSkuMap.put(new BigDecimal(962),1446804l);
		giftcardSkuMap.put(new BigDecimal(963),1446805l);
		giftcardSkuMap.put(new BigDecimal(964),1446822l);
		giftcardSkuMap.put(new BigDecimal(965),1446818l);
		giftcardSkuMap.put(new BigDecimal(966),1446832l);
		giftcardSkuMap.put(new BigDecimal(967),1446612l);
		giftcardSkuMap.put(new BigDecimal(968),1446626l);
		giftcardSkuMap.put(new BigDecimal(969),1446625l);
		giftcardSkuMap.put(new BigDecimal(970),1446615l);
		giftcardSkuMap.put(new BigDecimal(971),1446656l);
		giftcardSkuMap.put(new BigDecimal(972),1446653l);
		giftcardSkuMap.put(new BigDecimal(973),1446654l);
		giftcardSkuMap.put(new BigDecimal(974),1446661l);
		giftcardSkuMap.put(new BigDecimal(975),1446666l);
		giftcardSkuMap.put(new BigDecimal(976),1446659l);
		giftcardSkuMap.put(new BigDecimal(977),1446741l);
		giftcardSkuMap.put(new BigDecimal(978),1446778l);
		giftcardSkuMap.put(new BigDecimal(979),1446783l);
		giftcardSkuMap.put(new BigDecimal(980),1446780l);
		giftcardSkuMap.put(new BigDecimal(981),1446587l);
		giftcardSkuMap.put(new BigDecimal(982),1446597l);
		giftcardSkuMap.put(new BigDecimal(983),1446598l);
		giftcardSkuMap.put(new BigDecimal(984),1446593l);
		giftcardSkuMap.put(new BigDecimal(985),1446595l);
		giftcardSkuMap.put(new BigDecimal(986),1446590l);
		giftcardSkuMap.put(new BigDecimal(987),1446649l);
		giftcardSkuMap.put(new BigDecimal(988),1446644l);
		giftcardSkuMap.put(new BigDecimal(989),1446635l);
		giftcardSkuMap.put(new BigDecimal(990),1446650l);
		giftcardSkuMap.put(new BigDecimal(991),1446708l);
		giftcardSkuMap.put(new BigDecimal(992),1446719l);
		giftcardSkuMap.put(new BigDecimal(993),1446715l);
		giftcardSkuMap.put(new BigDecimal(994),1446738l);
		giftcardSkuMap.put(new BigDecimal(995),1446733l);
		giftcardSkuMap.put(new BigDecimal(996),1446740l);
		giftcardSkuMap.put(new BigDecimal(997),1446586l);
		giftcardSkuMap.put(new BigDecimal(998),1446580l);
		giftcardSkuMap.put(new BigDecimal(999),1446591l);
		giftcardSkuMap.put(new BigDecimal(1000),1447652l);
		
	}
	@Override
	public String buy(BizGiftcardOrder bizGiftcardOrder) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BUY,false,true);
		MapResult result = new MapResult();
		result.setSuccess(false);
		if(StringUtils.isBlank(bizGiftcardOrder.getThirdOrder())){
			result.setResultMessage("thirdOrder不能为空");
			return APIUtils.parseObject2Json(result);
		}
		
		if(StringUtils.isBlank(bizGiftcardOrder.getSku())){
			result.setResultMessage("sku不能为空");
			return APIUtils.parseObject2Json(result);
		}
		
		if(StringUtils.isBlank(bizGiftcardOrder.getMobile())){
			result.setResultMessage("mobile不能为空");
			return APIUtils.parseObject2Json(result);
		}
		
		SkuList skuList = OrderConvertUtils.parsingSkuList(bizGiftcardOrder.getSku());
		if(skuList == null){
			result.setResultMessage("sku格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		List<Sku> skuDetaillist = skuList.getSku();
		if(skuDetaillist == null || skuDetaillist.size() == 0){
			result.setResultMessage("sku格式不正确");
			return APIUtils.parseObject2Json(result);
		}

		List<Sku> newSkulist = new ArrayList<Sku>();
		for(int i=0;i<skuDetaillist.size();i++){
			Sku sku = skuDetaillist.get(i);
			Long skuId = giftcardSkuMap.get(sku.getPrice());
			if(skuId == null){
				result.setResultMessage(skuDetaillist.get(i).getPrice() + "不存在");
				return APIUtils.parseObject2Json(result);
			}
			sku.setName(sku.getPrice() + "礼品卡");
			sku.setCategory(6980);
			sku.setSkuId(skuId);
			newSkulist.add(sku);
		}
		try{
			BigDecimal orderPrice = baseOrderService.calculateOrderPrice(APIUtils.parseObject2Json(newSkulist));
			CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.BALANCESERVICE_GETBALANCE,false,true);
			try {
				//判断用户余额是否充足
				BigDecimal balance = bizPayService.getBalance(APIUtils.getPin(), PayTypeEnum.BALANCE.getType());
				
				if (balance == null) {
					LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("用户余额为空{}",APIUtils.getPin());
					result.setSuccess(false);
					result.setResultMessage("您的余额为空");
					return APIUtils.parseObject2Json(result);
				}
				// 计算用户余额是否充足
				if (balance.compareTo(orderPrice) == -1) {
					LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("用户余额不足	pin:{} 余额为：{}",APIUtils.getPin(),balance);
					result.setSuccess(false);
					result.setResultMessage("您的余额不足");
					return APIUtils.parseObject2Json(result);
				}
			} catch (Exception e) {
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e,"代码执行异常-codeException,礼品卡用户余额校验失败	pin:{} ",APIUtils.getPin());
				Profiler.functionError(callerInfo2);
			} finally{
				Profiler.registerInfoEnd(callerInfo2);
			}
			
			
			BizGiftcardOrder dbBizGiftcardOrder = new BizGiftcardOrder();
			dbBizGiftcardOrder.setClientId(APIUtils.getClientId());
			dbBizGiftcardOrder.setPin(APIUtils.getPin());
			dbBizGiftcardOrder.setThirdOrder(bizGiftcardOrder.getThirdOrder());
			
			//判断thirdOrder是否唯一
			if(this.bizGiftcardOrderManager.checkThirdOrderExist(dbBizGiftcardOrder) > 0){
				result.setResultMessage(dbBizGiftcardOrder.getThirdOrder()+"已存在，请勿重复下单");
				return APIUtils.parseObject2Json(result);
			}
			
			dbBizGiftcardOrder.setSku(APIUtils.parseObject2Json(newSkulist));
			dbBizGiftcardOrder.setOrderPrice(baseOrderService.calculateOrderPrice(dbBizGiftcardOrder.getSku()));
			dbBizGiftcardOrder.setCreated(new Date());
			dbBizGiftcardOrder.setIp(bizGiftcardOrder.getIp());
			dbBizGiftcardOrder.setMobile(bizGiftcardOrder.getMobile());
			dbBizGiftcardOrder.setModified(new Date());
			dbBizGiftcardOrder.setOrderguid(baseOrderService.createOrderguid(dbBizGiftcardOrder.getClientId()));
			dbBizGiftcardOrder.setOrderResult("刚下单，还未生成订单号");
			dbBizGiftcardOrder.setOrderState(0);//刚下单
			dbBizGiftcardOrder.setPaymentType(4);//支付类型	在线支付
			dbBizGiftcardOrder.setYn(1);//有效
			
			Long id = bizGiftcardOrderManager.submitBizGiftcardOrder(dbBizGiftcardOrder);//先入库
			LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("成功记录礼品卡下单信息，先入库		id={}",id);
			dbBizGiftcardOrder.setId(id);
			
			//客户端信息
			ClientInfo clientInfo = new ClientInfo();
			clientInfo.setServerName("企销api");
			clientInfo.setClientIP("172.17.15.47");
			//企销代下单 100670、旧版的企销API 100671、方正平台 100672、旧版企销API电子礼品卡100674。新版企销api是100005。找研发王凯申请。
			clientInfo.setBussinessType(100005); 
			clientInfo.setWebOriginId(3);
			clientInfo.setOriginId(1); //手机端下单这个值传 2
			clientInfo.setUserIP(dbBizGiftcardOrder.getIp());
			
			//购物车;
			CartVO cartVO = new CartVO();
			List<ProductSetVO> products = new ArrayList<ProductSetVO>();
			for(int i=0;i < newSkulist.size();i++) {
				Sku sku = newSkulist.get(i);
				ProductSetVO productSetVO = new ProductSetVO();
				SkuVO skuVo = new SkuVO();
				skuVo.setId(sku.getSkuId() + "");//商品编号。电影票商品编号固定
				skuVo.setNum(sku.getNum());//商品数量，对应老的订单接口的num 属性
				skuVo.setCid(sku.getCategory());//商品的三级分类,对应老订单接口中的 cid属性;
				skuVo.setName(sku.getName());//商品名称,对应老订单接口中的name 属性;
				skuVo.setPrice(new Money(sku.getPrice()));// 商品单价,对应老接口中Price 属性;
				productSetVO.setMainSku(skuVo);
				products.add(productSetVO);
			}
			cartVO.setProducts(products);
			cartVO.setTotalPrice(new Money(dbBizGiftcardOrder.getOrderPrice())); //订单总金额=商品单价*数量
			
			
			//订单参数
			OrderParam orderParam = new OrderParam();
			orderParam.setOrderGuid(dbBizGiftcardOrder.getOrderguid());//下单唯一标识，用于反查。此处传"pin_第三方订单号"
			orderParam.setPin(dbBizGiftcardOrder.getPin());//用户帐号;
			
			//收货人信息
			AddressParam addressParam = new AddressParam();
			addressParam.setProvinceId(1);//省
			addressParam.setCityId(72);//市
			addressParam.setCountyId(2799);//县
			addressParam.setTownId(0);//区，没四级地址可不传，例如北京。
			addressParam.setAddressDetail("礼品卡虚拟地址");//详细地址信息
			//addressParam.setOrgId(543); //机构号，可以不传
			addressParam.setName("虚拟客户");//设置收货人姓名,不然MQ那里会卡死;
			addressParam.setMobile(dbBizGiftcardOrder.getMobile());//收货人电话
			//addressParam.setEmail(bizOrder.getEmail());//收货人邮箱
			orderParam.setAddress(addressParam);
			
			
			//支付方式
			CombinationPaymentParam payType = new CombinationPaymentParam();
			payType.setMainPaymentType(dbBizGiftcardOrder.getPaymentType());//在线支付，余额支付方式
			orderParam.setCombinationPayment(payType);//支付方式
			
			// 让订单组不进行扣余，进行异步支付.
			/*BalanceParam balance = new BalanceParam();//使用余额
			balance.setUseBalance(true);
			orderParam.setBalance(balance);*///使用余额支付
			 			
			
			// 发票信息(如果不开发票，也要特意指定一下)
			InvoiceParam invoice = new InvoiceParam();
			invoice.setInvoicePutType(3); // 如果不开发票，需要将invoicePutType设置成3
			orderParam.setInvoice(invoice);
			
			
			// 配送方式
			CombinationShipmentParam combinationShipmentParam = new CombinationShipmentParam();
			ShipmentParam jdShipmentType = new ShipmentParam();// 京东配送
			jdShipmentType.setShipmentType(65);// 配送方式 京配
			Date now = new Date();
			jdShipmentType.setShipmentDate(now);// 送货日期 当天
			/**送货时间,参见CodTimeTypeDict [1：工作日送货,2：休息日送货,3：工作加休息日均送货 4:311配送 5:411配送]，必传**/
			jdShipmentType.setShipmentTimeType(3);
			jdShipmentType.setBigItemShipmentDate(now);
			jdShipmentType.setBigItemInstallDate(now);
			combinationShipmentParam.setJdShipmentType(jdShipmentType);// 京东配送
			orderParam.setCombinationShipment(combinationShipmentParam);
			
			//orderParam.setOrderNeedMoney(new BigDecimal(0));//结算金额(应收)=订单总金额 - 优惠金额(券,礼品卡,余额,京豆)
			orderParam.setOrderNeedMoney(dbBizGiftcardOrder.getOrderPrice());
			
			/**订单Necessary参数 ，可以传，可以不传**/
			SubmitOrderNecessary submitOrderNecessary = new SubmitOrderNecessary();
			/**设置订单备注**/
			submitOrderNecessary.setRemark("");//限制小于45字符
			submitOrderNecessary.setOrderType(33); //电子卡
			
			Map<Integer, Integer> sendPayTagMap=new HashMap<Integer, Integer>();
			
			//订单需打上不取消的标记即第3位写4  
	        sendPayTagMap.put(3,4);
	        
			sendPayTagMap.put(40,2);
			
	        submitOrderNecessary.setSendPayTagMap(sendPayTagMap);
	        
			
			// 汇总参数; IgnoreStepDict字典在这个类中,可以参考;
			List<Integer> ignoreList = new ArrayList<Integer>();
			ignoreList.add(IgnoreStepDict.PROMOTIONIGNORE);//不过促销
			ignoreList.add(IgnoreStepDict.STOCKIGNORE);// 不过库存
			ignoreList.add(IgnoreStepDict.ORDERTYPEIGNORE);//以传过来的订单类型为准
			ignoreList.add(IgnoreStepDict.PAYMENTIGNORE); //以传过来的支付方式为准
			ignoreList.add(IgnoreStepDict.SHIPMENTIGNORE); // 不过配送方式
			ignoreList.add(IgnoreStepDict.ADDRESSIGNORE);  //不过地址
			ignoreList.add(IgnoreStepDict.FREIGHTIGNORE);  //没有运费, 传值  0
			ignoreList.add(IgnoreStepDict.PAYPASSWORDIGNORE);  // 不过支付密码
			//list.add(IgnoreStepDict.ORGIDIGNORE); //机构号以传过来的为准
			//list.add(IgnoreStepDict.XUNILIUCHENG);//虚拟商品MQ那里使用；
			CallerInfo callerInfo3=Profiler.registerInfo(UMPFunctionKeyConstant.SUBMITORDEREXPORT_SUBMITORDER, false, true);
			//下单
			try {
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("礼品卡下单开始，入参如下：");
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("cartVO={}",APIUtils.parseObject2Json(cartVO));
				String orderParamStr=APIUtils.parseObject2Json(orderParam);
				orderParamStr=orderParamStr.replaceAll("(?<=\"(mobile|phone)\":\")\\d+(?=\")", "***");				
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("orderParam={}",orderParamStr);
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("clientInfo={}",APIUtils.parseObject2Json(clientInfo));
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("submitOrderNecessary={}",APIUtils.parseObject2Json(submitOrderNecessary));
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("ignoreList={}",APIUtils.parseObject2Json(ignoreList));
			} catch (Exception e1) {
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e1,"礼品卡下单入参参数打印失败！");
			}
			SubmitOrderResult submitOrderResult =  submitOrderExport.submitOrder(cartVO, 
					orderParam, clientInfo, submitOrderNecessary, null, ignoreList);
			Profiler.registerInfoEnd(callerInfo3);
			if(submitOrderResult == null){
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("礼品卡下单为空	id={}",id);
				result.setSuccess(false);
				result.setResultCode("");
				result.setResultMessage("下单异常，请稍后重试");
				return APIUtils.parseObject2Json(result);
			}
			try{
				dbBizGiftcardOrder.setOrderResult(submitOrderResult.getMessage());
				dbBizGiftcardOrder.setJdOrderId(submitOrderResult.getOrderId());
				dbBizGiftcardOrder.setId(id);
				this.bizGiftcardOrderManager.updateBizGiftcardOrderState(dbBizGiftcardOrder);//修改订单状态
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("成功修改礼品卡数据库	id={}",id);
			}catch (Exception e) {
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e,"修改礼品卡订单异常		id={}",id);
			}
			
			if(submitOrderResult.isResultFlag()){
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("礼品卡最终下单成功 ！	id={}",id);
				
				// 礼品卡下单成功，插入异步支付任务
				// add by ylei, 2015-03-19
				insertCreditPayTask(dbBizGiftcardOrder, APIUtils.getPin());
				
				result.setSuccess(true);
				result.setResultMessage("礼品卡下单成功");
				Map<String, Object> resultMap = new HashMap<String, Object>();
				resultMap.put("jdOrderId", dbBizGiftcardOrder.getJdOrderId());
				resultMap.put("sku", newSkulist);
				resultMap.put("orderPrice", dbBizGiftcardOrder.getOrderPrice());
				result.setResult(resultMap);
				return APIUtils.parseObject2Json(result);
			}else{
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("礼品卡最终下单失败		id={}",id);
				result.setSuccess(false);
				result.setResultMessage("礼品卡下单失败："+submitOrderResult.getMessage());
				return APIUtils.parseObject2Json(result);
			}
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e,"礼品卡下单异常了！	pin={}",APIUtils.getPin());
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		result.setSuccess(false);
		result.setResultMessage("网络繁忙，请稍后重试");
		return APIUtils.parseObject2Json(result);
	}

	/**
	 * 插入支付任务.
	 * 
	 * @param jdOrderId 京东订单号
	 * @param pin 用户pin
	 * @throws BizOrderServiceException 
	 */
	private void insertCreditPayTask(BizGiftcardOrder bizOrder, String pin) throws BizOrderServiceException{
		CallerInfo ci = Profiler.registerInfo(UMPFunctionKeyConstant.CALL_PAYSERVICE_PAY,false,true);
		try {
			BizPayTask payTask = new BizPayTask();
			payTask.setFlag(OrderConstants.PAY_FLAG_GIFT);		// 设置标志位，用来辨别在MQ中是否是自己的订单
			payTask.setIp(bizOrder.getIp());
			payTask.setJdOrderId(bizOrder.getJdOrderId());
			payTask.setCreated(new Date());
			payTask.setOrderPrice(bizOrder.getOrderPrice());
			payTask.setPayMoney(bizOrder.getOrderPrice());
			payTask.setPayType(bizOrder.getPaymentType());
			payTask.setPayWay(PayWayEnum.SLOW_PAY.getType());
			payTask.setPin(bizOrder.getPin());
			payTask.setRetryTimes(5);
			bizPayService.pay(payTask);
		} catch (BizPayException e){
			throw new BizOrderServiceException(BizOrderServiceErrorCode.CODE_EXCEPTION, "调用支付中心接口发起支付失败");
		} catch (Exception e) {
			LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e, "CODE-EXCEPTION 确认订单发起支付失败， jdOrderId:{}", bizOrder.getJdOrderId());
			Profiler.functionError(ci);
		} finally {
			Profiler.registerInfoEnd(ci);
		}
		LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("插入礼品卡异步支付任务成功[jdOrderId = {}]", bizOrder.getJdOrderId());
	}
	
	
	@Override
	public String selectGiftcardsByJdOrderId(String jdOrderId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.SELECT_GIFT_CARDS_BY_JD_ORDER_ID,false,true);
		ListResult result = new ListResult();
		result.setSuccess(false);		
		try{
			Long orderId = 0l;
			if(StringUtils.isBlank(jdOrderId)){
				result.setResultMessage("jdOrderId不能为空");
				return APIUtils.parseObject2Json(result);
			}
			try{
				orderId = Long.parseLong(jdOrderId);
				if(orderId == 0){
					LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("jdOrderId传入为{}", jdOrderId);
					result.setResultMessage("jdOrderId不能为0");
					return APIUtils.parseObject2Json(result);
				}
			}catch (Exception e) {
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e,"BizGiftcarOrderServiceImpl.selectGiftcardsByJdOrderId -ERROR");
				result.setResultMessage("jdOrderId格式不正确");
				return APIUtils.parseObject2Json(result);
			}
			BizGiftcardOrder bizGiftcardOrder = new BizGiftcardOrder();
			bizGiftcardOrder.setClientId(APIUtils.getClientId());
			bizGiftcardOrder.setPin(APIUtils.getPin());
			bizGiftcardOrder.setJdOrderId(orderId);
			BizGiftcardOrder dbBizGiftcardOrder = this.bizGiftcardOrderManager.selectBizGiftcardOrder(bizGiftcardOrder);
			if(dbBizGiftcardOrder == null){
				result.setResultMessage("订单不存在");
				return APIUtils.parseObject2Json(result);
			}
			
//			if(dbBizGiftcardOrder.getOrderState() == 0){
//				result.setResultMessage("正在制卡中，请稍后查询");
//				return APIUtils.parseObject2Json(result);
//			}
			CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.MONTHLYPAYMENTSERVICE_QUERYBIZPAYFIRSTCARDS, false, true);
			Result<List<GiftCard>> giftCardResult = monthlyPaymentService.queryBizPayFirstCards(orderId, APIUtils.getPin());
			Profiler.registerInfoEnd(callerInfo2);
			if(!giftCardResult.getSuccess()){
				result.setSuccess(false);
				result.setResultMessage(giftCardResult.getErrorMsg());
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("jdOrderId为{}的查询接口返回：{}",jdOrderId,giftCardResult.getErrorMsg());
				return APIUtils.parseObject2Json(result);
			}
			
			List<GiftCard> list = giftCardResult.getValue();
			List<Map<String, String>> resultList = new ArrayList<Map<String,String>>();
			String clientSecret = clientInfoService.queryClientInfoByClientId(APIUtils.getClientId()).getClientSecret();
			LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("礼品卡秘钥：" + clientSecret.substring(0, 8));
			for(GiftCard giftCard : list){
				Map<String, String> map = new HashMap<String, String>();
				map.put("id", giftCard.getId());
				map.put("pwdKey", DESUtil.encrypt(giftCard.getPwdKey(), clientSecret.substring(0, 8)));
				resultList.add(map);
			}
			result.setResult(resultList);
			result.setSuccess(true);
			result.setResultMessage("");
			result.setResultCode("");
			return APIUtils.parseObject2Json(result);
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e,"查询礼品卡信息");
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}		
		return APIUtils.parseObject2Json(result);
	}
	
	@Override
	public String selectJdOrderByThirdOrder(String thirdOrder) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.SELECT_JD_ORDER_BY_THIRD_ORDER,false,true);
		MapResult result = new MapResult();
		result.setSuccess(false);
		try{
			if(StringUtils.isBlank(thirdOrder)){
				result.setResultMessage("thirdOrder不能为空");
				return APIUtils.parseObject2Json(result);
			}		
			BizGiftcardOrder bizGiftcardOrder = new BizGiftcardOrder();
			bizGiftcardOrder.setPin(APIUtils.getPin());
			bizGiftcardOrder.setClientId(APIUtils.getClientId());
			bizGiftcardOrder.setThirdOrder(thirdOrder);
			
			BizGiftcardOrder dbBizGiftcardOrder = this.bizGiftcardOrderManager.selectJdOrderByThirdOrder(bizGiftcardOrder);
			
			if(dbBizGiftcardOrder == null){
				result.setResultMessage("该订单不存在");
				return APIUtils.parseObject2Json(result);
			}
			Map<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("jdOrderId", dbBizGiftcardOrder.getJdOrderId());
			resultMap.put("sku", APIUtils.parseJson2Object(dbBizGiftcardOrder.getSku(), List.class));
			resultMap.put("orderPrice", dbBizGiftcardOrder.getOrderPrice());
			result.setResult(resultMap);
			result.setSuccess(true);
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e,"第三方订单号：{}",thirdOrder);
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}
	
	public void setBaseOrderService(BaseOrderService baseOrderService) {
		this.baseOrderService = baseOrderService;
	}

	public void setSubmitOrderExport(SubmitOrderExport submitOrderExport) {
		this.submitOrderExport = submitOrderExport;
	}

	public void setBizGiftcardOrderManager(
			BizGiftcardOrderManager bizGiftcardOrderManager) {
		this.bizGiftcardOrderManager = bizGiftcardOrderManager;
	}

	public void setMonthlyPaymentService(MonthlyPaymentService monthlyPaymentService) {
		this.monthlyPaymentService = monthlyPaymentService;
	}
	
	public void setClientInfoService(ClientInfoService clientInfoService) {
		this.clientInfoService = clientInfoService;
	}
	
	@Override
	public String sendSms(String jdOrderId, String mobile, String pin, String clientId) {
		CallerInfo callerInfo2=Profiler.registerInfo(UMPFunctionKeyConstant.SEND_GIFT_CARD_SMS,false,true);
		StringResult result = new StringResult();
		result.setSuccess(false);		
		try {
			//0.参数校验
			if(StringUtils.isEmpty(jdOrderId) || jdOrderId.trim().equals("")){
				result.setResultMessage("输入订单号为空！");
				return APIUtils.parseObject2Json(result);
			}
			Long orderId;
			try {
				orderId = Long.valueOf(jdOrderId.trim());
			} catch (Exception e) {
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error(e,"转化订单号失败，待转化订单号={}",jdOrderId);
				result.setResultMessage("请输入正确的订单号");
				return APIUtils.parseObject2Json(result);
			}
			if(StringUtils.isEmpty(mobile) || mobile.trim().equals("")){
				result.setResultMessage("输入手机号为空！");
				return APIUtils.parseObject2Json(result);
			}
			BizGiftcardOrder query = new BizGiftcardOrder();
			query.setClientId(clientId);
			query.setPin(pin);
			query.setJdOrderId(orderId);
			BizGiftcardOrder giftOrder = bizGiftcardOrderManager.selectBizGiftcardOrder(query);
			if(null == giftOrder){
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("clinentId={},pin={},orderId={}",clientId,pin,orderId);
				result.setResultMessage("系统中不存在该订单号，输入的订单号："+jdOrderId);
				return APIUtils.parseObject2Json(result);
			}
			if(!mobile.trim().equals(giftOrder.getMobile())){
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("输入的手机号={},订单中的手机号={}",mobile,giftOrder.getMobile());
				result.setResultMessage("输入的手机号与订单中的手机号不一致！");
				return APIUtils.parseObject2Json(result);
			}
			//1.业务处理
			Result sendResult = monthlyPaymentService.sendSmsForBalanceCard(orderId, pin, mobile.trim(), "VOP");
			LogTypeEnum.SUBMIT_ORDER_LOG.info("发送短信输出对象={}",APIUtils.parseObject2Json(sendResult));
			if(null == sendResult){
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("接口调用入参:orderId={},pin={},mobile={}",orderId,pin,mobile.trim());
				result.setResultMessage("网络异常，请稍后重试！");
				return APIUtils.parseObject2Json(result);
			}
			if(!sendResult.getSuccess()){
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("接口调用入参:orderId={},pin={},mobile={}",orderId,pin,mobile.trim());
				LogTypeEnum.SUBMIT_GIFTCARD_ORDER_LOG.error("礼品卡补发短信失败,返回信息:errorCode={},errorMsg={}",sendResult.getResultCode(),sendResult.getErrorMsg());
				result.setResultMessage("礼品卡补发短信失败");
				return APIUtils.parseObject2Json(result);
			}			
			//2.成功对象返回
			result.setSuccess(true);
			result.setResult("礼品卡补发短信成功！");
			return APIUtils.parseObject2Json(result);
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"礼品卡短信补发失败,入参：jdOrderId={},mobile={},pin={}",jdOrderId,mobile,pin);
			result.setSuccess(false);
			result.setResultMessage("礼品卡短信补发失败！");
			Profiler.functionError(callerInfo2);
		}finally{
			Profiler.registerInfoEnd(callerInfo2);
		}
		return APIUtils.parseObject2Json(result);
	}
	
	public static void main(String[] args) {
		String jdOrderId = "  ";
		if(StringUtils.isEmpty(jdOrderId) || jdOrderId.trim().equals("")){
			System.out.println("为空");
		}
	}

	public void setBizPayService(BizPayService bizPayService) {
		this.bizPayService = bizPayService;
	}

}
