package com.jd.sns.biz.api.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;
import com.alibaba.fastjson.JSON;
import com.jd.common.util.StringUtils;
import com.jd.ka.price.soa.sdk.enums.PriceType;
import com.jd.ka.price.soa.sdk.service.GetJdPriceService;
import com.jd.ka.price.soa.sdk.service.GetRTPriceService;
import com.jd.ka.price.soa.sdk.service.GetRedisPriceService;
import com.jd.ka.price.soa.sdk.vo.request.QRTPricesReqVO;
import com.jd.ka.price.soa.sdk.vo.request.QRedisPricesReqVO;
import com.jd.ka.price.soa.sdk.vo.response.KaPriceResult;
import com.jd.ka.price.soa.sdk.vo.response.QRTPriceRespVO;
import com.jd.ka.price.soa.sdk.vo.response.QRTPricesRespVO;
import com.jd.ka.price.soa.sdk.vo.response.QRedisPricesRespVO;
import com.jd.ka.price.soa.sdk.vo.response.RTPriceVO;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizSkuList;
import com.jd.sns.biz.api.domain.Sku;
import com.jd.sns.biz.api.domain.SkuList;
import com.jd.sns.biz.api.manager.BizPoolSkuManager;
import com.jd.sns.biz.api.service.BaseOrderService;
import com.jd.sns.biz.api.service.JdPriceService;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.utils.OrderConvertUtils;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value = "baseOrderService")
public class BaseOrderServiceImpl implements BaseOrderService {
//    private static final Logger log = LoggerFactory.getLogger(BaseOrderServiceImpl.class);
    private BizPoolSkuManager bizPoolSkuManager;
    
    private GetRTPriceService getRTPriceService;
    private GetJdPriceService getJdPriceService;
    
	/**
     * 判断商品是否在商品池中
     *
     * @param demandOrder
     * @param result
     * @return
     */
    @Override
    public MapResult checkSkuListExist(String skuString, MapResult result) {
    	CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_SKU_LIST_EXIST,false,true);
        try {
			result.setSuccess(false);
			SkuList skuList = OrderConvertUtils.parsingSkuList(skuString);
			if (skuList == null) {
			    result.setResultMessage("sku格式不正确");
			    return result;
			}
			
			Map<Long, Object> validateMap = new HashMap<Long, Object>();
			try {
			    for (Sku sku : skuList.getSku()) {
			    	if(validateMap.get(sku.getSkuId()) != null){
			    		result.setResultMessage("商品列表中有重复的商品");
			            return result;
			    	}
			    	
			        validateMap.put(sku.getSkuId(), sku);
			    }
			    
			    List<Long> illegalSkus = bizPoolSkuManager.checkCanBySkuIds(validateMap.keySet(), APIUtils.getClientId());
			    if(!illegalSkus.isEmpty()){
			    	result.setResultMessage("商品列表中含有不能购买的商品" + JSON.toJSONString(illegalSkus));
		            return result;
			    }
			    
			    if (validateMap.size() > 100) {
			        result.setResultMessage("sku数量过多，目前最大支持100种商品");
			        return result;
			    }
			} catch (Exception e) {
			    LogTypeEnum.DEFAULT.error(e,"判断商品是否在数据库中异常");
			    result.setResultMessage("服务异常，请重试");
			    Profiler.functionError(callerInfo);
			    return result;
			}        
			result.setSuccess(true);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"代码执行异常-CodeExcepiton BaseOrderServiceImpl.checkSkuListExist 判断商品是否在数据库中异常-ERROR");
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
        return result;
    }

    @Override
    public MapResult assembleSkuPrice(int payType, SkuList skuList, MapResult result,List<RTPriceVO> respVos) {
        CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BATCH_GET_PRICES,false,true);
        Set<Long> skuIdSet = new HashSet<Long>();
    	for (Sku sku : skuList.getSku()){
    		skuIdSet.add(sku.getSkuId());
    	}
        try {
        	QRTPricesReqVO reqVo = new QRTPricesReqVO();
            reqVo.setPin(APIUtils.getPin());
            reqVo.setSkuSet(skuIdSet);
        	KaPriceResult<QRTPricesRespVO> kaPriceResult = null;
        	if (payType == PriceType.PCL_PRICE_LOWER.getType() || payType == PriceType.PCL_PRICE_SOLID.getType()) {//如果是协议价
                	kaPriceResult = getSellPrices(reqVo);
        	}else{
        			kaPriceResult = getJdPrices(reqVo);
        	}
        	respVos.addAll(kaPriceResult.getModel().getPriceList());
        	LogTypeEnum.DEFAULT.error("价格查询调用价格服务接口:{}", APIUtils.parseObject2Json(kaPriceResult));
        	if(kaPriceResult == null || !kaPriceResult.isSuccess()){
        		LogTypeEnum.DEFAULT.error("获取价格接口异常	skuIds={}", skuIdSet);
                result.setResultMessage("从价格服务获取价格异常");
        		return result;
        	}
        	
        	List<RTPriceVO> rtPriceVOList = kaPriceResult.getModel().getPriceList();
        	Map<Long,BigDecimal> priceMap = new HashMap<Long, BigDecimal>();
        	for(RTPriceVO rtPrice : rtPriceVOList){
        		if(rtPrice.getPrice() == null ){
        			LogTypeEnum.DEFAULT.error("{}价格不存在	priceType={}",rtPrice.getSkuId(), payType);
                    //如果根据该id获取不到价格，则代表该skuid没有协议价，则不允许提交需求单
                    result.setSuccess(false);
                    result.setResultMessage("商品id：" + rtPrice.getSkuId() + "价格不存在或者已经下架");
                    return result;
        		}
        		if (rtPrice.getPrice().compareTo(BigDecimal.ZERO) <= 0) {
                	LogTypeEnum.DEFAULT.error("{}价格不大于0	priceType={}  价格：{}" ,rtPrice.getSkuId() , payType , rtPrice.getPrice());
                    result.setSuccess(false);
                    result.setResultMessage("商品:" + rtPrice.getSkuId() + "价格不存在或者已经下架");
                    return result;
                }
        		priceMap.put(rtPrice.getSkuId(), rtPrice.getPrice());
        	}
        	for (Sku sku : skuList.getSku()){
        		sku.setPrice(priceMap.get(sku.getSkuId()));
        	}
        	
        } catch (Exception e) {
        	LogTypeEnum.DEFAULT.error(e,"代码执行异常-CodeExcepiton 获取价格接口异常	skuIds={}", skuIdSet);
            result.setResultMessage("服务异常，请检查参数后重试");
            Profiler.functionError(callerInfo);
        }
        result.setSuccess(true);
        return result;
    }
    
    private KaPriceResult<QRTPricesRespVO> getSellPrices(QRTPricesReqVO reqVo) throws Exception {
    	KaPriceResult<QRTPricesRespVO> kaPriceResult = null;
		CallerInfo getRTPriceInfo = Profiler.registerInfo(UMPFunctionKeyConstant.GETRTPRICE_GETSELLPRICES,false,true);
        try{
        	kaPriceResult =  getRTPriceService.getSellPrices(reqVo);
        }catch (Exception e) {
			Profiler.functionError(getRTPriceInfo);
			throw e;
		}finally{
			Profiler.registerInfoEnd(getRTPriceInfo);
		}
		return kaPriceResult;
    }
    
    private KaPriceResult<QRTPricesRespVO> getJdPrices(QRTPricesReqVO reqVo) throws Exception {
    	KaPriceResult<QRTPricesRespVO> kaPriceResult = null;
		CallerInfo getJdPriceInfo = Profiler.registerInfo(UMPFunctionKeyConstant.GETJDPRICE_GETJDPRICES,false,true);
		try {
			kaPriceResult = getJdPriceService.getJdPrices(reqVo);
		} catch (Exception e) {
			Profiler.functionError(getJdPriceInfo);
			throw e;
		}finally{
			Profiler.registerInfoEnd(getJdPriceInfo);
		}
		return kaPriceResult;
    }

    /**
     * 计算订单总金额
     *
     * @param skuString
     * @return
     */
    @Override
    public BigDecimal calculateOrderPrice(String skuString) {
        if (StringUtils.isBlank(skuString)) {
            return null;
        }
        SkuList skuList = OrderConvertUtils.parsingSkuList(skuString);
        return this.calculateOrderPrice(skuList);
    }

    /**
     * 计算订单总金额
     *
     * @param skuString
     * @return
     */
    @Override
    public BigDecimal calculateOrderPrice(SkuList skuList) {
        if (skuList == null) {
            return null;
        }
        BigDecimal result = new BigDecimal(0);
        for (Sku sku : skuList.getSku()) {
            result = result.add(sku.getPrice().multiply(new BigDecimal(sku.getNum())));
        }
        return result;
    }

    @Override
    public String createOrderguid(String clientId) {
        return "bizapi-clientId-" + UUID.randomUUID().toString();
    }

    public void setBizPoolSkuManager(BizPoolSkuManager bizPoolSkuManager) {
        this.bizPoolSkuManager = bizPoolSkuManager;
    }

	public void setGetRTPriceService(GetRTPriceService getRTPriceService) {
		this.getRTPriceService = getRTPriceService;
	}

	public void setGetJdPriceService(GetJdPriceService getJdPriceService) {
		this.getJdPriceService = getJdPriceService;
	}
    
    
}
