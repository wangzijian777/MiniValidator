package com.jd.sns.biz.api.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.jd.common.util.StringUtils;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizOrderFlow;
import com.jd.sns.biz.api.manager.BizOrderFlowManager;
import com.jd.sns.biz.api.manager.BizOrderManager;
import com.jd.sns.biz.api.service.BizOrderFlowService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="bizOrderFlowService")
public class BizOrderFlowServiceImpl implements BizOrderFlowService {
//	private static final Logger log = LoggerFactory.getLogger(BizOrderFlowServiceImpl.class);
	
	private BizOrderManager bizOrderManager;
	private BizOrderFlowManager bizOrderFlowManager;
	private DataSourceTransactionManager transactionManager;
	
	@Override
	public String submit(final String jdOrderId, final String workType, final String workInfo) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BIZ_ORDER_FLOW_SERVICEIMPL_SUBMIT,false,true);
		BooleanResult result = new BooleanResult();
		
		try{
			if(StringUtils.isBlank(jdOrderId)){
				result.setResult(false);
				result.setSuccess(false);
				result.setResultMessage("jdOrderId不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			if(StringUtils.isBlank(workType)){
				result.setResult(false);
				result.setSuccess(false);
				result.setResultMessage("workType不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			if(StringUtils.isBlank(workInfo)){
				result.setResult(false);
				result.setSuccess(false);
				result.setResultMessage("workInfo不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			long orderId = 0;
			try{
				orderId = Long.parseLong(jdOrderId);
			}catch (Exception e) {
				result.setResult(false);
				result.setSuccess(false);
				result.setResultMessage("jdOrderId格式不正确");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			
			if(bizOrderManager.checkBizOrderExistByClientIdAndOrderId(APIUtils.getClientId(), orderId) <= 0){
				result.setResult(false);
				result.setSuccess(false);
				result.setResultMessage("订单号不存在");
				return APIUtils.parseObject2Json(result);
			}
			
			int type = 0;
			try{
				type = Integer.parseInt(workType);
			}catch (Exception e) {
				result.setResult(false);
				result.setSuccess(false);
				result.setResultMessage("workType格式不正确");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			
			if(type != 1 && type != 2 && type != 3){
				result.setResult(false);
				result.setSuccess(false);
				result.setResultMessage("type数值不正确，只能是1或者2或者3");
				return APIUtils.parseObject2Json(result);
			}
			
			new TransactionTemplate(transactionManager).execute(new TransactionCallbackWithoutResult() {
				@Override
				protected void doInTransactionWithoutResult(TransactionStatus status) {
					BizOrderFlow bizOrderFlow = new BizOrderFlow();
					bizOrderFlow.setClientId(APIUtils.getClientId());
					bizOrderFlow.setCreated(new Date());
					bizOrderFlow.setModified(new Date());
					bizOrderFlow.setOrderId(Long.parseLong(jdOrderId));
					bizOrderFlow.setStatus(11);
					bizOrderFlow.setWorkInfo(workInfo);
					bizOrderFlow.setWorkType(Integer.parseInt(workType));
					//插入到挂起表和挂起流水表中
					bizOrderFlowManager.insertBizOrderFlow(bizOrderFlow);
					bizOrderFlowManager.insertBizOrderFlowDetail(bizOrderFlow);
					//更改订单表的挂起状态
					bizOrderManager.updateHangUpState(APIUtils.getClientId(), Long.parseLong(jdOrderId), 1);
				}
			});
			result.setSuccess(true);
			result.setResult(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"挂起订单异常");
			result.setSuccess(false);
			result.setResult(false);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}
	

	@Override
	public String select(String jdOrderId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BIZ_ORDER_FLOW_SERVICEIMPL_SELECT,false,true);
		MapResult result = new MapResult();
		try{
			if(StringUtils.isBlank(jdOrderId)){
				result.setSuccess(false);
				result.setResultMessage("订单号不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			long orderId = 0;
			try{
				orderId = Long.parseLong(jdOrderId);
			}catch (Exception e) {
				result.setSuccess(false);
				result.setResultMessage("订单号格式不正确");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			
			if(this.bizOrderManager.checkBizOrderExistByClientIdAndOrderId(APIUtils.getClientId(), orderId) <= 0){
				result.setSuccess(false);
				result.setResultMessage("该订单不存在");
				return APIUtils.parseObject2Json(result);
			}
			
			BizOrderFlow bizOrderFlow = this.bizOrderFlowManager.getBizOrderFlowByOrderId(APIUtils.getClientId(), orderId);
			if(bizOrderFlow == null){
				result.setSuccess(false);
				result.setResultMessage("该订单并未被挂起");
				return APIUtils.parseObject2Json(result);
			}
			Map map = new HashMap();
			map.put("jdOrderId", orderId);
			map.put("workType", bizOrderFlow.getWorkType());
			map.put("state", bizOrderFlow.getStatus());
			map.put("workInfo", bizOrderFlow.getWorkInfo());
			result.setResult(map);
			result.setSuccess(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"查询挂起订单异常{}",jdOrderId);
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}		
		return APIUtils.parseObject2Json(result);
	}
	
	@Override
	public String cancel(final String jdOrderId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BIZ_ORDER_FLOW_SERVICEIMPL_CANCEL,false,true);
		
		BooleanResult result = new BooleanResult();
		result.setSuccess(false);
		result.setResult(false);
		try{
			if(StringUtils.isBlank(jdOrderId)){
				result.setResultMessage("订单号不能为空");
				return APIUtils.parseObject2Json(result);
			}
			
			long orderId = 0;
			try{
				orderId = Long.parseLong(jdOrderId);
			}catch (Exception e) {
				result.setResultMessage("订单号格式不正确");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			
			if(this.bizOrderManager.checkBizOrderExistByClientIdAndOrderId(APIUtils.getClientId(), orderId) <= 0){
				result.setResultMessage("该订单不存在");
				return APIUtils.parseObject2Json(result);
			}
			
			final BizOrderFlow bizOrderFlow = bizOrderFlowManager.getBizOrderFlowByOrderId(APIUtils.getClientId(), orderId);
			if(bizOrderFlow == null || bizOrderFlow.getStatus() == 12){ //12代表联通方已经取消挂起
				result.setResultMessage("该订单并未挂起！");
				return APIUtils.parseObject2Json(result);
			}
			
			new TransactionTemplate(transactionManager).execute(new TransactionCallbackWithoutResult() {
				@Override
				protected void doInTransactionWithoutResult(TransactionStatus status) {
					
					BizOrderFlow dbBizOrderFlow = new BizOrderFlow();
					dbBizOrderFlow.setClientId(bizOrderFlow.getClientId());
					dbBizOrderFlow.setCreated(new Date());
					dbBizOrderFlow.setModified(new Date());
					dbBizOrderFlow.setOrderId(bizOrderFlow.getOrderId());
					dbBizOrderFlow.setStatus(12);//12代表联通方取消挂起
					dbBizOrderFlow.setWorkInfo(bizOrderFlow.getWorkInfo());
					dbBizOrderFlow.setWorkType(bizOrderFlow.getWorkType());
					
					if(bizOrderFlowManager.updateBizOrderFlow(dbBizOrderFlow) > 0){//12代表联通方取消挂起
						//插入到挂起表和挂起流水表中
						bizOrderFlowManager.insertBizOrderFlowDetail(dbBizOrderFlow);
						//更改订单表的挂起状态
						bizOrderManager.updateHangUpState(APIUtils.getClientId(), Long.parseLong(jdOrderId), 0);
					}else{
						throw new RuntimeException("联通方取消挂起异常");
					}
				}
			});
			result.setSuccess(true);
			result.setResult(true);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"取消挂起订单异常{}",jdOrderId);
			result.setResultMessage("服务异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}		
		return APIUtils.parseObject2Json(result);
	}
	
	
	public void setBizOrderManager(BizOrderManager bizOrderManager) {
		this.bizOrderManager = bizOrderManager;
	}
	public void setBizOrderFlowManager(BizOrderFlowManager bizOrderFlowManager) {
		this.bizOrderFlowManager = bizOrderFlowManager;
	}

	public void setTransactionManager(
			DataSourceTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

}
