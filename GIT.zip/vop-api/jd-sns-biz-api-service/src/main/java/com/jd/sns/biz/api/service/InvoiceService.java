package com.jd.sns.biz.api.service;

import com.jd.sns.biz.api.domain.AbstractInvoiceInfo;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.BizOrderInvoice;
import com.jd.sns.biz.api.domain.IVatQualification;
import com.jd.sns.biz.api.domain.InvoiceInfo;
import com.jd.sns.biz.api.order.exception.BizOrderServiceException;
import com.jd.sns.biz.ws.invoice.CustomerAddress;

/**
 * 增票接口
 * 
 * @author shilun
 * 
 */
public interface InvoiceService {

	String getInvoiceInfo(String pin);

	/**
	 * 检查票据信息是否成功
	 * @param order
	 * @return
	 */
	IVatQualification orderCheck(BizOrder order,AbstractInvoiceInfo invoiceInfo) throws BizOrderServiceException;

	/***
	 * 根据订单id 获取订单票据
	 * 
	 * @param orderId
	 * @return
	 */
	BizOrderInvoice findByOrderId(Long orderId);
	
	
	/**
	 * 业发票日志
	 * @param invoice
	 */
	void insertInvoice(BizOrderInvoice invoice);

	
	/**
	 * 查询用户增票
	 * @param pin
	 * @return
	 */
	IVatQualification findInvoiceInfo(String pin);

}
