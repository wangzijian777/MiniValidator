package com.jd.sns.biz.api.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.CacheConstant;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizMessage;
import com.jd.sns.biz.api.manager.BizMessageManager;
import com.jd.sns.biz.api.redis.JdCacheUtils;
import com.jd.sns.biz.api.service.BizMessageService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value = "bizMessageService")
public class BizMessageServiceImpl implements BizMessageService {
	// private static final Logger log =
	// LoggerFactory.getLogger(BizMessageServiceImpl.class);
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	private BizMessageManager bizMessageManager;
	private JdCacheUtils redisUtils;

	@Override
	public String getMessage(String type, String del) {
		CallerInfo callerInfo = Profiler.registerInfo(UMPFunctionKeyConstant.GET_MESSAGE, false, true);
		ListResult result = new ListResult();
		List<Integer> types = null;
		try {
			try {
				if (StringUtils.isNotBlank(type)) {
					types = new ArrayList<Integer>();
					String[] typeArr = type.split(",");
					for (int i = 0; i < typeArr.length; i++) {
						types.add(Integer.parseInt(typeArr[i]));
					}
				}
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e, "BizMessageServiceImpl.getMessage type格式不正确-ERROR");
				result.setResultMessage("type格式不正确");
				result.setSuccess(false);
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			try {
				List<BizMessage> list = bizMessageManager.getMessageList(APIUtils.getClientId(), types);
				if (list == null || list.size() == 0) {
					result.setResultMessage("暂无新消息");
					result.setSuccess(false);
					return APIUtils.parseObject2Json(result);
				}
				List resultList = new ArrayList();
				List idsList = new ArrayList();
				for (int i = 0; i < list.size(); i++) {
					BizMessage bizMessage = list.get(i);
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("id", bizMessage.getId());
					map.put("time", sdf.format(bizMessage.getCreated()));
					map.put("type", bizMessage.getType());
					map.put("result", APIUtils.parseJson2Object(bizMessage.getResult(), Map.class));
					resultList.add(map);
					idsList.add(bizMessage.getId());
				}
				result.setSuccess(true);
				result.setResult(resultList);
				if ("1".equals(del)) {
					this.bizMessageManager.delMessages(APIUtils.getClientId(), idsList);
				}
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e, "获取推送消息异常：client_id={}	type={}	del={}", APIUtils.getClientId(), type, del);
				result.setSuccess(false);
				result.setResultMessage("服务异常，请检查参数后重试");
				Profiler.functionError(callerInfo);
			}
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e, "BizMessageServiceImpl.getMessage -ERROR");
			throw new RuntimeException(e);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	@Override
	public String delMessage(String id) {
		CallerInfo callerInfo = Profiler.registerInfo(UMPFunctionKeyConstant.DEL_MESSAGE, false, true);
		BooleanResult result = new BooleanResult();
		try {
			if (StringUtils.isBlank(id)) {
				result.setSuccess(false);
				result.setResult(false);
				result.setResultMessage("id不能为空");
				return APIUtils.parseObject2Json(result);
			}
			String[] arr = id.split(",");
			List<Long> list = new ArrayList<Long>();
			for (int i = 0; i < arr.length; i++) {
				list.add(Long.parseLong(arr[i]));
			}
			redisDelMessage(list);
			this.bizMessageManager.delMessages(APIUtils.getClientId(), list);
			result.setSuccess(true);
			result.setResult(true);
			return APIUtils.parseObject2Json(result);
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "删除推送消息接口异常：id={}", id);
			result.setSuccess(false);
			result.setResult(false);
			result.setResultMessage("服务异常，请检查参数正确后重试");
			Profiler.functionError(callerInfo);
			return APIUtils.parseObject2Json(result);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	/**
	 * yz:删除redis中的数据
	 * @param list
	 */
	public void redisDelMessage(List<Long> list){
		// yz 判断是否存在缓存中，存在缓存则删除，主要应对查库存变化接口
		CallerInfo redisInfo = Profiler.registerInfo(UMPFunctionKeyConstant.REDIS_DEL_MESSAGE, false, true);
		try {
			//联通的才进行删除处理，不是联通的，直接过滤，不做删除
			if(!"XwI1spoB77".equals(APIUtils.getClientId())){
				return ;
			}
			String isDel = redisUtils.get(CacheConstant.CACHE_KEY_BIZMESSAGE_ISDEL);
			//只有当isDel=NO的时候才不会删除，其他默认删除；
			if (!"NO".equals(isDel)) {
				for (Long bizId : list) {
					String idKey = "bizMessage_" + bizId;
					if (redisUtils.exists(idKey)) {
						LogTypeEnum.DEFAULT.error("存在数据进行删除：idKey={}", idKey);
						redisUtils.del(redisUtils.get(idKey));
						redisUtils.del(idKey);
					}
				}
			}
		} catch (Exception e) {
			Profiler.functionError(redisInfo);
			//出错后，也不要影响主流程
			LogTypeEnum.DEFAULT.error(e, "代码执行异常-CodeException,BizMessageServiceImpl.redis 删除数据报错 -ERROR");
		}
		finally {
			Profiler.registerInfoEnd(redisInfo);
		}
	}

	public void setBizMessageManager(BizMessageManager bizMessageManager) {
		this.bizMessageManager = bizMessageManager;
	}

	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

}
