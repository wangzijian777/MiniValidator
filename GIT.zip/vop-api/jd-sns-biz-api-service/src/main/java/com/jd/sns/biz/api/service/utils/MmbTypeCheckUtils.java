package com.jd.sns.biz.api.service.utils;

import java.util.Set;

/**
 * 买卖宝类型客户校验类
 * @author bjtt
 * @date 2015-05-15
 *
 */
public class MmbTypeCheckUtils {

	//vop，需要计算运费的clientId集合
	private Set<String> clientIdSet;
	
	//四级地址对应偏远地区配置
	private Set<Integer> provincesLimit;
	private Set<Integer> citysLimit;
//	private Set<Integer> countrysLimit;
//	private Set<Integer> townsLimit;
	
	/** 免运费起点  59元**/
	private int freightFree;
	/** 基本运费 5元**/
	private int baseFreight;
	/** 偏远运费 10元/件  **/
	private int farAwayFreight;
	
	/**
	 * 根据clientId获取是否需要运费
	 * @param clientId
	 * @return
	 */
	public boolean isNeedFreight(String clientId){
		if(clientIdSet.contains(clientId)){
			return true;
		}
		return false;
	}
	
	/**
	 * 根据四级地址获取是否需要加收偏远地区运费
	 * @param clientId
	 * @return
	 */
	public boolean isNeedFarawayFreight(int provice, int city, int county, int town){
		if(provincesLimit.contains(provice)){
			return true;
		}
		if(citysLimit.contains(city)){
			return true;
		}
		return false;
	}

	public void setClientIdSet(Set<String> clientIdSet) {
		this.clientIdSet = clientIdSet;
	}

	public void setProvincesLimit(Set<Integer> provincesLimit) {
		this.provincesLimit = provincesLimit;
	}

	public void setCitysLimit(Set<Integer> citysLimit) {
		this.citysLimit = citysLimit;
	}

	public int getFreightFree() {
		return freightFree;
	}

	public void setFreightFree(int freightFree) {
		this.freightFree = freightFree;
	}

	public int getBaseFreight() {
		return baseFreight;
	}

	public void setBaseFreight(int baseFreight) {
		this.baseFreight = baseFreight;
	}

	public int getFarAwayFreight() {
		return farAwayFreight;
	}

	public void setFarAwayFreight(int farAwayFreight) {
		this.farAwayFreight = farAwayFreight;
	}
	
}
