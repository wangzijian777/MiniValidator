package com.jd.sns.biz.api.service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import com.jd.sns.biz.api.domain.Sku;

public interface ProductService {
	/**
	 * 获取用户所有商品池信息
	 * @return
	 */
	public String selectPageNumByClientId(String clientId);
	/**
	 * 根据商品池获取所有商品信息
	 * @param pageNum
	 * @return
	 */
	public String selectSkuIdsByClientIdAndPageNum(String clientId, String pageNum);
	
	public String getDetail(String ids);
	
	/**
	 * 批量获取商品上下架状态
	 * @param sku
	 * @return
	 */
	public String skuState(String sku);
	
	/**
	 * 批量获取商品的扩展图片
	 * @param sku
	 * @return
	 */
	public String skuImage(String sku);
	
	/**
	 * 获得商品评价
	 */
	public String getProductCommentSummarys(String sku);
	/**
	 * 获取商品的受限制区域
	 * @param skuIds
	 * @return
	 */
	public Map<Long, List<String>> getProductAreaLimit(Set<Long> skuIds);
	/**
	 * 获取商品名称
	 * @param skuId
	 * @return
	 */
	public String getProductName(Long skuId);
	
	/**
	 * 获取是否加收偏远地区运费扩展属性
	 * @param skus
	 * @return
	 */
	public Map<Long, Map<String, String>> getExtendInfo(List<Sku> skus);
	
	
	/**
	 * 商品、地址是否支持货到付款.
	 * 
	 * @param skuIds 商品sku,用','分割
	 * @param province 1级地址ID
	 * @param city 2级地址ID
	 * @param county 3级地址ID
	 * @param town 4级地址ID
	 * @return 
	 */
	String isSupportHuoDaoFuKuan(String skuIds, String province, String city, String county, String town);
	
	/**
	 * 获取赠品，附件信息
	 * @param skuId
	 * @param province
	 * @param city
	 * @param county
	 * @return
	 */
	public String getSkuGift(Long skuId, Integer province,Integer city,Integer county,Integer town);
	
	
	public String getYanbaoSku(List<Long> skuList);
}
