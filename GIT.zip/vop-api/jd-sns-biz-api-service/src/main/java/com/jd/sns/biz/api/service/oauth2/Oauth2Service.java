package com.jd.sns.biz.api.service.oauth2;

import java.util.Map;

import com.jd.common.web.result.Result;
import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.domain.User;

public interface Oauth2Service {
	/**
	 * 判断打开登录页面的参数是否正确
	 * @param user
	 * @param result
	 * @return
	 */
	public Result checkVisitLoginPageParams(User user, Result result);
	/**
	 * 判断获取token的参数是否正确
	 * @return
	 */
	public Result checkGetTokenParam(User user, Result result);
	
	public Map<String, Object> createAccessToken(User user, String pin) throws Exception;
	
	public AccessToken checkToken(String token);
	
	public AccessToken getAccessTokenByRefreshToken(String refreshToken);
	
	public Map<String, Object> refreshToken(AccessToken at) throws Exception ;
}
