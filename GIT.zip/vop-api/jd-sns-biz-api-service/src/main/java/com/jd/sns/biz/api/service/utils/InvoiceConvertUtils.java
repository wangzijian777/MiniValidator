package com.jd.sns.biz.api.service.utils;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.jd.biz.invoice.apply.domain.InvoiceBatchApi;
import com.jd.biz.invoice.apply.domain.InvoiceDetail;
import com.jd.common.util.Money;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.DateUtils;
import com.jd.sns.biz.api.constant.OrderConstants;
import com.jd.sns.biz.api.domain.BizDoInvoice;
import com.jd.sns.biz.api.domain.BizInvoiceDetail;


public class InvoiceConvertUtils {
	
	/**
	 * 将用户输入转换为调用发票系统需要数据结构
	 * @param bizDoInvoice
	 * @return
	 */
	public static InvoiceBatchApi convertToInvoiceBatchApi(BizDoInvoice bizDoInvoice){
		InvoiceBatchApi invoiceApi = new InvoiceBatchApi();
		String pin = APIUtils.getPin();
		String clientId = APIUtils.getClientId();
		invoiceApi.setEnterprisePin(pin);
		invoiceApi.setClientId(clientId);
		invoiceApi.setEnterpriseTaxpayer(bizDoInvoice.getEnterpriseTaxpayer());
		//结算单
		invoiceApi.setSettlementId(bizDoInvoice.getSettlementId());
		invoiceApi.setSettlementNum(bizDoInvoice.getSettlementNum());
		if(bizDoInvoice.getSettlementNakedPrice() != null){
			invoiceApi.setSettlementNakedPrice(new Money(bizDoInvoice.getSettlementNakedPrice()));
		}
		if(bizDoInvoice.getSettlementTaxPrice() != null){
			invoiceApi.setSettlementTaxPrice(new Money(bizDoInvoice.getSettlementTaxPrice()));
		}
		//当前批次
		invoiceApi.setBatchOrderNum(bizDoInvoice.getInvoiceNum());
		invoiceApi.setBatchNakedPrice(new Money(bizDoInvoice.getInvoiceNakedPrice()));
		invoiceApi.setBatchTaxPrice(new Money(bizDoInvoice.getInvoiceTaxPrice()));
		invoiceApi.setBatchPrice(new Money(bizDoInvoice.getInvoicePrice()));
		invoiceApi.setCurrentBatch(bizDoInvoice.getCurrentBatch());
		//总批次
		invoiceApi.setTotalBatch(bizDoInvoice.getTotalBatch());
		invoiceApi.setTotalBatchNakedAmount(new Money(bizDoInvoice.getTotalBatchInvoiceNakedAmount()));
		invoiceApi.setTotalBatchTaxAmount(new Money(bizDoInvoice.getTotalBatchInvoiceTaxAmount()));
		invoiceApi.setTotalBatchAmount(new Money(bizDoInvoice.getTotalBatchInvoiceAmount()));
		//发票相关信息
	//	invoiceApi.setInvoiceOrgName(bizDoInvoice.getInvoiceOrg()); invoiceOrgName	String	N	开票机构名称
		invoiceApi.setInvoiceOrganId(bizDoInvoice.getInvoiceOrg());
		invoiceApi.setInvoiceType(bizDoInvoice.getInvoiceType());
	//	invoiceApi.setInvoiceFormat(bizDoInvoice.getIN)  invoiceFormat	Integer	Y	开票形式：1预借，2集中（用户没传的话可以根据订单获取）
		invoiceApi.setInvoiceTitle(bizDoInvoice.getTitle());
	//	invoiceApi.setInvoiceRemark(bizDoInvoice.get)  invoiceRemark	String	N	发票备注
		invoiceApi.setInvoiceExpectTime(DateUtils.parse(bizDoInvoice.getInvoiceDate()));
		invoiceApi.setInvoiceContent(bizDoInvoice.getBizInvoiceContent());//invoiceContent	Integer	Y	开票内容 1.明细 2.办公用品 3.电脑配件 4.耗材 5.其他 （需要业务确认）
		
	//	invoiceApi.setDeliveryType(bizDoInvoice.get)  deliveryType	Integer	N	发票配送方式 1.邮寄 2自取（运营确定）
		invoiceApi.setMailAddress(bizDoInvoice.getBillToAddress());
		if(bizDoInvoice.getBillToProvince()!=null && bizDoInvoice.getBillToCity()!=null && bizDoInvoice.getBillToCounty()!=null && bizDoInvoice.getBillToTown()!=null){
			invoiceApi.setMailQlCode(bizDoInvoice.getBillToProvince().toString()+OrderConstants.SPILT_CODE+bizDoInvoice.getBillToCity()+OrderConstants.SPILT_CODE
					+bizDoInvoice.getBillToCounty()+OrderConstants.SPILT_CODE+bizDoInvoice.getBillToTown());
		}
		invoiceApi.setThrApplyNumber(bizDoInvoice.getMarkId()); //第三方申请单号（对应联通申请发票的markId）
		if(StringUtils.isNoneBlank(bizDoInvoice.getRepaymentDate())){
			invoiceApi.setRepayTime(DateUtils.parse(bizDoInvoice.getRepaymentDate()));
		}
		invoiceApi.setBillToParty(bizDoInvoice.getBillToParty());
		invoiceApi.setMailReceiver(bizDoInvoice.getBillToer());
		invoiceApi.setReceiverTel(bizDoInvoice.getBillToContact());
//		invoiceApi.setOp operator	String	N	操作人
		
		invoiceApi.setJdOrderIdList(getOrderList(bizDoInvoice.getSupplierOrder()));
		
		return invoiceApi;
	}
	
	//获取子订单列表
	private static List<Long> getOrderList(String orders){
		List<Long> list = new ArrayList<Long>();
		String[] orderArray = orders.split(OrderConstants.SPILT_CODE_D);
		for(String item: orderArray){
			list.add(Long.parseLong(item));
		}
		return list;
	}
	
	public static List<BizInvoiceDetail> converToBizInvoiceDetailList(List<InvoiceDetail> list){
		List<BizInvoiceDetail> re = new ArrayList<BizInvoiceDetail>();
		for(InvoiceDetail item:list){
			BizInvoiceDetail detail = new BizInvoiceDetail();
			detail.setInvoiceId(item.getInvoiceId());
			detail.setInvoiceCode(item.getInvoiceCode());
			detail.setInvoiceDate(item.getBillingDate());
			detail.setInvoiceNakedAmount(item.getExcludeTaxAmount().getAmount());
			detail.setInvoiceTaxRate(item.getTaxRate());
			detail.setInvoiceTaxAmount(item.getTax().getAmount());
			detail.setInvoiceAmount(item.getTotalAmount().getAmount());
			detail.setInvoiceType(item.getInvoiceType());
			detail.setSuccess(item.getStatus()==1?true:false);
			re.add(detail);
		}
		return re;
	}
}
