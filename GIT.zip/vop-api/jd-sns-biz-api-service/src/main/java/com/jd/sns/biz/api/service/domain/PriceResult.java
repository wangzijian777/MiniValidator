package com.jd.sns.biz.api.service.domain;

import java.util.List;
import java.util.Map;

import com.jd.sns.biz.api.service.domain.ResultBase;

public class PriceResult extends ResultBase{
	private List<Map<String, String>> result;

	public List<Map<String, String>> getResult() {
		return result;
	}

	public void setResult(List<Map<String, String>> result) {
		this.result = result;
	}

}
