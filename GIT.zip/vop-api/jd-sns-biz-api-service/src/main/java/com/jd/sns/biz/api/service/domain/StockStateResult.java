package com.jd.sns.biz.api.service.domain;

import java.util.List;
import java.util.Map;

public class StockStateResult extends ResultBase {
	private List<Map<String, Map<String, Integer>>> result;

	public List<Map<String, Map<String, Integer>>> getResult() {
		return result;
	}

	public void setResult(List<Map<String, Map<String, Integer>>> result) {
		this.result = result;
	}
	
}
