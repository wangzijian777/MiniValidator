package com.jd.sns.biz.api.service.zookeeper;


import java.util.Date;

import com.jd.configs.domain.BaseConfig;
import com.jd.configs.domain.ConfigDomainInitBean;
import com.jd.configs.domain.ConfigOther;
import com.jd.configs.util.JsonUtils;

public class CustemDomain extends BaseConfig implements ConfigDomainInitBean {
	private String quota;
	
	public String getQuota() {
		return quota;
	}

	public void setQuota(String quota) {
		this.quota = quota;
	}

	public static void main(String[] args) {
		final CustemDomain custemDomain = new CustemDomain();
		custemDomain.quota = "10";
		
		final ConfigOther db = new ConfigOther();
		db.setCacheSecond(1000);
		db.setConfigName("yujianming");
		db.setYn(1);
		db.setLastSaveTime(new Date());
		
		custemDomain.setZother(db);

		String configStr = JsonUtils.writeValue(custemDomain, true);
		System.out.println(configStr);
	}
}
