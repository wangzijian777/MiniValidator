package com.jd.sns.biz.api.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jd.common.util.StringUtils;
import com.jd.order.track.site.export.OrderTrackExport;
import com.jd.order.track.site.vo.TrackShowVo;
import com.jd.order.track.site.vo.result.TrackShowResult;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.BizOrderServiceErrorCode;
import com.jd.sns.biz.api.constant.OrderQueryConstant;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.BizOrderInvoice;
import com.jd.sns.biz.api.domain.DemandOrder;
import com.jd.sns.biz.api.domain.Sku;
import com.jd.sns.biz.api.domain.SkuList;
import com.jd.sns.biz.api.entity.service.BizOrderCommonService;
import com.jd.sns.biz.api.manager.BizOrderManager;
import com.jd.sns.biz.api.order.exception.BizOrderServiceException;
import com.jd.sns.biz.api.redis.JdCacheUtils;
import com.jd.sns.biz.api.service.BaseOrderService;
import com.jd.sns.biz.api.service.BizOrderService;
import com.jd.sns.biz.api.service.InvoiceService;
import com.jd.sns.biz.api.service.UserService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.domain.StringResult;
import com.jd.sns.biz.api.service.utils.GiftCheckUtils;
import com.jd.sns.biz.api.service.utils.MmbTypeCheckUtils;
import com.jd.sns.biz.api.service.utils.OrderConvertUtils;
import com.jd.sns.biz.common.enumtype.SourceType;
import com.jd.sns.biz.order.domain.BizOrderQuery;
import com.jd.sns.biz.order.domain.Order;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value = "bizOrderService")
public class BizOrderServiceImpl implements BizOrderService {

	private BizOrderManager bizOrderManager;
	private BaseOrderService baseOrderService;
	private OrderTrackExport orderTrackExport;
	private MmbTypeCheckUtils mmbTypeCheckUtils;
	
	//新下单接口 vxp
	private BizOrderCommonService bizOrderCommonService;

	private InvoiceService invoiceService;
	/** 用户信息service */
	private UserService userService;

	private JdCacheUtils redisUtils;
	
	private GiftCheckUtils giftCheckUtils;

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	// 订单类型 - 父订单
	private static final int ORDER_TYPE_PARENT = 1;

	@Override
	public String cancelJdOrder(String jdOrderId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BIZQBSERVICEIMPL_CANCEL_JD_ORDER,false,true);
		BooleanResult result = new BooleanResult();
		result.setSuccess(false);
		result.setResult(false);
		//TODO  cr yz  保持原流程，只是最后不去取消
		try {
			long orderId = 0;
			try {
				orderId = Long.parseLong(jdOrderId);
			} catch (Exception e) {
				result.setResultMessage("订单编号不正确");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}

			BizOrder bizOrder = bizOrderManager.selectJdOrder(APIUtils.getClientId(), orderId);
			if (bizOrder == null || bizOrder.getOrderState() != 1 || bizOrder.getSubmitState() != 1) {
				result.setResultMessage("jdOrderId不存在");
				return APIUtils.parseObject2Json(result);
			}
			if (bizOrder.getType() == 1) {
				result.setResultMessage("不能取消父订单");
				return APIUtils.parseObject2Json(result);
			}

			String clientId = APIUtils.getClientId();
			BizOrderQuery bizOrderQuery = new BizOrderQuery();
			bizOrderQuery.setJdOrderId(orderId);
			bizOrderQuery.setClientId(clientId);
			bizOrderQuery.setSourceType(SourceType.ORDER_VOP.getType());
			boolean flag = false;
			try {
				flag = bizOrderCommonService.cancelConfirmedOrder(bizOrderQuery);
			} catch (BizOrderServiceException e) {
				LogTypeEnum.SUBMIT_ORDER_LOG.error("此订单不能取消：订单号{},详细信息:{}" ,jdOrderId ,  e.getReturnMessage());
				result.setSuccess(false);
				result.setResult(false);
				result.setResultMessage("此订单不能取消:" + e.getReturnMessage());
				return APIUtils.parseObject2Json(result);
			}
			
			if(flag == true){
				LogTypeEnum.SUBMIT_ORDER_LOG.error("取消订单成功	订单号：{}",jdOrderId);
				result.setSuccess(true);
				result.setResult(true);
				result.setResultMessage("取消订单成功");
			}else{
				LogTypeEnum.SUBMIT_ORDER_LOG.error("取消订单最终失败	订单号：{}",jdOrderId);
				result.setResultMessage("取消订单失败，请重新取消订单");
			}
			
		} catch (Exception e) {
			result.setSuccess(false);
			result.setResult(false);
			result.setResultMessage("服务异常，请稍后重试");
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"订单号：{}" ,jdOrderId);
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	/**
	 * 将子订单转成Map
	 */
	private Map<String, Object> childOrder2Map(Order childOrder, boolean isUseOldGift) {
		if (childOrder == null) {
			return Collections.emptyMap();
		}
		Map<String, Object> childOrderMap = new HashMap<String, Object>();
		if(isUseOldGift){ //切换前
			OrderConvertUtils.dealWithOutGift(childOrder, childOrderMap);
		}else{
			OrderConvertUtils.dealWithGift(childOrder, childOrderMap);
		}
		childOrderMap.put("jdOrderId", childOrder.getJdOrderId());
		childOrderMap.put("orderPrice", childOrder.getOrderPrice());
		childOrderMap.put("type", childOrder.getType());
		// state为配送状态(0-订单初始状态;1-妥投;2-拒收)
		childOrderMap.put("state", childOrder.getState());
		childOrderMap.put("orderState", childOrder.getOrderState());// 0代表取消订单，1代表正常订单
		childOrderMap.put("submitState", childOrder.getSubmitState());// 0代表不实际下单，1代表已经确认下单
		childOrderMap.put("pOrder", childOrder.getParentId());
		if(mmbTypeCheckUtils.isNeedFreight(childOrder.getClientId())){ //如果是买卖宝类型的客户，添加运费的返回
			childOrderMap.put("freight", childOrder.getFreight());
		}
		return childOrderMap;
	}

	/**
	 * 将订单对象转成Map
	 * 
	 * 如果订单@bizOrder是父订单，则一并输入子订单列表
	 */
	private Map<String, Object> bizOrder2Map(Order order, boolean isUseOldGift) throws Exception {
		if (order == null) {
			return Collections.emptyMap();
		}
		Map<String, Object> bizOrderMap = new HashMap<String, Object>();
		// 如果是父订单
		if (order.getType() == ORDER_TYPE_PARENT) {
			// 父订单信息
			Map<String, Object> parentOrder = new HashMap<String, Object>();
			
			if(isUseOldGift){ //切换前
				OrderConvertUtils.dealWithOutGift(order, parentOrder);
			}else{
				OrderConvertUtils.dealWithGift(order, parentOrder);
			}
			parentOrder.put("jdOrderId", order.getJdOrderId());
			parentOrder.put("orderPrice", order.getOrderPrice());
			if(mmbTypeCheckUtils.isNeedFreight(order.getClientId())){ //如果是买卖宝类型的客户，添加运费的返回
				parentOrder.put("freight", order.getFreight());
			}
			// 子订单信息
			List<Map<String, Object>> childOrderMapList = new ArrayList<Map<String, Object>>();
			List<Order> childJdOrderList =order.getChildOrderList();
			if (CollectionUtils.isNotEmpty(childJdOrderList)) {
				for (Order childOrder : childJdOrderList) {
					if("[]".equals(childOrder.getSku())){
						continue;
					}
					//added by bjtt 2014-12-11
					if(childOrder.getPayMoney()==null){ //如果为空，是老数据，设置为orderPrice
						childOrder.setPayMoney(childOrder.getOrderPrice());
					}
					if(childOrder.getPayMoney().compareTo(BigDecimal.ZERO) <= 0 && isUseOldGift){ //价格大于0
						continue;
					}
					Map<String, Object> childOrderMap = childOrder2Map(childOrder,isUseOldGift);
					childOrderMapList.add(childOrderMap);
				}
			}
			// 将父订单、子订单放入到Map中
			bizOrderMap.put("type", order.getType());
			bizOrderMap.put("pOrder", parentOrder);
			bizOrderMap.put("cOrder", childOrderMapList);
			bizOrderMap.put("orderState", order.getOrderState()); // 0代表取消订单，1代表正常订单
			bizOrderMap.put("submitState", order.getSubmitState()); // 0代表不实际下单，1代表已经确认下单
		} else {
			// 如果是子订单，则直接放到Map中
			Map<String, Object> childOrderMap = childOrder2Map(order,isUseOldGift);
			bizOrderMap.putAll(childOrderMap);
		}
		return bizOrderMap;
	}
	
	/**
	 * 获取订单发票信息
	 * @param bizOrder
	 * @return
	 */
	private Map<String, Object> getOrderExtendInfo(BizOrder bizOrder) {
		Map<String, Object> invoiceInfo = new HashMap<String, Object>();
		BizOrderInvoice invoice = invoiceService.findByOrderId(bizOrder.getId());
		if(invoice==null){
			return invoiceInfo;
		}
		// 如果是增值税发票
		if (bizOrder.getInvoiceType() != null && bizOrder.getInvoiceType() == 2) {
			// 发票内容类型
			invoiceInfo.put("invoiceContentType", invoice.getInvoiceContentType());
			// 收票人
			invoiceInfo.put("consigneeName", invoice.getConsigneeName());
			// 联系电话
			invoiceInfo.put("contantPhone", invoice.getPhone());
			// 联系地址
			invoiceInfo.put("contantAddress", invoice.getAddress());
			// 发票单位
			invoiceInfo.put("company", invoice.getVatCompanyName());
			// 税号
			invoiceInfo.put("code", invoice.getCode());
			// 税号注册地址
			invoiceInfo.put("regAddr", invoice.getRegAddr());
			// 税号注册电话
			invoiceInfo.put("regPhone", invoice.getRegPhone());
			// 税号注册银行
			invoiceInfo.put("regBank", invoice.getRegBank());
			// 税号银行账户
			invoiceInfo.put("regBankAccount", invoice.getRegBankAccount());
		} else {
			// 发票抬头
			invoiceInfo.put("invoiceTitleType", invoice.getSeletedInvoiceTitle());
			// 单位
			invoiceInfo.put("companyName", invoice.getCompanyName());
			// 发票内容类型
			invoiceInfo.put("invoiceContentType", invoice.getInvoiceContentType());
		}
		return invoiceInfo;
	}
	@Override
	public String selectJdOrder(String jdOrderId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BIZQBSERVICEIMPL_SELECT_JD_ORDER,false,true);
		MapResult result = new MapResult();

		long orderId = 0;
		try {
			try {
				orderId = Long.parseLong(jdOrderId);
			} catch (Exception e) {
				result.setSuccess(false);
				result.setResultMessage("订单编号不正确");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			try {
				// 根据订单单号查询到订单对象
				BizOrderQuery bizOrderQuery=new BizOrderQuery();
				bizOrderQuery.setSourceType(SourceType.ORDER_VOP.getType());
				bizOrderQuery.setClientId(APIUtils.getClientId());
				bizOrderQuery.setJdOrderId(orderId);
				Set<String> querySet=new HashSet<String>();
				querySet.add(OrderQueryConstant.BASE);
				querySet.add(OrderQueryConstant.CHILD);
				
				Order order = null;
				try {
					order = bizOrderCommonService.getBizOrderDetail(bizOrderQuery, querySet);
				} catch (BizOrderServiceException e) {
					LogTypeEnum.SUBMIT_ORDER_LOG.error("查询订单详情出错:订单号{},详细信息:{}" ,jdOrderId ,  e.getReturnMessage());
					result.setSuccess(false);
					result.setResultMessage("查询订单详情出错:" + e.getReturnMessage());
					return APIUtils.parseObject2Json(result);
				}
				
			//	BizOrder bizOrder = bizOrderManager.selectJdOrder(APIUtils.getClientId(), orderId);
				if (order == null) {
					result.setSuccess(false);
					result.setResultMessage(orderId + "订单不存在");
					return APIUtils.parseObject2Json(result);
				}
				boolean isUseOldGift = giftCheckUtils.isUseOldGift(APIUtils.getClientId()); //true 代表客户还没替换赠品下单接口， false代表已替换赠品下单接口
				// 将订单对象转成Map
				Map<String, Object> bizOrderMap = bizOrder2Map(order,isUseOldGift);
				result.setSuccess(true);
				result.setResult(bizOrderMap);
			}catch (Exception e) {
				LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"订单号：{}" , jdOrderId);
				result.setSuccess(false);
				result.setResultMessage("服务异常，请稍后重试！");
				Profiler.functionError(callerInfo);
			}
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"BizOrderServiceImpl.selectJdOrder -ERROR");
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	private MapResult checkSubimeParam(BizOrder bizOrder, MapResult result) {
		result.setSuccess(false);
		if (bizOrder.getJdDemandOrder() == 0) {
			result.setResultMessage("jdDemandOrder不存在");
			return result;
		}
		if (StringUtils.isBlank(bizOrder.getThirdOrder())) {
			result.setResultMessage("thirdOrder不能为空");
			return result;
		}

		if (bizOrder.getThirdOrder().length() > 100) {
			result.setResultMessage("thirdOrder长多过长，必须在100以内");
			return result;
		}

		if (StringUtils.isBlank(bizOrder.getSku())) {
			result.setResultMessage("sku不能为空");
			return result;
		}
		if (StringUtils.isBlank(bizOrder.getName())) {
			result.setResultMessage("name不能为空");
			return result;
		}

		if (bizOrder.getName().length() > 20) {
			result.setResultMessage("name字数过长");
			return result;
		}

		if (bizOrder.getProvince() == 0 || bizOrder.getCity() == 0 || bizOrder.getCounty() == 0) {
			result.setResultMessage("地址信息不正确");
			return result;
		}
		if (StringUtils.isBlank(bizOrder.getAddress())) {
			result.setResultMessage("address不能为空");
			return result;
		}

		if (bizOrder.getAddress().length() >= 100) {
			result.setResultMessage("address长度超常，必须在100以内");
			return result;
		}

		if (StringUtils.isBlank(bizOrder.getZip())) {
			result.setResultMessage("zip不能为空");
			return result;
		}

		if (bizOrder.getZip().length() > 20) {
			result.setResultMessage("zip长度异常");
			return result;
		}

		if (StringUtils.isBlank(bizOrder.getPhone()) && StringUtils.isBlank(bizOrder.getMobile())) {
			result.setResultMessage("请填写收货人电话或手机号码");
			return result;
		}
		if (StringUtils.isBlank(bizOrder.getEmail())) {
			result.setResultMessage("邮箱不能为空");
			return result;
		}
		result = baseOrderService.checkSkuListExist(bizOrder.getSku(), result);
		if (!result.isSuccess()) {
			return result;
		}
		result.setSuccess(true);
		return result;
	}

	@Override
	public String orderTrack(String jdOrderId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.BIZQBSERVICEIMPL_ORDER_TRACK,false,true);
		MapResult result = new MapResult();
		long id = 0l;
		try {
			try {
				id = Long.parseLong(jdOrderId);
			} catch (Exception e) {
				LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"jdOrdedrId={}" , jdOrderId);
				result.setSuccess(false);
				result.setResultMessage("jdOrderId不能为空，且为纯数字");
				Profiler.functionError(callerInfo);
				return APIUtils.parseObject2Json(result);
			}
			try {
				if (bizOrderManager.checkBizOrderExistByClientIdAndOrderId(APIUtils.getClientId(), id) <= 0) {
					result.setSuccess(false);
					result.setResultMessage("该订单没有配送信息");
					return APIUtils.parseObject2Json(result);
				}
				TrackShowResult trackResult = this.orderTrackExport.getTrackShowResult(id, APIUtils.getPin());
				if (trackResult == null) {
					result.setSuccess(true);
					result.setResultMessage("未找到改订单配送信息");
					return APIUtils.parseObject2Json(result);
				}
				List<TrackShowVo> ziying = trackResult.getZiyingShowResult();
				List<TrackShowVo> third = trackResult.getThirdPsShowResult();
				List orderTrack = new ArrayList();
				if (ziying != null) {
					for (int i = 0; i < ziying.size(); i++) {
						TrackShowVo track = ziying.get(i);
						Map<String, Object> map = new HashMap<String, Object>();
						map.put("msgTime", sdf.format(track.getMsgTime()));
						map.put("content", track.getContent());
						map.put("operator", track.getOperator());
						orderTrack.add(map);
					}
				}
				if (third != null) {
					for (int i = 0; i < third.size(); i++) {
						TrackShowVo track = third.get(i);
						if (track == null || track.getMsgTime() == null) {
							continue;
						}
						Map<String, Object> map = new HashMap<String, Object>();
						map.put("msgTime", sdf.format(track.getMsgTime()));
						map.put("content", track.getContent());
						map.put("operator", track.getOperator());
						orderTrack.add(map);
					}
				}
				if (orderTrack.size() == 0) {
					result.setSuccess(false);
					result.setResultMessage("该订单暂无配送信息");
					return APIUtils.parseObject2Json(result);
				}
				Map<String, Object> resultMap = new HashMap<String, Object>();
				resultMap.put("jdOrderId", id);
				resultMap.put("orderTrack", orderTrack);
				result.setResult(resultMap);
				result.setSuccess(true);
			} catch (Exception e) {
				LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"订单号：{}" , jdOrderId);
				result.setSuccess(false);
				result.setResultMessage("服务异常，请稍后重试!");
				Profiler.functionError(callerInfo);
			}
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"BizOrderServiceImpl.orderTrack -ERROR");
			throw new RuntimeException(e);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	@Override
	public String selectJdOrderListByThirdOrder(String thirdOrder) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.SELECT_JD_ORDER_LIST_BY_THIRD_ORDER,false,true);
		ListResult result = new ListResult();
		if (StringUtils.isBlank(thirdOrder)) {
			result.setSuccess(false);
			result.setResultMessage("订单单号不能为空");
			return APIUtils.parseObject2Json(result);
		}
		try {
			// 根据第三方订单单号查询订单列表
			BizOrderQuery bizOrderQuery=new BizOrderQuery();
			bizOrderQuery.setSourceType(SourceType.ORDER_VOP.getType());
			bizOrderQuery.setClientId(APIUtils.getClientId());
			bizOrderQuery.setThirdOrderId(thirdOrder);
			Set<String> querySet=new HashSet<String>();
			querySet.add(OrderQueryConstant.BASE);
			List<Order> orderList = new ArrayList<Order>(); 
			try {
				orderList =  bizOrderCommonService.selectJdOrderListByThirdOrder(bizOrderQuery, querySet);
			} catch (BizOrderServiceException e) {
				LogTypeEnum.SUBMIT_ORDER_LOG.error("根据第三方订单号查询订单列表错误thirdOrder：{},详细信息:{}" ,thirdOrder ,  e.getReturnMessage());
				result.setSuccess(false);
				result.setResultMessage("查询订单出错:" + e.getReturnMessage());
				return APIUtils.parseObject2Json(result);
			}
			boolean isUseOldGift = giftCheckUtils.isUseOldGift(APIUtils.getClientId()); //true 代表客户还没替换赠品下单接口， false代表已替换赠品下单接口
			if (CollectionUtils.isNotEmpty(orderList)) {
				List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
				for (Order order : orderList) {
					// 这里查询出的都是子订单，所以在转换成Map时把bizOrder按照子订单方式处理
					mapList.add(childOrder2Map(order,isUseOldGift));
				}
				result.setSuccess(true);
				result.setResult(mapList);
			} else {
				result.setSuccess(false);
				result.setResultMessage(thirdOrder + "订单不存在");
			}
		}catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"-----------------BizOrderServiceImpl.selectJdOrderByThirdOrder------------thirdOrder={}" , thirdOrder);
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试！");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}

	@Override
	public String selectBizOrderByThirdOrder(String thirdOrder) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.SELECT_BIZ_ORDER_BY_THIRD_ORDER,false,true);
		StringResult result = new StringResult();
		if (StringUtils.isBlank(thirdOrder)) {
			result.setSuccess(false);
			result.setResultMessage("thirdOrder不能为空");
			return APIUtils.parseObject2Json(result);
		}
		try {
			BizOrder bizOrder = bizOrderManager.selectParentJdOrderByThirdOrder(APIUtils.getClientId(), thirdOrder);
			if (bizOrder == null) {
				result.setSuccess(false);
				result.setResultMessage(thirdOrder + "订单不存在");
				return APIUtils.parseObject2Json(result);
			}
			result.setSuccess(true);
			result.setResult(bizOrder.getJdOrderId() + "");		
		} catch (Exception e) {
			LogTypeEnum.SUBMIT_ORDER_LOG.error(e,"bizOrderManager.selectParentJdOrderByThirdOrder 根据第三方订单号，获取父订单信息-ERROR");
			result.setSuccess(false);
			result.setResultMessage("网络异常，请稍后重试");
			Profiler.functionError(callerInfo);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}
	
	public String doPay(long jdOrderId) {
		CallerInfo callerInfo = Profiler.registerInfo(UMPFunctionKeyConstant.SELECT_BIZ_ORDER_DO_PAY, false, true);
		String clientId = APIUtils.getClientId();
		BooleanResult result = new BooleanResult();
		result.setSuccess(false);
		result.setResult(false);
		try {
			BizOrderQuery bizOrderQuery = new BizOrderQuery();
			bizOrderQuery.setJdOrderId(jdOrderId);
			bizOrderQuery.setClientId(clientId);
			bizOrderQuery.setSourceType(SourceType.ORDER_VOP.getType());
			boolean isSuccess = bizOrderCommonService.payAfterOrdering(bizOrderQuery);
			result.setSuccess(isSuccess);
			result.setResult(isSuccess);	
		} catch (BizOrderServiceException e){
			LogTypeEnum.DEFAULT.error(e,"发起支付失败[jdOrderId = {}, pin = {}]", jdOrderId, clientId);
			
			result.setSuccess(true);
			result.setResultCode(StringUtils.isNotEmpty(e.getReturnCode()) ? e.getReturnCode() : BizOrderServiceErrorCode.CODE_EXCEPTION);
			result.setResultMessage(e.getReturnMessage());
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"CodeException-发起支付失败[jdOrderId = {}, pin = {}]", jdOrderId, clientId);
			
			result.setResultCode(BizOrderServiceErrorCode.CODE_EXCEPTION);
			result.setResultMessage("网络异常，请稍后重试");
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		return APIUtils.parseObject2Json(result);
	}
	public void setBizOrderManager(BizOrderManager bizOrderManager) {
		this.bizOrderManager = bizOrderManager;
	}

	public void setBaseOrderService(BaseOrderService baseOrderService) {
		this.baseOrderService = baseOrderService;
	}

	public void setOrderTrackExport(OrderTrackExport orderTrackExport) {
		this.orderTrackExport = orderTrackExport;
	}
	
	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setBizOrderCommonService(BizOrderCommonService bizOrderCommonService) {
		this.bizOrderCommonService = bizOrderCommonService;
	}

	public void setMmbTypeCheckUtils(MmbTypeCheckUtils mmbTypeCheckUtils) {
		this.mmbTypeCheckUtils = mmbTypeCheckUtils;
	}

	public void setGiftCheckUtils(GiftCheckUtils giftCheckUtils) {
		this.giftCheckUtils = giftCheckUtils;
	}

}
