package com.jd.sns.biz.api.service.utils;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.constant.CacheConstant;
import com.jd.sns.biz.api.redis.JdCacheUtils;

/**
 * invoiceState校验
 * @author bjtt
 * @date 2014-11-10
 *
 */

@Service(value="invoiceStateUtils")
public class InvoiceStateUtils {
	private JdCacheUtils redisUtils;

	/**
	 * 使用老 InvocieState 验证流程
	 * value存的:  clientId1,clientId2,clientId3
	 */
	public boolean isUseOldInvocieState(String clientId) throws Exception{
		String value = "," + redisUtils.get(CacheConstant.CACHE_KEY_INVOICE_USE_OLD) + ",";
		String query = "," + clientId + ",";
		if(value.contains(query)){
			return true;
		}
		return false;
	}

	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

		
	
}
