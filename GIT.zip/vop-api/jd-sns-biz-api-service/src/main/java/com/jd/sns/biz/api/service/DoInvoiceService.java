package com.jd.sns.biz.api.service;

import com.jd.sns.biz.api.domain.BizDoInvoice;


/**
 * 发票相关接口service
 * 
 * @author bjtt
 * 
 */
public interface DoInvoiceService {

	/**
	 * 申请开票
	 * @return
	 */
	public String submitInvoice(BizDoInvoice bizDoInvoice);

	/**
	 * 申请发票信息
	 * @return
	 */
	public String selectInvoice(String markId);

	/**
	 * 取消开票
	 * @return
	 */
	public String cancel(String markId);
	
}
