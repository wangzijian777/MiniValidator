package com.jd.sns.biz.api.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.sns.biz.api.dao.BizOrderInvoiceDao;
import com.jd.sns.biz.api.domain.BizOrderInvoice;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config.xml")
public class InvoiceServiceTest {

	@Autowired
	BizOrderInvoiceDao invoiceService;
	@Test
	public void testInsertInvoice() {
		BizOrderInvoice orderInvoice = new BizOrderInvoice();
		//设置订单id
		orderInvoice.setOrderId((long) 10000);
		//订单发票类型
		orderInvoice.setInvoiceType(2);
		//订单公司名称
		orderInvoice.setCompanyName("lujlkj");
		orderInvoice.setPhone("13541370905");
		orderInvoice.setProvinceId(5);
		orderInvoice.setCityId(5);
		orderInvoice.setCountyId(5);
		orderInvoice.setTownId(5);
		orderInvoice.setAddress("rtdyhfdh");
		orderInvoice.setPin("lunshi");
	
		orderInvoice.setSeletedInvoiceTitle(5);
		//订单发票内容类型
		orderInvoice.setInvoiceContentType(1);
	
			//公司名称
			orderInvoice.setVatCompanyName("fdaa");
			// 纳税人标识号
			orderInvoice.setCode("hfdsgfd");
			//注册地址			
			orderInvoice.setRegAddr("retertre");
			//注册电话
			orderInvoice.setRegPhone("gfedgdf");
			//订单id
	
			//注册银行
			orderInvoice.setRegBank("back");
			//注册银行
			orderInvoice.setRegBankAccount("account");
			
			//用户地址		
			orderInvoice.setConsigneeName("name");			
		
		invoiceService.insertInvoice(orderInvoice);
	}

	@Test
	public void testGetInvoice(){
		BizOrderInvoice findByOrderId = invoiceService.findByOrderId((long) 10000);
		System.out.println(findByOrderId);
	}
}
