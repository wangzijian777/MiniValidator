package com.jd.sns.biz.api.manager;

import java.math.BigDecimal;
import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;




import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.InvoiceInfo;
import com.jd.sns.biz.ws.invoice.VatQualification;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-config.xml")
public class BizOrderManagerTest {

	@Autowired
	private BizOrderManager bizOrderManager;
	@Test
	public void testSubmitOrderBizOrderAbstractInvoiceInfoIVatQualification() {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setAddress("address");
		bizOrder.setCity(5);
		bizOrder.setOrderPrice(new BigDecimal(1));
		bizOrder.setThirdOrder("x_888");
		bizOrder.setSku("888_sku");
		bizOrder.setClientId("fdas");
		bizOrder.setPin("lunshi");
		bizOrder.setCompanyName("fdas");
		bizOrder.setCounty(5);
		bizOrder.setName("ddd");
		bizOrder.setZip("61254");
		bizOrder.setEmail("tt@tt.com");
		InvoiceInfo info = new InvoiceInfo();
		info.setInvoiceAddress("chengdu");
		info.setInvoiceCity(5);;
		info.setInvoiceCounty(8);
		info.setInvoiceName("shilun");
		info.setInvoicePhone("13541370905");
	
		
		
		VatQualification vatQualification = new VatQualification();
		vatQualification.setAccount("a");
		vatQualification.setAddress("abnc");
		
		bizOrderManager.submitOrder(bizOrder, info, vatQualification);
		System.out.println(bizOrder.getId());
		
	}
	
	
	public static void main(String args []){
		new ArrayList().addAll(null);
	}

}
