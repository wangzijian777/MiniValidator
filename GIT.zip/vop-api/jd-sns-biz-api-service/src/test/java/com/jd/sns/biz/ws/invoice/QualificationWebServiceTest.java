package com.jd.sns.biz.ws.invoice;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.sns.biz.api.domain.IVatQualification;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/spring-config-ws-invoice.xml")
public class QualificationWebServiceTest {

	@Autowired
	QualificationWebService qualificationWebService;
	@Test
	public void testFindCustomerAddress() {
		List<CustomerAddress> findCustomerAddress = qualificationWebService.findCustomerAddress("3833634");
		for(CustomerAddress address:findCustomerAddress){
			System.out.println(address.getAddress());
		}
	}

	@Test
	public void testFindMemberByOutLink() {
		List<VatQualification> findQualificationByMemberName = qualificationWebService.findQualificationByMemberName("3833634");
		for(IVatQualification address:findQualificationByMemberName){
			System.out.println(address);
		}
	}

}
