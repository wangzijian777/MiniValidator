package wsdlCodeGen;


public class QualificationWebService {

	public static void main(String[] args) {
//		String[] arge=new String[] {
//		           "-impl",
//		           "-client",
//		           "-d","src/main/java",
//		           "-p","com.jd.sns.biz.ws.invoice" ,
//		           "qualificationWebService.xml"};
//		WSDLToJava.main(arge);
	}

}
