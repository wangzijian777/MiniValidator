package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;

/**
 * 下单时所需的促销json串对应的实体类
 * 
 * @author chenxiaoming
 */
public class PromotionSkuTypes {
    
    private String id;
    
    private int pty;
    
    private BigDecimal pdc;
    
    private int ptg;
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public int getPty() {
        return pty;
    }
    
    public void setPty(int pty) {
        this.pty = pty;
    }
    
    public BigDecimal getPdc() {
        return pdc;
    }
    
    public void setPdc(BigDecimal pdc) {
        this.pdc = pdc;
    }
    
    public int getPtg() {
        return ptg;
    }
    
    public void setPtg(int ptg) {
        this.ptg = ptg;
    }
    
}
