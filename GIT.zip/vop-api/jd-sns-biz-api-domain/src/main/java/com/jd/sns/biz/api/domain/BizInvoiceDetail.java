package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;
import java.util.Date;

public class BizInvoiceDetail {
//	invoiceId	发票号码
	private String invoiceId;
//	invoiceCode	发票代码
	private String invoiceCode;
//	invoiceDate	发票日期
	private Date invoiceDate;
//	invoiceNakedAmount	发票金额（裸价）
	private BigDecimal invoiceNakedAmount;
//	invoiceTaxRate	发票税率
	private BigDecimal invoiceTaxRate;
//	invoiceTaxAmount	发票税额
	private BigDecimal invoiceTaxAmount;
//	invoiceAmount	价税合计
	private BigDecimal invoiceAmount;
//	invoiceType	  发票类型
	private Integer invoiceType;
//	Success	是否
	private Boolean Success;
	
	public String getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	public String getInvoiceCode() {
		return invoiceCode;
	}
	public void setInvoiceCode(String invoiceCode) {
		this.invoiceCode = invoiceCode;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public BigDecimal getInvoiceNakedAmount() {
		return invoiceNakedAmount;
	}
	public void setInvoiceNakedAmount(BigDecimal invoiceNakedAmount) {
		this.invoiceNakedAmount = invoiceNakedAmount;
	}
	public BigDecimal getInvoiceTaxRate() {
		return invoiceTaxRate;
	}
	public void setInvoiceTaxRate(BigDecimal invoiceTaxRate) {
		this.invoiceTaxRate = invoiceTaxRate;
	}
	public BigDecimal getInvoiceTaxAmount() {
		return invoiceTaxAmount;
	}
	public void setInvoiceTaxAmount(BigDecimal invoiceTaxAmount) {
		this.invoiceTaxAmount = invoiceTaxAmount;
	}
	public BigDecimal getInvoiceAmount() {
		return invoiceAmount;
	}
	public void setInvoiceAmount(BigDecimal invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	public Integer getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}
	public Boolean getSuccess() {
		return Success;
	}
	public void setSuccess(Boolean success) {
		Success = success;
	}
	
}
