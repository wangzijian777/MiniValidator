package com.jd.sns.biz.api.constant;


public class OrderConstants {

	
	/** 拆单状态 - 原始订单 **/
	public static final int UNSPLIT = 0;
	/** 拆单状态 - 拆单后为父订单 **/
	public static final int SPLITED_PARENT = 1;
	/** 拆单状态 - 拆单后为子订单 **/
	public static final int SPLITED_CHILD = 2;
	/** 拆单状态 - 二次拆单 **/
	public static final int SPLITED_SECOND = 3;
	
	/** 定时任务状态  - 未处理 **/
	public static final int WAIT_PROCESS = 0;
	/** 定时任务状态  - 已处理 **/
	public static final int PROCESSED = 1;
	

	
	/**
	 * 订单组订单状态说明页面：
	 * 	http://cf.360buy-develop.com/pages/viewpage.action?pageId=2722914
	 */
	/** 订单状态 - 新订单 **/
	public static final int ORDERSTATE_NEW = 1;
	/** 订单状态 - 等待付款 **/
	public static final int ORDERSTATE_WAITED_PAY = 2;
	/** 订单状态 - 暂停 **/
	public static final int ORDERSTATE_PAUSE = 5;
	/** 订单状态 - 等待出库 **/
	public static final int ORDERSTATE_OUTSTOCK = 8;
	/** 订单状态 - 确认收货 **/
	public static final int ORDERSTATE_RECEIVED = 16;
	/** 订单状态 - 完成 **/
	public static final int ORDERSTATE_FINISH = 19;
	

	
	/** 订单状态 - 有效(订单生产) **/
	public static final int ORDER_AVAILABLE = 1;
	/** 订单状态 - 无效(订单已被取消) **/
	public static final int ORDER_UNAVAILABLE = 0;
	
	public static final String SPILT_CODE = "|";
	public static final String SPILT_CODE_D = ",";
	
	/** Q币商品三级分类 **/
	public static final int QB_CATEGORY = 4709;
	
	public static final String INVOICE_DATA_KEY = "invoiceDetailList";
	
	/** 偏远运费查询 查询key PianYuanYunFei**/
	public static final String FARAWAY_QUERY = "PianYuanYunFei";
	public static final String EXTEND_ELEGIFT = "EleGift";
	
	public static final String PAY_FLAG_GIFT = "flag_giftcard";

}
