package com.jd.sns.biz.api.constant;


public class CheckOrderConstants {

	/** 对账订单状态 - 新订单 **/
	public static final int ORDER_CHECK_NEW = 1;
	/** 对账订单状态 - 妥投**/
	public static final int ORDER_CHECK_DLOK = 2;
	/** 对账订单状态 - 拒收 **/
	public static final int ORDER_CHECK_REFUSE = 3;
	
}
