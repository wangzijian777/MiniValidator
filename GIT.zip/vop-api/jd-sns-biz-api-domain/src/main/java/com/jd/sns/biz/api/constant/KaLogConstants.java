package com.jd.sns.biz.api.constant;


public class KaLogConstants {

	/** 大客户日志系统  KA_LOG_KEY **/
	public static final String KA_LOG_KEY = "vop.order";
	
	/** 大客户日志系统 调用者 **/
	public static final String KA_LOG_CALLER = "用户";
	
	/** 大客户日志系统 业务名称 **/
	public static final String KA_LOG_BUSSINESS_ORDER_START = "下单开始";
	public static final String KA_LOG_BUSSINESS_ORDER_END = "下单结束";
	public static final String KA_LOG_BUSSINESS_CONFIRM_START = "确认下单开始";
	public static final String KA_LOG_BUSSINESS_CONFIRM_END = "确认下单结束";
	public static final String KA_LOG_BUSSINESS_CANCEL_UNCONFRIM_START = "取消未确认订单开始";
	public static final String KA_LOG_BUSSINESS_CANCEL_UNCONFRIM_END = "取消未确认订单结束";
	public static final String KA_LOG_BUSSINESS_CANCEL_CONFRIMED_START = "取消已确认订单开始";
	public static final String KA_LOG_BUSSINESS_CANCEL_CONFRIMED_END = "取消已确认订单结束";
	
}
