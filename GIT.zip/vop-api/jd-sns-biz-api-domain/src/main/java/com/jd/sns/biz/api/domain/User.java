package com.jd.sns.biz.api.domain;

import java.util.Date;

public class User extends Oauth2BaseDomain{
	private int id;
	//用户网站中文名称
	private String name;
	//用户网站域名
	private String domain;
	//用户网站应用访问类型
	private String response_type;
	//用户网站回调地址
	private String redirect_uri;
	//appid
	private String client_id;
	//appkey
	private String client_secret;
	//用户网站申请权限
	private String scope;
	//用户网站头像
	private String img;
	//创建时间
	private Date created;
	//修改时间
	private Date updated;
	//原样返回给用户
	private String state;
	//grant_type固定为authorization_code和access_token
	private String grant_type;
	
	/** 金融支付权限*/
	private Integer credit_pay;
	/** 金融支付费率*/
	private Integer credit_fee;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getResponse_type() {
		return response_type;
	}
	public void setResponse_type(String response_type) {
		this.response_type = response_type;
	}
	public String getRedirect_uri() {
		return redirect_uri;
	}
	public void setRedirect_uri(String redirect_uri) {
		this.redirect_uri = redirect_uri;
	}
	public String getClient_id() {
		return client_id;
	}
	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}
	public String getClient_secret() {
		return client_secret;
	}
	public void setClient_secret(String client_secret) {
		this.client_secret = client_secret;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getGrant_type() {
		return grant_type;
	}
	public void setGrant_type(String grant_type) {
		this.grant_type = grant_type;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getCredit_pay() {
		return credit_pay;
	}
	public void setCredit_pay(Integer creditPay) {
		credit_pay = creditPay;
	}
	public Integer getCredit_fee() {
		return credit_fee;
	}
	public void setCredit_fee(Integer creditFee) {
		credit_fee = creditFee;
	}
	
	
	
}
