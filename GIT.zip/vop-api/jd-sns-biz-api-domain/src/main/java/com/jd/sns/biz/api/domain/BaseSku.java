package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;

public class BaseSku {
	private long skuId;
	private int num;
	private int category;
	private BigDecimal price;
	private String name;
    private BigDecimal tax;
    private BigDecimal taxPrice;
    private BigDecimal nakedPrice;
    
	public long getSkuId() {
		return skuId;
	}
	public void setSkuId(long skuId) {
		this.skuId = skuId;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getCategory() {
		return category;
	}
	public void setCategory(int category) {
		this.category = category;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setId(long id){
		this.skuId = id;
	}
    public BigDecimal getNakedPrice() {
        return nakedPrice;
    }
    public void setNakedPrice(BigDecimal nakedPrice) {
        this.nakedPrice = nakedPrice;
    }
    public BigDecimal getTaxPrice() {
        return taxPrice;
    }
    public void setTaxPrice(BigDecimal taxPrice) {
        this.taxPrice = taxPrice;
    }
    public BigDecimal getTax() {
        return tax;
    }
    public void setTax(BigDecimal tax) {
        this.tax = tax;
    }

}
