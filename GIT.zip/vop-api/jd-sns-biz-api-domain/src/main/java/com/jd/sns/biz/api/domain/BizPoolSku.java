package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;
import java.util.Date;

public class BizPoolSku {
	private long id;
	private String clientId;
	private int poolId;
	private String poolName;
	private long skuId;
	private String skuName;
	private Date created;
	private Date modified;
	private BigDecimal price;
	private String ext_1;
	private String ext_2;
	private String ext_3;
	private String ext_4;
	private int yn;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public int getPoolId() {
		return poolId;
	}
	public void setPoolId(int poolId) {
		this.poolId = poolId;
	}
	public String getPoolName() {
		return poolName;
	}
	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}
	public long getSkuId() {
		return skuId;
	}
	public void setSkuId(long skuId) {
		this.skuId = skuId;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getModified() {
		return modified;
	}
	public void setModified(Date modified) {
		this.modified = modified;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public String getExt_1() {
		return ext_1;
	}
	public void setExt_1(String ext_1) {
		this.ext_1 = ext_1;
	}
	public String getExt_2() {
		return ext_2;
	}
	public void setExt_2(String ext_2) {
		this.ext_2 = ext_2;
	}
	public String getExt_3() {
		return ext_3;
	}
	public void setExt_3(String ext_3) {
		this.ext_3 = ext_3;
	}
	public String getExt_4() {
		return ext_4;
	}
	public void setExt_4(String ext_4) {
		this.ext_4 = ext_4;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	
}
