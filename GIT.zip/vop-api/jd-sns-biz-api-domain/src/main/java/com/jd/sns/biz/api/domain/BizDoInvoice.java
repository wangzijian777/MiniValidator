package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;

public class BizDoInvoice {
	//	史泰博发票请求子订单号，批量以，分割
	private String supplierOrder;
	//	 必须	联通申请发票的唯一id标识 (该标记下可以对应多张发票信息)
	private String markId;
	//	必须	结算单号
	private String settlementId;
	//	非必须	结算单子订单总数
	private Integer settlementNum;
	//	非必须	结算单不含税总金额
	private BigDecimal settlementNakedPrice;
	//	非必须	结算单总税额
	private BigDecimal settlementTaxPrice;
	//	  必须	发票类型   1普通 2增值税
	private Integer invoiceType;
	//	  必须	开票机构544(代确认)
	private Integer invoiceOrg;
	//	必须	开票内容：    明细  办公用品  电脑配件  耗材（需要业务部门确认）  
	private Integer bizInvoiceContent;
	//	必须	期望开票时间  2013-11-08
	private String invoiceDate;
	//	必须	发票抬头（参考使用）
	private String title;
	//	非必须	收票单位 （联通填写开票省份）
	private String billToParty;
	//	非必须	纳税人识别号（增票必须）
	private String enterpriseTaxpayer;
	//	非必须	收票人 （无
	private String billToer;
	//	非必须	收票人联系方式 （无）
	private String billToContact;
	//	非必须	收票人地址（省）  （无）
	private Integer billToProvince;
	//	非必须	收票人地址（市）  （无）
	private Integer billToCity;
	//	非必须	收票人地址（区）  （无）
	private Integer billToCounty;
	//	非必须	收票人地址（街道）（无）
	private Integer billToTown;
	//	非必须	收票人地址（详细地址）（无）
	private String billToAddress;
	//	非必须	预计还款时间2013-11-08
	private String repaymentDate;
	//	必须	当前批次子订单总数
	private Integer invoiceNum;
	//	必须	当前批次不含税总金额
	private BigDecimal invoiceNakedPrice;
	//	必须	当前批次总税额(参考用)
	private BigDecimal invoiceTaxPrice;
	//	必须	当前批次含税总金额
	private BigDecimal invoicePrice;
	//	必须	当前批次
	private Integer currentBatch;
	//	必须	总批次
	private Integer totalBatch;
	//	必须	总批次开发票金额（不含税）
	private BigDecimal totalBatchInvoiceNakedAmount;
	//	必须	总批次开发票税额
	private BigDecimal totalBatchInvoiceTaxAmount;
	//	必须	总批次开发票价税合计
	private BigDecimal totalBatchInvoiceAmount;
	
	public String getSupplierOrder() {
		return supplierOrder;
	}
	public void setSupplierOrder(String supplierOrder) {
		this.supplierOrder = supplierOrder;
	}
	public String getMarkId() {
		return markId;
	}
	public void setMarkId(String markId) {
		this.markId = markId;
	}
	public String getSettlementId() {
		return settlementId;
	}
	public void setSettlementId(String settlementId) {
		this.settlementId = settlementId;
	}
	public Integer getSettlementNum() {
		return settlementNum;
	}
	public void setSettlementNum(Integer settlementNum) {
		this.settlementNum = settlementNum;
	}
	public BigDecimal getSettlementNakedPrice() {
		return settlementNakedPrice;
	}
	public void setSettlementNakedPrice(BigDecimal settlementNakedPrice) {
		this.settlementNakedPrice = settlementNakedPrice;
	}
	public BigDecimal getSettlementTaxPrice() {
		return settlementTaxPrice;
	}
	public void setSettlementTaxPrice(BigDecimal settlementTaxPrice) {
		this.settlementTaxPrice = settlementTaxPrice;
	}
	public Integer getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}
	public Integer getInvoiceOrg() {
		return invoiceOrg;
	}
	public void setInvoiceOrg(Integer invoiceOrg) {
		this.invoiceOrg = invoiceOrg;
	}
	public Integer getBizInvoiceContent() {
		return bizInvoiceContent;
	}
	public void setBizInvoiceContent(Integer bizInvoiceContent) {
		this.bizInvoiceContent = bizInvoiceContent;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBillToParty() {
		return billToParty;
	}
	public void setBillToParty(String billToParty) {
		this.billToParty = billToParty;
	}
	public String getEnterpriseTaxpayer() {
		return enterpriseTaxpayer;
	}
	public void setEnterpriseTaxpayer(String enterpriseTaxpayer) {
		this.enterpriseTaxpayer = enterpriseTaxpayer;
	}
	public String getBillToer() {
		return billToer;
	}
	public void setBillToer(String billToer) {
		this.billToer = billToer;
	}
	public String getBillToContact() {
		return billToContact;
	}
	public void setBillToContact(String billToContact) {
		this.billToContact = billToContact;
	}
	public Integer getBillToProvince() {
		return billToProvince;
	}
	public void setBillToProvince(Integer billToProvince) {
		this.billToProvince = billToProvince;
	}
	public Integer getBillToCity() {
		return billToCity;
	}
	public void setBillToCity(Integer billToCity) {
		this.billToCity = billToCity;
	}
	public Integer getBillToCounty() {
		return billToCounty;
	}
	public void setBillToCounty(Integer billToCounty) {
		this.billToCounty = billToCounty;
	}
	public Integer getBillToTown() {
		return billToTown;
	}
	public void setBillToTown(Integer billToTown) {
		this.billToTown = billToTown;
	}
	public String getBillToAddress() {
		return billToAddress;
	}
	public void setBillToAddress(String billToAddress) {
		this.billToAddress = billToAddress;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getRepaymentDate() {
		return repaymentDate;
	}
	public void setRepaymentDate(String repaymentDate) {
		this.repaymentDate = repaymentDate;
	}
	public Integer getInvoiceNum() {
		return invoiceNum;
	}
	public void setInvoiceNum(Integer invoiceNum) {
		this.invoiceNum = invoiceNum;
	}
	public Integer getCurrentBatch() {
		return currentBatch;
	}
	public void setCurrentBatch(Integer currentBatch) {
		this.currentBatch = currentBatch;
	}
	public Integer getTotalBatch() {
		return totalBatch;
	}
	public void setTotalBatch(Integer totalBatch) {
		this.totalBatch = totalBatch;
	}
	public BigDecimal getInvoiceNakedPrice() {
		return invoiceNakedPrice;
	}
	public void setInvoiceNakedPrice(BigDecimal invoiceNakedPrice) {
		this.invoiceNakedPrice = invoiceNakedPrice;
	}
	public BigDecimal getInvoiceTaxPrice() {
		return invoiceTaxPrice;
	}
	public void setInvoiceTaxPrice(BigDecimal invoiceTaxPrice) {
		this.invoiceTaxPrice = invoiceTaxPrice;
	}
	public BigDecimal getInvoicePrice() {
		return invoicePrice;
	}
	public void setInvoicePrice(BigDecimal invoicePrice) {
		this.invoicePrice = invoicePrice;
	}
	public BigDecimal getTotalBatchInvoiceNakedAmount() {
		return totalBatchInvoiceNakedAmount;
	}
	public void setTotalBatchInvoiceNakedAmount(
			BigDecimal totalBatchInvoiceNakedAmount) {
		this.totalBatchInvoiceNakedAmount = totalBatchInvoiceNakedAmount;
	}
	public BigDecimal getTotalBatchInvoiceTaxAmount() {
		return totalBatchInvoiceTaxAmount;
	}
	public void setTotalBatchInvoiceTaxAmount(BigDecimal totalBatchInvoiceTaxAmount) {
		this.totalBatchInvoiceTaxAmount = totalBatchInvoiceTaxAmount;
	}
	public BigDecimal getTotalBatchInvoiceAmount() {
		return totalBatchInvoiceAmount;
	}
	public void setTotalBatchInvoiceAmount(BigDecimal totalBatchInvoiceAmount) {
		this.totalBatchInvoiceAmount = totalBatchInvoiceAmount;
	}
	
}
