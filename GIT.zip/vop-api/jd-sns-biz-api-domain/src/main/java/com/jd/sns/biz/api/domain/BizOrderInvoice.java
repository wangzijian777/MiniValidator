/*
 * Copyright (c) 2014 www.jd.com All rights reserved.
 * 本软件源代码版权归京东成都云平台所有,未经许可不得任意复制与传播.
 */
package com.jd.sns.biz.api.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * bizOrderInvoice
 * @author J-ONE
 * @since 2014-08-14
 */
public class BizOrderInvoice implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long id;
	private Long orderId;
	private String pin;
	private Integer invoiceType;
	private Integer seletedInvoiceTitle;
	private String companyName;
	private Integer invoiceContentType;
	private String consigneeName;
	private String phone;
	private Integer provinceId;
	private Integer cityId;
	private Integer countyId;
	private Integer townId;
	private String address;
	private String vatCompanyName;
	private String code;
	private String regAddr;
	private String regPhone;
	private String regBank;
	private String regBankAccount;
	private Date created;
	
	
		public BizOrderInvoice(){
		//默认无参构造方法
	}

		
		
		
		
	public String getCode() {
			return code;
		}





		public void setCode(String code) {
			this.code = code;
		}





	public Long getId() {
			return id;
		}



		public void setId(Long id) {
			this.id = id;
		}



	/**
	 * 获取 orderId
	 * @return
	 */
	public Long getOrderId(){
		return orderId;
	}
	
	/**
	 * 设置 orderId
	 * @param orderId
	 */
	public void setOrderId(Long orderId){
		this.orderId = orderId;
	}

	/**
	 * 获取 pin
	 * @return
	 */
	public String getPin(){
		return pin;
	}
	
	/**
	 * 设置 pin
	 * @param pin
	 */
	public void setPin(String pin){
		this.pin = pin;
	}

	/**
	 * 获取 invoiceType
	 * @return
	 */
	public Integer getInvoiceType(){
		return invoiceType;
	}
	
	/**
	 * 设置 invoiceType
	 * @param invoiceType
	 */
	public void setInvoiceType(Integer invoiceType){
		this.invoiceType = invoiceType;
	}

	/**
	 * 获取 seletedInvoiceTitle
	 * @return
	 */
	public Integer getSeletedInvoiceTitle(){
		return seletedInvoiceTitle;
	}
	
	/**
	 * 设置 seletedInvoiceTitle
	 * @param seletedInvoiceTitle
	 */
	public void setSeletedInvoiceTitle(Integer seletedInvoiceTitle){
		this.seletedInvoiceTitle = seletedInvoiceTitle;
	}

	/**
	 * 获取 companyName
	 * @return
	 */
	public String getCompanyName(){
		return companyName;
	}
	
	/**
	 * 设置 companyName
	 * @param companyName
	 */
	public void setCompanyName(String companyName){
		this.companyName = companyName;
	}

	/**
	 * 获取 invoiceContentType
	 * @return
	 */
	public Integer getInvoiceContentType(){
		return invoiceContentType;
	}
	
	/**
	 * 设置 invoiceContentType
	 * @param invoiceContentType
	 */
	public void setInvoiceContentType(Integer invoiceContentType){
		this.invoiceContentType = invoiceContentType;
	}

	/**
	 * 获取 consigneeName
	 * @return
	 */
	public String getConsigneeName(){
		return consigneeName;
	}
	
	/**
	 * 设置 consigneeName
	 * @param consigneeName
	 */
	public void setConsigneeName(String consigneeName){
		this.consigneeName = consigneeName;
	}

	/**
	 * 获取 phone
	 * @return
	 */
	public String getPhone(){
		return phone;
	}
	
	/**
	 * 设置 phone
	 * @param phone
	 */
	public void setPhone(String phone){
		this.phone = phone;
	}

	

	public Integer getProvinceId() {
		return provinceId;
	}





	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}





	public Integer getCityId() {
		return cityId;
	}





	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}







	public Integer getCountyId() {
		return countyId;
	}





	public void setCountyId(Integer countyId) {
		this.countyId = countyId;
	}





	public Integer getTownId() {
		return townId;
	}





	public void setTownId(Integer townId) {
		this.townId = townId;
	}





	/**
	 * 获取 address
	 * @return
	 */
	public String getAddress(){
		return address;
	}
	
	/**
	 * 设置 address
	 * @param address
	 */
	public void setAddress(String address){
		this.address = address;
	}

	/**
	 * 获取 vatCompanyName
	 * @return
	 */
	public String getVatCompanyName(){
		return vatCompanyName;
	}
	
	/**
	 * 设置 vatCompanyName
	 * @param vatCompanyName
	 */
	public void setVatCompanyName(String vatCompanyName){
		this.vatCompanyName = vatCompanyName;
	}

	/**
	 * 获取 regAddr
	 * @return
	 */
	public String getRegAddr(){
		return regAddr;
	}
	
	/**
	 * 设置 regAddr
	 * @param regAddr
	 */
	public void setRegAddr(String regAddr){
		this.regAddr = regAddr;
	}

	/**
	 * 获取 regPhone
	 * @return
	 */
	public String getRegPhone(){
		return regPhone;
	}
	
	/**
	 * 设置 regPhone
	 * @param regPhone
	 */
	public void setRegPhone(String regPhone){
		this.regPhone = regPhone;
	}

	/**
	 * 获取 regBank
	 * @return
	 */
	public String getRegBank(){
		return regBank;
	}
	
	/**
	 * 设置 regBank
	 * @param regBank
	 */
	public void setRegBank(String regBank){
		this.regBank = regBank;
	}

	/**
	 * 获取 regBankAccount
	 * @return
	 */
	public String getRegBankAccount(){
		return regBankAccount;
	}
	
	/**
	 * 设置 regBankAccount
	 * @param regBankAccount
	 */
	public void setRegBankAccount(String regBankAccount){
		this.regBankAccount = regBankAccount;
	}

	/**
	 * 获取 created
	 * @return
	 */
	public Date getCreated(){
		return created;
	}
	
	/**
	 * 设置 created
	 * @param created
	 */
	public void setCreated(Date created){
		this.created = created;
	}
}