package com.jd.sns.biz.api.domain;

import java.util.Date;

public class BizOrderDifference {
	private long id;
	private long jdOrderId;
	private String content;
	private String clientId;
	private int state;
	private int yn;
	private Date created;
	private Date modified;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getJdOrderId() {
		return jdOrderId;
	}
	public void setJdOrderId(long jdOrderId) {
		this.jdOrderId = jdOrderId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getModified() {
		return modified;
	}
	public void setModified(Date modified) {
		this.modified = modified;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
}
