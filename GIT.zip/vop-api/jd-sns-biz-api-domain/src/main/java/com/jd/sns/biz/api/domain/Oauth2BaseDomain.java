package com.jd.sns.biz.api.domain;

public class Oauth2BaseDomain {
	
	private String access_token;
	private String ip;
	
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	
}
