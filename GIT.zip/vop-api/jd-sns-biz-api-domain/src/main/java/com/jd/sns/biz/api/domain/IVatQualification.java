package com.jd.sns.biz.api.domain;

import javax.xml.datatype.XMLGregorianCalendar;

/**
 * 增票信息接口
 * @author shilun
 *
 */
public interface IVatQualification {

	/**
	 * 获取account属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getAccount();

	/**
	 * 设置account属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setAccount(String value);

	/**
	 * 获取address属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getAddress();

	/**
	 * 设置address属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setAddress(String value);

	/**
	 * 获取apply属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link Integer }
	 *     
	 */
	public abstract Integer getApply();

	/**
	 * 设置apply属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link Integer }
	 *     
	 */
	public abstract void setApply(Integer value);

	/**
	 * 获取applyStr属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getApplyStr();

	/**
	 * 设置applyStr属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setApplyStr(String value);

	/**
	 * 获取archivesId属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getArchivesId();

	/**
	 * 设置archivesId属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setArchivesId(String value);

	/**
	 * 获取bank属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getBank();

	/**
	 * 设置bank属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setBank(String value);

	/**
	 * 获取company属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getCompany();

	/**
	 * 设置company属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setCompany(String value);

	/**
	 * 获取createDate属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link XMLGregorianCalendar }
	 *     
	 */
	public abstract XMLGregorianCalendar getCreateDate();

	/**
	 * 设置createDate属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link XMLGregorianCalendar }
	 *     
	 */
	public abstract void setCreateDate(XMLGregorianCalendar value);

	/**
	 * 获取createEndTime属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getCreateEndTime();

	/**
	 * 设置createEndTime属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setCreateEndTime(String value);

	/**
	 * 获取createStartTime属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getCreateStartTime();

	/**
	 * 设置createStartTime属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setCreateStartTime(String value);

	/**
	 * 获取creator属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getCreator();

	/**
	 * 设置creator属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setCreator(String value);

	/**
	 * 获取endRow属性的值。
	 * 
	 */
	public abstract int getEndRow();

	/**
	 * 设置endRow属性的值。
	 * 
	 */
	public abstract void setEndRow(int value);

	/**
	 * 获取endTime属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link XMLGregorianCalendar }
	 *     
	 */
	public abstract XMLGregorianCalendar getEndTime();

	/**
	 * 设置endTime属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link XMLGregorianCalendar }
	 *     
	 */
	public abstract void setEndTime(XMLGregorianCalendar value);

	/**
	 * 获取endTimeStr属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getEndTimeStr();

	/**
	 * 设置endTimeStr属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setEndTimeStr(String value);

	/**
	 * 获取id属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link Integer }
	 *     
	 */
	public abstract Integer getId();

	/**
	 * 设置id属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link Integer }
	 *     
	 */
	public abstract void setId(Integer value);

	/**
	 * 获取importSuccess属性的值。
	 * 
	 */
	public abstract boolean isImportSuccess();

	/**
	 * 设置importSuccess属性的值。
	 * 
	 */
	public abstract void setImportSuccess(boolean value);

	/**
	 * 获取memberName属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getMemberName();

	/**
	 * 设置memberName属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setMemberName(String value);

	/**
	 * 获取memberType属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getMemberType();

	/**
	 * 设置memberType属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setMemberType(String value);

	/**
	 * 获取modifiedTaxId属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getModifiedTaxId();

	/**
	 * 设置modifiedTaxId属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setModifiedTaxId(String value);

	/**
	 * 获取phone属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getPhone();

	/**
	 * 设置phone属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setPhone(String value);

	/**
	 * 获取reserve1属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getReserve1();

	/**
	 * 设置reserve1属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setReserve1(String value);

	/**
	 * 获取reserve2属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getReserve2();

	/**
	 * 设置reserve2属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setReserve2(String value);

	/**
	 * 获取reserve3属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getReserve3();

	/**
	 * 设置reserve3属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setReserve3(String value);

	/**
	 * 获取startRow属性的值。
	 * 
	 */
	public abstract int getStartRow();

	/**
	 * 设置startRow属性的值。
	 * 
	 */
	public abstract void setStartRow(int value);

	/**
	 * 获取startTime属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link XMLGregorianCalendar }
	 *     
	 */
	public abstract XMLGregorianCalendar getStartTime();

	/**
	 * 设置startTime属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link XMLGregorianCalendar }
	 *     
	 */
	public abstract void setStartTime(XMLGregorianCalendar value);

	/**
	 * 获取startTimeStr属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getStartTimeStr();

	/**
	 * 设置startTimeStr属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setStartTimeStr(String value);

	/**
	 * 获取taxId属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getTaxId();

	/**
	 * 设置taxId属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setTaxId(String value);

	/**
	 * 获取updateDate属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link XMLGregorianCalendar }
	 *     
	 */
	public abstract XMLGregorianCalendar getUpdateDate();

	/**
	 * 设置updateDate属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link XMLGregorianCalendar }
	 *     
	 */
	public abstract void setUpdateDate(XMLGregorianCalendar value);

	/**
	 * 获取updater属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link String }
	 *     
	 */
	public abstract String getUpdater();

	/**
	 * 设置updater属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link String }
	 *     
	 */
	public abstract void setUpdater(String value);

	/**
	 * 获取valid属性的值。
	 * 
	 * @return
	 *     possible object is
	 *     {@link Integer }
	 *     
	 */
	public abstract Integer getValid();

	/**
	 * 设置valid属性的值。
	 * 
	 * @param value
	 *     allowed object is
	 *     {@link Integer }
	 *     
	 */
	public abstract void setValid(Integer value);

}