package com.jd.sns.biz.api.constant;

/**
 * UMP方法监控
 * @author cdwangyong3
 *
 */
public final class UMPFunctionKeyConstant {
	/**********内部方法监控key*************/
	public static final String CHECK_REPEAT_SUBMIT_ORDER="vop-api.BizOrderUtils.checkRepeatSubmitOrder";
	public static final String CHECK_VISIT_LOGIN_PAGE_PARAMS="vop-api.Oauth2ServiceImpl.checkVisitLoginPageParams";
	public static final String CHECK_GET_TOKEN_PARAM="vop-api.Oauth2ServiceImpl.checkGetTokenParam";
	public static final String CREATE_ACCESS_TOKEN="vop-api.Oauth2ServiceImpl.createAccessToken";
	public static final String CHECK_TOKEN="vop-api.Oauth2ServiceImpl.checkToken";
	public static final String GET_ACCESS_TOKEN_BY_REFRESH_TOKEN="vop-api.Oauth2ServiceImpl.getAccessTokenByRefreshToken";
	
	public static final String REFRESH_TOKEN="vop-api.Oauth2ServiceImpl.refreshToken";
	public static final String CREATE_USER="vop-api.UserServiceImpl.createUser";
	public static final String DEL_USER="vop-api.UserServiceImpl.delUser";
	public static final String UPDATE_USER="vop-api.UserServiceImpl.updateUser";
	public static final String GET_USER_BY_CLIENT_ID_AND_CACHE="vop-api.UserServiceImpl.getUserByClientIdAndCache";
	/**
	 * 库存接口
	 */
	public static final String GET_STOCK_BY_IDS="vop-api.StockStateServiceImpl.getStockByIds";
	/**
	 * 新库存接口
	 */
	public static final String GET_NEW_STOCK_BY_IDS="vop-api.StockStateServiceImpl.getNewStockByIds";
	public static final String SELECT_PAGE_NUM_BY_CLIENT_ID="vop-api.ProductServiceImpl.selectPageNumByClientId";
	public static final String SELECT_SKUIDS_BY_CLIENT_ID_AND_PAGE_NUM="vop-api.ProductServiceImpl.selectSkuIdsByClientIdAndPageNum";
	public static final String GET_DETAIL="vop-api.ProductServiceImpl.getDetail";
	public static final String SKU_STATE="vop-api.ProductServiceImpl.skuState";
	public static final String SKU_IMAGE="vop-api.ProductServiceImpl.skuImage";
	
	
	public static final String SEND_GIFT_CARD_SMS="vop-api.BizGiftcarOrderServiceImpl.sendSms";
	public static final String QUERY_CREDIT_LIMIT="vop-api.BizJincaiQueryServiceImpl.queryCreditLimit";//查询金采授信
	
	
	public static final String GET_PRODUCT_COMMENT_SUMMARYS="vop-api.ProductServiceImpl.getProductCommentSummarys";
	/**
	 * 预占库存下单
	 */
	public static final String SUBMIT_ORDER="vop-api.OccupyStockBizOrderServiceImpl.submitOrder";
	public static final String CONFIRM_ORDER="vop-api.OccupyStockBizOrderServiceImpl.confirmOrder";
	public static final String CANCEL="vop-api.OccupyStockBizOrderServiceImpl.cancel";
	public static final String ASSEMBLE_SKU_PRICE="vop-api.OccupyStockBizOrderServiceImpl.assembleSkuPrice";
	
	
	/**
	 * 协议价格批量查询
	 */
	public static final String BATCH="vop-api.JdPriceServiceImpl.batch";
	/**
	 * 京东价格批量查询
	 */
	public static final String JD_PRICE_BATCH_FROM_POOL="vop-api.JdPriceServiceImpl.jdPriceBatchFromPool";
	/**
	 * 根据skuId获取协议价
	 */
	public static final String GET_PRICE_BY_SKU_ID="vop-api.JdPriceServiceImpl.getPriceBySkuId";
	/**
	 * 根据skuId获取协议价
	 */
	public static final String GET_JDPRICE_BY_SKU_ID="vop-api.JdPriceServiceImpl.getJdPriceBySkuId";
	/**
	 * 查询余额
	 */
	public static final String SELECT_BALANCE="vop-api.JdPriceServiceImpl.selectBalance";
	/**
	 * 查询金彩额度
	 */
	public static final String GET_JINCAI_CREDIT="vop-api.JdPriceServiceImpl.getJincaiCredit";
	/**
	 * 获取省份信息
	 */
	public static final String GET_PROVINCES="vop-api.JdAreaServiceImpl.getProvinces";
	/**
	 * 获取城市
	 */
	public static final String GET_CITYS="vop-api.JdAreaServiceImpl.getCitys";
	/**
	 * 获取县
	 */
	public static final String GET_COUNTYS="vop-api.JdAreaServiceImpl.getCountys";
	/**
	 * 获取乡镇
	 */
	public static final String GET_TOWNS="vop-api.JdAreaServiceImpl.getTowns";
	/**
	 * 获取发票信息
	 */
	public static final String GET_INVOICE_INFO="vop-api.InvoiceServiceImpl.getInvoiceInfo";
	
	
	public static final String INSERT_JD_DEMAND_ORDER="vop-api.DemandOrderServiceImpl.insertJdDemandOrder";
	public static final String CANCEL_JD_DEMAND_ORDER="vop-api.DemandOrderServiceImpl.cancelJdDemandOrder";
	public static final String SELECT_DEMAND_ORDER_BY_ID="vop-api.DemandOrderServiceImpl.selectDemandOrderById";
	public static final String CHECK_THIRD_ORDER_EXIST="vop-api.DemandOrderServiceImpl.checkThirdOrderExist";
	public static final String CHECK_HANG_UP_ORDER="vop-api.CheckOrderServiceImpl.checkHangUpOrder";
	public static final String CHECK_ORDER_BY_STATE="vop-api.CheckOrderServiceImpl.checkOrderByState";
	public static final String CHECK_ORDER_BY_TYPE="vop-api.CheckOrderServiceImpl.checkOrderByType";
	public static final String GET_QB_PRICE="vop-api.BizQBServiceImpl.getQBPrice";
	
	public static final String QB_ORDER="vop-api.BizQBServiceImpl.qBOrder";
	public static final String QUERY_QB_ORDER_BY_ORDER_ID="vop-api.BizQBServiceImpl.queryQBOrderByOrderid";
	public static final String QUERY_QB_ORDER_BY_THIRD_ID="vop-api.BizQBServiceImpl.queryQBOrderByThirdid";
	
	/**
	 * 需求单形式的下订单接口
	 */
	public static final String BIZQBSERVICEIMPL_SUBMIT_ORDER="vop-api.BizOrderServiceImpl.submitOrder";
	/**
	 * 需求单形式的取消订单
	 */
	public static final String BIZQBSERVICEIMPL_CANCEL_JD_ORDER="vop-api.BizOrderServiceImpl.cancelJdOrder";
	/**
	 * 需求单形式的选择订单
	 */
	public static final String BIZQBSERVICEIMPL_SELECT_JD_ORDER="vop-api.BizOrderServiceImpl.selectJdOrder";
	
	/**
	 * 需求单形式的订单跟踪
	 */
	public static final String BIZQBSERVICEIMPL_ORDER_TRACK="vop-api.BizOrderServiceImpl.orderTrack";

	public static final String SELECT_JD_ORDER_LIST_BY_THIRD_ORDER="vop-api.BizOrderServiceImpl.selectJdOrderListByThirdOrder";

	public static final String SELECT_BIZ_ORDER_BY_THIRD_ORDER="vop-api.BizOrderServiceImpl.selectBizOrderByThirdOrder";
	
	public static final String SELECT_BIZ_ORDER_DO_PAY="vop-api.BizOrderServiceImpl.doPay";
	
	public static final String BIZ_ORDER_FLOW_SERVICEIMPL_SUBMIT="vop-api.BizOrderFlowServiceImpl.submit";
	public static final String PRINT_LOG="vop-api.InputOutputInterceptor.printLog";
	public static final String BIZ_ORDER_FLOW_SERVICEIMPL_SELECT="vop-api.BizOrderFlowServiceImpl.select";
	public static final String BIZ_ORDER_FLOW_SERVICEIMPL_CANCEL="vop-api.BizOrderFlowServiceImpl.cancel";
	
	public static final String INSERT_BIZORDER_DIFFERENCE="vop-api.BizOrderDifferenceServiceImpl.insertBizOrderDifference";
	
	public static final String GET_MESSAGE="vop-api.BizMessageServiceImpl.getMessage";	
	public static final String DEL_MESSAGE="vop-api.BizMessageServiceImpl.delMessage";
	public static final String REDIS_DEL_MESSAGE="vop-api.BizMessageServiceImpl.redis.delMessage";
	public static final String BIZ_INVOICE_SERVICEIMPL_SUBMIT="vop-api.BizInvoiceServiceImpl.submit";
	public static final String BIZ_INVOICE_SERVICEIMPL_SELECT="vop-api.BizInvoiceServiceImpl.select";
	
	public static final String BUY="vop-api.BizGiftcarOrderServiceImpl.buy";
	public static final String SELECT_GIFT_CARDS_BY_JD_ORDER_ID="vop-api.BizGiftcarOrderServiceImpl.selectGiftcardsByJdOrderId";
	public static final String SELECT_JD_ORDER_BY_THIRD_ORDER="vop-api.BizGiftcarOrderServiceImpl.selectJdOrderByThirdOrder";
	
	public static final String CHECK_SKU_LIST_EXIST="vop-api.BaseOrderServiceImpl.checkSkuListExist";
	
	public static final String SUBMIT_ORDER_UTILS_SUBMIT_ORDER="vop-api.submitOrderUtils.submitOrder";
	
	
	
	
	/**********外部接口监控key*************/
	public static final String JDPRODUCTSERVICE_QUERYPRODUCTBASE="vop-api.outline.jdProductService.queryProductBase";
	public static final String JDPRODUCTSERVICE_QUERYBIGFIELD="vop-api.outline.jdProductService.queryBigField";
	public static final String JDPRODUCTSERVICE_QUERYEXTEND="vop-api.outline.jdProductService.queryExtend";
	public static final String MONTHLYQUOTASERVICE_GETBALANCE="vop-api.outline.monthlyQuotaService.getBalance";
	public static final String MONTHLYQUOTASERVICE_LOCKMONTHLYQUOTA="vop-api.outline.monthlyQuotaService.lockMonthlyQuota";
	public static final String MONTHLYQUOTASERVICE_UNLOCKMONTHLYQUOTA="vop-api.outline.monthlyQuotaService.unlockMonthlyQuota";
	public static final String MONTHLYQUOTASERVICE_COMPLETEORDER="vop-api.outline.monthlyQuotaService.completeOrder";
	public static final String SUBMITORDEREXPORT_SUBMITORDER="vop-api.outline.submitOrderExport.submitOrder";
	public static final String JDSTOCKSTATESERVICE_QUERYSTOCKSTATELISTBYAREA="vop-api.outline.jdStockStateService.queryStockStateListByArea";
	public static final String ORDERINFOEXPORT_GETORDERID="vop-api.outline.orderInfoExport.getOrderId";
	public static final String MONTHLYPAYMENTSERVICE_QUERYBIZPAYFIRSTCARDS="vop-api.outline.monthlyPaymentService.queryBizPayFirstCards";
	public static final String AFTERSALESERVICE_GETAVAILABLENUMBERCOMP="vop-api.outline.afterSaleService.getAvailableNumberComp";
	public static final String AFTERSALESERVICE_GETCUSTOMEREXPECTCOMP="vop-api.outline.afterSaleService.getCustomerExpectComp";
	public static final String AFTERSALESERVICE_GETWARERETURNJDCOMP="vop-api.outline.afterSaleService.getWareReturnJdComp";
	public static final String AFTERSALESERVICE_CREATEAFSAPPLY="vop-api.outline.afterSaleService.createAfsApply";
	public static final String AFTERSALESERVICE_UPDATESENDSKU="vop-api.outline.afterSaleService.updateSendSku";
	public static final String AFTERSALESERVICE_GETSERVICELISTPAGE="vop-api.outline.afterSaleService.getServiceListPage";
	public static final String AFTERSALESERVICE_GETSERVICEDETAILINFO="vop-api.outline.afterSaleService.getServiceDetailInfo";
	public static final String AFTERSALESERVICE_AUDITCANCEL="vop-api.outline.afterSalecontroller.auditCancel";
	
	public static final String GETRTPRICE_GETSELLPRICES = "vop-api.outline.getRTPriceService.getSellPrices";
	public static final String GETJDPRICE_GETJDPRICES = "vop-api.outline.getJdPriceService.getJdPrices";
	
	
	public static final String PROMOINFOSERVICE_FINDGIFTINFOBYSKUIDS="vop-api.outline.promoInfoService.findGiftInfoBySkuIds";
	public static final String STRIKEPRICEREDISSERVICE_GETSTRIKEPRICES="vop-api.outline.strikePriceRedisService.getStrikePrices";
	public static final String STRIKEPRICESERVICE_GETSTRIKEPRICE="vop-api.outline.strikePriceService.getStrikePrice";
	public static final String OOMSERVICESOAP_CANDO="vop-api.outline.oomServiceSoap.canDo";
	
	public static final String BATCH_GET_PRICES="vop-api.outline.BaseOrderServiceImpl.assembleSkuPrice";
	
	public static final String GET_SKUS_BY_CLIENTID_BIZID="vop-api.outline.skuPoolQueryService.getSkusByClientIdAndBizId";
	public static final String CHECK_SKUS_IN_POOL_BY_CLIENTID="vop-api.outline.skuPoolQueryService.checkSkusInPoolByClientId";
	public static final String CHECK_SKUS_BATCH_IN_POOL_BY_CLIENTID="vop-api.outline.skuPoolQueryService.checkSkusBatchInPoolByClientId";
	public static final String CHECK_SKUID_EXIST="vop-api.outline.skuPoolQueryService.checkSkuIdExist";
	public static final String GET_CLIENTIDS_BY_SKUID="vop-api.outline.skuPoolQueryService.getClientIdsBySkuId";
	public static final String GET_SKU_POOLS_BY_CLIENTID="vop-api.outline.skuPoolQueryService.getSkuPoolsByClientId";
	public static final String CHECK_AREAS_LIMIT = "vop-api.outline.bizCommonQueryService.checkAreasLimit";
	public static final String CHECK_HUO_DAO_FU_KUAN = "vop-api.outline.bizCommonQueryService.getHuoDaoFuKuan";
	public static final String GET_SKU_GIFTS = "vop-api.outline.bizCommonQueryService.getSkuGift";
	
	/**
	 * 账户余额接口
	 */
	public static final String BALANCESERVICE_GETBALANCE="vop-api.outline.balanceService.getbalance";
	
	/**
	 * 主数据  查询用户 client有效性接口
	 */
	public static final String QUERY_USER_CLIENT_ID_FLAG="vop-api.OccupyStockBizOrderServiceImpl.queryUserClientIdFlag";
	
	/**
	 * 主数据  查询用户合同权限信息接口
	 */
	public static final String QUERY_ERP_CONTRACT_INFO="vop-api.OccupyStockBizOrderServiceImpl.queryErpContractInfo";
	
	/**
	 * 主数据  查询用户合同权限信息接口（赠品查询需要校验）先查缓存，没有则查接口
	 */
	public static final String QUERY_ERP_CONTRACT_GIFT_INFO="vop-api.OccupyStockBizOrderServiceImpl.queryErpContractGiftInfo";
	
	/**
	 * 主数据  查询用户合同信息接口
	 */
	public static final String QUERY_CONTRACT_INFO="vop-api.OccupyStockBizOrderServiceImpl.queryContractInfo";
	
	/**
	 * 主数据  根据clientId查询服务费率
	 */
	public static final String QUERY_SERVICE_RATE="vop-api.OccupyStockBizOrderServiceImpl.queryServiceRate";
	
	/**
	 * VXP 订单提交
	 */
	public static final String VXP_SUBMIT_ORDER="vop-api.OccupyStockBizOrderServiceImpl.vxpSubmitOrder";
	
	/**
	 * 主数据  redis相关监控
	 */
	public static final String REDIS_SET ="vop-api.JdCloudRedisUtilsImpl.set";
	public static final String REDIS_GET ="vop-api.JdCloudRedisUtilsImpl.get";
	public static final String REDIS_EXISTS ="vop-api.JdCloudRedisUtilsImpl.exists";
	public static final String REDIS_SET_EX ="vop-api.JdCloudRedisUtilsImpl.setStringByExpire";
	
	public static final String CALL_PAYSERVICE_PAY = "vop-api.call.BizPayService.pay";
}
