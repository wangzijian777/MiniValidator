package com.jd.sns.biz.api.domain;

import java.util.List;

public class BizMessageParam {
	private String clientId;
	private List<Integer> ids;
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public List<Integer> getIds() {
		return ids;
	}
	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
	
}
