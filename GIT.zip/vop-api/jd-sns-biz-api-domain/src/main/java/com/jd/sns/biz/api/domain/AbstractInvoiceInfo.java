package com.jd.sns.biz.api.domain;

import java.io.Serializable;

public interface AbstractInvoiceInfo extends Serializable{
	public String getInvoiceName() ;
	public void setInvoiceName(String invoiceName) ;
	public String getInvoicePhone() ;
	public void setInvoicePhone(String invoicePhone);
	public Integer getInvoiceProvice();
	public void setInvoiceProvice(Integer invoiceProvice);
	public Integer getInvoiceCity();
	public void setInvoiceCity(Integer invoiceCity) ;
	public Integer getInvoiceCounty();
	public void setInvoiceCounty(Integer invoiceCounty);
	public Integer getInvoiceTown();
	public void setInvoiceTown(Integer invoiceTown) ;
	public String getInvoiceAddress() ;
	public void setInvoiceAddress(String invoiceAddress) ;

}