package com.jd.sns.biz.api.domain;

import java.util.List;

public class BizSkuList {
	private List<BizSku> sku;

	public List<BizSku> getSku() {
		return sku;
	}

	public void setSku(List<BizSku> sku) {
		this.sku = sku;
	}
}
