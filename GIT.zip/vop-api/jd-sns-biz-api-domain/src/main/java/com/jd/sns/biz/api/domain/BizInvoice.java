package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class BizInvoice {
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
	private long id;
	//京东订单号，批量以 , 分割
	private String jdOrder;
	//联通申请发票的唯一id标识
	private String markId;
	//发票类型   1普通 2增值税 4营业税
	private int invoiceType;
	//开票机构  544(京东信息)  6(总公司) 3(上海)   10(广州)	  4(成都)   600(武汉) 611(沈阳)  
	private int invoiceOrg;
	// 开票内容：    明细  办公用品  电脑配件  耗材  
	private String bizInvoiceContent;
	//期望开票时间  2013-11-8
	private Date invoiceDate;
	//发票抬头
	private String title;
	//预计还款时间  2013-11-8
	private Date repaymentDate;
	//京东生成的 发票号 （后台录入）
	private String invoiceId;
	//开票状态	0为未开票	1为已开票
	private int state;
	//是否有效，1为有效，0为无效
	private int yn;
	private Date created;
	private Date modified;
	private String clientId;
	//本次申请总金额
	private BigDecimal invoicePrice;
	//本次申请订单数
	private Integer invoiceNum;
	//结算单号
	private String settlementId;
	//结算订单总数
	private Integer settlementNum;
	//结算总金额
	private BigDecimal settlementPrice;
	//用户pin
	private String pin;
	
	
	
	public void setInvoiceDate(String invoiceDate){
		if(StringUtils.isNotBlank(invoiceDate)){
			try {
				this.invoiceDate = sdf.parse(invoiceDate);
			} catch (ParseException e) {
			}
		}
	}
	public void setRepaymentDate(String repaymentDate){
		if(StringUtils.isNotBlank(repaymentDate)){
			try {
				this.repaymentDate = sdf.parse(repaymentDate);
			} catch (ParseException e) {
			}
		}
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getJdOrder() {
		return jdOrder;
	}
	public void setJdOrder(String jdOrder) {
		this.jdOrder = jdOrder;
	}
	public String getMarkId() {
		return markId;
	}
	public void setMarkId(String markId) {
		this.markId = markId;
	}
	public int getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(int invoiceType) {
		this.invoiceType = invoiceType;
	}
	public int getInvoiceOrg() {
		return invoiceOrg;
	}
	public void setInvoiceOrg(int invoiceOrg) {
		this.invoiceOrg = invoiceOrg;
	}
	public String getBizInvoiceContent() {
		return bizInvoiceContent;
	}
	public void setBizInvoiceContent(String bizInvoiceContent) {
		this.bizInvoiceContent = bizInvoiceContent;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getRepaymentDate() {
		return repaymentDate;
	}
	public String getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getModified() {
		return modified;
	}
	public void setModified(Date modified) {
		this.modified = modified;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public static SimpleDateFormat getSdf() {
		return sdf;
	}
	public static void setSdf(SimpleDateFormat sdf) {
		BizInvoice.sdf = sdf;
	}
	public BigDecimal getInvoicePrice() {
		return invoicePrice;
	}
	public void setInvoicePrice(BigDecimal invoicePrice) {
		this.invoicePrice = invoicePrice;
	}
	public String getSettlementId() {
		return settlementId;
	}
	public void setSettlementId(String settlementId) {
		this.settlementId = settlementId;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public void setRepaymentDate(Date repaymentDate) {
		this.repaymentDate = repaymentDate;
	}
	public Integer getInvoiceNum() {
		return invoiceNum;
	}
	public void setInvoiceNum(Integer invoiceNum) {
		this.invoiceNum = invoiceNum;
	}
	public Integer getSettlementNum() {
		return settlementNum;
	}
	public void setSettlementNum(Integer settlementNum) {
		this.settlementNum = settlementNum;
	}
	public BigDecimal getSettlementPrice() {
		return settlementPrice;
	}
	public void setSettlementPrice(BigDecimal settlementPrice) {
		this.settlementPrice = settlementPrice;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	
}
