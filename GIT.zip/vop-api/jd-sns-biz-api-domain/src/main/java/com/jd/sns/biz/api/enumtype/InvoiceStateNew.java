package com.jd.sns.biz.api.enumtype;

/**
 * 是否开发票
 * 0-预借发票；1-随货开票；2-集中开票
 * @author bjtt
 */
public enum InvoiceStateNew {

	YUJIE_INVOICE(0, "预借发票"),
	SUIHUO_INVOICE(1, "随货开票"),
	JIZHONG_INVOICE(2, "集中开票");

	private final int type;
	private final String typeName;

	private InvoiceStateNew(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static InvoiceStateNew getType(int type) {
		for (InvoiceStateNew t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
