package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;
import java.util.Date;

public class BizPoolSkuPrice {
	private long id;
	private long skuId;
	private BigDecimal applyPrice;
	private String applyUser;
	private Date apply_time;
	private BigDecimal agreementPrice;
	private String agreementUser;
	private Date agreementTime;
	private Date created;
	private Date modified;
	private int yn;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getSkuId() {
		return skuId;
	}
	public void setSkuId(long skuId) {
		this.skuId = skuId;
	}
	public BigDecimal getApplyPrice() {
		return applyPrice;
	}
	public void setApplyPrice(BigDecimal applyPrice) {
		this.applyPrice = applyPrice;
	}
	public String getApplyUser() {
		return applyUser;
	}
	public void setApplyUser(String applyUser) {
		this.applyUser = applyUser;
	}
	public Date getApply_time() {
		return apply_time;
	}
	public void setApply_time(Date apply_time) {
		this.apply_time = apply_time;
	}
	public BigDecimal getAgreementPrice() {
		return agreementPrice;
	}
	public void setAgreementPrice(BigDecimal agreementPrice) {
		this.agreementPrice = agreementPrice;
	}
	public String getAgreementUser() {
		return agreementUser;
	}
	public void setAgreementUser(String agreementUser) {
		this.agreementUser = agreementUser;
	}
	public Date getAgreementTime() {
		return agreementTime;
	}
	public void setAgreementTime(Date agreementTime) {
		this.agreementTime = agreementTime;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getModified() {
		return modified;
	}
	public void setModified(Date modified) {
		this.modified = modified;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	
}
