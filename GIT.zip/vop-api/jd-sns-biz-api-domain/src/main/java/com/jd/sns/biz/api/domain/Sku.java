package com.jd.sns.biz.api.domain;

public class Sku extends BaseSku{
	/**
	 * 该主sku对应的延保sku
	 */
    private String yanbao;
    
    /**
     * sku类型 0普通 1附件 2赠品
     */
    private Integer type;
    /**
	 * 是否需要赠品
	 */
	private Boolean bNeedGift;
	
	/**
	 * 是否需要附件
	 */
	private Boolean bNeedAnnex;
	
	public Boolean getbNeedGift() {
		if(bNeedGift == null){ //默认不需要赠品
			return false;
		}
		return bNeedGift;
	}
	
	public Boolean getbNeedAnnex() {
		if(bNeedAnnex == null){ //默认需要附件
			return true;
		}
		return bNeedAnnex;
	}

	public void setbNeedGift(Boolean bNeedGift) {
		this.bNeedGift = bNeedGift;
	}

	public void setbNeedAnnex(Boolean bNeedAnnex) {
		this.bNeedAnnex = bNeedAnnex;
	}

	public String getYanbao() {
		return yanbao;
	}

	public void setYanbao(String yanbao) {
		this.yanbao = yanbao;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
    
}
