package com.jd.sns.biz.api.constant;

public class CacheConstant {

	
	/** 缓存10分钟*/
	public final static int TEN_MINUTES=10*60;
	
	
	/** 缓存5分钟*/
	public final static int HALF_HOUR=5*60;
	
	
	private final static String CACHE_CLIENT_CONTRACT_ ="bizapi_contract_client_id_";
	private final static String CACHE_CLIENT_QUALIFICATION_ ="bizapi_qualification_client_id_";
	private final static String CACHE_NUMBER_CONTRACT_ ="bizapi_contract_number_";
	
	/** 使用老下单接口（赠品接口改造前）客户clientId **/
	public final static String CACHE_GIFT_USE_OLD_ ="bizapi_gift_use_old";
	
	
	public final static String CACHE_KEY_USER_CLIENT="bizapi_user_client_id_";
	
	public final static String CACHE_KEY_SERVICE_RATE_CLIENT="bizapi_service_rate_client_id_";
	
	public final static String CACHE_KEY_INVOICE_USE_OLD = "bizapi_service_invoice_use_old";
	
	public final static String CACHE_KEY_SPECIAL_CHAR="bizapi_special_char";//vop特殊字符过滤
	
	public final static String CACHE_KEY_BIZMESSAGE_ISDEL="bizapi_bizmessage_isdel";//判断是否需要删除bizMessage里面redis存储的信息；
	
	/** 获取用户client_id缓存key */
	public static String getUserClientCacheKey(String clientId){
		return CACHE_KEY_USER_CLIENT+clientId;
	}
	
	/** 获取用户client_id缓存serviceRate 的 key */
	public static String getServiceRateClientCacheKey(String clientId){
		return CACHE_KEY_SERVICE_RATE_CLIENT+clientId;
	}

	/** 获取client_id 对应合同缓存key */
	public static String getClientContractCacheKey(String clientId){
		return CACHE_CLIENT_CONTRACT_ + clientId;
	}
	
	/** 获取client_id 对应增票缓存key */
	public static String getClientQualificationCacheKey(String clientId, String pin){
		return CACHE_CLIENT_QUALIFICATION_ + clientId + "_" + pin;
	}
	
	/** 获取contractNumber 对应合同缓存key */
	public static String getNumberContractCacheKey(String contractNumber){
		return CACHE_NUMBER_CONTRACT_ + contractNumber;
	}
}
