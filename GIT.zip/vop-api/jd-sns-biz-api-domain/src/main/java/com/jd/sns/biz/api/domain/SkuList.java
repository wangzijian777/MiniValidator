package com.jd.sns.biz.api.domain;

import java.util.List;

public class SkuList {
	private List<Sku> sku;

	public List<Sku> getSku() {
		return sku;
	}

	public void setSku(List<Sku> sku) {
		this.sku = sku;
	}
}
