package com.jd.sns.biz.api.enumtype;

/**
 * 错误码
 * @author bjtt
 **/
public enum ErrorCodeEnum {

	//0*** 成功	
	SUCCESS("0000","操作成功"),
	ORDER_SUCCESS("0001", "下单成功"),
	CANCEL_SUCCESS("0002", "取消订单成功"),
	CONFRIM_SUCCESS("0003", "确认订单成功"),
	INVOICE_APPLY_SUCCESS("0004", "申请开票成功"),
	INVOICE_ALL_SUCCESS("0005", "全部开票成功"),
	INVOICE_PART_SUCCESS("0006", "部分开票成功"),
	CANCEL_INVOICE_SUCCESS("0007", "取消开票成功"),
	REPEAT_SUBMIT("0008", "重复提交"),
	RETURN_NULL_VALUE("0010", "返回数据为空"),
	
	//1*** 参数问题	
	PARAM_NULL("1001", "参数为空"),
	PARAM_FORMAT_ERROR("1002", "参数格式不正确"),
	PARAM_VALUE_ERROR("1003", "参数值不正确"),
	PARAM_VALUE_REPEAT("1004", "参数重复"),
	
	//2**　权限问题
	AUTHORITY_USER("2001","用户权限不足"),
	AUTHORITY_CONTRACT("2002","合同权限不足"),
	AUTHORITY_ENTERPRISE("2003","企业权限不足"),
	AUTHORITY_PRODUCT_POOL("2004","商品池权限不足"),
	AUTHORITY_JINCAI("2005","金彩权限问题"),
	
	//3** 业务问题
	//33** 发票业务问题
	WAIT_CHECK("3301", "待审核"),
	INVOICE_REJECT("3302", "驳回"),
	PASS_WAIT_INVOICE("3303", "通过待开票"),
	MARKID_NOT_EXISTS("3304","申请单不存在"),
	
	//5*** 系统异常
	SYSTEM_ERROR("5001", "服务异常，请稍后重试"),
	UNKNOWN_ERROR("5002", "未知错误");
	
	/**
	 * 2**　权限问题
2001 用户、企业、合同权限问题
2002 商品池权限问题

3**  业务问题
30** 订单-下单业务
3001 未找到对应地址
3002 未找到商品相关信息
3003 商品相关校验不通过
3004 余额不足 
3005 配额不足或者已被锁定
3006 下单失败，原因为... vop soa分别定义
31** 订单-其他业务（确认、取消、对账）
3101 订单不存在
3102 该订单已确认下单
3103 不能单独确认子订单
3104 确认订单失败
3105 订单已取消
3106 该订单已经生产，不能取消订单！
3107 不能取消已确认订单
3108 不能取消子订单
3109 不能取消未确认订单
3110 不能取消预占并且已确认订单
3111 不能取消父订单
3112 查询信息为空
32** 查询业务
33** 发票业务
3301 待审核
3302 驳回
3303 通过待开票
34** 支付业务

5*** 系统异常
5001 服务异常，请稍后重试
	 */
	private final String type;
	private final String typeName;

	private ErrorCodeEnum(String type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static ErrorCodeEnum getType(String type) {
		for (ErrorCodeEnum t : values()) {
			if (type.equals(t.getType())) {
				return t;
			}
		}
		return null;
	}

	public String getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
