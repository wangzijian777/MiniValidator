package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Date;

public class DemandOrder {
	private Long jdDemandOrder;
	private String clientId;
	private String pin;
	private String thirdOrder;
	private String sku;
	private Integer province;
	private Integer city;
	private Integer county;
	private Integer town;
	private BigDecimal orderPrice;
	private Long jdOrderId;
	private String remark;
	private Date created;
	private Date updated;
	private int yn;
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getThirdOrder() {
		return thirdOrder;
	}
	public void setThirdOrder(String thirdOrder) {
		this.thirdOrder = thirdOrder;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public BigDecimal getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}
	public Long getJdOrderId() {
		return jdOrderId;
	}
	public void setJdOrderId(Long jdOrderId) {
		this.jdOrderId = jdOrderId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	public void setDemandOrder(String demandOrder){
		this.thirdOrder = demandOrder;
	}
	public Long getJdDemandOrder() {
		return jdDemandOrder;
	}
	public void setJdDemandOrder(Long jdDemandOrder) {
		this.jdDemandOrder = jdDemandOrder;
	}
	public Integer getProvince() {
		return province;
	}
	public void setProvince(Integer province) {
		this.province = province;
	}
	public Integer getCity() {
		return city;
	}
	public void setCity(Integer city) {
		this.city = city;
	}
	public Integer getCounty() {
		return county;
	}
	public void setCounty(Integer county) {
		this.county = county;
	}
	public Integer getTown() {
		return town;
	}
	public void setTown(Integer town) {
		this.town = town;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	
}
