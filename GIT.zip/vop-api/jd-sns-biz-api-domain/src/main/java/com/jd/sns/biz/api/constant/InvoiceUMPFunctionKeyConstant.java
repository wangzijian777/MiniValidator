package com.jd.sns.biz.api.constant;

/**
 * UMP方法监控
 * @author cdwangyong3
 *
 */
public final class InvoiceUMPFunctionKeyConstant {
	/**********内部方法监控key*************/
	public static final String CONTROLLER_SUBMIT_INVOICE = "web.sns.bizapi.InvoiceController.submitInvoice";
	public static final String CONTROLLER_SELECT_INVOICE = "web.sns.bizapi.InvoiceController.selectInvoice";
	public static final String CONTROLLER_CANCEL_INVOICE = "web.sns.bizapi.InvoiceController.cancelInvoice";
	
	public static final String SUBMIT_INVOICE = "vop-api.DoInvoiceServiceImpl.submitInvoice";
	public static final String SELECT_INVOICE = "vop-api.DoInvoiceServiceImpl.selectInvoice";
	public static final String CANCEL_INVOICE = "vop-api.DoInvoiceServiceImpl.cancelInvoice";
	
	/**********外部方法监控key*************/
	public static final String SUBMIT_INVOICE_APPLY = "vop-api.DoInvoiceServiceImpl.submitInvoiceApply";
	public static final String SELECT_INVOICE_STATE = "vop-api.DoInvoiceServiceImpl.getInvoiceApplyState";
	public static final String SELECT_INVOICE_DETAIL = "vop-api.DoInvoiceServiceImpl.getInvoiceApplyDetatil";
	public static final String CANCEL_INVOICE_APPLY = "vop-api.DoInvoiceServiceImpl.repealInvoiceApply";
}
