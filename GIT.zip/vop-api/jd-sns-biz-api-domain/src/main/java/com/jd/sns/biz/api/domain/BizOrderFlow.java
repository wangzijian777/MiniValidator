package com.jd.sns.biz.api.domain;

import java.util.Date;

public class BizOrderFlow {
	private long id;
	private String clientId;
	private Long orderId;
	//工单挂起类型 1为未收到，2为退货，3为换货
	private int workType;
	//工单最新简要描述
	private String workInfo;
	/**
	 *  挂起状态：
	 *	11联通方申请挂起，12联通方取消挂起
	 *	21 京东工单处理完毕  22 京东工单确认无法处理 
	 *	23工单处理完成3天后，默认取消挂起
	 */
	private int status;
	private Date created;
	private Date modified;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public int getWorkType() {
		return workType;
	}
	public void setWorkType(int workType) {
		this.workType = workType;
	}
	public String getWorkInfo() {
		return workInfo;
	}
	public void setWorkInfo(String workInfo) {
		this.workInfo = workInfo;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getModified() {
		return modified;
	}
	public void setModified(Date modified) {
		this.modified = modified;
	}
	
}
