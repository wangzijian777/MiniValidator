package com.jd.sns.biz.api.domain;

import java.util.Date;

public class BizPool {
	private long id;
	private int poolId;
	private String poolName;
	private String clientId;
	private String clientName;
	private Date created;
	private Date modified;
	private String ext_1;
	private String ext_2;
	private String ext_3;
	private int yn;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getPoolId() {
		return poolId;
	}
	public void setPoolId(int poolId) {
		this.poolId = poolId;
	}
	public String getPoolName() {
		return poolName;
	}
	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getModified() {
		return modified;
	}
	public void setModified(Date modified) {
		this.modified = modified;
	}
	public String getExt_1() {
		return ext_1;
	}
	public void setExt_1(String ext_1) {
		this.ext_1 = ext_1;
	}
	public String getExt_2() {
		return ext_2;
	}
	public void setExt_2(String ext_2) {
		this.ext_2 = ext_2;
	}
	public String getExt_3() {
		return ext_3;
	}
	public void setExt_3(String ext_3) {
		this.ext_3 = ext_3;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	
}
