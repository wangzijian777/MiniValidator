package com.jd.sns.biz.api.enumtype;

/**
 * SKU类型
 * 1-普通;2-附件;3-赠品
 */
public enum SkuTypeEnum {

	NORMAL_SKU(0, "普通sku"),
	ANNEX_SKU(1, "附件sku"),
	GIFT_SKU(2, "赠品sku"),
	YANBAO_SKU(3, "延保sku");
	
	
	private final int type;
	private final String typeName;

	private SkuTypeEnum(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static SkuTypeEnum getType(int type) {
		for (SkuTypeEnum t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}