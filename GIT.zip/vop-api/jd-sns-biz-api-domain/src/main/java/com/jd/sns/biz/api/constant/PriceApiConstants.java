package com.jd.sns.biz.api.constant;

/**
 * User: putengfei
 * Date: 14-9-12
 * Time: 下午2:42
 */
public class PriceApiConstants {

    /**
     * 批量获取redis价格
     */
    public static final String PRICE_API_BREDIS = "PRICE_API_BREDIS";

    /**
     * 单个获取redis价格
     */
    public static final String PRICE_API_REDIS = "PRICE_API_REDIS";

    /**
     * 批量获取实时价格
     */
    public static final String PRICE_API_BRT = "PRICE_API_BRT";

    /**
     * 单个获取实时价格
     */
    public static final String PRICE_API_RT = "PRICE_API_RT";
    
    

}
