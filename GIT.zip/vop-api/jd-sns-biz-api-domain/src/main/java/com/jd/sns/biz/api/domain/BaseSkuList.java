package com.jd.sns.biz.api.domain;

import java.util.List;

public class BaseSkuList {
	private List<BaseSku> sku;

	public List<BaseSku> getSku() {
		return sku;
	}

	public void setSku(List<BaseSku> sku) {
		this.sku = sku;
	}
}
