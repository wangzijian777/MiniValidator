package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;

import com.jd.sns.biz.api.enumtype.SkuTypeEnum;

public class BizSku extends BaseSku{
    private Integer type;
    private Long oid;
    
	public Integer getType() {
		if(type!=null){
			return type;
		}
		if(this.getPrice().compareTo(BigDecimal.ZERO)>0){
			return SkuTypeEnum.NORMAL_SKU.getType();
		}
		return SkuTypeEnum.GIFT_SKU.getType();
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Long getOid() {
		if(oid == null){
			return 0L;
		}
		return oid;
	}
	public void setOid(Long oid) {
		this.oid = oid;
	}
    
}
