package com.jd.sns.biz.api.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 金融支付定时任务
 * 
 * @author bjhuming
 */
public class CreditPayTask implements Serializable {

	private static final long serialVersionUID = -6353572626808745100L;
	private Long id;
	private String pin;
	private Long jdOrderId;
	private Integer state;
	private Date created;
	private Date modified;

	private int orderType = ORDER_TYPE_GOODS;
	
	/**
	 * 订单类型:实物
	 */
	public static final int ORDER_TYPE_GOODS = 1;
	/**
	 * 订单类型:礼品卡
	 */
	public static final int ORDER_TYPE_GIFTCARD = 2;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public Long getJdOrderId() {
		return jdOrderId;
	}

	public void setJdOrderId(Long jdOrderId) {
		this.jdOrderId = jdOrderId;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getModified() {
		return modified;
	}

	public void setModified(Date modified) {
		this.modified = modified;
	}

	public int getOrderType() {
		return orderType;
	}

	public void setOrderType(int orderType) {
		this.orderType = orderType;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CreditPayTask [created=").append(created).append(", id=").append(id).append(", jdOrderId=").append(jdOrderId).append(", modified=").append(modified).append(", pin=").append(pin).append(", state=").append(state).append(", orderType=").append(orderType).append("]");
		return builder.toString();
	}
	
}