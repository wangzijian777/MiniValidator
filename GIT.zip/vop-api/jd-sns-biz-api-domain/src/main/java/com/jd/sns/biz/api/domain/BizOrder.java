package com.jd.sns.biz.api.domain;

import java.math.BigDecimal;
import java.util.Date;

public class BizOrder {
	private long id;
	//京东订单号
	private long jdOrderId;
	//第三方唯一标识
	private String clientId;
	//京东需求单号
	private long jdDemandOrder;
	//用户pin
	private String pin;
	//第三方的订单单号
	private String thirdOrder;
	//商品sku
	//[{"skuId":1, "num":1,"bNeedAnnex":true, "bNeedGift":false,"yanbao": [{skuId:2}]}]
	private String sku;
	//一级地址
	private int province;
	//二级地址
	private int city;
	//三级地址
	private int county;
	//四级地址
	private int town=0;
	//总订单金额
	private BigDecimal orderPrice;
	//收货人姓名
	private String name;
	//收货人详细地址
	private String address;
	//收货人邮编
	private String zip;
	//收货人座机
	private String phone;
	//收货人手机
	private String mobile;
	//收货人邮箱
	private String email;
	//父订单号
	private long parentId;
	//类别，1为父订单，2为子订单
	private int type;
	//配送状态
	//0订单默认状态，1妥投，2拒收
	private int state;
	//订单状态、取消订单的话，则修改这个状态值
	//正常订单，状态是1，取消订单为0，二次拆单为2
	private int orderState;
	//备注
	private String remark;
	//创建时间
	private Date created;
	//提交订单时间
	private Date submitOrderTime;
	//配送信息更改时间
	private Date trackUpdateTime;
	//修改时间
	private Date updated;
	//用户访问ip
	private String ip;
	//是否挂起0为未挂起，1为挂起
	private Integer hangUpState;
	//是否开发票，0为未开发票，1为已开发票
	private Integer invoiceState;
	//发票类型 1普通发票 2增值税发票
	private Integer invoiceType;
	//发票抬头：4个人，5单位
	private Integer selectedInvoiceTitle;
	//如果发票抬头为单位，单位名称必填
	private String companyName;
	//1:明细，3：电脑配件，19:耗材，22：办公用品，增值税发票只能选择"明细
	private Integer invoiceContent;
	//预占库存提交订单状态，1为确认提交订单，0为已经提交订单，预占库存状态
	private Integer submitState;
	//创建订单的时间
	//createOrderTime为第三方网站提交订单开始预占库存的时间，submitOrderTime预占库存修改订单时间的最终下单时间。
	private Date createOrderTime;
	//订单防重的唯一标识
	private String orderguid;
	//价格类型 议0为协价 1为京东价
	private Integer priceType;
	//是否使用余额
	private Integer isUseBalance;
	//支付方式 (1：货到付款，2：邮局付款，4：在线支付，5：公司转账，6：银行转账，12：月结  	15：金融支付)
	private Integer paymentType;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getJdOrderId() {
		return jdOrderId;
	}
	public void setJdOrderId(long jdOrderId) {
		this.jdOrderId = jdOrderId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public long getJdDemandOrder() {
		return jdDemandOrder;
	}
	public void setJdDemandOrder(long jdDemandOrder) {
		this.jdDemandOrder = jdDemandOrder;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getThirdOrder() {
		return thirdOrder;
	}
	public void setThirdOrder(String thirdOrder) {
		this.thirdOrder = thirdOrder;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public int getProvince() {
		return province;
	}
	public void setProvince(int province) {
		this.province = province;
	}
	public int getCity() {
		return city;
	}
	public void setCity(int city) {
		this.city = city;
	}
	public int getCounty() {
		return county;
	}
	public void setCounty(int county) {
		this.county = county;
	}
	public int getTown() {
		return town;
	}
	public void setTown(int town) {
		this.town = town;
	}
	public BigDecimal getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(BigDecimal orderPrice) {
		this.orderPrice = orderPrice;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getParentId() {
		return parentId;
	}
	public void setParentId(long parentId) {
		this.parentId = parentId;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getOrderState() {
		return orderState;
	}
	public void setOrderState(int orderState) {
		this.orderState = orderState;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getSubmitOrderTime() {
		return submitOrderTime;
	}
	public void setSubmitOrderTime(Date submitOrderTime) {
		this.submitOrderTime = submitOrderTime;
	}
	public Date getTrackUpdateTime() {
		return trackUpdateTime;
	}
	public void setTrackUpdateTime(Date trackUpdateTime) {
		this.trackUpdateTime = trackUpdateTime;
	}
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Integer getHangUpState() {
		return hangUpState;
	}
	public void setHangUpState(Integer hangUpState) {
		this.hangUpState = hangUpState;
	}
	public Integer getInvoiceState() {
		return invoiceState;
	}
	public void setInvoiceState(Integer invoiceState) {
		this.invoiceState = invoiceState;
	}
	public Date getCreateOrderTime() {
		return createOrderTime;
	}
	public void setCreateOrderTime(Date createOrderTime) {
		this.createOrderTime = createOrderTime;
	}
	public String getOrderguid() {
		return orderguid;
	}
	public void setOrderguid(String orderguid) {
		this.orderguid = orderguid;
	}
	public Integer getSubmitState() {
		return submitState;
	}
	public void setSubmitState(Integer submitState) {
		this.submitState = submitState;
	}
	public Integer getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(Integer invoiceType) {
		this.invoiceType = invoiceType;
	}
	public Integer getSelectedInvoiceTitle() {
		return selectedInvoiceTitle;
	}
	public void setSelectedInvoiceTitle(Integer selectedInvoiceTitle) {
		this.selectedInvoiceTitle = selectedInvoiceTitle;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Integer getInvoiceContent() {
		return invoiceContent;
	}
	public void setInvoiceContent(Integer invoiceContent) {
		this.invoiceContent = invoiceContent;
	}
	public Integer getPriceType() {
		return priceType;
	}
	public void setPriceType(Integer priceType) {
		this.priceType = priceType;
	}
	public Integer getIsUseBalance() {
		return isUseBalance;
	}
	public void setIsUseBalance(Integer isUseBalance) {
		this.isUseBalance = isUseBalance;
	}
	public Integer getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(Integer paymentType) {
		this.paymentType = paymentType;
	}
}
