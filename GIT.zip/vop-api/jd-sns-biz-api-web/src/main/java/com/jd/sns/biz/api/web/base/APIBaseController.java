package com.jd.sns.biz.api.web.base;

import javax.servlet.http.HttpServletRequest;

import com.jd.common.util.StringUtils;

import commons.spring.mvc.controller.BaseController;

public class APIBaseController extends BaseController {
	
	protected String getRemoteIp(HttpServletRequest request) {
		if (request == null) {
			return null;
		}
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		if (StringUtils.isNotBlank(ip) && ip.contains(",")) {
			ip = ip.substring(0, ip.indexOf(","));
		}
		if (ip != null) {
			return ip.split(":")[0];
		}
		return null;
	}
	
	protected String getClient_id(HttpServletRequest request){
		return request.getAttribute("client_id").toString();
	}
	
	protected String getPin(HttpServletRequest request){
		return request.getAttribute("pin").toString();
	}
}
