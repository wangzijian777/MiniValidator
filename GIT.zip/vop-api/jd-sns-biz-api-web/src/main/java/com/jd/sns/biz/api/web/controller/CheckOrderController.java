package com.jd.sns.biz.api.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.constant.CheckOrderConstants;
import com.jd.sns.biz.api.service.CheckOrderService;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


@org.springframework.stereotype.Controller
@RequestMapping("/api/checkOrder")
public class CheckOrderController extends APIBaseController {
	
//	private static final Logger log = LoggerFactory.getLogger(CheckOrderController.class);
	
	private CheckOrderService checkOrderService;
	
	@RequestMapping(value = "checkNewOrder", method = RequestMethod.POST)
	public @ResponseBody String checkNewOrder(String date, String page, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.CheckOrderController.checkNewOrder", true, true);
		String result = checkOrderService.checkOrderByType(date, page, CheckOrderConstants.ORDER_CHECK_NEW);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "checkDlokOrder", method = RequestMethod.POST)
	public @ResponseBody String checkDlokOrder(String date, String page, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.CheckOrderController.checkDlokOrder", true, true);
		String result = checkOrderService.checkOrderByType(date, page, CheckOrderConstants.ORDER_CHECK_DLOK);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "checkRefuseOrder", method = RequestMethod.POST)
	public @ResponseBody String checkRefuseOrder(String date, String page, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.CheckOrderController.checkRefuseOrder", true, true);
		String result = checkOrderService.checkOrderByType(date, page, CheckOrderConstants.ORDER_CHECK_REFUSE);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "checkUnOpenInvoiceOrder", method = RequestMethod.POST)
	public @ResponseBody String checkUnOpenInvoiceOrder(String date, String page, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.CheckOrderController.checkUnOpenInvoiceOrder", true, true);
		String result = checkOrderService.checkOrderByState(date, page, 2, 3);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "checkHangUpOrder", method = RequestMethod.POST)
	public @ResponseBody String checkHangUpOrder(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.CheckOrderController.checkHangUpOrder", true, true);
		String result = checkOrderService.checkHangUpOrder();
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	public void setCheckOrderService(CheckOrderService checkOrderService) {
		this.checkOrderService = checkOrderService;
	}
	
}
