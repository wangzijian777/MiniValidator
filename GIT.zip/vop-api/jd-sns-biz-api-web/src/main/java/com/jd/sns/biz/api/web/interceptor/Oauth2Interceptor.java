package com.jd.sns.biz.api.web.interceptor;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.jd.common.util.StringUtils;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.service.domain.ResultBase;
import com.jd.sns.biz.api.service.oauth2.Oauth2Service;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


public class Oauth2Interceptor  implements HandlerInterceptor {
	
	private Oauth2Service oauth2Service;

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.visit.all", true, true);
		Profiler.registerInfoEnd(info);
		String token = request.getParameter("token");
		ResultBase result = new ResultBase();
		if(StringUtils.isNotBlank(token)){
			AccessToken at = oauth2Service.checkToken(token);
			if(at != null){
				request.setAttribute("pin", at.getPin());
				request.setAttribute("client_id", at.getClient_id());
				request.setAttribute("scope", at.getScope());
				return true;
			}else{
				result.setResultMessage("token已过期");
			}
		}else{
			result.setResultMessage("token不能为空");
		}
		PrintWriter pr = response.getWriter();
		response.setHeader("Content-Type", "application/json;charset=UTF-8");
		result.setSuccess(false);
		pr.print(APIUtils.parseObject2Json(result));
		return false;
//		request.setAttribute("pin", "yujianming_02");
//		request.setAttribute("client_id", "client_id_1");
//		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		
	}

	public void setOauth2Service(Oauth2Service oauth2Service) {
		this.oauth2Service = oauth2Service;
	}

}
