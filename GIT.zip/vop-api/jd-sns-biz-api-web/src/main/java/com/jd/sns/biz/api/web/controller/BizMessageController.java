package com.jd.sns.biz.api.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.service.BizMessageService;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


@org.springframework.stereotype.Controller
@RequestMapping("/api/message")
public class BizMessageController extends APIBaseController {
	
//	private static final Logger log = LoggerFactory.getLogger(BizMessageController.class);
	private BizMessageService bizMessageService;
	
	@RequestMapping(value = "get", method = RequestMethod.POST)
	public @ResponseBody String get(String type, String del,HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizMessageController.get", true, true);
		String result = bizMessageService.getMessage(type, del);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "del", method = RequestMethod.POST)
	public @ResponseBody String del(String id, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizMessageController.del", true, true);
		String result = bizMessageService.delMessage(id);
		Profiler.registerInfoEnd(info);
		return result;
	}

	public void setBizMessageService(BizMessageService bizMessageService) {
		this.bizMessageService = bizMessageService;
	}
	
}
