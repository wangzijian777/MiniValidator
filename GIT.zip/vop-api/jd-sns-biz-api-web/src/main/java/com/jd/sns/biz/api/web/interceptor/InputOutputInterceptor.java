package com.jd.sns.biz.api.web.interceptor;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.jd.sns.biz.api.common.utils.LogBusinessIdUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


/**
 * vop-api 输入输出拦截器：用于打印输入输出信息
 * @author cdwangyong3
 *
 */
@Aspect
public class InputOutputInterceptor implements HandlerInterceptor{
	private static final int STR_LEN=1800;
	private static Map<String,String> filter;//过滤不需要打印的接口
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		try {
			LogBusinessIdUtils.clear();
			String requestParams=getRequestParams(request);
			printLog("request",requestParams,STR_LEN);
		} catch (Exception e) {
			LogTypeEnum.INPUT_OUTPUT.error("拦截器打印请求参数失败",e);
		}		
		return true;
	}
	
	@Around("execution(* com.jd.sns.biz.api.web..*.*Controller.*(..))")
	public Object doAround(ProceedingJoinPoint pjp) throws Throwable{	
		Object retVal = pjp.proceed();
		try {
			if(!filter.containsKey(pjp.getSignature().toString())){
				printLog("response", retVal,STR_LEN);
			}
		} catch (Exception e) {
			LogTypeEnum.INPUT_OUTPUT.error("拦截器打印输出日志失败", e);
		}
		return retVal;
	}
	

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		if(ex!=null){
			LogTypeEnum.INPUT_OUTPUT.error(ex,"拦截器获取输入参数输出结果出错");
		}		
	}
	
	/**
	 * 获取请求参数
	 * @param request
	 * @return
	 */
	private String getRequestParams(HttpServletRequest request){
		StringBuffer params=new StringBuffer();
		params.append("path:");
		params.append(request.getRequestURI());
		params.append("\rparams:\r");
		Enumeration<String> paramNames=request.getParameterNames();
		while(paramNames.hasMoreElements()){
			String name=paramNames.nextElement();
			params.append(name).append(":").append(request.getParameter(name)).append("\r");
		}		
		return params.toString();
	}
	
	/**
	 * 打印请求响应日志
	 * @param requestParams 
	 * @param uuid 
	 */
	private void printLog(String type, Object content,int size){
		CallerInfo info=Profiler.registerInfo(UMPFunctionKeyConstant.PRINT_LOG, true, true);
		try {
			StringBuilder sb=new StringBuilder();
			if(content!=null){
				if(content.toString().length()<=size){
					sb.append(content);
				}else{
					List<String> list=split(content.toString(),size);
					for(String elem:list){
						printLog(type,elem,size);
					}
				}			
			}
			if(content.toString().length()<=size){
				String str=sb.toString();
				str=str.replaceAll("(?<=(mobile|phone|address):)(\\d|\\w|[\\u4e00-\\u9fa5])+(?=)", "***");
				LogTypeEnum.INPUT_OUTPUT.error(str);	
			}
		} catch (Exception e) {
			LogTypeEnum.INPUT_OUTPUT.error(e,"打印请求响应日志失败！");
			Profiler.functionError(info);
		}finally{
			Profiler.registerInfoEnd(info);
		}		
	}
	
	/**
	 * 由于统一日志对于长度超过2000的日志不展示，故将>2000的进行切割
	 * @param content
	 * @param size
	 * @return
	 */
	private List<String> split(String content,int size){
		List<String> list=new ArrayList<String>();
		int start=0;
		int end=start+size;
		int len=content.length()-1;
		while(start<=len && end<=len){
			String elem=content.substring(start, end);
			list.add(elem);
			start=end;
			end=start+size;
		}
		//把尾巴给加进来
		if(start<=len){
			String elem=content.substring(start,len+1);
			list.add(elem);
		}
		return list;
	}

	public static Map<String, String> getFilter() {
		return filter;
	}

	public void setFilter(Map<String, String> filter) {
		InputOutputInterceptor.filter = filter;
	}
}
