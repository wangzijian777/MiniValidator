package com.jd.sns.biz.api.web.domain;



public class ReqServiceListPageDto {
	private String clientId;
	private Long jdOrderId;
	private Integer pageSize;
	private Integer pageIndex;
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public Long getJdOrderId() {
		return jdOrderId;
	}
	public void setJdOrderId(Long jdOrderId) {
		this.jdOrderId = jdOrderId;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}
	
	
}
