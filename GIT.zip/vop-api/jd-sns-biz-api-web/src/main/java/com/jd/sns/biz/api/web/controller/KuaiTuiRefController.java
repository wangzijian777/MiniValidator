package com.jd.sns.biz.api.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.fce.orb.domain.CancelOrderDetail;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.service.KuaiTuiRefService;
import com.jd.sns.biz.api.web.base.APIBaseController;

//@org.springframework.stereotype.Controller
@RequestMapping("/api/kuaiTui")
public class KuaiTuiRefController extends APIBaseController {

	@Resource(name = "kuaiTuiRefService")
	private KuaiTuiRefService kuaiTuiRefService;

	@RequestMapping(value = "querySteps", method = RequestMethod.POST)
	public @ResponseBody String submit(String jdOrderId, String pin) {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", false);
		
		long jdOrderIdLong = NumberUtils.toLong(jdOrderId, 0);
		
		if(jdOrderIdLong <= 0){
			result.put("resultCode", String.valueOf(-1));
			result.put("resultMessage", "京东订单号不能为空!");
			return APIUtils.parseObject2Json(result);
		}
		
		if(!StringUtils.hasText(pin)){
			result.put("resultCode", String.valueOf(-1));
			result.put("resultMessage", "用户pin不能为空!");
			return APIUtils.parseObject2Json(result);
		}
		
		CancelOrderDetail detail = null;
		try {
			detail = kuaiTuiRefService.queryCancelStepsByOrderId(jdOrderIdLong, pin);
			if(detail != null){
				result.put("resultCode", String.valueOf(0));
				result.put("result", APIUtils.parseObject2Json(detail));
				result.put("success", true);
				result.put("resultMessage", "快退接口查询成功!");
			} else {
				result.put("resultCode", String.valueOf(1));
				result.put("resultMessage", "快退接口查询为空!");
			}
		} catch (Exception e) {
			result.put("resultCode", String.valueOf(2));
			result.put("resultMessage", "快退接口查询异常!");
		}
		
		return APIUtils.parseObject2Json(result);
	}


}
