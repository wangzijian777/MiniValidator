package com.jd.sns.biz.api.web.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.bigcustomer.corelog.api.KaCorelog;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogBusinessIdUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.BizOrderServiceErrorCode;
import com.jd.sns.biz.api.constant.KaLogConstants;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.InvoiceInfo;
import com.jd.sns.biz.api.service.BizOrderService;
import com.jd.sns.biz.api.service.OccupyStockBizOrderService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@org.springframework.stereotype.Controller
@RequestMapping("/api/order")
public class OrderController extends APIBaseController {
	private BizOrderService bizOrderService;
	private OccupyStockBizOrderService occupyStockBizOrderService;
	
	/**
	 * 预占库存的下订单接口(协议价，商品池，预占库存，不开发票)
	 * @param bizOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "submit", method = RequestMethod.POST)
	public @ResponseBody String submit(BizOrder bizOrder, InvoiceInfo invoiceInfo,HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		bizOrder.setIp(getRemoteIp(request));
		bizOrder.setPriceType(0);//协议价
		if(bizOrder.getPaymentType() == null){
			bizOrder.setPaymentType(12);
		}
		if(bizOrder.getIsUseBalance() == null){
			bizOrder.setIsUseBalance(0);
		}
		if(bizOrder.getSubmitState() == null){
			bizOrder.setSubmitState(0);//默认是预占库存下单方式
		}
		bizOrder.setPin(getPin(request));
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.submit", true, true);
		String result = occupyStockBizOrderService.submitOrder(bizOrder,invoiceInfo);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 给民生银行提供的submit2方法（预占库存京东价下单接口，在下单接口传发票参数（只有普票），发票随货）
	 * @param bizOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "submit2", method = RequestMethod.POST)
	public @ResponseBody String submit2(BizOrder bizOrder, InvoiceInfo invoiceInfo, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		bizOrder.setIp(getRemoteIp(request));
		bizOrder.setPriceType(1);//京东价
		if(bizOrder.getPaymentType() == null){
			bizOrder.setPaymentType(12);
		}
		if(bizOrder.getIsUseBalance() == null){
			bizOrder.setIsUseBalance(0);
		}
		if(bizOrder.getSubmitState() == null){
			bizOrder.setSubmitState(0);//默认是预占库存下单方式
		}
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.submit2", true, true);
		bizOrder.setPin(getPin(request));
		String result = occupyStockBizOrderService.submitOrder(bizOrder,invoiceInfo);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "jdPriceSubmit", method = RequestMethod.POST)
	public @ResponseBody String jdPriceSubmit(BizOrder bizOrder,  InvoiceInfo invoiceInfo,HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		bizOrder.setIp(getRemoteIp(request));
		bizOrder.setPriceType(1);//京东价
		if(bizOrder.getSubmitState() == null){
			bizOrder.setSubmitState(1);//京东价余额实物下单，默认是不占库存方式
		}
		if(bizOrder.getIsUseBalance() == null){
			bizOrder.setIsUseBalance(0);
		}
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.jdPriceSubmit", true, true);
		bizOrder.setPin(getPin(request));
		String result = occupyStockBizOrderService.submitOrder(bizOrder,invoiceInfo);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 预占库存类型订单确认下单接口
	 * @param bizOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "confirmOrder", method = RequestMethod.POST)
	public @ResponseBody String confirmOrder(String jdOrderId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.confirmOrder", true, true);
		LogTypeEnum.SUBMIT_ORDER_LOG.error("用户确认下单	订单号：{}",jdOrderId);
		KaCorelog.event(KaLogConstants.KA_LOG_KEY,jdOrderId,KaLogConstants.KA_LOG_BUSSINESS_CONFIRM_START,KaLogConstants.KA_LOG_CALLER,"业务标示ID:"+LogBusinessIdUtils.getCurBusinessId()+",调用确认下单接口confirmOrder.");
		String result = occupyStockBizOrderService.confirmOrder(jdOrderId);
		KaCorelog.event(KaLogConstants.KA_LOG_KEY,jdOrderId,KaLogConstants.KA_LOG_BUSSINESS_CONFIRM_END,KaLogConstants.KA_LOG_CALLER,"业务标示ID:"+LogBusinessIdUtils.getCurBusinessId()+",调用确认下单接口confirmOrder，返回："+result);
		Profiler.registerInfoEnd(info);
		return result;
	}
	/**
	 * 取消未确认预留库存订单接口
	 * @param jdOrderId
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "cancel", method = RequestMethod.POST)
	public @ResponseBody String cancel(String jdOrderId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.cancelJdOrder", true, true);
		LogTypeEnum.SUBMIT_ORDER_LOG.error("用户取消未确认订单	订单号：{}",jdOrderId);
		KaCorelog.event(KaLogConstants.KA_LOG_KEY,jdOrderId,KaLogConstants.KA_LOG_BUSSINESS_CANCEL_UNCONFRIM_START,KaLogConstants.KA_LOG_CALLER,"业务标示ID:"+LogBusinessIdUtils.getCurBusinessId()+",调用取消未确认订单接口cancel.");
		String result = occupyStockBizOrderService.cancel(jdOrderId);
		KaCorelog.event(KaLogConstants.KA_LOG_KEY,jdOrderId,KaLogConstants.KA_LOG_BUSSINESS_CANCEL_UNCONFRIM_END,KaLogConstants.KA_LOG_CALLER,"业务标示ID:"+LogBusinessIdUtils.getCurBusinessId()+",调用取消未确认订单接口cancel，返回："+result);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "selectJdOrder", method = RequestMethod.POST)
	public @ResponseBody String selectJdOrder(String jdOrderId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.selectJdOrder", true, true);
		String result = bizOrderService.selectJdOrder(jdOrderId);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 查询商品配送信息
	 * @param jdOrderId
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "orderTrack", method = RequestMethod.POST)
	public @ResponseBody String orderTrack(String jdOrderId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.orderTrack", true, true);
		String result = bizOrderService.orderTrack(jdOrderId);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 取消确认订单接口
	 * @param jdOrderId
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "cancelJdOrder", method = RequestMethod.POST)
	public @ResponseBody String cancelJdOrder(String jdOrderId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.cancelJdOrder", true, true);
		LogTypeEnum.SUBMIT_ORDER_LOG.error("用户取消已确认订单	订单号：{}",jdOrderId);
		KaCorelog.event(KaLogConstants.KA_LOG_KEY,jdOrderId,KaLogConstants.KA_LOG_BUSSINESS_CANCEL_CONFRIMED_START,KaLogConstants.KA_LOG_CALLER,"业务标示ID:"+LogBusinessIdUtils.getCurBusinessId()+",调用取消已确认订单接口cancelJdOrder.");
		String result = bizOrderService.cancelJdOrder(jdOrderId);
		KaCorelog.event(KaLogConstants.KA_LOG_KEY,jdOrderId,KaLogConstants.KA_LOG_BUSSINESS_CANCEL_CONFRIMED_END,KaLogConstants.KA_LOG_CALLER,"业务标示ID:"+LogBusinessIdUtils.getCurBusinessId()+",调用取消已确认订单接口cancelJdOrder，返回："+result);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 根据第三方订单编号查出企业有效订单
	 * 
	 * @param thirdOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "selectJdOrderListByThirdOrder", method = RequestMethod.POST)
	public @ResponseBody String selectJdOrderListByThirdOrder(String thirdOrder, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.selectJdOrderListByThirdOrder", true, true);
		String result = bizOrderService.selectJdOrderListByThirdOrder(thirdOrder);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 弃用掉
	 * @param thirdOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "selectJdOrderByThirdOrder", method = RequestMethod.POST)
	public @ResponseBody String selectJdOrderByThirdOrder(String thirdOrder, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.selectJdOrderListByThirdOrder", true, true);
		String result = bizOrderService.selectJdOrderListByThirdOrder(thirdOrder);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 根据thirdOrder获取下单时的订单ID
	 * @param thirdOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "selectJdOrderIdByThirdOrder", method = RequestMethod.POST)
	public @ResponseBody String selectJdOrderIdByThirdOrder(String thirdOrder, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.selectJdOrderIdByThirdOrder", true, true);
		String result = bizOrderService.selectBizOrderByThirdOrder(thirdOrder);

		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "doPay", method = RequestMethod.POST)
	public @ResponseBody String doPay(String jdOrderId) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.OrderController.doPay", false, true);
		try{
			long lJdOrderId = NumberUtils.toLong(jdOrderId, 0);
			if(lJdOrderId <= 0){
				BooleanResult result = new BooleanResult();
				result.setSuccess(false);
				result.setResult(false);
				result.setResultCode(BizOrderServiceErrorCode.CODE_PARAM_VALUE_ERROR);
				result.setResultMessage("jdOrderId格式错误或不合法");
				return APIUtils.parseObject2Json(result);
			}
			
			String result = bizOrderService.doPay(lJdOrderId);
			return result;
		}finally{
			Profiler.registerInfoEnd(info);
		}
	}

	public void setBizOrderService(BizOrderService bizOrderService) {
		this.bizOrderService = bizOrderService;
	}

	public void setOccupyStockBizOrderService(
			OccupyStockBizOrderService occupyStockBizOrderService) {
		this.occupyStockBizOrderService = occupyStockBizOrderService;
	}

}
