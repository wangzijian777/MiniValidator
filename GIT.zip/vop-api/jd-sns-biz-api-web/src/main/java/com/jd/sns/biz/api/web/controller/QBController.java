//package com.jd.sns.biz.api.web.controller;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import com.jd.sns.biz.api.common.utils.APIUtils;
//import com.jd.sns.biz.api.virtual.service.api.face.QBSafService;
//import com.jd.sns.biz.api.web.base.APIBaseController;
//import com.jd.ump.profiler.CallerInfo;
//import com.jd.ump.profiler.proxy.Profiler;
//
//@org.springframework.stereotype.Controller
//@RequestMapping("/api/qb")
//public class QBController extends APIBaseController {
//
//	@Autowired
//	private QBSafService qbSafService;
//
//	/**
//	 * @author dulingling 查询Q币售价
//	 * @return
//	 * @date 2014/6/13
//	 */
//	@RequestMapping(value = "getQBPrice", method = RequestMethod.POST)
//	public @ResponseBody
//	String getQBPrice(String facePrice, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.QBController.getQBPrice", true, true);
//		String result = qbSafService.queryQBPrice(facePrice, APIUtils.getClientId());
//		Profiler.registerInfoEnd(info);
//		return result;
//	}
//
//	/**
//	 * @author dulingling Q币下单
//	 * @return
//	 * @date 2014/6/13
//	 */
//	@RequestMapping(value = "qBOrder", method = RequestMethod.POST)
//	public @ResponseBody
//	String qBOrder(String thirdOrderId, String facePrice, String num, String salePrice, String qq, String mobile,
//			HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.QBController.qBOrder", true, true);
//		String result = qbSafService.submitQBOrder(thirdOrderId, facePrice, num, salePrice, qq, mobile,
//				request.getRemoteAddr(), APIUtils.getPin(), APIUtils.getClientId());
//		Profiler.registerInfoEnd(info);
//		return result;
//	}
//
//	/**
//	 * @author dulingling Q币订单查询(根据京东订单号)
//	 * @return
//	 * @date 2014/6/13
//	 */
//	@RequestMapping(value = "queryqbOrderByOrderId", method = RequestMethod.POST)
//	public @ResponseBody
//	String queryqbOrderByOrderId(String jdOrderId, HttpServletRequest request, HttpServletResponse response,
//			ModelMap context) {
//		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.QBController.queryqbOrderByOrderId", true, true);
//		String result = qbSafService.queryQBOrderByJdOrderid(APIUtils.getPin(), Long.valueOf(jdOrderId));
//		Profiler.registerInfoEnd(info);
//		return result;
//	}
//
//	/**
//	 * @author dulingling Q币订单查询（根据第三方订单号）
//	 * @return
//	 * @date 2014/6/13
//	 */
//	@RequestMapping(value = "queryqbOrderThirdId", method = RequestMethod.POST)
//	public @ResponseBody
//	String queryqbOrderByThirdId(String thirdOrderId, HttpServletRequest request, HttpServletResponse response,
//			ModelMap context) {
//		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.QBController.queryqbOrderByThirdId", true, true);
//		String result = qbSafService.queryQBOrderByThrOrderid(APIUtils.getPin(), thirdOrderId);
//		Profiler.registerInfoEnd(info);
//		return result;
//	}
//}
