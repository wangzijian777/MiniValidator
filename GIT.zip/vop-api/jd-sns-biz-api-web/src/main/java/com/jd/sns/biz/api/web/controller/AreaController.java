package com.jd.sns.biz.api.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.service.JdAreaService;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


@org.springframework.stereotype.Controller
@RequestMapping("/api/area")
public class AreaController extends APIBaseController {
	
//	private static final Logger log = LoggerFactory.getLogger(AreaController.class);
	
	private JdAreaService jdAreaService;
	
	/**
	 * 一级地址(省)
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "getProvince", method = RequestMethod.POST)
	public @ResponseBody String provinces(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.AreaController.provinces", true, true);
		Profiler.registerInfoEnd(info);
		return jdAreaService.getProvinces();
	}
	
	/**
	 * 二级地址(市)
	 * @param id
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "getCity", method = RequestMethod.POST)
	public @ResponseBody String cities(String id, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.AreaController.cities", true, true);
		String result = jdAreaService.getCitys(id);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 三级地址
	 * @param id
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "getCounty", method = RequestMethod.POST)
	public @ResponseBody String countys(String id, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.AreaController.countys", true, true);
		String result = jdAreaService.getCountys(id);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 四级地址
	 * @param id
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "getTown", method = RequestMethod.POST)
	public @ResponseBody String towns(String id, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.AreaController.towns", true, true);
		String result = jdAreaService.getTowns(id);
		Profiler.registerInfoEnd(info);
		return result;
	}
	

	public void setJdAreaService(JdAreaService jdAreaService) {
		this.jdAreaService = jdAreaService;
	}
	
}
