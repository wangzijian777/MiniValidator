package com.jd.sns.biz.api.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.service.BizOrderDifferenceService;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@org.springframework.stereotype.Controller
@RequestMapping("/api/difference")
public class BizOrderDifferenceController {
	
	private BizOrderDifferenceService bizOrderDifferenceService;
	
	@RequestMapping(value = "submit", method = RequestMethod.POST)
	public @ResponseBody String submit(String jdOrderId, String content, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizOrderDifferenceController.submit", true, true);
		Profiler.registerInfoEnd(info);
		return bizOrderDifferenceService.insertBizOrderDifference(jdOrderId, content);
	}

	public void setBizOrderDifferenceService(
			BizOrderDifferenceService bizOrderDifferenceService) {
		this.bizOrderDifferenceService = bizOrderDifferenceService;
	}
	
}
