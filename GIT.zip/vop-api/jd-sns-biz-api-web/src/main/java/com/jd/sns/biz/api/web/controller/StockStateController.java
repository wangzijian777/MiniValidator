package com.jd.sns.biz.api.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.service.StockStateService;
import com.jd.sns.biz.api.service.impl.StockStateServiceImpl;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@org.springframework.stereotype.Controller
@RequestMapping("/api/stock")
public class StockStateController {

	public static final String STOCK_APP_ID_BIG_CUSTOMER = "big_customer";
	public static final String STOCK_APP_ID_BIZAPI = "bizapi";
	private StockStateService stockStateService;
	
	@RequestMapping(value = "getStockById", method = RequestMethod.POST)
	public @ResponseBody String getStockById(String sku, String area, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.StockStateController.getStockById", true, true);
		String result = stockStateService.getStockByIds(sku, area);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "getNewStockById", method = RequestMethod.POST)
	public @ResponseBody String getNewStockById(String skuNums, String area,HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.StockStateController.getNewStockById", true, true);
		String result = stockStateService.getNewStockByIds(skuNums,area, STOCK_APP_ID_BIG_CUSTOMER);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "getFiveStockById", method = RequestMethod.POST)
	public @ResponseBody String getFiveStockById(String skuNums, String area) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.StockStateController.getFiveStockById", false, true);
		try{
			String result = stockStateService.getNewStockByIds(skuNums,area, STOCK_APP_ID_BIZAPI);
			return result;
		}finally{
			Profiler.registerInfoEnd(info);
		}
	}

	public void setStockStateService(StockStateService stockStateService) {
		this.stockStateService = stockStateService;
	}
	
	
}
