//package com.jd.sns.biz.api.web.controller;
//
//import java.util.List;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import com.jd.common.web.result.Result;
//import com.jd.sns.biz.api.domain.User;
//import com.jd.sns.biz.api.service.UserService;
//import com.jd.sns.biz.api.service.domain.ResultBase;
//import com.jd.sns.biz.api.web.base.APIBaseController;
//
//
//@org.springframework.stereotype.Controller
//@RequestMapping("/admin/user")
//public class UserController extends APIBaseController {
//	
//	private static final Logger log = LoggerFactory.getLogger(UserController.class);
//	
//	private UserService userService;
//	
//	@RequestMapping(value = "index", method = RequestMethod.GET)
//	public String index(User user, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		try{
//			Result result = new Result();
//			List list = userService.selectAllUser(user);
//			result.addDefaultModel("list", list);
//			result.addDefaultModel("user", user);
//			toVm(result, context, request);
//			return "/admin/user/index";
//		}catch (Exception e) {
//			log.error("", e);
//		}
//		return null;
//	}
//	
//	@RequestMapping(value = "detail", method = RequestMethod.GET)
//	public String detail(int id, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		try{
//			Result result = new Result();
//			User user = userService.getUserById(id);
//			result.addDefaultModel("user", user);
//			toVm(result, context, request);
//			return "/admin/user/detail";
//		}catch (Exception e) {
//			log.error("", e);
//		}
//		return null;
//	}
//	
//	@RequestMapping(value = "add", method = RequestMethod.GET)
//	public String add(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		return "/admin/user/add";
//	}
//	
//	@RequestMapping(value = "create", method = RequestMethod.POST)
//	public @ResponseBody ResultBase create(User user, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		try{
//			return userService.createUser(user);
//		}catch (Exception e) {
//			log.error("", e);
//		}
//		return null;
//	}
//	
//	@RequestMapping(value = "update", method = RequestMethod.POST)
//	public @ResponseBody ResultBase update(User user, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		try{
//			return userService.updateUser(user);
//		}catch (Exception e) {
//			log.error("", e);
//		}
//		return null;
//	}
//	
//	@RequestMapping(value = "delete", method = RequestMethod.POST)
//	public @ResponseBody ResultBase delete(int id, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		return  userService.delUser(id);
//	}
//
//	public void setUserService(UserService userService) {
//		this.userService = userService;
//	}
//
//	
//}
