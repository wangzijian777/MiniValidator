package com.jd.sns.biz.api.web.domain;

import java.util.List;


public class ReqServiceDetailInfoDto {
	private Long afsServiceId;
	private List<Integer> appendInfoSteps;
	public Long getAfsServiceId() {
		return afsServiceId;
	}
	public void setAfsServiceId(Long afsServiceId) {
		this.afsServiceId = afsServiceId;
	}
	public List<Integer> getAppendInfoSteps() {
		return appendInfoSteps;
	}
	public void setAppendInfoSteps(List<Integer> appendInfoSteps) {
		this.appendInfoSteps = appendInfoSteps;
	}
	
	
}
