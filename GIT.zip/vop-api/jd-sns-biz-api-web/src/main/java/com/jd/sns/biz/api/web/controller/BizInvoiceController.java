package com.jd.sns.biz.api.web.controller;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.domain.BizInvoice;
import com.jd.sns.biz.api.service.BizInvoiceService;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


@org.springframework.stereotype.Controller
@RequestMapping("/api/invoice")
public class BizInvoiceController extends APIBaseController {
	
//	private static final Logger log = LoggerFactory.getLogger(BizInvoiceController.class);
	
	private BizInvoiceService bizInvoiceService;
	
//	@RequestMapping(value = "submit", method = RequestMethod.POST)
	public @ResponseBody String submit(String invoicePrice, String invoiceNum, String settlementId, String settlementNum, String settlementPrice, String jdOrder, String markId, String invoiceType, String invoiceOrg, String bizInvoiceContent,String title, String invoiceDate, String repaymentDate, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizInvoiceController.submit", true, true);
		BooleanResult result = new BooleanResult();
		result.setSuccess(false);
		result.setResult(false);
		
		Profiler.registerInfoEnd(info);
		BizInvoice bizInvoice = new BizInvoice();
		bizInvoice.setClientId(APIUtils.getClientId());
		bizInvoice.setSettlementId(settlementId);
		bizInvoice.setJdOrder(jdOrder);
		bizInvoice.setMarkId(markId);
		try{
			bizInvoice.setInvoiceType(Integer.parseInt(invoiceType));
		}catch (Exception e) {
			result.setResultMessage("invoiceType格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		try{
			if(StringUtils.isNotBlank(invoicePrice)){
				bizInvoice.setInvoicePrice(new BigDecimal(invoicePrice));
			}
		}catch (Exception e) {
			result.setResultMessage("invoicePrice格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		try{
			if(StringUtils.isNotBlank(invoiceNum)){
				bizInvoice.setInvoiceNum(Integer.parseInt(invoiceNum));
			}
		}catch (Exception e) {
			result.setResultMessage("invoiceNum格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		try{
			if(StringUtils.isNotBlank(settlementNum)){
				bizInvoice.setSettlementNum(Integer.parseInt(settlementNum));
			}
		}catch (Exception e) {
			result.setResultMessage("settlementNum格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		try{
			if(StringUtils.isNotBlank(settlementPrice)){
				bizInvoice.setSettlementPrice(new BigDecimal(settlementPrice));
			}
		}catch (Exception e) {
			result.setResultMessage("settlementPrice格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		try{
			bizInvoice.setInvoiceOrg(Integer.parseInt(invoiceOrg));
		}catch (Exception e) {
			result.setResultMessage("invoiceOrg格式不正确");
			return APIUtils.parseObject2Json(result);
		}
		bizInvoice.setBizInvoiceContent(bizInvoiceContent);
		bizInvoice.setInvoiceDate(invoiceDate);
		bizInvoice.setTitle(title);
		bizInvoice.setRepaymentDate(repaymentDate);
		return bizInvoiceService.submit(bizInvoice);
	}
	
//	@RequestMapping(value = "select", method = RequestMethod.POST)
	public @ResponseBody String select(String markId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizInvoiceController.select", true, true);
		Profiler.registerInfoEnd(info);
		return bizInvoiceService.select(markId);
	}

	public void setBizInvoiceService(BizInvoiceService bizInvoiceService) {
		this.bizInvoiceService = bizInvoiceService;
	}

}
