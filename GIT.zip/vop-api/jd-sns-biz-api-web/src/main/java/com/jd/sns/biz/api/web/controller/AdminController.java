package com.jd.sns.biz.api.web.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.order.relation.export.domain.OrderInfoParam;
import com.jd.order.relation.export.domain.OrderInfoResult;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.dao.AdminDao;
import com.jd.sns.biz.api.dao.BizInvoiceDao;
import com.jd.sns.biz.api.dao.BizMessageDao;
import com.jd.sns.biz.api.dao.BizMessageTaskDao;
import com.jd.sns.biz.api.dao.BizOrderDao;
import com.jd.sns.biz.api.dao.BizOrderDifferenceDao;
import com.jd.sns.biz.api.dao.BizQuotaDao;
import com.jd.sns.biz.api.dao.DemandOrderDao;
import com.jd.sns.biz.api.domain.BizInvoice;
import com.jd.sns.biz.api.domain.BizMessage;
import com.jd.sns.biz.api.domain.BizMessageTask;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.BizOrderDifference;
import com.jd.sns.biz.api.domain.BizQuota;
import com.jd.sns.biz.api.domain.DemandOrder;
import com.jd.sns.biz.api.redis.JdCacheUtils;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.vertical.trade.sdk.export.OrderInfoExport;
import com.jd.vertical.trade.sdk.export.common.ClientInfo;

//@org.springframework.stereotype.Controller
//@RequestMapping("/admin/admin")
public class AdminController extends APIBaseController {

	private BizMessageDao bizMessageDao;
	private BizMessageTaskDao bizMessageTaskDao;
	private BizOrderDao bizOrderDao;
	private DemandOrderDao demandOrderDao;
	private JdCacheUtils redisUtils;
	private BizInvoiceDao bizInvoiceDao;
	private AdminDao adminDao;
	private BizOrderDifferenceDao bizOrderDifferenceDao;
	private OrderInfoExport orderInfoExport;
	private BizQuotaDao bizQuotaDao;

//	private static final Logger log = LoggerFactory
//			.getLogger(AdminController.class);

	// ----------------------------BizMessage------------start-----------------------------
//	@RequestMapping(value = "getMessageAll", method = RequestMethod.GET)
	public @ResponseBody
	String getMessageAll(BizMessage bizMessage, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try {
			ListResult listResult = new ListResult();
			listResult.setResult(bizMessageDao.getAll(bizMessage));
			return APIUtils.parseObject2Json(listResult);
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "1";
	}

	//	@RequestMapping(value = "updateMessageOne", method = RequestMethod.GET)
	public @ResponseBody
	String updateMessageOne(BizMessage bizMessage, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			return bizMessageDao.updateOne(bizMessage) + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error( e, "");
		}
		return "1";
	}

	//@RequestMapping(value = "insertMessageOne", method = RequestMethod.GET)
	public @ResponseBody
	String insertMessageOne(BizMessage bizMessage, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			bizMessage.setCreated(new Date());
			bizMessageDao.insertMessage(bizMessage);
			return "ok";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "1";
	}

	// ----------------------------BizMessage------------end-----------------------------

	// ----------------------------BizMessageTask------------start-----------------------------
	//@RequestMapping(value = "getMessageTaskAll", method = RequestMethod.GET)
	public @ResponseBody
	String getMessageTaskAll(int type, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			ListResult listResult = new ListResult();
			listResult.setResult(bizMessageTaskDao.getAll(type));
			return APIUtils.parseObject2Json(listResult);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "1";
	}

	//@RequestMapping(value = "updateMessageTaskOne", method = RequestMethod.GET)
	public @ResponseBody
	String updateMessageTaskOne(BizMessageTask bizMessageTask,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap context) {
		try{
			return bizMessageTaskDao.updateOne(bizMessageTask) + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "1";
	}

	//@RequestMapping(value = "insertMessageTaskOne", method = RequestMethod.GET)
	public @ResponseBody
	String insertMessageTaskOne(BizMessageTask bizMessageTask,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap context) {
		try{
			bizMessageTask.setCreated(new Date());
			bizMessageTaskDao.insertBizMessageTask(bizMessageTask);
			return "ok";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "");
		}
		return "1";
	}

	// ----------------------------BizMessageTask------------start-----------------------------

	//@RequestMapping(value = "redis", method = RequestMethod.GET)
	public @ResponseBody
	String redis(String key, int time, String value,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap context) {
		try {
//			redisUtils.setex(key, time, value);
			redisUtils.setStringByExpire(key, value, time, TimeUnit.SECONDS);
			return "ok";
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "exception";
	}
	
	//@RequestMapping(value = "chijiuredis", method = RequestMethod.GET)
	public @ResponseBody
	String chijiuredis(String key, int time, String value,
			HttpServletRequest request, HttpServletResponse response,
			ModelMap context) {
		try {
			redisUtils.set(key, value);
			return "ok";
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "exception";
	}

	//@RequestMapping(value = "getOrderAll", method = RequestMethod.GET)
	public @ResponseBody
	String getOrderAll(HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			ListResult listResult = new ListResult();
			listResult.setResult(bizOrderDao.getAll());
			return APIUtils.parseObject2Json(listResult);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e, "");
		}
		return "1";
	}

	//@RequestMapping(value = "getDemandAll", method = RequestMethod.GET)
	public @ResponseBody
	String getDemandAll(HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			ListResult listResult = new ListResult();
			listResult.setResult(demandOrderDao.getAll());
			return APIUtils.parseObject2Json(listResult);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "1";
	}

	//@RequestMapping(value = "updateJdOrderId", method = RequestMethod.GET)
	public @ResponseBody
	String updateJdOrderId(DemandOrder demandOrder, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			return demandOrderDao.updateJdOrderId(demandOrder) + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "1";
	}

	//@RequestMapping(value = "updateOneOrderState", method = RequestMethod.GET)
	public @ResponseBody
	String updateOneOrderState(BizOrder bizOrder, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			return bizOrderDao.updateOneOrderState(bizOrder) + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "1";
	}
	
	//@RequestMapping(value = "submitOrder", method = RequestMethod.GET)
	public @ResponseBody String submitOrder(BizOrder bizOrder, String submitOrderTimeString, String createOrderTimeString, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			bizOrder.setCreateOrderTime(sdf.parse(createOrderTimeString));
			bizOrder.setSubmitOrderTime(sdf.parse(submitOrderTimeString));
			bizOrderDao.submitOrder(bizOrder);
//			redisUtils.setex("order-"+bizOrder.getJdOrderId(), 60*60*24*30, "ok");
			redisUtils.setStringByExpire("order-"+bizOrder.getJdOrderId(), "ok", 60*60*24*30, TimeUnit.SECONDS);
			return "ok";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
		}
		return "1";
	}
	
	//@RequestMapping(value = "getRedisValue", method = RequestMethod.GET)
	public @ResponseBody String getRedisValue(String key, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			return redisUtils.get(key);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "getInvoiceAll", method = RequestMethod.GET)
	public @ResponseBody String getInvoiceAll(HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		try{
			ListResult result = new ListResult();
			List list = bizInvoiceDao.getAll();
			if(list == null){
				return "is null";
			}
			result.setResult(list);
			return APIUtils.parseObject2Json(result);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "updateTwoStateAndTime", method = RequestMethod.GET)
	public @ResponseBody String updateTwoStateAndTime(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			adminDao.updateCreateOrderTime();
			adminDao.updateInvoiceState();
			adminDao.updateSubmitState();
			return "OK";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "getBizOrderDifferenceAll", method = RequestMethod.GET)
	public @ResponseBody String getBizOrderDifferenceAll(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			ListResult result = new ListResult();
			result.setResult(bizOrderDifferenceDao.selectBizOrderDifferences(new BizOrderDifference()));
			return APIUtils.parseObject2Json(result);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "updateBizInvoiceState", method = RequestMethod.GET)
	public @ResponseBody String updateBizInvoiceState(BizInvoice bizInvoice, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			return bizInvoiceDao.updateBizInvoiceState(bizInvoice) + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "initUpdateYn", method = RequestMethod.GET)
	public @ResponseBody String initUpdateYn(BizInvoice bizInvoice, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			return bizMessageDao.initUpdateYn() + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "initUpdateYnByType", method = RequestMethod.GET)
	public @ResponseBody String initUpdateYnByType(BizInvoice bizInvoice, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			return bizMessageDao.initUpdateYnByType() + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "getLeafList", method = RequestMethod.GET)
	public @ResponseBody String getLeafList(long jdOrderId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			String result = "";
			OrderInfoResult orderInfoResult = null;
			Client client = ClientBuilder.newBuilder().build();
			WebTarget target = client.target("http://orderrelation.purchase.jd.local/service/findLeafOrders");
			OrderInfoParam param = new OrderInfoParam();
			param.setOrderId(jdOrderId);
			Response response1 = null;
			try {
				response1 = target.request().post(Entity.json(param));
				orderInfoResult = response1.readEntity(OrderInfoResult.class);
			} catch (Exception e) {
				LogTypeEnum.DEFAULT.error(e,"");
				throw new RuntimeException("查询拆分信息接口异常");
			} finally {
				close(response1, client);
			}
			
			if(orderInfoResult != null && orderInfoResult.getLeafOrders() != null && orderInfoResult.getLeafOrders().size() > 0){
				List<Long> leafList = orderInfoResult.getLeafOrders();
				if(leafList == null || leafList.size() == 0){
					return "leafList是空";
				}
				for(int j=0;j<leafList.size();j++){
					result = result + leafList.get(j) + ",";
				}
				return result;
			}else{
				return "orderInfoResult是空";
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "getOrderIdByOrderguid", method = RequestMethod.GET)
	public @ResponseBody String getOrderIdByOrderguid(String guid, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			ClientInfo clientInfo = new ClientInfo();
			clientInfo.setServerName("企销api");
			clientInfo.setClientIP("172.17.36.93");
			clientInfo.setOriginId(1);// 网站
			clientInfo.setBussinessType(100005);// 流程标示
			clientInfo.setWebOriginId(3);// 来自购物车页面，还是京东页面 1表示购物车,2表示订单,3是trade
			CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.ORDERINFOEXPORT_GETORDERID, false, true);
			com.jd.vertical.trade.sdk.export.order.result.OrderInfoResult result = orderInfoExport.getOrderId(guid, clientInfo);
			Profiler.registerInfoEnd(callerInfo);
			if(result == null || !result.isResultFlag() || result.getOrderId() <= 0){
				return "数据为空";
			}else{
				return result.getOrderId()+"";
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
		
	}
	
	//@RequestMapping(value = "insertBizQuota", method = RequestMethod.GET)
	public @ResponseBody String insertBizQuota(BizQuota bizQuota, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			this.bizQuotaDao.insert(bizQuota);
			return "OK";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
		
	}
	
	//@RequestMapping(value = "updateBizQuota", method = RequestMethod.GET)
	public @ResponseBody String updateBizQuota(BizQuota bizQuota, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			return this.bizQuotaDao.update(bizQuota) + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	//@RequestMapping(value = "deleteByClientId", method = RequestMethod.GET)
	public @ResponseBody String deleteByClientId(String clientId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		try{
			return this.bizMessageDao.deleteByClientId(clientId) + "";
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			return "exception";
		}
	}
	
	private void close(Response response, Client client) {
		response.close();
		client.close();
	}
	
	public void setBizMessageDao(BizMessageDao bizMessageDao) {
		this.bizMessageDao = bizMessageDao;
	}

	public void setBizMessageTaskDao(BizMessageTaskDao bizMessageTaskDao) {
		this.bizMessageTaskDao = bizMessageTaskDao;
	}

	public void setRedisUtils(JdCacheUtils redisUtils) {
		this.redisUtils = redisUtils;
	}

	public void setBizOrderDao(BizOrderDao bizOrderDao) {
		this.bizOrderDao = bizOrderDao;
	}

	public void setDemandOrderDao(DemandOrderDao demandOrderDao) {
		this.demandOrderDao = demandOrderDao;
	}

	public void setBizInvoiceDao(BizInvoiceDao bizInvoiceDao) {
		this.bizInvoiceDao = bizInvoiceDao;
	}

	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}

	public void setBizOrderDifferenceDao(BizOrderDifferenceDao bizOrderDifferenceDao) {
		this.bizOrderDifferenceDao = bizOrderDifferenceDao;
	}

	public void setOrderInfoExport(OrderInfoExport orderInfoExport) {
		this.orderInfoExport = orderInfoExport;
	}

	public void setBizQuotaDao(BizQuotaDao bizQuotaDao) {
		this.bizQuotaDao = bizQuotaDao;
	}

}
