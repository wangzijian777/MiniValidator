package com.jd.sns.biz.api.web.controller;

import java.util.Date;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.afs.saf.api.service.audit.AuditCancelProvider;
import com.jd.afs.saf.domain.base.OperatorInfoExport;
import com.jd.afs.saf.domain.base.ResultExport;
import com.jd.afs.saf.domain.service.audit.AuditCancelExport;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.JsonUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.service.AfterSaleService;
import com.jd.sns.biz.api.service.afs.dto.AfsServicebyCustomerPinPageDto;
import com.jd.sns.biz.api.service.afs.dto.CompatibleServiceDetailDTO;
import com.jd.sns.biz.api.service.afs.dto.facade.AfterSaleDto;
import com.jd.sns.biz.api.service.afs.dto.facade.AfterSaleSendInfoDto;
import com.jd.sns.biz.api.service.afs.dto.facade.ReqAfterSale;
import com.jd.sns.biz.api.service.domain.BeanResult;
import com.jd.sns.biz.api.service.domain.BooleanResult;
import com.jd.sns.biz.api.service.domain.IntegerResult;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.sns.biz.api.web.domain.ReqServiceDetailInfoDto;
import com.jd.sns.biz.api.web.domain.ReqServiceListPageDto;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
@Controller
@RequestMapping("api/afterSale")
public class AfterSaleController extends APIBaseController{
//    private static final Logger log = LoggerFactory.getLogger(AfterSaleController.class);
	private AfterSaleService afterSaleService;
	private AuditCancelProvider auditCancelProvider;
	/** vop系统调用售后接口平台号  **/
	private static final int AF_PLATFORM_SOURCE = 211;
	
	/**
	 * 取消服务单
	 * @param param
	 * @return
	 */
	@RequestMapping(value="auditCancel", method = RequestMethod.POST)
	public @ResponseBody BooleanResult auditCancel(String param){
		BooleanResult result=new BooleanResult();
		result.setSuccess(false);
		result.setResult(false);
		//参数转换
		AuditCancelExport  req = null;
		try{
			req = checkAuditCancelParam(param);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"参数校验没通过,param={}",param);
			result.setResultCode("6001");
			result.setResultMessage("参数格式不正确");
			return result;
		}
		//jsf接口调用
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.AFTERSALESERVICE_AUDITCANCEL, false, true);
		ResultExport<Integer> resultExport = null;
		try{
			resultExport= auditCancelProvider.auditCancel(req);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LogTypeEnum.DEFAULT.error(e,"auditCancel:");
			result.setResultCode("6000");
			result.setResultMessage("网络异常,请稍后重试");
			return result;
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		//返回值转换
		if(resultExport != null){
			if(resultExport.getResultCode() == 1){ //售后返回成功
				result.setSuccess(true);
				result.setResult(true);
			}else{ //售后返回失败
				result.setResultMessage(resultExport.getErrMsg());
			}
		}else{
			result.setResultMessage("取消售后服务单返回信息为空");
		}
		return result;
	}
	
	private AuditCancelExport  checkAuditCancelParam(String param){
		AuditCancelExport req = JsonUtils.readValue(param,AuditCancelExport.class);
		if(CollectionUtils.isEmpty(req.getServiceIdList())){
			throw new RuntimeException("服务单号集合为空");
		}
		if(StringUtils.isEmpty(req.getApproveNotes())){
			throw new RuntimeException("审核意见为空");
		}
		OperatorInfoExport op = new OperatorInfoExport();
		op.setOperatorPin(APIUtils.getPin());
		op.setOperatorNick(APIUtils.getPin());
		op.setOperatorDate(new Date());
		op.setPlatformSrc(AF_PLATFORM_SOURCE);
		req.setOperatorInfoExport(op);
		return req;
	}
	
	@RequestMapping(value="getAvailableNumberComp", method = RequestMethod.POST)
	public @ResponseBody IntegerResult getAvailableNumberComp(String param){
		LogTypeEnum.DEFAULT.debug("getAvailableNumberComp param="+param);
		IntegerResult result=new IntegerResult();
		ReqAfterSale req = null;
		try{
			req = JsonUtils.readValue(param,ReqAfterSale.class);
			req.setClientId(APIUtils.getClientId());
			req.setPin(APIUtils.getPin());
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			result.setSuccess(false);
			result.setResultCode("6001");
			result.setResultMessage("参数格式不正确");
			return result;
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.AFTERSALESERVICE_GETAVAILABLENUMBERCOMP, false, true);
		try{
			result=	afterSaleService.getAvailableNumberComp(req);
			Profiler.registerInfoEnd(callerInfo);
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"getAvailableNumberComp:");
			result.setSuccess(false);
			result.setResultCode("6000");
			result.setResultMessage("网络异常,请稍后重试");
			Profiler.functionError(callerInfo);
		}
		
		return result;
	}
	
	
	@RequestMapping(value="getCustomerExpectComp", method = RequestMethod.POST)
	public @ResponseBody ListResult getCustomerExpectComp(String param){
		LogTypeEnum.DEFAULT.debug("getCustomerExpectComp param={}",param);
		ListResult result=new ListResult();
		ReqAfterSale req = null;
		try{
			req = JsonUtils.readValue(param,ReqAfterSale.class);
			req.setClientId(APIUtils.getClientId());
			req.setPin(APIUtils.getPin());
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			result.setSuccess(false);
			result.setResultCode("6001");
			result.setResultMessage("参数格式不正确");
			return result;
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.AFTERSALESERVICE_GETCUSTOMEREXPECTCOMP, false, true);
		try{
			result= afterSaleService.getCustomerExpectComp(req);
			Profiler.registerInfoEnd(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"getCustomerExpectComp:");
			result.setSuccess(false);
			result.setResultCode("6000");
			result.setResultMessage("网络异常,请稍后重试");
			Profiler.functionError(callerInfo);
		}
		return result;
	}
	
	
	@RequestMapping(value="getWareReturnJdComp", method = RequestMethod.POST)
	public @ResponseBody ListResult getWareReturnJdComp(String param){
		LogTypeEnum.DEFAULT.debug("getWareReturnJdComp param={}",param);
		ListResult result=new ListResult();
		ReqAfterSale req = null;
		try{
			req = JsonUtils.readValue(param,ReqAfterSale.class);
			req.setClientId(APIUtils.getClientId());
			req.setPin(APIUtils.getPin());
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			result.setSuccess(false);
			result.setResultCode("6001");
			result.setResultMessage("参数格式不正确");
			return result;
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.AFTERSALESERVICE_GETWARERETURNJDCOMP, false, true);
		try{
			result= afterSaleService.getWareReturnJdComp(req);
			Profiler.registerInfoEnd(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"getWareReturnJdComp:");
			result.setSuccess(false);
			result.setResultCode("6000");
			result.setResultMessage("网络异常,请稍后重试");
			Profiler.functionError(callerInfo);
		}
		return result;
	}
	/**
	 * 
	 *服务单保存申请
	 *
	 * @Title createAfsApply
	 * @param strReq
	 * @return
	 * @author zhangyunyun@jd.com 2014-6-23 下午03:46:36
	 */
	@RequestMapping(value= "createAfsApply", method = RequestMethod.POST)
	public @ResponseBody ListResult createAfsApply(String param){
		LogTypeEnum.DEFAULT.debug("createAfsApply param={}",param);
		ListResult result=new ListResult();
		AfterSaleDto req = null;
		try{
			req = JsonUtils.readValue(param,AfterSaleDto.class);
			req.setClientId(APIUtils.getClientId());
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			result.setSuccess(false);
			result.setResultCode("6001");
			result.setResultMessage("参数格式不正确");
			return result;
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.AFTERSALESERVICE_CREATEAFSAPPLY, false, true);
		try{
			result= afterSaleService.createAfsApply(req);
			Profiler.registerInfoEnd(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"createAfsApply:");
			result.setSuccess(false);
			result.setResultCode("6000");
			result.setResultMessage("网络异常,请稍后重试");
		}
		return result;
	}
	
	/**
	 * 
	 * 填写发货信息
	 *
	 * @Title updateSendSku
	 * @param strReq
	 * @return
	 * @author zhangyunyun@jd.com 2014-6-23 下午03:46:21
	 */
	@RequestMapping(value= "updateSendSku", method = RequestMethod.POST)
	public @ResponseBody ListResult updateSendSku(String param){
		LogTypeEnum.DEFAULT.debug("updateSendSku param={}",param);
		ListResult result=new ListResult();
		
		AfterSaleSendInfoDto req = null;
		try{
			req = JsonUtils.readValue(param,AfterSaleSendInfoDto.class);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			result.setSuccess(false);
			result.setResultCode("6001");
			result.setResultMessage("参数格式不正确");
			return result;
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.AFTERSALESERVICE_UPDATESENDSKU, false, true);
		
		try{
			result= afterSaleService.updateSendSku(req);
			Profiler.registerInfoEnd(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"updateSendSku:");
			result.setSuccess(false);
			result.setResultCode("6000");
			result.setResultMessage("网络异常,请稍后重试");
			Profiler.functionError(callerInfo);
		}
		return result;
	}
	
	/**
	 * 
	 *  根据客户账号和订单号分页查询服务单概要信息
	 *
	 * @Title updateSendSku
	 * @param strReq
	 * @return
	 * @author zhangyunyun@jd.com 2014-6-23 下午03:48:44
	 */
	@RequestMapping(value="getServiceListPage" , method = RequestMethod.POST)
	public @ResponseBody BeanResult<AfsServicebyCustomerPinPageDto> getServiceListPage(String param){
		LogTypeEnum.DEFAULT.debug("getServiceListPage param={}",param);
		BeanResult<AfsServicebyCustomerPinPageDto> result=new BeanResult<AfsServicebyCustomerPinPageDto>();
		
		ReqServiceListPageDto req = null;
		try{
			req = JsonUtils.readValue(param,ReqServiceListPageDto.class);
			if(req==null){
				throw new IllegalArgumentException();
			}
			req.setClientId(APIUtils.getClientId());
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			result.setSuccess(false);
			result.setResultCode("6001");
			result.setResultMessage("参数格式不正确");
			return result;
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.JDPRODUCTSERVICE_QUERYPRODUCTBASE, false, true);
		try{
			result= afterSaleService.getServiceListPage(req.getClientId(), req.getJdOrderId(),
					req.getPageSize(),req.getPageIndex());
			Profiler.registerInfoEnd(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"getServiceListPage:");
			result.setSuccess(false);
			result.setResultCode("6000");
			result.setResultMessage("网络异常,请稍后重试");

			Profiler.functionError(callerInfo);
		}
		return result;
	}
	/**
	 * 根据服务单号，获取服务单明细
	 *
	 * @Title getServiceDetailInfo
	 * @param strReq
	 * @return
	 * @author zhangyunyun@jd.com 2014-6-23 下午04:00:14
	 */
	@RequestMapping(value= "getServiceDetailInfo", method = RequestMethod.POST)
	public @ResponseBody BeanResult<CompatibleServiceDetailDTO> getServiceDetailInfo(String param){
		LogTypeEnum.DEFAULT.debug("getServiceDetailInfo param={}",param);
		BeanResult<CompatibleServiceDetailDTO> result=new BeanResult<CompatibleServiceDetailDTO>();
		ReqServiceDetailInfoDto req=null;
		try{
			req = JsonUtils.readValue(param,ReqServiceDetailInfoDto.class);
			if(req==null){
				throw new IllegalArgumentException();
			}
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			result.setSuccess(false);
			result.setResultCode("6001");
			result.setResultMessage("参数格式不正确");
			return result;
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.AFTERSALESERVICE_GETSERVICEDETAILINFO, false, true);
		try{
			result= afterSaleService.getServiceDetailInfo(req.getAfsServiceId(),req.getAppendInfoSteps());
			Profiler.registerInfoEnd(callerInfo);
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"getServiceDetailInfo:");
			result.setSuccess(false);
			result.setResultCode("6000");
			result.setResultMessage("网络异常,请稍后重试");
			Profiler.functionError(callerInfo);
		}
		return result;
	}
	
	
	public void setAfterSaleService(AfterSaleService afterSaleService) {
		this.afterSaleService = afterSaleService;
	}

	public void setAuditCancelProvider(AuditCancelProvider auditCancelProvider) {
		this.auditCancelProvider = auditCancelProvider;
	}

}
