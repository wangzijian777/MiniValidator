package com.jd.sns.biz.api.web.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.constant.InvoiceUMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizDoInvoice;
import com.jd.sns.biz.api.service.DoInvoiceService;
import com.jd.sns.biz.api.service.InvoiceService;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * 增值税发票
 * 
 * @author shilun
 * 
 */

@Controller
@RequestMapping("/api/invoice")
public class InvoiceController extends APIBaseController {

	@Resource
	private InvoiceService invoiceService;
	@Resource
	private DoInvoiceService doInvoiceService;

	@RequestMapping(value = "view", method = RequestMethod.POST)
	public @ResponseBody
	String getInvoiceDetail(HttpServletRequest request) {
		String pin = getPin(request);
		return invoiceService.getInvoiceInfo(pin);
	}
	
	/**
	 * 申请开票
	 * @param bizDoInvoice
	 * @return
	 */
	@RequestMapping(value = "submit", method = RequestMethod.POST)
	public @ResponseBody String submitInvoice(BizDoInvoice bizDoInvoice){
		CallerInfo info = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.CONTROLLER_SUBMIT_INVOICE, true, true);
		String result = doInvoiceService.submitInvoice(bizDoInvoice);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 查询发票信息
	 * @param markId
	 * @return
	 */
	@RequestMapping(value = "select", method = RequestMethod.POST)
	public @ResponseBody String selectInvoice(String markId){
		CallerInfo info = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.CONTROLLER_SELECT_INVOICE, true, true);
		String result = doInvoiceService.selectInvoice(markId);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 发票提报取消
	 * @param markId
	 * @return
	 */
	@RequestMapping(value = "cancel", method = RequestMethod.POST)
	public @ResponseBody String cancel(String markId){
		CallerInfo info = Profiler.registerInfo(InvoiceUMPFunctionKeyConstant.CONTROLLER_CANCEL_INVOICE, true, true);
		String result = doInvoiceService.cancel(markId);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
}
