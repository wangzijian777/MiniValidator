package com.jd.sns.biz.api.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.domain.BizGiftcardOrder;
import com.jd.sns.biz.api.service.BizGiftcarOrderService;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@org.springframework.stereotype.Controller
@RequestMapping("/api/giftCard")
public class GiftcardOrderController extends APIBaseController {
//	private static final Logger log = LoggerFactory.getLogger(GiftcardOrderController.class);
	
	private BizGiftcarOrderService bizGiftcarOrderService;
	/**
	 * 购买礼品卡接口
	 * @param bizOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "buy", method = RequestMethod.POST)
	public @ResponseBody String buy(BizGiftcardOrder bizGiftcardOrder, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		bizGiftcardOrder.setIp(getRemoteIp(request));
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.GiftcardOrderController.buy", true, true);
		String result = bizGiftcarOrderService.buy(bizGiftcardOrder);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 查询接口
	 * @param bizOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "select", method = RequestMethod.POST)
	public @ResponseBody String select(String jdOrderId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.GiftcardOrderController.select", true, true);
		String result = bizGiftcarOrderService.selectGiftcardsByJdOrderId(jdOrderId);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 查询接口
	 * @param bizOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "selectByThirdOrder", method = RequestMethod.POST)
	public @ResponseBody String selectByThirdOrder(String thirdOrder, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.GiftcardOrderController.selectByThirdOrder", true, true);
		String result = bizGiftcarOrderService.selectJdOrderByThirdOrder(thirdOrder);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 礼品卡短信补发接口
	 * @param thirdOrder
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "sendSms", method = RequestMethod.POST)
	public @ResponseBody String sendSms(String jdOrderId, String mobile,HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		String pin = this.getPin(request);
		String clientId = this.getClient_id(request);
		String result = bizGiftcarOrderService.sendSms(jdOrderId,mobile,pin,clientId);
		return result;
	}
	

	public void setBizGiftcarOrderService(
			BizGiftcarOrderService bizGiftcarOrderService) {
		this.bizGiftcarOrderService = bizGiftcarOrderService;
	}


	
}
