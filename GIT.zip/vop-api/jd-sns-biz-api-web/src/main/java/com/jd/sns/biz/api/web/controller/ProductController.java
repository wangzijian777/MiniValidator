package com.jd.sns.biz.api.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.fastjson.JSON;
import com.jd.platform.saf.domain.yanbao.YanBaoRelations;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.entity.service.BizCommonQueryService;
import com.jd.sns.biz.api.enumtype.ErrorCodeEnum;
import com.jd.sns.biz.api.service.ProductService;
import com.jd.sns.biz.api.service.domain.ObjectResult;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@org.springframework.stereotype.Controller
@RequestMapping("/api/product")
public class ProductController extends APIBaseController {
	@Resource
	private BizCommonQueryService bizCommonQueryService;
	
	private ProductService productService;

	@RequestMapping(value = "getPageNum", method = RequestMethod.POST)
	public @ResponseBody String getPageNum(HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.ProductController.getPageNum", true, true);
		String result = productService.selectPageNumByClientId(getClient_id(request));
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "getSku", method = RequestMethod.POST)
	public @ResponseBody String getSku(String pageNum, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.ProductController.getSku", true, true);
		String result = productService.selectSkuIdsByClientIdAndPageNum(getClient_id(request), pageNum);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "getDetail", method = RequestMethod.POST)
	public @ResponseBody String getDetail(String sku, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.ProductController.getDetail", true, true);
		String result = productService.getDetail(sku);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "skuState", method = RequestMethod.POST)
	public @ResponseBody String skuState(String sku, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.ProductController.skuState", true, true);
		String result = productService.skuState(sku);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "skuImage", method = RequestMethod.POST)
	public @ResponseBody String skuImage(String sku, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.ProductController.skuImage", true, true);
		String result = productService.skuImage(sku);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	@RequestMapping(value = "getCommentSummarys", method = RequestMethod.POST)
	public @ResponseBody String getCommentSummarys(String sku, HttpServletRequest request,
			HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.ProductController.getCommentSummarys", true, true);
		String result = productService.getProductCommentSummarys(sku);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
    @RequestMapping(value = "checkAreaLimit", method = RequestMethod.POST)
    public @ResponseBody String checkAreaLimit(String skuIds, String province, String city, String county, String town, HttpServletRequest request,
            HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo(
				UMPFunctionKeyConstant.CHECK_AREAS_LIMIT, true, true);
		String clientId = APIUtils.getClientId();
		String result = bizCommonQueryService.checkSkusAreasLimit(skuIds,
				province, city, county, town, clientId);
		Profiler.registerInfoEnd(info);
		return result;
	}

	@RequestMapping(value = "getIsCod", method = RequestMethod.POST)
	public @ResponseBody String getIsCod(String skuIds, String province, String city, String county, String town) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.ProductController.getHuoDaoFuKuan", false, true);
		try{
			String result = productService.isSupportHuoDaoFuKuan(skuIds, province, city, county, town);
			return result;
		}finally{
			Profiler.registerInfoEnd(info);
		}
	}
	
	@RequestMapping(value = "getSkuGift", method = RequestMethod.POST)
	public @ResponseBody String getSkuGift(Long skuId, Integer province,Integer city,Integer county,Integer town) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.ProductController.getSkuGift", false, true);
		try{
			String result = productService.getSkuGift(skuId, province, city, county, town);
			return result;
		}finally{
			Profiler.registerInfoEnd(info);
		}
	}

	@RequestMapping(value = "getYanbaoSku", method = RequestMethod.POST)
	public @ResponseBody String getYanbaoSku(String skuIds) {
		ObjectResult result = new ObjectResult();
		if(StringUtils.isBlank(skuIds)){
			result.setResultCode(ErrorCodeEnum.PARAM_NULL.getType());
			result.setResultMessage(ErrorCodeEnum.PARAM_NULL.getTypeName());
			result.setSuccess(false);
			return JSON.toJSONString(result);
		}
		List<Long> skuList = new ArrayList<Long>();
		try{
			for (String skuStr : skuIds.split(",")) {
				skuList.add(Long.parseLong(skuStr));
			}
		}catch (Exception e){
			LogTypeEnum.DEFAULT.error(e, "转换sku出错", skuIds);
			result.setResultCode(ErrorCodeEnum.PARAM_FORMAT_ERROR.getType());
			result.setResultMessage(ErrorCodeEnum.PARAM_FORMAT_ERROR.getTypeName());
			result.setSuccess(false);
			return JSON.toJSONString(result);
		}
		
		// 测试sku133802l
		String yanBaoInfo = productService.getYanbaoSku(skuList);
		
		if(StringUtils.isBlank(yanBaoInfo)){
			result.setResultCode(ErrorCodeEnum.RETURN_NULL_VALUE.getType());
			result.setResultMessage(ErrorCodeEnum.RETURN_NULL_VALUE.getTypeName());
			result.setSuccess(false);
			return JSON.toJSONString(result);
		}
		
		result.setResultCode(ErrorCodeEnum.SUCCESS.getType());
		result.setResultMessage(ErrorCodeEnum.SUCCESS.getTypeName());
		result.setSuccess(true);
		result.setResult(JSON.parseObject(yanBaoInfo));
		return JSON.toJSONString(result);
	}
	
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

}
