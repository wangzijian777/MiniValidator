package com.jd.sns.biz.api.web.base;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.catagory.pbim.pbia.dubbo.service.ProductService;
import com.jd.common.util.StringUtils;
import com.jd.common.web.result.Result;
import com.jd.primitive.client.address.bean.AreaListBeanVO;
import com.jd.primitive.client.address.result.GetAreaListResultVO;
import com.jd.primitive.client.address.service.AreaService;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.common.utils.MD5Util;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.manager.BizPoolManager;
import com.jd.sns.biz.api.manager.BizPoolSkuManager;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.web.utils.HttpUtils;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

import commons.spring.mvc.controller.BaseController;



/**
 * @auth lsg
 * @version 1.0.0
 */
@org.springframework.stereotype.Controller
@RequestMapping("/sandbox")
public class TestController extends BaseController {
	@Resource
	private AreaService areaService;
	@Resource
	private ProductService jdProductService;
	@Resource(name="productService")
	private com.jd.sns.biz.api.service.ProductService productService;
	@Resource
	private BizPoolSkuManager bizPoolSkuManager;
	
	private static String KEY = "73A1FF014F78EDC194C99EB37ACFF3DF";
	
//	@RequestMapping(value = "login", method = RequestMethod.GET)
	public String login(User user, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		String client_id = "client_id_1";
		String redirect_uri = "http://bizapi.jd.com/sandbox/callback";
		String response_type = "code";
		try {
			response.sendRedirect("http://bizapi.jd.com/oauth2/authorize?client_id="+client_id+"&redirect_uri="+redirect_uri+"&response_type="+response_type);
			return null;
		} catch (Exception e) {
		}
		
		return "test";
	}
	
	@RequestMapping(value = "callback/{key}", method = RequestMethod.GET)
	public String callback(String code, HttpServletRequest request, HttpServletResponse response, ModelMap context, @PathVariable String key) {
		
		if(StringUtils.isBlank(key) || !KEY.equals(key)){
			return "error";
		}
		
		Result result = new Result();
		result.addDefaultModel("code", code);
		toVm(result, context, request);
		return "/login/callback";
	}
	
//	@RequestMapping(value = "getToken", method = RequestMethod.POST)
	public @ResponseBody String getToken(String code, User user, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		System.out.print("aaa");
        return HttpUtils.httpPostData("http://bizapi.jd.com/oauth2/access_token", "code="+code+"&client_id="+user.getClient_id()+"&client_secret="+user.getClient_secret()+"&grant_type="+user.getGrant_type()+"&redirect_uri="+user.getRedirect_uri(), null);
	}
	
//	@RequestMapping(value = "codCheck", method = RequestMethod.POST)
	public @ResponseBody String addrcCODCheck(Integer provinceId,Integer cityId,Integer countyId,Integer townId,HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		StringBuilder sb=new StringBuilder();
		if(townId!=null && !townId.equals(0)){
			 GetAreaListResultVO result=areaService.getTowns(countyId);
			 CODCheckResult(sb, result);			
		}else if(countyId!=null && !countyId.equals(0)){
			 GetAreaListResultVO result=areaService.getCountys(cityId);
			 CODCheckResult(sb, result);			
		}else if(cityId!=null && !cityId.equals(0)){
			 GetAreaListResultVO result=areaService.getCitys(provinceId);
			 CODCheckResult(sb, result);			
		}else{
			 GetAreaListResultVO result=areaService.getProvinces();
			 CODCheckResult(sb, result);			
		}
		return sb.toString();
	}
	
//	@RequestMapping(value = "skuCODCheck", method = RequestMethod.POST)
	public @ResponseBody String skuCODCheck(Long skuId,Integer townId,HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		StringBuilder sb=new StringBuilder();
		if(skuId!=null){
			Set<Long> skus=new HashSet<Long>();
			skus.add(skuId);
			//获取商品基本信息
			Set<String> base=new HashSet<String>();
			base.add("valuePayFirst");
			Map<Long, Map<String, String>> skuBaseMap=null;
			try {
				skuBaseMap=jdProductService.queryProductBase(skus, base);
			} catch (Exception e) {
				sb.append("查询商品基本属性失败，sku="+skuId).append(" ");
				return sb.toString();
			}
			if(skuBaseMap!=null && !skuBaseMap.isEmpty()){
				Map<String, String> map=skuBaseMap.get(skuId);
				sb.append("商品基本属性：").append(APIUtils.parseObject2Json(map)).append(" ");
			}else{
				sb.append("未获取到商品基本属性，sku="+skuId+" ");
			}
			//获取商品扩展信息
			Set<String> extend=new HashSet<String>();
			extend.add("factoryShip");
			extend.add("LuxuryGoods");
			extend.add("highValueGoods");
			Map<Long, Map<String, String>> skuExtMap;
			try {
				skuExtMap = jdProductService.queryExtend(skus, extend);
			} catch (Exception e) {
				sb.append("查询商品扩展属性失败，sku="+skuId).append(" ");
				return sb.toString();
			}
			if(skuExtMap!=null && !skuExtMap.isEmpty()){
				Map<String, String> map=skuExtMap.get(skuId);
				sb.append("商品扩展属性：").append(APIUtils.parseObject2Json(map)).append(" ");
			}else{
				sb.append("未获取到商品扩展属性，sku="+skuId);
			}
		}
		return sb.toString();
	}
	

	private void CODCheckResult(StringBuilder sb, GetAreaListResultVO result) {
		List<AreaListBeanVO> areaList=result.getAreaList();
			if(CollectionUtils.isNotEmpty(areaList)){
				for(AreaListBeanVO e:areaList){
					if(!e.isCod()){
						sb.append("id:"+e.getId()+e.getName()+"【不支持】货到付款 ");
					}else{
						sb.append("id:"+e.getId()+e.getName()+"【支持】货到付款 ");
					}
				}
			}
	}
	
	
		public static void main(String[] args) throws UnsupportedEncodingException {
			String username = "天津BHYH";
			System.out.println(URLEncoder.encode("天津BHYH", "utf-8"));
			String enCodeName = URLEncoder.encode(username, "utf-8");
			String password = "123456";
			System.out.println(MD5Util.getMD5Str(password));
			password = MD5Util.getMD5Str(password);
			String timestamp = "2015-06-15 10:34:44";
			String clientSecret="v0ml6bPY93j04Yxisn5B";
			String clientId="bohaibank";
			String sign = clientSecret + timestamp + clientId+ username + password + "access_token" + clientSecret;
			System.out.println("sign="+sign);
			sign = MD5Util.getMD5Str(sign).toUpperCase();
			System.out.println("sign="+sign);
			String url = "http://bizapi.jd.com/oauth2/access_token";
			String data =
			"grant_type=access_token" +
			"&client_id=" +clientId+
			"&username=" + enCodeName +
			"&password=" + password +
			"&timestamp=" + timestamp +
			"&sign="+sign;
			String rev = HttpUtils.httpPostData(url, data, null);
			System.out.println(rev);
			}
	
	/***** 商品池服务测试 by wy ******/
	/**
	 * 通过client_id查询商品池列表
	 * @param skuId
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
//	@RequestMapping(value = "getPoolsByClientId", method = RequestMethod.POST)
	public @ResponseBody String getPoolsByClientId(String clientId,HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		return productService.selectPageNumByClientId(clientId);
	}
	/**
	 * 通过clientId和poolId获取商品池商品；
	 * @param clientId
	 * @param poolId
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
//	@RequestMapping(value = "getSkusByClientIdAndPoolId", method = RequestMethod.POST)
	public @ResponseBody String getSkusByClientIdAndPoolId(String clientId,String poolId,HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		return productService.selectSkuIdsByClientIdAndPageNum(clientId, poolId);
	}
	/**
	 * 判断客户是否可以购买该skuId
	 * @param clientId
	 * @param skuId
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 * @throws Exception
	 */
//	@RequestMapping(value = "checkSkuClientCanBuy", method = RequestMethod.POST)
	public @ResponseBody String checkSkuClientCanBuy(String clientId,long skuId,HttpServletRequest request, HttpServletResponse response, ModelMap context) throws Exception {
		MapResult result = new MapResult();
		result.setSuccess(false);
		if(bizPoolSkuManager.checkSkuIdExistByClientID(clientId, skuId) <= 0){
			result.setSuccess(false);
			result.setResultMessage("您的商品池中，没有该商品信息！");			
		}else{
			result.setSuccess(true);
			result.setResultMessage("您的商品池中，存在该商品！");
		}
		return APIUtils.parseObject2Json(result);
	}
	/**
	 * 判断商品是否为大客户商品
	 * @param skuId
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 * @throws Exception
	 */
//	@RequestMapping(value = "checkIsBigClientSku", method = RequestMethod.POST)
	public @ResponseBody String checkIsBigClientSku(long skuId,HttpServletRequest request, HttpServletResponse response, ModelMap context) throws Exception {
		MapResult result = new MapResult();
		result.setSuccess(false);
		if(bizPoolSkuManager.checkSkuIdExist(skuId) <= 0){
			result.setSuccess(false);
			result.setResultMessage("商品不是大客户商品！");			
		}else{
			result.setSuccess(true);
			result.setResultMessage("商品是大客户商品！");
		}
		return APIUtils.parseObject2Json(result);
	}
	/**
	 * 根据商家id判断有哪些商家可以购买该商品
	 * @param skuId
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 * @throws Exception
	 */
//	@RequestMapping(value = "getClientIdsBySku", method = RequestMethod.POST)
	public @ResponseBody String getClientIdsBySku(long skuId,HttpServletRequest request, HttpServletResponse response, ModelMap context) throws Exception {
		ListResult result = new ListResult();
		try{
			List list = bizPoolSkuManager.getClientIdsBySkuId(skuId);
			if(list == null || list.size() == 0){
				result.setSuccess(false);
				result.setResultMessage("通过商品未属于任何商品池！");
				return APIUtils.parseObject2Json(result);
			}
			result.setResult(list);
			result.setSuccess(true);
		}catch (Exception e) {
			result.setSuccess(false);
			result.setResultMessage("服务异常，请稍后重试");
		}
		return APIUtils.parseObject2Json(result);
	}	
	
//	@RequestMapping(value = "getProductAreaLimit", method = RequestMethod.POST)
	public @ResponseBody String getProductAreaLimit(long skuId,HttpServletRequest request, HttpServletResponse response, ModelMap context){
		Set<Long> set=new HashSet<Long>();
		set.add(skuId);
		Map<Long, List<String>> map=productService.getProductAreaLimit(set);
		return APIUtils.parseObject2Json(map);
	}
	
//	@RequestMapping(value = "getProductName", method = RequestMethod.POST)
	public @ResponseBody String getProductName(long skuId,HttpServletRequest request, HttpServletResponse response, ModelMap context) throws Exception {
		return productService.getProductName(skuId);
	}
	
}
