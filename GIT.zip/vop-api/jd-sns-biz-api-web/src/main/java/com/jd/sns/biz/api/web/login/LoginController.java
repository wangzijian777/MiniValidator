package com.jd.sns.biz.api.web.login;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.common.web.result.Result;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.ApiConstants;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.service.domain.MapResult;
import com.jd.sns.biz.api.service.login.LoginService;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;



/**
 * @auth lsg
 * @version 1.0.0
 */
@org.springframework.stereotype.Controller
@RequestMapping("/oauth2")
public class LoginController extends APIBaseController {
	
//	private static final Logger log = LoggerFactory.getLogger(LoginController.class);
	
	private LoginService loginService;
	
	@RequestMapping(value = "authorize", method = RequestMethod.GET)
	public String authorize(User user, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		user.setIp(getRemoteIp(request));
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.LoginController.authorize", true, true);
		Result result = loginService.checkLoginParam(user);
		Profiler.registerInfoEnd(info);
		toVm(result, context, request);
		if(result.isSuccess()){
			return "/login/login";
		}
		return "/login/paramError";
	}
	
	@RequestMapping(value = "loginService", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> loginService(User user, String loginname, String loginpwd,  HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		Map<String, Object> root = new HashMap<String, Object>();
		try{
			user.setIp(getRemoteIp(request));
			Result result = loginService.checkLoginParam(user);
			if(!result.isSuccess()){
				root.put("result", result.getResultCode());
				root.put("success", "false");
				return root;
			}
			CallerInfo info = Profiler.registerInfo("web.sns.bizapi.LoginController.loginService", true, true);
			result = loginService.loginService(loginname, loginpwd, result, getRemoteIp(request));
			if(!result.isSuccess() || !ApiConstants.returnValue.OK.equals(result.getResultCode())){
				root.put("result", result.getResultCode());
				return root;
			}
			Profiler.registerInfoEnd(info);
			root.put("success", true);
			root.put("url", user.getRedirect_uri()+"?code="+loginService.getAuthorizationCode(loginname)+"&state="+user.getState());
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			root.put("success", false);
		}
		return root;
	}
	
	@RequestMapping(value = "access_token", method = RequestMethod.POST)
	public @ResponseBody String token(User user, String code, String sign, String username, String password, String timestamp, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		Map<String, Object> root = new HashMap<String, Object>();
		try{
			CallerInfo info = Profiler.registerInfo("web.sns.bizapi.LoginController.access_token.code", true, true);
			Profiler.registerInfoEnd(info);
			if("access_token".equals(user.getGrant_type())){
				MapResult mapResult = loginService.getToken(user, username, password, getRemoteIp(request), sign, timestamp);
				return APIUtils.parseObject2Json(mapResult);
			}else{
				Result result = loginService.getToken(user, code);
				
				if(result.isSuccess() && ApiConstants.returnValue.OK.equals(result.getResultCode())){
					root = (Map<String, Object>)result.get("token");
					return APIUtils.parseObject2Json(root);
				}else{
					root.put("error_description", result.getResultCode());
				}
			}
			
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			root.put("error_description", "exception");
		}
		return APIUtils.parseObject2Json(root);
	}
	
	@RequestMapping(value = "refresh_token", method = RequestMethod.POST)
	public @ResponseBody String refreshToken(String client_id, String client_secret, String refresh_token, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		Map<String, Object> root = new HashMap<String, Object>();
		try{
			CallerInfo info = Profiler.registerInfo("web.sns.bizapi.LoginController.refreshToken", true, true);
			Result result = loginService.refreshToken(client_id, client_secret, refresh_token);
			if(result.isSuccess()){
				root = (Map<String, Object>)result.get("token");
				return APIUtils.parseObject2Json(root);
			}
			Profiler.registerInfoEnd(info);
			root.put("error_description", result.getResultCode());
		}catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"");
			root.put("error_description", "exception");
		}
		return APIUtils.parseObject2Json(root);
	}

	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}
	
}
