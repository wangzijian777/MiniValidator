package com.jd.sns.biz.api.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.service.JdPriceService;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.sns.biz.common.enumtype.PaymentType;
import com.jd.sns.biz.pay.enumtype.PayTypeEnum;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


@org.springframework.stereotype.Controller
@RequestMapping("/api/price")
public class PriceController extends APIBaseController {
	
//	private static final Logger log = LoggerFactory.getLogger(PriceController.class);
	
	private JdPriceService jdPriceService;
	
//	/**
//	 * 单个查询价格
//	 * @param skuid
//	 * @param area
//	 * @param request
//	 * @param response
//	 * @param context
//	 * @return
//	 */
//	@RequestMapping(value = "single", method = RequestMethod.POST)
//	public @ResponseBody String single(String skuid, String area, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		return jdPriceService.single(skuid, area);
//	}
	
//	@RequestMapping(value = "getPrice", method = RequestMethod.POST)
//	public @ResponseBody String getPrice(String skuids, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
//		return "";
//	}
	
	/**
	 * 批量查询协议价格和京东价（包含商品池）
	 * @param skuid
	 * @param area
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "getPrice", method = RequestMethod.POST)
	public @ResponseBody String getPrice(String sku, String containsTax, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.PriceController.getPrice", true, true);
		String result = jdPriceService.batch(sku, containsTax);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 批量查询京东价格（包含商品池）
	 * @param skuid
	 * @param area
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "getJdPrice", method = RequestMethod.POST)
	public @ResponseBody String getJdPrice(String sku, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.PriceController.getJdPrice", true, true);
		String result = jdPriceService.jdPriceBatchFromPool(sku);
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 查询用户余额
	 * @return
	 */
	@RequestMapping(value = "selectBalance", method = RequestMethod.POST)
	public @ResponseBody String selectBalance(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.PriceController.selectBalance", true, true);
		String result = jdPriceService.selectBalance(APIUtils.getPin(), PayTypeEnum.BALANCE.getType());
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 查询金彩额度
	 * @return
	 */
	@RequestMapping(value = "selectCreditLimit", method = RequestMethod.POST)
	public @ResponseBody String selectCreditLimit(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.PriceController.selectBalance", true, true);
		String result = jdPriceService.selectBalance(APIUtils.getPin(),PayTypeEnum.JINCAI.getType());
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 查询网银钱包额度
	 * @return
	 */
	@RequestMapping(value = "selectWalletLimit", method = RequestMethod.POST)
	public @ResponseBody String selectWalletLimit(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.PriceController.selectBalance", true, true);
		String result = jdPriceService.selectBalance(APIUtils.getPin(),PayTypeEnum.WALLET.getType());
		Profiler.registerInfoEnd(info);
		return result;
	}
	
	/**
	 * 查询金彩额度
	 * @return
	 */
	@RequestMapping(value = "selectJincaiCredit", method = RequestMethod.POST)
	public @ResponseBody String selectJincaiCredit(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.PriceController.selectJincaiCredit", true, true);
		String result = jdPriceService.getJincaiCredit(APIUtils.getPin());
		Profiler.registerInfoEnd(info);
		return result;
	}

	public void setJdPriceService(JdPriceService jdPriceService) {
		this.jdPriceService = jdPriceService;
	}
	

	
}
