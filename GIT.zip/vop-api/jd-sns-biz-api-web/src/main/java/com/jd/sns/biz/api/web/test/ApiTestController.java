package com.jd.sns.biz.api.web.test;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.common.web.result.Result;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.biz.api.web.utils.HttpUtils;
import commons.spring.mvc.controller.BaseController;



/**
 * @auth lsg
 * @version 1.0.0
 */
@org.springframework.stereotype.Controller
//@RequestMapping("/api")
public class ApiTestController extends BaseController {
	
	//	@RequestMapping(value = "login", method = RequestMethod.GET)
	public String login(String token, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		Result result = new Result();
		result.addDefaultModel("token", token);
		toVm(result, context, request);
		return "apitest";
	}
	
	//	@RequestMapping(value = "test", method = RequestMethod.GET)
	public @ResponseBody String test(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		String result = HttpUtils.httpGetData("http://bizapi.jd.com/admin/admin/getOrderAll", "", null);
		ListResult listResult = APIUtils.parseJson2Object(result, ListResult.class);
		List<BizOrder> list = listResult.getResult();
		String html = "<table><tr><td>订单号</td><td>价格</td></tr>";
		for(int i=0;i<list.size();i++){
			BizOrder bizOrder = list.get(i);
			if(bizOrder.getOrderState() == 1 && bizOrder.getType() == 2){
				html+="<tr><td>"+bizOrder.getJdOrderId()+"</td><tr>"+bizOrder.getOrderPrice()+"</td></tr>";
			}
		}
		html += "</table>";
		return html;
	}
	
}
