package com.jd.sns.biz.api.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.service.BizOrderFlowService;
import com.jd.sns.biz.api.web.base.APIBaseController;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


@org.springframework.stereotype.Controller
@RequestMapping("/api/hangUp")
public class BizOrderFlowController extends APIBaseController {
	
//	private static final Logger log = LoggerFactory.getLogger(BizOrderFlowController.class);
	
	private BizOrderFlowService bizOrderFlowService;
	
	@RequestMapping(value = "submit", method = RequestMethod.POST)
	public @ResponseBody String submit(String jdOrderId, String workType, String workInfo, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizOrderFlowController.submit", true, true);
		Profiler.registerInfoEnd(info);
		return bizOrderFlowService.submit(jdOrderId, workType, workInfo);
	}
	
	@RequestMapping(value = "select", method = RequestMethod.POST)
	public @ResponseBody String select(String jdOrderId, String workInfo, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizOrderFlowController.select", true, true);
		Profiler.registerInfoEnd(info);
		return bizOrderFlowService.select(jdOrderId);
	}
	
	@RequestMapping(value = "cancel", method = RequestMethod.POST)
	public @ResponseBody String cancel(String jdOrderId, HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizOrderFlowController.cancel", true, true);
		Profiler.registerInfoEnd(info);
		return bizOrderFlowService.cancel(jdOrderId);
	}

	public void setBizOrderFlowService(BizOrderFlowService bizOrderFlowService) {
		this.bizOrderFlowService = bizOrderFlowService;
	}

}
