package com.jd.sns.biz.api.web.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.sns.biz.api.service.BizJincaiQueryService;
import com.jd.sns.biz.api.web.base.APIBaseController;

@org.springframework.stereotype.Controller
@RequestMapping("/api/payment")
public class PaymentController extends APIBaseController {
	@Resource
	private BizJincaiQueryService bizJincaiQueryService;
	
	/**
	 * 查询金采授信额度
	 * @param request
	 * @param response
	 * @param context
	 * @return
	 */
	@RequestMapping(value = "queryCreditLimit", method = RequestMethod.POST)
	public @ResponseBody String queryCreditLimit(HttpServletRequest request, HttpServletResponse response, ModelMap context) {
		String pin = this.getPin(request);
		String result = bizJincaiQueryService.queryCreditLimit(pin);
		return result;
	}
	

}
