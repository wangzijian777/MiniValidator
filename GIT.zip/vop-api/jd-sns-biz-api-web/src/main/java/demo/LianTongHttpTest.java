package demo;

import com.jd.sns.biz.api.common.utils.HttpUtils;


public class LianTongHttpTest {
	public static void main(String[] args) {
		//添加需求单
	
//		String oauth = "http://bizapi.jd.com/oauth2/access_token?client_id=XwI1spoB77&client_secret=igiiLoYU7w&redirect_uri=http://jd.eshop.unicom.local/ishop/index.jsp&username=yujianming&password="+MD5Util.md5Hex("asd123")+"&grant_type=access_token";
//		System.out.println(HttpUtils.httpPostData(oauth, null, null));
		
		
//		联通的access_token U724OeF3dwTZFeAWyZTdZPTOp
//		String oauth = "http://bizapi.jd.com/oauth2/access_token?client_id=XwI1spoB77&client_secret=igiiLoYU7w&grant_type=authorization_code&code=tVEuuiAoqSGAliRr8yuE5G2JC&redirect_uri=http://jd.eshop.unicom.local/ishop/index.jsp";
//		System.out.println(HttpUtils.httpPostData(oauth, null, null));
		
//		联通的refresh_token  gJUNwNcBgCa5FXXuV4i2uAPvq17l8MEyMFGcerMT
		String oauth = "http://bizapi.jd.com/oauth2/refresh_token?client_id=XwI1spoB77&client_secret=igiiLoYU7w&refresh_token=gJUNwNcBgCa5FXXuV4i2uAPvq17l8MEyMFGcerMT";
		System.out.println(HttpUtils.httpPostData(oauth, null, null));
		
//		String skuDetail = "http://bizapi.jd.com/api/product/getDetail?sku=779651&token=wwESXbfJm97aAt5AZ4DaBgBR8";
//		String result = HttpUtils.httpPostData(skuDetail, null, null);
//		System.out.println(result);
		
		
		//系统测试的 refresh_token:3toIZos4yvoobYuoe70wv1wNyvFSGk7SEvpiNKmb
//		access_token:z5sQu0ECVuR8jHSK9I5k4s0Jj
//		String access_token = "http://bizapi.jd.com/oauth2/access_token?code=WME8MHA78l3YGsX78NcAw4HA8&grant_type=authorization_code&client_id=client_id_1&client_secret=ImYfgbonR9LX2wQvVOIL&redirect_uri=http%3A%2F%2Fbizapi.jd.com%2Ftest%2Fcallback&refresh_token=BwZdRPLT6fj3UPuAa2ztIg5oMM3Lcci2PoNyYRXM";
//		System.out.println(HttpUtils.httpPostData(access_token, null, null));
		
		
		  
//		String a = "http://bizapi.jd.com/api/order/submitOrder?zip=250100&phone=0531-8888888&jdDemandOrder=1000027&sku=[{\"skuId\":423478, \"num\":1}]&city=1000&thirdOrder=jdsd-20131106164753316&email=111@163.com&token=dhGqjUpUenOXGHel9wq8IdBsz&county=40488&address=华能路87号&name=收货人&province=13&town=40548&mobile=15169166337";
//		System.out.println(HttpUtils.httpPostData(a, null, null));;
//		String a = "http://bizapi.jd.com/api/order/submitOrder?thirdOrder=jdsd-20131106164753316&jdDemandOrder=1000027&sku=[{\"id\":423478,\"num\":1}]}&name=于建明&province=1&city=72&county=2839&address=阿斯达按时啊四大四大四大按时大大&zip=10000&phone=010-52315213&mobile=13333333333&email=21312@jd.com&token=dhGqjUpUenOXGHel9wq8IdBsz";
//		System.out.println(HttpUtils.httpPostData(a, null, null));
		
//		String b = "http://bizapi.jd.com/oauth2/access_token?grant_type=authorization_code&client_id=OusAjBrUwm&client_secret=46tkw6u2bM&redirect_uri=http://ecsaletest.19e.cn/ecsale/jdToken_getJdCode.action&code=hSTivBuYHUNHu4YZViDBljsrO";
//		System.out.println(HttpUtils.httpPostData(b, null, null));
		
//		String b = "http://bizopen.jd.com/phoneRecharge/selectPricet.rest?accessToken=ef61c263be7f593950b363ab9fc7d782f2192bd15aeafc8a00afd090d166b7601ff482a8a96e02896ed3d9fb7e6053abdf8c9ba83c58d06f94c2502834829deda0ea092465deeca50d5d946633e368b6233dc34b0c6ec9236774307ebb6ff7a484f8583fb7cdc69af600e6b0e66933379a81ac0deec83e3cf9f838eae296f8e8295b03f7a0729e3ad52850d42e63efbe8e0d6cf7e1eb0ea2a21519db0af599333cb750dfdd8b04741b12d732a0595a8f63c52b3434386152ee52a48699a414cbf575e6475c27bedacd5b2241f442956e6d48c40e7dbedf77dfa0cab45d8a17b0cc76cef49ca07b9c49f8f98d8f4ee27e2ae2b4e4811cf8b806602aebcc1e5aa0030183d1def0063918148655a9bd44ce1b99ae14ed7c627b2db05ccf52831fcbd4a04db194ec82255e26ebbc92185450139b366fe9614350f131b86e6a4f533262eb8bea306b7d07d1b5ecd562ea5e279e42f702cf2ed3641fa1c9cc95371adad19ed9c9f6f07c3ba1b0ab5aafba308ecd3b99375545af44743bcc1e7b5e73557127077d146b244a894958c71a9e4b4e&jsp=2&area=12&fillType=0&facePrice=10";
//		System.out.println(HttpUtils.httpPostData(b, null, null));
		
	}
}
