package demo;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;


import org.apache.commons.httpclient.HttpClient;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.jd.common.util.StringUtils;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.MD5Util;
import com.jd.sns.biz.api.domain.Sku;
import com.jd.sns.biz.api.domain.SkuList;

public class Test {

//	 static ApplicationContext ctx = new
//	 ClassPathXmlApplicationContext("spring-config.xml");

//    public static void main(String[] args) throws ParseException, UnsupportedEncodingException {

        // AreaService areaService = (AreaService)ctx.getBean("areaService");

        // GetAreaListResultVO galrv = areaService.getProvinces();
        // List<AreaListBeanVO> list = galrv.getAreaList();
        // for(int i = 0 ;i < list.size() ; i++){
        // System.out.println(list.get(i).getName() + "	"+list.get(i).getId());
        // }
        // System.out.println("--------------------------------------------------------------");
        // GetAreaListResultVO cities = areaService.getCitys(1);
        // List<AreaListBeanVO> list2 = cities.getAreaList();
        // for(int i = 0 ;i < list2.size() ; i++){
        // System.out.println(list2.get(i).getName() +
        // "	"+list2.get(i).getId());
        // }
        // System.out.println("--------------------------------------------------------------");
        // GetAreaListResultVO countys = areaService.getCountys(72);
        // List<AreaListBeanVO> list3 = countys.getAreaList();
        // for(int i = 0 ;i < list3.size() ; i++){
        // System.out.println(list3.get(i).getName() +
        // "	"+list3.get(i).getId());
        // }
        // System.out.println("--------------------------------------------------------------");
        // GetAreaListResultVO towns = areaService.getTowns(2799);
        // List<AreaListBeanVO> list4 = towns.getAreaList();
        // for(int i = 0 ;list4 != null && i < list4.size() ; i++){
        // System.out.println(list4.get(i).getName() +
        // "	"+list4.get(i).getId());
        // }
        // System.out.println("结束");

        // JdAreaService jda = (JdAreaService)ctx.getBean("jdAreaService");
        // System.out.println(jda.getProvinces());
        // System.out.println("-----------------------------------------------------------");
        // System.out.println(jda.getCitys(5));
        // System.out.println("-----------------------------------------------------------");
        // System.out.println(jda.getCountys(258));
        // System.out.println("-----------------------------------------------------------");
        // System.out.println(jda.getTowns(2756));

        // ProductService productService =
        // (ProductService)ctx.getBean("productService");
        // System.out.println(productService.queryBigField("134178"));

        // System.out.println(productService.getDetail("188076"));
        // String a =
        // HttpUtils.httpPostData("http://bizapi.jd.com/api/area/getProvince",
        // "token=tAqc5LoOReZB0YLdzkprUabm", "gbk");
        // System.out.println(a);
        // System.out.println(1381480688147l + 15724800000l);
        // System.out.println(new Date().getTime());

        // System.out.println(HttpUtils.httpPostData("http://bizapi.jd.com/oauth2/access_token",
        // "code=LODadbukGyG6fERtPPy2F8XMe&grant_type=authorization_code&client_id=XwI1spoB77&client_secret=igiiLoYU7w&redirect_uri=http://dev.eshop.unicom.local/ishop/index.jsp",
        // null));

        // com.jd.catagory.pbim.pbia.dubbo.service.ProductService productService
        // =
        // (com.jd.catagory.pbim.pbia.dubbo.service.ProductService)ctx.getBean("jdProductService");
        // Set set = new HashSet();
        // set.add(100015l);
        // List<String> list = new ArrayList<String>();
        // list.add("wareQD");
        // ProductBigField p = productService.queryBigField("100015", list);
        // System.out.println(p.getWareQD());
        // System.out.println("完成");

        // List list = new ArrayList();
        // list.add("propCode");
        // list.add("wdis");
        // ProductBigField pbf = productService.queryBigField("100015", list);
        // System.out.println(pbf.getPropCode());
        // System.out.println(pbf.getWdis());
        // Set set = new HashSet<Long>();
        // set.add(100015l);
        // Map map = productService.queryProductBase(set, null);
        // System.out.println(map);

        // ImageService a = (ImageService)ctx.getBean("productService");
        // Set set = new HashSet<Long>();
        // set.add(100015l);
        // Map map = a.queryImage(set);
        // System.out.println(map);

        // OrderTrackExport a =
        // (OrderTrackExport)ctx.getBean("orderTrackExport");
        // TrackShowResult result = a.getTrackShowResult(170364488,
        // "zhouzhongmingcs");
        // List<TrackShowVo> list = result.getZiyingShowResult();
        // List<TrackShowVo> list2 = result.getThirdPsShowResult();
        // TrackShowVo t = list.get(0);
        // System.out.println("aa");

        // System.out.println(MD5Util.md5Hex("asd123"));
        // System.out.println(HttpUtils.httpPostData("http://bizapi.jd.com/oauth2/access_token?grant_type=access_token&username=yujianming&password=bfd59291e825b5f2bbf1eb76569f8fe7&client_id=XwI1spoB77&client_secret=igiiLoYU7w&redirect_uri=http://jd.eshop.unicom.local/ishop/index.jsp",
        // "", null));
        // System.out.println(HttpUtils.httpPostData("http://bizapi.jd.com/oauth2/refresh_token?client_id=client_id_1&client_secret=client_secret_1&refresh_token=uihSXZBbqNEWHS7acWaPrygIbdzgAY6Aepzf1miI",
        // "", null));

        // String a = "{\"num\":\"11\",\"price\":\"1.2111\",\"id\":\"111\"}";
        // // Sku sku = new Sku();
        // // sku.setId(111l);
        // // sku.setNum(11);
        // // sku.setPrice(new BigDecimal("1.2111"));
        // ObjectMapper om = new ObjectMapper();
        // try {
        // Sku sku1 = om.readValue(a, Sku.class);
        // // System.out.println(om.writeValueAsString(sku));
        // System.out.println(sku1.getId());
        // System.out.println(sku1.getNum());
        // System.out.println(sku1.getPrice());
        // } catch (Exception e) {
        // e.printStackTrace();
        // }

        // String sku =
        // "[{\"id\":405491,\"num\":1, \"price\":10},{\"id\":325194,\"num\":3, \"price\":20},{\"id\":325194,\"num\":2, \"price\":30}]";
        // System.out.println(calculateOrderPrice(sku));
        // List<Sku> list = APIUtils.parseJson2Object(sku, Sku.class);
        // Sku sku1 = skuList.getList().get(0);
        // System.out.println(sku1.getId());
        // System.out.println(sku1.getNum());
        // System.out.println(sku1.getPrice());
        // String html =
        // "http://bizapi.jd.com/api/order/jdDemandOrder?demandOrder=123123&sku=[{\"id\":405491,\"num\":1, \"price\":10},{\"id\":325194,\"num\":3, \"price\":20.2}]}&province=1&city=1&county=1&town=1&token=Rh3BJnXuaxK6V8ZcykrkPLSEi";
        // System.out.println(HttpUtils.httpPostData(html, null, null));
//		String a = "<?xml version=\"1.0\" encoding=\"utf-16\"?><Message xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><OrderId>12321312312</OrderId><OperateTime>2013-09-11T11:23:46</OperateTime><OrderType>0</OrderType><SplitType>2</SplitType><OperateCode>-2</OperateCode><Reason>不满足拆分条件,原因:只能处理等待拆分的暂停订单</Reason><Key>Split_poc</Key> </Message>";
//		Document document = null;
//		try {
//			document = DocumentHelper.parseText(a);
//		} catch (DocumentException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		Element root = document.getRootElement();
//		for (Iterator iterator = root.elements().iterator(); iterator.hasNext();) {
//			Element info = (Element) iterator.next();
//			if (info.getName().equals("result")) {
//				map.put("result", info.getText());
//			} else if (info.getName().equals("pin")) {
//				map.put("pin", info.getText());
//			}
//		}

//		ListResult result = l
//		List list = new ArrayList();
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("state", 1);
//		map.put("sku", "423478");
//		list.add(map);
//		System.out.println(APIUtils.parseObject2Json(list));


//		String a = "{\"opeTime\":\"2013-11-06 16:15:39\",\"opeSiteName\":null,\"opeUserName\":null,\"orderId\":\"833572058\",\"opeSiteId\":\"1213\",\"opeUserId\":\"6443\",\"waybillCode\":\"833572058\"} ";
//		Map<String, Object> map = APIUtils.parseJson2Object(a, Map.class);
//		if(map != null && map.size() > 0 && map.get("orderId") != null){
//			Map<String, Object> messageMap = new HashMap<String, Object>();
//			System.out.println(Long.parseLong(map.get("orderId").toString()));
//		}

//		ServiceSoap s = (ServiceSoap)ctx.getBean("oomServiceSoap");
//		Order order = s.getOrderById(30000047241l, true, OrderLoadFlag.getLoadFlag(new String[] {"基本信息", "金额 "}));
////		System.out.println(order.getPin());
//		
//		
//		List list = new ArrayList();
//		list.add("基本信息");
//		list.add("顾客信息");
//		list.add("金额");
//		list.add("状态");
//
//		Order order2 = s.getOrderById(30000047241l, true, list);
//		System.out.println(order2.getPin());

//		BigDecimal price = new BigDecimal("10.22");
//		int b = 2;
//		System.out.println(price.multiply(new BigDecimal(String.valueOf(b))));;


//		jd.oom.client.clientbean.ServiceSoap oomServiceSoap = (jd.oom.client.clientbean.ServiceSoap)ctx.getBean("oomServiceSoap");
//		Order order = oomServiceSoap.getOrderById(986920181, true, OrderLoadFlag.getLoadFlag(new String[] {"状态"}));
//		
//		System.out.println(order.getState());
//		System.out.println(order.getState2());
//		System.out.println(order.getOrderStateName());;
//		System.out.println(order.getOrderStateEnum().toString());


//		ArrayOfOrderDetail detail =  order.getDetails();
//		List<OrderDetail> detailList = detail.getOrderDetail();
//		List skuList = new ArrayList();
//		BigDecimal orderPrice = new BigDecimal("0");
//		for(int m = 0 ;m<detailList.size();m++){
//			HashMap<String, Object> skuMap = new HashMap<String, Object>();
//			OrderDetail od = detailList.get(m);
//			skuMap.put("num", od.getNum());
//			skuMap.put("skuId", od.getProductId());
//			skuMap.put("price", od.getPrice());
//			skuList.add(skuMap);
//			orderPrice = orderPrice.add(od.getPrice().multiply(new BigDecimal(String.valueOf(od.getNum()))));
//		}
//		System.out.println("ok");

//		Order order = oomServiceSoap.getOrderById(986920181, true, OrderLoadFlag.getLoadFlag(new String[] {"状态"}));


//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("1", "a");
//		map.put("2", "b");
//		map.put("3", "c");
//		List<user> list = new ArrayList<user>();
//		list.add(new user("1", "a"));
//		list.add(new user("2", "b"));
//		list.add(new user("3", "c"));
//		
//		System.out.println(APIUtils.parseObject2Json(map));
//		System.out.println("----------------------");
//		System.out.println(APIUtils.parseObject2Json(list));

//		http%253A%252F%252Fadmin.haoli168.cn%252Fjd%252Findex.php
//		String a = "http://admin.haoli168.cn/jd/index.php";
//		String html = "http://bizapi.jd.com/oauth2/access_token?grant_type=authorization_code&client_id=lianhelihua&client_secret=GDqwrXUFISApBV9qiGjy&scope=&redirect_uri="+URLEncoder.encode(a, "utf-8")+"&code=HrYT2AVZGwh94ZGx0J10z83Uk&state=123";
//		System.out.println(html);
//		System.out.println(HttpUtils.httpPostData(html, "", null));


//		System.out.println(MessageFormat.format("-----PhoneRechargeServiceImpl.selectPricet------获得价格结束...userPin={0},facePrice={1},area={2},fillType={3},isp={4},price={5}", null, null, null, null, null, 0));

//		System.out.println(new BigDecimal("19").compareTo(new BigDecimal("10237.1")));

//		StringBuilder sb = new StringBuilder();
//		sb.append("2014-05-06 15:00:00");
//		sb.append("client_id_1");
//		sb.append("yujianming_02");
//		sb.append("http://bizapi.jd.com/test/callback");
//		sb.append("200820e3227815ed1756a6b531e7e0d2");
//		sb.append("");
//		sb.append("access_token");
//		sb.append("");
//		sb.append("client_secret_1");
//		System.out.println(sb.toString());
//		System.out.println(MD5Util.md5Hex(sb.toString()).toUpperCase());
        //			2014-05-06 15:00:00client_id_1yujianming_02http://bizapi.jd.com/test/callback200820e3227815ed1756a6b531e7e0d2access_tokenclient_secret_1
        //          2014-05-06 15:00:00client_id_1yujianming_01http://bizapi.jd.com/test/callback200820e3227815ed1756a6b531e7e0d2access_tokenclient_secret_1
//		String a = "2014-05-06 14:00:00client_id_1yujianming_02http://bizapi.jd.com/test/callback200820e3227815ed1756a6b531e7e0d2access_tokenclient_secret_1";
//		System.out.println(MD5Util.md5Hex("qwe123"));
//		System.out.println(MD5Util.md5Hex("yourclientsecret2014-01-01 01:01:01yourclientidyourpinyourpasswordaccess_tokenyourclientsecret").toUpperCase());
//        BigDecimal bizPrice = new BigDecimal(100);
//        BigDecimal tax = new BigDecimal(17).divide(new BigDecimal(100));
//        BigDecimal taxValue = new BigDecimal(1).add(tax);
//        BigDecimal result = bizPrice.divide(taxValue, 2, BigDecimal.ROUND_HALF_UP).multiply(tax);
//        System.out.println(result);
//        System.out.println(result.setScale(2, BigDecimal.ROUND_HALF_UP));
//        biz.erp.360buy.com/mysqlJson/sql.action?sql=
//        System.out.print(URLEncoder.encode("select * from bop_order_record where third_part_orderid like '%JF201405141000065640'","utf-8"));
    	
//    	
//    	System.out.println(HttpUtils.httpGetData("https://bizapi.jd.com/test/callback", null, null));
//    }
    
    
    public static void main(String[] args)throws Exception{ 
//        Map<String, String> params = new HashMap<String, String>(); 
//        params.put("TransName", "IQSR"); 
//        params.put("Plain", "transId=IQSR~|~originalorderId=2012~|~originalTransAmt= ~|~merURL= "); 
//        params.put("Signature", "9b759887e6ca9d4c24509d22ee4d22494d0dd2dfbdbeaab3545c1acee62eec7"); 
//        sendSSLPostRequest("https://bizapi.jd.com/test/callback", params);
    	
    	
    	StringBuilder sb = new StringBuilder();
        sb.append("PI5NmtLfM8wCZ0pU6ox7");
		sb.append("2014-06-04 18:42:07");
		sb.append("zhongguoyouzheng");
		sb.append("中国邮政集团公司专号");
		sb.append("62bd77187e8a6f972a9ac67ed734efae");
		sb.append("access_token");
		sb.append("PI5NmtLfM8wCZ0pU6ox7");
		System.out.print(MD5Util.md5Hex(sb.toString()).toUpperCase());
    } 
     
    /**
     * 向HTTPS地址发送POST请求
     * @param reqURL 请求地址
     * @param params 请求参数
     * @return 响应内容
     */ 
    @SuppressWarnings("finally") 
    public static String sendSSLPostRequest(String reqURL, Map<String, String> params){ 
        long responseLength = 0;                         //响应长度 
        String responseContent = null;                   //响应内容 
        org.apache.http.client.HttpClient httpClient = new DefaultHttpClient(); //创建默认的httpClient实例 
        X509TrustManager xtm = new X509TrustManager(){   //创建TrustManager 
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {} 
            public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {} 
            public X509Certificate[] getAcceptedIssuers() { return null; } 
        }; 
        try { 
            //TLS1.0与SSL3.0基本上没有太大的差别，可粗略理解为TLS是SSL的继承者，但它们使用的是相同的SSLContext 
            SSLContext ctx = SSLContext.getInstance("TLS"); 
             
            //使用TrustManager来初始化该上下文，TrustManager只是被SSL的Socket所使用 
            ctx.init(null, new TrustManager[]{xtm}, null); 
             
            //创建SSLSocketFactory 
            SSLSocketFactory socketFactory = new SSLSocketFactory(ctx); 
             
            //通过SchemeRegistry将SSLSocketFactory注册到我们的HttpClient上 
            httpClient.getConnectionManager().getSchemeRegistry().register(new Scheme("https", 443, socketFactory)); 
             
            HttpPost httpPost = new HttpPost(reqURL);                        //创建HttpPost 
            List<NameValuePair> formParams = new ArrayList<NameValuePair>(); //构建POST请求的表单参数 
            for(Map.Entry<String,String> entry : params.entrySet()){ 
                formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue())); 
            } 
            httpPost.setEntity(new UrlEncodedFormEntity(formParams, "UTF-8")); 
             
            HttpResponse response = httpClient.execute(httpPost); //执行POST请求 
            HttpEntity entity = response.getEntity();             //获取响应实体 
             
            if (null != entity) { 
                responseLength = entity.getContentLength(); 
                responseContent = EntityUtils.toString(entity, "UTF-8"); 
                EntityUtils.consume(entity); //Consume response content 
            } 
            System.out.println("请求地址: " + httpPost.getURI()); 
            System.out.println("响应状态: " + response.getStatusLine()); 
            System.out.println("响应长度: " + responseLength); 
            System.out.println("响应内容: " + responseContent); 
        } catch (KeyManagementException e) { 
            e.printStackTrace(); 
        } catch (NoSuchAlgorithmException e) { 
            e.printStackTrace(); 
        } catch (UnsupportedEncodingException e) { 
            e.printStackTrace(); 
        } catch (ClientProtocolException e) { 
            e.printStackTrace(); 
        } catch (IOException e) { 
            e.printStackTrace(); 
        } finally { 
            httpClient.getConnectionManager().shutdown(); //关闭连接,释放资源 
            return responseContent; 
        } 
    } 

    public static class user {
        private String name;
        private String value;

        public user(String name, String value) {
            this.name = name;
            this.value = value;
        }

        public user() {
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

    }

    private static Object asd() {
        List list = new ArrayList();
        list.add(1);
        list.add(2);
        return list;
    }

    private static BigDecimal calculateOrderPrice(String skuString) {
        SkuList skuList = parsingSkuList(skuString);
        BigDecimal result = new BigDecimal(0);
        for (Sku sku : skuList.getSku()) {
            result = result.add(sku.getPrice().multiply(
                    new BigDecimal(sku.getNum())));
        }

        return result;
    }

    private static SkuList parsingSkuList(String sku) {
        String skuString = "{\"sku\":" + sku + "}";
        return APIUtils.parseJson2Object(skuString, SkuList.class);
    }
}
