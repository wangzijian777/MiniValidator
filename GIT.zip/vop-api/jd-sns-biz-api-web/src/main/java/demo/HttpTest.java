package demo;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import com.jd.sns.biz.api.common.utils.HttpUtils;
import org.jboss.netty.handler.codec.base64.Base64Dialect;

public class HttpTest {
	
	private static String token = "QKF5iRUl0ExeJdqlD13o320jp";
	
//	private static String token = "qkKOPZVFyTJ6MBcLr2iUCX0Hk";
	
	/**
	 * @param args
	 * @throws UnsupportedEncodingException 
	 */
	public static void main(String[] args) throws UnsupportedEncodingException {
		//添加需求单
//		String jdDemandOrder = "http://bizapi.jd.com/api/order/jdDemandOrder?demandOrder=100004&sku=[{\"id\":800031,\"num\":1},{\"id\":800032,\"num\":1},{\"id\":800033,\"num\":1},{\"id\":800034,\"num\":1},{\"id\":800035,\"num\":1}]}&province=1&city=72&county=2839&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(jdDemandOrder, null, null));
		
		//取消需求单
//		String cancelJdDemandOrder = "http://bizapi.jd.com/api/order/cancelJdDemandOrder?jdDemandOrder=1000055&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(cancelJdDemandOrder, null, null));
		
		//查询需求单
//		String selectDemandOrder = "http://bizapi.jd.com/api/order/selectDemandOrder?jdDemandOrder=1000054&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(selectDemandOrder, null, null));
		
		
		
		//submit预占库存下单接口
//		String submitOrder = "";
//		try{
//			submitOrder = "http://bizapi.jd.com/api/order/submit?thirdOrder=110011421&sku=[{\"id\":712609,\"num\":4},{\"id\":569172,\"num\":5}]}&name="+URLEncoder.encode("于建明", "utf-8")+"&province=1&city=72&county=2839&address="+URLEncoder.encode("北辰世纪中心A座2层", "utf-8")+"&zip=10000&phone=&mobile=18910024183&email=liuyunfei@jd.com&token="+token+"&paymentType=12&isUseBalance=0&submitState=0";
//		}catch (Exception e) {
//
//		}
//		System.out.println(HttpUtils.httpPostData(submitOrder, null, null));

		//京东价下单，预占库存，余额下单接口
//		String submitOrder = "";
//		try{
//			submitOrder = "http://bizapi.jd.com/api/order/jdPriceSubmit?thirdOrder=110045&sku=[{\"id\":569172,\"num\":1},{\"id\":102194,\"num\":1}]}&name="+URLEncoder.encode("于建明", "utf-8")+"&province=1&city=72&county=2839&address="+URLEncoder.encode("北辰世纪中心A座2层", "utf-8")+"&zip=10000&phone=&mobile=18910024183&email=liuyunfei@jd.com&token=z905HDqyPtKsFDYqPXHXCszYT&paymentType=12&isUseBalance=0";
//		}catch (Exception e) {
//
//		}
//		System.out.println(HttpUtils.httpPostData(submitOrder, null, null));

		//取消未确认订单接口
		
//		String submitOrder = "";
//		try{
//			submitOrder = "http://bizapi.jd.com/api/order/cancel?jdOrderId=1295495591&token=z5sQu0ECVuR8jHSK9I5k4s0Jj";
//		}catch (Exception e) {
//			
//		}
//		System.out.println(HttpUtils.httpPostData(submitOrder, null, null));
		
		//预占库存，开发票，京东价下单接口，给民生银行提供的
//		String submitOrder = "";
//		try{
//			submitOrder = "http://bizapi.jd.com/api/order/submit2?thirdOrder=100035&sku=[{\"id\":800032,\"num\":1}]}&name="+URLEncoder.encode("于建明", "utf-8")+"&province=1&city=72&county=2839&address="+URLEncoder.encode("北辰世纪中心A座2层", "utf-8")+"&zip=10000&phone=&mobile=18910024183&email=liuyunfei@jd.com&token="+token+"&invoiceState=1&invoiceType=1&selectedInvoiceTitle=5&companyName=aaa&invoiceContent=1";
//		}catch (Exception e) {
//			
//		}
//		System.out.println(HttpUtils.httpPostData(submitOrder, null, null));
		
		//取消预占库存订单接口
//		String cancelOrder = "http://bizapi.jd.com/api/order/cancel?jdOrderId=41160437506&token="+token;
//		System.out.println(HttpUtils.httpPostData(cancelOrder, null, null));
		
		//确认下单接口
//		String confirmOrder = "http://bizapi.jd.com/api/order/confirmOrder?jdOrderId=41460457498&token="+token;
//		System.out.println(HttpUtils.httpPostData(confirmOrder, null, null));
		
		//未确认下单的取消接口
//		String cancel = "http://bizapi.jd.com/api/order/cancel?jdOrderId=40080094237&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(cancel, null, null));
		
		//取消订单
//		String cancelOrder = "http://bizapi.jd.com/api/order/cancelJdOrder?jdOrderId=40080094222&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(cancelOrder, null, null));
		
		//查询订单
//		String selectJdOrder = "http://bizapi.jd.com/api/order/selectJdOrder?jdOrderId=1425684586&token="+token;
//		System.out.println(HttpUtils.httpPostData(selectJdOrder, null, null));
		
		//订单挂起
//		try {
//			String hangUpSubmit = "http://bizapi.jd.com/api/hangUp/submit?jdOrderId=40095096448&workType=1&workInfo="+URLEncoder.encode("1", "utf-8")+"&token="+ctoken;
//			System.out.println(HttpUtils.httpPostData(hangUpSubmit, null, null));
//		} catch (Exception e) {
//			System.out.println("异常了");
//		}
		
		//查询挂起订单
//		String hangUpSelect = "http://bizapi.jd.com/api/hangUp/select?jdOrderId=40060091648&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(hangUpSelect, null, null));
		
		//取消挂起
//		String hangUpCancel = "http://bizapi.jd.com/api/hangUp/cancel?jdOrderId=40095096448&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(hangUpCancel, null, null));
		
		//开发票接口
//		String fapiaoSubmit = "http://bizapi.jd.com/api/invoice/submit?jdOrder=40060091648,1111,1111,111&markId=markId8&invoiceType=1&invoiceOrg=544&bizInvoiceContent="+URLEncoder.encode("明细", "utf-8")+"&invoiceDate=2013-11-11&title="+URLEncoder.encode("发票抬头", "utf-8")+"&repaymentDate=2013-11-12&invoicePrice=20.2&invoiceNum=1&settlementId=222&settlementNum=3&settlementPrice=4.2&token="+token;
//		System.out.println(HttpUtils.httpPostData(fapiaoSubmit, null, null));
		
		//查询发票接口
//		String fapiao = "http://bizapi.jd.com/api/invoice/select?markId=markId1&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(fapiao, null, null));
		
		//提交差异订单
//		String difference = "http://bizapi.jd.com/api/difference/submit?jdOrderId=40095095590&content="+URLEncoder.encode("提交差异订单测试", "utf-8")+"&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(difference, null, null));
		
		//查看商品评价
//		String difference = "http://bizapi.jd.com/api/product/getCommentSummarys?sku=800020,800035&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(difference, null, null));
		
		
		
//		String selectJdOrderListByThirdOrder = "http://bizapi.jd.com/api/order/selectJdOrderListByThirdOrder?thirdOrder=100028&token=";
//		System.out.println(HttpUtils.httpPostData(selectJdOrderListByThirdOrder, null, null));
		
		
		
		//礼品卡下单接口
//		String giftcard = "http://bizapi.jd.com/api/giftCard/buy?thirdOrder=118&sku=[{\"price\":100,\"num\":2},{\"price\":10,\"num\":1}]&mobile=13423142312";
//		System.out.println(HttpUtils.httpPostData(giftcard, null, null));
		
		//查询礼品卡
//		String giftcard = "http://bizapi.jd.com/api/giftCard/select?jdOrderId=40685341986";
//		System.out.println(HttpUtils.httpPostData(giftcard, null, null));
		
		//根据第三方订单号查询礼品卡信息
//		String giftcard = "http://bizapi.jd.com/api/giftCard/selectByThirdOrder?thirdOrder=118";
//		System.out.println(HttpUtils.httpPostData(giftcard, null, null));
		
//		String giftcard = "http://biz.erp.360buy.com/mysqlJson/sql.action?sql="+URLEncoder.encode("select * from bop_phone_recharge_order limit 0,1", "utf-8");
//		System.out.println(HttpUtils.httpPostData(giftcard, null, null));
		
		
		//测试：
		
		
		
		
		//地址
//		String dizhi = "http://bizapi.jd.com/api/area/getCounty?id=1930&token="+token;
//		System.out.println(HttpUtils.httpPostData(dizhi, null, null));
		
//		String peisongzhuangtai = "http://bizapi.jd.com/api/order/orderTrack?token=BoV4KKk5VPVEPcaSD6K9YAJnW&jdOrderId=40000085387";
//		System.out.println(HttpUtils.httpPostData(peisongzhuangtai, null, null));
		
//		String xuqiudan = "http://bizapi.jd.com/api/order/jdDemandOrder?token=KAt6HW1Ve8ylHTJgaQ3AF7OIE&demandOrder=12347&sku=[{\"id\":800020,\"num\":1}]&province=1&city=72&county=2839&town=0";
//		System.out.println(HttpUtils.httpPostData(xuqiudan, null, null));
		
//		try{
//			String xiadan = "http://bizapi.jd.com/api/order/submitOrder?thirdOrder=12347&jdDemandOrder=1000028&sku=[{\"id\":800020,\"num\":1}]&name="+URLEncoder.encode("邢大飞", "utf-8")+"&province=1&city=72&county=2839&address="+URLEncoder.encode("北京朝阳区四环到五环之间北辰西路8号北辰世纪中心A座16层", "utf-8")+"&zip=10000&phone=&mobile=13501117630&email=xingdafei@jd.com&token=KAt6HW1Ve8ylHTJgaQ3AF7OIE";
//			System.out.println(HttpUtils.httpPostData(xiadan, null, null));
//		}catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
		
//		String updateJdOrderId = "http://bizapi.jd.com/admin/admin/updateJdOrderId";
//		System.out.println(HttpUtils.httpGetData(updateJdOrderId, "jdDemandOrder=1000318&jdOrderId=837942180", null));
		
		//837938561,837947552
		
//		String updateOneOrderState = "http://bizapi.jd.com/admin/admin/updateOneOrderState";
//		System.out.println(HttpUtils.httpGetData(updateOneOrderState, "type=2&state=0&orderState=1&parentId=837942180&jdOrderId=837947552", null));
		
//		String getOrderAll = "http://bizapi.jd.com/admin/admin/getOrderAll";
//		System.out.println(HttpUtils.httpGetData(getOrderAll, "type=1", null));
		
//		String getDemandAll = "http://bizapi.jd.com/admin/admin/getDemandAll";
//		System.out.println(HttpUtils.httpGetData(getDemandAll, "", null));
		
		//添加redis
//		String redis = "http://bizapi.jd.com/admin/admin/redis";
//		System.out.println(HttpUtils.httpGetData(redis, "key=order-837442905&time=604800&value=ok", null));
		
//		String getMessageTaskAll = "http://bizapi.jd.com/admin/admin/getMessageTaskAll";
//		System.out.println(HttpUtils.httpGetData(getMessageTaskAll, "type=5", null));
		
//		String updateMessageTaskOne = "http://bizapi.jd.com/admin/admin/updateMessageTaskOne";
//		System.out.println(HttpUtils.httpGetData(updateMessageTaskOne, "state=2&id=7338", null));
		
//		String updateMessageOne = "http://bizapi.jd.com/admin/admin/updateMessageOne";
//		System.out.println(HttpUtils.httpGetData(updateMessageOne, "type=-1&id=1", null));
		
//		String insertMessageOne = "http://bizapi.jd.com/admin/admin/insertMessageOne";
//		try{
//			System.out.println(HttpUtils.httpGetData(insertMessageOne, "clientId=1&result=1&type=-1", null));
//		}catch (Exception e) {
//		}
		
//		String insertMessageOne = "http://bizapi.jd.com/admin/admin/insertMessageOne";
//		try{
//			System.out.println(HttpUtils.httpGetData(insertMessageOne, "clientId=1&result=1&type=-1", null));
//		}catch (Exception e) {
//		}
		
//		String tuisongxiaoxi = "http://bizapi.jd.com/api/message/get?del=0&type=&token="+token;
//		System.out.println(HttpUtils.httpPostData(tuisongxiaoxi, null, null));
		
//		String shanchuxiaoxi = "http://bizapi.jd.com/api/message/del?id=325981,325982&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(shanchuxiaoxi, null, null));
		
//		String searchBizInvoice = "http://bizapi.jd.com/api/invoice/select?markId=markId1&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(searchBizInvoice, null, null));
		
//		String selectJdOrderIdByThirdOrder = "http://bizapi.jd.com/api/order/selectJdOrderIdByThirdOrder?thirdOrder=PO-jdsd-20140714100355833&token="+token;
//		System.out.println(HttpUtils.httpPostData(selectJdOrderIdByThirdOrder, null, null));
		
		
		
		
		
		
		
		
		
		
		//线上
		
//		String xuqiudan = "http://bizapi.jd.com/api/order/submit2?thirdOrder=DH1405141527340305&sku=[{\"skuId\":970581,\"num\":1}]&name=11&province=19&city=1672&county=19827&town=&address=广东阳江市江城区&zip=&phone=&mobile=15999999999&email=&remark=&invoiceState=1&invoiceType=1&selectedInvoiceTitle=5&companyName=桂林力港网络科技有限公司&invoiceContent=1&paymentType=4&isUseBalance=1&token=d7Sb8WpGueGUlJgBoMGnarVcV";
//        System.out.print(URLDecoder.decode(xuqiudan, "utf-8"));
//		System.out.println(HttpUtils.httpPostData(xuqiudan, null, null));
//		try{
//			String xiadan = "http://bizapi.jd.com/api/order/submitOrder?thirdOrder=12345&jdDemandOrder=1000310&sku=[{\"id\":818260,\"num\":1},{\"id\":781113,\"num\":1}]&name="+URLEncoder.encode("邢大飞", "utf-8")+"&province=1&city=72&county=2839&address="+URLEncoder.encode("北京朝阳区四环到五环之间北辰西路8号北辰世纪中心A座16层", "utf-8")+"&zip=10000&phone=&mobile=13501117630&email=xingdafei@jd.com&token=BoV4KKk5VPVEPcaSD6K9YAJnW";
//			System.out.println(HttpUtils.httpPostData(xiadan, null, null));
//		}catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
		
//		String shangpinchi = "http://bizapi.jd.com/api/product/getPageNum?token="+token;
//		for(int i=0;i<500;i++){
//			System.out.println(i+HttpUtils.httpPostData(shangpinchi, null, null));
//		}
		
//		String jiage = "http://bizapi.jd.com/api/price/getPrice?sku=J_921723&containsTax=1&token="+token;
//        System.out.println(HttpUtils.httpPostData(jiage, null, null));

//		String chakankucun = "http://bizapi.jd.com/api/stock/getStockById?token=Tv4sGzrUAsqXgckB5sdqL9Jng&sku=781113&area=13_1000_40488";
//		System.out.println(HttpUtils.httpPostData(chakankucun, null, null));
		
//		String tuisongxiaoxi = "http://bizapi.jd.com/api/message/get?del=0&type=2&token="+token;
//		for(int i=0;i<500;i++){
//			System.out.println(i+HttpUtils.httpPostData(tuisongxiaoxi, null, null));
//		}
		
		
//		String peisongzhuangtai = "http://bizapi.jd.com/api/order/orderTrack?token="+token+"&jdOrderId=837442905";
//		for(int i=0;i<500;i++){
//			System.out.println(i+HttpUtils.httpPostData(peisongzhuangtai, null, null));
//		}
		
		//查询订单
//		String selectJdOrder = "http://bizapi.jd.com/api/order/selectJdOrder?jdOrderId=1440976705&token="+token;
//		System.out.println(HttpUtils.httpPostData(selectJdOrder, null, null));
		
		//取消订单
//		String quxiaodingdan = "http://bizapi.jd.com/api/order/cancelJdOrder?jdOrderId=30000047022&token=SsCYR7Fguutp6e3AesBwaN9tv";
//		System.out.println(HttpUtils.httpPostData(quxiaodingdan, null, null));
		
		//刷order缓存
//		String refreshRedis = "http://bizapi.jd.com/admin/admin/refreshRedis";
//		System.out.println(HttpUtils.httpGetData(refreshRedis, null, null));
		
		//地址
//		for(int i =0;i<500;i++){
//			String dizhi = "http://bizapi.jd.com/api/area/getProvince?param="+i+"&token="+token;
//			System.out.println(i+HttpUtils.httpPostData(dizhi, null, null));
//		}
		
		
		//图片
//		String image = "http://bizapi.jd.com/api/product/skuImage?sku=800031&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(image, null, null));
		
		//商品上下架
//		StringBuilder sb = new StringBuilder();
//		for(int i=0;i<101;i++){
//			sb.append("80003"+i+",");
//		}
//		System.out.println(sb.toString().substring(0, sb.toString().length()-1));
//		String skuState = "http://bizapi.jd.com/api/product/skuState?sku="+sb.toString().substring(0, sb.toString().length()-1)+"&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(skuState, null, null));
		
		//价格
//		StringBuilder sb = new StringBuilder();
//		for(int i=0;i<10;i++){
//			sb.append("J_80003"+i+",");
//		}
//		System.out.println(sb.toString().substring(0, sb.toString().length()-1));
//		String getPrice = "http://bizapi.jd.com/api/price/getJdPrice?sku="+sb.toString().substring(0, sb.toString().length()-1)+"&token="+token;
//		System.out.println(HttpUtils.httpPostData(getPrice, null, null));
		
		//库存
//		StringBuilder sb = new StringBuilder();
//		for(int i=0;i<101;i++){
//			sb.append("80003"+i+",");
//		}
//		String stock = "http://bizapi.jd.com/api/stock/getStockById?area=1_0_0&sku="+sb.toString().substring(0, sb.toString().length()-1)+"&token="+ctoken;
//		System.out.println(HttpUtils.httpPostData(stock, null, null));
		
		//商品detail
//		String detail = "http://bizapi.jd.com/api/product/getDetail?sku=569172&token="+token;
//        System.out.println(HttpUtils.httpPostData(detail, null, null));

		//订单配送
//		String orderTrack = "http://bizapi.jd.com/api/order/orderTrack?jdOrderId=851878784&token="+token;
//		for(int i =0;i<500;i++){
//			System.out.println(i+HttpUtils.httpPostData(orderTrack, null, null));
//		}
	}
}
