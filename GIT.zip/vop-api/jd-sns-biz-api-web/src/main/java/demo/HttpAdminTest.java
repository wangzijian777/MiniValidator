package demo;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import jd.oom.client.clientbean.ArrayOfOrderDetail;
import jd.oom.client.clientbean.Business;
import jd.oom.client.clientbean.Order;
import jd.oom.client.clientbean.OrderDetail;
import jd.oom.client.clientbean.Result;
import jd.oom.client.clientbean.ServiceSoap;
import jd.oom.client.core.OrderLoadFlag;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.HttpUtils;
import com.jd.sns.biz.api.domain.BizOrder;

public class HttpAdminTest {
	private static final Logger log = LoggerFactory.getLogger(HttpAdminTest.class);
	private static String token = "U2qvjXQbnJbMJ2D2hUAVXe7Xp";
	private static String ctoken = "HLhBDK9kmV7wuEDoKtvZleyHp";
	
	/**
	 * @param args
	 * @throws UnsupportedEncodingException 
	 */
	public static void main(String[] args) throws UnsupportedEncodingException {
		//后台补充提交一个订单		 start
//		String buchongdingdan = "http://bizapi.jd.com/admin/admin/submitOrder";
//		StringBuilder sb = new StringBuilder("");
//		sb.append("jdOrderId=").append("868071230");
//		sb.append("&").append("clientId=").append("XwI1spoB77");
//		sb.append("&").append("jdDemandOrder=").append("1000422");
//		sb.append("&").append("pin=").append("中国联通总公司");
//		sb.append("&").append("thirdOrder=").append("jdsd-20131121100902281");
//		sb.append("&").append("sku=").append(URLEncoder.encode("[{\"skuId\":196856,\"num\":50,\"category\":4837,\"price\":8.91,\"name\":\"得力(deli)0012 优质高强度订书钉12# 1000枚/盒 10盒装\"},{\"skuId\":385885,\"num\":10,\"category\":7372,\"price\":4.5,\"name\":\"得力(deli)9874 40ml快干清洁印泥油(红色) \"},{\"skuId\":385907,\"num\":5,\"category\":4837,\"price\":4.5,\"name\":\"得力(deli)0596 锌合金卷笔刀 \"},{\"skuId\":385918,\"num\":30,\"category\":4837,\"price\":1.8,\"name\":\"得力（deli）7138 21g中性固体胶棒 多色随机发 单支装\"},{\"skuId\":557114,\"num\":50,\"category\":4840,\"price\":3.0,\"name\":\"齐心（COMIX）A1154 PVC网格拉链袋/文件袋/资料袋 A4\"},{\"skuId\":569063,\"num\":50,\"category\":4837,\"price\":5.85,\"name\":\"得力(deli)0010 订书钉10＃ 10盒装 \"},{\"skuId\":569127,\"num\":20,\"category\":4837,\"price\":1.8,\"name\":\"得力(deli)2001 经济实用型塑料壳美工刀(红、蓝混色随机发) \"},{\"skuId\":569213,\"num\":20,\"category\":7372,\"price\":4.32,\"name\":\"得力(deli)9863 圆形透明外壳快干印台(红色) \"},{\"skuId\":760226,\"num\":50,\"category\":4839,\"price\":4.41,\"name\":\"得力(deli) 30007 彩色透明胶带8mm*30y 12卷（筒装）\"},{\"skuId\":880019,\"num\":10,\"category\":4839,\"price\":41.0,\"name\":\"齐心（COMIX） JT5508-6 超透封箱宽胶带55mm*80y 6卷/筒\"}]", "utf-8"));
//		sb.append("&").append("province=").append("2");
//		sb.append("&").append("city=").append("2833");
//		sb.append("&").append("county=").append("2869");
//		sb.append("&").append("town=").append("0");
//		sb.append("&").append("orderPrice=").append("1762.4");
//		sb.append("&").append("name=").append("杨艳");
//		sb.append("&").append("address=").append("上海青浦区外环以外盈港路453号港隆大厦20楼");
//		sb.append("&").append("zip=").append("201700");
//		sb.append("&").append("phone=").append("021-60829465");
//		sb.append("&").append("mobile=").append("18601721072");
//		sb.append("&").append("email=").append("");
//		sb.append("&").append("type=").append("1");
//		sb.append("&").append("state=").append("0");
//		sb.append("&").append("orderState=").append("1");
//		sb.append("&").append("remark=").append("");
//		sb.append("&").append("parentId=").append("0");
//		sb.append("&").append("ip=").append("202.99.45.130");
//		sb.append("&").append("hangUpState=").append("0");
//		sb.append("&").append("invoiceState=").append("0");
//		System.out.println(HttpUtils.httpGetData(buchongdingdan, sb.toString(), null));
		//后台补充提交一个订单		 end
		
		
		
		
		//修改订单状态
		String updateOneOrderState = "http://bizapi.jd.com/admin/admin/updateOneOrderState";
		StringBuilder sb = new StringBuilder();
		sb.append("type=").append("1");//1是父订单，2是子订单
		sb.append("&").append("state=").append("0");//0是刚下单，1是妥投，2是拒收
		sb.append("&").append("orderState=").append("0");//0是无效，1是有效，2是二次拆单
		sb.append("&").append("parentId=").append("0");//父订单
		sb.append("&").append("hangUpState=").append("0");//0是未挂起，1是挂起
		sb.append("&").append("invoiceState=").append("0");//0是未开发票，1是已开发票
		sb.append("&").append("submitState=").append("0");//0是预占库存订单，1是已经确认下订单
		sb.append("&").append("jdOrderId=").append("1507443898");//订单号
		System.out.println(HttpUtils.httpGetData(updateOneOrderState, sb.toString(), null));
		
		
		
		//手动添加一条拆单任务 start
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("orderId", 1507691798);
//		map.put("splitType", 3);//1需要拆单。3为无需拆单
//		String insertMessageTaskOne = "http://bizapi.jd.com/admin/admin/insertMessageTaskOne";
//		System.out.println(HttpUtils.httpGetData(insertMessageTaskOne, "message="+APIUtils.parseObject2Json(map)+"&state=1&type=1", null));
		//手动添加一条拆单任务 end
		
		
		//手动添加一条妥投任务 start
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("orderId", 1203253578);
//		map.put("state", 1);//1为妥投2为拒收
//		map.put("time", "2014-03-21 15:13:14");
//		String insertMessageTaskOne = "http://bizapi.jd.com/admin/admin/insertMessageTaskOne";
//		System.out.println(HttpUtils.httpGetData(insertMessageTaskOne, "message="+URLEncoder.encode(APIUtils.parseObject2Json(map), "utf-8")+"&state=1&type=5", null));
		//手动添加一条妥投任务 end
		
		//查询redis里面有没有该订单
//		String getRedisValue = "http://bizapi.jd.com/admin/admin/getRedisValue";
//		System.out.println(HttpUtils.httpGetData(getRedisValue, "key=biz_quota_testpin4", null));
		
		//修改一个bizMessageTask
//		String updateMessageTaskOne = "http://bizapi.jd.com/admin/admin/updateMessageTaskOne";
//		System.out.println(HttpUtils.httpGetData(updateMessageTaskOne, "state=2&type=1", null));
		
		//获得所有推送消息
//		String getMessageAll = "http://bizapi.jd.com/admin/admin/getMessageAll";
//		System.out.println(HttpUtils.httpGetData(getMessageAll, "type=1", null));
		
		//获取所有发票信息
//		String getMessageAll = "http://bizapi.jd.com/admin/admin/getInvoiceAll";
//		System.out.println(HttpUtils.httpGetData(getMessageAll, "", null));
		
		//获取所有异常订单信息
//		String getBizOrderDifferenceAll = "http://bizapi.jd.com/admin/admin/getBizOrderDifferenceAll";
//		System.out.println(HttpUtils.httpGetData(getBizOrderDifferenceAll, "", null));
		
		//修改开发票状态
//		String updateBizInvoiceState = "http://bizapi.jd.com/admin/admin/updateBizInvoiceState";
//		System.out.println(HttpUtils.httpGetData(updateBizInvoiceState, "state=1&invoiceId=34787690&id=9", null));
		
		//手动添加一个消息
//		String insertMessageOne = "http://bizapi.jd.com/admin/admin/insertMessageOne";
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("state", 1);
//        map.put("orderId", 1230485525);
//		System.out.println(HttpUtils.httpGetData(insertMessageOne, "clientId=XwI1spoB77&type=5&result="+URLEncoder.encode(APIUtils.parseObject2Json(map), "utf-8"), null));
		
		//手动让某个商品发货
//		Set<Long> set = new HashSet<Long>();
//		set.add(924918269L);
//		set.add(924894098L);
//		set.add(921860468L);
//		set.add(913124846L);
//		set.add(912619023L);
//		set.add(919586837L);
//		set.add(919582500L);
//		set.add(919570350L);
//		set.add(919555945L);
//		set.add(919551196L);
//		confirmJdOrder(set);
		
		
		//查看一个订单的所有叶子订单
//		String getLeafList = "http://bizapi.jd.com/admin/admin/getLeafList";
//		System.out.println(HttpUtils.httpGetData(getLeafList, "jdOrderId=920226492", null));
		
		//根据guid查询订单号
//		String getOrderIdByOrderguid = "http://bizapi.jd.com/admin/admin/getOrderIdByOrderguid";
//		for(int i=0;i<100;i++){
//			System.out.println(HttpUtils.httpGetData(getOrderIdByOrderguid, "guid=bizapi-clientId-9ea1d4c7-389e-4765-ac1f-60f3878b7224", null));
//		}
		
		//添加一个月结任务
//		String insertBizQuota = "http://bizapi.jd.com/admin/admin/insertBizQuota";
//		System.out.println(HttpUtils.httpGetData(insertBizQuota, "pin=aaaa&price=1.1&key=11111&code=123123&yn=1", null));
		
		
//		String redis = "http://bizapi.jd.com/admin/admin/getRedisValue";
//		System.out.println(HttpUtils.httpGetData(redis, "key=biz_quota_"+URLEncoder.encode("中国联通总公司", "utf-8"), null));
		
//		String chijiuredis = "http://bizapi.jd.com/admin/admin/chijiuredis";
//		System.out.println(HttpUtils.httpGetData(chijiuredis, "key=biz_quota_"+URLEncoder.encode("biz_quota_testpin4", "utf-8")+"&value=2&time=1", null));
		
		//删除所有百度的推送消息
//		String deleteByClientId = "http://bizapi.jd.com/admin/admin/deleteByClientId";
//		System.out.println(HttpUtils.httpGetData(deleteByClientId, "clientId=z4jIQBpWh8", null));
		
//		selectJdOrder(1111l);
	}
	
	private static void selectJdOrder(Long jdOrderId){
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		ServiceSoap oomServiceSoap = (ServiceSoap)ctx.getBean("oomServiceSoap");
		System.out.println("拿到");
		Order order = oomServiceSoap.getOrderById(jdOrderId, true, OrderLoadFlag.getLoadFlag(new String[] {"基本信息", "金额 "}));
		if(order == null){
			throw new RuntimeException("order == null 订单已经拆分成功，但是调用订单查询接口时，该接口无数据");
		}
		//下面的判断逻辑判断一下是否非空
		ArrayOfOrderDetail detail =  order.getDetails();
		System.out.println("拿到2");
		if(detail == null){
			throw new RuntimeException("detail == null 订单已经拆分成功，但是调用订单查询接口时，该接口无数据");
		}
		List<OrderDetail> detailList = detail.getOrderDetail();
		if(detailList == null || detailList.size() == 0){
			throw new RuntimeException("detailList.size() == 0 订单已经拆分成功，但是调用订单查询接口时，该接口无数据");
		}
		
		List skuList = new ArrayList();
		BigDecimal orderPrice = new BigDecimal("0");
		for(int m = 0 ;m<detailList.size();m++){
			HashMap<String, Object> skuMap = new HashMap<String, Object>();
			OrderDetail od = detailList.get(m);
			skuMap.put("num", od.getNum());
			skuMap.put("skuId", od.getProductId());
			skuMap.put("price", od.getPrice());
			skuList.add(skuMap);
			orderPrice = orderPrice.add(od.getPrice().multiply(new BigDecimal(String.valueOf(od.getNum()))));
		}
	}
	
	/**
	 * 修改订单配送时间方法。没事儿别用
	 * @param jdOrderId
	 * @return
	 */
	private static boolean confirmJdOrder(Set<Long> set){
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring-config.xml");
		ServiceSoap oomServiceSoap = (ServiceSoap)ctx.getBean("oomServiceSoap");
		if(set == null || set.isEmpty() || set.size() == 0){
			System.out.println("是空的大哥");
			return false;
		}
		try{
			Date date = new Date();//订单配送时间设为当天
			Iterator<Long> it = set.iterator();
			while(it.hasNext()){
				Long jdOrderId = it.next();
				
				Business business=new Business();
				Order order = new Order();
				order.setId(jdOrderId);
				
				GregorianCalendar cal = new GregorianCalendar();
				cal.setTime(date);
				XMLGregorianCalendar gc = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
				order.setExpectPickTime(gc);
				
				business.setOrder(order);
				business.setOrderId(jdOrderId);
				business.setType(193);
				business.setOperatorPin("中国联通总公司");//操作人pin
				business.setOperatorName("中国联通总公司");
				Result orderResult=oomServiceSoap.canDo(business);
				if(orderResult.isFlag()){
					Result result2 = oomServiceSoap._do(business);
					if(result2.isFlag()){
						System.out.println(jdOrderId + "OK");
					}else{
						System.out.println(jdOrderId);
						return false;
					}
				}else{
					System.out.println(jdOrderId);
					return false;
				}
			}
			System.out.println("执行完毕");
			return true;
		}catch (Exception e) {
			log.error("", e);
		}
		System.out.println("not OK");
		return false;
	}
	
}
