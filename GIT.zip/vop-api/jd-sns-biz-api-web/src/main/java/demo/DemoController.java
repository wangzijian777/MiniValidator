package demo;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.common.web.result.Result;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.HttpUtils;
import com.jd.sns.biz.api.service.domain.ListResult;
import com.jd.sns.vip.service.DemoService;
import commons.spring.mvc.controller.BaseController;



/**
 * @auth lsg
 * @version 1.0.0
 */
@org.springframework.stereotype.Controller
//@RequestMapping("/test")
public class DemoController extends BaseController {
	
	private static final Logger log = LoggerFactory.getLogger(DemoController.class);
	
	private DemoService demoService;
	
	public void setDemoService(DemoService demoService) {
		this.demoService = demoService;
	}

	//http://one1.jd.com:8012/test/demo
	//	@RequestMapping(value = "demo", method = RequestMethod.GET)
	public String demo(HttpServletRequest req, HttpServletResponse resp, ModelMap context) {
		Result result = new Result();
		result.setSuccess(true);
		result.addDefaultModel("hello", "<h1>hello中国</h1>");
		result.setResultCode("message.param");
		result.setResultCodeParams(new String[]{"errorParam1"});
		result.addDefaultModel("name", demoService.getName("yujianming"));
		toVm(result, context, req);
		return "demo";
		
	}

	@RequestMapping(value = "ajax", method = RequestMethod.GET)
	public @ResponseBody Map<String, Object> ajax() {
		Map<String, Object> root = new HashMap<String, Object>();
		root.put("one", "hello中国");
		root.put("date", new Date());
		Map<String, Object> map = new HashMap<String, Object>();
		map.putAll(root);
		root.put("map", map);
		return root;
	}
	
	//	@RequestMapping(value = "needLogin", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> needLogin(HttpServletRequest req) {
		
		Map<String, Object> root = new HashMap<String, Object>();
		root.put("one", "hello中国");
		root.put("date", new Date());
		root.put("pin", getPin(req));
		Map<String, Object> map = new HashMap<String, Object>();
		map.putAll(root);
		root.put("map", map);
		return root;
	}

	//@RequestMapping(value = "duizhang", method = RequestMethod.GET)
	public @ResponseBody
	Map<String, Object> duizhang(HttpServletRequest req) {
		Map<String, Object> root = new HashMap<String, Object>();
		
		String html = HttpUtils.httpGetData("http://bizapi.jd.com/admin/admin/getOrderAll", "", null);
		ListResult result = APIUtils.parseJson2Object(html, ListResult.class);
		List list = result.getResult();
		List nList = new ArrayList();
		List tList = new ArrayList();
		List jList = new ArrayList();
		BigDecimal nOrderPrice = new BigDecimal(0);
		BigDecimal tOrderPrice = new BigDecimal(0);
		BigDecimal jOrderPrice = new BigDecimal(0);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for(int i=0;i<list.size() ;i++){
			Map bizOrder = (Map)list.get(i);
			Integer type = (Integer)bizOrder.get("type");
			Integer orderState = (Integer)bizOrder.get("orderState");
			Integer submitState = (Integer)bizOrder.get("submitState");
			Integer state = (Integer)bizOrder.get("state");
			BigDecimal one = new BigDecimal(bizOrder.get("orderPrice").toString());
			if(type == 2 &&orderState==1&& bizOrder.get("clientId").toString().equals("XwI1spoB77")){
				
				Map map = new HashMap();
				map.put("thirdOrder", bizOrder.get("thirdOrder").toString());
				map.put("jdOrderId", bizOrder.get("jdOrderId").toString());
				map.put("orderPrice", bizOrder.get("orderPrice").toString());
				map.put("state", state);
				map.put("created", bizOrder.get("created").toString());
				if(state == 0){
					nList.add(map);
					nOrderPrice = nOrderPrice.add(one);
				}else if(state == 1){
					tList.add(map);
					tOrderPrice = tOrderPrice.add(one);
				}else{
					jList.add(map);
					jOrderPrice = jOrderPrice.add(one);
				}
			}
		}
		root.put("nList", nList);
		root.put("nOrderPrice", nOrderPrice);
		root.put("nSize", nList.size());
		root.put("tList", tList);
		root.put("tOrderPrice", tOrderPrice);
		root.put("tSize", tList.size());
		root.put("jList", jList);
		root.put("jOrderPrice", jOrderPrice);
		root.put("jSize", jList.size());
		root.put("size", list.size());
		return root;
	}
	
}
