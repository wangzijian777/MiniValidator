/**
 * 
 */
package demo;

import java.net.URLEncoder;

import com.jd.sns.biz.api.common.utils.HttpUtils;

/**
 * @author chenxiaoming 2014-7-9
 */
public class TestGiftOrder {
    
    public static void main(String[] args) throws Exception {
        String submitOrder = "";
//        String submitOrder = "http://bizapi.jd.com/api/order/jdPriceSubmit?thirdOrder=110045&sku=[{\"id\":569172,\"num\":1},{\"id\":102194,\"num\":1}]}&name="
//                    + URLEncoder.encode("于建明", "utf-8")
//                    + "&province=1&city=72&county=2839&address="
//                    + URLEncoder.encode("北辰世纪中心A座2层", "utf-8")
//                    + "&zip=10000&phone=&mobile=18910024183&email=liuyunfei@jd.com&token=z905HDqyPtKsFDYqPXHXCszYT&paymentType=12&isUseBalance=0";
        
        //获得商品池 7、10
        //submitOrder = "http://bizapi.jd.com/api/product/getPageNum?token=X3KwAvmXDu242VEejaodOwWzI";
        
        //获得商品池SKU
        //100001,800021,800022,800023,800024,800025,800026,800027,800028,800029,800030,800031,800032,800033,800034,800035,800036,800037,800038,800039,800040
        submitOrder = "http://bizapi.jd.com/api/product/getSku?token=X3KwAvmXDu242VEejaodOwWzI&pageNum=10";
        
        //获得商品详细信息
        submitOrder = "http://bizapi.jd.com/api/product/getDetail?token=X3KwAvmXDu242VEejaodOwWzI&sku=100001";
        
        //下单 1：货到付款，2：邮局付款，4：在线支付，5：公司转账，6：银行转账，12：月结
        submitOrder = "http://bizapi.jd.com/api/order/jdPriceSubmit?thirdOrder=11004578&sku=[{\"id\":102194,\"num\":1}]}&name="
          + URLEncoder.encode("于建明", "utf-8")
          + "&province=1&city=72&county=2839&address="
          + URLEncoder.encode("北辰世纪中心A座2层", "utf-8")
          + "&zip=10000&phone=&mobile=18910024183&email=liuyunfei@jd.com&token=Vi9lEfVkR67FRAfUiJ0QLXHrP&paymentType=1&isUseBalance=0";
        
        
        //832674
        //{"success":true,"resultMessage":"下单成功！","resultCode":null,"result":{"jdOrderId":41425454579,"orderPrice":102.00,"orderNakedPrice":87.18,"sku":[{"skuId":102194,"num":1,"category":1443,"price":102.00,"name":"yu2211","tax":17,"taxPrice":14.82,"nakedPrice":87.18}],"orderTaxPrice":14.82}}
        //{"success":true,"resultMessage":"下单成功！","resultCode":null,"result":{"jdOrderId":41425454603,"orderPrice":102.00,"orderNakedPrice":87.18,"sku":[{"skuId":102194,"num":1,"category":1443,"price":102.00,"name":"yu2211","tax":17,"taxPrice":14.82,"nakedPrice":87.18}],"orderTaxPrice":14.82}}
        //{"success":true,"resultMessage":"下单成功！","resultCode":null,"result":{"jdOrderId":41425454633,"orderPrice":102.00,"orderNakedPrice":87.18,"sku":[{"skuId":102194,"num":1,"category":1443,"price":102.00,"name":"yu2211","tax":17,"taxPrice":14.82,"nakedPrice":87.18}],"orderTaxPrice":14.82}}
        
        System.out.println(HttpUtils.httpPostData(submitOrder, null, null));
        
    }
    
}
