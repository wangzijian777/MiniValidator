package com.jd.sns.biz.test;

import javax.annotation.Resource;

import org.junit.Test;

import com.jd.sns.biz.api.service.UserService;
import com.jd.sns.biz.base.BaseTest;

public class UserServiceTest extends BaseTest{

	@Resource(name="userService")
	UserService userService;
	
	@Test
	public void redisTest(){
		userService.getUserByClientIdAndCache("test");
	}
	
	
}
