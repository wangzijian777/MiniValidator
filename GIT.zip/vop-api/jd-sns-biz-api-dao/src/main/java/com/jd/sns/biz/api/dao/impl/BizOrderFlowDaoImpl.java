package com.jd.sns.biz.api.dao.impl;

import java.util.List;
import java.util.Map;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizOrderFlowDao;
import com.jd.sns.biz.api.domain.BizOrderFlow;

public class BizOrderFlowDaoImpl extends BaseDao implements BizOrderFlowDao {

	@Override
	public List<BizOrderFlow> getBizOrderFlowByStatus(BizOrderFlow bizOrderFlow) {
		return super.queryForList("BizOrderFlow.getBizOrderFlowByStatus", bizOrderFlow);
	}

	@Override
	public void insertBizOrderFlow(BizOrderFlow bizOrderFlow) {
		super.insert("BizOrderFlow.insertBizOrderFlow", bizOrderFlow);
	}

	@Override
	public int updateBizOrderFlow(BizOrderFlow bizOrderFlow) {
		return super.update("BizOrderFlow.updateBizOrderFlow", bizOrderFlow);
	}

	@Override
	public BizOrderFlow getBizOrderFlowByOrderId(BizOrderFlow bizOrderFlow) {
		return (BizOrderFlow)super.queryForObject("BizOrderFlow.getBizOrderFlowByOrderId", bizOrderFlow);
	}

	@Override
	public void insertBizOrderFlowDetail(BizOrderFlow bizOrderFlow) {
		super.insert("BizOrderFlow.insertBizOrderFlowDetail", bizOrderFlow);
	}

}
