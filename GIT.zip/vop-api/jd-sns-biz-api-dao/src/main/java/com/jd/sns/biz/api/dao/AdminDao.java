package com.jd.sns.biz.api.dao;

public interface AdminDao {
	public void updateInvoiceState();
	public void updateSubmitState();
	public void updateCreateOrderTime();
}
