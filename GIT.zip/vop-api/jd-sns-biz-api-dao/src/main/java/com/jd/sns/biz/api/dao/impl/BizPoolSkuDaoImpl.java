package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizPoolSkuDao;
import com.jd.sns.biz.api.domain.BizPoolSku;

public class BizPoolSkuDaoImpl extends BaseDao implements BizPoolSkuDao {

	@Override
	public List selectSkuIdsByClientIdAndPageNum(BizPoolSku bizPoolSku) {
		return super.queryForList("BizPoolSku.selectSkuIdsByClientIdAndPageNum", bizPoolSku);
	}

	@Override
	public int checkSkuIdExistByClientID(BizPoolSku bizPoolSku) {
		return (Integer)super.queryForObject("BizPoolSku.checkSkuIdExistByClientID", bizPoolSku);
	}

	@Override
	public int checkSkuIdExist(long skuId) {
		return (Integer)super.queryForObject("BizPoolSku.checkSkuIdExist", skuId);
	}

	@Override
	public List getClientIdsBySkuId(long skuId) {
		return super.queryForList("BizPoolSku.getClientIdsBySkuId", skuId);
	}
}
