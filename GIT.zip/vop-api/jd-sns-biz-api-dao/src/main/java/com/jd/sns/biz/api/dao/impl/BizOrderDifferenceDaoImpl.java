package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizOrderDifferenceDao;
import com.jd.sns.biz.api.domain.BizOrderDifference;

public class BizOrderDifferenceDaoImpl extends BaseDao implements BizOrderDifferenceDao {

	@Override
	public void insertBizOrderDifference(BizOrderDifference bizOrderDifference) {
		super.insert("BizOrderDifference.insertBizOrderDifference", bizOrderDifference);
	}

	@Override
	public int updateBizOrderDifference(BizOrderDifference bizOrderDifference) {
//		return super.update("BizOrderDifference.updateBizOrderDifference", bizOrderDifference);
		return 0;
	}

	@Override
	public List<BizOrderDifference> selectBizOrderDifferences(
			BizOrderDifference bizOrderDifference) {
		return super.queryForList("BizOrderDifference.selectBizOrderDifferences", bizOrderDifference);
	}

}
