package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.DemandOrder;

public interface DemandOrderDao {
	public long insertJdDemandOrder(DemandOrder demandOrder);
	
	public int cancelJdDemandOrder(DemandOrder demandOrder);
	
	public DemandOrder selectDemandOrderById(DemandOrder demandOrder);
	
	public int checkThirdOrderExist(DemandOrder demandOrder);
	
	public List<DemandOrder> getAll();
	
	public int updateJdOrderId(DemandOrder demandOrder);
}
