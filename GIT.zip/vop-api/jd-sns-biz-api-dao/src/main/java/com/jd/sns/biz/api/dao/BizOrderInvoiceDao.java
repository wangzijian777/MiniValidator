package com.jd.sns.biz.api.dao;

import com.jd.sns.biz.api.domain.BizOrderInvoice;

public interface BizOrderInvoiceDao {
	void insertInvoice(BizOrderInvoice invoice);

	BizOrderInvoice findByOrderId(Long orderId);
}
