package com.jd.sns.biz.api.dao.impl;



import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.CreditPayTaskDao;
import com.jd.sns.biz.api.domain.CreditPayTask;

@SuppressWarnings("unchecked")
public class CreditPayTaskDaoImpl extends BaseDao implements CreditPayTaskDao {

	@Override
	public void deleteCreditPayTaskById(Long id) {
		super.delete("CreditPayTask.deleteCreditPayTaskById", id);
	}

	@Override
	public void insertCreditPayTask(CreditPayTask creditPayTask) {
		super.insert("CreditPayTask.insertCreditPayTask", creditPayTask);
	}
	
	@Override
	public int updateCreditPayTask(CreditPayTask creditPayTask) {
		return super.update("CreditPayTask.updateCreditPayTask", creditPayTask);
	}



	
}
