package com.jd.sns.biz.api.dao.oauth2.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.oauth2.Oauth2Dao;
import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.domain.User;

public class Oauth2DaoImpl extends BaseDao implements Oauth2Dao {

	@Override
	public User getUser(String client_id) {
		return (User)this.queryForObject("Oauth2.getUser", client_id);
	}

	@Override
	public void createAccessToken(AccessToken at) {
		this.insert("Oauth2.createAccessToken", at);
	}

}
