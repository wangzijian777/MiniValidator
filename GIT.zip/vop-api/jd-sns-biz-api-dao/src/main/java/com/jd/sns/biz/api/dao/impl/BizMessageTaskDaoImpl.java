package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizMessageTaskDao;
import com.jd.sns.biz.api.domain.BizMessage;
import com.jd.sns.biz.api.domain.BizMessageTask;

public class BizMessageTaskDaoImpl extends BaseDao implements BizMessageTaskDao {
	
	@Override
	public void insertBizMessageTask(BizMessageTask bizMessageTask) {
		super.insert("BizMessageTask.insertBizMessageTask", bizMessageTask);
	}

	@Override
	public List<BizMessageTask> selectBizMessageTaskList() {
		return (List<BizMessageTask>)super.queryForList("BizMessageTask.selectBizMessageTaskList");
	}

	@Override
	public int delBizMessageTaskById(long id) {
		return super.update("BizMessageTask.delBizMessageTaskById", id);
	}

	
	//admin-------------------------------------
	@Override
	public List<BizMessageTask> getAll(int type) {
		return (List<BizMessageTask>)super.queryForList("BizMessageTask.getAll", type);
	}

	@Override
	public int updateOne(BizMessageTask bizMessageTask) {
		return super.update("BizMessageTask.updateOne", bizMessageTask);
	}

}
