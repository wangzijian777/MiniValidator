package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.CheckOrderPage;

public interface BizOrderDao {
	public Long submitOrder(BizOrder bizOrder);
	
	public int updateOrderState(BizOrder bizOrder);
	
	public BizOrder selectJdOrder(BizOrder bizOrder);
	
	public BizOrder selectParentJdOrderByThirdOrder(BizOrder bizOrder);
	
	public int checkThirdOrderExist(BizOrder bizOrder);
	
	public List<BizOrder> selectChildJdOrder(BizOrder bizOrder);
	
	public int checkDemandOrderExist(BizOrder bizOrder);
	
	public int checkBizOrderExistByClientIdAndOrderId(BizOrder bizOrder);
	
	/**
	 * 获得某一日期下所有新创建订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByCreateDateAndState(CheckOrderPage page);
	
	/**
	 * 获得某一日期下所有新创建订单分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByCreateDateAndPageAndState(CheckOrderPage page);
	
	/**
	 * 获得某一日期下所有妥投或者拒收订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByTrackDateAndState(CheckOrderPage page);
	
	/**
	 * 获得某一日期下所有妥投或者拒收的分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByTrackDateAndPageAndState(CheckOrderPage page);
	
	/**
	 * 获得某天之前的所有未开发票的订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByInvoiceState(CheckOrderPage page);
	
	/**
	 * 获得某天之前的所有未开发票的订单分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByInvoiceState(CheckOrderPage page);
	
	/**
	 * 获得所有被挂起订单接口
	 * @param client_id
	 * @return
	 */
	public List getBizOrderByHangUpState(String client_id);
	
	/**
	 * 挂起订单
	 * @param clientId
	 * @param jdOrderId
	 * @param hangUpState
	 * @return
	 */
	public int updateHangUpState(BizOrder bizOrder);
	
	/**
	 * 更改订单信息
	 * @param bizOrder
	 * @return
	 */
	public int updateSubmitOrderStateById(BizOrder bizOrder);
	/**
	 * 确认订单
	 * @param bizOrder
	 * @return
	 */
	public int confirmSubmitOrder(BizOrder bizOrder);
	
	
	
	
	
	
	
	//---------admin--------------
	public List<BizOrder> getAll();
	public int updateOneOrderState(BizOrder bizOrder);

	/**
	 * 根据第三方订单单号和订单状态查询订单
	 * 
	 * @param thirdOrder
	 * @param clientId
	 */
	public List<BizOrder> selectJdOrderListByThirdOrder(String thirdOrder, String clientId);
	
}
