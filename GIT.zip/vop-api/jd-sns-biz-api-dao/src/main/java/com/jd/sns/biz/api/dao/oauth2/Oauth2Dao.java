package com.jd.sns.biz.api.dao.oauth2;

import java.util.List;

import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.domain.User;

public interface Oauth2Dao {
	public User getUser(String client_id);
	
	public void createAccessToken(AccessToken at);
}
