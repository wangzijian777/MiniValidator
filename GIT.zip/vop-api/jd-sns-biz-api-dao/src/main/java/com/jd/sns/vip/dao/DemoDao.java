package com.jd.sns.vip.dao;

/**
 * @auth lsg
 * @version 1.0.0
 */
public interface DemoDao {
	
	/**
	 * insert 
	 * @param name
	 * @param age
	 */
	public String getName(String pin);
}
