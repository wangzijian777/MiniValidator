package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizQuotaDao;
import com.jd.sns.biz.api.domain.BizQuota;

public class BizQuotaDaoImpl extends BaseDao implements BizQuotaDao {

	@Override
	public void insert(BizQuota bizQuota) {
		super.insert("BizQuota.insert", bizQuota);
	}

	@Override
	public int update(BizQuota bizQuota) {
		return super.update("BizQuota.update", bizQuota);
	}

}
