package com.jd.sns.biz.api.dao.oauth2;

import com.jd.sns.biz.api.domain.AccessToken;

public interface AccessTokenDao {
	/**
	 * 创建一个accessToken
	 * @param at
	 */
	public void createAccessToken(AccessToken at);
	/**
	 * 根据刷新的token获取accessToken信息
	 * @param refreshToken
	 * @return
	 */
	public AccessToken getAccessTokenByRefreshToken(String refreshToken);
}
