package com.jd.sns.biz.api.dao.impl;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.AdminDao;

public class AdminDaoImpl extends BaseDao implements AdminDao {

	@Override
	public void updateInvoiceState() {
		super.update("AdminDao.updateInvoiceState");
	}

	@Override
	public void updateSubmitState() {
		super.update("AdminDao.updateSubmitState");
	}

	@Override
	public void updateCreateOrderTime() {
		super.update("AdminDao.updateCreateOrderTime");
	}

}
