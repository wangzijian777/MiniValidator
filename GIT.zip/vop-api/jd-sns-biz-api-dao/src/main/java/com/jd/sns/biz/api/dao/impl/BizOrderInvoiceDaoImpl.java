package com.jd.sns.biz.api.dao.impl;

import java.util.HashMap;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizOrderInvoiceDao;
import com.jd.sns.biz.api.domain.BizOrderInvoice;

public class BizOrderInvoiceDaoImpl extends BaseDao implements BizOrderInvoiceDao {

	@Override
	public void insertInvoice(BizOrderInvoice invoice) {
		
		super.insert("bizOrderInvoice.insertEntry", invoice);
	}

	@Override
	public BizOrderInvoice findByOrderId(Long orderId) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("orderId", orderId);
		return (BizOrderInvoice) super.queryForObject("bizOrderInvoice.selectByOrderId", params);
	}

}
