package com.jd.sns.biz.api.dao;

import java.util.List;
import java.util.Map;

import com.jd.sns.biz.api.domain.BizOrderFlow;

public interface BizOrderFlowDao {
	public List<BizOrderFlow> getBizOrderFlowByStatus(BizOrderFlow bizOrderFlow);
	
	public void insertBizOrderFlow(BizOrderFlow bizOrderFlow);
	
	public void insertBizOrderFlowDetail(BizOrderFlow bizOrderFlow);
	
	public int updateBizOrderFlow(BizOrderFlow bizOrderFlow);
	
	public BizOrderFlow getBizOrderFlowByOrderId(BizOrderFlow bizOrderFlow);
}
