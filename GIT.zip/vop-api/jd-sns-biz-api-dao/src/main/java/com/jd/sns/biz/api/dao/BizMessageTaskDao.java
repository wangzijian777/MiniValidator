package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.BizMessageTask;

public interface BizMessageTaskDao {
	public void insertBizMessageTask(BizMessageTask bizMessageTask);
	public List<BizMessageTask> selectBizMessageTaskList();
	public int delBizMessageTaskById(long id);
	
	
	
	//admin------------------------------------
	public List<BizMessageTask> getAll(int type);
	public int updateOne(BizMessageTask bizMessageTask);
}
