package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.BizOrderDifference;

public interface BizOrderDifferenceDao {
	public void insertBizOrderDifference(BizOrderDifference bizOrderDifference);
	
	public int updateBizOrderDifference(BizOrderDifference bizOrderDifference);
	
	public List<BizOrderDifference> selectBizOrderDifferences(BizOrderDifference bizOrderDifference);
}
