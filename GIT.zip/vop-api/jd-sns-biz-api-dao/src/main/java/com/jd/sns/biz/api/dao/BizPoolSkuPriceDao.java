package com.jd.sns.biz.api.dao;

import com.jd.sns.biz.api.domain.BizPoolSkuPrice;

import java.math.BigDecimal;

public interface BizPoolSkuPriceDao {
	public BigDecimal getBizPriceBySkuId(long skuId);
}
