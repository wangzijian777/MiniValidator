package com.jd.sns.biz.api.dao.impl;

import java.util.List;
import java.util.Map;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizMessageDao;
import com.jd.sns.biz.api.domain.BizMessage;
import com.jd.sns.biz.api.domain.BizMessageParam;

public class BizMessageDaoImpl extends BaseDao implements BizMessageDao {

	@Override
	public List<BizMessage> getMessageList(BizMessageParam param) {
		return super.queryForList("BizMessage.getMessageList", param);
	}

	@Override
	public int delMessages(BizMessageParam param) {
		return super.delete("BizMessage.delMessages", param);
	}

	@Override
	public void insertMessage(BizMessage message) {
		super.insert("BizMessage.insertMessage", message);
	}

	
	
	// admin ---------------------------------------
	@Override
	public List<BizMessage> getAll(BizMessage message) {
		return super.queryForList("BizMessage.getAll", message);
	}

	@Override
	public int updateOne(BizMessage bizMessage) {
		return super.update("BizMessage.updateOne", bizMessage);
	}

	@Override
	public int initUpdateYn() {
		return super.update("BizMessage.initUpdateYn");
	}

	@Override
	public int initUpdateYnByType() {
		return super.update("BizMessage.initUpdateYnByType");
	}

	@Override
	public int deleteByClientId(String clientId) {
		return super.delete("BizMessage.deleteByClientId", clientId);
	}

}
