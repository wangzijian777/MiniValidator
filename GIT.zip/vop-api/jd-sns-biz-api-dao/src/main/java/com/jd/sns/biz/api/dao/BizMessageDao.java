package com.jd.sns.biz.api.dao;

import java.util.List;
import java.util.Map;

import com.jd.sns.biz.api.domain.BizMessage;
import com.jd.sns.biz.api.domain.BizMessageParam;

public interface BizMessageDao {
	public List<BizMessage> getMessageList(BizMessageParam param);
	public int delMessages(BizMessageParam param);
	public void insertMessage(BizMessage message);
	
	
	//admin-------------------------------
	
	public List<BizMessage> getAll(BizMessage message);
	public int updateOne(BizMessage bizMessage);
	public int initUpdateYn();
	public int initUpdateYnByType();
	public int deleteByClientId(String clientId);
}
