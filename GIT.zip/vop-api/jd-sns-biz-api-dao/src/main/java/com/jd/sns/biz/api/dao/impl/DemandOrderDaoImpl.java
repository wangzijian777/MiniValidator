package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.common.util.SequenceUtil;
import com.jd.sns.biz.api.dao.DemandOrderDao;
import com.jd.sns.biz.api.domain.DemandOrder;

public class DemandOrderDaoImpl extends BaseDao implements DemandOrderDao{
	
	private SequenceUtil sequenceUtil;
	
	@Override
	public long insertJdDemandOrder(DemandOrder demandOrder) {
		return (Long)super.insert("DemandOrder.insertJdDemandOrder", demandOrder);
	}

	@Override
	public int cancelJdDemandOrder(DemandOrder demandOrder) {
		return super.delete("DemandOrder.cancelJdDemandOrder", demandOrder);
	}

	@Override
	public DemandOrder selectDemandOrderById(DemandOrder demandOrder) {
		return (DemandOrder)super.queryForObject("DemandOrder.selectDemandOrderById", demandOrder);
	}

	@Override
	public int checkThirdOrderExist(DemandOrder demandOrder) {
		return (Integer)super.queryForObject("DemandOrder.checkThirdOrderExist", demandOrder);
	}
	
	@Override
	public int updateJdOrderId(DemandOrder demandOrder) {
		return super.update("DemandOrder.updateJdOrderId", demandOrder);
	}
	
	public void setSequenceUtil(SequenceUtil sequenceUtil) {
		this.sequenceUtil = sequenceUtil;
	}

	@Override
	public List<DemandOrder> getAll() {
		return (List<DemandOrder>)super.queryForList("DemandOrder.getAll");
	}

}
