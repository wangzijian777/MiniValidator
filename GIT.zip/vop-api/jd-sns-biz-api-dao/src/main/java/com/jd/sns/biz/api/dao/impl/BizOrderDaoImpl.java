package com.jd.sns.biz.api.dao.impl;

import java.util.List;
import java.util.Map;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizOrderDao;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.CheckOrderPage;

public class BizOrderDaoImpl extends BaseDao implements BizOrderDao {

	@Override
	public Long submitOrder(BizOrder bizOrder) {
		return (Long)super.insert("BizOrder.submitOrder", bizOrder);
	}

	@Override
	public int updateOrderState(BizOrder bizOrder) {
		return super.update("BizOrder.updateOrderState", bizOrder);
	}

	@Override
	public BizOrder selectJdOrder(BizOrder bizOrder) {
		return (BizOrder)super.queryForObject("BizOrder.selectJdOrder", bizOrder);
	}
	
	@Override
	public BizOrder selectParentJdOrderByThirdOrder(BizOrder bizOrder) {
		return (BizOrder)super.queryForObject("BizOrder.selectParentJdOrderByThirdOrder", bizOrder);
	}

	@Override
	public int checkThirdOrderExist(BizOrder bizOrder) {
		return (Integer)super.queryForObject("BizOrder.checkThirdOrderExist", bizOrder);
	}

	@Override
	public List<BizOrder> selectChildJdOrder(BizOrder bizOrder) {
		return super.queryForList("BizOrder.selectChildJdOrder", bizOrder);
	}

	@Override
	public int checkDemandOrderExist(BizOrder bizOrder) {
		return (Integer)super.queryForObject("BizOrder.checkDemandOrderExist", bizOrder);
	}

	@Override
	public int checkBizOrderExistByClientIdAndOrderId(BizOrder bizOrder) {
		return (Integer)super.queryForObject("BizOrder.checkBizOrderExistByClientIdAndOrderId", bizOrder);
	}
	
	@Override
	public int getTotalNumByCreateDateAndState(CheckOrderPage page) {
		return (Integer)super.queryForObject("BizOrder.getTotalNumByCreateDateAndState", page);
	}
	
	@Override
	public List getBizOrderByCreateDateAndPageAndState(CheckOrderPage page) {
		return super.queryForList("BizOrder.getBizOrderByCreateDateAndPageAndState", page);
	}
	
	@Override
	public int getTotalNumByTrackDateAndState(CheckOrderPage page) {
		return (Integer)super.queryForObject("BizOrder.getTotalNumByTrackDateAndState", page);
	}

	@Override
	public List getBizOrderByTrackDateAndPageAndState(CheckOrderPage page) {
		return super.queryForList("BizOrder.getBizOrderByTrackDateAndPageAndState", page);
	}
	
	@Override
	public int getTotalNumByInvoiceState(CheckOrderPage page) {
		return (Integer)super.queryForObject("BizOrder.getTotalNumByInvoiceState", page);
	}

	@Override
	public List getBizOrderByInvoiceState(CheckOrderPage page) {
		return super.queryForList("BizOrder.getBizOrderByInvoiceState", page);
	}

	@Override
	public List getBizOrderByHangUpState(String client_id) {
		return super.queryForList("BizOrder.getBizOrderByHangUpState", client_id);
	}
	
	@Override
	public int updateHangUpState(BizOrder bizOrder) {
		return super.update("BizOrder.updateHangUpState", bizOrder);
	}
	
	@Override
	public int updateSubmitOrderStateById(BizOrder bizOrder) {
		return super.update("BizOrder.updateSubmitOrderStateById", bizOrder);
	}
	
	@Override
	public int confirmSubmitOrder(BizOrder bizOrder) {
		return super.update("BizOrder.confirmSubmitOrder", bizOrder);
	}

	@Override
	public List<BizOrder> getAll() {
		return (List<BizOrder>)super.queryForList("BizOrder.getAll");
	}

	@Override
	public int updateOneOrderState(BizOrder bizOrder) {
		return super.update("BizOrder.updateOneOrderState", bizOrder);
	}

	@Override
	public List<BizOrder> selectJdOrderListByThirdOrder(String thirdOrder, String clientId) {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setThirdOrder(thirdOrder);
		bizOrder.setClientId(clientId);
		return super.queryForList("BizOrder.selectJdOrderListByThirdOrder", bizOrder);
	}
}
