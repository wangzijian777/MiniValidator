package com.jd.sns.vip.dao.impl;

import com.jd.sns.vip.common.base.dao.BaseDao;
import com.jd.sns.vip.common.data.switcher.DataSourceSwitcher;
import com.jd.sns.vip.dao.DemoDao;


/**
 * @auth lsg
 * @version 1.0.0
 */
public class DemoDaoImpl extends BaseDao implements DemoDao {
	//admin
	
	@Override
	public String getName(String pin) {
		return (String)this.queryForObject("Demo.getName", pin);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//------------------------------------------------------------------------------------------------------------------
	//soa
	
	
	

}
