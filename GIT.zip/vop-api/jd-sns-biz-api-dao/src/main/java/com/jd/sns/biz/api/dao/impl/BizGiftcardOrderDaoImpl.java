package com.jd.sns.biz.api.dao.impl;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizGiftcardOrderDao;
import com.jd.sns.biz.api.domain.BizGiftcardOrder;

public class BizGiftcardOrderDaoImpl extends BaseDao implements BizGiftcardOrderDao {

	@Override
	public Long submitBizGiftcardOrder(BizGiftcardOrder bizGiftcardOrder) {
		return (Long)super.insert("BizGiftcardOrder.submitBizGiftcardOrder", bizGiftcardOrder);
	}

	@Override
	public BizGiftcardOrder selectBizGiftcardOrder(BizGiftcardOrder bizGiftcardOrder) {
		return (BizGiftcardOrder)super.queryForObject("BizGiftcardOrder.selectBizGiftcardOrder", bizGiftcardOrder);
	}
	
	@Override
	public int checkThirdOrderExist(BizGiftcardOrder bizGiftcardOrder) {
		return (Integer)super.queryForObject("BizGiftcardOrder.checkThirdOrderExist", bizGiftcardOrder);
	}

	@Override
	public int updateBizGiftcardOrderState(BizGiftcardOrder bizGiftcardOrder){
		return super.update("BizGiftcardOrder.updateBizGiftcardOrderState", bizGiftcardOrder);
	}

	@Override
	public BizGiftcardOrder selectJdOrderByThirdOrder(
			BizGiftcardOrder bizGiftcardOrder) {
		return (BizGiftcardOrder)super.queryForObject("BizGiftcardOrder.selectJdOrderByThirdOrder", bizGiftcardOrder);
	}

}
