package com.jd.sns.biz.api.dao.oauth2.impl;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.oauth2.AccessTokenDao;
import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.domain.User;

public class AccessTokenDaoImpl extends BaseDao implements AccessTokenDao{

	@Override
	public void createAccessToken(AccessToken at) {
		this.insert("Oauth2.createAccessToken", at);
	}

	@Override
	public AccessToken getAccessTokenByRefreshToken(String refreshToken) {
		return (AccessToken)this.queryForObject("Oauth2.getAccessTokenByRefreshToken", refreshToken);
	}

}
