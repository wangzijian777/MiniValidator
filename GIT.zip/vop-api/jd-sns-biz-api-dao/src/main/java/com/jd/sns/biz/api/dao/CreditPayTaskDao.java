package com.jd.sns.biz.api.dao;


import java.util.List;

import com.jd.sns.biz.api.domain.CreditPayTask;


public interface CreditPayTaskDao {

	void insertCreditPayTask(CreditPayTask creditPayTask);
	
	void deleteCreditPayTaskById(Long id);
	
	int updateCreditPayTask(CreditPayTask creditPayTask);
	
	
	
}
