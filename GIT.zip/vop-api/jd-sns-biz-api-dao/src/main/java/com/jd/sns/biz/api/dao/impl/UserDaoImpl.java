package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.UserDao;
import com.jd.sns.biz.api.domain.User;

public class UserDaoImpl extends BaseDao implements UserDao {
	@Override
	public List selectAllUser(User user) {
		return this.queryForList("User.selectAllUser", user);
	}

	@Override
	public User getUserById(int id) {
		return (User)queryForObject("User.getUserById", id);
	}

	@Override
	public void createUser(User user) {
		this.insert("User.createUser", user);
	}

	@Override
	public int delUser(int id) {
		return this.delete("User.delUser", id);
	}

	@Override
	public int updateUser(User user) {
		return this.update("User.updateUser", user);
	}

	@Override
	public User getUserByClientId(String client_id) {
		return (User)this.queryForObject("User.getUserByClientId", client_id);
	}
}
