package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizInvoiceDao;
import com.jd.sns.biz.api.domain.BizInvoice;

public class BizInvoiceDaoImpl extends BaseDao implements BizInvoiceDao{

	@Override
	public void insertBizInvoice(BizInvoice bizInvoice) {
		super.insert("BizInvoice.insertBizInvoice", bizInvoice);
	}

	@Override
	public BizInvoice selectBizInvoiceByMarkId(BizInvoice bizInvoice) {
		return (BizInvoice)super.queryForObject("BizInvoice.selectBizInvoiceByMarkId", bizInvoice);
	}

	@Override
	public List getAll() {
		return super.queryForList("BizInvoice.getAll");
	}

	@Override
	public int updateBizInvoiceState(BizInvoice bizInvoice) {
		return super.update("BizInvoice.updateBizInvoiceState", bizInvoice);
	}

}
