package com.jd.sns.biz.api.dao.impl;

import java.util.List;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizPoolDao;
import com.jd.sns.biz.api.domain.BizPool;

public class BizPoolDaoImpl extends BaseDao implements BizPoolDao {

	@Override
	public List selectPageNumByClientId(String clientId) {
		return super.queryForList("BizPool.selectPageNumByClientId", clientId);
	}
	
}
