package com.jd.sns.biz.api.dao.impl;

import com.jd.common.dao.BaseDao;
import com.jd.sns.biz.api.dao.BizPoolSkuPriceDao;

import java.math.BigDecimal;

public class BizPoolSkuPriceDaoImpl extends BaseDao implements BizPoolSkuPriceDao {

	@Override
	public BigDecimal getBizPriceBySkuId(long skuId) {
		return (BigDecimal)super.queryForObject("BizPoolSkuPrice.getBizPriceBySkuId", skuId);
	}

}
