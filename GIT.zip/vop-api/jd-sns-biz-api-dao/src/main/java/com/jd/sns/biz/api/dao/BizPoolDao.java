package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.BizPool;

public interface BizPoolDao {
	public List selectPageNumByClientId(String clientId);
}
