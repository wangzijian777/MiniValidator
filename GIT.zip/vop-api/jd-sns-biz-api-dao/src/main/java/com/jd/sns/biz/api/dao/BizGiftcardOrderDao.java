package com.jd.sns.biz.api.dao;

import com.jd.sns.biz.api.domain.BizGiftcardOrder;

public interface BizGiftcardOrderDao {
	/**
	 * 添加订单
	 * @param bizOrder
	 */
	public Long submitBizGiftcardOrder(BizGiftcardOrder bizGiftcardOrder);
	
	/**
	 * 根据订单号查询礼品卡订单信息
	 * @param jdOrderId
	 * @return
	 */
	public BizGiftcardOrder selectBizGiftcardOrder(BizGiftcardOrder bizGiftcardOrder);
	
	/**
	 * 判断第三方订单号是否存在
	 * @param thirdOrder
	 * @return
	 */
	public int checkThirdOrderExist(BizGiftcardOrder bizGiftcardOrder);
	
	public int updateBizGiftcardOrderState(BizGiftcardOrder bizGiftcardOrder);
	
	public BizGiftcardOrder selectJdOrderByThirdOrder(BizGiftcardOrder bizGiftcardOrder);
}
