package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.BizPool;
import com.jd.sns.biz.api.domain.BizPoolSku;

public interface BizPoolSkuDao {
	public List selectSkuIdsByClientIdAndPageNum(BizPoolSku bizPoolSku);
	
	public int checkSkuIdExistByClientID(BizPoolSku bizPoolSku);
	
	public int checkSkuIdExist(long skuId);
	
	public List getClientIdsBySkuId(long skuId);
}
