package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.BizInvoice;

public interface BizInvoiceDao {
	public void insertBizInvoice(BizInvoice bizInvoice);
	
	public BizInvoice selectBizInvoiceByMarkId(BizInvoice bizInvoice);
	
	
	
	public int updateBizInvoiceState(BizInvoice bizInvoice);
	
	public List getAll();
}
