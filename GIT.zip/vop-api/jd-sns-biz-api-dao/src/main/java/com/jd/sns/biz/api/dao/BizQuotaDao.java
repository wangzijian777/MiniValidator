package com.jd.sns.biz.api.dao;

import java.util.List;

import com.jd.sns.biz.api.domain.BizQuota;

public interface BizQuotaDao {
	void insert(BizQuota bizQuota);
	
	int update(BizQuota bizQuota);
}
