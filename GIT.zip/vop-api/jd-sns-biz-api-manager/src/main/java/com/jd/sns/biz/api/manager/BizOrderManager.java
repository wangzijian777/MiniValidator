package com.jd.sns.biz.api.manager;

import java.util.List;

import com.jd.sns.biz.api.domain.AbstractInvoiceInfo;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.CheckOrderPage;
import com.jd.sns.biz.api.domain.IVatQualification;

public interface BizOrderManager {

	/**
	 * 添加订单
	 * @param bizOrder 订单信息
	 * @return
	 */
	public Long submitOrder(BizOrder bizOrder);
	/**
	 * 添加订单
	 * @param bizOrder 订单信息
	 * @param info 发票配送信息
	 * @param vatQualification 增票信息
	 * @return
	 */
	public Long submitOrder(BizOrder bizOrder,AbstractInvoiceInfo info,IVatQualification vatQualification);

	/**
	 * 取消订单
	 * @param jdOrderId
	 * @return
	 */
	public int cancelJdOrder(long jdOrderId, String clientId);

	/**
	 * 根据订单号查询订单信息
	 * @param jdOrderId
	 * @return
	 */
	public BizOrder selectJdOrder(String clientId, long jdOrderId);
	
	/**
	 * 根据第三方订单号，获取父订单信息
	 * @param bizOrder
	 * @return
	 */
	public BizOrder selectParentJdOrderByThirdOrder(String clientId, String thirdOrder);
	
	/**
	 * 判断第三方订单号是否存在
	 * @param thirdOrder
	 * @return
	 */
	public int checkThirdOrderExist(String thirdOrder, String clientId);
	
	/**
	 * 根据父订单查询子订单
	 * @param jdOrderId
	 * @return
	 */
	public List<BizOrder> selectChildJdOrder(long jdOrderId, String clientId);
	
	/**
	 * 判断需求单是否存在
	 * @param bizOrder
	 * @return
	 */
	public int checkDemandOrderExist(BizOrder bizOrder);
	
	/**
	 * 查看京东订单号是否存在
	 * @return
	 */
	public int checkBizOrderExistByClientIdAndOrderId(String clientId, long jdOrderId);
	
	/**
	 * 获得某一日期下所有新创建订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByCreateDateAndState(CheckOrderPage page);
	
	/**
	 * 获得某一日期下所有新创建订单分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByCreateDateAndPageAndState(CheckOrderPage page);
	
	/**
	 * 获取所有挂起订单
	 * @param client_id
	 * @return
	 */
	public List getBizOrderByHangUpState(String client_id);
	
	/**
	 * 获得某一日期下所有妥投或者拒收订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByTrackDateAndState(CheckOrderPage page);
	
	/**
	 * 获得某一日期下所有头陀或者拒收的分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByTrackDateAndPageAndState(CheckOrderPage page);
	
	/**
	 * 获得某天之前的所有未开发票的订单总数
	 * @param page
	 * @return
	 */
	public int getTotalNumByInvoiceState(CheckOrderPage page);
	
	/**
	 * 获得某天之前的所有未开发票的订单分页列表
	 * @param page
	 * @return
	 */
	public List getBizOrderByInvoiceState(CheckOrderPage page);
	/**
	 * 确认订单
	 * @param bizOrder
	 * @return
	 */
	public int confirmSubmitOrder(BizOrder bizOrder);
	
	
	/**
	 * 挂起订单
	 * @param clientId
	 * @param jdOrderId
	 * @param hangUpState
	 * @return
	 */
	public int updateHangUpState(String clientId, long jdOrderId, int hangUpState);
	
	public int updateOrderState(BizOrder bizOrder);
	
	public int updateSubmitOrderStateById(BizOrder bizOrder);
	
	/**
	 * 根据第三方订单号查询子订单列表
	 * 
	 * @param thirdOrder
	 * @param clientId
	 * @return
	 */
	public List<BizOrder> selectJdOrderListByThirdOrder(String thirdOrder, String clientId);
}
