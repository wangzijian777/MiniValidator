package com.jd.sns.biz.api.manager.impl;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.BizGiftcardOrderDao;
import com.jd.sns.biz.api.domain.BizGiftcardOrder;
import com.jd.sns.biz.api.manager.BizGiftcardOrderManager;

@Service(value="bizGiftcardOrderManager")
public class BizGiftcardOrderManagerImpl implements BizGiftcardOrderManager {

	private BizGiftcardOrderDao bizGiftcardOrderDao;
	
	@Override
	public Long submitBizGiftcardOrder(BizGiftcardOrder bizGiftcardOrder) {
		return bizGiftcardOrderDao.submitBizGiftcardOrder(bizGiftcardOrder);
	}

	@Override
	public BizGiftcardOrder selectBizGiftcardOrder(BizGiftcardOrder bizGiftcardOrder) {
		return bizGiftcardOrderDao.selectBizGiftcardOrder(bizGiftcardOrder);
	}

	@Override
	public int checkThirdOrderExist(BizGiftcardOrder bizGiftcardOrder) {
		return bizGiftcardOrderDao.checkThirdOrderExist(bizGiftcardOrder);
	}

	@Override
	public int updateBizGiftcardOrderState(BizGiftcardOrder bizGiftcardOrder) {
		return bizGiftcardOrderDao.updateBizGiftcardOrderState(bizGiftcardOrder);
	}
	
	@Override
	public BizGiftcardOrder selectJdOrderByThirdOrder(BizGiftcardOrder bizGiftcardOrder) {
		return bizGiftcardOrderDao.selectJdOrderByThirdOrder(bizGiftcardOrder);
	}
	
	public void setBizGiftcardOrderDao(BizGiftcardOrderDao bizGiftcardOrderDao) {
		this.bizGiftcardOrderDao = bizGiftcardOrderDao;
	}


}
