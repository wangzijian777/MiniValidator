package com.jd.sns.biz.api.manager;

import java.util.List;

import com.jd.sns.biz.api.domain.BizMessage;

public interface BizMessageManager {
	public List<BizMessage> getMessageList(String clientId, List<Integer> types);
	public int delMessages(String clientId, List ids);
	public void insertMessage(BizMessage message);
}
