package com.jd.sns.biz.api.manager.impl;


import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.CreditPayTaskDao;
import com.jd.sns.biz.api.domain.CreditPayTask;
import com.jd.sns.biz.api.manager.CreditPayTaskManager;


@Service(value = "creditPayTaskManager")
public class CreditPayTaskManagerImpl implements CreditPayTaskManager {

	private CreditPayTaskDao creditPayTaskDao;
	
	@Override
	public void deleteCreditPayTaskById(Long id) {
		creditPayTaskDao.deleteCreditPayTaskById(id);
	}

	@Override
	public void insertCreditPayTask(CreditPayTask creditPayTask) {
		creditPayTaskDao.insertCreditPayTask(creditPayTask);
	}


	@Override
	public int updateCreditPayTask(CreditPayTask creditPayTask) {
		return creditPayTaskDao.updateCreditPayTask(creditPayTask);
	}

	public void setCreditPayTaskDao(CreditPayTaskDao creditPayTaskDao) {
		this.creditPayTaskDao = creditPayTaskDao;
	}
	
}
