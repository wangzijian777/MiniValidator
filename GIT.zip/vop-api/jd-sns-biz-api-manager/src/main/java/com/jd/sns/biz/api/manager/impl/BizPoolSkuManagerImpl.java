package com.jd.sns.biz.api.manager.impl;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.management.RuntimeErrorException;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.jd.ka.wareplatform.sdk.service.SkuPoolQueryService;
import com.jd.ka.wareplatform.sdk.vo.WarePlatResult;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.domain.BizPoolSku;
import com.jd.sns.biz.api.manager.BizPoolSkuManager;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="bizPoolSkuManager")
public class BizPoolSkuManagerImpl implements BizPoolSkuManager {
	@Resource
	private SkuPoolQueryService skuPoolQueryService;
	private static final int NOT_EXIST=0;
	private static final int EXIST=1;
	
	@Override
	public List<String> selectSkuIdsByClientIdAndPageNum(BizPoolSku bizPoolSku)  throws Exception{
		try {
			LogTypeEnum.DEFAULT.info("获取商品池商品列表开始,bizPoolSku={}",APIUtils.parseObject2Json(bizPoolSku));
		} catch (Exception e) {
			LogTypeEnum.DEFAULT.error(e,"解析入参失败！");
		}
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_SKUS_BY_CLIENTID_BIZID, true, true);
		WarePlatResult<String> result;
		try {
			result = skuPoolQueryService.getSkusByClientIdAndBizId(bizPoolSku.getClientId(), String.valueOf(bizPoolSku.getPoolId()));
		} catch (Exception e1) {
			LogTypeEnum.DEFAULT.error(e1,"获取商品池商品列表服务异常！clientId={},poolID={}",bizPoolSku.getClientId(),bizPoolSku.getPoolId());
			Profiler.functionError(callerInfo);
			throw e1;
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		try {
			LogTypeEnum.DEFAULT.info("skuPoolQueryService.getSkusByClientIdAndBizId返回结果result={}",APIUtils.parseObject2Json(result));
		} catch (Exception e2) {
			LogTypeEnum.DEFAULT.error(e2,"打印result信息失败！");
		}
		if(result==null){
			LogTypeEnum.DEFAULT.error("获取商品池商品列表返回对象为空!clientId={},poolID={}",bizPoolSku.getClientId(),bizPoolSku.getPoolId());
			throw new RuntimeException("获取商品池商品列表返回对象为空");
		}
		if(!result.isSuccess()){
			LogTypeEnum.DEFAULT.error("获取商品池商品列表失败,原因={},clientId={},poolID={}",result.getMessage(),bizPoolSku.getClientId(),bizPoolSku.getPoolId());
			return null;
		}
		LogTypeEnum.DEFAULT.info("获取商品池商品列表成功！");
		String originDate=result.getData();
		if (StringUtils.isEmpty(originDate))
			return null;
		List<String> targetList=Arrays.asList(originDate.split(","));
		return targetList;
	}
	
	@Override
	public int checkSkuIdExistByClientID(String clientId, long skuId)  throws Exception{
		LogTypeEnum.DEFAULT.info("查询该用户是否可购买该商品开始,clentId={},skuId={}",clientId,skuId);
		Set<Long> skuIdSet=new HashSet<Long>();
		skuIdSet.add(skuId);
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_SKUS_IN_POOL_BY_CLIENTID, true, true);
		WarePlatResult<List<Long>> result;
		try {
			result = skuPoolQueryService.checkSkusInPoolByClientId(skuIdSet, clientId);
		} catch (Exception e1) {
			LogTypeEnum.DEFAULT.error(e1,"查询该用户是否可购买该商品服务异常！");
			Profiler.functionError(callerInfo);
			throw e1;
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		try {
			LogTypeEnum.DEFAULT.info("skuPoolQueryService.checkSkusInPoolByClientId返回结果result={}",APIUtils.parseObject2Json(result));
		} catch (Exception e2) {
			LogTypeEnum.DEFAULT.error(e2,"打印result信息失败！");
		}
		if(result==null){
			LogTypeEnum.DEFAULT.error("查询该用户是否可购买该商品返回对象为空,skuId:{}",skuId);
			throw new RuntimeException("查询该用户是否可购买该商品返回对象为空,skuId:"+skuId);
		}
		if(!result.isSuccess()){
			LogTypeEnum.DEFAULT.error("查询该用户是否可购买该商品失败,原因={},skuId:{}",result.getMessage(),skuId);
			//与zsb沟通，这个应该返回不存在
			return NOT_EXIST;
		}
		LogTypeEnum.DEFAULT.info("查询该用户是否可购买该商品成功！");
		return EXIST;		
	}
	
	@Override
	public int checkSkuIdExist(long skuId) throws Exception {
		LogTypeEnum.DEFAULT.error("检查商品是否为大客户商品开始,skuId={}",skuId);
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_SKUID_EXIST, true, true);
		WarePlatResult<Boolean> result;
		try {
			result = skuPoolQueryService.checkSkuIsBigClient(String.valueOf(skuId));
		} catch (Exception e1) {
			LogTypeEnum.DEFAULT.error(e1,"检查商品是否为大客户商品服务异常！skuId={}",skuId);
			Profiler.functionError(callerInfo);
			throw e1;
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		try {
			LogTypeEnum.DEFAULT.info("skuPoolQueryService.checkSkuIsBigClient返回结果result={}",APIUtils.parseObject2Json(result));
		} catch (Exception e2) {
			LogTypeEnum.DEFAULT.error(e2,"打印result信息失败！skuId={}",skuId);
		}
		if(result==null){
			LogTypeEnum.DEFAULT.error("检查商品是否为大客户商品返回对象为空,skuId={}",skuId);
			throw new RuntimeException("检查商品是否为大客户商品返回对象为空");
		}
		if(!result.isSuccess()){
			LogTypeEnum.DEFAULT.error("检查商品是否为大客户商品失败,原因={},skuId={}",result.getMessage(),skuId);
			return NOT_EXIST;
		}
		LogTypeEnum.DEFAULT.info("检查商品是否为大客户商品成功！skuId={}",skuId);
		Boolean data=result.getData();
		if(data) return EXIST;
		else return NOT_EXIST;
	}
	
	@Override
	public List<String> getClientIdsBySkuId(long skuId) throws Exception {
		LogTypeEnum.DEFAULT.info("获取商品归属clientId列表开始,skuId={}",skuId);
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_CLIENTIDS_BY_SKUID, true, true);
		WarePlatResult<List<String>> result;
		try {
			result = skuPoolQueryService.getClientIdsBySkuId(String.valueOf(skuId));
		} catch (Exception e1) {
			LogTypeEnum.DEFAULT.error(e1,"获取商品归属clientId列表服务异常！skuId={}",skuId);
			Profiler.functionError(callerInfo);
			throw e1;
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		try {
			LogTypeEnum.DEFAULT.info("skuPoolQueryService.getClientIdsBySkuId返回结果result={}",APIUtils.parseObject2Json(result));
		} catch (Exception e2) {
			LogTypeEnum.DEFAULT.error(e2,"打印result信息失败！skuId={}",skuId);
		}
		if(result==null){
			LogTypeEnum.DEFAULT.error("获取商品归属clientId列表返回对象为空,skuId={}",skuId);
			throw new RuntimeException("获取商品归属clientId列表返回对象为空");
		}
		if(!result.isSuccess()){
			LogTypeEnum.DEFAULT.error("获取商品归属clientId列表失败,失败原因={},skuId={}",result.getMessage(),skuId);
			return null;
		}
		LogTypeEnum.DEFAULT.info("获取商品归属clientId列表成功！");
		return result.getData();		
	}
	
	/**
	 * 
	 * @param skuIds
	 * @param clientId
	 * @return
	 * @throws Exception
	 */
	public List<Long> checkCanBySkuIds(Set<Long> skuIds,String clientId) {
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.CHECK_SKUS_BATCH_IN_POOL_BY_CLIENTID, true, true);
		LogTypeEnum.DEFAULT.info("skuPoolQueryService.checkSkusInPoolByClientId入参:skuIds={},clientId={}",APIUtils.parseObject2Json(skuIds),clientId);
		WarePlatResult<List<Long>> result;
		try {
			result = skuPoolQueryService.checkSkusInPoolByClientId(skuIds, clientId.trim());
		} catch (Exception e1) {
			LogTypeEnum.DEFAULT.error(e1,"查询该用户是否可购买该商品服务异常！skuIds="+skuIds);
			Profiler.functionError(callerInfo);
			throw new RuntimeException("查询skuid="+skuIds+"是否是该用户可购买商品服务器异常",e1);
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
		LogTypeEnum.DEFAULT.info("skuPoolQueryService.checkSkusInPoolByClientId返回结果result={}",APIUtils.parseObject2Json(result));

		if(result==null){
			LogTypeEnum.DEFAULT.error("查询该用户是否可购买该商品返回对象为空");
			throw new RuntimeException("查询该用户是否可购买该商品返回对象为空");
		}
		if(!result.isSuccess()){
			// TODO yz 考虑日志量先把这里屏蔽掉，后续在加上；
			LogTypeEnum.DEFAULT.info("存在部分（或全部）商品用户不能购买,不能购买的商品={}，原因={}",APIUtils.parseObject2Json(result.getData()),result.getMessage());
			List<Long> list=result.getData();
			return list;
		}
		return Collections.emptyList();//校验通过则返回空	
	}
}
