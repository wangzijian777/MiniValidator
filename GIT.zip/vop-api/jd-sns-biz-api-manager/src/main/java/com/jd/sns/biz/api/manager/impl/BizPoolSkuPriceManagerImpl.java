package com.jd.sns.biz.api.manager.impl;

import org.springframework.stereotype.Service;

import com.jd.common.util.Money;
import com.jd.sns.biz.api.dao.BizPoolSkuPriceDao;
import com.jd.sns.biz.api.manager.BizPoolSkuPriceManager;

import java.math.BigDecimal;

@Service(value="bizPoolSkuPriceManager")
public class BizPoolSkuPriceManagerImpl implements BizPoolSkuPriceManager {

	private BizPoolSkuPriceDao bizPoolSkuPriceDao;
	@Override
	public BigDecimal getBizPriceBySkuId(long skuId) {
		Money m= new Money(bizPoolSkuPriceDao.getBizPriceBySkuId(skuId));
		return new BigDecimal(m.toString());
	}
	public void setBizPoolSkuPriceDao(BizPoolSkuPriceDao bizPoolSkuPriceDao) {
		this.bizPoolSkuPriceDao = bizPoolSkuPriceDao;
	}

}
