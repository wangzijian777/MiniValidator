package com.jd.sns.vip.manager.impl;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.jd.common.manager.BaseManager;
import com.jd.sns.vip.dao.DemoDao;
import com.jd.sns.vip.manager.DemoManager;


/**
 * @auth lsg
 * @version 1.0.0
 */
public class DemoManagerImpl extends BaseManager implements DemoManager {
	
	private PlatformTransactionManager vipMysqlTransactionManager;
	private DemoDao demoDao;
	
	@Override
	public String getName(final String pin) {
//		return new TransactionTemplate(vipMysqlTransactionManager).execute(new TransactionCallback<String>() {
//			@Override
//			public String doInTransaction(TransactionStatus status) {
				return demoDao.getName(pin);
//			}
//		});
	}

	public void setVipMysqlTransactionManager(
			PlatformTransactionManager vipMysqlTransactionManager) {
		this.vipMysqlTransactionManager = vipMysqlTransactionManager;
	}

	public void setDemoDao(DemoDao demoDao) {
		this.demoDao = demoDao;
	}
}
