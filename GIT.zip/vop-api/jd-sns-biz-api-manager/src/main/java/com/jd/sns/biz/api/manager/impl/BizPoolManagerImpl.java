package com.jd.sns.biz.api.manager.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.jd.ka.wareplatform.sdk.service.SkuPoolQueryService;
import com.jd.ka.wareplatform.sdk.vo.WarePlatResult;
import com.jd.ka.wareplatform.sdk.vo.res.SkuPoolResVo;
import com.jd.sns.biz.api.common.utils.APIUtils;
import com.jd.sns.biz.api.common.utils.LogTypeEnum;
import com.jd.sns.biz.api.constant.UMPFunctionKeyConstant;
import com.jd.sns.biz.api.manager.BizPoolManager;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
/**
 * 商品池manager:改为调用商品池服务
 * @author cdwangyong3
 *
 */
@Service(value="bizPoolManager")
public class BizPoolManagerImpl implements BizPoolManager {
	@Resource
	private SkuPoolQueryService skuPoolQueryService;

	@Override
	public List<Object> selectPageNumByClientId(String clientId) throws Exception {
		LogTypeEnum.DEFAULT.info("获取商品池列表开始,client={}",clientId);
		CallerInfo callerInfo=Profiler.registerInfo(UMPFunctionKeyConstant.GET_SKU_POOLS_BY_CLIENTID, true, true);
		WarePlatResult<List<SkuPoolResVo>> result;
		try {
			result = skuPoolQueryService.getSkuPoolsByClientId(clientId);
		} catch (Exception e1) {
			LogTypeEnum.DEFAULT.error(e1,"获取商品池列表服务异常！");
			Profiler.functionError(callerInfo);
			throw e1;
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
	
		if(result==null){
			LogTypeEnum.DEFAULT.error("获取商品池列表返回对象为空");
			throw new RuntimeException("获取商品池列表返回对象为空");
		}
		if(!result.isSuccess()){
			LogTypeEnum.DEFAULT.error("获取商品池列表失败,失败原因={}",result.getMessage());
			return null;
		}
		LogTypeEnum.DEFAULT.info("获取商品池列表成功！");
		List<SkuPoolResVo> originList = result.getData();
		ArrayList<Object> targetList = new ArrayList<Object>();
		if (CollectionUtils.isEmpty(originList))
			return null;
		for (SkuPoolResVo e : originList) {
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("page_num", e.getBizId());
			map.put("name", e.getName());
			targetList.add(map);
		}
		return targetList;
	}
}
