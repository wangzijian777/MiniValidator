package com.jd.sns.biz.api.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.BizOrderDifferenceDao;
import com.jd.sns.biz.api.domain.BizOrderDifference;
import com.jd.sns.biz.api.manager.BizOrderDifferenceManager;

@Service(value="bizOrderDifferenceManager")
public class BizOrderDifferenceManagerImpl implements BizOrderDifferenceManager {

	private BizOrderDifferenceDao bizOrderDifferenceDao;
	
	@Override
	public void insertBizOrderDifference(BizOrderDifference bizOrderDifference) {
		bizOrderDifferenceDao.insertBizOrderDifference(bizOrderDifference);
	}

	@Override
	public int updateBizOrderDifference(BizOrderDifference bizOrderDifference) {
		return bizOrderDifferenceDao.updateBizOrderDifference(bizOrderDifference);
	}

	@Override
	public List<BizOrderDifference> selectBizOrderDifferences(
			BizOrderDifference bizOrderDifference) {
		return bizOrderDifferenceDao.selectBizOrderDifferences(bizOrderDifference);
	}

	public void setBizOrderDifferenceDao(BizOrderDifferenceDao bizOrderDifferenceDao) {
		this.bizOrderDifferenceDao = bizOrderDifferenceDao;
	}

}
