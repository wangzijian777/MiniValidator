package com.jd.sns.biz.api.manager.impl;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.BizInvoiceDao;
import com.jd.sns.biz.api.domain.BizInvoice;
import com.jd.sns.biz.api.manager.BizInvoiceManager;

@Service(value="bizInvoiceManager")
public class BizInvoiceManagerImpl implements BizInvoiceManager {

	private BizInvoiceDao bizInvoiceDao;
	
	@Override
	public void insertBizInvoice(BizInvoice bizInvoice) {
		bizInvoiceDao.insertBizInvoice(bizInvoice);
	}

	@Override
	public BizInvoice selectBizInvoiceByMarkId(String clientId, String markId) {
		BizInvoice bizInvoice = new BizInvoice();
		bizInvoice.setClientId(clientId);
		bizInvoice.setMarkId(markId);
		return bizInvoiceDao.selectBizInvoiceByMarkId(bizInvoice);
	}

	public void setBizInvoiceDao(BizInvoiceDao bizInvoiceDao) {
		this.bizInvoiceDao = bizInvoiceDao;
	}

}
