package com.jd.sns.biz.api.manager;

import com.jd.sns.biz.api.domain.BizGiftcardOrder;
import com.jd.sns.biz.api.domain.BizOrder;

public interface BizGiftcardOrderManager {
	/**
	 * 添加订单
	 * @param bizOrder
	 */
	public Long submitBizGiftcardOrder(BizGiftcardOrder bizGiftcardOrder);
	
	/**
	 * 根据订单号查询礼品卡订单信息
	 * @param jdOrderId
	 * @return
	 */
	public BizGiftcardOrder selectBizGiftcardOrder(BizGiftcardOrder bizGiftcardOrder);
	/**
	 * 根据第三方订单号获取订单详细信息
	 * @param thirdOrder
	 * @return
	 */
	public BizGiftcardOrder selectJdOrderByThirdOrder(BizGiftcardOrder bizGiftcardOrder);
	
	/**
	 * 判断第三方订单号是否存在
	 * @param thirdOrder
	 * @return
	 */
	public int checkThirdOrderExist(BizGiftcardOrder bizGiftcardOrder);
	
	public int updateBizGiftcardOrderState(BizGiftcardOrder bizGiftcardOrder);
}
