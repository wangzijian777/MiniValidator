package com.jd.sns.biz.api.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.BizQuotaDao;
import com.jd.sns.biz.api.domain.BizQuota;
import com.jd.sns.biz.api.manager.BizQuotaManager;

@Service(value="bizQuotaManager")
public class BizQuotaManagerImpl implements BizQuotaManager {

	private BizQuotaDao bizQuotaDao;
	
	@Override
	public void insert(BizQuota bizQuota) {
		bizQuotaDao.insert(bizQuota);
	}

	@Override
	public int update(BizQuota bizQuota) {
		return bizQuotaDao.update(bizQuota);
	}

	public void setBizQuotaDao(BizQuotaDao bizQuotaDao) {
		this.bizQuotaDao = bizQuotaDao;
	}
	
}
