package com.jd.sns.biz.api.manager.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.BizMessageDao;
import com.jd.sns.biz.api.domain.BizMessage;
import com.jd.sns.biz.api.domain.BizMessageParam;
import com.jd.sns.biz.api.manager.BizMessageManager;

@Service(value="bizMessageManager")
public class BizMessageManagerImpl implements BizMessageManager {

	private BizMessageDao bizMessageDao;
	@Override
	public List<BizMessage> getMessageList(String clientId, List<Integer> types) {
		BizMessageParam param = new BizMessageParam();
		param.setClientId(clientId);
		param.setIds(types);
		return bizMessageDao.getMessageList(param);
	}

	@Override
	public int delMessages(String clientId, List ids) {
		BizMessageParam param = new BizMessageParam();
		param.setClientId(clientId);
		param.setIds(ids);
		return bizMessageDao.delMessages(param);
	}

	@Override
	public void insertMessage(BizMessage message) {
		bizMessageDao.insertMessage(message);
	}

	public void setBizMessageDao(BizMessageDao bizMessageDao) {
		this.bizMessageDao = bizMessageDao;
	}

	
}
