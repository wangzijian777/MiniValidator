package com.jd.sns.biz.api.manager;

import java.util.List;
import java.util.Set;

import com.jd.sns.biz.api.domain.BizPool;
import com.jd.sns.biz.api.domain.BizPoolSku;

public interface BizPoolSkuManager {
	/**
	 * 通过clientId和poolId获取商品池商品:Y
	 * @param bizPoolSku
	 * @return
	 */
	public List selectSkuIdsByClientIdAndPageNum(BizPoolSku bizPoolSku) throws Exception;
	
	/**
	 * 判断客户是否可以购买该skuId商品  Y
	 * @param bizPoolSku
	 * @return
	 */
	public int checkSkuIdExistByClientID(String clientId, long skuId)  throws Exception;
	
	/**
	 * 检测商品是否为大客户商品 by wy Y  没有地方调用
	 * @param skuId
	 * @return
	 */
	public int checkSkuIdExist(long skuId) throws Exception ;
	
	/**
	 * 根据商品id，获取该商品都有哪些商家
	 * @return
	 */
	public List getClientIdsBySkuId(long skuId) throws Exception ;
	
	/**
	 * 
	 * @param skuIds
	 * @param clientId
	 * @return 返回不能购买的商品sku列表
	 */
	public List<Long> checkCanBySkuIds(Set<Long> skuIds,String clientId);
}
