package com.jd.sns.biz.api.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.UserDao;
import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.manager.UserManager;

@Service(value="userManager")
public class UserManagerImpl implements UserManager {

	private UserDao userDao;
	
	@Override
	public List selectAllUser(User user) {
		return userDao.selectAllUser(user);
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	@Override
	public User getUserById(int id) {
		return userDao.getUserById(id);
	}

	@Override
	public void createUser(User user) {
		userDao.createUser(user);
	}

	@Override
	public int delUser(int id) {
		return userDao.delUser(id);
	}

	@Override
	public int updateUser(User user) {
		return userDao.updateUser(user);
	}

	@Override
	public User getUserByClientId(String client_id) {
		return userDao.getUserByClientId(client_id);
	}

	
}
