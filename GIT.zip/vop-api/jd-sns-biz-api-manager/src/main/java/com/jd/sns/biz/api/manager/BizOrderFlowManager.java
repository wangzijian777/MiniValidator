package com.jd.sns.biz.api.manager;

import java.util.List;

import com.jd.sns.biz.api.domain.BizOrderFlow;


public interface BizOrderFlowManager {
	public List<BizOrderFlow> getBizOrderFlowByStatus(String clientId, int status);
	
	public void insertBizOrderFlow(BizOrderFlow bizOrderFlow);
	
	public void insertBizOrderFlowDetail(BizOrderFlow bizOrderFlow);
	
	public int updateBizOrderFlow(BizOrderFlow bizOrderFlow);
	
	public BizOrderFlow getBizOrderFlowByOrderId(String clientId, long orderId);
}

