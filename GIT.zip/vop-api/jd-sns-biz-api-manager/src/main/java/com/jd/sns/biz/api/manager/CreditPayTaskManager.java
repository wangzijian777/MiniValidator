package com.jd.sns.biz.api.manager;


import com.jd.sns.biz.api.domain.CreditPayTask;


public interface CreditPayTaskManager {

	void insertCreditPayTask(CreditPayTask creditPayTask);
	
	void deleteCreditPayTaskById(Long id);
	
	int updateCreditPayTask(CreditPayTask creditPayTask);
	
	
}
