package com.jd.sns.vip.manager;

/**
 * @auth lsg
 * @version 1.0.0
 */
public interface DemoManager {
	
	/**
	 * echo name
	 * @param name
	 * @return
	 */
	public String getName(String pin);
	
}
