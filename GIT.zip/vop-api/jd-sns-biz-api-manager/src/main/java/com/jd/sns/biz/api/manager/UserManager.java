package com.jd.sns.biz.api.manager;

import java.util.List;

import com.jd.sns.biz.api.domain.User;

public interface UserManager {
	public List selectAllUser(User user);
	
	public User getUserById(int id);
	
	public void createUser(User user);
	
	public int delUser(int id);
	
	public int updateUser(User user);	
	
	public User getUserByClientId(String client_id);
}
