package com.jd.sns.biz.api.manager;

import com.jd.sns.biz.api.domain.DemandOrder;

public interface DemandOrderManager {
	public long insertJdDemandOrder(DemandOrder demandOrder);

	public int cancelJdDemandOrder(long jdDemandOrder, String clientId);

	public DemandOrder selectDemandOrderById(long jdDemandOrder, String clientId);
	
	public int checkThirdOrderExist(String thirdOrder, String clientId);

	public int updateJdOrderId(DemandOrder demandOrder);
	
}
