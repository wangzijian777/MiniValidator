package com.jd.sns.biz.api.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionOperations;
import org.springframework.transaction.support.TransactionTemplate;




import com.jd.sns.biz.api.dao.BizOrderDao;
import com.jd.sns.biz.api.dao.BizOrderInvoiceDao;
import com.jd.sns.biz.api.domain.AbstractInvoiceInfo;
import com.jd.sns.biz.api.domain.BizOrder;
import com.jd.sns.biz.api.domain.BizOrderInvoice;
import com.jd.sns.biz.api.domain.CheckOrderPage;
import com.jd.sns.biz.api.domain.IVatQualification;
import com.jd.sns.biz.api.manager.BizOrderManager;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Service(value="bizOrderManager")
public class BizOrderManagerImpl implements BizOrderManager {

	private BizOrderDao bizOrderDao;
	private BizOrderInvoiceDao bizOrderInvoiceDao;
	private PlatformTransactionManager transactionManager;

	@Override
	public Long submitOrder(final BizOrder bizOrder,final AbstractInvoiceInfo info,final IVatQualification vatQualification) {		
		CallerInfo info_submit = Profiler.registerInfo("web.sns.bizapi.BizOrderManagerImpl.submitOrder", true, true);
		TransactionTemplate transactionTemplate = new TransactionTemplate(transactionManager);	
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {			
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				Long id = bizOrderDao.submitOrder(bizOrder);
				bizOrder.setId(id);
				insertInvoice(bizOrder,info,vatQualification);				
			}
		});
		Profiler.registerInfoEnd(info_submit);	
		return bizOrder.getId();
	}
	@Override
	public Long submitOrder(BizOrder bizOrder) {
		CallerInfo info_submit = Profiler.registerInfo("web.sns.bizapi.BizOrderManagerImpl.submitOrder", true, true);
		Long id = bizOrderDao.submitOrder(bizOrder);
		bizOrder.setId(id);		
		Profiler.registerInfoEnd(info_submit);
		return id;
	}
	//
	private void insertInvoice(BizOrder order, AbstractInvoiceInfo info,IVatQualification qualification) {
		
		//如果不需要开票，直接返回
		if(order.getInvoiceState()==null || order.getInvoiceState()!=1){
			return ;
		}
		
		BizOrderInvoice orderInvoice = new BizOrderInvoice();
		//设置订单id
		orderInvoice.setOrderId(order.getId());
		//订单发票类型
		orderInvoice.setInvoiceType(order.getInvoiceType());
		//pin
		orderInvoice.setPin(order.getPin());
	
		//普通发票
		if(order.getInvoiceType()!=null&&order.getInvoiceType()==1)
		{
			//订单发票内容类型
			orderInvoice.setInvoiceContentType(order.getInvoiceContent());
			//抬头 公司还是个人
			orderInvoice.setSeletedInvoiceTitle(order.getSelectedInvoiceTitle());	
			//订单公司名称
			orderInvoice.setCompanyName(order.getCompanyName());
		}
		//增票
		if (order.getInvoiceType()!=null&&order.getInvoiceType().intValue() == 2) {
			//公司名称
			orderInvoice.setVatCompanyName(qualification.getCompany());
			// 纳税人标识号
			orderInvoice.setCode(qualification.getTaxId());
			//注册地址			
			orderInvoice.setRegAddr(qualification.getAddress());
			//注册电话
			orderInvoice.setRegPhone(qualification.getPhone());
			//注册银行
			orderInvoice.setRegBank(qualification.getBank());
			//注册银行
			orderInvoice.setRegBankAccount(qualification.getAccount());
			
			//收票人	信息
			//姓名
			orderInvoice.setConsigneeName(info.getInvoiceName());
			//电话
			orderInvoice.setPhone(info.getInvoicePhone());
			//省
			orderInvoice.setProvinceId(info.getInvoiceProvice());
			//市
			orderInvoice.setCityId(info.getInvoiceCity());
			//县
			orderInvoice.setCountyId(info.getInvoiceCounty());
			//镇
			orderInvoice.setTownId(info.getInvoiceTown());
			//地址
			orderInvoice.setAddress(info.getInvoiceAddress());	
		}
		
		bizOrderInvoiceDao.insertInvoice(orderInvoice);
	}

	@Override
	public int cancelJdOrder(long jdOrderId, String clientId) {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setJdOrderId(jdOrderId);
		bizOrder.setClientId(clientId);
		bizOrder.setOrderState(0);
		return bizOrderDao.updateOrderState(bizOrder);
	}

	@Override
	public BizOrder selectJdOrder(String clientId, long jdOrderId) {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setClientId(clientId);
		bizOrder.setJdOrderId(jdOrderId);
		return bizOrderDao.selectJdOrder(bizOrder);
	}
	
	@Override
	public int checkThirdOrderExist(String thirdOrder, String clientId) {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setThirdOrder(thirdOrder);
		bizOrder.setClientId(clientId);
		return bizOrderDao.checkThirdOrderExist(bizOrder);
	}

	@Override
	public List<BizOrder> selectChildJdOrder(long jdOrderId, String clientId) {
		CallerInfo info = Profiler.registerInfo("web.sns.bizapi.BizOrderManagerImpl.selectChildJdOrder", true, true);
		BizOrder bizOrder = new BizOrder();
		bizOrder.setJdOrderId(jdOrderId);
		bizOrder.setClientId(clientId);
		List<BizOrder> list = bizOrderDao.selectChildJdOrder(bizOrder);
		Profiler.registerInfoEnd(info);
		return list;
	}
	
	@Override
	public int checkDemandOrderExist(BizOrder bizOrder) {
		return bizOrderDao.checkDemandOrderExist(bizOrder);
	}
	
	@Override
	public int checkBizOrderExistByClientIdAndOrderId(String clientId, long jdOrderId) {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setClientId(clientId);
		bizOrder.setJdOrderId(jdOrderId);
		return this.bizOrderDao.checkBizOrderExistByClientIdAndOrderId(bizOrder);
	}
	
	@Override
	public int getTotalNumByCreateDateAndState(CheckOrderPage page) {
		return this.bizOrderDao.getTotalNumByCreateDateAndState(page);
	}

	@Override
	public List getBizOrderByCreateDateAndPageAndState(CheckOrderPage page) {
		return this.bizOrderDao.getBizOrderByCreateDateAndPageAndState(page);
	}
	
	@Override
	public List getBizOrderByHangUpState(String client_id) {
		return this.bizOrderDao.getBizOrderByHangUpState(client_id);
	}

	@Override
	public int getTotalNumByTrackDateAndState(CheckOrderPage page) {
		return bizOrderDao.getTotalNumByTrackDateAndState(page);
	}

	@Override
	public List getBizOrderByTrackDateAndPageAndState(CheckOrderPage page) {
		return bizOrderDao.getBizOrderByTrackDateAndPageAndState(page);
	}
	
	@Override
	public int getTotalNumByInvoiceState(CheckOrderPage page) {
		return bizOrderDao.getTotalNumByInvoiceState(page);
	}

	@Override
	public List getBizOrderByInvoiceState(CheckOrderPage page) {
		return bizOrderDao.getBizOrderByInvoiceState(page);
	}
	
	@Override
	public int updateHangUpState(String clientId, long jdOrderId,
			int hangUpState) {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setClientId(clientId);
		bizOrder.setJdOrderId(jdOrderId);
		bizOrder.setHangUpState(hangUpState);
		return bizOrderDao.updateHangUpState(bizOrder);
	}
	
	@Override
	public int updateOrderState(BizOrder bizOrder) {
		return bizOrderDao.updateOrderState(bizOrder);
	}
	
	@Override
	public BizOrder selectParentJdOrderByThirdOrder(String clientId, String thirdOrder) {
		BizOrder bizOrder = new BizOrder();
		bizOrder.setClientId(clientId);
		bizOrder.setThirdOrder(thirdOrder);
		return this.bizOrderDao.selectParentJdOrderByThirdOrder(bizOrder);
	}
	
	@Override
	public int updateSubmitOrderStateById(BizOrder bizOrder) {
		return this.bizOrderDao.updateSubmitOrderStateById(bizOrder);
	}
	
	@Override
	public int confirmSubmitOrder(BizOrder bizOrder) {
		return this.bizOrderDao.confirmSubmitOrder(bizOrder);
	}
  
	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}	

	@Override
	public List<BizOrder> selectJdOrderListByThirdOrder(String thirdOrder, String clientId) {
		return bizOrderDao.selectJdOrderListByThirdOrder(thirdOrder, clientId);
	}
	
	public void setBizOrderDao(BizOrderDao bizOrderDao) {
		this.bizOrderDao = bizOrderDao;
	}
	public void setBizOrderInvoiceDao(BizOrderInvoiceDao bizOrderInvoiceDao) {
		this.bizOrderInvoiceDao = bizOrderInvoiceDao;
	}
	
	
}
