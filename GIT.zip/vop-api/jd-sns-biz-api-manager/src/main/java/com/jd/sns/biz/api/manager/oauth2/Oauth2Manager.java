package com.jd.sns.biz.api.manager.oauth2;

import java.util.List;

import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.domain.User;

public interface Oauth2Manager {
	/**
	 * 获得授权网站信息
	 * @param client_id
	 * @return
	 */
	public User getUser(String client_id);
	/**
	 * 创建一个accessToken记录
	 * @param at
	 */
	public void createAccessToken(AccessToken at);
	
	public AccessToken getAccessToken(String refreshToken);
}
