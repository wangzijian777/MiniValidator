package com.jd.sns.biz.api.manager;

import com.jd.sns.biz.api.domain.BizInvoice;

public interface BizInvoiceManager {
	public void insertBizInvoice(BizInvoice bizInvoice);
	
	public BizInvoice selectBizInvoiceByMarkId(String clientId, String markId);
}
