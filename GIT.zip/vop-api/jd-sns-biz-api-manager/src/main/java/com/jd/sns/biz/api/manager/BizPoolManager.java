package com.jd.sns.biz.api.manager;

import java.util.List;

public interface BizPoolManager {
	/**
	 * 获取client_id查询商品池列表 by wangyong cando:Y
	 * @param clientId
	 * @return
	 */
	public List selectPageNumByClientId(String clientId) throws Exception;
}
