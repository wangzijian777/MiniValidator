package com.jd.sns.biz.api.manager;

import java.util.List;

import com.jd.sns.biz.api.domain.BizQuota;

public interface BizQuotaManager {
	void insert(BizQuota bizQuota);

	int update(BizQuota bizQuota);
}
