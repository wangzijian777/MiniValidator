package com.jd.sns.biz.api.manager.impl;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.DemandOrderDao;
import com.jd.sns.biz.api.domain.DemandOrder;
import com.jd.sns.biz.api.manager.DemandOrderManager;

@Service(value="demandOrderManager")
public class DemandOrderManagerImple implements DemandOrderManager {
	
	private DemandOrderDao demandOrderDao;

	@Override
	public long insertJdDemandOrder(DemandOrder demandOrder) {
		return demandOrderDao.insertJdDemandOrder(demandOrder);
	}

	@Override
	public int cancelJdDemandOrder(long jdDemandOrder, String clientId) {
		DemandOrder demandOrder = new DemandOrder();
		demandOrder.setJdDemandOrder(jdDemandOrder);
		demandOrder.setClientId(clientId);
		return demandOrderDao.cancelJdDemandOrder(demandOrder);
	}

	@Override
	public DemandOrder selectDemandOrderById(long jdDemandOrder, String clientId) {
		DemandOrder demandOrder = new DemandOrder();
		demandOrder.setJdDemandOrder(jdDemandOrder);
		demandOrder.setClientId(clientId);
		return demandOrderDao.selectDemandOrderById(demandOrder);
	}

	@Override
	public int checkThirdOrderExist(String thirdOrder, String clientId) {
		DemandOrder demandOrder = new DemandOrder();
		demandOrder.setClientId(clientId);
		demandOrder.setThirdOrder(thirdOrder);
		return demandOrderDao.checkThirdOrderExist(demandOrder);
	}
	
	public void setDemandOrderDao(DemandOrderDao demandOrderDao) {
		this.demandOrderDao = demandOrderDao;
	}

	@Override
	public int updateJdOrderId(DemandOrder demandOrder) {
		return demandOrderDao.updateJdOrderId(demandOrder);
	}

}
