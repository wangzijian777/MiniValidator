package com.jd.sns.biz.api.manager.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.BizMessageTaskDao;
import com.jd.sns.biz.api.domain.BizMessageTask;
import com.jd.sns.biz.api.manager.BizMessageTaskManager;

@Service(value="bizMessageTaskManager")
public class BizMessageTaskManagerImpl implements BizMessageTaskManager {

	private BizMessageTaskDao bizMessageTaskDao;
	
	@Override
	public void insertBizMessageTask(BizMessageTask bizMessageTask) {
		bizMessageTaskDao.insertBizMessageTask(bizMessageTask);
	}

	@Override
	public List<BizMessageTask> selectBizMessageTaskList() {
		return bizMessageTaskDao.selectBizMessageTaskList();
	}

	@Override
	public int delBizMessageTaskById(long id) {
		return bizMessageTaskDao.delBizMessageTaskById(id);
	}

	public void setBizMessageTaskDao(BizMessageTaskDao bizMessageTaskDao) {
		this.bizMessageTaskDao = bizMessageTaskDao;
	}

}
