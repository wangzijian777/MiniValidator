package com.jd.sns.biz.api.manager.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.BizOrderFlowDao;
import com.jd.sns.biz.api.domain.BizOrderFlow;
import com.jd.sns.biz.api.manager.BizOrderFlowManager;

@Service(value="bizOrderFlowManager")
public class BizOrderFlowManagerImpl implements BizOrderFlowManager {
	
	private BizOrderFlowDao bizOrderFlowDao;
	
	@Override
	public List<BizOrderFlow> getBizOrderFlowByStatus(String clientId, int status){
		BizOrderFlow bizOrderFlow = new BizOrderFlow();
		bizOrderFlow.setClientId(clientId);
		bizOrderFlow.setStatus(status);
		
		return bizOrderFlowDao.getBizOrderFlowByStatus(bizOrderFlow);
	}
	
	@Override
	public void insertBizOrderFlow(BizOrderFlow bizOrderFlow) {
		BizOrderFlow dbBizOrderFlow = this.getBizOrderFlowByOrderId(bizOrderFlow.getClientId(), bizOrderFlow.getOrderId());
		if(dbBizOrderFlow == null){
			this.bizOrderFlowDao.insertBizOrderFlow(bizOrderFlow);
		}
		this.updateBizOrderFlow(bizOrderFlow);
	}
	
	@Override
	public void insertBizOrderFlowDetail(BizOrderFlow bizOrderFlow) {
		this.bizOrderFlowDao.insertBizOrderFlowDetail(bizOrderFlow);
	}

	@Override
	public BizOrderFlow getBizOrderFlowByOrderId(String clientId, long orderId) {
		BizOrderFlow bizOrderFlow = new BizOrderFlow();
		bizOrderFlow.setClientId(clientId);
		bizOrderFlow.setOrderId(orderId);
		
		return bizOrderFlowDao.getBizOrderFlowByOrderId(bizOrderFlow);
	}
	
	@Override
	public int updateBizOrderFlow(BizOrderFlow bizOrderFlow){
		return this.bizOrderFlowDao.updateBizOrderFlow(bizOrderFlow);
	}
	
	public void setBizOrderFlowDao(BizOrderFlowDao bizOrderFlowDao) {
		this.bizOrderFlowDao = bizOrderFlowDao;
	}

}