package com.jd.sns.biz.api.manager;

import java.util.List;

import com.jd.sns.biz.api.domain.BizMessageTask;

public interface BizMessageTaskManager {
	public void insertBizMessageTask(BizMessageTask bizMessageTask);
	public List<BizMessageTask> selectBizMessageTaskList();
	public int delBizMessageTaskById(long id);
}
