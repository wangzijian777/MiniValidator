package com.jd.sns.biz.api.manager.oauth2.impl;

import org.springframework.stereotype.Service;

import com.jd.sns.biz.api.dao.oauth2.AccessTokenDao;
import com.jd.sns.biz.api.dao.oauth2.Oauth2Dao;
import com.jd.sns.biz.api.domain.AccessToken;
import com.jd.sns.biz.api.domain.User;
import com.jd.sns.biz.api.manager.oauth2.Oauth2Manager;

@Service(value="oauth2Manager")
public class Oauth2ManagerImpl implements Oauth2Manager{

	private Oauth2Dao oauth2Dao;
	
	private AccessTokenDao accessTokenDao;
	
	@Override
	public User getUser(String client_id) {
		return oauth2Dao.getUser(client_id);
	}
	
	
	@Override
	public void createAccessToken(AccessToken at){
		oauth2Dao.createAccessToken(at);
	}
	
	@Override
	public AccessToken getAccessToken(String refreshToken) {
		return accessTokenDao.getAccessTokenByRefreshToken(refreshToken);
	}

	public void setOauth2Dao(Oauth2Dao oauth2Dao) {
		this.oauth2Dao = oauth2Dao;
	}


	public void setAccessTokenDao(AccessTokenDao accessTokenDao) {
		this.accessTokenDao = accessTokenDao;
	}


}
