package com.jd.sns.biz.api.manager;

import java.math.BigDecimal;

public interface BizPoolSkuPriceManager {
	public BigDecimal getBizPriceBySkuId(long skuId);
}
