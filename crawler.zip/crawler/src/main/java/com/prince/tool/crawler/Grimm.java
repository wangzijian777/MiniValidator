package com.prince.tool.crawler;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.AndFilter;
import org.htmlparser.filters.HasAttributeFilter;
import org.htmlparser.filters.NodeClassFilter;
import org.htmlparser.tags.Div;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;


public class Grimm {
	public static void main(String[] args) throws FileNotFoundException {
		Map<String, List<String>> stories = getZhStories();
		for (String key : stories.keySet()) {
			for (String v : stories.get(key)) {
				System.out.println(v);
//				getStoriesSta(v);
			}
			break;
		}

		System.out.println(getStoriesSta("http://www.grimmstories.com/zh/grimm_tonghua/qingwa_wangzi").size());
	}

	private static List<String> getStoriesSta(String url) {
		List<String> statement = new ArrayList<String>();
		String html = GetTool.getHtml(url);
		try {
			Parser parser = new Parser(html);
			NodeFilter aNodeFilter = new NodeClassFilter(Div.class); 
			HasAttributeFilter attributeFilter = new HasAttributeFilter("itemprop", "text");
			AndFilter filter = new AndFilter(aNodeFilter, attributeFilter);
			NodeList nodeList = parser.extractAllNodesThatMatch(filter);
			for(int i = 0; i<nodeList.size();i++){  
				Div div = (Div)nodeList.elementAt(i);
				if(url.contains("/zh/") || url.contains("/ja/")){
					for (String s : div.getStringText().split("。")){
						statement.add(s);
					}
				}else{
					for (String s : div.getStringText().split("\\.")){
						statement.add(s);
					}
				}
				System.out.println();
			}
		} catch (ParserException e) {
			e.printStackTrace();
		}
		return statement;
	}

	private static List<String> getOtherLink(String url) {
		List<String> links = new ArrayList<String>();
		List<String> language = new ArrayList<String>();
		language.add("ZH");
		language.add("VI");
		language.add("TR");
		language.add("RU");
		language.add("RO");
		language.add("PT");
		language.add("PL");
		language.add("NL");
		language.add("KO");
		language.add("JA");
		language.add("IT");
		language.add("HU");
		language.add("FR");
		language.add("FI");
		language.add("ES");
		language.add("EN");
		language.add("DE");
		language.add("DA");

		String html = GetTool.getHtml(url);
		try {
			Parser parser = new Parser(html);
			NodeFilter aNodeFilter = new NodeClassFilter(LinkTag.class); 
			NodeList nodeList = parser.extractAllNodesThatMatch(aNodeFilter);
			for(int i = 0; i<nodeList.size();i++){  
				LinkTag link = (LinkTag) nodeList.elementAt(i);
				if(language.contains(link.getLinkText())){
					links.add(link.getLink());
				}
			}
		} catch (ParserException e) {
			e.printStackTrace();
		}
		return links;
	}

	private static Map<String, List<String>> getZhStories() throws FileNotFoundException {
		Scanner s = new Scanner(new File("/gelin.txt"));
		Map<String, List<String>> stories = new HashMap<String, List<String>>();
		int i = 0;
		while(s.hasNext()){
			String url = s.next();
			String key = url.substring(url.lastIndexOf("/") + 1);
			List<String> story = getOtherLink(url);
			stories.put(key, story);
			System.out.println(i ++ );
			break;
		}
		return stories;
	}


}
