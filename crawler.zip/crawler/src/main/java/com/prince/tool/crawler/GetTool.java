package com.prince.tool.crawler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;

public class GetTool {
	public static String getHtml(String url){
		String responseStr = "";
		HttpClient httpClient = new HttpClient();
		httpClient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
		GetMethod get = new GetMethod(url);
		int statusCode = 0;
		InputStream inputStream = null;
		BufferedReader br = null;
		try {
			statusCode = httpClient.executeMethod(get);
			if(statusCode == 200){
				inputStream  = get.getResponseBodyAsStream();
				br = new BufferedReader(new InputStreamReader(inputStream)); 
				StringBuffer stringBuffer = new StringBuffer(); 
				String str= ""; 
				while((str = br.readLine()) != null){ stringBuffer.append(str ); }
				responseStr = stringBuffer.toString();
			}else {
				System.out.println(get.getResponseBodyAsString());
			}
			
		} catch (HttpException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			try {
				br.close();
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			get.releaseConnection();
		}
		return responseStr;
	}
}
