package com.jd.cloudeye.drp.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/collectData")
@Produces({"application/xml","application/json"})
@Consumes({"application/xml","application/json"})
public interface CollectionCloudServiceLog 
{
	@POST
	@Path("/sendServiceLog")
	public String sendServiceLog(String data);
}
