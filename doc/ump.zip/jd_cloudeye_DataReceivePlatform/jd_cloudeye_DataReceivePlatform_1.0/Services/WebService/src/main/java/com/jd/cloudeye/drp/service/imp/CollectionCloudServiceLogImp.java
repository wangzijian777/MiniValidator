package com.jd.cloudeye.drp.service.imp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.cloudeye.drp.service.CollectionCloudServiceLog;
import com.jd.cloudeye.drp.service.common.DataHandle;

public class CollectionCloudServiceLogImp implements CollectionCloudServiceLog
{
	private static final Logger LOGGER = LoggerFactory.getLogger(CollectionCloudServiceLogImp.class);
	private DataHandle dataHandle;
	
	@Override
	public String sendServiceLog(String data) 
	{
		if(LOGGER.isInfoEnabled())
		{
			LOGGER.info("CollectionCloudServiceLogReceiveJson is ["+data+"]");
		}
		return dataHandle.dataHandle(data);
	}
	
	public DataHandle getDataHandle() {
		return dataHandle;
	}
	public void setDataHandle(DataHandle dataHandle) {
		this.dataHandle = dataHandle;
	}

}
