package com.jd.cloudeye.drp.service.common.util;
/**
 * @title 
 * @description
 * @author yangjialiang
 * @date 2013-3-2
 */
public class GlobalConstants {
	/**
	 * CDRC CommonService ModuleName
	 */
	public static final String ModuleName = "CDRC.CommonService";
	
	/**
	 * CDRC EC2 Alive Time redisKey
	 */
	public static final String EC2_AliveTime_Key = "EC2_AliveTime";
	
	/**
	 * SERICE_TYPE指标更新时间5分钟 
	 */
	public static final int SERICE_TYPE_CACHE_TIME = 300000;
	
	/**
	 * 判断字符串是否为空或空串（&trim）
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public static boolean isEmpty(String str)
	{
		return str == null || "".equals(str.trim());
	}
	
	
}
