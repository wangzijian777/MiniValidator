package com.jd.cloudeye.drp.service.common.util;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;



/**
 * @title 针对DateTime的处理工具类
 * @description
 * @author yangjialiang
 * @date 2013-2-28
 */
public class DateTimeUtil {
	/**
	 * 精确到毫秒数的时间格式字符串"yyyyMMddHHmmssSSS"
	 */
	private static final String DATEFORMATSTRING_Accurate2MilliSeconds = "yyyyMMddHHmmssSSS";

	/**
	 * 精确到分钟数的时间格式字符串"yyyyMMddHHmm"
	 */
	private static final String DATEFORMATSTRING_Accurate2Minutes = "yyyyMMddHHmm";   
    
	
	/**
	 * 仅指向到秒数的时间格式字符串"ss"
	 */
	private static final String DATEFORMATSTRING_OnlySeconds = "ss";
	
	/**
	 * 得到指定格式("yyyyMMddHHmmssSSS")的当前时间字符串
	 * @return
	 */
	public static String getCurrentDataTimeString(){
		return DateFormatUtils.format(new Date(),DATEFORMATSTRING_Accurate2MilliSeconds);
	}
	
	/**
	 * 得到long型的当前时间的字符串形式
	 * @return
	 */
	public static String getCurrentLontTimeString(){
		return Long.toString(new Date().getTime());
	}

    /**
     * 从yyyyMMddHHmmssSSS格式的字符串时间中得到精确到分钟的时间字符串及秒数 
     * @param sTime 以(yyyyMMddHHmmssSSS)格式化后的时间,如：20130115145323000
     * @return 正常是返回2个长度的先后存放有精确到分钟的时间字符串和秒数的数组
     * @throws ParseException
     */
    public static String[] getTimeAccurate2Minutes_SecondNum(String sTime) throws ParseException {

		String[] resultList = null;
    	
        if (sTime == null || sTime.trim().equals("")) {
            throw new IllegalArgumentException("timeString is null or ''");
        }
        // 检查参数长度是否与预期的一致
        if (sTime.length() != DATEFORMATSTRING_Accurate2MilliSeconds.length()) {
            throw new IllegalArgumentException("timeString.length() != DATEFORMAT_STRING.length(),timeString is:" + sTime);
        }
        resultList = new String[2];
        Date date = DateUtils.parseDate(sTime,new String[]{DATEFORMATSTRING_Accurate2MilliSeconds});
        resultList[0]=DateFormatUtils.format(date,DATEFORMATSTRING_Accurate2Minutes);
        
        //取出秒数
        resultList[1]=DateFormatUtils.format(date,DATEFORMATSTRING_OnlySeconds);

        return resultList;
    }
    
}
