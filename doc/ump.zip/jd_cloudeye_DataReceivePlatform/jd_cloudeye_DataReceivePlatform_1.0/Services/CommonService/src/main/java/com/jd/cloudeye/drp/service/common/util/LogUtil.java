package com.jd.cloudeye.drp.service.common.util;

import org.apache.log4j.Logger;

import com.jd.cloudeye.common.CommonLogUtil;

/**
 * @title 记录日志的工具类
 * @description 为记录日志增加了指定格式的前缀
 * @author yangjialiang
 * @date 2013-3-2
 */
public class LogUtil {
	private static final String message_Log_Format = "%1$s %2$s";
	
	/**
	 * 记录不可预见的错误或异常
	 * @param logger 由调用方传入的日志记录器
	 * @param moduleName 调用方所在的模块名
	 * @param className  调用方所在的类名
	 * @param errorMessage 调用方需要记录的异常信息
	 */
	public static void logError(Logger logger,String moduleName
			,String className,String errorMessage){
		logger.error(String.format(message_Log_Format
				, CommonLogUtil.makeErrorHead(moduleName, className)
				,errorMessage));
	}
	/**
	 * 记录可预见的错误或异常
	 * @param logger 由调用方传入的日志记录器
	 * @param moduleName 调用方所在的模块名
	 * @param className  调用方所在的类名
	 * @param methodName 调用方所在的方法名
	 * @param errorMessage 调用方需要记录的异常信息
	 */
	public static void logWarn(Logger logger,String moduleName
			,String className,String methodName,String errorMessage){
		logger.warn(String.format(message_Log_Format
				, CommonLogUtil.makeWarnHead(moduleName, className, methodName)
				,errorMessage));	
		
	}
	/**
	 * 记录可预见的处理日志
	 * @param logger 由调用方传入的日志记录器
	 * @param moduleName 调用方所在的模块名
	 * @param className  调用方所在的类名
	 * @param methodName 调用方所在的方法名
	 * @param errorMessage 调用方需要记录的异常信息
	 */
	public static void logInfo(Logger logger,String moduleName
			,String className,String methodName,String errorMessage){
		
			logger.info(String.format(message_Log_Format
					, CommonLogUtil.makeInfoHead(moduleName, className, methodName)
					,errorMessage));
		

	}	
}
