package com.jd.cloudeye.drp.service.common.vo;
/**
 * @title 保存接口处理结果的vo类
 * @description
 * @author yangjialiang
 * @date 2013-2-28
 */
public class HandleResult {
	private String state;
	private String message;
	private String responseTime;
	public void setState(String state) {
		this.state = state;
	}
	public String getState() {
		return state;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}
	public String getResponseTime() {
		return responseTime;
	}
	
	public HandleResult(String state,String message,String responseTime){
		this.state = state;
		this.message = message;
		this.responseTime = responseTime;
	}
}
