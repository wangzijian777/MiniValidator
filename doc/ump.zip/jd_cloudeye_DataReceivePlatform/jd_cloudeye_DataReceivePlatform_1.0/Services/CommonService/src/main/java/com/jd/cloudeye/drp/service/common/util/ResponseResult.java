package com.jd.cloudeye.drp.service.common.util;

import com.alibaba.fastjson.JSONObject;
import com.jd.cloudeye.drp.service.common.vo.HandleResult;
import com.jd.cloudeye.drp.service.common.vo.ResultStateMessage;

/**
 * @title 为接口调用定义的返回值处理类
 * @description
 * @author yangjialiang
 * @date 2013-2-28
 */
public class ResponseResult {
	
	/**
	 * 将监控数据处理后的结果组装成指定的JSON格式字符串
	 * eg:{“state”:”1”,”message”:“success”,”responseTime”: “20130222100355195”}
	 * @param result 返回结果枚举(由状态及消息组成)
	 * @return 将结果以json字符串的格式返回
	 */
	public static String result(ResultStateMessage result){
		HandleResult temp = new HandleResult(result.getState(),result.getMessage(),DateTimeUtil.getCurrentDataTimeString());
		return JSONObject.toJSONString(temp);		
	}
}
