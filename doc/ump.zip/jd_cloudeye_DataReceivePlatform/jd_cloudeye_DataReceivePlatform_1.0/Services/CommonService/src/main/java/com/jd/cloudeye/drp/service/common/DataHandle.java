package com.jd.cloudeye.drp.service.common;
/**
 * @title 数据处理接口
 * @description
 * @author yangjialiang
 * @date 2013-2-28
 */
public interface DataHandle {

    /**
     * 数据处理方法
     * @param jsonData
     */
    String dataHandle(String jsonData);
}
