package com.jd.cloudeye.drp.drc;


import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.AppInfo;
import com.jd.cloudeye.common.AppVersionUtil;
import com.jd.cloudeye.common.Module;
import com.jd.cloudeye.drp.common.DrpCommonModuleCreator;
import com.jd.cloudeye.drp.service.common.CommonServiceModuleCreator;
import com.jd.cloudeye.drp.service.common.WebServiceModuleCreator;
import com.jd.redis.support.RedisCommands;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * 服务中心系统心跳,版本注册
 * @author Upton
 *
 */
@Component
public class ServiceCenterHeartBeat {
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceCenterHeartBeat.class);
	
	@Resource(name = "redisClient")
	private RedisCommands redisClient;

	@PostConstruct
	public void init(){
		//初始化系统心跳
		Profiler.InitHeartBeats("jdce.dataReceiveCenter");
		
		//初始化模块版本
		initModuleVersion();
		
	}
	
	/**
	 * 初始化模块版本
	 */
	private void initModuleVersion(){
		
		AppInfo app = new AppInfo();
		
		app.setName("CloudEyeDataReceiveCenter");
		app.setHost(AppVersionUtil.getHostName());
		app.setStartTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		
		//对外发布接口
		app.addModule(new WebServiceModuleCreator().create());
		//数据接收中心公共模块
		app.addModule(new DrpCommonModuleCreator().create());
		//数据接收服务中心模块
		app.addModule(new DataReceiveCenterModuleCreator().create());
		//数据接收公共服务模块
		app.addModule(new CommonServiceModuleCreator().create());
		
		regApp(app);
		
	}
	
	/**
	 * 在redis中缓存各个模块的版本号
	 * @param app
	 */
	private void regApp(AppInfo app){
		String appKey = "APP_INFO_" + app.getName();
				
		for(Module module : app.getModules()){
			redisClient.hset(appKey, app.getHost() + "-->" + module.getName(), module.getVersion());
		}
		
		redisClient.hset(appKey, app.getHost() + "-->#StartTime#", app.getStartTime());
		
		LOGGER.info("Register app info ok. ");
	}
	
	
	
}