package com.jd.cloudeye.drp.common;

import com.jd.cloudeye.common.IModuleCreator;
import com.jd.cloudeye.common.Module;

public class DrpCommonModuleCreator implements IModuleCreator
{
	@Override
	public Module create() 
	{
		Module module = new Module();
		
		module.setName("DrpCommon");
		module.setVersion("2013040901");
		
		return module;
	}
}
