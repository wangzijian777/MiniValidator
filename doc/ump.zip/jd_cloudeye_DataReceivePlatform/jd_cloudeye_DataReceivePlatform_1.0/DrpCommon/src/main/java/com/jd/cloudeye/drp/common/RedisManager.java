package com.jd.cloudeye.drp.common;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.jd.redis.support.RedisCommands;

@Component
public class RedisManager 
{
	private static final String JDCE_PREFIX = "JDCE#";
	@Resource(name = "redisClient") 
	private RedisCommands redisClient;
	
	public void saveFieldData(String key,String field,String value)
	{
		redisClient.hset(JDCE_PREFIX + key, field, value);
	}
	
	public Map<String,String> fetchAllFieldData(String key)
	{
		return redisClient.hgetAll(JDCE_PREFIX + key);
	}
	
	public void setExpire(final String key, final int second) 
	{
		redisClient.expire(JDCE_PREFIX + key, second);
	}

	public String getValue(String key) {
		return redisClient.get(key);
	}
}
