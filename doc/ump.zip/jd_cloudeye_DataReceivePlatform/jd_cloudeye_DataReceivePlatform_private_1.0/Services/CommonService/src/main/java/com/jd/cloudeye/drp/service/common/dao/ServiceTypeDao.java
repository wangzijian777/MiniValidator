package com.jd.cloudeye.drp.service.common.dao;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.InitBinder;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.drp.common.RedisManager;
import com.jd.cloudeye.drp.service.common.util.DateTimeUtil;
import com.jd.cloudeye.drp.service.common.util.GlobalConstants;
import com.jd.cloudeye.drp.service.common.vo.CloudEyeData;

@Repository("serviceTypeDao")
public class ServiceTypeDao {
	
	private static final Logger log = Logger.getLogger(ServiceTypeDao.class);
	
	private static final String bigKey_ForMatString = "%1$s#%2$s#%3$s#%4$s#%5$s";
	private static final String BIGKEY_NULLVALUE_STRING = "KNULL";
	
	
	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Resource(name = "redisManager")
	private RedisManager redisManager;
	
	/**
	 * 最后一次更新 服务缓存集合 时间
	 */
	private long lastUpdateCacheTime = 0;
	
	/**
	 * 服务缓存集合 
	 */
	private Map<String,String> serviceTypeCache = new HashMap<String,String>();
	
	/**
	 * 校验服务类型
	 * 
	 * @param serviceType 参加校验的服务类型
	 * 
	 * @return boolean 是否合法
	 * 
	 * @author chenhualiang
	 * @since 2013-03-20
	 */
	public boolean isValidServiceType(String serviceType)
	{
		if(GlobalConstants.isEmpty(serviceType))
		{
			return false;
		}
		if(serviceTypeCache.containsKey(serviceType))
		{
			return true;
		}
		synchronized (serviceTypeCache) {
			if(serviceTypeCache.containsKey(serviceType))
			{
				return true;
			}
			if(System.currentTimeMillis() - lastUpdateCacheTime > GlobalConstants.SERICE_TYPE_CACHE_TIME)
			{
				loadServiceType();
				return serviceTypeCache.containsKey(serviceType);
			}
			else
			{
				return false;
			}
		}
	}
	
	
	/**
	 * 加载服务类型 
	 */
	@InitBinder
	public void loadServiceType() {
		try{
			String sql = "SELECT jce_dictionary_code ,jce_dictionary_value FROM jce_dictionary where jce_level = '-1'";
			List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
			if(list != null && !list.isEmpty())
			{
				serviceTypeCache.clear();
				for(Map<String, Object> item : list)
				{
					Object code = item.get("jce_dictionary_code");
					Object value = item.get("jce_dictionary_value");
					if(code != null && value != null)
					{
						serviceTypeCache.put(code.toString(), value.toString());
					}
				}
				lastUpdateCacheTime = System.currentTimeMillis();
			}
		}catch (Exception e) {
			log.error(CommonLogUtil.makeErrorHead("CommonService", "ServiceTypeDao") + " load service type from db exception",e);
		}
	}
	
	/**
	 * 将经过拆分后的数据组装成指定的redis格式
	 * @param list 从json数据串中解析出的CloudEyeData对象列表
	 * @return
	 * @throws ParseException 
	 */
	public HashMap<String, HashMap<String,String>> convert(List<CloudEyeData> list) throws ParseException{
		HashMap<String, HashMap<String,String>> result= new HashMap<String, HashMap<String,String>>();
		Map<String, String> tempMetrics = null;
		String bigKey = null;
		String metricValue = null;
		String[] minuteTimeSecondNumList = null;
		String minuteTime = null;
		String secondNum =null;
		HashMap<String, String> tempRedisMap;
		 
		for (CloudEyeData perData : list) {
			tempMetrics = perData.getMetrics();

			minuteTimeSecondNumList = DateTimeUtil.getTimeAccurate2Minutes_SecondNum(
					perData.getTime());
			
			if(minuteTimeSecondNumList!=null && minuteTimeSecondNumList.length==2){
				minuteTime = minuteTimeSecondNumList[0];
				secondNum = minuteTimeSecondNumList[1];
				
				for(Entry<String, String> metric:tempMetrics.entrySet()){
					metricValue = metric.getValue();
					bigKey = getBigKey(perData,metric.getKey().trim(),minuteTime);
					if(bigKey!=null && bigKey.length()>0){
						if(result.containsKey(bigKey)){
							tempRedisMap = result.get(bigKey);
							tempRedisMap.put(secondNum, metricValue);
						}else{
							tempRedisMap = new HashMap<String, String>();
							tempRedisMap.put(secondNum, metricValue);
							result.put(bigKey, tempRedisMap);
						}
					}
					//modify by cdchenhl 2013-06-17
					if("ELB".equalsIgnoreCase(perData.getServiceType())
							||"AS".equalsIgnoreCase(perData.getServiceType()))
					{
						bigKey = createJECSData(perData,metric.getKey().trim(),minuteTime);
						if(bigKey!=null && bigKey.length()>0){
							if(result.containsKey(bigKey)){
								tempRedisMap = result.get(bigKey);
								tempRedisMap.put(secondNum, metricValue);
							}else{
								tempRedisMap = new HashMap<String, String>();
								tempRedisMap.put(secondNum, metricValue);
								result.put(bigKey, tempRedisMap);
							}
							log.info(CommonLogUtil.makeInfoHead("CommonService", "ServiceTypeDao","convert") + perData.getServiceType() + "(" + perData.getInstanceId() + ") to JECS ==>{key:" +  bigKey + ",secondNum:" + secondNum + ",metricValue:" + metricValue + "}");
						}
					}
				}
			}
		}
		return result;		
	}
	/**
	 * 组装BigKey：ServiceType#userID#InstanceID#Metric#Time
	 */
	private String getBigKey(CloudEyeData data,String metricKey,String dateAccurate2Minutes){
		String resultString = null;
		String tempValueString = null;
		if(metricKey!=null && metricKey.length()>0){
			if(isValidServiceType(tempValueString=data.getServiceType())){
				resultString = String.format(bigKey_ForMatString
						, tempValueString
						,getBigKeyItemValue(data.getUserId())
						,getBigKeyItemValue(data.getInstanceId())
						,metricKey
						,dateAccurate2Minutes);
			}			
		}

			
		return resultString;
	}
	
	/**
	 * 组装JECS BigKey：ServiceType#userID#InstanceID#Metric#Time
	 */
	private String createJECSData(CloudEyeData data,String metricKey,String dateAccurate2Minutes){
		String resultString = null;
		String tempValueString = "JECS";
		if(metricKey!=null && metricKey.length()>0){
				String instanceId = getJECSInstance("ELB".equals(data.getServiceType()),data.getInstanceId());
				if(instanceId == null)
				{
					return null;
				}
				resultString = String.format(bigKey_ForMatString
						, tempValueString
						,data.getUserId()
						,instanceId
						,metricKey.replaceAll("^((AS_)|(ELB_))", "JECS_")
						,dateAccurate2Minutes);
		}
		return resultString;
	}
	
	/**
	 * 获取JECS的实例ID 
	 */
	private String getJECSInstance(boolean isELB,String instanceId) {
		if(isELB)
		{
			String key = "JECS_RELATION#ELB#" + instanceId;
			instanceId = redisManager.getValue(key);
			log.info(CommonLogUtil.makeInfoHead("CommonService", "ServiceTypeDao","getJECSInstance") + "{key:" + key + ",value:" + instanceId + "}");
		}
		return instanceId;
	}


	/**
	 * 处理BigKey中各组成item的值
	 * @param itemValue
	 * @return
	 */
	private String getBigKeyItemValue(String itemValue){
		String resultString = null;
		if(itemValue==null || itemValue.length()<1){
			resultString = BIGKEY_NULLVALUE_STRING;
		}else {
			resultString = itemValue;
		}
		return resultString;
	}
	
	/**
	 * 得到可能存在的EC2实例及心跳时间(在经过拆分后的数据中挑选出所有EC2的实例,然后使用当前时间作为其心跳时间)
	 * @param list 从json数据串中解析出的CloudEyeData对象列表
	 * @return
	 * @throws ParseException 
	 */
	public HashMap<String,String> pickUpEC2AliveTime(List<CloudEyeData> list){
		HashMap<String,String> resultHashMap = new HashMap<String,String>();
		String currentTime = DateTimeUtil.getCurrentLontTimeString();
		String tempValueString = null;
		for (CloudEyeData perData : list) {
			if((tempValueString=perData.getServiceType())!=null && tempValueString.equals("EC2")){
				if((tempValueString=perData.getInstanceId())!=null){
					resultHashMap.put(tempValueString, currentTime);
				}
			}
		}
		return resultHashMap;
	}

}
