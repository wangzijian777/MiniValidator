package com.jd.cloudeye.drp.service.common;

import com.jd.cloudeye.common.IModuleCreator;
import com.jd.cloudeye.common.Module;

public class CommonServiceModuleCreator implements IModuleCreator
{
	@Override
	public Module create() 
	{
		Module module = new Module();
		
		module.setName("CommonService");
		module.setVersion("2013102301");
		
		return module;
	}
}
