package com.jd.cloudeye.drp.service.common;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONArray;
import com.jd.cloudeye.drp.common.RedisManager;
import com.jd.cloudeye.drp.service.common.dao.ServiceTypeDao;
import com.jd.cloudeye.drp.service.common.util.GlobalConstants;
import com.jd.cloudeye.drp.service.common.util.LogUtil;
import com.jd.cloudeye.drp.service.common.util.ResponseResult;
import com.jd.cloudeye.drp.service.common.vo.CloudEyeData;
import com.jd.cloudeye.drp.service.common.vo.ResultStateMessage;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * @title 数据处理实现类
 * @description
 * @author yangjialiang
 * @date 2013-2-28
 */
public class DataHandleImpl implements DataHandle{

	private static final String className = "DataHandleImpl";
	
	private static final Logger LOGGER = Logger.getLogger(DataHandleImpl.class);
	/**
	 * 过期时间暂定为1小时
	 */
	private static final int EXPIRETIME_SECONDAMOUNT = 1 * 60 *60 ;
	
	private RedisManager redisManager;
	
	private ServiceTypeDao serviceTypeDao;
	
	public ServiceTypeDao getServiceTypeDao() {
		return serviceTypeDao;
	}
	public void setServiceTypeDao(ServiceTypeDao serviceTypeDao) {
		this.serviceTypeDao = serviceTypeDao;
	}
	/**
	 * 处理方法
	 */
	@Override
	public String dataHandle(String jsonData) {
		String result=null;
		
		boolean isValidData = true;
		boolean isContainNullMetricKeyOrValue = false;
		
		CallerInfo callerInfo = Profiler.registerInfo("jms.DRC.CommonService.dataHandle", true, true);
		
		//拆分
		List<CloudEyeData> list  = splitCloudEyeData(jsonData);
		if(list==null || list.isEmpty()){
			//无法拆分数据时返回参数无效
			result = ResponseResult.result(ResultStateMessage.PARAMETERILLEGAL);
		}else{			
			//验证
			isValidData = isValidData(list);
			if(!isValidData){
				result = ResponseResult.result(ResultStateMessage.PARAMETERILLEGAL);
			}
			else{
				//更新EC2的心跳时间
				final HashMap<String, String> ec2AlvieTime=serviceTypeDao.pickUpEC2AliveTime(list);
				if(!ec2AlvieTime.isEmpty()){
					new Thread(new Runnable() {
						
						@Override
						public void run() {							
							saveEC2AliveTime2Redis(ec2AlvieTime);
						}
						
					}).start();
				}
				
				isContainNullMetricKeyOrValue = isContainNullMetricKeyOrValue(list);
				try {				
					//组装assembling
					HashMap<String, HashMap<String,String>> map2Redis = serviceTypeDao.convert(list);
					//存储到redis save2redis
					saveData2Redis(map2Redis);
					
					//成功处理后且(不存在指标key为空或值为空)返回成功
					if(!isContainNullMetricKeyOrValue){
						result = ResponseResult.result(ResultStateMessage.SUCCESS);
					}
					//成功处理后但(存在指标key为空或值为空)返回参数无效
					else{
						result = ResponseResult.result(ResultStateMessage.PARAMETERILLEGAL);
					}
					
					
				} catch (Exception e) {
					//在组装或存储时出现异常时就返回失败
					Profiler.functionError(callerInfo);
					Profiler.businessAlarm("jdce.drc.dataHandle.assemblingOrSave.exception"
							, new Date().getTime(), "assembling or save2redis throw exception：["+e.toString()+"]");
					
					result = ResponseResult.result(ResultStateMessage.FAIL);
					LogUtil.logWarn(LOGGER, GlobalConstants.ModuleName, className
							,"dataHandle", "###assembling or save2redis throw exception：["+e.toString()+"]");
				} 
			}
		}			
		LogUtil.logInfo(LOGGER, GlobalConstants.ModuleName, className,"dataHandle"
				, "noTopStat###handle result："+result+"###isValidData:"+isValidData
				+"###isContainNullMetricKeyOrValue:"+isContainNullMetricKeyOrValue+"###receive data："+jsonData);
		
		Profiler.registerInfoEnd(callerInfo);
		
		return result;
	}
    /**
     * 拆分：从指定格式的json字符串数据中解析出与其格式对应的CloudEyeData对象列表
     * @param jsonData 指定格式的json字符串数据 例如：[{"clusterId":"","instanceId":"","metrics":{"EC2_CPU":"65"},"serviceType":"EC2","time":"20130305171704054","userId":""}]
     * @param list
     * @return
     */
	@SuppressWarnings("finally")
	private List<CloudEyeData> splitCloudEyeData(String jsonData){
		List<CloudEyeData> list = null;
		CallerInfo callerInfo = Profiler.registerInfo("jms.DRC.CommonService.dataHandle.split", true, true);
		try {
			list = JSONArray.parseArray(jsonData, CloudEyeData.class);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			String errMessage = "dataHandle splitCloudEyeData on error"+e+"###jsonData:"+jsonData;
			LogUtil.logWarn(LOGGER, GlobalConstants.ModuleName, className,"SplitCloudEyeData", errMessage);
			Profiler.businessAlarm("jdce.drc.dataHandle.splitCloudEyeData.exception"
					, new Date().getTime(), errMessage);
			e.printStackTrace();
		} finally{
			Profiler.registerInfoEnd(callerInfo);
			return list;
		}
	}	
	
	/**
	 * 将拼装好的数据批量保存到redis中
	 * @param map2Redis
	 */
	private void saveData2Redis(HashMap<String, HashMap<String,String>> map2Redis){
		String bigKey = null;
		
		for(Entry<String, HashMap<String,String>> perMetricMinuteData:map2Redis.entrySet()){
			bigKey = perMetricMinuteData.getKey();
			for(Entry<String,String> perData:perMetricMinuteData.getValue().entrySet()){
				redisManager.saveFieldData(bigKey, perData.getKey(), perData.getValue());
			}
			redisManager.setExpire(bigKey, EXPIRETIME_SECONDAMOUNT);
		}
		
	}
	
	/**
	 * 注册或更新EC2的心跳时间到redis中
	 * @param map2Redis
	 */
	private void saveEC2AliveTime2Redis(HashMap<String,String> map2Redis){
		String bigKey = GlobalConstants.EC2_AliveTime_Key;				
		
		for(Entry<String,String> perData:map2Redis.entrySet()){
			redisManager.saveFieldData(bigKey, perData.getKey(), perData.getValue());
		}
		
	}
	public RedisManager getRedisManager() {
		return redisManager;
	}
	public void setRedisManager(RedisManager redisManager) {
		this.redisManager = redisManager;
	}
	
	/**
	 * 验证收到的数据是否合法
	 * @param list
	 * @return
	 */
	private boolean isValidData(List<CloudEyeData> list){
        boolean isValidData = true;
		for (CloudEyeData per : list) {
			//modify by cdchenhl 2013-06-17
			if(!serviceTypeDao.isValidServiceType(per.getServiceType())){
				return false;
			}
		}
		return isValidData;
	}
	/**
	 * 判断解析出的数据中是否存在指标key为空或值为空
	 * @param list
	 * @return
	 */
	private boolean isContainNullMetricKeyOrValue(List<CloudEyeData> list){
        boolean result = false;
        String tempString=null;
        Map<String, String> temMetricsMap = null;
		for (CloudEyeData per : list) {
			temMetricsMap = per.getMetrics();
			for(Entry<String, String> entry:temMetricsMap.entrySet()){
				if((tempString=entry.getKey())==null || tempString.length()<1){
					return true;
				}
				if((tempString=entry.getValue())==null || tempString.length()<1){
					return true;
				}
			}
		}
		return result;
	}
	
}
