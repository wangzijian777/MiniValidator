package com.jd.cloudeye.drp.service.common.vo;
/**
 * @title 接口返回状态及对应消息的枚举
 * @description
 * @author yangjialiang
 * @date 2013-2-28
 */
public enum ResultStateMessage {
	FAIL("fail","0"),SUCCESS("success","1"),PARAMETERILLEGAL("parameterillegal","2");
	
	private String message;
	private String state;
	
	private ResultStateMessage(String message,String state){
		this.setMessage(message);
		this.setState(state);
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getState() {
		return state;
	}
}
