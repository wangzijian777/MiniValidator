package com.jd.cloudeye.mdas.center;

import java.util.ArrayList;
import java.util.List;

import com.jd.cloudeye.tsc.management.AppPropertiesManager;

/**
 * 指标分析常量
 * 
 * @author duliang
 * @date 2013-03-02
 */
public class MetricsDataAnalysisUtil {
	
	/**
	 * 指标分析缓存
	 */
	public static List<MetricsDataAnalysisInfo> CACHE_METRICS_DATA_ANALYSIS_LIST = new ArrayList<MetricsDataAnalysisInfo>();
	
	/**
	 * 字典表中服务的ID
	 */
	public static final String SERVICE_PARENT_ID = "0";
	
	/**
	 * 数据有效与无效
	 */
	public static final int VALID = 1;
	public static final int INVALID = 0;
    
    /**
     * 模块名
     */
    public static final String MODULE_NAME = "MetricsDataAnalysisSchedule";
    
    /**
     * 为空默认值
     */
    public static final String KNULL = "KNULL";
    
    
    /**
     * 指标分析频率
     */
    public static long TASK_TIMER_PERIOD = Long.parseLong(AppPropertiesManager.getProperty("MetricsDataAnalysis_Task_TimePeriod"));

    /**
     * 任务延迟时间
     */
    public static int TASK_DELAY_TIME = Integer.parseInt(AppPropertiesManager.getProperty("MetricsDataAnalysis_Task_DelayTime"));
    
    /**
     * 线程个数
     */
    public static int TASK_THREAD_COUNT = Integer.parseInt(AppPropertiesManager.getProperty("MetricsDataAnalysis_Task_ThreadCount"));
	
    /**
     * 队列名称
     */
    public static String TASK_QUEUE_NAME = AppPropertiesManager.getProperty("MetricsDataAnalysis_Task_QueueName");
    
    
    /**
     * JAE分析延迟时间值
     */
    public static long JAE_ANALYSIS_DELAY_TIME = 120000L;
	
    
}
