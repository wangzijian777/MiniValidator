package com.jd.cloudeye.mdas.center;

import java.util.Timer;

import com.jd.cloudeye.tsc.management.ToolBox;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.Source;

/**
 * 下发指标分析任务定时器
 * 
 * @date 2013-03-01
 * @author duliang
 */
public class MetricsDataAnalysisCenter implements Source {

	/**
	 * 启动下发时间：开机后的下一分钟的第10秒
	 * 定时器频率：1分钟
	 * 下发时间：每分钟的第10秒
	 */
	public void open() {
		 Timer metricsDataAnalysisTimer = new Timer("MetricsDataAnalysisTimer");
		 metricsDataAnalysisTimer.scheduleAtFixedRate(new MetricsDataAnalysisTimer(),
					ToolBox.getNextMinuteForInitial(1,MetricsDataAnalysisUtil.TASK_DELAY_TIME),
					MetricsDataAnalysisUtil.TASK_TIMER_PERIOD);
	}
	
	public void close() {}

	public void connect(Sink arg0) {}

	public boolean isBlocking() {
		return false;
	}

}
