package com.jd.cloudeye.mdas.center;

import java.io.Serializable;

/**
 * 指标分析配置类
 */
public class MetricsDataAnalysisInfo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private long usinId;	//关联ID
	private String userId;	//用户ID
	private String serviceCode;	//服务code
	private String instanceId;	//实例Id
	private String metricsCode;	//指标code
	private long taskTime;	//任务时间
	
	public long getUsinId() {
		return usinId;
	}
	public void setUsinId(long usinId) {
		this.usinId = usinId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getInstanceId() {
		return instanceId;
	}
	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}
	public String getMetricsCode() {
		return metricsCode;
	}
	public void setMetricsCode(String metricsCode) {
		this.metricsCode = metricsCode;
	}
	public long getTaskTime() {
		return taskTime;
	}
	public void setTaskTime(long taskTime) {
		this.taskTime = taskTime;
	}
	
}
