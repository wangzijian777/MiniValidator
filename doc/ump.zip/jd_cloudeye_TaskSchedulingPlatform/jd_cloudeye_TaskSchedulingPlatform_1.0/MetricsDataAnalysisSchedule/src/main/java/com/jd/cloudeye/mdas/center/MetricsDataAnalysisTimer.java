package com.jd.cloudeye.mdas.center;

import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.cloudeye.tsc.management.MQManager;
import com.jd.cloudeye.tsc.management.ThreadPoolManager;
import com.jd.cloudeye.tsc.management.ToolBox;
import com.jd.cloudeye.tsc.masterslave.SwitchMasterSlaveUtil;

/**
 * 发送指标分析数据 
 * 定时器频率：1分钟 
 * 下发时间：每分钟的第10秒 
 * 数据格式：MetricsDataAnalysisInfo
 * 
 * @date 2013-03-02
 * @author duliang
 */
public class MetricsDataAnalysisTimer extends TimerTask {

	private final static Logger LOGGER = LoggerFactory.getLogger(MetricsDataAnalysisTimer.class);
	private ThreadPoolManager threadPoolManagerMDAT;

	public MetricsDataAnalysisTimer() {
		this.threadPoolManagerMDAT = new ThreadPoolManager(MetricsDataAnalysisUtil.TASK_THREAD_COUNT);
	}

	@Override
	public void run() {

		// 首先获得分析任务的时间点(前一分钟的整分钟数)
		long taskTime = ToolBox.getNextMinuteForInitial(-1, 0).getTime();
		
		try {
			if (SwitchMasterSlaveUtil.SEND_DATA_STATUS) {
				synchronized (MetricsDataAnalysisUtil.CACHE_METRICS_DATA_ANALYSIS_LIST) {
					if (MetricsDataAnalysisUtil.CACHE_METRICS_DATA_ANALYSIS_LIST.size() > 0) {
						for (MetricsDataAnalysisInfo metricsDataAnalysisInfo : MetricsDataAnalysisUtil.CACHE_METRICS_DATA_ANALYSIS_LIST) {
							if("JAE".equals(metricsDataAnalysisInfo.getServiceCode())){
								metricsDataAnalysisInfo.setTaskTime(taskTime - MetricsDataAnalysisUtil.JAE_ANALYSIS_DELAY_TIME);
							}else{
								metricsDataAnalysisInfo.setTaskTime(taskTime);
							}
							threadPoolManagerMDAT.execute(sendDataToMQ(metricsDataAnalysisInfo));
						}
					}
				}
			}
		} catch (Exception e) {
			SwitchMasterSlaveUtil.SCAN_DB_STATUS = false;
			LOGGER.error(ToolBox.logError(MetricsDataAnalysisUtil.MODULE_NAME,
					"MetricsDataAnalysisTimer", "Timer ERROR!"), e);
		}
	}

	
	/**
	 * 调用MQ接口发送数据
	 */
	private Runnable sendDataToMQ(final MetricsDataAnalysisInfo metricsDataAnalysisInfo) {
		return new Runnable() {
			public void run() {
				try {
					new MQManager().sendObjectToMQ(MetricsDataAnalysisUtil.TASK_QUEUE_NAME,metricsDataAnalysisInfo);
					
					//日志打印
					if(LOGGER.isDebugEnabled()){
						String logContent = Long.toString(metricsDataAnalysisInfo.getUsinId()) + "|" + 
						metricsDataAnalysisInfo.getUserId() + "|" + 
						metricsDataAnalysisInfo.getServiceCode() + "|" + 
						metricsDataAnalysisInfo.getInstanceId() + "|" + 
						metricsDataAnalysisInfo.getMetricsCode() + "|" +
						Long.toString(metricsDataAnalysisInfo.getTaskTime());
	
						LOGGER.debug(ToolBox.logInfo(MetricsDataAnalysisUtil.MODULE_NAME, "MetricsDataAnalysisTimer", 
								"sendDataToMQ", logContent));
					}
					
				} catch (Exception e) {
					LOGGER.error(ToolBox.logError(MetricsDataAnalysisUtil.MODULE_NAME,
							"MetricsDataAnalysisTimer","SendDataToMQ ERROR!"), e);
				}
			}
		};
	}

}
