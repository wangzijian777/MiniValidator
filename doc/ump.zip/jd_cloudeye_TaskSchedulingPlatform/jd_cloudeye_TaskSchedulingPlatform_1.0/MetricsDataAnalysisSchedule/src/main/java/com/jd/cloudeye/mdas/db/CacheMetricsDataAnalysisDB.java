package com.jd.cloudeye.mdas.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jd.cloudeye.mdas.center.MetricsDataAnalysisUtil;
import com.jd.cloudeye.mdas.center.MetricsDataAnalysisInfo;
import com.jd.cloudeye.tsc.management.DBManager;
import com.jd.cloudeye.tsc.management.ToolBox;

/**
 * 缓存指标分析的信息
 * 
 * @author duliang
 * @date 2013-03-01
 */
public class CacheMetricsDataAnalysisDB {
    private final static Logger LOGGER = LoggerFactory.getLogger(CacheMetricsDataAnalysisDB.class);
    private JdbcTemplate jdbcTemplate;
    
    /**
     * 数据库注册连接
     */
    public CacheMetricsDataAnalysisDB() {
    	this.jdbcTemplate = new DBManager().getJdbcTemplate();
    }
    
    
    /**
     * 缓存指标分析任务的信息
     * 格式：List<MetricsDataAnalysisInfo>
     */
    public void loadCache(){
    	try{
    		List<MetricsDataAnalysisInfo> metricsAnalysisInfoList = new ArrayList<MetricsDataAnalysisInfo>();
    		
    		HashMap<String,String> serviceMetricsMap = getServiceMetricsFromDB();
    		HashMap<Long,String> userServiceInstanceMap = getUserServiceInstanceFromDB();

			for (Map.Entry<Long,String> entry_usi : userServiceInstanceMap.entrySet()) {
				Long usi_usinId = entry_usi.getKey();
				String userId_serviceCode_instanceId = entry_usi.getValue();
				
				String[] usiArray = userId_serviceCode_instanceId.split(",");
				String usi_userId = usiArray[0];
				String usi_serviceCode = usiArray[1];
				String usi_instanceId = usiArray[2];
				
				for(Map.Entry<String,String> entry_sm : serviceMetricsMap.entrySet()){
					String sm_metricsCode = entry_sm.getKey();
					String sm_serviceCode = entry_sm.getValue(); 
					
					if(usi_serviceCode.equals(sm_serviceCode)){
						MetricsDataAnalysisInfo metricsAnalysisInfo = new MetricsDataAnalysisInfo();
						metricsAnalysisInfo.setUsinId(usi_usinId.longValue());
						metricsAnalysisInfo.setUserId(usi_userId);
						metricsAnalysisInfo.setServiceCode(usi_serviceCode);
						metricsAnalysisInfo.setInstanceId(usi_instanceId);
						metricsAnalysisInfo.setMetricsCode(sm_metricsCode);
						metricsAnalysisInfoList.add(metricsAnalysisInfo);
					}
				}
			}
			
			//同步更新缓存
			synchronized (MetricsDataAnalysisUtil.CACHE_METRICS_DATA_ANALYSIS_LIST) {
				if(MetricsDataAnalysisUtil.CACHE_METRICS_DATA_ANALYSIS_LIST.size()>0){
					MetricsDataAnalysisUtil.CACHE_METRICS_DATA_ANALYSIS_LIST.clear();
				}
				if(metricsAnalysisInfoList.size()>0){
					for(MetricsDataAnalysisInfo metricsDataAnalysisInfo : metricsAnalysisInfoList){
						if(metricsDataAnalysisInfo!=null){
							MetricsDataAnalysisUtil.CACHE_METRICS_DATA_ANALYSIS_LIST.add(metricsDataAnalysisInfo);
						}
					}
				}
			}
    		
			//打印日志
    		String logContent = "Cache MetricsDataAnalysis |" + ToolBox.getNowTime() + " | size: " + MetricsDataAnalysisUtil.CACHE_METRICS_DATA_ANALYSIS_LIST.size() + "";
    		LOGGER.info(ToolBox.logInfo(MetricsDataAnalysisUtil.MODULE_NAME, "CacheMetricsDataAnalysisDB", 
    				"loadCache", logContent));
    		
    	}catch(Exception e){
    		String logContent = "Catch MetricsDataAnalysis ERROR!";
    		LOGGER.error(ToolBox.logError(MetricsDataAnalysisUtil.MODULE_NAME, "CacheMetricsDataAnalysisDB", logContent),e);
    	}
    }
    
    
    /**
     * 查询服务-指标相关的信息(jce_dictionary表)
     * 格式：MAP(metricsCode, serviceCode)
     */
    public HashMap<String, String> getServiceMetricsFromDB() {
    	
    	HashMap<String,String> serviceMetricsMap = new HashMap<String,String>();
    	String sql = " select t.dCode,j.jce_dictionary_code from " +
				" (select id,jce_dictionary_code AS dCode from jce_dictionary where jce_parent_id=? and is_valid=?) t " +
				" join jce_dictionary j on t.id = j.jce_parent_id where j.is_valid=? ";
		
		Object[] paramsForSelect = new Object[] { MetricsDataAnalysisUtil.SERVICE_PARENT_ID, MetricsDataAnalysisUtil.VALID, MetricsDataAnalysisUtil.VALID};
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
		
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
				String metricsCode = ((String) row.get("jce_dictionary_code")).trim();
				String serviceCode = ((String) row.get("dCode")).trim();
				serviceMetricsMap.put(metricsCode, serviceCode);
		    }
		}
		return serviceMetricsMap;
    }
    
    
    /**
     * 查询用户-服务-实例相关的信息(jce_service_instance表)
     * 格式：MAP(usinId,userId_serviceCode_instanceId)
     */
    public HashMap<Long, String> getUserServiceInstanceFromDB() {
    	
    	HashMap<Long,String> userServiceInstanceMap = new HashMap<Long,String>();
    	String sql = " select id,jce_boss_user_id,jce_service_code,jce_instance_key from jce_service_instance where is_valid=? ";
		
		Object[] paramsForSelect = new Object[] { MetricsDataAnalysisUtil.VALID };
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
		
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
		    	Long usinId = (Long) row.get("id");
				String userId = ((String) row.get("jce_boss_user_id")).trim();
				String serviceCode = ((String) row.get("jce_service_code")).trim();
				String instanceId = (String)row.get("jce_instance_key")==null?MetricsDataAnalysisUtil.KNULL:((String)row.get("jce_instance_key")).trim();
				String userId_serviceCode_instanceId = userId + "," + serviceCode + "," + instanceId;
				userServiceInstanceMap.put(usinId,userId_serviceCode_instanceId);
		    }
		}
		return userServiceInstanceMap;
    }
    
}
