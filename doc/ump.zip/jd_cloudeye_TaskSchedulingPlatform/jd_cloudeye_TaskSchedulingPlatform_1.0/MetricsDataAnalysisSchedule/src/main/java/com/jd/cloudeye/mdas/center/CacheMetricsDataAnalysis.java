package com.jd.cloudeye.mdas.center;

import com.jd.cloudeye.mdas.db.CacheMetricsDataAnalysisDB;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.source.TimerSource;

/**
 * 定时缓存指标分析的数据
 * 频率：10分钟
 * 启动时间：开机启动
 * 
 * @author duliang
 * @date 2013-03-01
 */
public class CacheMetricsDataAnalysis extends TimerSource {

	protected void doTimerTask(Sink sink) {
		new CacheMetricsDataAnalysisDB().loadCache();
	}

}
