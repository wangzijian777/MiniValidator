package com.jd.cloudeye.tsc.management;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * 获取数据库连接
 * 
 * @date 2013-02-28
 * @author duliang
 */
public class DBManager {
    
	 public JdbcTemplate jdbcTemplate;

    /**
     * 获取DB连接
     * @return
     */
    public JdbcTemplate getJdbcTemplate() {
		jdbcTemplate = (JdbcTemplate) TaskSchedulingStartManagers.factory.getBean("jdbcTemplate");
		return jdbcTemplate;
    }

}
