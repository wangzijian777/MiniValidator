package com.jd.cloudeye.tsc.masterslave;

import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.cloudeye.tsc.management.TaskSchedulingUtil;
import com.jd.cloudeye.tsc.management.ToolBox;

/**
 * 任务调度中心主从切换定时器扫描数据库程序。
 * 
 * @date 2013-02-28
 * @author duliang
 */
public class SwitchMasterSlaveTimer extends TimerTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(SwitchMasterSlaveTimer.class);
    
    /**
     * 开始运行定时器
     */
    @Override
    public void run() {
        try {
        	long taskTime = System.currentTimeMillis();
        	
            //判断是否执行扫描数据库的动作
            if (SwitchMasterSlaveUtil.SCAN_DB_STATUS) {

                boolean isUpdateDB = new SwitchMasterSlaveDB().switchMasterSlave();
                
                //只要更新数据库成功，设置本机为主机，否则设置自己为从机
                if (isUpdateDB) {
                	SwitchMasterSlaveUtil.SEND_DATA_STATUS = true;
                } else {
                	SwitchMasterSlaveUtil.SEND_DATA_STATUS = false;
                }
            } else {
                //如果本次不执行扫描数据库的动作，那么下一次继续执行扫描数据库的动作
            	SwitchMasterSlaveUtil.SCAN_DB_STATUS = true;
            }
            String logContent = ToolBox.fomartTime(taskTime) + "|" + SwitchMasterSlaveUtil.SCAN_DB_STATUS + "|" + SwitchMasterSlaveUtil.SEND_DATA_STATUS;
            LOGGER.info(ToolBox.logInfo(TaskSchedulingUtil.MODULE_NAME, "SwitchMasterSlaveTimer","run",logContent));
        
        } catch (Exception e) {
        	SwitchMasterSlaveUtil.SEND_DATA_STATUS = false;
            LOGGER.error(ToolBox.logError(TaskSchedulingUtil.MODULE_NAME, "SwitchMasterSlaveTimer","Timer ERROR!"), e);
        }
        
    }

    

}
