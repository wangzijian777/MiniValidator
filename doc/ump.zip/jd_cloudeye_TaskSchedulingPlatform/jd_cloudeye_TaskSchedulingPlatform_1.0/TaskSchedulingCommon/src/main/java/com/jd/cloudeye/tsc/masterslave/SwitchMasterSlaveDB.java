package com.jd.cloudeye.tsc.masterslave;

import org.springframework.jdbc.core.JdbcTemplate;

import com.jd.cloudeye.tsc.management.DBManager;
import com.jd.cloudeye.tsc.management.TaskSchedulingStartManagers;

/**
 * 扫描数据库，检查是否有更新数据库，实现主从切换
 * 
 * @date 2013-03-04
 * @author duliang
 */
public class SwitchMasterSlaveDB {
    private JdbcTemplate jdbcTemplate;

    /**
     * 主从切换数据库注册连接
     */
    public SwitchMasterSlaveDB() {
    	this.jdbcTemplate = new DBManager().getJdbcTemplate();
    }

    /**
     * 检查数据库中主从切换表是否有记录，如果没有则insert一条(只在程序第一次启动的时候检查一次)
     */
    public int checkRecordInDB() {
		int insertCount = 0;
		String sqlForSelect = " select count(1) as count from jce_task_scheduling_center where jce_tsc_taskname = ? ";
		final Object[] paramsForSelect = new Object[] { SwitchMasterSlaveUtil.TASK_NAME };
	
		String sqlForInsert = " insert jce_task_scheduling_center(jce_tsc_taskname,jce_tsc_description) values(?,?) ";
		final Object[] paramsForInsert = new Object[] { SwitchMasterSlaveUtil.TASK_NAME, SwitchMasterSlaveUtil.TASK_DES };
	
		int queryCount = this.jdbcTemplate.queryForInt(sqlForSelect,paramsForSelect);
		if (queryCount < 1) {
		    insertCount = this.jdbcTemplate.update(sqlForInsert,paramsForInsert);
		}
		return insertCount;
    }

    
    /**
     * 扫描数据库，检查是否有更新数据库 实现主从切换
     */
    public boolean switchMasterSlave() {
		String sql = " update jce_task_scheduling_center set jce_tsc_address=?,jce_tsc_locktime=sysdate() where jce_tsc_taskname = ? and ("
			+ " (jce_tsc_address is null and jce_tsc_locktime is null) or (jce_tsc_address=?)"
			+ " or (jce_tsc_address!=? and TIMESTAMPDIFF(SECOND,jce_tsc_locktime,sysdate()) > ?)"
			+ ")";
		final Object[] params = new Object[] { TaskSchedulingStartManagers.hostName,
				SwitchMasterSlaveUtil.TASK_NAME, TaskSchedulingStartManagers.hostName,
				TaskSchedulingStartManagers.hostName, SwitchMasterSlaveUtil.SCAN_DB_TIMEOUT };
		int updateCount = this.jdbcTemplate.update(sql, params);
		if (updateCount > 0)
		    return true;
		return false;
    }

}
