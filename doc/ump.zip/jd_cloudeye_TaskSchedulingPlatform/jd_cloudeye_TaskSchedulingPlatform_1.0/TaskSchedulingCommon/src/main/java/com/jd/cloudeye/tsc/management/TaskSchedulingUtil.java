package com.jd.cloudeye.tsc.management;

import java.io.File;

import com.jd.mas.bootstrap.NodeCtl;

/**
 * 任务调度中心相关常量
 * 
 * @author duliang
 * @date 2013-02-27
 */
public class TaskSchedulingUtil {
    
	
	/**
	 * 配置文件地址
	 */
    public static final String APP_FILE_PATH = NodeCtl.APP_BASEDIR + File.separator
	    + "conf" + File.separator + "ApplicationContext.xml";
    
    public static final String CONF_FILE_PATH = NodeCtl.APP_BASEDIR + File.separator
	    + "conf" + File.separator + "conf.properties";
	
    
    /**
     * 模块名
     */
    public static final String MODULE_NAME = "TaskSchedulingCommon";
    
}
