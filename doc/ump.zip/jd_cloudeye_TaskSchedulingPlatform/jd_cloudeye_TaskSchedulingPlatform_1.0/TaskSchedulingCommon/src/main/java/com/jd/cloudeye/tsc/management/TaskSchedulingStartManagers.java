package com.jd.cloudeye.tsc.management;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.jd.cloudeye.tsc.masterslave.SwitchMasterSlaveUtil;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 启动加载管理
 * 
 * @author duliang
 * @date 2013-02-28
 */
public class TaskSchedulingStartManagers {

	private final static Logger LOGGER = LoggerFactory.getLogger(TaskSchedulingStartManagers.class);
	public static ApplicationContext factory;
	public static String hostName = "";

	static {
		
		//加载Spring配置文件  
		factory = new FileSystemXmlApplicationContext("file:" + TaskSchedulingUtil.APP_FILE_PATH);
		
		//获得本机IP作为hostName
		try {
		    InetAddress addr = InetAddress.getLocalHost();
		    hostName = addr.getHostAddress() + "|" + Long.toString(System.currentTimeMillis());
		} catch (UnknownHostException e) {
		    hostName = SwitchMasterSlaveUtil.TASK_NAME + "|" + Long.toString(System.currentTimeMillis());
		    LOGGER.warn(ToolBox.logWarn(TaskSchedulingUtil.MODULE_NAME, "TaskSchedulingStartManagers", 
		    		"static" ,"Get IP Address ERROR at TSP Start."));
		}
		
		
		//启动时打印配置信息
    	String dbJDBCUrl = AppPropertiesManager.getProperty("db.jdbcUrl");
    	String dbInitialSize = AppPropertiesManager.getProperty("db.initialSize");
    	String dbMaxActive = AppPropertiesManager.getProperty("db.maxActive");
    	String mqBrokerURL = AppPropertiesManager.getProperty("mq.brokerURL");
    	String mqSessionCacheSize = AppPropertiesManager.getProperty("mq.sessionCacheSize");
    	
    	LOGGER.info(ToolBox.logInfo(TaskSchedulingUtil.MODULE_NAME, "TaskSchedulingStartManagers", 
    			"static","DB_JDBCUrl : " + dbJDBCUrl));
    	LOGGER.info(ToolBox.logInfo(TaskSchedulingUtil.MODULE_NAME, "TaskSchedulingStartManagers", 
    			"static","DB_InitialSize : " + dbInitialSize));
    	LOGGER.info(ToolBox.logInfo(TaskSchedulingUtil.MODULE_NAME, "TaskSchedulingStartManagers", 
    			"static","DB_MaxActive : " + dbMaxActive));
    	LOGGER.info(ToolBox.logInfo(TaskSchedulingUtil.MODULE_NAME, "TaskSchedulingStartManagers", 
    			"static","MQ_BrokerURL : " + mqBrokerURL));
    	LOGGER.info(ToolBox.logInfo(TaskSchedulingUtil.MODULE_NAME, "TaskSchedulingStartManagers", 
    			"static","MQ_SessionCacheSize : " + mqSessionCacheSize));
		LOGGER.info(ToolBox.logInfo(TaskSchedulingUtil.MODULE_NAME, "TaskSchedulingStartManagers", 
				"static","HostName : " + hostName));
		
	}
	

}
