package com.jd.cloudeye.tsc.masterslave;

import com.jd.cloudeye.tsc.management.AppPropertiesManager;

/**
 * 任务调度中心相关常量
 * 
 * @author duliang
 * @date 2013-02-27
 */
public class SwitchMasterSlaveUtil {
    
    /**
     * 扫描数据库的任务名称
     */
    public static final String TASK_NAME = "JDCE_TSP_SwitchMasterSlave";
    
    /**
     * 扫描数据库的任务名称描述
     */
    public static final String TASK_DES = "SwitchMasterSlave_Task";
    
    /**
     * 扫描超时时间
     */
    public static long SCAN_DB_TIMEOUT = Long.parseLong(AppPropertiesManager.getProperty("SwitchMasterSlave_ScanDB_TimeOut"));

    /**
     * 任务频率
     */
    public static long TASK_TIMER_PERIOD = Long.parseLong(AppPropertiesManager.getProperty("SwitchMasterSlave_Task_TimePeriod"));
    
    
    /**
     * 判断是否需要发送数据的状态(不写在配置文件中)
     */
    public static boolean SEND_DATA_STATUS = false;

    /**
     * 判断是否需要扫描数据库的状态(不写在配置文件中)
     */
    public static boolean SCAN_DB_STATUS = true;

    
}
