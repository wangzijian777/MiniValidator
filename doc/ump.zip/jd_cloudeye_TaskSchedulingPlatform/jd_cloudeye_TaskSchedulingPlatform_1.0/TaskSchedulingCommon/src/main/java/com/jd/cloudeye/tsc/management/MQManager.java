package com.jd.cloudeye.tsc.management;

import java.io.Serializable;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/**
 * 调用MQ接口发送数据
 * 
 * @date 2013-02-28
 * @author duliang
 */
public class MQManager {
    
    private JmsTemplate jmsTemplate;

    /**
     * 注册连接
     */
    public MQManager() {
        this.jmsTemplate = (JmsTemplate) TaskSchedulingStartManagers.factory.getBean("jmsTemplate");
    }

    
    /**
     * 调用MQ接口发送数据
     * 
     * @param dataMessage
     */
    public void sendDataToMQ(final String queueName, final String dataMessage) {
        jmsTemplate.send(queueName,new MessageCreator() {
            public Message createMessage(Session session) throws JMSException {
                TextMessage mm = session.createTextMessage();
                mm.setText(dataMessage);
                return mm;
            }
        });
    }
    
    
    /**
     * 调用MQ接口发送对象
     * 
     * @param dataMessage
     */
    public void sendObjectToMQ(final String queueName, final Serializable dataMessage) {
    	jmsTemplate.send(queueName,new MessageCreator() {
    		public Message createMessage(Session session) throws JMSException {
    			ObjectMessage mm = session.createObjectMessage();
    			mm.setObject(dataMessage);
    			return mm;
    		}
    	});
    }

}
