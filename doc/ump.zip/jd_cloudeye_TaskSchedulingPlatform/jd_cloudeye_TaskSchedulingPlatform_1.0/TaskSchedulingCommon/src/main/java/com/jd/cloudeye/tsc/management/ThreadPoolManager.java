package com.jd.cloudeye.tsc.management;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 定义线程池管理
 * 
 * @author duliang
 * @date 2013-02-27
 */
public class ThreadPoolManager extends ThreadPoolExecutor {

    public ThreadPoolManager(int poolSize) {
	super(poolSize, poolSize, 5, TimeUnit.SECONDS,new LinkedBlockingQueue<Runnable>());
    }
}
