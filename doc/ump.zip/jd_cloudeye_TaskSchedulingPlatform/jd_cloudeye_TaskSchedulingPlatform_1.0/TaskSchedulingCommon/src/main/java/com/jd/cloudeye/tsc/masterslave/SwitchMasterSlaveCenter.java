package com.jd.cloudeye.tsc.masterslave;

import java.util.Timer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.cloudeye.tsc.management.TaskSchedulingUtil;
import com.jd.cloudeye.tsc.management.ToolBox;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.Source;


/**
 * 任务调度中心主从切换程序。
 * 
 * @date 2013-02-28
 * @author duliang
 */
public class SwitchMasterSlaveCenter implements Source {

    private final static Logger LOGGER = LoggerFactory.getLogger(SwitchMasterSlaveCenter.class);
    
    /**
     * 主从扫描程序入口
     */
    public void open() {
		
		// 判断数据库主从切换表是否有记录，如果没有则需要insert一条记录
		try {
		    new SwitchMasterSlaveDB().checkRecordInDB();
		} catch (Exception e) {
		    LOGGER.error(ToolBox.logError(TaskSchedulingUtil.MODULE_NAME, "SwitchMasterSlaveCenter",
		    		"Check MasterSlave Record In DB ERROR!"), e);
		}
	
		
		//开始进行主从切换扫描数据库程序
		Timer switchMasterSlaveTimer = new Timer("SwitchMasterSlaveTimer");
			switchMasterSlaveTimer.scheduleAtFixedRate(new SwitchMasterSlaveTimer(), 
					ToolBox.getNextMinuteForInitial(1,0), SwitchMasterSlaveUtil.TASK_TIMER_PERIOD);
    }

    
    public void close() {}

    public void connect(Sink arg0) {}

    public boolean isBlocking() {
    	return false;
    }

}
