package com.jd.cloudeye.tsc.management;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;


import com.jd.cloudeye.tsc.management.TaskSchedulingUtil;

/**
 * 获取conf.properties的配置信息
 * 
 * @author dulianginfo
 * @date 2013-02-27
 */
@SuppressWarnings("unused")
public class AppPropertiesManager{
	
	private final static Logger log ;
	
	private static Map<String, String> propMap ;
	
	static{
		log = Logger.getLogger(AppPropertiesManager.class);
		propMap = new HashMap<String, String>();
		Properties prop = new Properties();
		InputStream is = null;
		try {
			is = new FileInputStream(TaskSchedulingUtil.CONF_FILE_PATH);
			if(is != null)
			{
				prop.load(is);
				if(!prop.isEmpty())
				{
					Set<Object> keyset = prop.keySet();
					for(Object key : keyset)
					{
						propMap.put(key.toString(), prop.get(key).toString());
					}
					if(log.isDebugEnabled())
					{
						log.debug(TaskSchedulingUtil.CONF_FILE_PATH + " :" + propMap.toString());
					}
				}
			}
			else
			{
				log.error(ToolBox.logError(TaskSchedulingUtil.MODULE_NAME, "AppPropertiesManager","file " + TaskSchedulingUtil.CONF_FILE_PATH + " can not be fond"));
			}
		} catch (IOException e) {
			String logContent = "Load conf.properties is ERROR!";
			log.error(ToolBox.logError(TaskSchedulingUtil.MODULE_NAME, "AppPropertiesManager",logContent),e);
			
		}
		finally
		{
			if(is != null)
			{
				try {
					is.close();
				} catch (IOException e) {
				}
			}
		}
	}
	
	
	public static String getProperty(String key){		
		return getProperty(key, null);
	}
	
	public static String getProperty(String key, String defautValue){
		if(propMap == null || propMap.isEmpty())
		{
			throw new RuntimeException("load properties error:" + TaskSchedulingUtil.CONF_FILE_PATH);
		}
		String value = propMap.get(key);
		return value == null ? defautValue : value.trim(); // 增加配置项内容的trim
	}
	
}