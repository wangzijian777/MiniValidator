package com.jd.cloudeye.tsc.management;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 常用的方法
 * 
 * @author duliang
 * @date 2012-05-04
 */
public class ToolBox {

    /**
     * 格式化当前时间
     * 
     * @return
     */
    public static String getNowTime() {
    	SimpleDateFormat DATE_FORMAT_FULL = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	return DATE_FORMAT_FULL.format(new Date());
    }

    /**
     * 格式化时间
     * 
     * @param time
     * @return
     */
    public static String fomartTime(long time) {
    	SimpleDateFormat DATE_FORMAT_FULL = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	return DATE_FORMAT_FULL.format(time);
    }

    /**
     * 格式化时间忽略秒
     * 
     * @return
     */
    public static String getTimeIgnoreSecond(long time) {
    	SimpleDateFormat DATE_FORMAT_IGNORE_SECOND = new SimpleDateFormat("yyyy-MM-dd HH:mm:00");
    	return DATE_FORMAT_IGNORE_SECOND.format(time);
    }

    /**
     * 获得当前时间后N分钟的第M秒的整点时间,并且毫秒数为0，返回date
     * @param minute
     * @param second
     * @return
     */
    public static Date getNextMinuteForInitial(int minute,int second) {
		Calendar now = Calendar.getInstance();
		now.add(Calendar.MINUTE, minute);
		now.set(Calendar.SECOND, second);
		now.set(Calendar.MILLISECOND, 0);
		Date date = now.getTime();
		return date;
    }
    
    /**
     * 获得N分钟的整数倍的下一个时间点并设置固定的秒数,并且毫秒数为0,返回date
     * @param multipleMinute
     * @return
     */
    public static Date getTimePointForMultipleMinute(int multipleMinute,int second) {
		Calendar now = Calendar.getInstance();
		now.set(Calendar.SECOND, second);
		now.set(Calendar.MILLISECOND, 0);
	
		int mimute = now.get(12);
		Date date = null;
		if (mimute % multipleMinute == 0) {
		    date = now.getTime();
		} else {
		    int newMinute = mimute + (multipleMinute - mimute % multipleMinute);
		    now.set(Calendar.MINUTE, newMinute);
		    date = now.getTime();
		}
	
		return date;
    }
    
   /**
    * 获得每小时里固定分钟点的时间点，如果当前时间超过这个小时的这个分钟点,则返回下一个小时的这个分钟点
    * 并且秒数和毫秒为0,返回date
    * @param timePoint
    * @return
    */
    public static Date getTimePointForPerHourFixedMinute(int mimutePoint) {
    	Date date = null;
    	
		Calendar now = Calendar.getInstance();
		now.set(Calendar.SECOND, 0);
		now.set(Calendar.MILLISECOND, 0);
	
		int mimute = now.get(12);
		
		if(mimute <= mimutePoint){
			now.set(Calendar.MINUTE, mimutePoint);
			date = now.getTime();
		}else{
			now.add(Calendar.HOUR_OF_DAY, 1);
			now.set(Calendar.MINUTE, mimutePoint);
			date = now.getTime();
		}
    	
    	return date;
    }
    
    
    /**
     * 获得每天里固定小时的时间点，如果当前时间超过当天的这个小时点,则返回下一天的这个小时点
     * 并且秒数和毫秒为0,返回date
     * @param timePoint
     * @return
     */
    public static Date getTimePointForPerDayFixedHour(int hourPoint) {
    	Date date = null;
    	
    	Calendar now = Calendar.getInstance();
    	
    	Calendar taskTime = Calendar.getInstance();
    	taskTime.set(Calendar.HOUR_OF_DAY, hourPoint);
    	taskTime.set(Calendar.MINUTE, 0);
    	taskTime.set(Calendar.SECOND, 0);
    	taskTime.set(Calendar.MILLISECOND, 0);
    	
    	if(now.before(taskTime)){
    		date = taskTime.getTime();
    	}else{
    		taskTime.add(Calendar.DATE, 1);
    		date = taskTime.getTime();
    	}
    	
    	return date;
    }
    
    
    /**
     * 获得需要发送数据的时间点 参数为延迟时间
     * 
     * @return 当前时间 - 延迟时间
     */
    public static long getNewTaskTimePoint(long delayTime) {
		long newTaskStartTimePoint = 0;
		long currentTime = System.currentTimeMillis();
		long delayTimeNow = currentTime - delayTime;
		
		SimpleDateFormat DATE_FORMAT_IGNORE_SECOND = new SimpleDateFormat("yyyy-MM-dd HH:mm:00");
		
		String startDate = DATE_FORMAT_IGNORE_SECOND.format(delayTimeNow);
		Date delayData = null;
		try {
		    delayData = DATE_FORMAT_IGNORE_SECOND.parse(startDate);
		} catch (ParseException e) {}
		newTaskStartTimePoint = delayData.getTime();
		return newTaskStartTimePoint;
    }
    
    
    
    /**
     * 日志输出info级别
     * @param moduleName
     * @param className
     * @param methodName
     * @return
     */
    public static String logInfo(String moduleName,String className,String methodName,String content) {
    	String infoMessage = "[INFO]["+moduleName+"]["+className+"]["+methodName+"]" + content ;
    	return infoMessage;
    }
    
    
    /**
     * 日志输出warn级别
     * @param moduleName
     * @param className
     * @param methodName
     * @return
     */
    public static String logWarn(String moduleName,String className,String methodName,String content) {
    	String warnMessage = "[WARN]["+moduleName+"]["+className+"]["+methodName+"]" + content;
    	return warnMessage;
    }
    
    /**
     * 日志输出error级别
     * @param moduleName
     * @param className
     * @return
     */
    public static String logError(String moduleName,String className,String content) {
    	String errorMessage = "[TSP#"+moduleName+"#"+className+"]" + content;
    	return errorMessage;
    }
    

}
