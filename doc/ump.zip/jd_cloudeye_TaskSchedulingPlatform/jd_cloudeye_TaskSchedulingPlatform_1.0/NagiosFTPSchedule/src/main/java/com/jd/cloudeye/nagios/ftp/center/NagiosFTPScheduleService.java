package com.jd.cloudeye.nagios.ftp.center;

import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Logger;

import com.jd.cloudeye.nagios.ftp.NagiosFTPUtil;
import com.jd.cloudeye.tsc.management.MQManager;
import com.jd.cloudeye.tsc.management.ToolBox;
import com.jd.cloudeye.tsc.masterslave.SwitchMasterSlaveUtil;

/**
 * Nagios FTP 文件获取任务下发服务类
 * 
 * @author chenhualiang
 * @since 2013-03-28
 */
public class NagiosFTPScheduleService {
	
	private static Logger LOGGER = Logger.getLogger(NagiosFTPScheduleService.class);
	
	/**
	 * 单利 
	 */
	private static NagiosFTPScheduleService instance = new NagiosFTPScheduleService();
	
	private NagiosFTPScheduleService(){}
	
	public static final NagiosFTPScheduleService getInstatnce()
	{
		return instance;
	}
	
	/**
	 * 定时线程 
	 */
	private Timer nagiosFTPTimer = new Timer("nagiosFTPTimer");
	
	/**
	 * 处理业务 
	 */
	public void doTask()
	{
		if(LOGGER.isDebugEnabled())
		{
			LOGGER.debug("***start NagiosFTPSchedule task");
		}
		if(!SwitchMasterSlaveUtil.SEND_DATA_STATUS)
		{
			if(LOGGER.isDebugEnabled())
			{
				LOGGER.debug("***SEND_DATA_STATUS = false ,do nothing" );
			}
			return ;
		}
		/**
		 * 判断是否停止nagios采集任务
		 */
		if("DRC".equals(NagiosFTPUtil.STOP_NAGIOS_FTP))
		{
			if(LOGGER.isDebugEnabled())
			{
				LOGGER.debug("***STOP_NAGIOS_FTP = DRC ,do nothing" );
			}
			return ;
		}
		nagiosFTPTimer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				try{
					String command = NagiosFTPUtil.NAGIOS_FTP_COMMAND + "|" + NagiosFTPUtil.getNow();
					new MQManager().sendDataToMQ(NagiosFTPUtil.NAGIOS_FTP_MQ_QUEUE,command);
					LOGGER.info(ToolBox.logInfo("NagiosFTPSchedule", "NagiosFTPScheduleService", "doTask","{queue='" + NagiosFTPUtil.NAGIOS_FTP_MQ_QUEUE + "',command='" + command + "'}"));
				}catch (Throwable e) {
					SwitchMasterSlaveUtil.SCAN_DB_STATUS = false;
					LOGGER.error(ToolBox.logError("NagiosFTPSchedule","NagiosFTPScheduleService", "Timer ERROR!"), e);
				}
			}
			
		}, 0);
	}

}
