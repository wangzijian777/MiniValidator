package com.jd.cloudeye.nagios.ftp;

import java.text.SimpleDateFormat;

import com.jd.cloudeye.tsc.management.AppPropertiesManager;

/**
 * nagios ftp任务下发工具类
 */
public class NagiosFTPUtil {
	
	/**
	 * 在MQ中保存获取 nagios ftp文件指令的队列
	 */
	public static final String NAGIOS_FTP_MQ_QUEUE = AppPropertiesManager.getProperty("nagios.ftp.mq.queue");
	
	/**
	 * 在MQ中保存获取 nagios ftp文件指令
	 */
	public static final String NAGIOS_FTP_COMMAND = AppPropertiesManager.getProperty("nagios.ftp.command");
	
	/**
	 * 判断是否停止nagios采集任务
	 */
	public static final String STOP_NAGIOS_FTP = AppPropertiesManager.getProperty("CgatherTask_Task_sendFlag");
	
	public static String getNow()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		return sdf.format(System.currentTimeMillis());
	}

}
