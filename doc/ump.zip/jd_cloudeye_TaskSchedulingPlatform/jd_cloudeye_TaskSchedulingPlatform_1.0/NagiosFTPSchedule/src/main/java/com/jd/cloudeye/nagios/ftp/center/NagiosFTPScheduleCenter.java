package com.jd.cloudeye.nagios.ftp.center;

import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.source.TimerSource;

/**
 * Nagios FTP文件获取定时间隔任务
 * 
 * @author chenhualiang
 * @since 2013-03-08
 *
 */
public class NagiosFTPScheduleCenter extends TimerSource
{
	
	private NagiosFTPScheduleService service = NagiosFTPScheduleService.getInstatnce();
	
	@Override
	protected void doTimerTask(Sink sink) {
		service.doTask();
	}
}
