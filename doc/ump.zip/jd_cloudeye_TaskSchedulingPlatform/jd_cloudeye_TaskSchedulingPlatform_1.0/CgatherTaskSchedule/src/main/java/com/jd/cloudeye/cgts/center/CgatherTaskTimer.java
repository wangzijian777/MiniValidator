package com.jd.cloudeye.cgts.center;

import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.cloudeye.tsc.management.MQManager;
import com.jd.cloudeye.tsc.management.ThreadPoolManager;
import com.jd.cloudeye.tsc.management.ToolBox;
import com.jd.cloudeye.tsc.masterslave.SwitchMasterSlaveUtil;

/**
 * 启动下发时间：开机后的后两分钟的第30秒
 * 定时器频率：30秒
 * 下发时间：每分钟的第0秒和第30秒
 * 数据格式：ServerInfo
 * 
 * @date 2013-08-21
 * @author duliang
 */
public class CgatherTaskTimer extends TimerTask {

	private final static Logger LOGGER = LoggerFactory.getLogger(CgatherTaskTimer.class);
	private ThreadPoolManager threadPoolManagerCGTT;

	public CgatherTaskTimer() {
		this.threadPoolManagerCGTT = new ThreadPoolManager(CgatherTaskUtil.TASK_THREAD_COUNT);
	}

	@Override
	public void run() {

		// 首先获得分析任务的时间点
		long taskTime = System.currentTimeMillis();
		
		try {
			if (SwitchMasterSlaveUtil.SEND_DATA_STATUS) {
				synchronized (CgatherTaskUtil.CACHE_CGATHER_TASK_LIST) {
					if (CgatherTaskUtil.CACHE_CGATHER_TASK_LIST.size() > 0) {
						for (ServerInfo serverInfo : CgatherTaskUtil.CACHE_CGATHER_TASK_LIST) {
							serverInfo.setTime(taskTime);
							threadPoolManagerCGTT.execute(sendDataToMQ(serverInfo));
						}
					}
				}
			}
		} catch (Exception e) {
			SwitchMasterSlaveUtil.SCAN_DB_STATUS = false;
			LOGGER.error(ToolBox.logError(CgatherTaskUtil.MODULE_NAME,
					"CgatherTaskTimer", "Timer ERROR!"), e);
		}
	}

	
	/**
	 * 调用MQ接口发送数据
	 */
	private Runnable sendDataToMQ(final ServerInfo serverInfo) {
		return new Runnable() {
			public void run() {
				try {
					new MQManager().sendObjectToMQ(CgatherTaskUtil.TASK_QUEUE_NAME,serverInfo);
					
					
					if(LOGGER.isDebugEnabled()){
						//日志打印
						String logContent = serverInfo.getIp() + "|" + 
						serverInfo.getCommunity() + "|" + 
						serverInfo.getSendFlag() + "|" + 
						serverInfo.getServerMedian() + "|" + 
						serverInfo.getSystemFlag() + "|" +
						serverInfo.getIndexs().size() + "|" +
						Long.toString(serverInfo.getTime());
						
						LOGGER.debug(ToolBox.logInfo(CgatherTaskUtil.MODULE_NAME, "CgatherTaskTimer", 
								"sendDataToMQ", logContent));
					}
				} catch (Exception e) {
					LOGGER.error(ToolBox.logError(CgatherTaskUtil.MODULE_NAME,
							"CgatherTaskTimer","SendDataToMQ ERROR!"), e);
				}
			}
		};
	}

}
