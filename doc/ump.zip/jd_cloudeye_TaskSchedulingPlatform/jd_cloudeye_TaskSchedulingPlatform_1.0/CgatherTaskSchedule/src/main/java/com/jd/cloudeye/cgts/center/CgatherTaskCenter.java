package com.jd.cloudeye.cgts.center;

import java.util.Timer;

import com.jd.cloudeye.tsc.management.ToolBox;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.Source;

/**
 * 下发指标分析任务定时器
 * 
 * @date 2013-03-01
 * @author duliang
 */
public class CgatherTaskCenter implements Source {

	/**
	 * 启动下发时间：开机后的后两分钟的第30秒
	 * 定时器频率：30秒
	 * 下发时间：每分钟的第0秒和第30秒
	 */
	public void open() {
		cgatherTask();
	}
	
	
	public void cgatherTask(){
		 Timer cgatherTaskTimer = new Timer("CgatherTaskTimer");
		 cgatherTaskTimer.scheduleAtFixedRate(new CgatherTaskTimer(),
					ToolBox.getNextMinuteForInitial(2,30),
					CgatherTaskUtil.TASK_TIMER_PERIOD);
	}
	
	public void close() {}

	public void connect(Sink arg0) {}

	public boolean isBlocking() {
		return false;
	}

}
