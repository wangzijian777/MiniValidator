package com.jd.cloudeye.cgts.center;

import java.util.ArrayList;
import java.util.List;

import com.jd.cloudeye.tsc.management.AppPropertiesManager;

/**
 * 指标分析常量
 * 
 * @author duliang
 * @date 2013-08-20
 */
public class CgatherTaskUtil {
	
	/**
	 * 硬件服务器指标采集的任务参数
	 */
	public static List<ServerInfo> CACHE_CGATHER_TASK_LIST = new ArrayList<ServerInfo>();
	

	/**
     * 模块名
     */
    public static final String MODULE_NAME = "CgatherTaskSchedule";
    
    
    /**
     * 采集下发频率
     */
    public static long TASK_TIMER_PERIOD = Long.parseLong(AppPropertiesManager.getProperty("CgatherTask_Task_TimePeriod"));

   
    /**
     * 线程个数
     */
    public static int TASK_THREAD_COUNT = Integer.parseInt(AppPropertiesManager.getProperty("CgatherTask_Task_ThreadCount"));
	
    /**
     * 队列名称
     */
    public static String TASK_QUEUE_NAME = AppPropertiesManager.getProperty("CgatherTask_Task_QueueName");
    
    
    /**
     * 登录用户名
     */
    public static String COMMUNITY = AppPropertiesManager.getProperty("CgatherTask_Task_community");
    
    /**
     * 发送标识
     */
    public static String SEND_FLAG = AppPropertiesManager.getProperty("CgatherTask_Task_sendFlag");
    
    
    /**
     * 操作系统位数
     */
    public static int SERVER_MEDIAN = Integer.parseInt(AppPropertiesManager.getProperty("CgatherTask_Task_server_median"));
    
    /**
     * 操作系统类型
     */
    public static String SYSTEM_FLAG = AppPropertiesManager.getProperty("CgatherTask_Task_system_flag");
    
    /**
     * 获取配置文件中其他采集服务器的IP
     */
    public static String OTHER_IP_LINUX = AppPropertiesManager.getProperty("CgatherTask_Task_OtherIp_linux");
    public static String OTHER_IP_WINDOWS = AppPropertiesManager.getProperty("CgatherTask_Task_OtherIp_windows");
    
}
