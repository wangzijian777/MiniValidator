package com.jd.cloudeye.cgts.db;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jd.cloudeye.cgts.center.CgatherTaskUtil;
import com.jd.cloudeye.cgts.center.ServerInfo;
import com.jd.cloudeye.tsc.management.DBManager;
import com.jd.cloudeye.tsc.management.ToolBox;

/**
 * 缓存cgather需要采集数据的IP地址等
 * 
 * @author duliang
 * @date 2013-08-20
 */
public class CacheCgatherTaskDB {
    private final static Logger LOGGER = LoggerFactory.getLogger(CacheCgatherTaskDB.class);
    private JdbcTemplate jdbcTemplate;
    
    /**
     * 数据库注册连接
     */
    public CacheCgatherTaskDB() {
    	this.jdbcTemplate = new DBManager().getJdbcTemplate();
    }
    
    
    /**
     * 缓存指标分析任务的信息
     * 格式：List<ServerInfo>
     */
    public void loadCache(){
    	try{
    		List<ServerInfo> serverInfoList = new ArrayList<ServerInfo>();
    		
    		List<String> ipList = getIpListFromDB();
    		List<String> indexsList = getindexsListFromDB();
    		
    		if(indexsList.size()>0){
    			for (String ip : ipList) {
    				ServerInfo serverInfo = new ServerInfo();
    				serverInfo.setIp(ip);
    				serverInfo.setIndexs(indexsList);
    				serverInfo.setSendFlag(CgatherTaskUtil.SEND_FLAG);
    				serverInfo.setServerMedian(CgatherTaskUtil.SERVER_MEDIAN);
    				serverInfo.setSystemFlag(CgatherTaskUtil.SYSTEM_FLAG);
    				serverInfo.setCommunity(CgatherTaskUtil.COMMUNITY);
    				serverInfoList.add(serverInfo);
    			}
    			
    			//获取配置的linux服务器的IP，并拼装任务
        		String otherIPLinux = CgatherTaskUtil.OTHER_IP_LINUX;
        		if(otherIPLinux!=null && !"".equals(otherIPLinux)){
        			String[] ips = otherIPLinux.split(",");
        			LOGGER.info(ToolBox.logInfo(CgatherTaskUtil.MODULE_NAME, "CacheCgatherTaskDB", 
            				"loadCache", "otherIPLinux Count:" + ips.length));
        			for (String ip : ips) {
        				if(ip!=null && !"".equals(ip)){
        					ServerInfo serverInfo = new ServerInfo();
            				serverInfo.setIp(ip);
            				serverInfo.setIndexs(indexsList);
            				serverInfo.setSendFlag("LOG");
            				serverInfo.setServerMedian(CgatherTaskUtil.SERVER_MEDIAN);
            				serverInfo.setSystemFlag("linux");
            				serverInfo.setCommunity(CgatherTaskUtil.COMMUNITY);
            				serverInfoList.add(serverInfo);
        				}
        			}
        		}
        		
        		//获取配置的windows服务器的IP，并拼装任务
        		String otherIPWindows = CgatherTaskUtil.OTHER_IP_WINDOWS;
        		if(otherIPWindows!=null && !"".equals(otherIPWindows)){
        			String[] ips = otherIPWindows.split(",");
        			LOGGER.info(ToolBox.logInfo(CgatherTaskUtil.MODULE_NAME, "CacheCgatherTaskDB", 
            				"loadCache", "otherIPWindows Count:" + ips.length));
        			for (String ip : ips) {
        				if(ip!=null && !"".equals(ip)){
        					ServerInfo serverInfo = new ServerInfo();
            				serverInfo.setIp(ip);
            				serverInfo.setIndexs(indexsList);
            				serverInfo.setSendFlag("LOG");
            				serverInfo.setServerMedian(CgatherTaskUtil.SERVER_MEDIAN);
            				serverInfo.setSystemFlag("windows");
            				serverInfo.setCommunity(CgatherTaskUtil.COMMUNITY);
            				serverInfoList.add(serverInfo);
        				}
        			}
        		}
    			
    		}
			
    		
			
			//同步更新缓存
			synchronized (CgatherTaskUtil.CACHE_CGATHER_TASK_LIST) {
				if(CgatherTaskUtil.CACHE_CGATHER_TASK_LIST.size()>0){
					CgatherTaskUtil.CACHE_CGATHER_TASK_LIST.clear();
				}
				if(serverInfoList.size()>0){
					CgatherTaskUtil.CACHE_CGATHER_TASK_LIST.addAll(serverInfoList);
				}
			}
    		
			//打印日志
    		String logContent = "Cache Cgather Task ServerInfo |" + ToolBox.getNowTime() + " | size: " + CgatherTaskUtil.CACHE_CGATHER_TASK_LIST.size() + "";
    		LOGGER.info(ToolBox.logInfo(CgatherTaskUtil.MODULE_NAME, "CacheCgatherTaskDB", 
    				"loadCache", logContent));
    		
    	}catch(Exception e){
    		String logContent = "Catch Cgather Task ServerInfo ERROR!";
    		LOGGER.error(ToolBox.logError(CgatherTaskUtil.MODULE_NAME, "CacheCgatherTaskDB", logContent),e);
    	}
    }
    
    
    /**
     * 查询EC2的IP信息(jce_service_instance表)
     * 格式：List<String>
     */
    public List<String> getIpListFromDB() {
    	
    	List<String> ipList =  new ArrayList<String>();
    	
    	String sql = " select distinct jce_instance_key from jce_service_instance where jce_service_code = ? and is_valid =1 ";
    	
		Object[] paramsForSelect = new Object[] { "EC2" };
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
		
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
				String ip = ((String) row.get("jce_instance_key")).trim();
				if(ip!=null && !"".equals(ip)){
					ipList.add(ip);
				}
		    }
		}
		return ipList;
    }
    
    
    /**
     * 查询EC2主机采集指标表(jce_machine_basedata_config)
     * 格式：List<String>
     */
    public List<String> getindexsListFromDB() {
    	
    	List<String> indexsList =  new ArrayList<String>();
    	String sql = " select distinct mbc_index from jce_machine_basedata_config where mbc_status=1 ";
		
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql);
		
		if (tpRows.size() > 0) {
			for (Map<String, Object> row : tpRows) {
				String index = ((String) row.get("mbc_index")).trim();
				if(index!=null && !"".equals(index)){
					indexsList.add(index);
				}
		    }
		}
		return indexsList;
    }
    
}
