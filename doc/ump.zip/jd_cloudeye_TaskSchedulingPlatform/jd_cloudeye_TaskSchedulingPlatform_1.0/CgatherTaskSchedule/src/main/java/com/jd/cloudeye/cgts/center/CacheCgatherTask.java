package com.jd.cloudeye.cgts.center;

import com.jd.cloudeye.cgts.db.CacheCgatherTaskDB;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.source.TimerSource;

/**
 * 定时缓存cgather需要采集数据的IP地址等
 * 频率：10分钟
 * 执行时间：启动后一分钟
 * 
 * @author duliang
 * @date 2013-08-20
 */
public class CacheCgatherTask extends TimerSource {

	protected void doTimerTask(Sink sink) {
		new CacheCgatherTaskDB().loadCache();
	}

}
