package com.jd.cloudeye.cgts.center;


import java.io.Serializable;
import java.util.List;
/**
 * 
 * @title 硬件服务器指标采集的任务参数
 * @author cdwenxing
 * @date 2013-8-20
 */
public class ServerInfo implements Serializable{
   
    private static final long serialVersionUID = 1L;
    /**
     * 服务器IP
     */
    private String ip;
    /**
     * 任务时间
     */
    private long time;
    /**
     * 系统类型
     * windows,linux
     */
    private String systemFlag;
    /**
     * 系统位数：32位，64位
     * 32
     * 64
     */
    private int serverMedian;
    /**
     * 指标
     */
    private List<String> indexs;
    /**
     * 发送标识 
     * LOG
     * DRC
     */
    private String sendFlag;
    /**
     * 用户名
     * 360buy
     */
    private String community;
	
    
    public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public String getSystemFlag() {
		return systemFlag;
	}
	public void setSystemFlag(String systemFlag) {
		this.systemFlag = systemFlag;
	}
	public int getServerMedian() {
		return serverMedian;
	}
	public void setServerMedian(int serverMedian) {
		this.serverMedian = serverMedian;
	}
	public List<String> getIndexs() {
		return indexs;
	}
	public void setIndexs(List<String> indexs) {
		this.indexs = indexs;
	}
	public String getSendFlag() {
		return sendFlag;
	}
	public void setSendFlag(String sendFlag) {
		this.sendFlag = sendFlag;
	}
	public String getCommunity() {
		return community;
	}
	public void setCommunity(String community) {
		this.community = community;
	}
    
}
