package com.jd.cloudeye.maas.center;

import com.jd.cloudeye.maas.db.CacheMetricsAlarmAnalysisDB;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.source.TimerSource;

/**
 * 定时缓存指标报警分析的数据
 * 频率：10分钟
 * 启动时间：开机启动
 * 
 * @author duliang
 * @date 2013-03-01
 */
public class CacheMetricsAlarmAnalysis extends TimerSource {

	protected void doTimerTask(Sink sink) {
		new CacheMetricsAlarmAnalysisDB().loadCache();
	}

}
