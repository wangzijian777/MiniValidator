package com.jd.cloudeye.maas.center;

import java.util.Timer;

import com.jd.cloudeye.tsc.management.ToolBox;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.Source;

/**
 * 下发指标报警分析任务定时器
 * 
 * @date 2013-03-02
 * @author duliang
 */
public class MetricsAlarmAnalysisCenter implements Source {

	/**
	 * 启动下发时间：开机后按照时间频率的下一个整点发送的第50秒
	 * 定时器频率：1,5,10,15,30,60分钟
	 * 下发时间：1,5,10,15,30,60分钟的第50秒
	 */
	public void open() {

		// 启动N个不同时间频率任务的定时器
		for (int i = 0; i < MetricsAlarmAnalysisUtil.TASK_TIMER_PERIOD.length; i++) {
			String tp = MetricsAlarmAnalysisUtil.TASK_TIMER_PERIOD[i];
			
		    Timer metricsAlarmAnalysisTimer = new Timer("MetricsAlarmAnalysisTimer" + tp);
		    long timePeriod = 60000L * Long.parseLong(tp);
		    metricsAlarmAnalysisTimer.scheduleAtFixedRate(
		    		new MetricsAlarmAnalysisTimer(tp), 
		    		ToolBox.getTimePointForMultipleMinute(Integer.parseInt(tp),MetricsAlarmAnalysisUtil.TASK_DELAY_TIME),
		    		timePeriod);
		}
	}
	
	public void close() {}

	public void connect(Sink arg0) {}

	public boolean isBlocking() {
		return false;
	}

}
