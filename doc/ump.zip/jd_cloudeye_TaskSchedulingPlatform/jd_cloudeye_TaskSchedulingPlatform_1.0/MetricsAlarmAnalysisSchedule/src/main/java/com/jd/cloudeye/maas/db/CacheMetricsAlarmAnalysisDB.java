package com.jd.cloudeye.maas.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jd.cloudeye.maas.center.MetricsAlarmAnalysisInfo;
import com.jd.cloudeye.maas.center.MetricsAlarmAnalysisUtil;
import com.jd.cloudeye.tsc.management.DBManager;
import com.jd.cloudeye.tsc.management.ToolBox;

/**
 * 缓存指标报警分析的信息
 * 
 * @author duliang
 * @date 2013-03-01
 */
public class CacheMetricsAlarmAnalysisDB {
    private final static Logger LOGGER = LoggerFactory.getLogger(CacheMetricsAlarmAnalysisDB.class);
    private JdbcTemplate jdbcTemplate;
    
    /**
     * 数据库注册连接
     */
    public CacheMetricsAlarmAnalysisDB() {
    	this.jdbcTemplate = new DBManager().getJdbcTemplate();
    }
    
    
    /**
     * 缓存指标报警任务的信息
     * 格式：MAP(1,List<MetricsAlarmAnalysisInfo>)
     */
    public void loadCache(){
    	try{
    		HashMap<String,List<MetricsAlarmAnalysisInfo>> alarmRuleMap = new HashMap<String,List<MetricsAlarmAnalysisInfo>>();
    		
    		HashMap<Long, HashMap<Long,String>> alarmRuleDetailMap = getAlarmRuleDetailFromDB();
    		
    		String sql = " select ar.id,ar.jce_usin_id,ar.jce_metrics_id,ar.jce_continual_occurs,ar.jce_period,ar.jce_statics,ar.jce_computors ,ar.jce_threshold,ar.jce_alarm_level, " +
			" si.jce_boss_user_id, si.jce_service_code, si.jce_instance_key  " +
			" from jce_alarm_rule as ar,jce_service_instance as si " +
			" where ar.is_valid=? and si.id=ar.jce_usin_id ";
    		
			Object[] paramsForSelect = new Object[] { MetricsAlarmAnalysisUtil.VALID };
			List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
			
			if (tpRows.size() > 0) {
			    for (Map<String, Object> row : tpRows) {
			    	Long alarmRuleId = (Long) row.get("id");
			    	Long usiId = (Long) row.get("jce_usin_id");
			    	String userId = (String)row.get("jce_boss_user_id");
			    	String serviceCode = (String)row.get("jce_service_code");
			    	String instanceId = (String)row.get("jce_instance_key");
			    	String metricsCode = (String)row.get("jce_metrics_id");
			    	int continualOccurs = ((Integer)row.get("jce_continual_occurs")).intValue();
			    	int period = ((Integer)row.get("jce_period")).intValue();
			    	String statics = (String)row.get("jce_statics");
			    	int computors = ((Integer)row.get("jce_computors")).intValue();
			    	long threshold = ((Long)row.get("jce_threshold")).longValue();
			    	int alarmLevel = ((Integer)row.get("jce_alarm_level"))==null?0:((Integer)row.get("jce_alarm_level")).intValue();
			    	
			    	//组装数据
			    	MetricsAlarmAnalysisInfo metricsAlarmAnalysisInfo = new MetricsAlarmAnalysisInfo();
			    	metricsAlarmAnalysisInfo.setUsinId(usiId);
			    	metricsAlarmAnalysisInfo.setAlarmRuleId(alarmRuleId);
			    	metricsAlarmAnalysisInfo.setUserId(userId);
			    	metricsAlarmAnalysisInfo.setServiceCode(serviceCode);
			    	metricsAlarmAnalysisInfo.setInstanceId(instanceId);
			    	metricsAlarmAnalysisInfo.setMetricsCode(metricsCode);
			    	metricsAlarmAnalysisInfo.setContinualOccurs(continualOccurs);
			    	metricsAlarmAnalysisInfo.setPeriod(period);
			    	metricsAlarmAnalysisInfo.setStatics(statics);
			    	metricsAlarmAnalysisInfo.setComputors(computors);
			    	metricsAlarmAnalysisInfo.setThreshold(threshold);
			    	metricsAlarmAnalysisInfo.setAlarmLevel(alarmLevel);
			    	metricsAlarmAnalysisInfo.setAlarmRuleDetail(alarmRuleDetailMap.get(alarmRuleId));
			    	
			    	//按照时间粒度缓存
			    	if(alarmRuleMap.containsKey(Integer.toString(period))){
			    		alarmRuleMap.get(Integer.toString(period)).add(metricsAlarmAnalysisInfo);
			    	}else{
			    		List<MetricsAlarmAnalysisInfo> metricsAlarmAnalysisInfoList = new ArrayList<MetricsAlarmAnalysisInfo>();
			    		metricsAlarmAnalysisInfoList.add(metricsAlarmAnalysisInfo);
			    		alarmRuleMap.put(Integer.toString(period), metricsAlarmAnalysisInfoList);
			    	}
			    }
			}
		    		
			
			//同步更新缓存
			synchronized (MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP) {
				if(MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP.size()>0){
					MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP.clear();
				}
				if(alarmRuleMap.size()>0){
					for (Map.Entry<String,List<MetricsAlarmAnalysisInfo>> entry : alarmRuleMap.entrySet()) {
						MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP.put(entry.getKey(), entry.getValue());
					}
				}
			}
    		
			//打印日志
    		String logContent = "Cache MetricsAlarmAnalysis |" + ToolBox.getNowTime() + " | size: " + MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP.size() + "";
    		LOGGER.info(ToolBox.logInfo(MetricsAlarmAnalysisUtil.MODULE_NAME, "CacheMetricsAlarmAnalysisDB", 
    				"loadCache", logContent));
    		
    	}catch(Exception e){
    		String logContent = "Catch MetricsAlarmAnalysis ERROR!";
    		LOGGER.error(ToolBox.logError(MetricsAlarmAnalysisUtil.MODULE_NAME, "CacheMetricsAlarmAnalysisDB", logContent),e);
    	}
    }
    
    
    /**
     * 查询报警细则信息(jce_alarm_rule_detail表)
     * 格式：MAP(alarm_rule_id, HashMap<alarm_rule_detail_id,alarmDetailContent>)
     */
    public HashMap<Long, HashMap<Long,String>> getAlarmRuleDetailFromDB() {
    	
    	HashMap<Long, HashMap<Long,String>> alarmRuleDetailMap = new HashMap<Long, HashMap<Long,String>>();
    	String sql = " select id,jce_alarm_rule_id,jce_alarm_way,jce_address,jce_alarm_content,jce_interval_time " +
    			" from jce_alarm_rule_detail where is_valid=? ";
		
		Object[] paramsForSelect = new Object[] { MetricsAlarmAnalysisUtil.VALID };
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
		
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
		    	Long alarmRuleDetailId = (Long) row.get("id");
		    	Long alarmRuleId = (Long) row.get("jce_alarm_rule_id");
				
		    	//细则详细信息
		    	int alarmWay = ((Integer) row.get("jce_alarm_way")).intValue();
				String address = (String)row.get("jce_address");
				String alarmContent = (String)row.get("jce_alarm_content");
				int intervalTime = ((Integer) row.get("jce_interval_time")).intValue();
				
				String alarmDetailContent = Integer.toString(alarmWay) + MetricsAlarmAnalysisUtil.SPLIT_MARK +
										address + MetricsAlarmAnalysisUtil.SPLIT_MARK + 
										alarmContent + MetricsAlarmAnalysisUtil.SPLIT_MARK + 
										Integer.toString(intervalTime);
				
				if(alarmRuleDetailMap.containsKey(alarmRuleId)){
					alarmRuleDetailMap.get(alarmRuleId).put(alarmRuleDetailId, alarmDetailContent);
				}else{
					HashMap<Long,String> hm = new HashMap<Long,String>();
					hm.put(alarmRuleDetailId, alarmDetailContent);
					alarmRuleDetailMap.put(alarmRuleId, hm);
				}
		    }
		}
		return alarmRuleDetailMap;
    }
    
}
