package com.jd.cloudeye.maas.center;

import java.util.List;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.cloudeye.tsc.management.MQManager;
import com.jd.cloudeye.tsc.management.ThreadPoolManager;
import com.jd.cloudeye.tsc.management.ToolBox;
import com.jd.cloudeye.tsc.masterslave.SwitchMasterSlaveUtil;

/**
 * 发送指标分析数据 
 * 定时器频率：1,5,10,15,30,60分钟 
 * 下发时间：1,5,10,15,30,60分钟 的第50秒 
 * 数据格式：MetricsAlarmAnalysisInfo
 * 
 * @date 2013-03-02
 * @author duliang
 */
public class MetricsAlarmAnalysisTimer extends TimerTask {

	private final static Logger LOGGER = LoggerFactory.getLogger(MetricsAlarmAnalysisTimer.class);
	private ThreadPoolManager threadPoolManagerMAAT;
	private String timePeriod;

	public MetricsAlarmAnalysisTimer(String timePeriod) {
		this.timePeriod = timePeriod;
		this.threadPoolManagerMAAT = new ThreadPoolManager(MetricsAlarmAnalysisUtil.TASK_THREAD_COUNT);
	}

	@Override
	public void run() {

		// 首先获得分析任务的时间点(当前分钟的整点)
		long taskTime = ToolBox.getNextMinuteForInitial(0,0).getTime();
		
		try {
			if (SwitchMasterSlaveUtil.SEND_DATA_STATUS) {
				synchronized (MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP) {
					if (MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP.size() > 0) {
						if(MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP.containsKey(timePeriod)){
							List<MetricsAlarmAnalysisInfo> metricsAlarmAnalysisInfoList = MetricsAlarmAnalysisUtil.CACHE_METRICS_ALARM_ANALYSIS_MAP.get(timePeriod);
							for(MetricsAlarmAnalysisInfo metricsAlarmAnalysisInfo : metricsAlarmAnalysisInfoList){
								if (metricsAlarmAnalysisInfo != null) {
									if("JAE".equals(metricsAlarmAnalysisInfo.getServiceCode())){
										metricsAlarmAnalysisInfo.setTaskTime(taskTime - MetricsAlarmAnalysisUtil.JAE_ALARM_DELAY_TIME);
									}else{
										metricsAlarmAnalysisInfo.setTaskTime(taskTime);
									}
									threadPoolManagerMAAT.execute(sendDataToMQ(metricsAlarmAnalysisInfo));
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			SwitchMasterSlaveUtil.SCAN_DB_STATUS = false;
			LOGGER.error(ToolBox.logError(MetricsAlarmAnalysisUtil.MODULE_NAME,
					"MetricsAlarmAnalysisTimer", "Timer ERROR!"), e);
		}
	}

	
	/**
	 * 调用MQ接口发送数据
	 */
	private Runnable sendDataToMQ(final MetricsAlarmAnalysisInfo metricsAlarmAnalysisInfo) {
		return new Runnable() {public void run() {
			try {
				new MQManager().sendObjectToMQ(MetricsAlarmAnalysisUtil.TASK_QUEUE_NAME,metricsAlarmAnalysisInfo);
				
				//日志打印
				if(LOGGER.isDebugEnabled()){
					String logContent = Long.toString(metricsAlarmAnalysisInfo.getUsinId()) + "|" + 
					Long.toString(metricsAlarmAnalysisInfo.getAlarmRuleId()) + "|" + 
					metricsAlarmAnalysisInfo.getMetricsCode() + "|" + 
					Integer.toString(metricsAlarmAnalysisInfo.getContinualOccurs()) + "|" + 
					Integer.toString(metricsAlarmAnalysisInfo.getPeriod()) + "|" +
					metricsAlarmAnalysisInfo.getStatics() + "|" +
					Integer.toString(metricsAlarmAnalysisInfo.getComputors()) + "|" +
					Long.toString(metricsAlarmAnalysisInfo.getThreshold()) + "|" +
					Integer.toString(metricsAlarmAnalysisInfo.getAlarmLevel()) + "|" +
					Long.toString(metricsAlarmAnalysisInfo.getTaskTime());

					LOGGER.debug(ToolBox.logInfo(MetricsAlarmAnalysisUtil.MODULE_NAME, "MetricsAlarmAnalysisTimer", 
							"sendDataToMQ", logContent));
				}
				
			} catch (Exception e) {
				LOGGER.error(ToolBox.logError(MetricsAlarmAnalysisUtil.MODULE_NAME,
						"MetricsAlarmAnalysisTimer","SendDataToMQ ERROR!"), e);
			}
		}
	};
}

}
