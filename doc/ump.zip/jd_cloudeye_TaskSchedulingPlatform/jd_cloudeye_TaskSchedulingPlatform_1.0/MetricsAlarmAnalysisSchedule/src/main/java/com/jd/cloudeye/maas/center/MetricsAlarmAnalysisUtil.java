package com.jd.cloudeye.maas.center;

import java.util.HashMap;
import java.util.List;

import com.jd.cloudeye.tsc.management.AppPropertiesManager;

/**
 * 指标报警分析常量
 * 
 * @author duliang
 * @date 2013-03-02
 */
public class MetricsAlarmAnalysisUtil {
	
	/**
	 * 指标报警分析缓存
	 */
	public static HashMap<String,List<MetricsAlarmAnalysisInfo>> CACHE_METRICS_ALARM_ANALYSIS_MAP = new HashMap<String,List<MetricsAlarmAnalysisInfo>>();
	
	
	/**
	 * 数据有效与无效
	 */
	public static final int VALID = 1;
	public static final int INVALID = 0;
    
    /**
     * 模块名
     */
    public static final String MODULE_NAME = "MetricsAlarmAnalysisSchedule";
    
    /**
     * 为空默认值
     */
    public static final String KNULL = "KNULL";
    
    /**
     * 分隔符
     */
    public static final String SPLIT_MARK = "#JDCE#";
    
    /**
     * 指标分析频率
     */
    public static String[] TASK_TIMER_PERIOD = AppPropertiesManager.getProperty("MetricsAlarmAnalysis_Task_TimePeriod").split(",");

    /**
     * 任务延迟时间
     */
    public static int TASK_DELAY_TIME = Integer.parseInt(AppPropertiesManager.getProperty("MetricsAlarmAnalysis_Task_DelayTime"));
    
    /**
     * 线程个数
     */
    public static int TASK_THREAD_COUNT = Integer.parseInt(AppPropertiesManager.getProperty("MetricsAlarmAnalysis_Task_ThreadCount"));
	
    /**
     * 队列名称
     */
    public static String TASK_QUEUE_NAME = AppPropertiesManager.getProperty("MetricsAlarmAnalysis_Task_QueueName");
    
    /**
     * JAE报警延迟时间值
     */
    public static long JAE_ALARM_DELAY_TIME = 120000L;
    
}
