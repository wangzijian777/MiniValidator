package com.jd.ump.bmp.common.alarm;

import java.math.BigDecimal;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.bmp.common.RuleVO;

@Component
public class AlarmRuleContext 
{	
	@Resource(name="filedValueFetch")
	private AlarmCompareValueFetch filedValueFetch;
	
	@Resource(name="fixedValueFetch")
	private AlarmCompareValueFetch fixedValueFetch;
	
	@Resource(name="ringCompareValueFetch")
	private AlarmCompareValueFetch ringCompareValueFetch;
	
	@Resource(name="sameTermValueFetch")
	private AlarmCompareValueFetch sameTermValueFetch;
	
	@Resource(name="expressionValueFetch")
	private AlarmCompareValueFetch expressionValueFetch;
	
	@Resource(name="amplificationValueFetch")
	private AlarmCompareValueFetch amplificationValueFetch;
	
	public BigDecimal fetchBusinessValue(RuleVO ruleVO,Map<String,String> currentDataMap)
	{
		if(ruleVO.getCompareValueType() == CommonConstants.FACILITY_VALUE_AMPLIFICATION_TYPE)
		{
			return amplificationValueFetch.fetchValue(currentDataMap, ruleVO.getCompareValue());
		}
		if(ruleVO.getCompareValueType() == CommonConstants.FACILITY_VALUE_SAMETERMCOMPARE_AMPLIFICATION_TYPE)
		{
			return amplificationValueFetch.fetchValue(currentDataMap, ruleVO.getCompareValue(),ruleVO.getSameTermAmplifyDataWay());
		}
		else if(ruleVO.getCompareValueType() == CommonConstants.FACILITY_REFERENCE_VALUE_FIELD_TYPE)
		{
			return filedValueFetch.fetchValue(currentDataMap, ruleVO.getCompareValue());
		}
		else if(ruleVO.getCompareValueType() == CommonConstants.FACILITY_REFERENCE_VALUE_EXPRESSION_TYPE)
		{
			return expressionValueFetch.fetchValue(currentDataMap, ruleVO.getCompareValue());
		}
		return null;
	}
	
	public BigDecimal fetchReferenceValue(RuleVO ruleVO,Map<String,String> currentDataMap)
	{
		if(ruleVO.getThresholdValueType() == CommonConstants.REFERENCE_VALUE_FIXED_TYPE)
		{
			return fixedValueFetch.fetchValue(currentDataMap, ruleVO.getThresholdValue());
		}
		else if(ruleVO.getThresholdValueType() == CommonConstants.FACILITY_REFERENCE_VALUE_FIELD_TYPE)
		{
			return filedValueFetch.fetchValue(currentDataMap, ruleVO.getThresholdValue());
		}
		else if(ruleVO.getThresholdValueType() == CommonConstants.FACILITY_REFERENCE_VALUE_EXPRESSION_TYPE)
		{
			return expressionValueFetch.fetchValue(currentDataMap, ruleVO.getThresholdValue());
		}
		else if(ruleVO.getThresholdValueType() == CommonConstants.REFERENCE_VALUE_RINGCOMPARE_TYPE)
		{
			return ringCompareValueFetch.fetchValue(currentDataMap,ruleVO.getThresholdValue(),
					ruleVO.getLrrCompareThresholdValueType());
		}
		else if(ruleVO.getThresholdValueType() == CommonConstants.REFERENCE_VALUE_SAMETERMCOMPARE)
		{
			return sameTermValueFetch.fetchValue(currentDataMap, ruleVO.getThresholdValue(),ruleVO.getSameTermType(),ruleVO.getSameTermFetchDataWay());
		}
		return null;
	}
}
