package com.jd.ump.bmp.common.alarm;

import groovy.lang.GroovyShell;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.bmp.common.cache.SetCache;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class ExpressionValueFetch implements AlarmCompareValueFetch
{
	private final static Logger LOGGER = LoggerFactory.getLogger(ExpressionValueFetch.class);
	
	@Resource(name = "setCache")
    private SetCache setCache;
	
	@Override
	public BigDecimal fetchValue(Map<String, String> map, String value,Integer ... param) 
	{
		String bKey = map.get(CommonConstants.BKEY);
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.AlarmRuleExpressionValueFetch.processorMessage", false, true);
			GroovyShell shell = new GroovyShell();
			List<String> fieldList = setCache.getFacFieldCache(bKey);
			if(fieldList != null && fieldList.size() > 0)
			{
				for(int i=0;i<fieldList.size();i++)
				{
					String fieldName = fieldList.get(i);
					int num = value.indexOf(fieldName);
					if(num < 0)
						continue;
					shell.setVariable(fieldList.get(i), new BigDecimal(map.get(fieldName)));
				}
				Object calResult = shell.evaluate(value);
				return new BigDecimal(calResult.toString());
			}
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[ExpressionValueFetch]method[fetchValue]key["+bKey+"]expression parse error!",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
	
}
