package com.jd.ump.bmp.common;

public class UmpKeyConfigVO 
{
	/**
	 * ump_key表id
	 */
	private int id;
	/**
	 * 监控点key
	 */
	private String key;
	/**
	 * 应用id
	 */
	private long applicationId;
	/**
	 * 报警方式
	 */
	private String alarmWay;
	/**
	 * 描述
	 */
	private String remak;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}
	public String getAlarmWay() {
		return alarmWay;
	}
	public void setAlarmWay(String alarmWay) {
		this.alarmWay = alarmWay;
	}
	public String getRemak() {
		return remak;
	}
	public void setRemak(String remak) {
		this.remak = remak;
	}
}
