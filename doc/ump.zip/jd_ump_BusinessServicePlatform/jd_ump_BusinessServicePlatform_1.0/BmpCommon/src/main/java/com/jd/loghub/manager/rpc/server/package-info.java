@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.rpc.manager.loghub.jd.com/")
package com.jd.loghub.manager.rpc.server;
