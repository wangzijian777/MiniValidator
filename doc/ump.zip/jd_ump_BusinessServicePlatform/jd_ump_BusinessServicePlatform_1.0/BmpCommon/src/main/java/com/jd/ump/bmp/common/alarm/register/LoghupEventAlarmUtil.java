package com.jd.ump.bmp.common.alarm.register;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.loghub.manager.rpc.server.AlarmServer;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

public class LoghupEventAlarmUtil 
{
	private final static Logger LOGGER = LoggerFactory.getLogger(LoghupEventAlarmUtil.class);
	private static ThreadPoolExecutor executor = new ThreadPoolExecutor(50, 50, 5, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
	private static final String ALARM_ID = "alarmId";
	private static final String ALARM_TIME = "alarmTime";
	private static final String ALARM_TIMES = "times";
	public static void loghupSendAlarmer(final String key,final String date,final String value)
	{
		executor.execute(new Runnable(){
			@Override
			public void run() 
			{
				CallerInfo callerInfo = null;
				try
				{
					callerInfo = Profiler.registerInfo("ump.bmp.BusinessDataHandle.loghupSendAlarmer", false, true);
					LOGGER.debug("class[LoghupEventAlarmUtil]key["+key+"] read url is method is[]");

					String alarmJsonStr = "{'"+ALARM_ID+"':'"+key+"','"+ALARM_TIME+"':'"+date+"','"+ALARM_TIMES+"':'"+value+"'}";
					AlarmServer alarmServer = LoghupAlarmSoapObject.getInstance();
					alarmServer.notifyAlarm(alarmJsonStr);
				}
				catch(Exception e)
				{
					Profiler.functionError(callerInfo);
					LOGGER.error("class[LoghupEventAlarmUtil]key["+key+"]invoke alarm interface error!",e);
				}
				finally
				{
					Profiler.registerInfoEnd(callerInfo);
				}
			}
			
		});
	}
}
