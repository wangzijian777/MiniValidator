package com.jd.ump.bmp.common.alarm;

import java.math.BigDecimal;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class FixedValueFetch implements AlarmCompareValueFetch
{
	private final static Logger LOGGER = LoggerFactory.getLogger(FixedValueFetch.class);
	
	@Override
	public BigDecimal fetchValue(Map<String, String> map, String value,Integer ... param)
	{
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.AlarmRuleFixedValueFetch.fetchValue", false, true);
			return new BigDecimal(value);
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[FixedValueFetch]method[fetchValue]key["+map.get(CommonConstants.BKEY)+"]parse fixed value error!",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}

}
