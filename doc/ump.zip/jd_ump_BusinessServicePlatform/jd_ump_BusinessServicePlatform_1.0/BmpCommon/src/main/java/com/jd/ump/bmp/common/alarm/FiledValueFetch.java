package com.jd.ump.bmp.common.alarm;

import java.math.BigDecimal;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class FiledValueFetch implements AlarmCompareValueFetch
{
	private final static Logger LOGGER = LoggerFactory.getLogger(FiledValueFetch.class);
	
	@Override
	public BigDecimal fetchValue(Map<String, String> map, String value,Integer ... param) 
	{
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.AlarmRuleFiledValueFetch.fetchValue", false, true);
			String fieldValue = map.get(value);
			return new BigDecimal(fieldValue);
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[FiledValueFetch]method[fetchValue]key["+map.get(CommonConstants.BKEY)+"]fetch field value error!",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
	
}
