package com.jd.ump.bmp.common;

public class MessagePackage 
{
	public static final String  MP_AMPLIFICATION = "环比增幅";	
	public static final String  MP_FIELD = "字段";
	public static final String  MP_EXPRESSION = "表达式 ";
	public static final String  MP_SAMETERMCOMPARE_AMPLIFICATION = "同比增幅";
	public static final String  MP_FIXED = "固定值";
	public static final String  MP_RINGCOMPARE = "环比";
	public static final String  MP_SAMETERMCOMPARE = "同比";
	public static final String  MP_DAY = "天";
	public static final String  MP_WEEK = "周";
	public static final String  MP_BLANK = "";
	
	private static MessagePackage messagePackage = new MessagePackage();;
	
	private MessagePackage()
	{
		
	}
	
	public static MessagePackage getInstance()
	{
		return messagePackage;
	}
	
	public String fetchCompareValueTypeDesc(int compareValueType)
	{
		if(compareValueType == CommonConstants.FACILITY_VALUE_AMPLIFICATION_TYPE)
		{
			return MP_AMPLIFICATION; 
		}
		else if(compareValueType == CommonConstants.FACILITY_REFERENCE_VALUE_FIELD_TYPE)
		{
			return MP_FIELD;
		}
		else if(compareValueType == CommonConstants.FACILITY_REFERENCE_VALUE_EXPRESSION_TYPE)
		{
			return MP_EXPRESSION; 
		}
		else if(compareValueType == CommonConstants.FACILITY_VALUE_SAMETERMCOMPARE_AMPLIFICATION_TYPE)
		{
			return MP_SAMETERMCOMPARE_AMPLIFICATION; 
		}
		else
		{
			return MP_BLANK;
		}
	}
	
	public  String fetchThresholdValueTypeDesc(int thresholdValueType)
	{
		if(thresholdValueType == CommonConstants.REFERENCE_VALUE_FIXED_TYPE)
		{
			return MP_FIXED; 
		}
		else if(thresholdValueType == CommonConstants.FACILITY_REFERENCE_VALUE_FIELD_TYPE)
		{
			return MP_FIELD;
		}
		else if(thresholdValueType == CommonConstants.FACILITY_REFERENCE_VALUE_EXPRESSION_TYPE)
		{
			return MP_EXPRESSION; 
		}
		else if(thresholdValueType == CommonConstants.REFERENCE_VALUE_RINGCOMPARE_TYPE)
		{
			return MP_RINGCOMPARE; 
		}
		else if(thresholdValueType == CommonConstants.REFERENCE_VALUE_SAMETERMCOMPARE)
		{
			return MP_SAMETERMCOMPARE; 
		}
		else
		{
			return MP_BLANK;
		}
	}
	
	public  String fetchThreldValueDataTypeDesc(int threldValueDataType)
	{
		if(threldValueDataType == CommonConstants.SAMETERMCOMPARE_TYPE_DAY)
		{
			return MP_DAY; 
		}
		else if(threldValueDataType == CommonConstants.SAMETERMCOMPARE_TYPE_WEEK)
		{
			return MP_WEEK;
		}
		else
		{
			return MP_BLANK;
		}
	}
	
}
