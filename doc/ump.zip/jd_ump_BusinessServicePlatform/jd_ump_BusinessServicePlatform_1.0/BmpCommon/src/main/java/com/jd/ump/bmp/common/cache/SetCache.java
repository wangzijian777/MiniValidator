package com.jd.ump.bmp.common.cache;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.BaseConfigVO;
import com.jd.ump.bmp.common.BusinessFieldVO;
import com.jd.ump.bmp.common.RuleVO;

@Component
public class SetCache {
	
    @Resource(name = "loadData")
    private LoadData loadData;
    
    private final static Logger LOGGER = LoggerFactory.getLogger(SetCache.class);
    
	private final ConcurrentHashMap<String,BaseConfigVO> baseConfigMaps = new ConcurrentHashMap<String,BaseConfigVO>();
	private final ConcurrentHashMap<String,BusinessFieldVO> facFieldMaps = new ConcurrentHashMap<String,BusinessFieldVO>();
	private final ConcurrentHashMap<String,List<RuleVO>> ruleMaps = new ConcurrentHashMap<String,List<RuleVO>>();
	private final ConcurrentHashMap<String,List<String>> fieldMaps = new ConcurrentHashMap<String,List<String>>();
	
	public BaseConfigVO baseConfigCache(String businessKey)
	{
		BaseConfigVO cacheVO = baseConfigMaps.get(businessKey);
		if(cacheVO == null)
		{
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[test message][baseConfigCache]start search key["+businessKey+"]base data;");
			BaseConfigVO loadVO = loadData.loadBaseConfig(businessKey);
			if(loadVO == null)
				return null;
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[test message][baseConfigCache]end search key["+businessKey+"]base data");
			baseConfigMaps.put(businessKey, loadVO);
			return loadVO;
		}
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("[test message][baseConfigCache]fetch key["+businessKey+"] base config from cache!");
		return cacheVO;
	}
	
	public BusinessFieldVO facFieldCache(String businessKey)
	{
		BusinessFieldVO cacheVO = facFieldMaps.get(businessKey);
		if(cacheVO == null)
		{
			BusinessFieldVO loadVO = loadData.loadFacField(businessKey);
			if(loadVO == null)
				return null;
			facFieldMaps.put(businessKey, loadVO);
			return loadVO;
		}
		return cacheVO;
	}
	
	public List<RuleVO> getAWRuleCache(String businessKey,int sign)
	{
//		String warnAlarmKey = (sign == CommonConstants.WARN_SIGN?CommonConstants.WARN_SIGN_STR:CommonConstants.ALARM_SIGN_STR);
		List<RuleVO> ruleCache = ruleMaps.get(businessKey);
		if(ruleCache == null)
		{
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[test message][getAWRuleCache]start search key["+businessKey+"]alarm rule;");
			List<RuleVO> loadList = loadData.loadRuleObject(businessKey,sign);
			if (loadList == null)
				return null;
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[test message][getAWRuleCache]end search key["+businessKey+"]alarm rule;rule size is["+loadList.size()+"]");
			ruleMaps.put(businessKey,loadList);
			return loadList;
		}
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("[test message][getAWRuleCache]fetch key["+businessKey+"] alarm rule from cache!");
		return ruleCache;
	}
	
	public List<String> getFacFieldCache(String businessKey)
	{
		List<String> fieldCache = fieldMaps.get(businessKey);
		if(fieldCache == null)
		{
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[test message][getFacFieldCache]start search key["+businessKey+"]facility field;");
			List<String> loadList = loadData.loadField(businessKey);
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[test message][getFacFieldCache]end search key["+businessKey+"]facility field,field size is["+loadList.size()+"]");
			fieldMaps.put(businessKey, loadList);
			return loadList;
		}
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("[test message][getFacFieldCache]fetch key["+businessKey+"]field from cache!");
		return fieldCache;
	}
	
	public void clearCache()
	{
		if(baseConfigMaps != null && !baseConfigMaps.isEmpty())
			baseConfigMaps.clear();
		
		if(facFieldMaps != null && !facFieldMaps.isEmpty())
			facFieldMaps.clear();
		
		if(fieldMaps != null && !fieldMaps.isEmpty())
			fieldMaps.clear();
	}
	
	public void clearAlarmRuleCache() {
		if(ruleMaps != null && !ruleMaps.isEmpty())
			ruleMaps.clear();
	}
}
