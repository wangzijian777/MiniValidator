package com.jd.ump.bmp.common;

import java.util.Date;
import java.util.Map;

public class BaseConfigVO
{
	public final static Map<String,String> map = ValueObjectUtility.dataColumnMaping(new String[][]{
		{"id","id"},
		{"businessKey","bus_key"},
		{"businessDataCollectWay","bus_datacollect_way"},
		{"businessActiveUrl","bus_active_url"},
		{"businessActiveUrlType","bus_active_url_type"},
		{"businessActiveRate","bus_active_rate"},
		{"businessActiveHour","bus_active_hour"},
		{"businessActiveMin","bus_active_min"},
		{"businessActiveExttime","bus_active_exttime"},
		{"businessActiveMethodName","bus_active_metodnm"},
		{"businessAlarmAnlyway","bus_alm_anlyway"},
		{"businessAlarmAnalysisRate","bus_alm_anlyrate"},
		{"businessLogAnalysisWay","bus_log_anlyway"},
		{"businessLogSumRate","bus_log_sumrate"},
		{"businessAlarmAnalysisLogMergeWay","bus_almanlylog_mgway"},	
		{"appid","bus_appid"},
		{"departId","bus_deptid"},
		{"status","bus_status"},
		{"createby","bus_created_by"},
		{"createDate","bus_dt_created"},
		{"autoRegisterCd","auto_register_cd"},
		{"updateby","bus_updated_by"},
		{"updateDate","bus_dt_updated"},
//		这两个字段目前数据库还没有 @date：2013/1/8
//		{"autoRegisterFlag",""},
//		{"businessActiveSec",""},
	});
	
	private int id;
	private String businessKey;
	/**
	 * 数据采集方式
	 */
	private int businessDataCollectWay;
	/**
	 * 主动访问的url
	 */
	private String businessActiveUrl;
	/**
	 * 主动访问的URL类型
	 */
	private int businessActiveUrlType;
	/**
	 * 主动访问频率
	 */
	private int businessActiveRate;
	/**
	 * 主动访问频率的小时数
	 */
	private int businessActiveHour;
	/**
	 * 主动访问频率的分钟数
	 */
	private int businessActiveMin;
	/**
	 * 主动访问频率的秒数
	 */
	private int businessActiveSec;
	/**
	 * 主动访问的超时时间
	 */
	private int businessActiveExttime;
	/**
	 * 主动访问的方法名称
	 */
	private String businessActiveMethodName;
	/**
	 * 报警预警分析方式
	 */
	private int businessAlarmAnlyway;
	/**
	 * 报警预警分析频率
	 */
	private int businessAlarmAnalysisRate;
	/**
	 * 日志数据的解析方式
	 */
	private int businessLogAnalysisWay;
	/**
	 * 累加频率
	 */
	private int businessLogSumRate = 1;
	/**
	 * 报警预警解析时数据合并方式
	 */
	private int businessAlarmAnalysisLogMergeWay;
	/**
	 * 是否自动注册的key，0-不是，1-loghupalert
	 */
	private int autoRegisterFlag;
	/*
	 * 应用id
	 */
	private int appid;
	/*
	 * 部门代码
	 */
	private int departId;
	/*
	 * 状态（启用中或禁用中）
	 */
	private Integer status;
	/**
	 * 创建人
	 */
	private String createby;
	
	/**
	 * 创建日期
	 */
	private Date createDate;
	/**
	 * 标识统一日志项目的key
	 */
	private int autoRegisterCd;
	
	/**
	 * 更新人
	 */
	private String updateby;
	
	/**
	 * 更新日期
	 */
	private String updateDate;
	
	public int getId() {
		return id;
	}	
	public void setId(int id) {
		this.id = id;
	}
	public String getBusinessKey() {
		return businessKey;
	}
	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}
	public int getBusinessDataCollectWay() {
		return businessDataCollectWay;
	}
	public void setBusinessDataCollectWay(int businessDataCollectWay) {
		this.businessDataCollectWay = businessDataCollectWay;
	}
	public String getBusinessActiveUrl() {
		return businessActiveUrl;
	}
	public void setBusinessActiveUrl(String businessActiveUrl) {
		this.businessActiveUrl = businessActiveUrl;
	}
	public int getBusinessActiveUrlType() {
		return businessActiveUrlType;
	}
	public void setBusinessActiveUrlType(int businessActiveUrlType) {
		this.businessActiveUrlType = businessActiveUrlType;
	}
	public int getBusinessActiveRate() {
		return businessActiveRate;
	}
	public void setBusinessActiveRate(int businessActiveRate) {
		this.businessActiveRate = businessActiveRate;
	}
	public int getBusinessActiveHour() {
		return businessActiveHour;
	}
	public void setBusinessActiveHour(int businessActiveHour) {
		this.businessActiveHour = businessActiveHour;
	}
	public int getBusinessActiveMin() {
		return businessActiveMin;
	}
	public void setBusinessActiveMin(int businessActiveMin) {
		this.businessActiveMin = businessActiveMin;
	}
	public int getBusinessActiveSec() {
		return businessActiveSec;
	}
	public void setBusinessActiveSec(int businessActiveSec) {
		this.businessActiveSec = businessActiveSec;
	}
	public int getBusinessActiveExttime() {
		return businessActiveExttime;
	}
	public void setBusinessActiveExttime(int businessActiveExttime) {
		this.businessActiveExttime = businessActiveExttime;
	}
	public String getBusinessActiveMethodName() {
		return businessActiveMethodName;
	}
	public void setBusinessActiveMethodName(String businessActiveMethodName) {
		this.businessActiveMethodName = businessActiveMethodName;
	}
	public int getBusinessAlarmAnlyway() {
		return businessAlarmAnlyway;
	}
	public void setBusinessAlarmAnlyway(int businessAlarmAnlyway) {
		this.businessAlarmAnlyway = businessAlarmAnlyway;
	}
	public int getBusinessAlarmAnalysisRate() {
		return businessAlarmAnalysisRate;
	}
	public void setBusinessAlarmAnalysisRate(int businessAlarmAnalysisRate) {
		this.businessAlarmAnalysisRate = businessAlarmAnalysisRate;
	}
	public int getBusinessLogAnalysisWay() {
		return businessLogAnalysisWay;
	}
	public void setBusinessLogAnalysisWay(int businessLogAnalysisWay) {
		this.businessLogAnalysisWay = businessLogAnalysisWay;
	}
	public int getBusinessLogSumRate() {
		return businessLogSumRate;
	}
	public void setBusinessLogSumRate(int businessLogSumRate) {
		this.businessLogSumRate = businessLogSumRate;
	}
	public int getBusinessAlarmAnalysisLogMergeWay() {
		return businessAlarmAnalysisLogMergeWay;
	}
	public void setBusinessAlarmAnalysisLogMergeWay(
			int businessAlarmAnalysisLogMergeWay) {
		this.businessAlarmAnalysisLogMergeWay = businessAlarmAnalysisLogMergeWay;
	}
	public int getAutoRegisterFlag() {
		return autoRegisterFlag;
	}
	public void setAutoRegisterFlag(int autoRegisterFlag) {
		this.autoRegisterFlag = autoRegisterFlag;
	}
	public int getAppid() {
		return appid;
	}
	public void setAppid(int appid) {
		this.appid = appid;
	}
	public int getDepartId() {
		return departId;
	}
	public void setDepartId(int departId) {
		this.departId = departId;
	}
	public String getCreateby() {
		return createby;
	}
	public void setCreateby(String createby) {
		this.createby = createby;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public int getAutoRegisterCd() {
		return autoRegisterCd;
	}
	public void setAutoRegisterCd(int autoRegisterCd) {
		this.autoRegisterCd = autoRegisterCd;
	}
	public String getUpdateby() {
		return updateby;
	}
	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	
}
