package com.jd.ump.bmp.common;

import java.util.Date;
import java.util.Map;

public class RuleVO 
{
	public final static Map<String,String> map = ValueObjectUtility.dataColumnMaping(new String[][]{
		{"id","id"},
		{"alarmAndWarnLeval","ar_alarm_leval"},
		{"linkSign","ar_link_sign"},
		{"alarmContinustimes","ar_alarm_ctie_times"},
		{"compareSign","ar_compare_sign"},
		{"compareValue","ar_compare_value"},
		{"thresholdValue","ar_threshold_val"},
		{"thresholdValueType","ar_thresholdval_type"},
		{"compareValueType","ar_compare_val_type"},
		{"lrrCompareThresholdValueType","ar_lrrCompare_type"},
		{"threldValueDataType","ar_threld_data_type"},
		{"sameTermType","ar_sameterm_type"},
		{"sameTermFetchDataWay","ar_sameterm_fetway"},
		{"sameTermAmplifyDataWay","ar_sametermAmplify_data_type"},	
		{"bizkey","ar_key"},
		{"createby","ar_created_by"},
		{"createDate","ar_dt_created"},
		{"updateby","ar_updated_by"},
		{"updateDate","ar_dt_updated"},
//		这个字段目前数据库还没有 @date：2013/1/8
//		{"warnContinustimes",""},
	});
	private int id;
	/**
	 * 报警预警级别
	 */
	private int alarmAndWarnLeval;
	/**
	 * 条件连接标识
	 */
	private int linkSign;
	/**
	 * 报警连续次数
	 */
	private int alarmContinustimes;
	/**
	 * 警告连续次数
	 */
	private int warnContinustimes;
	/**
	 * 比较标识
	 */
	private int compareSign;
	/**
	 * 业务值
	 */
	private String compareValue;
	/**
	 * 参照值
	 */
	private String thresholdValue;
	/**
	 * 参照值类型
	 */
	private int thresholdValueType;
	/**
	 * 比较值类型
	 */
	private int compareValueType;
	/**
	 * 环比参照值类型
	 */
	private int lrrCompareThresholdValueType;
	/**
	 * 参照值数据类型
	 */
	private int threldValueDataType;
	/**
	 * 同期数据类型
	 */
	private int sameTermType;
	/**
	 * 同期数据获取方式
	 */
	private int sameTermFetchDataWay;
	/**
	 * 同比增幅类型的周期 ****author:yfliliang
	 */
	private int sameTermAmplifyDataWay;
	/**
	 * key
	 */
	private String bizkey;
	/**
	 * 创建人
	 */
	private String createby;
	
	/**
	 * 创建日期
	 */
	private Date createDate;
	/**
	 * 更新人
	 */
	private String updateby;
	
	/**
	 * 更新日期
	 */
	private String updateDate;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAlarmAndWarnLeval() {
		return alarmAndWarnLeval;
	}
	public void setAlarmAndWarnLeval(int alarmAndWarnLeval) {
		this.alarmAndWarnLeval = alarmAndWarnLeval;
	}
	public int getLinkSign() {
		return linkSign;
	}
	public void setLinkSign(int linkSign) {
		this.linkSign = linkSign;
	}
	public int getAlarmContinustimes() {
		return alarmContinustimes;
	}
	public void setAlarmContinustimes(int alarmContinustimes) {
		this.alarmContinustimes = alarmContinustimes;
	}
	public int getWarnContinustimes() {
		return warnContinustimes;
	}
	public void setWarnContinustimes(int warnContinustimes) {
		this.warnContinustimes = warnContinustimes;
	}
	public int getCompareSign() {
		return compareSign;
	}
	public void setCompareSign(int compareSign) {
		this.compareSign = compareSign;
	}
	public String getCompareValue() {
		return compareValue;
	}
	public void setCompareValue(String compareValue) {
		this.compareValue = compareValue;
	}
	public String getThresholdValue() {
		return thresholdValue;
	}
	public void setThresholdValue(String thresholdValue) {
		this.thresholdValue = thresholdValue;
	}
	public int getThresholdValueType() {
		return thresholdValueType;
	}
	public void setThresholdValueType(int thresholdValueType) {
		this.thresholdValueType = thresholdValueType;
	}
	public int getCompareValueType() {
		return compareValueType;
	}
	public void setCompareValueType(int compareValueType) {
		this.compareValueType = compareValueType;
	}
	public int getLrrCompareThresholdValueType() {
		return lrrCompareThresholdValueType;
	}
	public void setLrrCompareThresholdValueType(int lrrCompareThresholdValueType) {
		this.lrrCompareThresholdValueType = lrrCompareThresholdValueType;
	}
	public int getThreldValueDataType() {
		return threldValueDataType;
	}
	public void setThreldValueDataType(int threldValueDataType) {
		this.threldValueDataType = threldValueDataType;
	}
	public int getSameTermType() {
		return sameTermType;
	}
	public void setSameTermType(int sameTermType) {
		this.sameTermType = sameTermType;
	}
	public int getSameTermFetchDataWay() {
		return sameTermFetchDataWay;
	}
	public void setSameTermFetchDataWay(int sameTermFetchDataWay) {
		this.sameTermFetchDataWay = sameTermFetchDataWay;
	}
	public int getSameTermAmplifyDataWay() {
		return sameTermAmplifyDataWay;
	}
	public void setSameTermAmplifyDataWay(int sameTermAmplifyDataWay) {
		this.sameTermAmplifyDataWay = sameTermAmplifyDataWay;
	}
	
	public String getBizkey() {
		return bizkey;
	}
	public void setBizkey(String bizkey) {
		this.bizkey = bizkey;
	}
	public String getCreateby() {
		return createby;
	}
	public void setCreateby(String createby) {
		this.createby = createby;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}	
	public String getUpdateby() {
		return updateby;
	}
	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	@Override
	public String toString()
	{
		return "alarmAndWarnLeval["+alarmAndWarnLeval+"]linkSign["+linkSign+"]alarmContinustimes["+alarmContinustimes+"]warnContinustimes["+warnContinustimes+"]" +
				"compareSign["+compareSign+"]compareValue["+compareValue+"]thresholdValue["+thresholdValue+"]thresholdValueType["+thresholdValueType+"]" +
				"compareValueType["+compareValueType+"]lrrCompareThresholdValueType["+lrrCompareThresholdValueType+"]threldValueDataType["+threldValueDataType+"]"+
				"sameTermType["+sameTermType+"]sameTermFetchDataWay["+sameTermFetchDataWay+"]sameTermAmplifyDataWay["+sameTermAmplifyDataWay+"]";
	}
}
