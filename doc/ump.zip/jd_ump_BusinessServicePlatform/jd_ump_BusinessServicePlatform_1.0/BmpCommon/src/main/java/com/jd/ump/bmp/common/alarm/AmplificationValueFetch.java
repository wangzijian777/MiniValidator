package com.jd.ump.bmp.common.alarm;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.BaseConfigVO;
import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.bmp.common.HbaseClient;
import com.jd.ump.bmp.common.cache.SetCache;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class AmplificationValueFetch implements AlarmCompareValueFetch
{
	private final static Logger LOGGER = LoggerFactory.getLogger(AmplificationValueFetch.class);
	
	@Resource(name="lastFacValueFetch")
	private LastFacValueFetch lastFacValueFetch;
	
	@Resource(name = "setCache")
    private SetCache setCache;
	
	@Resource(name = "hbaseClient")
	private HbaseClient hbaseClient;
	
	private final static int SA_DATA_TYPE = 0;
	
	@Override
	public BigDecimal fetchValue(Map<String, String> map, String value,Integer ... param) 
	{
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.AlarmRuleAmplificationValueFetch.fetchValue", false, true);
		    //通过param数组长度来判断是同比增幅还是环比增幅
			if(param.length == 0)
			{
				BigDecimal lastValue = lastFacValueFetch.fetchValue(map, value);
				BigDecimal currentValue = new BigDecimal(map.get(value));
				if(lastValue != null && currentValue != null)
				{
					//取到的增幅结果为百分比，如果是40就是40%
					return (currentValue.subtract(lastValue)).multiply(new BigDecimal(100)).divide(lastValue,0,RoundingMode.CEILING);
				}
			}
			else
			{//这个把获取同比增幅中上下两周期的数据和在一起了
				BigDecimal lastValue = this.fetchSametermAmplifyValue(map, value,param[SA_DATA_TYPE]);
				BigDecimal currentValue = new BigDecimal(map.get(value));
				if(lastValue != null && currentValue != null)
				{
					//取到的增幅结果为百分比，如果是40就是40%
					return (currentValue.subtract(lastValue)).multiply(new BigDecimal(100)).divide(lastValue,0,RoundingMode.CEILING);
				}
			}	
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[AmplificationValueFetch]method[fetchValue]key["+map.get(CommonConstants.BKEY)+"]amplification value parse error!",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
	/**
	 * 
	 * @param 获取同比增幅数据
	 */
	public BigDecimal fetchSametermAmplifyValue(Map<String, String> map, String value,Integer ... param)
	{
		String bKey = map.get(CommonConstants.BKEY);
		try 
		{
			BaseConfigVO bcVO = setCache.baseConfigCache(bKey);
			int analysisRate = bcVO.getBusinessAlarmAnalysisRate();
			long endTime = this.dateTimeParse(map.get(CommonConstants.BTIME),bKey);
			long startTime = endTime - TimeUnit.MINUTES.toMillis(analysisRate - 1);
			String fieldName = bcVO.getBusinessLogAnalysisWay() == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_VALUE_ACCUMULATION?CommonConstants.BVALUE:CommonConstants.BCOUNT;
			int mergeWay = bcVO.getBusinessAlarmAnalysisLogMergeWay();
	        return this.fetchDayOrWeekValue(bKey,param[SA_DATA_TYPE],startTime, endTime, fieldName, mergeWay);
			
		}
		catch (Exception e) 
		{
			LOGGER.error("class[AmplificationValueFetch]method[fetchSametermAmplifyValue]key["+bKey+"] sametermAmplifyValue fetch error!",e);
		}
		finally
		{
			
		}
		return null;
	}
	/**
	 * 
	 * @author yfliliang
	 * @param 这个函数是从同比里面拿出来的，能不能提到公共类里面呢?
	 * @return
	 */
	private long dateTimeParse(String date,String bKey)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.JSON_DATA_FORMAT);
		try
		{
			Date sourceDate = sdf.parse(date);
			return sourceDate.getTime();
		}
		catch(Exception e)
		{
			LOGGER.error("class[RuleAnalysis]method[dateTimeParse]key["+bKey+"]date["+date+"]date parse error!",e);
		}
		return 0l;
	}
	
	/**
	 * 
	 * @author yfliliang
	 * @param 这个函数获取同比增幅中上周期的数据
	 * @return
	 */
	private BigDecimal fetchDayOrWeekValue(String bKey,int sameTermAmplifyDataWay,long startTime,long endTime,String field,int mergeWay) throws IOException
	{
		long lastDayOrWeekSameStartTime;
		long lastDayOrWeekSameEndTime;
		if( sameTermAmplifyDataWay == CommonConstants.SAMETERMCOMPARE_AMPLIFICATION_TYPE_DAY  )
		{//上一天
			lastDayOrWeekSameStartTime = startTime - TimeUnit.HOURS.toMillis(24);
			lastDayOrWeekSameEndTime = endTime - TimeUnit.HOURS.toMillis(24);
		}
		else 
		{//上一周
			lastDayOrWeekSameStartTime = startTime - TimeUnit.DAYS.toMillis(7);
			lastDayOrWeekSameEndTime = endTime - TimeUnit.DAYS.toMillis(7);
		}		
		String hBaseStartTime = DateFormatUtils.format(new Date(lastDayOrWeekSameStartTime),CommonConstants.DATE_KEY_FORMAT);
		String hBaseEndTime = DateFormatUtils.format(new Date(lastDayOrWeekSameEndTime),CommonConstants.DATE_KEY_FORMAT);
		if(hBaseStartTime.equals(hBaseEndTime))
		{
			String hbaseKey = bKey+"."+hBaseEndTime;
			Map<String,String> resultMap = hbaseClient.queryRow(hbaseKey);
			if(resultMap == null || resultMap.isEmpty())
				return null;
			
			return new BigDecimal(resultMap.get(field));
		}
		else
		{
			String hbaseStartKey = bKey + "." + hBaseStartTime;
			String hbaseEndKey = bKey + "." + hBaseEndTime;
			List<Map<String,String>> resultList = hbaseClient.scanByRow(hbaseStartKey,hbaseEndKey);
			
			if(resultList == null || resultList.size() == 0)
				return null;
			
			BigDecimal sumValue = new BigDecimal(0);
			for(Map<String,String> map:resultList)
			{
				sumValue = sumValue.add(new BigDecimal(map.get(field)));
			}
			if(mergeWay == CommonConstants.ANALYSIS_DATA_MERGE_WAY_AVERGE)
			{
				BigDecimal avg = sumValue.divide(new BigDecimal(resultList.size()),0,RoundingMode.CEILING);
				return avg;
			}
			else
			{
				return sumValue;
			}
		}
	}

}
