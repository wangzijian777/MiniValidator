package com.jd.ump.bmp.common.domain;

import java.util.HashMap;
import java.util.Map;

public class RowData {
	private String rowKey;
	private Map<String, String> data = new HashMap<String, String>();
	
	
	public String getRowKey() {
		return rowKey;
	}
	public void setRowKey(String rowKey) {
		this.rowKey = rowKey;
	}
	public Map<String, String> getData() {
		return data;
	}
	public void setData(Map<String, String> data) {
		this.data = data;
	}

}
