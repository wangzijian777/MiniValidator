package com.jd.ump.bmp.common.cache;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


@Component
public class ClearCacheSource {
	private final static Logger LOGGER = LoggerFactory.getLogger(ClearCacheSource.class);
	@Resource(name = "setCache")
	private SetCache setCache;
	
	/**
	 * 整10分的时候清除缓存
	 */
	@Scheduled(cron = "0 0/30 * * * ?")
	public void clearCache() {
		LOGGER.info("class[ClearCacheSource]method[clearCache] start clear anlyway cache!");
		
		setCache.clearCache();

		LOGGER.debug("class[ClearCacheSource]method[clearCache] end clear anlyway cache!");
	}
	/**
	 * 每30分钟的时候清除缓存
	 */
	@Scheduled(cron = "0 0/30 * * * ?")
	public void clearAlarmRuleCache() {
		LOGGER.info("class[ClearCacheSource]method[clearAlarmRuleCache] start clear alarm rule cache!");

		setCache.clearAlarmRuleCache();

		LOGGER.debug("class[ClearCacheSource]method[clearAlarmRuleCache] end clear alarm rule cache!");
	}
}
