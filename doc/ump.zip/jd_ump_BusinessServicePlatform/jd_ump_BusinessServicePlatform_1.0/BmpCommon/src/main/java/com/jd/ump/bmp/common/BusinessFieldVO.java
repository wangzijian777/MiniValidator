package com.jd.ump.bmp.common;

public class BusinessFieldVO 
{
	/*
	 * 业务监控点key
	 */
	private String businessKey;
	/*
	 * 自定义字段1到5的名字
	 */
	private String field1;
	private String field2;
	private String field3;
	private String field4;
	private String field5;
	/*
	 * 自定义字段1到5的类型
	 */
	private int field1Type;
	private int field2Type;
	private int field3Type;
	private int field4Type;
	private int field5Type;
	/*
	 * 自定义字段1到5的序号
	 */
	private int field1Order;
	private int field2Order;
	private int field3Order;
	private int field4Order;
	private int field5Order;
	public String getBusinessKey() {
		return businessKey;
	}
	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}
	public String getField1() {
		return field1;
	}
	public void setField1(String field1) {
		this.field1 = field1;
	}
	public String getField2() {
		return field2;
	}
	public void setField2(String field2) {
		this.field2 = field2;
	}
	public String getField3() {
		return field3;
	}
	public void setField3(String field3) {
		this.field3 = field3;
	}
	public String getField4() {
		return field4;
	}
	public void setField4(String field4) {
		this.field4 = field4;
	}
	public String getField5() {
		return field5;
	}
	public void setField5(String field5) {
		this.field5 = field5;
	}
	public int getField1Type() {
		return field1Type;
	}
	public void setField1Type(int field1Type) {
		this.field1Type = field1Type;
	}
	public int getField2Type() {
		return field2Type;
	}
	public void setField2Type(int field2Type) {
		this.field2Type = field2Type;
	}
	public int getField3Type() {
		return field3Type;
	}
	public void setField3Type(int field3Type) {
		this.field3Type = field3Type;
	}
	public int getField4Type() {
		return field4Type;
	}
	public void setField4Type(int field4Type) {
		this.field4Type = field4Type;
	}
	public int getField5Type() {
		return field5Type;
	}
	public void setField5Type(int field5Type) {
		this.field5Type = field5Type;
	}
	public int getField1Order() {
		return field1Order;
	}
	public void setField1Order(int field1Order) {
		this.field1Order = field1Order;
	}
	public int getField2Order() {
		return field2Order;
	}
	public void setField2Order(int field2Order) {
		this.field2Order = field2Order;
	}
	public int getField3Order() {
		return field3Order;
	}
	public void setField3Order(int field3Order) {
		this.field3Order = field3Order;
	}
	public int getField4Order() {
		return field4Order;
	}
	public void setField4Order(int field4Order) {
		this.field4Order = field4Order;
	}
	public int getField5Order() {
		return field5Order;
	}
	public void setField5Order(int field5Order) {
		this.field5Order = field5Order;
	}
}
