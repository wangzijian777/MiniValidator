package com.jd.ump.bmp.common.alarm;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.BaseConfigVO;
import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.bmp.common.HbaseClient;
import com.jd.ump.bmp.common.cache.LoadData;
import com.jd.ump.bmp.common.cache.SetCache;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class SameTermValueFetch implements AlarmCompareValueFetch
{
	private final static Logger LOGGER = LoggerFactory.getLogger(SameTermValueFetch.class);
	private final static int ST_TYPE = 0;
	private final static int ST_DATA_WAY = 1;
	
	@Resource(name = "setCache")
    private SetCache setCache;
	
	@Resource(name = "hbaseClient")
	private HbaseClient hbaseClient;
	
	@Resource(name="loadData")
	private LoadData loadData;
	
	@Resource(name="expressionValueFetch")
	private AlarmCompareValueFetch expressionValueFetch;
	
	@Override
	public BigDecimal fetchValue(Map<String, String> map, String value,
			Integer... param) 
	{
		String bKey = map.get(CommonConstants.BKEY);
		CallerInfo callerInfo = null;
		
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.AlarmRuleSameTermValueFetch.fetchValue", false, true);
			
			BaseConfigVO bcVO = setCache.baseConfigCache(bKey);
			int analysisRate = bcVO.getBusinessAlarmAnalysisRate();
			long endTime = this.dateTimeParse(map.get(CommonConstants.BTIME),bKey);
			long startTime = endTime - TimeUnit.MINUTES.toMillis(analysisRate - 1);
			String fieldName = bcVO.getBusinessLogAnalysisWay() == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_VALUE_ACCUMULATION?CommonConstants.BVALUE:CommonConstants.BCOUNT;
			int mergeWay = bcVO.getBusinessAlarmAnalysisLogMergeWay();
			if(param[ST_TYPE] == CommonConstants.SAMETERMCOMPARE_TYPE_DAY && param[ST_DATA_WAY] == CommonConstants.SAMETERMCOMPARE_FETCH_WAY_VALUE)
			{
				return this.fetchDayDirectValue(bKey,value,startTime, endTime, fieldName, mergeWay);
			}
			else if(param[ST_TYPE] == CommonConstants.SAMETERMCOMPARE_TYPE_DAY 
					&& param[ST_DATA_WAY] == CommonConstants.SAMETERMCOMPARE_FETCH_WAY_HISAVGVALUE)
			{
				return this.fetchDayHisAvgValue(bKey,value,fieldName,startTime, endTime, mergeWay);
			}
			else if(param[ST_TYPE] == CommonConstants.SAMETERMCOMPARE_TYPE_WEEK 
					&& param[ST_DATA_WAY] == CommonConstants.SAMETERMCOMPARE_FETCH_WAY_VALUE)
			{
				return this.fetchWeekDerectValue(bKey,value,startTime, endTime, fieldName, mergeWay);
			}
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[SameTermValueFetch]method[fetchValue]key["+bKey+"]same term value fetch error!",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
	
	private BigDecimal fetchDayDirectValue(String bKey,String referenceValue,long startTime,long endTime,String field,int mergeWay) throws IOException
	{
		long lastDaySameStartTime = startTime - TimeUnit.HOURS.toMillis(24);
		long lastDaySameEndTime = endTime - TimeUnit.HOURS.toMillis(24);
		String hBaseStartTime = DateFormatUtils.format(new Date(lastDaySameStartTime),CommonConstants.DATE_KEY_FORMAT);
		String hBaseEndTime = DateFormatUtils.format(new Date(lastDaySameEndTime),CommonConstants.DATE_KEY_FORMAT);
		if(hBaseStartTime.equals(hBaseEndTime))
		{
			String hbaseKey = bKey+"."+hBaseEndTime;
			Map<String,String> resultMap = hbaseClient.queryRow(hbaseKey);
			if(resultMap == null || resultMap.isEmpty())
				return null;
			
			return expressionValueFetch.fetchValue(resultMap, referenceValue);
//			return new BigDecimal(resultMap.get(field));
		}
		else
		{
			String hbaseStartKey = bKey + "." + hBaseStartTime;
			String hbaseEndKey = bKey + "." + hBaseEndTime;
			List<Map<String,String>> resultList = hbaseClient.scanByRow(hbaseStartKey,hbaseEndKey);
			
			if(resultList == null || resultList.size() == 0)
				return null;
			
//			int sumValue = 0;
			BigDecimal sumValue = new BigDecimal(0);
			for(Map<String,String> map:resultList)
			{
//				sumValue += Integer.valueOf(map.get(field));
				sumValue = sumValue.add(new BigDecimal(map.get(field)));
			}
			Map<String,String> dataMap = new HashMap<String,String>();
			dataMap.put(CommonConstants.BKEY, bKey);
			if(mergeWay == CommonConstants.ANALYSIS_DATA_MERGE_WAY_AVERGE)
			{
//				int avg = sumValue / resultList.size();
				BigDecimal avg = sumValue.divide(new BigDecimal(resultList.size()),0,RoundingMode.CEILING);
				dataMap.put(field, avg.toString());
//				return new BigDecimal(avg);
			}
			else
			{
				dataMap.put(field,sumValue.toString());
//				return new BigDecimal(sumValue);
			}
			return expressionValueFetch.fetchValue(dataMap, referenceValue);
		}
	}
	
	private BigDecimal fetchDayHisAvgValue(String bKey,String referenceValue,String fieldName,long startTime,long endTime,int mergeWay)
	{
		long lastDaySameStartTime = startTime - TimeUnit.HOURS.toMillis(24);
		long lastDaySameEndTime = endTime - TimeUnit.HOURS.toMillis(24);
		List<BigDecimal> resultList = loadData.getSameTermData(bKey, lastDaySameStartTime, lastDaySameEndTime);
		if(resultList == null || resultList.size() == 0)
			return null;
		
		BigDecimal sumValue = new BigDecimal(0);
		int size = resultList.size();
		for(int i=0;i<size;i++)
		{
//			sumValue += resultList.get(i);
			sumValue = sumValue.add(resultList.get(i));
		}
		Map<String,String> dataMap = new HashMap<String,String>();
		dataMap.put(CommonConstants.BKEY, bKey);
		if(mergeWay == CommonConstants.ANALYSIS_DATA_MERGE_WAY_AVERGE)
		{
//			int avg = sumValue / size;
			BigDecimal avg = sumValue.divide(new BigDecimal(size),0,RoundingMode.CEILING);
			dataMap.put(fieldName, avg.toString());
//			return new BigDecimal(avg);
		}
		else
		{
			dataMap.put(fieldName,sumValue.toString());
		}
		return expressionValueFetch.fetchValue(dataMap, referenceValue);
//		return new BigDecimal(sumValue);
	}
	
	private BigDecimal fetchWeekDerectValue(String bKey,String referenceValue,long startTime,long endTime,String field,int mergeWay) throws IOException
	{
		long lastWeekSameStartTime = startTime - TimeUnit.DAYS.toMillis(7);
		long lastWeekSameEndTime = endTime - TimeUnit.DAYS.toMillis(7);
		String hBaseStartTime = DateFormatUtils.format(new Date(lastWeekSameStartTime),CommonConstants.DATE_KEY_FORMAT);
		String hBaseEndTime = DateFormatUtils.format(new Date(lastWeekSameEndTime),CommonConstants.DATE_KEY_FORMAT);
		if(hBaseStartTime.equals(hBaseEndTime))
		{
			String hbaseKey = bKey+"."+hBaseEndTime;
			Map<String,String> resultMap = hbaseClient.queryRow(hbaseKey);
			if(resultMap == null || resultMap.isEmpty())
				return null;
			
			return expressionValueFetch.fetchValue(resultMap,referenceValue);
//			return new BigDecimal(resultMap.get(field));
		}
		else
		{
			String hbaseStartKey = bKey + "." + hBaseStartTime;
			String hbaseEndKey = bKey + "." + hBaseEndTime;
			List<Map<String,String>> resultList = hbaseClient.scanByRow(hbaseStartKey,hbaseEndKey);
			
			if(resultList == null || resultList.size() == 0)
				return null;
			
			BigDecimal sumValue = new BigDecimal(0);
			for(Map<String,String> map:resultList)
			{
//				sumValue += Integer.valueOf(map.get(field));
				sumValue = sumValue.add(new BigDecimal(map.get(field)));
			}
			Map<String,String> dataMap = new HashMap<String,String>();
			dataMap.put(CommonConstants.BKEY, bKey);
			if(mergeWay == CommonConstants.ANALYSIS_DATA_MERGE_WAY_AVERGE)
			{
//				int avg = sumValue / resultList.size();
				BigDecimal avg = sumValue.divide(new BigDecimal(resultList.size()));
				dataMap.put(field,avg.toString());
//				return new BigDecimal(avg);
			}
			else
			{
				dataMap.put(field,sumValue.toString());
//				return new BigDecimal(sumValue);
			}
			return expressionValueFetch.fetchValue(dataMap,referenceValue);
		}
	}
	
	private long dateTimeParse(String date,String bKey)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.JSON_DATA_FORMAT);
		try
		{
			Date sourceDate = sdf.parse(date);
			return sourceDate.getTime();
		}
		catch(Exception e)
		{
			LOGGER.error("class[RuleAnalysis]method[dateTimeParse]key["+bKey+"]date["+date+"]date parse error!",e);
		}
		return 0l;
	}
}
