package com.jd.ump.bmp.common.alarm;

import java.math.BigDecimal;
import java.util.Map;

public interface AlarmCompareValueFetch 
{
	public BigDecimal fetchValue(Map<String,String> map,String value,Integer ... param);
}
