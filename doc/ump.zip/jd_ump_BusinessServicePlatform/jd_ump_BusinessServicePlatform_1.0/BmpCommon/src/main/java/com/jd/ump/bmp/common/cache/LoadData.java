package com.jd.ump.bmp.common.cache;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.BaseConfigVO;
import com.jd.ump.bmp.common.BusinessFieldVO;
import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.bmp.common.RuleVO;

@Component
public class LoadData 
{
	private final static Logger LOGGER = LoggerFactory.getLogger(LoadData.class);
	
    @Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;
    
    public BaseConfigVO loadBaseConfig(String businessKey)
	{
		BaseConfigVO bcVO = new BaseConfigVO();
		try
		{
			String sql = "select bus_key,bus_datacollect_way,bus_alm_anlyway,bus_alm_anlyrate,bus_log_anlyway,bus_almanlylog_mgway,auto_register_cd from ump_business_key_cfg(nolock) where bus_key=? and bus_status = 1";
			final Object[] params = new Object[] { businessKey };
			List<Map<String, Object>> rows = this.jdbcTemplate.queryForList(sql, params);
			if(rows.size() > 0)
			{
				for(Map<String,Object> row:rows)
				{
					bcVO.setBusinessKey(row.get("bus_key").toString());
					bcVO.setBusinessDataCollectWay((Integer)row.get("bus_datacollect_way"));
					bcVO.setBusinessAlarmAnlyway((Integer)row.get("bus_alm_anlyway"));
					bcVO.setBusinessAlarmAnalysisRate(row.get("bus_alm_anlyrate") == null?0:(Integer)row.get("bus_alm_anlyrate"));
					bcVO.setBusinessLogAnalysisWay(row.get("bus_log_anlyway") == null?0:(Integer)row.get("bus_log_anlyway"));
					bcVO.setBusinessAlarmAnalysisLogMergeWay(row.get("bus_almanlylog_mgway") == null?0:(Integer)row.get("bus_almanlylog_mgway"));
					bcVO.setAutoRegisterFlag(row.get("auto_register_cd") == null?0:(Integer)row.get("auto_register_cd"));
					return bcVO;
				}
			}
		}
		catch(Exception e)
		{
			LOGGER.error("class[LoadData]method[loadBaseConfig] data load error!",e);
		}
		return null;
	}
    
    public List<RuleVO> loadRuleObject(String businessKey,int sign)
	{
		try
		{
			String sql = "select ar_link_sign,ar_alarm_ctie_times,ar_compare_sign,ar_compare_value,ar_threshold_val,ar_thresholdval_type,ar_compare_val_type,ar_lrrCompare_type,ar_threld_data_type,ar_sameterm_type,ar_sameterm_fetway,ar_sametermAmplify_data_type from ump_business_alarm_rule(nolock) where ar_key = ? and ar_alarm_leval = ? order by ar_link_sign";
			final Object[] params = new Object[] { businessKey,sign };
			List<Map<String, Object>> ruleRows = this.jdbcTemplate.queryForList(sql, params);
			if (ruleRows.size() > 0)
			{
				List<RuleVO> list = new ArrayList<RuleVO>();
				for (Map<String, Object> row : ruleRows) 
				{
					RuleVO ruleVO = new RuleVO();
					ruleVO.setLinkSign(row.get("ar_link_sign") == null?0:(Integer)row.get("ar_link_sign"));
					ruleVO.setAlarmContinustimes(row.get("ar_alarm_ctie_times") == null?1:(Integer)row.get("ar_alarm_ctie_times"));
//					ruleVO.setWarnContinustimes(row.get("ar_warn_ctie_times") == null?1:(Integer)row.get("ar_warn_ctie_times"));
					ruleVO.setCompareSign(row.get("ar_compare_sign") == null?0:(Integer)row.get("ar_compare_sign"));
					ruleVO.setCompareValue(row.get("ar_compare_value").toString());
					ruleVO.setThresholdValue(row.get("ar_threshold_val") == null?"":row.get("ar_threshold_val").toString());
					ruleVO.setThresholdValueType(row.get("ar_thresholdval_type") == null?0:(Integer)row.get("ar_thresholdval_type"));
					ruleVO.setCompareValueType(row.get("ar_compare_val_type") == null?0:(Integer)row.get("ar_compare_val_type"));
					ruleVO.setLrrCompareThresholdValueType(row.get("ar_lrrCompare_type") == null?0:(Integer)row.get("ar_lrrCompare_type"));
					ruleVO.setThreldValueDataType(row.get("ar_threld_data_type") == null?0:(Integer)row.get("ar_threld_data_type"));
					ruleVO.setSameTermType(row.get("ar_sameterm_type") == null?0:(Integer)row.get("ar_sameterm_type"));
					ruleVO.setSameTermFetchDataWay(row.get("ar_sameterm_fetway") == null?0:(Integer)row.get("ar_sameterm_fetway"));
					ruleVO.setSameTermAmplifyDataWay(row.get("ar_sametermAmplify_data_type") == null?0:(Integer)row.get("ar_sametermAmplify_data_type"));
					list.add(ruleVO);
				}
				return list;
			}
		}
		catch(Exception e)
		{
			LOGGER.error("class[RuleParseDBManager]method[loadRuleObject]key["+businessKey+"]sign["+sign+"] invoke fail!",e);
		}
		return null;
	}
    
    public List<String> loadField(String businessKey)
	{
		List<String> list = new ArrayList<String>();
		try
		{
			String sql = "select bf_name from ump_business_field(nolock) where bus_key = ? and bf_type = 1";
			final Object[] params = new Object[] { businessKey };
			List<Map<String, Object>> fieldRows = this.jdbcTemplate.queryForList(sql, params);
			if (fieldRows.size() > 0)
			{
				 for (Map<String, Object> row : fieldRows)
				 {
					 list.add(row.get("bf_name").toString());
				 }
			}
		}
		catch(Exception e)
		{
			LOGGER.error("class[RuleParseDBManager]method[loadField] method invoke fail! parameter key=" + businessKey,e);
		}
		return list;
	}
    
    public BusinessFieldVO loadFacField(String businessKey)
    {
    	try
    	{
    		String sql = "select bf_name,bf_order,bf_type from ump_business_field(nolock) where bus_key = ?";
    		final Object[] params = new Object[] { businessKey };
    		List<Map<String, Object>> rows = this.jdbcTemplate.queryForList(sql, params);
    		if(rows.size() > 0)
    		{
    			BusinessFieldVO bFieldVO = new BusinessFieldVO();
    			bFieldVO.setBusinessKey(businessKey);
    			for(Map<String,Object> row:rows)
    			{
    				int order = (Integer)row.get("bf_order");
    				String fieldName = row.get("bf_name").toString();
    				int fieldType = (Integer)row.get("bf_type");
    				if(order == 1)
    				{
    					bFieldVO.setField1(fieldName);
    					bFieldVO.setField1Order(order);
    					bFieldVO.setField1Type(fieldType);
    				}
    				else if(order == 2)
    				{
    					bFieldVO.setField2(fieldName);
    					bFieldVO.setField2Order(order);
    					bFieldVO.setField2Type(fieldType);
    				}
    				else if(order == 3)
    				{
    					bFieldVO.setField3(fieldName);
    					bFieldVO.setField3Order(order);
    					bFieldVO.setField3Type(fieldType);
    				}
    				else if(order == 4)
    				{
    					bFieldVO.setField4(fieldName);
    					bFieldVO.setField4Order(order);
    					bFieldVO.setField4Type(fieldType);
    				}
    				else if(order == 5)
    				{
    					bFieldVO.setField5(fieldName);
    					bFieldVO.setField5Order(order);
    					bFieldVO.setField5Type(fieldType);
    				}
    			}
    			return bFieldVO;
    		}
    	}
    	catch(Exception e)
    	{
    		LOGGER.error("class[LoadData]method[loadFacField] data load error!",e);
    	}
    	return null;
    }
    
    public List<BigDecimal> getSameTermData(String businessKey,long startTime,long endTime)
	{
		List<BigDecimal> list = new ArrayList<BigDecimal>();
		try
		{
			int dtStartTime = this.parseDataFormat(startTime);
			int dtEndTime = this.parseDataFormat(endTime);
//			String sql = "select (bst_value/bst_count) as st_value from ump_business_sameterm(nolock) where bst_key = ? and bst_hm >= ? and bst_hm <= ?";
			String sql = "select cast(bst_value/bst_count as decimal(18,0)) as st_value from ump_business_sameterm(nolock) where bst_key = ? and bst_hm >= ? and bst_hm <= ?";
			final Object[] params = new Object[] { businessKey,dtStartTime,dtEndTime };
			List<Map<String, Object>> rows = this.jdbcTemplate.queryForList(sql, params);
			if (rows.size() > 0)
			{
				for(Map<String,Object> row:rows)
				{
					list.add(new BigDecimal(row.get("st_value").toString()));
				}
			}
		}
		catch(Exception e)
		{
			LOGGER.error("class[RuleParseDBManager]method[getSameTermData]key["+businessKey+"] invoke fail!",e);
			return null;
		}
		return list;
	}
	
	private int parseDataFormat(long time) throws ParseException
	{
		return Integer.valueOf(DateFormatUtils.format(new Date(time),CommonConstants.HHMM_FORMAT));
	}
	
	
}
