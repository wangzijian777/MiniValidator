package com.jd.ump.bmp.common;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.jd.redis.support.RedisCommands;

@Component
public class RedisManager {
	@Resource(name = "redisClient")
	private RedisCommands redisClient;
	
	private final static String BMP_PREFIX = "BMP_";
	
	public boolean exists(String key, String field) {
		return redisClient.hexists(BMP_PREFIX + key, field);
	}
	
	public String getFieldData(String key,String field)
	{
		return redisClient.hget(BMP_PREFIX + key, field);
	}
	
	public void saveFieldData(String key,String field,String value)
	{
		redisClient.hset(BMP_PREFIX + key, field, value);
	}

	public Map<String, String> getData(String key) {
		Map<String, String> resultMap = redisClient.hgetAll(BMP_PREFIX + key);
		return resultMap;
	}
	
	public Long hincrBy(String key, String field, Long value){
		Long result = redisClient.hincrBy(BMP_PREFIX + key, field, value);
		return result;
	}

	public void setExpire(final String key, final int second) {
		redisClient.expire(BMP_PREFIX + key, second);
	}
}
