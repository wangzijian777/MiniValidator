package com.jd.ump.bmp.common;

public class CommonBackCodeConstants 
{
	/**
	 * 数据校验成功
	 */
	public static final String SUCCESS = "0000000";
	/**
	 * JSON字符串为null
	 */
	public static final String ERROR_JSON_NULL = "0000001";
	/**
	 * 未知异常
	 */
	public static final String ERROR_OTHER = "9999999";
	/**
	 * JSON字符串解析错误
	 */
	public static final String ERROR_JSON_PARSE = "0000002";
	/**
	 * 业务监控key为null
	 */
	public static final String ERROR_MONITOR_KEY_NULL = "0000003";
	/**
	 * 基础配置信息为null
	 */
	public static final String ERROR_BASE_CONFIG_NULL = "0000004";
	/**
	 * 数据来源与页面配置的数据采集方式不匹配
	 */
	public static final String ERROR_DATA_COLLECTION_WAY_NOEQ = "0000005";
	/**
	 * 没有配置业务字段
	 */
	public static final String ERROR_FACILITY_FIELD_NOCONFIG = "0000006";
	/**
	 * 页面配置的字段类型和接收到的字段类型不匹配
	 */
	public static final String ERROR_FACILITY_FIELD_TYPE_NOSAME = "0000007";
	/**
	 * 数据保存失败
	 */
	public static final String ERROR_DATA_SAVE_FAIL = "0000008";
	
	//自动注册相关校验异常
	/**
	 * key的前缀不是以应用名英文缩写开头
	 */
	public static final String ERROR_KEY_PREFIX_NE_APPNAME = "0000009";
	/**
	 * 报警分析频率不是1,5,10,15,20,30中的一个
	 */
	public static final String ERROR_ALARM_ANALYSIS_RATE = "0000010";
	/**
	 * 操作标识不是1,2,3中的一个(1为新增，2为修改，3为删除)
	 */
	public static final String ERROR_OPERATE_SIGN = "0000011";
	/**
	 * 比较标识不是1,2,3,4中的一个(1为大于，2为小于，3为大于等于，4为小于等于)
	 */
	public static final String ERROR_COMPARE_SIGN = "0000012";
	/**
	 * 不是整数校验
	 */
	public static final String ERROR_NON_NUMERIC = "0000013";
	/**
	 * 自动注册状态码不为0,1(1为启用中，0为禁用中)
	 */
	public static final String ERROR_MONITOR_STATUS = "0000014";
	/**
	 * 自动注册新增时，验证不通过;
	 */
	public static final String ERROR_FAIL = "0000015";
	/**
	 * 自动注册新增时，key值已存在;
	 */
	public static final String ERROR_KEY_EXISTED = "0000016";
	/**
	 * key状态为可用状态时key无法删除
	 */
	public static final String ERROR_KEY_UESE_NOW = "0000017";
	/**
	 * 没有创建应用在UMP中
	 */
	public static final String ERROR_APP_NOEXIST = "0000018";
}
