package com.jd.ump.bmp.common;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ValueObjectUtility 
{
	private static final Logger logger = LoggerFactory.getLogger(ValueObjectUtility.class);
	protected static Map<String,String> dataColumnMaping(String[][] data)
	{
		Map<String,String> map = new HashMap<String,String>();
		for(int i=0;i<data.length;i++)
		{
			String propertyName = data[i][0];
			if(map.containsKey(propertyName))
			{
				logger.warn("class[ValueObject]propertyName["+propertyName+"]already exist!");
			}
			else
			{
				map.put(propertyName, data[i][1]);
			}
		}
		return map;
	}
}
