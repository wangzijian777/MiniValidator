package com.jd.ump.bmp.common.alarm;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.BaseConfigVO;
import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.bmp.common.HbaseClient;
import com.jd.ump.bmp.common.RedisManager;
import com.jd.ump.bmp.common.cache.SetCache;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class LastFacValueFetch
{
	private final static Logger LOGGER = LoggerFactory.getLogger(LastFacValueFetch.class);
	
	@Resource(name = "setCache")
    private SetCache setCache;
	
	@Resource(name = "hbaseClient")
	private HbaseClient hbaseClient;
	
	@Resource(name = "redisManager")
	protected RedisManager redisManager;
	
	public BigDecimal fetchValue(Map<String, String> map, String value,Integer ... param) 
	{
		String bKey = map.get(CommonConstants.BKEY);
		BaseConfigVO bcVO = setCache.baseConfigCache(bKey);
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.AlarmRuleLastFacValueFetch.fetchValue", false, true);
			
			if((bcVO.getBusinessDataCollectWay() == CommonConstants.DATA_SOURCE_ACTIVED || bcVO.getBusinessDataCollectWay() == CommonConstants.DATA_SOURCE_LOG)
					&& (bcVO.getBusinessLogAnalysisWay() == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_VALUE_ACCUMULATION || 
							bcVO.getBusinessLogAnalysisWay() == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_TIMES_ACCUMULATION))
			{
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[LastFacValueFetch] value and count leijia fetch value");
					
				return fetchValueAndCountLastValue(bKey,bcVO.getBusinessAlarmAnalysisRate(),
						map.get(CommonConstants.BTIME),
						bcVO.getBusinessAlarmAnalysisLogMergeWay(),value);
			}
			else
			{
				return fetchResultLastValue(bKey,value);
			}
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[LastFacValueFetch]metod[fetchValue]key["+bKey+"] fetch last value error!",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
	
	public Map<String, String> fetchMapValue(Map<String, String> map,
			String value) 
	{
		String bKey = map.get(CommonConstants.BKEY);
		BaseConfigVO bcVO = setCache.baseConfigCache(bKey);
		try
		{
			if((bcVO.getBusinessDataCollectWay() == CommonConstants.DATA_SOURCE_ACTIVED || bcVO.getBusinessDataCollectWay() == CommonConstants.DATA_SOURCE_LOG)
					&& (bcVO.getBusinessLogAnalysisWay() == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_VALUE_ACCUMULATION || 
							bcVO.getBusinessLogAnalysisWay() == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_TIMES_ACCUMULATION))
			{
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[LastFacValueFetch] value and count leijia fetch value");
				
				String fieldName = null;
				if(bcVO.getBusinessLogAnalysisWay() == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_VALUE_ACCUMULATION)
				{
					fieldName = CommonConstants.BVALUE;
				}
				else
				{
					fieldName = CommonConstants.BCOUNT;
				}
				
				BigDecimal resultValue = this.fetchValueAndCountLastValue(bKey,bcVO.getBusinessAlarmAnalysisRate(),
						map.get(CommonConstants.BTIME),
						bcVO.getBusinessAlarmAnalysisLogMergeWay(),fieldName);
				Map<String,String> resultMap = new HashMap<String,String>();
				resultMap.put(CommonConstants.BKEY, bKey);
				resultMap.put(CommonConstants.BTIME, map.get(CommonConstants.BTIME));
				resultMap.put(fieldName, resultValue.toString());
				return resultMap;
			}
			else
			{
				return this.fetchResultLastMap(bKey);
			}
		}
		catch(Exception e)
		{
			LOGGER.error("class[LastFacValueFetch]metod[fetchValue]key["+bKey+"] fetch last value error!",e);
		}
		return null;
	}
	
	private BigDecimal fetchValueAndCountLastValue(String bKey,int analysisRate,String analysisTime,int mergeWay,String value) throws IOException
	{
		long time = this.dateTimeParse(analysisTime, bKey);
		int lastInterval = analysisRate + analysisRate - 1;
		long hbaseStartTime = time - TimeUnit.MINUTES.toMillis(lastInterval);
		long hbaseEndTime = time - TimeUnit.MINUTES.toMillis(analysisRate);
		String hbaseKeyStartTime = DateFormatUtils.format(new Date(hbaseStartTime),CommonConstants.DATE_KEY_FORMAT);
		String hbaseKeyEndTime = DateFormatUtils.format(new Date(hbaseEndTime),CommonConstants.DATE_KEY_FORMAT);
		if(hbaseKeyStartTime.equals(hbaseKeyEndTime))
		{
			String hbaseKey = bKey+"."+hbaseKeyEndTime;
			Map<String,String> resultMap = hbaseClient.queryRow(hbaseKey);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[LastFacValueFetch]hbaseKey["+hbaseKey+"]value["+resultMap.get(value)+"]");
			
			return new BigDecimal(resultMap.get(value));
		}
		else
		{
			String hbaseStartKey = bKey+"."+hbaseKeyStartTime;
			String hbaseEndKey = bKey + "." + hbaseKeyEndTime;
			List<Map<String,String>> resultList = hbaseClient.scanByRow(hbaseStartKey,hbaseEndKey);
			BigDecimal sumValue = new BigDecimal(0);
			for(Map<String,String> map:resultList)
			{
//				sumValue +=  Integer.valueOf(map.get(value));
				sumValue = sumValue.add(new BigDecimal(map.get(value)));
			}
			
			if(mergeWay == CommonConstants.ANALYSIS_DATA_MERGE_WAY_AVERGE)
			{
//				int avg = sumValue / resultList.size();
				BigDecimal avg = sumValue.divide(new BigDecimal(resultList.size()),0,RoundingMode.CEILING);
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[LastFacValueFetch]hbaseStartKey["+hbaseStartKey+"]hbaseEndKey["+hbaseEndKey+"]avgvalue["+avg+"]");
				
//				return new BigDecimal(avg);
				return avg;
			}
			else
			{
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[LastFacValueFetch]hbaseStartKey["+hbaseStartKey+"]hbaseEndKey["+hbaseEndKey+"]sumvalue["+sumValue+"]");
				
//				return new BigDecimal(sumValue);
				return sumValue;
			}
		}
	}
	
	private BigDecimal fetchResultLastValue(String bKey,String field) throws IOException
	{
		Map<String,String> resultMap = this.fetchResultLastMap(bKey);
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("[LastFacValueFetch]last value is["+resultMap.get(field)+"]");
		
		return new BigDecimal(resultMap.get(field));
	}
	
	private Map<String,String> fetchResultLastMap(String bKey) throws IOException
	{
		String hBaseKey = redisManager.getFieldData(CommonConstants.LAST_RESULT_KEY_HBASE, bKey);
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("[LastFacValueFetch]redis last hbasekey["+hBaseKey+"]");
		
		Map<String,String> resultMap = hbaseClient.queryRow(hBaseKey);
		return resultMap;
	}
	
	private long dateTimeParse(String date,String bKey)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.JSON_DATA_FORMAT);
		try
		{
			Date sourceDate = sdf.parse(date);
			return sourceDate.getTime();
		}
		catch(Exception e)
		{
			LOGGER.error("class[RuleAnalysis]method[dateTimeParse]key["+bKey+"]date["+date+"]date parse error!",e);
		}
		return 0l;
	}
}
