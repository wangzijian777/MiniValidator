package com.jd.ump.bmp.common;

public class DataCheckException extends Exception
{
	private static final long serialVersionUID = 1L;
	private String message;
	private String code;
	public DataCheckException(String msg,String code)
	{
		super(msg);
		this.code = code;
		this.message = msg;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
}
