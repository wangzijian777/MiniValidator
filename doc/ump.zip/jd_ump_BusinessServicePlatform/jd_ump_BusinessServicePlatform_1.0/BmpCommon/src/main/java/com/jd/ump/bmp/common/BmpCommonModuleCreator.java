package com.jd.ump.bmp.common;

import com.jd.ump.common.IModuleCreator;
import com.jd.ump.common.Module;

public class BmpCommonModuleCreator implements IModuleCreator {
	@Override
	public Module create() {
		Module module = new Module();
		
		module.setName("BmpCommon");
		module.setVersion("2013020201");
		
		return module;
	}
}