package com.jd.ump.bmp.common.alarm;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.BaseConfigVO;
import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.bmp.common.MessagePackage;
import com.jd.ump.bmp.common.RedisManager;
import com.jd.ump.bmp.common.RuleVO;
import com.jd.ump.bmp.common.alarm.register.LoghupEventAlarmUtil;
import com.jd.ump.bmp.common.cache.SetCache;
import com.jd.ump.common.EventAlarmUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class AlarmRuleParse 
{
	private final static Logger LOGGER = LoggerFactory.getLogger(AlarmRuleParse.class);
	
	@Resource(name = "setCache")
    private SetCache setCache;
	
	@Resource(name = "redisManager")
	private RedisManager redisManager;
	
	@Resource(name = "alarmRuleContext")
	private AlarmRuleContext alarmRuleContext;
	
	public void alarmAndWarnParse(Map<String,String> currentDataMap)
	{
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("[Test Message][alarmAndWarnParse]alarm analysis map is["+currentDataMap.toString()+"]");
		
		String bKey = currentDataMap.get(CommonConstants.BKEY);
		String bTime = currentDataMap.get(CommonConstants.BTIME);
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.AlarmRuleParse.alarmAndWarnParse", false, true);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[common alarm analysis center]key["+bKey+"]btime["+bTime+"] start analysis!");
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[Test Message][alarmAndWarnParse]start key["+bKey+"] alarm analysis!");
			
			List<RuleVO> alarmRuleList = setCache.getAWRuleCache(bKey, CommonConstants.ALARM_SIGN);
			StringBuilder message = new StringBuilder("");
			BaseConfigVO bcVO = setCache.baseConfigCache(bKey);
			
			buildMessage(bcVO.getBusinessDataCollectWay(),bcVO.getBusinessLogAnalysisWay(),bcVO.getBusinessAlarmAnalysisRate(), bTime, bKey, message);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug(message.toString());
			
			boolean alarmRuleExist = alarmRuleList != null && alarmRuleList.size() > 0;
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[common alarm analysis center]key["+bKey+"]btime["+bTime+"]alarm rule size["+alarmRuleList.size()+"]");
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[Test Message][alarmAndWarnParse]alarm rule exist sign["+alarmRuleExist+"]");
			
			int sourceAlarmCount = this.fetchAlarmAndWarnTimes(bKey);
			int currentAlarmCount = sourceAlarmCount;
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[Test Message][alarmAndWarnParse]alarm cache times is ["+sourceAlarmCount+"] in redis!");
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[common alarm analysis center]key["+bKey+"]btime["+bTime+"]alarm source alarm count is ["+sourceAlarmCount+"];");
			
			if(alarmRuleExist)
			{
				
				boolean alarmFlag = false;
				
				alarmFlag = alarmCompare(currentDataMap,alarmRuleList,message);
				
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[Test Message][alarmAndWarnParse]alarm analysis result is["+alarmFlag+"]");
				
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[common alarm analysis center]key["+bKey+"]btime["+bTime+"] alarm analysis reuslt is ["+alarmFlag+"]");
				
				if(alarmFlag)
				{
					if(LOGGER.isDebugEnabled())
						LOGGER.debug("[Test Message][alarmAndWarnParse]alarm message is ["+message.toString()+"]");
					
					int alarmContinueTimes = alarmRuleList.get(0).getAlarmContinustimes();
					currentAlarmCount = currentAlarmCount + 1;
					if(currentAlarmCount >= alarmContinueTimes)
					{
						currentAlarmCount = 0;
						//是统一日志的key则调用统一日志的报警接口报警，否则走UMP的报警
						if(bcVO.getAutoRegisterFlag() == CommonConstants.LOGHUPALERT_SIGN)
						{
							String value = null;
							if(bcVO.getBusinessLogAnalysisWay() == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_VALUE_ACCUMULATION)
							{
								value = currentDataMap.get(CommonConstants.BVALUE);
							}
							else
							{
								value = currentDataMap.get(CommonConstants.BCOUNT);
							}
							this.alarm(bKey,System.currentTimeMillis(),value);
						}
						else
						{
							this.alarm(bKey, message.toString());
						}
					}
				}
				else
				{
					if(currentAlarmCount > 0)
						currentAlarmCount = 0;
				}
				
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[common alarm analysis center]key["+bKey+"]btime["+bTime+"]current alarm count is ["+currentAlarmCount+"];");
				
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[Test Message][alarmAndWarnParse]current alarm analysis times is["+currentAlarmCount+"]");
				
				if(sourceAlarmCount != currentAlarmCount)
					this.saveAlarmTimesResult(currentAlarmCount,bKey);
				
			}
			else
			{
				LOGGER.error("class[AlarmRuleParse]method[alarmAndWarnParse]key["+bKey+"]time["+bTime+"]alarm rule don't exist!");
				return;
			}
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[common alarm analysis center]key["+bKey+"]btime["+bTime+"] end analysis!");
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[AlarmRuleParse]method[alarmAndWarnParse]key["+bKey+"]time["+bTime+"]alarm parse error!please check alarm rule!",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("[Test Message][alarmAndWarnParse]end key["+bKey+"] alarm analysis!");
	}
	
	private boolean alarmCompare(Map<String,String> currentDataMap,List<RuleVO> ruleList,StringBuilder message)
	{
		boolean compareResult = false;
		for(int i=0;i<ruleList.size();i++)
		{
			RuleVO alarmRuleVO = ruleList.get(i);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[Test Message][alarmCompare]alarm rule is ["+alarmRuleVO.toString()+"]!");
			
			if((alarmRuleVO.getLinkSign() == CommonConstants.LINK_SIGN_AND && !compareResult) || (alarmRuleVO.getLinkSign() == CommonConstants.LINK_SIGN_OR && compareResult))
			{
				continue;
			}
			
			BigDecimal facilityValue = alarmRuleContext.fetchBusinessValue(alarmRuleVO, currentDataMap);
			BigDecimal referenceValue = alarmRuleContext.fetchReferenceValue(alarmRuleVO, currentDataMap);
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[Test Message][alarmCompare] calculate facilityValue is ["+facilityValue+"]");
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[Test Message][alarmCompare] calculate referenceValue is ["+referenceValue+"]");
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[common alarm analysis center]facilityValue is["+facilityValue+"]referenceValue is["+referenceValue+"]");
			
			if(facilityValue == null || referenceValue == null)
			{
				LOGGER.error("class[AlarmRuleParse]method[alarmAndWarnParse] facilityValue or referenceValue is null,don't compare!");
				return false;
			}
				
			if(i == 1 && compareResult)
			{
				message.append(alarmRuleVO.getLinkSign() == CommonConstants.LINK_SIGN_AND?"And":"Or");
			}
			
			boolean result = alarmValueCompare(facilityValue,referenceValue,alarmRuleVO,message);
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[Test Message][alarmCompare]alarm rule ["+i+"]referenceValue and faicilityValue compare result is ["+result+"]");
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("alam message[" + message.toString()+"]...............");
			
			if(alarmRuleVO.getLinkSign() == CommonConstants.LINK_SIGN_AND)
			{
				compareResult = compareResult && result;
			}
			else if(alarmRuleVO.getLinkSign() == CommonConstants.LINK_SIGN_OR)
			{
				compareResult = compareResult || result;
			}
			else
			{
				compareResult = result;
			}
		}
		return compareResult;
	}
	
	private boolean alarmValueCompare(BigDecimal facilityValue,BigDecimal referenceValue,RuleVO alarmRuleVO,StringBuilder messageCondition)
	{
		boolean judgeResult = false;
		int compareSign = alarmRuleVO.getCompareSign();
		int compareValueType = alarmRuleVO.getCompareValueType();
		String compareValue  = alarmRuleVO.getCompareValue();
		int thresholdValueType = alarmRuleVO.getThresholdValueType();
		String thresholdValue = alarmRuleVO.getThresholdValue();
		if(compareSign == CommonConstants.COMPARE_SIGN_GREATERTHAN)
		{
			judgeResult = facilityValue.compareTo(referenceValue) > 0;
		}
		else if(compareSign == CommonConstants.COMPARE_SIGN_LESSTHAN)
		{
			judgeResult = facilityValue.compareTo(referenceValue) < 0;
		}
		else if(compareSign == CommonConstants.COMPARE_SIGN_EQUALGT)
		{
			judgeResult = facilityValue.compareTo(referenceValue) >= 0;
		}
		else if(compareSign == CommonConstants.COMPARE_SIGN_EQUALLT)
		{
			judgeResult = facilityValue.compareTo(referenceValue) <= 0;
		}
		
		if(judgeResult)
		{
			String percent = "";
			MessagePackage messagePc = MessagePackage.getInstance();
			if(compareValueType == CommonConstants.FACILITY_VALUE_SAMETERMCOMPARE_AMPLIFICATION_TYPE)
			{
				percent = "%";
				int sameTermAmplifyDataType = alarmRuleVO.getSameTermAmplifyDataWay();
				messageCondition.append("【业务值(以"+compareValue+"按"+messagePc.fetchThreldValueDataTypeDesc(sameTermAmplifyDataType)+"做"+messagePc.fetchCompareValueTypeDesc(compareValueType)+")"+facilityValue+percent+this.fetchCompareSignDesc(compareSign));
			}
			else if(compareValueType == CommonConstants.FACILITY_VALUE_AMPLIFICATION_TYPE)
			{
				percent = "%";
				messageCondition.append("【业务值(以"+compareValue+"做"+messagePc.fetchCompareValueTypeDesc(compareValueType)+")"+facilityValue+percent+this.fetchCompareSignDesc(compareSign));
			}
			else
			{
				messageCondition.append("【业务值("+messagePc.fetchCompareValueTypeDesc(compareValueType)+compareValue+")"+facilityValue+percent+this.fetchCompareSignDesc(compareSign));
			}
			if(thresholdValueType == CommonConstants.REFERENCE_VALUE_RINGCOMPARE_TYPE )
			{
				messageCondition.append("参照值(以"+thresholdValue+"做环比)"+referenceValue+percent+"】");
			}
			else if(thresholdValueType == CommonConstants.REFERENCE_VALUE_SAMETERMCOMPARE )
			{
				int sameTermPeriod = alarmRuleVO.getSameTermType();
				messageCondition.append("参照值(以"+thresholdValue+"按"+messagePc.fetchThreldValueDataTypeDesc(sameTermPeriod)+"做同比)"+referenceValue+percent+"】");
			}
			else if(thresholdValueType == CommonConstants.REFERENCE_VALUE_FIXED_TYPE)
			{
				messageCondition.append("参照值("+messagePc.fetchThresholdValueTypeDesc(thresholdValueType)+")"+referenceValue+percent+"】");
			}
			else
			{
				messageCondition.append("参照值("+messagePc.fetchThresholdValueTypeDesc(thresholdValueType)+thresholdValue+")"+referenceValue+percent+"】");
			}
			//messageCondition.append("【业务值"+facilityValue+this.fetchCompareSignDesc(compareSign)+"参照值"+referenceValue+"】");
		}	
		return judgeResult;
	}
	
	private int fetchAlarmAndWarnTimes(String fieldKey)
	{
		String alamTimes = redisManager.getFieldData(CommonConstants.ALARM_WARN_TIMES_KEY,fieldKey);
		if(alamTimes == null)
		{
			return 0;
		}
		else
		{
			return Integer.valueOf(alamTimes);
		}
	}
	
	private void saveAlarmTimesResult(int alarmCount,String fieldKey)
	{
		redisManager.saveFieldData(CommonConstants.ALARM_WARN_TIMES_KEY, fieldKey, String.valueOf(alarmCount));
	}
	
	private String fetchCompareSignDesc(int compareSign)
	{
		if(compareSign == CommonConstants.COMPARE_SIGN_GREATERTHAN)
		{
			return "大于"; 
		}
		else if(compareSign == CommonConstants.COMPARE_SIGN_LESSTHAN)
		{
			return "小于";
		}
		else if(compareSign == CommonConstants.COMPARE_SIGN_EQUALGT)
		{
			return "大于等于"; 
		}
		else if(compareSign == CommonConstants.COMPARE_SIGN_EQUALLT)
		{
			return "小于等于";
		}
		else
		{
			return "";
		}
	}
	
	private void buildMessage(int dataFetchWay,int logAnalysisWay,int logAnalysisRate,String analysisTime,String bKey,StringBuilder message)
	{
		StringBuilder smsMessage = new StringBuilder("");
		if(dataFetchWay == CommonConstants.DATA_SOURCE_ACTIVE)
		{
			message.append("在"+this.dateParse(analysisTime,bKey).get(CommonConstants.MAIL_TAG)+"时间");
			smsMessage.append("时间"+this.dateParse(analysisTime,bKey).get(CommonConstants.SMS_TAG)+",详情见邮件");
		}
		else if((dataFetchWay == CommonConstants.DATA_SOURCE_ACTIVED || dataFetchWay == CommonConstants.DATA_SOURCE_LOG)
				&& logAnalysisWay == CommonConstants.FACILITY_DATA_ANALYSIS_WAY_SOURCEDATA)
		{
			message.append("在"+this.dateParse(analysisTime,bKey).get(CommonConstants.MAIL_TAG)+"时间");
			smsMessage.append("时间"+this.dateParse(analysisTime,bKey).get(CommonConstants.SMS_TAG)+",详情见邮件");
		}
		else
		{
			long time = dateTimeParse(analysisTime,bKey);
			if(logAnalysisRate == 1)
			{
				message.append("在"+DateFormatUtils.format(time,CommonConstants.DATE_FORMAT)+"时间");
				smsMessage.append("时间"+DateFormatUtils.format(time,CommonConstants.HH_MM_FORMAT)+",详情见邮件");
			}
			else
			{
				long startTime = time - TimeUnit.MINUTES.toMillis(logAnalysisRate-1);
				message.append("在"+DateFormatUtils.format(startTime,CommonConstants.DATE_FORMAT)+"和"+DateFormatUtils.format(time,CommonConstants.DATE_FORMAT)+"时间范围内");
				smsMessage.append("时间"+DateFormatUtils.format(startTime,CommonConstants.HH_MM_FORMAT)+"到"+DateFormatUtils.format(time,CommonConstants.HH_MM_FORMAT)+",详情见邮件");
			}
		}
		smsMessage.append(CommonConstants.ALARM_SEPARATOR);
		message.insert(0, smsMessage);
	}
	
	private void alarm(String key,String message)
	{	
		String smsKey = "";
		if(key.length()>37)
		{
			String [] keyArr = key.split("\\.");
			if(keyArr.length>1)
			{
				smsKey = keyArr[0] + "*" + keyArr[keyArr.length - 1];
			}
		}
		else
		{
			smsKey = key;
		}
		String[] mes = message.split(CommonConstants.ALARM_SEPARATOR);
	    String smsMessage = CommonConstants.BUSINESS_ALARM + "："  + smsKey + "," + mes[CommonConstants.SMS_TAG];
	    String mailMessage = "key【"+key+"】" + mes[CommonConstants.MAIL_TAG];
	    String sendMessage = smsMessage + CommonConstants.ALARM_SEPARATOR+ CommonConstants.BUSINESS_ALARM + CommonConstants.ALARM_SEPARATOR + mailMessage;
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug(sendMessage);
		
		EventAlarmUtil.sendEventAlarmer(key, "", 5, 0, 1, sendMessage);
	}
	/**
	 * 调用统一日志报警接口传递报警信息
	 * @param key
	 * @param alarmTime
	 * @param value
	 */
	private void alarm(String key,long alarmTime,String value)
	{
		String alarmDate = DateFormatUtils.format(alarmTime,CommonConstants.DATE_FORMAT);
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("class[AlarmRuleParse]loghup alarm key["+key+"]date["+alarmDate+"]value["+value+"]");
		LoghupEventAlarmUtil.loghupSendAlarmer(key, alarmDate, value);
	}
	
	private List<String> dateParse(String date,String bKey)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.JSON_DATA_FORMAT);
		try
		{
			List<String> dateList = new ArrayList<String>();
			Date sourceDate = sdf.parse(date);
			
			dateList.add(DateFormatUtils.format(sourceDate,CommonConstants.HH_MM_FORMAT));
			dateList.add(DateFormatUtils.format(sourceDate,CommonConstants.DATE_FORMAT));			
			return dateList;
		}
		catch(Exception e)
		{
			LOGGER.error("class[RuleAnalysis]method[dateParse]key["+bKey+"]date["+date+"]date parse error!",e);
		}
		return null;
	}
	
	public long dateTimeParse(String date,String bKey)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.JSON_DATA_FORMAT);
		try
		{
			Date sourceDate = sdf.parse(date);
			return sourceDate.getTime();
		}
		catch(Exception e)
		{
			LOGGER.error("class[RuleAnalysis]method[dateTimeParse]key["+bKey+"]date["+date+"]date parse error!",e);
		}
		return 0l;
	}
}
