package com.jd.ump.bmp.common.alarm.register;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.loghub.manager.rpc.server.AlarmServer;
import com.jd.loghub.manager.rpc.server.AlarmServer_Service;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

public final class LoghupAlarmSoapObject 
{
	private final static Logger LOGGER = LoggerFactory.getLogger(LoghupAlarmSoapObject.class);
	private static LoghupAlarmSoapObject soapClient = new LoghupAlarmSoapObject();
	private static final Object lock = new Object();
//	private Client client = null;
//	private JaxWsDynamicClientFactory  clientFactory = null;
	private AlarmServer_Service service = null;
	private AlarmServer alarmServer = null;
	
	private LoghupAlarmSoapObject()
	{
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.BusinessDataHandle.LoghupAlarmSoapObject", false, true);
//			clientFactory = JaxWsDynamicClientFactory.newInstance();
//			client = clientFactory.createClient(CommonConstants.LOGHUP_ALARM_URL);
			service = new AlarmServer_Service();
			alarmServer = service.getAlarmServerImplPort();
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[LoghupAlarmSoapObject]init fail!wsURL[]",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	public static AlarmServer getInstance()
	{
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("class[LoghupAlarmSoapObject]read url is method is[]========================");
		
		if(soapClient.service == null)
		{
			synchronized (lock)
			{
				if(soapClient.service == null)
				{
					if(LOGGER.isDebugEnabled())
						LOGGER.debug("class[LoghupAlarmSoapObject] init client!key loghupAlarm.lifang.test");
					
					soapClient.service = new AlarmServer_Service(); 
					soapClient.alarmServer = soapClient.service.getAlarmServerImplPort();
					LOGGER.warn("class[LoghupAlarmSoapObject]init soap client success!");
				}
			}
		}
		return soapClient.alarmServer;
	}
}
