package com.jd.ump.bmp.common;


public class CommonConstants 
{
	public static final String BKEY = "bKey";
	public static final String BTIME = "bTime";
	public static final String BVALUE = "bValue";
	public static final String BCOUNT = "bCount";
	public static final String BHOST = "bHost";
	/**
	 * 数据来源1-监控系统主动获取
	 */
	public static final int DATA_SOURCE_ACTIVE = 1;
	/**
	 * 数据来源2-监控系统被动获取
	 */
	public static final int DATA_SOURCE_ACTIVED = 2;
	/**
	 * 数据来源3-日志方式
	 */
	public static final int DATA_SOURCE_LOG = 3;
	
	
	/**
	 * 字段类型1-数字
	 */
	public static final int FIELD_TYPE_NUMBER = 1;
	/**
	 * 字段类型2-字符串
	 */
	public static final int FIELD_TYPE_STRING = 3;
	/**
	 * 字段类型3-日期
	 */
	public static final int FIELD_TYPE_DATE = 2;
	
	
	/**
	 * 业务数据解析方式-值累加
	 */
	public static final int FACILITY_DATA_ANALYSIS_WAY_VALUE_ACCUMULATION = 1;
	/**
	 * 业务数据解析方式-次数累加
	 */
	public static final int FACILITY_DATA_ANALYSIS_WAY_TIMES_ACCUMULATION = 2;
	/**
	 * 业务数据解析方式-原始数据
	 */
	public static final int FACILITY_DATA_ANALYSIS_WAY_SOURCEDATA = 3;
	
	
	/**
	 * 报警预警分析数据的合并方式-取平均值
	 */
	public static final int ANALYSIS_DATA_MERGE_WAY_AVERGE = 1;
	/**
	 * 报警预警分析数据的合并方式-求和
	 */
	public static final int ANALYSIS_DATA_MERGE_WAY_SUM = 2;
	
	
	
	/**
	 * 报警预警标识-预警
	 */
	public static final int WARN_SIGN = 1;
	public static final String WARN_SIGN_STR = "warn";
	/**
	 * 报警预警标识-报警
	 */
	public static final int ALARM_SIGN = 2;
	public static final String ALARM_SIGN_STR = "alarm";
	
	
	/**
	 * 业务值 1-环比增幅
	 */
	public static final int FACILITY_VALUE_AMPLIFICATION_TYPE = 1;
	/**
	 * 业务值 1-同比增幅-**************author：yfliliang
	 */
	public static final int FACILITY_VALUE_SAMETERMCOMPARE_AMPLIFICATION_TYPE = 4;
	/**
	 * 同比增幅周期1-天**************author：yfliliang
	 */
	public static final int SAMETERMCOMPARE_AMPLIFICATION_TYPE_DAY = 1;
	/**
	 * 同比增幅周期2-周**************author：yfliliang
	 */
	public static final int SAMETERMCOMPARE_AMPLIFICATION_TYPE_WEEK = 2;
	/**
	 * 业务值和参照值类型 2-字段值
	 */
	public static final int FACILITY_REFERENCE_VALUE_FIELD_TYPE = 2;
	/**
	 * 业务值和参照值类型3-表达式
	 */
	public static final int FACILITY_REFERENCE_VALUE_EXPRESSION_TYPE = 3;
	
	/**
	 * 环比参照值类型1-字段值
	 */
	public static final int RING_COMPARE_REFERENCE_VALUE_FIELD_TYPE = 1;
	
	/**
	 * 环比参照值类型2-表达式
	 */
	public static final int RING_COMPARE_REFERENCE_VALUE_EXPRESSION_TYPE = 2;
	
	/**
	 * 参照值类型1-固定值
	 */
	public static final int REFERENCE_VALUE_FIXED_TYPE = 1;
	/**
	 * 参照值类型4-环比
	 */
	public static final int REFERENCE_VALUE_RINGCOMPARE_TYPE = 4;
	/**
	 * 参照值类型5-同比
	 */
	public static final int REFERENCE_VALUE_SAMETERMCOMPARE = 5;
	/**
	 * 同比时数据的同比周期1-天
	 */
	public static final int SAMETERMCOMPARE_TYPE_DAY = 1;
	/**
	 * 同比时数据的同比周期2-周
	 */
	public static final int SAMETERMCOMPARE_TYPE_WEEK = 2;
	/**
	 * 同比时数据的获取方式1-直接取值
	 */
	public static final int SAMETERMCOMPARE_FETCH_WAY_VALUE = 1;
	/**
	 * 同比时数据的获取方式2-历史平均值
	 */
	public static final int SAMETERMCOMPARE_FETCH_WAY_HISAVGVALUE = 2;
	
	/**
	 * 比较标识1-大于
	 */
	public static final int COMPARE_SIGN_GREATERTHAN = 1;
	/**
	 * 比较标识2-小于
	 */
	public static final int COMPARE_SIGN_LESSTHAN = 2;
	/**
	 * 比较标识3-大于等于
	 */
	public static final int COMPARE_SIGN_EQUALGT = 3;
	/**
	 * 比较标识4-小于等于
	 */
	public static final int COMPARE_SIGN_EQUALLT = 4;
	
	
	
	/**
	 * 连接标识1-and
	 */
	public static final int LINK_SIGN_AND = 1;
	/**
	 * 连接标识2-or
	 */
	public static final int LINK_SIGN_OR = 2;
	
	/**
	 * 对每个监控key在redis中存储Hbase中收集的最后一条记录的key（主要针对主动获取和原始数据）
	 */
	public static final String LAST_RESULT_KEY_HBASE = "last_result_key_coll";
	
	
	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	public static final String JSON_DATA_FORMAT = "yyyyMMddHHmmssSSS";
	public static final String DATE_KEY_FORMAT = "yyyyMMddHHmm";
	public final static String HHMM_FORMAT = "HHmm";
	public final static String HH_MM_FORMAT = "HH:mm";
	
	/**
	 * 缓存监控点key的报警预警次数
	 */
	public static final String ALARM_WARN_TIMES_KEY = "facilityKey.alarmWarn.times";
	
	/**
	 * 报警分析方式2-直接分析
	 */
	public static final int ALARM_ANALYSIS_WAY_DIRECT = 2;
	/**
	 * 报警预警分析方式1-按频率分析
	 */
	public static final int ALARM_ANALYSIS_WAY_RATE = 1;
	
	
	/**
	 * webservice类型：
	 * 1：SOAP  , 2：SF
	 */
	public static final int WEBSERVICE_SOAP = 1;
	public static final int WEBSERVICE_REST = 2;
	
	
	/**
	 * 自报警类别
	 */
	public static final int ALARM_TYPE = 5; 
	
	/**
	 * 报警级别0(error),1(warning)
	 */
	public static final int ALARM_LEVEL = 1;
	
	/**
	 * 自动注册监控点标识1-统一日志项目
	 */
	public static final int LOGHUPALERT_SIGN = 1;
	/**
	 * 统一日志报警接口的URL
	 */
//	public static final String LOGHUP_ALARM_URL = AppProperties.getProperty("loghupAlarmUrl", "");
	/**
	 * 统一日志报警接口方法
	 */
//	public static final String LOGHUP_ALARM_INTERFACE_METHOD = AppProperties.getProperty("loghupAlarmMethod", "");
	/**
	 * 邮件报警消息时时间tag = 1
	 */
	public static final int MAIL_TAG = 1 ;
	/**
	 * 短信报警消息时时间tag = 0
	 */
	public static final int SMS_TAG = 0 ;
	/**
	 * 业务监控报警BUSINESS_ALARM:"业务监控报警"
	 */
	public static final String BUSINESS_ALARM = "业务监控报警" ;
	/**
	 * 报警消息分割符ALARM_SEPARATOR:"#UMP#"
	 */
	public static final String ALARM_SEPARATOR = "#UMP#" ;
	
}
