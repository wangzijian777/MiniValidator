package com.jd.ump.bmp.common.alarm;

import java.math.BigDecimal;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.CommonConstants;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class RingCompareValueFetch implements AlarmCompareValueFetch
{
	private final static Logger LOGGER = LoggerFactory.getLogger(RingCompareValueFetch.class);
	private static final int RC_TYPE = 0;
	
	@Resource(name="lastFacValueFetch")
	private LastFacValueFetch lastFacValueFetch;
	
	@Resource(name="expressionValueFetch")
	private AlarmCompareValueFetch expressionValueFetch;
	
	
	@Override
	public BigDecimal fetchValue(Map<String, String> map, String value,Integer ... param) 
	{
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("ump.bmp.AlarmRuleRingCompareValueFetch.fetchValue", false, true);
			
			if(param[RC_TYPE] != null && param[RC_TYPE] == CommonConstants.RING_COMPARE_REFERENCE_VALUE_FIELD_TYPE)
			{
				return lastFacValueFetch.fetchValue(map, value);
			}
			else if(param[RC_TYPE] != null && param[RC_TYPE] == CommonConstants.RING_COMPARE_REFERENCE_VALUE_EXPRESSION_TYPE)
			{
				Map<String,String> lastValueMap = lastFacValueFetch.fetchMapValue(map, value);
				return expressionValueFetch.fetchValue(lastValueMap, value);
			}
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error("class[RingCompareValueFetch]method[fetchValue]ring compare value fetch error!",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
		return null;
	}
}
