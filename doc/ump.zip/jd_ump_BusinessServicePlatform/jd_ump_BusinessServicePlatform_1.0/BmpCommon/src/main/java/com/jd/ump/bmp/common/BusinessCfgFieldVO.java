package com.jd.ump.bmp.common;

import java.util.Date;

public class BusinessCfgFieldVO 
{
	/**
	 * 业务字段配置表id
	 */
	private int id;
	/**
	 * 业务字段名（英文缩写）
	 */
	private String fieldName;
	/**
	 * 业务字段描述
	 */
	private String fieldDescription;
	/**
	 * 业务字段序号
	 */
	private int fieldOrder;
	/**
	 * 监控点key
	 */
	private String businessKey;
	/**
	 * 业务字段类型1-数字，3-字符串，2-日期
	 */
	private int businessFiledType;
	/**
	 * 创建人
	 */
	private String createdBy;
	/**
	 * 更新人
	 */
	private String updatedBy;
	/**
	 * 创建时间
	 */
	private Date createdDate;
	/**
	 * 更新时间
	 */
	private Date updatedDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getFieldDescription() {
		return fieldDescription;
	}
	public void setFieldDescription(String fieldDescription) {
		this.fieldDescription = fieldDescription;
	}
	public int getFieldOrder() {
		return fieldOrder;
	}
	public void setFieldOrder(int fieldOrder) {
		this.fieldOrder = fieldOrder;
	}
	public String getBusinessKey() {
		return businessKey;
	}
	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}
	public int getBusinessFiledType() {
		return businessFiledType;
	}
	public void setBusinessFiledType(int businessFiledType) {
		this.businessFiledType = businessFiledType;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
}
