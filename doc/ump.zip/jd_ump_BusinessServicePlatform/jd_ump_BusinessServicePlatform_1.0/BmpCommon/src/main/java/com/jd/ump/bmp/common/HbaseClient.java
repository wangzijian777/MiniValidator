package com.jd.ump.bmp.common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HConstants;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.HTablePool;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.io.hfile.Compression.Algorithm;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.ump.bmp.common.domain.RowData;
import com.jd.ump.common.AppProperties;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class HbaseClient {
	private final static Logger LOGGER = LoggerFactory.getLogger(HbaseClient.class);

	private static Configuration config = null;
	private static HBaseAdmin admin = null;
	private static HTablePool pool = null;
//	private static Long FLUSH_CACHE_SIZE = null;
	private static String UMP_BMP_TABLE_NAME = null;
	private static String[] FAMILIES = null;
	private final static String HBASE_CONN_TIMEOUT = "20000";
	private final static String SourceTime = "20";
	private final static String Proint = ".";

	@PostConstruct
	public void init () {
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.init", false, true);
			if (null == config) {
				config = HBaseConfiguration.create();
				config.set(HConstants.HBASE_RPC_TIMEOUT_KEY, HBASE_CONN_TIMEOUT);
				config.set("hbase.zookeeper.quorum", AppProperties.getProperty("hbase.zookeeper.servers"));
				LOGGER.debug("zookeeper_servers=" + AppProperties.getProperty("hbase.zookeeper.servers"));
				config.set("hbase.zookeeper.property.clientPort",
						AppProperties.getProperty("hbase.zookeeper.client.port"));
			}
			if (null == admin) {
				admin = new HBaseAdmin(config);
			}
			UMP_BMP_TABLE_NAME = AppProperties.getProperty("hbase.table.name");
			FAMILIES =new String[] { AppProperties.getProperty("hbase.families.name") };
			pool = new HTablePool(config, Integer.parseInt(AppProperties.getProperty("hbase.pool.size")));
//			FLUSH_CACHE_SIZE = Long.parseLong(AppProperties.getProperty("hbase.cache.size")) * 1024 * 1024L;
//			this.createTable(UMP_BMP_TABLE_NAME, FAMILIES);
		} catch (Exception e) {
			LOGGER.error("Init Hbase Occur Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new RuntimeException("Init Hbase Occur Exception", e);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
	}

	/**
	 * 创建表
	 * 
	 * @param tableName
	 *            表名
	 * @param families
	 *            族名集合
	 */
	public void createTable(String tableName, String[] families) {
		try {
			if (!admin.tableExists(tableName)) {
				HTableDescriptor htd = new HTableDescriptor(tableName);
				
				for (String family : families) {
					HColumnDescriptor hcd = new HColumnDescriptor(family);
					int blockSize = hcd.getBlocksize();
					LOGGER.info(family + "block size: " + blockSize);
					// hcd.setInMemory(true);//对小表而言，可以考虑将值放在内存中
					// hcd.setBloomFilterType(StoreFile.BloomType.ROWCOL);
					// hcd.setTimeToLive(10);
					hcd.setMaxVersions(3);
					hcd.setCompressionType(Algorithm.GZ);
					hcd.setCompactionCompressionType(Algorithm.GZ);
					htd.addFamily(hcd);
				}

				htd.setMaxFileSize(512 * 1024 * 1024L);
				htd.setMemStoreFlushSize(128 * 1024 * 1024L);
				// table的一个region的最大值，如1024M，当达到这个值时，会进行region会split
				long maxFileSize = htd.getMaxFileSize();
				// table先想缓存中写数据，如缓存大小256M，当达到这个值时，会将cache中的数据flush到HDFS上
				long memStoreFlushSize = htd.getMemStoreFlushSize();

				LOGGER.info("region最大值：" + maxFileSize);
				LOGGER.info("服务端缓存最大值：" + memStoreFlushSize);

				admin.createTable(htd);
				LOGGER.info("Create hbase table ok.");
			}
		} catch (Exception e) {
			LOGGER.error("Create hbase table fail", e);
			throw new RuntimeException("Create hbase table fail", e);
		}
	}

	/**
	 * 
	 * @param tableName
	 * @return
	 */
	public HTable getTable(String tableName) {
		if(LOGGER.isDebugEnabled()) LOGGER.debug("Get hbase table " + tableName);
		
		return (HTable) pool.getTable(tableName);
	}


	private void deleteDataByRowKey(HTable table, String rowKey) throws IOException {
		Delete d = new Delete(rowKey.getBytes());
		table.delete(d);		
	}
	
	/**
	 * 删除指定行数据
	 * 
	 * @param table
	 * @param rowKey
	 * @throws IOException 
	 */
	public void deleteDataByRowKey(String rowKey) throws IOException{
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.deleteDataByRowKey", false, true);
			deleteDataByRowKey(getTable(UMP_BMP_TABLE_NAME), rowKey);
		} catch (IOException e) {
			LOGGER.error("deleteDataByRowKey Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new IOException("HbaseClient.deleteDataByRowKey",e);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
		
	}
	
	/**
	 * 删除指定key前缀的所有数据
	 * @param key
	 * @return
	 * @throws IOException
	 */
	public int deleteMultiDataByKey(String key) throws IOException {
		CallerInfo callerInfo = null;
		HTable table = getTable(UMP_BMP_TABLE_NAME);
		String tKey = key + Proint + SourceTime;
		PrefixFilter filter = new PrefixFilter(tKey.getBytes());
		int count = 0;
		Scan scan = new Scan();
		scan.setFilter(filter);
		ResultScanner rs = null;
		rs = table.getScanner(scan);
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.deleteMultiDataByKey", false, true);
			for (Result r : rs) {
				Delete delete = new Delete(r.getRow());
				table.delete(delete);
				count++;
			}
		} catch (IOException e) {
			LOGGER.error("deleteMultiDataByKey Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new IOException("HbaseClient.deleteMultiDataByKey",e);
		} finally {
			rs.close();
			Profiler.registerInfoEnd(callerInfo);
		}
		return count;
	}
	
	/**
	 * 批量flush数据到hbase
	 * 
	 * @param tableName
	 *            表名
	 * @param hbasePutList
	 *            待写入的put集合
	 * @throws IOException
	 */
	public void flush(HTable table, List<Put> hbasePutList) throws IOException {
		table.setAutoFlush(false);
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.flush(HTable, List<Put>)", false, true);
			table.setWriteBufferSize(Long.parseLong(AppProperties.getProperty("hbase.cache.size")) * 1024 * 1024L);
			table.put(hbasePutList);
		} catch (IOException e) {
			LOGGER.error("flush(HTable, List<Put>) Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new IOException("HbaseClient.flush(HTable, List<Put>)",e);
		} finally {
			table.flushCommits();
			table.close();
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	public void flush(Map<String, String> data, String key) throws IOException {
		Put hbasePut= map2Put(data, key);
		flush(getTable(UMP_BMP_TABLE_NAME), hbasePut);
	}

	/**
	 * 批量插入多行数据(不建议使用)
	 */
	public void flush(List<RowData> data) throws IOException {
		List<Put> list = new ArrayList<Put>();
		for (RowData rd : data) {
			list.add(map2Put(rd.getData(), rd.getRowKey()));
		}
		flush(getTable(UMP_BMP_TABLE_NAME), list);
	}


	private void flush(HTable table, Put put) throws IOException {

		table.setAutoFlush(false);
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.flush(HTable, Put)", false, true);
			table.setWriteBufferSize(Long.parseLong(AppProperties.getProperty("hbase.cache.size")) * 1024 * 1024L);
			table.put(put);
		} catch (IOException e) {
			LOGGER.error("flush(HTable, Put) Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new IOException("HbaseClient.flush(HTable, Put)",e);
		} finally {
			table.flushCommits();
			table.close();
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	/**
	 * flush数据到hbase
	 * 
	 * @param tableName
	 *            表名
	 * @param hbasePutList
	 *            Put
	 * @throws IOException 
	 */
	public void flush(Put put) throws IOException{
		flush(getTable(UMP_BMP_TABLE_NAME), put);
	}

	/**
	 * 按row key查询所有family的所有最新版本的值
	 * 
	 * @param table
	 * @param row
	 * @return
	 * @throws IOException 
	 */
	public Map<String, String> queryRow(String row) throws IOException {
		CallerInfo callerInfo = null;
		Map<String, String> resultMap = new HashMap<String,String>();
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.queryRow", false, true);
			HTable table = this.getTable(UMP_BMP_TABLE_NAME);
			Get get = null;
			get = new Get(Bytes.toBytes(row)).setMaxVersions(); // 只取最新版本的值
			resultMap = convertRawResult(table.get(get));
		} catch (IOException e) {
			LOGGER.error("queryRow Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new IOException("HbaseClient.queryRow",e);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
		return resultMap;
	}
	
	public boolean checkEmptyByRowKey(String rowKey) throws IOException {
		HTable table = this.getTable(UMP_BMP_TABLE_NAME);
		Get get = new Get(Bytes.toBytes(rowKey));
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.checkEmptyByRowKey", false, true);
			if (table.get(get).isEmpty()) {
				return false;
			}
		} catch (IOException e) {
			LOGGER.error("queryRow Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new IOException("HbaseClient.queryRow",e);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
		return true;
	}

	public List<Map<String, String>> scanByRow(String startRow, String endRow) throws IOException {
		HTable table = this.getTable(UMP_BMP_TABLE_NAME);
		CallerInfo callerInfo = null;
		ResultScanner result = null;
		Scan scan = new Scan();
		scan.setStartRow(startRow.getBytes());		
		byte[] end = endRow.getBytes();
		end[end.length - 1] = (byte) (end[end.length - 1] + 1);
		scan.setStopRow(end);
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.scanByRow", false, true);
			result = table.getScanner(scan);
		} catch (IOException e) {
			LOGGER.error("scanByRow Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new IOException("HbaseClient.scanByRow",e);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
		return convertyRawScanner(result);
	}
	
	public List<RowData> scanRowByTimeWithRowkey(String startRow, String endRow) throws IOException {
		HTable table = this.getTable(UMP_BMP_TABLE_NAME);
		CallerInfo callerInfo = null;
		ResultScanner result = null;
		Scan scan = new Scan();
		scan.setStartRow(startRow.getBytes());		
		byte[] end = endRow.getBytes();
		end[end.length - 1] = (byte) (end[end.length - 1] + 1);
		scan.setStopRow(end);
		
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.HbaseClient.scanRowByTimeWithRowkey", false, true);
			result = table.getScanner(scan);
		} catch (IOException e) {
			LOGGER.error("scanRowByTimeWithRowkey Exception: ", e);
			Profiler.functionError(callerInfo);
			throw new IOException("HbaseClient.scanRowByTimeWithRowkey",e);
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
		return convertyRawScannerWithRowkey(result);
	}
	
	/**
	 * 转换单行Result为map
	 * 
	 * @param result
	 */
	private Map<String, String> convertRawResult(Result result) {
		
		if (null == result) {			
			return null;
		}
		
		Map<String, String> resultMap = new HashMap<String, String>();
		for (KeyValue kv : result.raw()) {
			resultMap.put(new String(kv.getQualifier()), new String(kv.getValue()));			
		}
		
		return resultMap;
	}

	private List<Map<String, String>> convertyRawScanner(ResultScanner result) {
		if (null == result) {			
			return null;
		}
		
		List<Map<String, String>> resultList = new ArrayList<Map<String,String>>();		
		Map<String, String> rowMap = null;
		
		for (Result r : result) {
			rowMap = new HashMap<String, String>();
			for (KeyValue kv : r.raw()) {
				rowMap.put(new String(kv.getQualifier()), new String(kv.getValue()));
			}
			resultList.add(rowMap);
		}
		result.close();
		return resultList;
	}
	
	private List<RowData> convertyRawScannerWithRowkey(ResultScanner result) {
		if (null == result) {			
			return null;
		}
		
		List<RowData> resultList = new ArrayList<RowData>();
		Map<String, String> rowMap = null;
		for (Result r : result) {
			RowData rd = new RowData();
			rowMap = new HashMap<String, String>();
			rd.setRowKey(new String(r.getRow()));
			for (KeyValue kv : r.raw()) {
				rowMap.put(new String(kv.getQualifier()), new String(kv.getValue()));
				rd.setData(rowMap);
			}
			resultList.add(rd);
		}
		result.close();
		return resultList;
	}
	
	private Put map2Put(Map<String, String> data, String key) {
		if (data == null || (key == null && "".equals(key)))
			return null;
		Put put = new Put(Bytes.toBytes(key));
		for(Entry<String,String> entry:data.entrySet()) {
			put.add(FAMILIES[0].getBytes(), Bytes.toBytes(entry.getKey().toString()), Bytes.toBytes(entry.getValue().toString()));
		}
		return put;
	}
}
