package com.jd.ump.bmp.bsc;


import com.jd.ump.common.IModuleCreator;
import com.jd.ump.common.Module;

public class ServiceCenterModuleCreator implements IModuleCreator {
	@Override
	public Module create() {
		Module module = new Module();
		
		module.setName("BusinessServiceCenter");
		module.setVersion("2013012501");
		
		return module;
	}
}