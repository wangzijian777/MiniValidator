package com.jd.ump.bmp.bsc;


import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.redis.support.RedisCommands;
import com.jd.ump.bmp.common.BmpCommonModuleCreator;
import com.jd.ump.bmp.service.common.CommonServiceModuleCreator;
import com.jd.ump.bmp.task.awac.AlarmAndWarnModuleCreator;
import com.jd.ump.bmp.task.biac.common.BusinessInterfaceAccessModuleCreator;
import com.jd.ump.bmp.task.hddc.HbaseDataDeleteCenterModuleCreator;
import com.jd.ump.bmp.task.stdcc.common.SameTermDataCollectionModuleCreator;
import com.jd.ump.common.AppInfo;
import com.jd.ump.common.AppVersionUtil;
import com.jd.ump.common.CommModuleCreator;
import com.jd.ump.common.Module;
import com.jd.ump.common.WebServiceModuleCreator;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * 服务中心系统心跳,版本注册
 * @author Upton
 *
 */
@Component
public class ServiceCenterHeartBeat {
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceCenterHeartBeat.class);
	
	@Resource(name = "redisClient")
	private RedisCommands redisClient;
	
	@PostConstruct
	public void init(){
		//初始化系统心跳
		Profiler.InitHeartBeats("ump.bmp.BusinessServiceCenter");
		
		//初始化模块版本
		initModuleVersion();
		
	}
	
	/**
	 * 初始化模块版本
	 */
	private void initModuleVersion(){
		
		AppInfo app = new AppInfo();
		
		app.setName("BusinessServiceCenter");
		app.setHost(AppVersionUtil.getHostName());
		app.setStartTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		
		// 公共模块 
		app.addModule(new CommModuleCreator().create());
		
		//主动访问接口模块
		app.addModule(new BusinessInterfaceAccessModuleCreator().create());
		
		//报警分析中心
		app.addModule(new AlarmAndWarnModuleCreator().create());
		
		//同期数据分析
		app.addModule(new SameTermDataCollectionModuleCreator().create());
		
		//对外发布接口
		app.addModule(new WebServiceModuleCreator().create());
		
		//BMP检验数据、数据存储
		app.addModule(new BmpCommonModuleCreator().create());
		
		
		// 服务中心模块
		app.addModule(new ServiceCenterModuleCreator().create());
		
		//删除hbase数据模块
		app.addModule(new HbaseDataDeleteCenterModuleCreator().create());
		
		//CommonService
		app.addModule(new CommonServiceModuleCreator().create());
		regApp(app);
		
	}
	
	/**
	 * 在redis中缓存各个模块的版本号
	 * @param app
	 */
	private void regApp(AppInfo app){
		String appKey = "APP_INFO_" + app.getName();
				
		for(Module module : app.getModules()){
			redisClient.hset(appKey, app.getHost() + "-->" + module.getName(), module.getVersion());
		}
		
		redisClient.hset(appKey, app.getHost() + "-->#StartTime#", app.getStartTime());
		
		LOGGER.info("Register app info ok. ");
	}
	
	
	
}