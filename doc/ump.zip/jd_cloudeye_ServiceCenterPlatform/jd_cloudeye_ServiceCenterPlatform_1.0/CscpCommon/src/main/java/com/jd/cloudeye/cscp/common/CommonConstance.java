package com.jd.cloudeye.cscp.common;

public class CommonConstance 
{
	/**
	 *  module define
	 */
	public static final String MODULE_DAC = "DataAnalysisCenter";
	public static final String KEY_SPLIT = "#";
	/**
	 * 计算最大最小平均值的数组下标
	 */
	public final static int MAX = 0;
	public final static int MIN = 1;
	public final static int AVG = 2;
	public final static int SUM = 3;
	
	/**
	 * 日期格式yyyyMMddHHmm
	 */
	public final static String DATA_FORMAT_YYYYMMDDHHMM = "yyyyMMddHHmm";
	public final static String DATA_FORMAT_YYYYMMDDHHMMSS = "yyyy-MM-dd HH:mm:ss";
	public final static String SERVICE_EC2 = "EC2";
	public final static String SERVICE_ELB = "ELB";
	public final static String KNULL = "KNULL";
	public final static String METRICS_AS = "AS_";
	
	/**
	 * '#JDCE#' 任务内容分隔符常量
	 */
	public static final String TASK_CONTENT_SEPARATOR = "#JDCE#";
	
	/**
	 * '2'邮件 常量
	 */
	public static final String EML_FLAG = "2";
	
	/**
	 * jce_ 表前缀
	 */
	public static final String TABLE_PREFIX = "jce_";
	
	/**
	 * _dataresult_1m 表后缀
	 */
	public static final String TABLE_POSTFIX = "_dataresult_1m";
	
	 /**
     * 
     * @param strs 要查找的字符串数组
     * @param s 要查找的字符或字符串
     * @return
     * @author cdxuxiaolong
     * @date 2013-12-10
     */
    public static boolean isHave(String[] strs, String s) {
        for (int i = 0; i < strs.length; i++) {
            if (strs[i].indexOf(s) != -1) {
                return true;
            }
        }
        return false;
    }
}
