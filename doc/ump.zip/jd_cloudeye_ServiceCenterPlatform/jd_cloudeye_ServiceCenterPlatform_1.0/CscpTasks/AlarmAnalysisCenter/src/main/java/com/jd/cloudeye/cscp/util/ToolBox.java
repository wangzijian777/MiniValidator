package com.jd.cloudeye.cscp.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.jd.cloudeye.common.EventAlarmUtil;
import com.jd.cloudeye.common.util.AlarmNoticeMoreParam;
import com.jd.cloudeye.common.util.AlarmNoticeOneParam;
/**
 * 工具类
 * @author cdpangyang
 *
 */
public class ToolBox {
	
	/**
	 * 发送报警信息
	 * @param task
	 * @param alarmContent
	 */
	public static void sendAlarm(List<AlarmNoticeOneParam> alarmContent){
		AlarmNoticeMoreParam anmp = new AlarmNoticeMoreParam();
		anmp.setAlarmNoticeOneParamList(alarmContent);
		EventAlarmUtil.sendEventAlarmer(anmp);
	}
	
	/**
	 * 时间处理
	 * @param time
	 */
	public static Date dateUtil(long time){
		return new Date(time);
	}
	
	/**
	 * 时间处理-转换为String
	 * @param time
	 */
	public static String dateUtil4String(long time){
		SimpleDateFormat sdf = new SimpleDateFormat(AnalysisConsts.TIME_PATTERN);
		return sdf.format(new Date(time));
	}
}
