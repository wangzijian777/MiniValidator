package com.jd.cloudeye.cscp.util;

/**
 * 常量类
 * @author cdpangyang
 *
 */
public final class AnalysisConsts {
	/**
	 * 'ALARM_ANALYSIS' 报警分析 redis key 组成部分
	 */
	public static final String ALARM_KEYFIX = "ALARM_ANALYSIS";
	
	/**
	 * '|' redis value 分隔符常量,带转义符\\
	 */
	public static final String VALUE_SEPARATOR = "\\|";
	
	/**
	 * '|' redis value 分隔符常量,不带转义符
	 */
	public static final String JUST_VALUE_SEPARATOR = "|";
	
	/**
	 * 常量 0
	 */
	public static final int VALUE_ZERO = 0;
	
	/**
	 * module name
	 */
	public static final String MODULE_NAME = "AlarmAnalysisCenter@JDCE";
	
	/**
	 * email 主题
	 */
	public static final String EMALSUBJECT = "京东云监控报警" ;
	
	/**
	 * 联系方式分割符 ，
	 */
	public static final String ADDRESS_SEPARATOR = ",";
	
	/**
	 * 3 比较符 =
	 */
	public static final int COMPARESIGN_EQUAL = 3;
	
	/**
	 * 1 比较符 >
	 */
	public static final int COMPARESIGN_GREATER = 1;
	
	/**
	 * 2 比较符 <
	 */
	public static final int COMPARESIGN_SMALLER = 2;
	
	/**
	 * yyyy-MM-dd HH:mm:ss 时间格式
	 */
	public static final String TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";
	
	
	/**
	 * http://console.jcloud.com  云监控地址
	 */
	public static final String JMS_URL = "http://console.jcloud.com";
}
