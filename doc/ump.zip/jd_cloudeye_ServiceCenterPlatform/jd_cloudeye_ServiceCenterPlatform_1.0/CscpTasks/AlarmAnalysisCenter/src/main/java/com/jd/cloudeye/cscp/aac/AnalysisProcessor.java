package com.jd.cloudeye.cscp.aac;

import com.jd.cloudeye.maas.center.MetricsAlarmAnalysisInfo;

/**
 * 分析处理器
 * @author cdpangyang
 *
 */
public interface AnalysisProcessor {

	void process(MetricsAlarmAnalysisInfo task);
}
