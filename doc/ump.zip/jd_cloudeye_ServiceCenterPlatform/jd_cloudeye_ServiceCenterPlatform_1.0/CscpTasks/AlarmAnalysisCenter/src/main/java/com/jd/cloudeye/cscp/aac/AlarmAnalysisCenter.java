package com.jd.cloudeye.cscp.aac;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.util.AnalysisConsts;
import com.jd.cloudeye.maas.center.MetricsAlarmAnalysisInfo;

/**
 * 报警分析中心--需要加注解注入listenner的对象
 * @author cdpangyang
 *
 */
@Component
public class AlarmAnalysisCenter implements MessageListener{

	private final static Logger LOGGER = LoggerFactory.getLogger(AlarmAnalysisCenter.class);
	private final static String CLASSNAME = "AlarmAnalysisCenter";
	@Autowired
	AnalysisProcessor alarmAnalysisProcessor ;
	
	@Override
	public void onMessage(Message msg) {
		try{
			if(msg instanceof ObjectMessage){
				ObjectMessage objMsg = (ObjectMessage) msg;
				MetricsAlarmAnalysisInfo task = (MetricsAlarmAnalysisInfo) objMsg.getObject();
				if(task != null){
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("=======task key content ======  usinId ： " + task.getUsinId()
								+ " userId : " + task.getUserId() + " serviceCode : " + task.getServiceCode()
								+ " instanceId : " + task.getInstanceId() + " metricsCode : " + task.getMetricsCode()
								+ " tasktime : " + task.getTaskTime() + " AlarmRuleId : " + task.getAlarmRuleId());
					}
					
					alarmAnalysisProcessor.process(task);
				}
			}else{
				if(LOGGER.isWarnEnabled()){
					LOGGER.warn(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "onMessage") + " :msg type err!");
				}
			}
		}catch (JMSException e) {
			if(LOGGER.isErrorEnabled()){
				LOGGER.error(CommonLogUtil.makeErrorHead(AnalysisConsts.MODULE_NAME, CLASSNAME ) + "Task err ！" + e);
			}
		}
	}

}
