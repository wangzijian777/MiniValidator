package com.jd.cloudeye.cscp.util;

/**
 * email 内容
 * @author cdpangyang
 *
 */
public class EmailContent {
	private String title;//标题
	private String serviceName;//服务名
	private String instanceName;//实例名称
	private String metricName;//指标名
	private String alarmText;//报警内容文本
	private String alarmTime;//报警时间
	private String urlLink;//url连接地址
	
	private String remark;//备注信息

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public EmailContent(){
		
	}
	
	/** 
	 * @param title //标题
	 * @param serviceName //服务名
	 * @param instanceName //实例名称
	 * @param metricName //指标名
	 * @param alarmText //报警内容文本
	 * @param alarmTime //报警时间
	 * @param urlLink //url连接地址
	 */
	public EmailContent(String title, String serviceName, String instanceName,
			String metricName, String alarmText, String alarmTime, String urlLink) {
		this.title = title;
		this.serviceName = serviceName;
		this.instanceName = instanceName;
		this.metricName = metricName;
		this.alarmText = alarmText;
		this.alarmTime = alarmTime;
		this.urlLink = urlLink;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getInstanceName() {
		return instanceName;
	}
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}
	public String getMetricName() {
		return metricName;
	}
	public void setMetricName(String metricName) {
		this.metricName = metricName;
	}
	public String getAlarmText() {
		return alarmText;
	}
	public void setAlarmText(String alarmText) {
		this.alarmText = alarmText;
	}
	public String getAlarmTime() {
		return alarmTime;
	}
	public void setAlarmTime(String alarmTime) {
		this.alarmTime = alarmTime;
	}
	public String getUrlLink() {
		return urlLink;
	}
	public void setUrlLink(String urlLink) {
		this.urlLink = urlLink;
	}
	
	/**
	 * 将对象to成字符串
	 */
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer("<table style=\"border:1px solid #35A7FE\" width=\"566\">");
		sb.append(" <tr style=\"background-color:#35A7FE;color:#fff;font-weight:bold;font-size:20px;height:38px;\">")
			.append(" <td colspan=\"2\">").append(this.title).append("</td></tr>")
			.append(" <tr style=\"background-color:#fff;height:30px;\">")
			.append(" <td style=\"border-bottom:1px dotted #B0DEFF\" width=\"88\">服务名称 : </td><td style=\"border-bottom:1px dotted #B0DEFF\">")
			.append(this.serviceName).append("</td> </tr>");
			if(this.instanceName != null)
			{
				sb.append(" <tr style=\"background-color:#fff;height:30px;\"> ")
				.append(" <td style=\"border-bottom:1px dotted #B0DEFF\">实例名称 : </td><td style=\"border-bottom:1px dotted #B0DEFF\">")
				.append(this.instanceName).append("</td> </tr>");
			}
			sb.append(" <tr style=\"background-color:#fff;height:30px;\"> ")
			.append(" <td style=\"border-bottom:1px dotted #B0DEFF\">指标名称 : </td><td style=\"border-bottom:1px dotted #B0DEFF\">")
			.append(this.metricName).append("</td></tr>")
			.append(" <tr style=\"background-color:#fff;height:30px;\"> ")
			.append(" <td style=\"border-bottom:1px dotted #B0DEFF\">报警内容 : </td><td style=\"color:red;border-bottom:1px dotted #B0DEFF\">")
			.append(this.alarmText).append("</td></tr> ")
			.append(" <tr style=\"background-color:#fff;height:30px;\">")
			.append("<td style=\"border-bottom:1px dotted #B0DEFF\">报警时间 : </td><td style=\"color:red;border-bottom:1px dotted #B0DEFF\"> ")
			.append(this.alarmTime).append("</td> </tr>")
			.append(" <tr style=\"background-color:#fff;height:30px;\"><td>备注信息 : </td><td> ").append(this.remark).append("</td> </tr> ")
			.append("<tr style=\"background-color:#B0DEFF;height:30px;color:grey;\"> ")
			.append(" <td align=\"right\" colspan=\"2\">");
			if(this.urlLink != null && this.urlLink.length() > 0 )
			{
				sb.append("<a href=\"").append(this.urlLink).append("\">").append(this.urlLink).append(" </a>");
			}
			sb.append("&nbsp;&nbsp;</td></tr></table>");
		return sb.toString();
	}
}
