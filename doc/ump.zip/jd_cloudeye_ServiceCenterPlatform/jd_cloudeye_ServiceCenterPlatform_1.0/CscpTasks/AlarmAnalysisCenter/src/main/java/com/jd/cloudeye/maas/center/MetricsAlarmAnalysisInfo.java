package com.jd.cloudeye.maas.center;

import java.io.Serializable;
import java.util.HashMap;

/**
 * 指标报警分析配置类
 */
public class MetricsAlarmAnalysisInfo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private long usinId;	//关联ID
	private String userId;	//用户ID
	private String serviceCode;	//服务code
	private String instanceId;	//实例ID
	private long alarmRuleId;	//规则ID
	private String metricsCode;	//指标code
	private int continualOccurs;	//连续出现次数
	private int period;	//时间段内
	private String statics;	//计算方式
	private int computors;	//阀值比较符
	private long threshold;	//阀值
	private int alarmLevel;	//报警级别
	private HashMap<Long,String> alarmRuleDetail;	//报警规则详细
	private long taskTime;	//任务时间
	
	public long getUsinId() {
		return usinId;
	}
	public void setUsinId(long usinId) {
		this.usinId = usinId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getInstanceId() {
		return instanceId;
	}
	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}
	public long getAlarmRuleId() {
		return alarmRuleId;
	}
	public void setAlarmRuleId(long alarmRuleId) {
		this.alarmRuleId = alarmRuleId;
	}
	public String getMetricsCode() {
		return metricsCode;
	}
	public void setMetricsCode(String metricsCode) {
		this.metricsCode = metricsCode;
	}
	public int getContinualOccurs() {
		return continualOccurs;
	}
	public void setContinualOccurs(int continualOccurs) {
		this.continualOccurs = continualOccurs;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public String getStatics() {
		return statics;
	}
	public void setStatics(String statics) {
		this.statics = statics;
	}
	public int getComputors() {
		return computors;
	}
	public void setComputors(int computors) {
		this.computors = computors;
	}
	public long getThreshold() {
		return threshold;
	}
	public void setThreshold(long threshold) {
		this.threshold = threshold;
	}
	public int getAlarmLevel() {
		return alarmLevel;
	}
	public void setAlarmLevel(int alarmLevel) {
		this.alarmLevel = alarmLevel;
	}
	public HashMap<Long, String> getAlarmRuleDetail() {
		return alarmRuleDetail;
	}
	public void setAlarmRuleDetail(HashMap<Long, String> alarmRuleDetail) {
		this.alarmRuleDetail = alarmRuleDetail;
	}
	public long getTaskTime() {
		return taskTime;
	}
	public void setTaskTime(long taskTime) {
		this.taskTime = taskTime;
	}
	
}
