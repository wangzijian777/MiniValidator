package com.jd.cloudeye.cscp.dac;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.common.CommonConstance;
import com.jd.cloudeye.cscp.common.db.RedisManager;
import com.jd.cloudeye.cscp.dac.db.DataBaseManager;
import com.jd.cloudeye.cscp.dac.vo.MetricAnalysisVO;
import com.jd.cloudeye.mdas.center.MetricsDataAnalysisInfo;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class DataAnalysisCenterProcessor 
{
	private final static Logger LOGGER = LoggerFactory.getLogger(DataAnalysisCenterProcessor.class);
	private final static String CLASS_NAME = "DataAnalysisCenterProcessor";
	private final static String[] IOMETRICS = {"EC2_NetworkIn","EC2_NetworkOut","EC2_DiskReadMB","EC2_DiskWriteMB","EC2_DiskReadIO","EC2_DiskWriteIO"};
    private final static String[] DISKMETRICS = {"EC2_DiskFree","EC2_DiskUsed"};

	@Resource(name="redisManager")
	private RedisManager redisManager; 
	
	@Resource(name="dataBaseManager")
	private DataBaseManager dataBaseManager;
	
	
	public void processor(MetricsDataAnalysisInfo task)
	{
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.processor", false, true);
			
			CallerInfo metricsKeyCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.constructMetricsKey", false, true);
			String metricsKey = constructMetricsKey(task);
			Profiler.registerInfoEnd(metricsKeyCallInfo);
			
			String formatTime = convertTime(task.getTaskTime());
			String formatTimeSecond = convertTimeSecond(task.getTaskTime());
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[START] analysis metrics key is ["+metricsKey+"]time["+formatTime+"]");
			//判断是否是计算I/O的指标
			Boolean IOMetricsFlag = CommonConstance.isHave(IOMETRICS, task.getMetricsCode());
			//判断是否是磁盘的指标
            Boolean diskMetricsFlag = CommonConstance.isHave(DISKMETRICS, task.getMetricsCode());
            //判断是否是AS的指标
            Boolean asMetricsFlag = (task.getMetricsCode().indexOf(CommonConstance.METRICS_AS) != -1);
			
			CallerInfo fetchAnalysisDataCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.fetchAnalysisData", false, true);
			//取CDRC中存储的redis数据
			Map<String,String> analysisData = fetchAnalysisData(metricsKey,formatTime);
			Map<String,String> analysisDataLastMin = new HashMap<String,String>();
			if(IOMetricsFlag) {
			    //取上一分钟的原始数据
			    Calendar calendar = Calendar.getInstance();
	            calendar.setTimeInMillis(task.getTaskTime());
	            calendar.set(Calendar.SECOND, 0);
	            calendar.set(Calendar.MILLISECOND, 0);
	            calendar.add(Calendar.MINUTE, -1);
			    analysisDataLastMin = fetchAnalysisData(metricsKey,convertTime(calendar.getTimeInMillis()));
			}
			Profiler.registerInfoEnd(fetchAnalysisDataCallInfo);
			
			if(analysisData != null && analysisData.size() > 0)
			{
			    if(diskMetricsFlag)
			    {
			        CallerInfo calculateValueCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.calculateValue", false, true);
                    //数据解析
                    String[] analysisResult = calculateDiskValue(analysisData);
                    Profiler.registerInfoEnd(calculateValueCallInfo);
                    
                    //存redis缓存
                    long cacheLength = cacheLastResultDiskData(analysisResult,metricsKey,formatTime);
                    
                    if(LOGGER.isDebugEnabled())
                        LOGGER.debug("metricsKey["+metricsKey+"]time["+formatTime+"]cache length["+cacheLength+"]");
                    
                    CallerInfo insertAnalysisResultCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.insertAnalysisResult", false, true);
                    //解析数据保存数据库
                    dataBaseManager.insertDiskAnalysisResult(task, formatTimeSecond, analysisResult);
                    Profiler.registerInfoEnd(insertAnalysisResultCallInfo);
                    
                    if(LOGGER.isDebugEnabled())
                        LOGGER.debug("[END] analysis metrics key is ["+metricsKey+"]time["+formatTime+"]");
			    }
			    else
			    {
			        CallerInfo calculateValueCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.calculateValue", false, true);
                    //数据解析
                    double[] analysisResult = calculateValue(analysisData, analysisDataLastMin, IOMetricsFlag, asMetricsFlag);
                    Profiler.registerInfoEnd(calculateValueCallInfo);
                    
                    if(LOGGER.isDebugEnabled())
                        LOGGER.debug("["+metricsKey+"]calculate result is max["+analysisResult[CommonConstance.MAX]+"]min["+analysisResult[CommonConstance.MIN]+"]avg["+analysisResult[CommonConstance.AVG]+"]sum["+analysisResult[CommonConstance.SUM]+"]");
                    
                    //存redis缓存
                    long cacheLength = cacheLastResultData(analysisResult,metricsKey,formatTime);
                    
                    if(LOGGER.isDebugEnabled())
                        LOGGER.debug("metricsKey["+metricsKey+"]time["+formatTime+"]cache length["+cacheLength+"]");
                    
                    CallerInfo insertAnalysisResultCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.insertAnalysisResult", false, true);
                    //解析数据保存数据库
                    dataBaseManager.insertAnalysisResult(constructResultVO(task,analysisResult), constructTableName(task.getServiceCode()));
                    Profiler.registerInfoEnd(insertAnalysisResultCallInfo);
                    
                    if(LOGGER.isDebugEnabled())
                        LOGGER.debug("[END] analysis metrics key is ["+metricsKey+"]time["+formatTime+"]");
			    }
			}
			else
			{
			    if(LOGGER.isDebugEnabled()) {
			        LOGGER.debug(CommonLogUtil.makeWarnHead(CommonConstance.MODULE_DAC, CLASS_NAME, "processor")+"key["+metricsKey+"]time["+formatTime+"]don't data in redis!");
			    }
			}
		}
		catch(DacException dac)
		{
			Profiler.functionError(callerInfo);
			LOGGER.warn(dac.getMessage());
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error(CommonLogUtil.makeErrorHead(CommonConstance.MODULE_DAC, CLASS_NAME) + "analysis task error!["+task.toString()+"]",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	private MetricAnalysisVO constructResultVO(MetricsDataAnalysisInfo task,double[] analysisResult)
	{
		MetricAnalysisVO maVO = new MetricAnalysisVO();
		maVO.setAnalysisTime(new Date(task.getTaskTime()));
		maVO.setAvgValue(analysisResult[CommonConstance.AVG]);
		maVO.setMaxValue(analysisResult[CommonConstance.MAX]);
		maVO.setMetricsCode(task.getMetricsCode());
		maVO.setMinValue(analysisResult[CommonConstance.MIN]);
		maVO.setSumValue(analysisResult[CommonConstance.SUM]);
		maVO.setUsinId(Long.valueOf(task.getUsinId()));
		return maVO;
	}
	
	private String constructMetricsKey(MetricsDataAnalysisInfo task)
	{
		StringBuilder metricsKey = new StringBuilder(task.getServiceCode());
		metricsKey.append(CommonConstance.KEY_SPLIT).append(task.getServiceCode().equals(CommonConstance.SERVICE_EC2)?CommonConstance.KNULL:task.getUserId())
		        .append(CommonConstance.KEY_SPLIT).append(task.getInstanceId())
		        .append(CommonConstance.KEY_SPLIT).append(task.getMetricsCode());
		return metricsKey.toString();
	}
	
	private Map<String,String> fetchAnalysisData(String metricsKey,String time)
	{
		return redisManager.hGetAll(metricsKey + CommonConstance.KEY_SPLIT + time);
	}
	
	/**
	 * 根据数据接收中心缓存的一分钟原始数据，取最大值，最小值，平均值，求和的计算
	 * @param analysisData
	 * @param analysisDataLastMin
	 * @param flag
	 * @return
	 */
	private double[] calculateValue(Map<String,String> analysisData, Map<String,String> analysisDataLastMin, Boolean flag, Boolean asMetricsFlag) throws DacException
	{
		double [] result = new double[4];
		double maxValue = 0;
		double minValue = 0;
		double avgValue = 0;
		double sumValue = 0;
		int count = 0;
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("analysis source data print :");
		
		//如果是I/O指标
		if(flag)
		{
		    if(analysisData==null || analysisData.isEmpty() || analysisDataLastMin==null || analysisDataLastMin.isEmpty())
		    {
		        sumValue = 0;
		        maxValue = 0;
		        minValue = 0;
		        count = 1;
		    }
		    else
		    {
		        Iterator<String> dataIterator = analysisData.keySet().iterator();
		        String timeLastMin = "";
		        String valueLastMin = "";
		        //抽样上一分钟的一个数据
		        for(Entry<String,String> entry:analysisDataLastMin.entrySet())
		        {
		            if(entry.getValue() == null || "".equals(entry.getValue()) || entry.getKey() == null || "".equals(entry.getValue()))
	                {
	                    continue;
	                }
		            else
		            {
		                timeLastMin = entry.getKey();
		                valueLastMin = entry.getValue();
		                break;
		            }
		        }
		        if("".equals(timeLastMin) || "".equals(valueLastMin))
	            {
	                sumValue = 0;
	                maxValue = 0;
	                minValue = 0;
	                count = 1;
	            }
		        else
		        {
    		        //遍历当前分钟的数据
        		    while(dataIterator.hasNext())
        	        {
        		        String timeNow = dataIterator.next();
        		        String valueNow = analysisData.get(timeNow);
        	            if(LOGGER.isDebugEnabled())
        	                LOGGER.debug("source data now time["+timeNow+"]value["+valueNow+"], source data last min time["+timeLastMin+
        	                        "]value["+valueLastMin+"]");
        	            
        	            if(valueNow == null || "".equals(valueNow))
        	            {
        	                continue;
        	            }
        	            
        	            double value = 0;
        	            try
        	            {
            	            int timeMission = Integer.valueOf(timeNow) + 60 - Integer.valueOf(timeLastMin);
            	            double valueMission = Double.valueOf(valueNow) - Double.valueOf(valueLastMin);
            	            if(valueMission > 0) 
            	            {
            	                value = valueMission/timeMission;
            	            }
        	            }catch(Exception e)
        	            {
        	                LOGGER.error("calculate the I/O value error!", e);
        	            }
        	            if(count == 0)
        	            {
        	                maxValue = value;
        	                minValue = value;
        	            }
        	            sumValue += value;
        	            maxValue = Math.max(maxValue, value);
        	            minValue = Math.min(minValue, value);
        	            count++;
        	        }
		        }
		    }
		}
		else
		{
    		for(Entry<String,String> entry:analysisData.entrySet())
    		{
    			if(LOGGER.isDebugEnabled())
    				LOGGER.debug("source data time["+entry.getKey()+"]value["+entry.getValue()+"]");
    			
    			if(entry.getValue() == null || "".equals(entry.getValue()))
    			{
    				continue;
    			}
    			
    			double value = Double.valueOf(entry.getValue());
    			
    			//如果是AS指标
    			if(asMetricsFlag)
    			{
    			    sumValue = value;
    			    maxValue = value;
    			    minValue = value;
    			}else{
    			    if(count == 0)
                    {
                        maxValue = value;
                        minValue = value;
                    }
                    sumValue += value;
                    maxValue = Math.max(maxValue, value);
                    minValue = Math.min(minValue, value);
    			}
    			
    			count++;
    		}
		}
		
		if(count == 0)
			throw new DacException(CommonLogUtil.makeWarnHead(CommonConstance.MODULE_DAC, CLASS_NAME, "calculateValue")+"all metrics value is null,please check!");
		
		//如果是AS指标
        if(asMetricsFlag)
        {
            avgValue = sumValue;
        }else
        {
            avgValue = new BigDecimal(sumValue).divide(new BigDecimal(count),1,RoundingMode.HALF_UP).doubleValue();
        }
		result[CommonConstance.MAX] = formatNumber(maxValue);
		result[CommonConstance.MIN] = formatNumber(minValue);
		result[CommonConstance.AVG] = formatNumber(avgValue);
		result[CommonConstance.SUM] = formatNumber(sumValue);
		return result;
	}
	
	/**
	 * 计算磁盘指标
	 * @param analysisData
	 * @return
	 * @throws DacException
	 * @author cdxuxiaolong
	 * @date 2013-12-12
	 */
	private String[] calculateDiskValue(Map<String,String> analysisData) throws DacException
    {
        String lastValue = "";
        int maxKey = 0;
        
        if(LOGGER.isDebugEnabled())
            LOGGER.debug("analysis source data(disk) print :");
        
        for(Entry<String,String> entry:analysisData.entrySet())
        {
            if(entry.getValue() == null || "".equals(entry.getValue()))
            {
                continue;
            }
            
            int secondTime = 0;
            try
            {
                secondTime = Integer.valueOf(entry.getKey());
            } catch(Exception e)
            {
            }
            if(secondTime > maxKey)
            {
                maxKey = secondTime;
                lastValue = entry.getValue();
            }
        }
        
        if(lastValue == null || "".equals(lastValue))
            throw new DacException(CommonLogUtil.makeWarnHead(CommonConstance.MODULE_DAC, CLASS_NAME, "calculateValue")+"all metrics value is null,please check!");
        
        if(LOGGER.isDebugEnabled())
        {
            LOGGER.debug("The last disk data is: " + lastValue);
        }
        
        try {
            String[] result = lastValue.split(",");
            return result;
        }catch(Exception e) {
            throw new DacException(CommonLogUtil.makeWarnHead(CommonConstance.MODULE_DAC, CLASS_NAME, "calculateValue")+"the last disk data split error,please check!");
        }
    }
	
	/**
	 * 将分析结果缓存到redis中，只缓存最近88分钟的数据,供AS接口和报警分析直接在缓存中获取，不用查询一次数据库
	 * @param analysisResult
	 * @param metricsKey
	 * @return
	 */
	private long cacheLastResultData(double[] analysisResult,String metricsKey,String formatTime)
	{
		StringBuilder cacheResult = new StringBuilder(formatTime);
		cacheResult.append(CommonConstance.KEY_SPLIT).append(String.valueOf(analysisResult[CommonConstance.MAX]))
				   .append(CommonConstance.KEY_SPLIT).append(analysisResult[CommonConstance.MIN])
		           .append(CommonConstance.KEY_SPLIT).append(analysisResult[CommonConstance.AVG])
		           .append(CommonConstance.KEY_SPLIT).append(analysisResult[CommonConstance.SUM]);
		return redisManager.cacheAnalysisResult(metricsKey, cacheResult.toString());
	}
	
	/**
	 * disk数据缓存到redis中
	 * @param analysisResult
	 * @param metricsKey
	 * @param formatTime
	 * @return
	 * @author cdxuxiaolong
	 * @date 2013-12-12
	 */
	private long cacheLastResultDiskData(String[] analysisResult,String metricsKey,String formatTime)
    {
        StringBuilder cacheResult = new StringBuilder(formatTime);
        for(int i=0; i<analysisResult.length; i++)
        {
            cacheResult.append(CommonConstance.KEY_SPLIT).append(analysisResult[i]);
        }
        return redisManager.cacheAnalysisResult(metricsKey, cacheResult.toString());
    }
	
	/**
	 * 把分析任务中的long性时间解析成字符串时间yyyyMMddHHmm
	 * @param time
	 * @return
	 */
	private String convertTime(long time)
	{
		return DateFormatUtils.format(time,CommonConstance.DATA_FORMAT_YYYYMMDDHHMM);
	}
	
	/**
     * 把分析任务中的long性时间解析成字符串时间yyyyMMddHHmmss
     * @param time
     * @return
     */
    private String convertTimeSecond(long time)
    {
        return DateFormatUtils.format(time,CommonConstance.DATA_FORMAT_YYYYMMDDHHMMSS);
    }
	
	/**
	 * 根据服务名拼装结果表
	 * @param serverName
	 * @return
	 */
	private String constructTableName(String serverName)
	{
		
		return CommonConstance.TABLE_PREFIX + serverName.toLowerCase() + CommonConstance.TABLE_POSTFIX;
	}
	
	/**
	 * 格式化double数字保留两位小数
	 * @param num
	 * @return
	 */
	public Double formatNumber(Double num)
	{
		return new BigDecimal(num).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}
	
//	public static void main(String [] args) throws DacException
//	{
//		DataAnalysisCenterProcessor dac = new DataAnalysisCenterProcessor();
//		MetricsDataAnalysisInfo me = new MetricsDataAnalysisInfo();
//		me.setClusterId("");
//		me.setInstanceId("10.23.33.443");
//		me.setMetricsCode("cup");
//		me.setServiceCode("EBS");
//		me.setTaskTime(System.currentTimeMillis());
//		me.setUserId("lifang");
//		me.setUsinId("333");
//		Map<String,String> map = new HashMap<String,String>();
//		map.put("00", "");
//		map.put("10", "");
//		map.put("20", "");
//		map.put("30", "");
//		map.put("40", "");
//		map.put("50", "6");
//		System.out.println(dac.constructTableName("EC2"));
//	}
}
