package com.jd.cloudeye.cscp.dac;

public class DacException extends Exception
{
	private static final long serialVersionUID = 1L;

	public DacException(String message) 
	{
		super(message);
	}
}
