package com.jd.cloudeye.cscp.dac.vo;

import java.util.Date;

public class MetricAnalysisVO 
{
	private long usinId;
	private String metricsCode;
	private double avgValue;
	private double maxValue;
	private double minValue;
	private double sumValue;
	private Date   analysisTime;
	private Date   createDate;
	
	public long getUsinId() {
		return usinId;
	}
	public void setUsinId(long usinId) {
		this.usinId = usinId;
	}
	public String getMetricsCode() {
		return metricsCode;
	}
	public void setMetricsCode(String metricsCode) {
		this.metricsCode = metricsCode;
	}
	public double getAvgValue() {
		return avgValue;
	}
	public void setAvgValue(double avgValue) {
		this.avgValue = avgValue;
	}
	public double getMaxValue() {
		return maxValue;
	}
	public void setMaxValue(double maxValue) {
		this.maxValue = maxValue;
	}
	public double getMinValue() {
		return minValue;
	}
	public void setMinValue(double minValue) {
		this.minValue = minValue;
	}
	public double getSumValue() {
		return sumValue;
	}
	public void setSumValue(double sumValue) {
		this.sumValue = sumValue;
	}
	public Date getAnalysisTime() {
		return analysisTime;
	}
	public void setAnalysisTime(Date analysisTime) {
		this.analysisTime = analysisTime;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
}
