package com.jd.cloudeye.cscp.dac;

import javax.annotation.Resource;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.common.CommonConstance;
import com.jd.cloudeye.mdas.center.MetricsDataAnalysisInfo;
@Component
public class DataAnalysisCenterSource implements MessageListener
{
	private final static Logger LOGGER = LoggerFactory.getLogger(DataAnalysisCenterSource.class);
	private final static String CLASS_NAME = "DataAnalysisCenterSource";
	@Resource(name="dataAnalysisCenterProcessor")
	private DataAnalysisCenterProcessor dataAnalysisCenterProcessor;
	
	@Override
	public void onMessage(Message msg)
	{
		try
		{
			if(msg instanceof ObjectMessage) 
			{
				ObjectMessage message = (ObjectMessage)msg; 
				MetricsDataAnalysisInfo metricsTask = (MetricsDataAnalysisInfo)message.getObject();
				if(metricsTask != null)
				{
					if(LOGGER.isDebugEnabled())
						LOGGER.debug("analysis task is " + metricsTask.toString());
					dataAnalysisCenterProcessor.processor(metricsTask);
				}
				else
				{
					LOGGER.info(CommonLogUtil.makeInfoHead(CommonConstance.MODULE_DAC, CLASS_NAME, "onMessage") + "fetch analysis task object is null!");
				}
			}
			else
			{
				LOGGER.warn(CommonLogUtil.makeWarnHead(CommonConstance.MODULE_DAC, CLASS_NAME, "onMessage") + "fetch analysis task object type error!"+msg);
			}
		}
		catch(Exception e)
		{
			LOGGER.error(CommonLogUtil.makeErrorHead(CommonConstance.MODULE_DAC, CLASS_NAME) + " analysis task error!", e);
		}
	}
}
