package com.jd.cloudeye.cscp.dac.db;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.common.CommonConstance;
import com.jd.cloudeye.cscp.dac.vo.MetricAnalysisVO;
import com.jd.cloudeye.mdas.center.MetricsDataAnalysisInfo;

@Component
public class DataBaseManager 
{
	private final static Logger LOGGER = LoggerFactory.getLogger(DataBaseManager.class);
	private final static String CLASS_NAME = "DataBaseManager";
	
	@Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;
	
	@Resource(name = "transactionTemplate")
    private TransactionTemplate transactionTemplate;
	
	public int insertAnalysisResult(MetricAnalysisVO maVO,String tableName)
	{
		try
		{
			String sql = "insert into "+tableName+"(jce_usin_id,jce_metrics_code,jce_avg_value,jce_max_value,jce_min_value,jce_sum_value,jce_anly_time,create_time)" +
					" values(?,?,?,?,?,?,?,now())";
			Object [] param = new Object[]{maVO.getUsinId(),maVO.getMetricsCode(),maVO.getAvgValue(),maVO.getMaxValue(),maVO.getMinValue(),maVO.getSumValue(),maVO.getAnalysisTime()};
			return jdbcTemplate.update(sql, param);
		}
		catch(Exception e)
		{
			LOGGER.error(CommonLogUtil.makeErrorHead(CommonConstance.MODULE_DAC, CLASS_NAME)+"data insert error!",e);
		}
		return 0;
	}
	
	/**
	 * 保存磁盘分析数据到数据库中
	 * @param maVO
	 * @param tableName
	 * @return
	 * @author cdxuxiaolong
	 * @date 2013-12-12
	 */
	public int insertDiskAnalysisResult(final MetricsDataAnalysisInfo task, final String time, final String[] analysisResult)
    {
	    final String sql = "insert into jce_ec2_disk(ecd_instance_id,ecd_metrics_code,ecd_disk_name,ecd_disk_value,ecd_create_time,ecd_db_time) values(?,?,?,?,?,now())";
        try
        {
            transactionTemplate.execute(new TransactionCallback<Integer>() {

                @Override
                public Integer doInTransaction(TransactionStatus status) {
                    jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
                        
                        @Override
                        public void setValues(PreparedStatement ps, int i) throws SQLException {
                            String[] diskValue = analysisResult[i].split("=");
                            ps.setLong(1, task.getUsinId());
                            ps.setString(2, task.getMetricsCode());
                            ps.setString(3, diskValue[0]);
                            ps.setString(4, diskValue[1]);
                            ps.setString(5, time);
                        }
                        
                        @Override
                        public int getBatchSize() {
                            return analysisResult.length;
                        }
                    });
                    
                    return 1;
                }
            });
           
        }
        catch(Exception e)
        {
            LOGGER.error(CommonLogUtil.makeErrorHead(CommonConstance.MODULE_DAC, CLASS_NAME)+"data insert error!",e);
        }
        return 1;
    }
}
