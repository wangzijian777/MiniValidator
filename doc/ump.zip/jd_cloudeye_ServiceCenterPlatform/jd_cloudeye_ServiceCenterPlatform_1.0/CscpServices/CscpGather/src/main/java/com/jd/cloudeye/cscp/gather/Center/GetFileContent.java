package com.jd.cloudeye.cscp.gather.Center;

import java.io.IOException;
import java.io.InputStream;
import java.io.LineNumberReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.SocketException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.AppProperties;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.gather.common.FtpClient;
import com.jd.cloudeye.cscp.gather.common.GatherUtil;
import com.jd.cloudeye.cscp.gather.common.PerformanceTypeUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;



@Component
public class GetFileContent {
	private final static Logger log = LoggerFactory.getLogger(GetFileContent.class);
	
	@Resource(name = "ftpClient")
	private FtpClient ftpClient;
	
	private static String url = null;
	private static int port;
	private static String username = null;
	private static String password = null;
	FTPClient ftp = null;
	
	@PostConstruct
	public void init() {
		url = AppProperties.getProperty("ftp.url");
		port = Integer.parseInt(AppProperties.getProperty("ftp.port"));
		username = AppProperties.getProperty("ftp.user");
		password = AppProperties.getProperty("ftp.pwd");
	}
	
	public Map<String, Map<String, String>> analysisLogContent () {
		List<String> is = null;
		LineNumberReader reader = null;
		CallerInfo callerInfo = null;
    	// 主机性能类型map
		Map<String, Map<String, String>> hm = new HashMap<String,Map<String, String>>();
        // 得到最后修改的文件名
		is = getLastModifyFileByTime();
//    	log.info("=================The nagios Log file name is : " + is);
		try {
			callerInfo = Profiler.registerInfo("jms.CSC.CscpGather.analysisLogContent", false, true);
	        if (is != null) {
	        	// 每次读取一行
		        for (String line : is) {
			        try {
			        	String [] st = line.split(PerformanceTypeUtil.SPLIT_DOUBLE_SLASH);
			        	Map<String, String> hmTemp = new HashMap<String,String>();
			        	if (st.length > 2) {
			        		if (hm.get(st[1]) != null) {
			        			hmTemp = hm.get(st[1]);
			        		}
				        	if (st[2].equals(PerformanceTypeUtil.TCP_CONNS)) {
				        		hmTemp.put(PerformanceTypeUtil.EC2_TcpConnections, st[4].split(PerformanceTypeUtil.SPLIT_EQUAL_SIGNS)[1]);
				        	} else if (st[2].equals(PerformanceTypeUtil.LOAD)) {
				        		Map<String, String> sMapTempLoad = logAnalysis(st[4]);
				        		StringBuffer sbLoad = new StringBuffer();
				        		if (sMapTempLoad != null) {
				        			sbLoad.append(sMapTempLoad.get("load_1_min").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[0]).append(PerformanceTypeUtil.SPLIT_SEMICOLON)
				        			.append(sMapTempLoad.get("load_5_min").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[0]).append(PerformanceTypeUtil.SPLIT_SEMICOLON)
				        			.append(sMapTempLoad.get("load_15_min").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[0]).append(PerformanceTypeUtil.SPLIT_SEMICOLON);
					        		hmTemp.put(PerformanceTypeUtil.EC2_Load, sbLoad.toString());
				        		}
				        	} else if (st[2].equals(PerformanceTypeUtil.MEMORY)) {
				        		Map<String, String> sMapTempMem = logAnalysis(st[4]);
				        		long memUsed = 0;
				        		long memTotal = 0;
				        		long memUsage = 0;
				        		long memUsedRate = 0;
				        		
				        		if (sMapTempMem != null) {
				        			if (sMapTempMem.containsKey("ram_used")) {
					        			memUsed = Long.valueOf(sMapTempMem.get("ram_used").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[0].replace("KB", ""));
					        			memTotal = Long.valueOf(sMapTempMem.get("ram_used").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[4]);
						        		memUsage = memTotal - memUsed;
		
						        		BigDecimal a = new BigDecimal(memUsed);
						        		BigDecimal b = new BigDecimal(memTotal);
						        		BigDecimal c = a.divide(b, 2, RoundingMode.CEILING).multiply(new BigDecimal(100));
						        		memUsedRate = c.longValue();
		
						        		hmTemp.put(PerformanceTypeUtil.EC2_MemUsed, String.valueOf(memUsed));
						        		hmTemp.put(PerformanceTypeUtil.EC2_MemAvailable, String.valueOf(memUsage));
						        		hmTemp.put(PerformanceTypeUtil.EC2_MemUsedPercent, String.valueOf(memUsedRate));
						        		
				        			} else if (sMapTempMem.containsKey("Physical_Memory")) {
				        				// Physical_Memory=5093MB;29482;32102;0;32758
				        				memUsed = Long.valueOf(sMapTempMem.get("Physical_Memory").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[0].replace("MB", "")) * 1024L;
				        				memTotal = Long.valueOf(sMapTempMem.get("Physical_Memory").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[4]) * 1024L;
				        				memUsage = memTotal - memUsed;
				        				
						        		BigDecimal a = new BigDecimal(memUsed);
						        		BigDecimal b = new BigDecimal(memTotal);
						        		BigDecimal c = a.divide(b, 2, RoundingMode.CEILING).multiply(new BigDecimal(100));
						        		memUsedRate = c.longValue();
						        		
						        		hmTemp.put(PerformanceTypeUtil.EC2_MemUsed, String.valueOf(memUsed));
						        		hmTemp.put(PerformanceTypeUtil.EC2_MemAvailable, String.valueOf(memUsage));
						        		hmTemp.put(PerformanceTypeUtil.EC2_MemUsedPercent, String.valueOf(memUsedRate));
				        			}
				        		}
				        	} else if (st[2].equals(PerformanceTypeUtil.NET_IO)) {
				        		Map<String, String> sMapTempNet = logAnalysis(st[4]);
				        		float netIn;
				        		float netOut;
				        		
				        		if (sMapTempNet != null) {
				        			netIn = Float.valueOf(sMapTempNet.get("In").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[0].replace("Mbps", "")) * 1024f;
				        			netOut = Float.valueOf(sMapTempNet.get("Out").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[0].replace("Mbps", ""))* 1024f;
				        			
				        			hmTemp.put(PerformanceTypeUtil.EC2_NetworkIn, String.valueOf(netIn));
				        			hmTemp.put(PerformanceTypeUtil.EC2_NetworkOut, String.valueOf(netOut));
				        		}
			        			
				        	} else if (st[2].equals(PerformanceTypeUtil.DISK_IO)) {
				        		Map<String, String> sMapTempDiskIO = logAnalysis(st[4]);
				        		float diskReadMB = 0;
				        		float diskWriteMB = 0;
				        		float diskReadIO = 0;
				        		float diskWriteIO = 0;
				        		if (sMapTempDiskIO != null) {
				        			if (sMapTempDiskIO.get("ReadIO").indexOf("IO/s") != -1) {
				        				diskReadIO = Float.valueOf(sMapTempDiskIO.get("ReadIO").replace("IO/s", ""));
					        			diskWriteIO = Float.valueOf(sMapTempDiskIO.get("WriteIO").replace("IO/s", ""));
				        			} else {
				        				log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "GetFileContent", "analysisLogContent")+"Disk_IO's unit is not IO/s");
				        			}
				        			if (sMapTempDiskIO.get("ReadMB").indexOf("MB/s") != -1) {
				        				diskReadMB = Float.valueOf(sMapTempDiskIO.get("ReadMB").replace("MB/s", ""));
				        				diskWriteMB = Float.valueOf(sMapTempDiskIO.get("WriteMB").replace("MB/s", ""));
				        			} else {
				        				log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "GetFileContent", "analysisLogContent")+"Disk_IO's unit is not MB/s");
				        			}
				        			hmTemp.put(PerformanceTypeUtil.EC2_DiskReadIO, String.valueOf(diskReadIO));
				        			hmTemp.put(PerformanceTypeUtil.EC2_DiskWriteIO, String.valueOf(diskWriteIO));
				        			hmTemp.put(PerformanceTypeUtil.EC2_DiskReadMB, String.valueOf(diskReadMB));
				        			hmTemp.put(PerformanceTypeUtil.EC2_DiskWriteMB, String.valueOf(diskWriteMB));
				        		}
				        	} else if (st[2].equals(PerformanceTypeUtil.DISK)) {
				        		long totalDisk = 0;
				        		long usedDisk = 0;
				        		long freeDisk = 0;
	
				        		String[] temp = st[4].split(PerformanceTypeUtil.SPLIT_BLANK);
				        		for (String tt : temp) {
				        			String[] tl = tt.split(PerformanceTypeUtil.SPLIT_EQUAL_SIGNS);
				        			if (!tl[0].equals("/dev/shm")) {
				        				String[] tempD = tl[1].split(PerformanceTypeUtil.SPLIT_SEMICOLON);
				        				totalDisk = totalDisk + (Long.valueOf(tempD[4]) * 1024L);
				        				if (tempD[0].indexOf("%") > -1) {
				        					usedDisk = usedDisk + ( (Long.valueOf(tempD[0].replace("%", "")) * totalDisk) / 100 );
				        				} else if (tempD[0].indexOf("MB") > -1) {
				        					usedDisk = usedDisk + ( totalDisk - (Long.valueOf(tempD[0].replace("MB", "")) * 1024L) );
				        				} else {
				        					log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "GetFileContent", "analysisLogContent")+"usedDisk is not Numeric");
				        				}
				        				freeDisk = freeDisk + (totalDisk - usedDisk);
				        			}
				        		}
				        		hmTemp.put(PerformanceTypeUtil.EC2_DiskUsedSize, String.valueOf(usedDisk));
			        			hmTemp.put(PerformanceTypeUtil.EC2_DiskAvailableSize, String.valueOf(freeDisk));
				        	} else if (st[2].equals(PerformanceTypeUtil.CPU)) {
				        		hmTemp.put(PerformanceTypeUtil.EC2_CPUtilization, st[4].split(PerformanceTypeUtil.SPLIT_EQUAL_SIGNS)[1].replace("%", "").split(PerformanceTypeUtil.SPLIT_SEMICOLON)[0]);
				        	} 
				        	hm.put(st[1], hmTemp);
			        	} else {
			        		log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "GetFileContent", "analysisLogContent")+ "Analysis Log Content Format is Wrong!");
				        	continue;
			        	}
		        	} catch (Exception e) {
			        		log.warn("The nagios Log Content fomat is Wrong, detail is: " + line, e);
			        		continue;
			        }
		        }
		        if (hm.size() == 0) {
		        	log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "GetFileContent", "analysisLogContent")+ "Analysis Log Content is NULL, The Log File's Content is or not NULL Or Log Format has been Changed !");
		        	return null;
		        }
	        } else {
	        	log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "GetFileContent","analysisLogContent")+"Log Content is NULL, Did not Get File Content!");
	        	return null;
	        }
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "GetFileContent")+"analysis log file error!", e);
			return null;
		} finally {
			Profiler.registerInfoEnd(callerInfo);
	        try {
	        	if (reader != null) {
	        		reader.close();
	        	}
	        	if (ftp != null) {
			        if (ftp.isConnected()) {
			        	ftp.logout();
			            ftp.disconnect();  
			        }
	        	}
			} catch (Exception e) {
				log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "GetFileContent")+"Close Stream or Ftp client error!", e);
				return null;
			}
		}
		return hm;
	}
	
	private Map<String, String> logAnalysis (String logData) {
		String[] hostPerfdata = null;
		Map<String, String> sb = new HashMap<String, String>();
		if (logData != null || !"".equals(logData)) {
			hostPerfdata = logData.split(PerformanceTypeUtil.SPLIT_BLANK);
	    	for (String hp : hostPerfdata) {
				String[] performance = hp.split(PerformanceTypeUtil.SPLIT_EQUAL_SIGNS);
//				String[] pfj = performance[1].split(PerformanceTypeUtil.SPLIT_SEMICOLON);
				sb.put(performance[0], performance[1]);
			}
	    	return sb;
		}
		return null;
	}
	
	
	/**
	 * 连接ftp并返回最后修改文件的文件流，出错返回null
	 * @return
	 */
	private List<String> getLastModifyFileByTime () {
		TreeMap<Long,FTPFile> tm = new TreeMap<Long,FTPFile>();
		InputStream ss = null;
		List<String> logList = null;
		// 取得连接,返回ftp连接对象
		try {
			ftp = ftpClient.ftpConnect(url, port, username, password);
			ftp.enterLocalPassiveMode();
		} catch (SocketException e) {
			log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "GetFileContent")+"Connect Ftp Socket Error!", e);
			return null;
		} catch (IOException e) {
			log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "GetFileContent")+"Connect Ftp IO Error!", e);
			return null;
		}
		if (ftp != null) {
	        FTPFile[] fs = null;
			try {
				fs = ftp.listFiles();
			} catch (IOException e) {
				log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "GetFileContent")+"get file list Error!", e);
				return null;
			}
			if (fs != null && fs.length > 0) {
				for(FTPFile ff:fs){
		        	if (ff.getName().indexOf("temp") < 0 && ff.getName().indexOf(PerformanceTypeUtil.FTPCLIENT_IP_FILE_NAME) < 0) {
		        		tm.put(ff.getTimestamp().getTimeInMillis(), ff);
		        	}
		        }
				if (tm.size() > 0) {
			        log.info(CommonLogUtil.makeInfoHead(GatherUtil.MODULE_NAME, "GetFileContent","getLastModifyFileByTime")+"The FTP Server's Last Modify File is ++++++++++++++ " + tm.get((tm.lastKey())).getName());
			        try {
						ss = ftp.retrieveFileStream((tm.get((tm.lastKey())).getName()));
						logList = IOUtils.readLines(ss);
					} catch (IOException e) {
						log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "GetFileContent")+ "get last modify file stream Error!", e);
						try {
							if (ftp != null) {
							    if (ftp.isConnected()) {
							    	ftp.logout();
							        ftp.disconnect();  
							    }	
							}
						} catch (Exception e1) {
							log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "GetFileContent")+ "Close ftp error!", e1);
						}
						return null;
					}
				} else {
					log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "GetFileContent", "getLastModifyFileByTime")+"The nagios log file list is empty!");
					return null;
				}
			} else {
				log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "GetFileContent", "getLastModifyFileByTime")+ "The file list is empty!");
				return null;
			}
	        
		} else {
			return null;
		}
		return logList;
	}
}
