package com.jd.cloudeye.cscp.gather.common;

import com.jd.cloudeye.common.IModuleCreator;
import com.jd.cloudeye.common.Module;


/**
 * 
 * @author baiyunqi
 *
 */
public class GatherModuleCreator implements IModuleCreator {
	@Override
	public Module create() {
		Module module = new Module();
		
		module.setName("CscpGather");
		module.setVersion("2013032701");
		
		return module;
	}
}