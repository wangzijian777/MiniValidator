package com.jd.cloudeye.cscp.gather.common;



public class PerformanceTypeUtil {
	public static final String TYPE_RESOURCE = "RESOURCE";
	
	public static final String TCP_CONNS = "TCP conns";
	public static final String LOAD = "Load";
	public static final String DISK = "Disk";
	public static final String MEMORY = "Memory";
	public static final String NET_IO = "Net IO";
	public static final String CPU = "CPU";
	public static final String CHECK_HOST_ALIVE = "check-host-alive";
	public static final String DISK_IO  = "DISKIO";
	
	public static final String SPLIT_BLANK = " ";
	public static final String SPLIT_DOUBLE_SLASH = "\\|\\|";
	public static final String SPLIT_SEMICOLON = ";";
	public static final String SPLIT_EQUAL_SIGNS = "=";
	public static final String SPLIT_COLON = ":";
	public static final String SPLIT_COMMA = ",";
	
	public static final String TASK_SCAN = "scanNagios";
	
	public static final String FTPCLIENT_STATUS_KEY = "AS_FTPCLIENT_STATUS";
	
	public static final String FTPCLIENT_IP_FILE_NAME = "iplist";
	
	public static final String EC2_TcpConnections = "EC2_TcpConnections";
	public static final String EC2_CPUtilization = "EC2_CPUtilization";
	public static final String EC2_NetworkIn = "EC2_NetworkIn";
	public static final String EC2_NetworkOut = "EC2_NetworkOut";
	public static final String EC2_MemUsedPercent = "EC2_MemUsedPercent";
	public static final String EC2_MemAvailable = "EC2_MemAvailable";
	public static final String EC2_MemUsed = "EC2_MemUsed";
	public static final String EC2_Load = "EC2_Load";
	public static final String EC2_DiskAvailableSize = "EC2_DiskAvailableSize";
	public static final String EC2_DiskUsedSize = "EC2_DiskUsedSize";
	public static final String EC2_DiskReadMB = "EC2_DiskReadMB";
	public static final String EC2_DiskWriteMB = "EC2_DiskWriteMB";
	public static final String EC2_DiskReadIO = "EC2_DiskReadIO";
	public static final String EC2_DiskWriteIO = "EC2_DiskWriteIO";
}
