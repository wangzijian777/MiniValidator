package com.jd.cloudeye.cscp.gather.common;

import java.io.IOException;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;

@Component
public class FtpClient {
	
	private final static Logger log = LoggerFactory.getLogger(FtpClient.class);
	/**
	 * 连接ftp
	 * @param url
	 * @param port
	 * @param username
	 * @param password
	 * @return
	 * @throws SocketException
	 * @throws IOException
	 */
	public FTPClient ftpConnect(String url, int port, String username, String password) throws SocketException, IOException {
		int reply;
		FTPClient ftp = new FTPClient();
		ftp.connect(url, port);
		//如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器  
		ftp.login(username, password);
		// 得到返回码
		reply = ftp.getReplyCode();
		log.info(CommonLogUtil.makeInfoHead(GatherUtil.MODULE_NAME, "FtpClient","ftpConnect")+"reply code is : "+reply);
		if (!FTPReply.isPositiveCompletion(reply)) {  
			ftp.disconnect();
			log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "FtpClient","ftpConnect")+"FTP Client FAIL!");
			return null;
		}
		log.info(CommonLogUtil.makeInfoHead(GatherUtil.MODULE_NAME, "FtpClient","ftpConnect")+"FTP Client SUCCESS!");
		return ftp;
	}
}
