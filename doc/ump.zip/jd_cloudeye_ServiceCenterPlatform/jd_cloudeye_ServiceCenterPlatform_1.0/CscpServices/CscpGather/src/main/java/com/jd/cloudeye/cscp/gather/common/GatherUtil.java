package com.jd.cloudeye.cscp.gather.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.time.DateFormatUtils;


/**
 * AutoScanning相关常量
 * 
 * @author duliang
 * @date 2013-03-10
 */
public class GatherUtil {
	
	/**
	 * 模块名称
	 */
	public static final String MODULE_NAME = "CscpGather";
	
	/**
	 * redis中的前缀
	 */
	public static final String ANALYSIS_SOURCE_DATA_PREFIX = "AS_";
	public static final String ANALYSIS_RESULT_DATA_PREFIX = "AS_V_";
	
	
	/**
	 * 分析结果过期时间
	 * 过期时间：2小时
	 */
	public static final int ANALYSIS_RESULT_DATA_EXPIRE_TIME = 60 * 10;
	
	/**
	 * 时间格式
	 */
	public static final String DATE_FORMAT_YEAR_MONTH_DAY_HOUR_MINUTE = "yyyyMMddHHmmssSSS";
	
	/**
	 * 指标计算方式
	 */
	public static final String CALCULATION_MAX = "max";
	public static final String CALCULATION_MIN = "min";
	public static final String CALCULATION_AVG = "avg";
	public static final String CALCULATION_SUM = "sum";
	
	
	/**
	 * 格式化时间
	 * yyyyMMddHHmm
	 * @param time
	 * @return
	 */
	public static String formatTimeForMinute(long time){
		String yearMonthDateHourMinute = DateFormatUtils.format(time,DATE_FORMAT_YEAR_MONTH_DAY_HOUR_MINUTE);
    	return yearMonthDateHourMinute;
	}
	
	public static boolean isIPValid (String ipAddress) {
		Pattern pattern = Pattern.compile("\\b((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\." +
											"((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\b");
		Matcher matcher = pattern.matcher(ipAddress);
		if(matcher.matches()) {
			return true;
		} else {
			return false;
		}
	}
}
