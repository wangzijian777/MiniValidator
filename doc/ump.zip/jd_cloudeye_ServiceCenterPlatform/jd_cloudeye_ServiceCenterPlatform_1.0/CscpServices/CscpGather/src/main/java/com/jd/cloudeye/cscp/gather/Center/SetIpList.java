package com.jd.cloudeye.cscp.gather.Center;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.AppProperties;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.gather.common.FtpClient;
import com.jd.cloudeye.cscp.gather.common.GatherUtil;
import com.jd.cloudeye.cscp.gather.common.PerformanceTypeUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


@Component
public class SetIpList {
	private final static Logger log = LoggerFactory.getLogger(SetIpList.class);
	@Resource(name = "ftpClient")
	private FtpClient ftpClient;
	private static String url = null;
	private static int port;
	private static String username = null;
	private static String password = null;
	
	@PostConstruct
	public void init() {
		url = AppProperties.getProperty("ftp.url");
		port = Integer.parseInt(AppProperties.getProperty("ftp.port"));
		username = AppProperties.getProperty("ftp.user");
		password = AppProperties.getProperty("ftp.pwd");
	}
	
	public boolean setIPList (List<String> vmlist) {
		if (vmlist.size() != 0) {
			StringBuffer sb = new StringBuffer();
			Set<String> tt = new HashSet<String>();
			for (String aif : vmlist) {
				if(GatherUtil.isIPValid(aif))
				{
					if(!tt.contains(aif))
					{
						tt.add(aif);
						sb.append(aif).append(System.getProperty("line.separator"));
					}
				}
				else
					continue;
			}
			if (!saveIP2File(sb.toString())) {
				log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "SetIpList", "setIPList")+"saveIP2File Error!");
				return false;
			}
		} else {
			log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "SetIpList","setIPList")+"The IP List is NULL!");
			return false;
		}
		return true;
	}
	
	private boolean saveIP2File (String data) {
		FTPClient ftp = null;
		BufferedWriter pw = null;
		InputStream input = null;
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("jms.CSC.CscpGather.saveIP2File", false, true);
			ftp = ftpClient.ftpConnect(url, port, username, password);
			ftp.enterLocalPassiveMode();
//			FTPFile[] fs = ftp.listFiles();
//			for (FTPFile ff:fs) {
//				if (ff.getName().indexOf(PerformanceTypeUtil.FTPCLIENT_IP_FILE_NAME) >= 0) {
			ftp.deleteFile(PerformanceTypeUtil.FTPCLIENT_IP_FILE_NAME);
//				}
//			}
			String fileName = SetIpList.class.getResource("/").getPath()+PerformanceTypeUtil.FTPCLIENT_IP_FILE_NAME;
			log.info("==============="+fileName);
			input = new FileInputStream(fileName);
			ftp.storeFile(PerformanceTypeUtil.FTPCLIENT_IP_FILE_NAME, input);
			
			OutputStreamWriter out = new OutputStreamWriter(ftp.appendFileStream(PerformanceTypeUtil.FTPCLIENT_IP_FILE_NAME));
			pw = new BufferedWriter(out);
			log.info(CommonLogUtil.makeInfoHead(GatherUtil.MODULE_NAME, "SetIpList","saveIP2File")+"Gather ++++++++ begin time is : " + new Date());
			pw.write(data);
			return true;
		} catch (Exception e) {
			log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "SetIpList")+"Save file error!", e);
			Profiler.functionError(callerInfo);
			return false;
		} finally {
			Profiler.registerInfoEnd(callerInfo);
			try {
				if (input != null) {
					input.close();
				}
				if (pw != null) {
					pw.flush();
					pw.close();
					log.info(CommonLogUtil.makeInfoHead(GatherUtil.MODULE_NAME, "SetIpList","saveIP2File")+"Gather ++++++++ end time is : " + new Date());
				}
				if (ftp != null) {
				    if (ftp.isConnected()) {
				    	ftp.logout();
				        ftp.disconnect();  
				    }
				}
			} catch (Exception e) {
				log.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "SetIpList")+"Close BufferedWriter or FTPClient Error", e);
				return false;
			}
			
		}
	}
}
