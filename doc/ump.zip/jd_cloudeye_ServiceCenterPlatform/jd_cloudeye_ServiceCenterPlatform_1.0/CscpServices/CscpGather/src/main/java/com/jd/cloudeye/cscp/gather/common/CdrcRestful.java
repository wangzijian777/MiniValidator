package com.jd.cloudeye.cscp.gather.common;

import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.AppProperties;

@Component
public class CdrcRestful {

	//公有云监控-数据接收中心-数据采集接口URL
	private static final String restfulURL = AppProperties.getProperty("cdrc.url");
	private static final String contentType = "application/json";
	private static final String pathUri = "collectData/sendServiceLog";
	private WebClient restFulclient = null;
	private HTTPConduit httpConduit = null;
	
	private CdrcRestful()
	{
		restFulclient = WebClient.create(restfulURL);
		httpConduit = WebClient.getConfig(restFulclient).getHttpConduit();
		restFulclient.path(pathUri).accept(contentType).encoding("utf-8");
		httpConduit.getClient().setReceiveTimeout(0);
		httpConduit.getClient().setConnectionTimeout(0);
	}
	
	public synchronized static WebClient getInstance()
	{
		return new CdrcRestful().restFulclient;
	}
}
