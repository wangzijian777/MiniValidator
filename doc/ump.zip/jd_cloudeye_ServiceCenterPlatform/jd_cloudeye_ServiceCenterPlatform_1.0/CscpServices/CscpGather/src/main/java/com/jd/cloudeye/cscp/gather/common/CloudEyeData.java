package com.jd.cloudeye.cscp.gather.common;

import java.util.Map;

/**
 * @title 匹配测试数据JSON的VO
 * @description
 * @author yangjialiang
 * @date 2013-2-28
 */
public class CloudEyeData {
	private String userId;
	private String serviceType;
	private String clusterId;
	private String instanceId;
	private String time;
	private Map<String, String> metrics;
	
	public void setUserId(String userId) {
		this.userId = userId.trim();
	}
	public String getUserId() {
		return userId;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType.trim();
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setClusterId(String clusterId) {
		this.clusterId = clusterId.trim();
	}
	public String getClusterId() {
		return clusterId;
	}
	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId.trim();
	}
	public String getInstanceId() {
		return instanceId;
	}
	public void setTime(String time) {
		this.time = time.trim();
	}
	public String getTime() {
		return time;
	}
	public void setMetrics(Map<String, String> metrics) {
		this.metrics = metrics;
	}
	public Map<String, String> getMetrics() {
		return metrics;
	}
}
