package com.jd.cloudeye.cscp.gather.db;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.gather.common.GatherUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AutoScanning数据库存储
 * 
 * @date 2013-03-10
 * @author baiyunqi
 */

@Component
public class GatherDBManager {
    
	private final static Logger logger = LoggerFactory.getLogger(GatherDBManager.class);
	
	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;

	
	/**
	 * 保存AS数据分析结果
	 * @param resultMap
	 * @param taskArray
	 */
	public void saveAnalysisAutoScanning(Map<String,Map<String,String>> resultMap,String[] taskArray) {
		try{
			for(Map.Entry<String,Map<String,String>> entry : resultMap.entrySet()){
				 String sqlForInsert = " insert into ump_machine_index_result( uir_uuid,uir_code,uir_max,uir_min,uir_avg,uir_sum,uir_datetime )" +
				 		" values(?,?,?,?,?,?,?) ";
			     final Object[] paramsForInsert = new Object[] 
			        { 
		    		 taskArray[0],
		    		 entry.getKey(),
		    		 entry.getValue().get(GatherUtil.CALCULATION_MAX),
		    		 entry.getValue().get(GatherUtil.CALCULATION_MIN),
		    		 entry.getValue().get(GatherUtil.CALCULATION_AVG),
		    		 entry.getValue().get(GatherUtil.CALCULATION_SUM),
		    		 GatherUtil.formatTimeForMinute(Long.parseLong(taskArray[1]))
			    	};
			     this.jdbcTemplate.update(sqlForInsert, paramsForInsert); 
			}
		}catch (Exception e) {
		    logger.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "GatherDBManager"), "Save AnalysisAutoScanning Error!" + e);
        }
	}
	
}
