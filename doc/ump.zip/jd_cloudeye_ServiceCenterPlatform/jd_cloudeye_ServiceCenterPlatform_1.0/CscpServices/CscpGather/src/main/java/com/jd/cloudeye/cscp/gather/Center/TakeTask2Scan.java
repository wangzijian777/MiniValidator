package com.jd.cloudeye.cscp.gather.Center;

import javax.annotation.Resource;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.gather.common.GatherUtil;
import com.jd.cloudeye.cscp.gather.common.PerformanceTypeUtil;
@Component
public class TakeTask2Scan implements MessageListener {
	
	@Resource(name = "sendData2Cdrc")
	private SendData2Cdrc sendData2Cdrc;
	
	private final static Logger LOGGER = LoggerFactory.getLogger(TakeTask2Scan.class);
	/**
	 * 一旦监听到MQ队列有任务则执行onMessage方法开始处理
	 */
	public void onMessage(Message msg) { 
		if (msg instanceof TextMessage) {
			try {
				String receivedData = ((TextMessage) msg).getText();
				LOGGER.info(CommonLogUtil.makeInfoHead(GatherUtil.MODULE_NAME, "TakeTask2Scan","onMessage")+"AutoScanning TASK:" + receivedData);
				String[] switchMethod = receivedData.split("\\|");
				if (switchMethod.length==2) {
					if (PerformanceTypeUtil.TASK_SCAN.equals(switchMethod[0].trim())) {
						LOGGER.info("++++++++++Begin Scan Data Handle");
						if(!sendData2Cdrc.sent2Cdrc()) {
							LOGGER.error("Scan Nagios Log File Failed!");
						}
					}
				}
			} catch (Exception e) {
				LOGGER.error(CommonLogUtil.makeErrorHead(GatherUtil.MODULE_NAME, "TakeTask2Scan")+" Scan Nagios log file ERROR!", e);
			}
		} else {
			LOGGER.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "TakeTask2Scan","onMessage")+"Scan Nagios log file ERROR!");
		}

		LOGGER.info("++++++++++End Scan Data Handle");
	}
}
