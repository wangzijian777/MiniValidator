package com.jd.cloudeye.cscp.gather.Center;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.gather.common.CdrcRestful;
import com.jd.cloudeye.cscp.gather.common.CloudEyeData;
import com.jd.cloudeye.cscp.gather.common.GatherUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class SendData2Cdrc {
	@Resource(name = "getFileContent")
	private GetFileContent getFileContent;
	@Resource(name = "cdrcRestful")
	private CdrcRestful cdrcRestful;
	
	private final static Logger log = LoggerFactory.getLogger(SetIpList.class);
	
	public boolean sent2Cdrc () {
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("jms.CSC.CscpGather.sent2Cdrc", false, true);
			Map<String, Map<String, String>> hm = new HashMap<String,Map<String, String>>();
			if((hm = getFileContent.analysisLogContent()) == null) {
				log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "SendData2Cdrc", "sent2Cdrc")+"analysisLogContent is NULL, Did not Get File Content!");
	        	return false;
			} else {
				log.info("==============The Nagios Map is : " + hm);
				List<CloudEyeData> data = new ArrayList<CloudEyeData>();
				for (Entry<String, Map<String, String>> entry : hm.entrySet()) {
					CloudEyeData jsonObject = new CloudEyeData();
					jsonObject.setInstanceId(entry.getKey());
					jsonObject.setServiceType("EC2");
					jsonObject.setMetrics(entry.getValue());
					jsonObject.setTime(GatherUtil.formatTimeForMinute(new Date().getTime()));
					data.add(jsonObject);
				}
				log.info("===============Send to Cdrc's Data is : " + JSON.toJSONString(data));
				String tt = cdrcRestful.getInstance().post(JSON.toJSONString(data), String.class);
				log.info("============The cdrc return is : " + tt);
			}
			return true;
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			log.warn(CommonLogUtil.makeWarnHead(GatherUtil.MODULE_NAME, "SendData2Cdrc", "sent2Cdrc")+"analysisLogContent Error!", e);
			return false;
		} finally {
			Profiler.registerInfoEnd(callerInfo);
		}
	}
}
