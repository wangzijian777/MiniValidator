

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.jd.cloudeye.cscp.gather.Center.SendData2Cdrc;


/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2011-6-17
 * Time: 16:47:56
 * To change this template use File | Settings | File Templates.
 */
public class RestFulClient {
	private SendData2Cdrc sendData2Cdrc;
	@Before
	public void init()
	{
		String path = RestFulClient.class.getResource("/").getPath();
		ApplicationContext context = new FileSystemXmlApplicationContext("classpath:applicationContext.xml");
		sendData2Cdrc = (SendData2Cdrc) context.getBean("sendData2Cdrc");
	}
	
	@Test
	public void testSend2Crdc()
	{
		System.out.println(sendData2Cdrc.sent2Cdrc());
	}
}