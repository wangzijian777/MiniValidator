package com.jd.jdce.test;

import java.lang.management.ManagementFactory;

import java.net.InetAddress;
import java.net.URLDecoder;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.util.List;

import com.sun.management.OperatingSystemMXBean;

/**
 * JVM 信息获取器的本地实现（运行于JVM内部）
 * 
 * @author chenhualiang
 * @since 2013-01-28
 * @see JvmInfoPicker,RuntimeMXBean,OperatingSystemMXBean,MemoryMXBean,ThreadMXBean,ClassLoadingMXBean,System
 */
public class LocalJvmInfoPicker {
	
	/**
	 * 双引号
	 */
	private static final String QUOTATION = "\"";
	
	/**
	 * 冒号
	 */
	private static final String COLON  = ":";
	
	/**
	 * 逗号
	 */
	private static final String COMMA   = ",";
	
	/**
	 * jvm环境信息最大长度 
	 */
	private static final int MAX_JVM_INFO_LENGTH = 512;
	
	/**
	 * 最近一次更新cpu使用率的时间 
	 */
	private long uptime;
	
	/**
	 * 最近一次更新cpu使用使用的时间
	 */
	private long processCpuTime;
	
	/**
	 * 启动路径 
	 */
	private String startPath;
	
	/**
	 * 工程路径 
	 */
	private String appPath;
	
	/**
	 * 启动参数 
	 */
	private String args;
	
	/**
	 * JVM 信息获取器的本地实现 的单利
	 */
	private static LocalJvmInfoPicker instance = new LocalJvmInfoPicker();
	
	/**
	 * 构造方法 
	 */
	private LocalJvmInfoPicker()
	{
		init();
	}
	
	/**
	 * 初始化方法 
	 */
	private void init()
	{
		//初始化，项目启动路径和项目路径,以及启动参数
		pickJvmEnvironmentInfo();
	}
	
	/**
	 * 获取JVM 信息获取器的本地实现 的单利
	 * 
	 * @return JVM信息获取器的本地实现 的单利
	 * 
	 * @author chenhualiang
	 */
	public static LocalJvmInfoPicker getInstance()
	{
		return instance;
	}
	
	/**
	 * 获取体系结构
	 */
	public String getOSarch() {
		return System.getProperties().getProperty("os.arch");
	}

	/**
	 * 获取操作系统名称
	 */
	public String getOSName() {
		return System.getProperties().getProperty("os.name");
	}

	/**
	 * 操作系统的体制
	 */
	public String getSystemModel() {
		return System.getProperties().getProperty("sun.arch.data.model");
	}

	/**
	 * 库路径
	 */
	public String getLibPath() {
		return System.getProperties().getProperty("java.library.path");
	}

	/**
	 * jre的版本号
	 */
	public String getJREVersion() {
		return System.getProperties().getProperty("java.version");
	}

	/**
	 * 类路径
	 */
	public String getClassPath() {
		return ManagementFactory.getRuntimeMXBean().getClassPath();
	}

	/**
	 * 引导类路径
	 */
	public String getBootClassPath() {
		return ManagementFactory.getRuntimeMXBean().getBootClassPath();
	}

	/**
	 * 线程个数峰值
	 */
	public long getPeakThreadCount() {
		return ManagementFactory.getThreadMXBean().getPeakThreadCount();
	}

	/**
	 * 活动线程个数
	 */
	public long getThreadCount() {
		return ManagementFactory.getThreadMXBean().getThreadCount();
	}

	/**
	 * 守护线程个数
	 */
	public long getDaemonThreadCount() {
		return ManagementFactory.getThreadMXBean().getDaemonThreadCount();
	}

	/**
	 * 获取当前进程的PID
	 */
	public int getPid() {
		String name = ManagementFactory.getRuntimeMXBean().getName();
		try {
			return Integer.parseInt(name.substring(0, name.indexOf('@')));
		} catch (Exception e) {
			return -1;
		}
	}

	/**
	 * cpu个数
	 */
	public int getAvailableProcessors() {
		return ManagementFactory.getOperatingSystemMXBean().getAvailableProcessors();
	}

	/**
	 * 获取jre供应商
	 */
	public String getJREVendor() {
		return System.getProperties().getProperty("java.vm.vendor");
	}

	/**
	 * jvm参数
	 * 
	 * 只获取第一个参数
	 */
	public String getInputArguments() {
		if(this.args != null)
		{
			return this.args;
		}
		List<String> argList = ManagementFactory.getRuntimeMXBean().getInputArguments();
		if(argList == null || argList.isEmpty())
		{
			return this.args = "";
		}
		else
		{
			return this.args = argList.get(0);
		}
	}

	/**
	 * 最大物理内存
	 */
	public long getTotalPhysicalMemorySize() {
		OperatingSystemMXBean osbean = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
		return osbean.getTotalPhysicalMemorySize();
	}

	/**
	 * 分配的虚拟内存
	 */
	public long getCommittedVirtualMemorySize() {
		OperatingSystemMXBean osbean = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
		return osbean.getCommittedVirtualMemorySize();
	}

	/**
	 * 交换空间总量
	 */
	public long getTotalSwapSpaceSize() {
		OperatingSystemMXBean osbean = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
		return osbean.getTotalSwapSpaceSize();
	}

	/**
	 * 当前类已装入个数
	 */
	public long getLoadedClassCount() {
		return ManagementFactory.getClassLoadingMXBean().getLoadedClassCount();
	}

	/**
	 * 已装入类的总数
	 */
	public long getTotalLoadedClassCount() {
		return ManagementFactory.getClassLoadingMXBean().getTotalLoadedClassCount();
	}

	/**
	 * 已卸载类的总数
	 */
	public long getUnloadedClassCount() {
		return ManagementFactory.getClassLoadingMXBean().getUnloadedClassCount();
	}
	
	/**
	 * 获取堆栈内存大小 
	 */
	public long getHeapMemoryUsage()
	{
		try{
			return ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed();
		}catch (Throwable e) {
			//极端情况或JVM内部BUG会导致该处异常或错误
			return 0l;
		}
	}
	
	/**
	 * 获取非堆栈内存大小 
	 */
	public long getNonHeapMemoryUsage()
	{
		try{
			return ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage().getUsed();
		}catch (Throwable e) {
			//极端情况或JVM内部BUG会导致该处异常或错误
			return 0l;
		}
	}
	
	/**
	 * 获取最大堆栈内存大小 
	 */
	public long getMaxHeapMemoryUsage()
	{
		try{
			return ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getMax();
		}catch (Throwable e) {
			//极端情况或JVM内部BUG会导致该处异常或错误
			return 0l;
		}
	}
	
	/**
	 * 获取最大非堆栈内存大小 
	 */
	public long getMaxNonHeapMemoryUsage()
	{
		try{
			return ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage().getMax();
		}catch (Throwable e) {
			//极端情况或JVM内部BUG会导致该处异常或错误
			return 0l;
		}
	}
	
	/**
	 * 工程路径（web）
	 * classes路径 （worker）
	 */
	public String getApplicationPath()
	{
		if(appPath != null)
		{
			return appPath;
		}
		String classPath = URLDecoder.decode(this.getClass().getClassLoader().getResource("").getPath());
		classPath = classPath.replaceAll("\\\\", "/");
		if(classPath.matches(".*(/|\\\\)WEB-INF(/|\\\\)classes(/|\\\\)$"))
		{
			//去掉web工程class路径的后面的/WEB-INF/classes/
			return appPath = classPath.replaceAll("(/|\\\\)WEB-INF(/|\\\\)classes(/|\\\\)$", "");
		}
		else
		{
			return appPath = classPath;
		}
	}
	
	/**
	 * 获取host name 
	 */
	public String getHostName() {
		if (System.getenv("COMPUTERNAME") != null) {
			return System.getenv("COMPUTERNAME");
		} else {
			try {
				return (InetAddress.getLocalHost()).getHostName();
			} catch (UnknownHostException uhe) {
				String host = uhe.getMessage();
				if (host != null) {
					int colon = host.indexOf(':');
					if (colon > 0) {
						return host.substring(0, colon);
					}
				}
				return "UnknownHost";
			}
		}
	}
	
	/**
	 * 启动路径
	 */
	public String getStartPath()
	{
		if(startPath != null)
		{
			return startPath;
		}
		startPath = System.getProperties().get("user.dir").toString();
		startPath = startPath.replaceAll("\\\\", "/");
		return startPath;
	}
	
	/**
	 * 获取JVM占cpu的百分比 
	 * 
	 * 本百分比值为：
	 * 上一次计算结束到现在 的cpu使用率
	 * 
	 * 注意第一次执行 始终为0.0；
	 * 第二次执行才可以计算出第一次到第二次执行之间平均cpu使用率
	 */
	public String getCpu() {
		OperatingSystemMXBean osbean = (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
		long uptimeNow = ManagementFactory.getRuntimeMXBean().getUptime();
		long processCpuTimeNow = osbean.getProcessCpuTime();
		String cpu = "0.0";
		//false:第一次运行;true:上一次调用时间到当前时间，cpu使用率计算 
		if(uptime > 0 && processCpuTime > 0)
		{
			//与上一次调用的时时间差(单位：毫秒)
			long l2 = uptimeNow -  uptime;
			//上一次调用到本次调用， cpu被JVM使用的时间(单位：纳秒)
			long l1 = processCpuTimeNow - processCpuTime;
			if(l2 > 0)
			{
				//result = cpu的耗时 / 时间段的时间差 * (单位换算 / 100.0,这里算出来是10000.0) * cpu个数
				float cpuValue = Math.min(99.0F, (float)l1 / ((float)l2 * 10000.0F * osbean.getAvailableProcessors()));
				//精确到小数点后3位,必须包含一位小数
				DecimalFormat df = new DecimalFormat("##0.0##"); 
				cpu = df.format(cpuValue);
			}
		}
		uptime = uptimeNow;
		processCpuTime = processCpuTimeNow;
		return cpu;
	}

	public String pickJvmEnvironmentInfo() {
		String jvmEI = getJvmEnvironmentInfo();
		int jvmInfoLength = jvmEI.length();
		if(jvmInfoLength > MAX_JVM_INFO_LENGTH)
		{
			//截取启动路径
			String startPathTemp = startPath.replaceAll(".*(/|\\\\)", "");
			//截取工程路径
			String appPathTemp = appPath.replaceAll(".*(/|\\\\)", "");
			int temp = startPath.length() + appPath.length() - startPathTemp.length() - appPathTemp.length();
			int argsLength = args.length();
			//只需要截取启动路径和工程路径
			if(temp > jvmInfoLength - MAX_JVM_INFO_LENGTH)
			{
				startPath = startPathTemp;
				appPath = appPathTemp;
				//从新获取JVM环境信息
				return getJvmEnvironmentInfo();
			}
			//需要截取启动路径、工程路径和参数
			else if(temp + argsLength > jvmInfoLength - MAX_JVM_INFO_LENGTH)
			{
				startPath = startPathTemp;
				appPath = appPathTemp;
				//启动参数全截取
				args = "";
				//从新获取JVM环境信息
				return getJvmEnvironmentInfo();
			}
			//任然超长
			else
			{
				return "JVM环境信息长度超过允许采集最大长度:" + MAX_JVM_INFO_LENGTH;
			}
		}
		return jvmEI;
	}
	
	/**
	 * 获取JVM环境信息（json） 
	 */
	private String getJvmEnvironmentInfo()
	{
		StringBuilder sb = new StringBuilder("{");
		//当前进程的PID
		sb.append(QUOTATION).append("PId").append(QUOTATION).append(COLON).append(QUOTATION).append(getPid()).append(QUOTATION).append(COMMA);
		//jre的版本号
		sb.append(QUOTATION).append("JREV").append(QUOTATION).append(COLON).append(QUOTATION).append(getJREVersion()).append(QUOTATION).append(COMMA);
		//jvm参数
		sb.append(QUOTATION).append("args").append(QUOTATION).append(COLON).append(QUOTATION).append(getInputArguments()).append(QUOTATION).append(COMMA);
		//最大物理内存
		sb.append(QUOTATION).append("TPMS").append(QUOTATION).append(COLON).append(QUOTATION).append(getTotalPhysicalMemorySize()).append(QUOTATION).append(COMMA);
		//启动路径
		sb.append(QUOTATION).append("SP").append(QUOTATION).append(COLON).append(QUOTATION).append(getStartPath()).append(QUOTATION).append(COMMA);
		//工程路径
		sb.append(QUOTATION).append("AP").append(QUOTATION).append(COLON).append(QUOTATION).append(getApplicationPath()).append(QUOTATION).append(COMMA);
		//交换空间总量
		sb.append(QUOTATION).append("TSSS").append(QUOTATION).append(COLON).append(QUOTATION).append(getTotalSwapSpaceSize()).append(QUOTATION).append(COMMA);
		//分配的虚拟内存
		sb.append(QUOTATION).append("CVMS").append(QUOTATION).append(COLON).append(QUOTATION).append(getCommittedVirtualMemorySize()).append(QUOTATION);
		sb.append("}");
		return sb.toString();
	}

	public String pickJvmRumtimeInfo() {
		StringBuilder sb = new StringBuilder("{");
		//线程个数峰值
		sb.append(QUOTATION).append("PTC").append(QUOTATION).append(COLON).append(QUOTATION).append(getPeakThreadCount()).append(QUOTATION).append(COMMA);
		//活动线程个数
		sb.append(QUOTATION).append("TC").append(QUOTATION).append(COLON).append(QUOTATION).append(getThreadCount()).append(QUOTATION).append(COMMA);
		//守护线程个数
		sb.append(QUOTATION).append("DTC").append(QUOTATION).append(COLON).append(QUOTATION).append(getDaemonThreadCount()).append(QUOTATION).append(COMMA);
		//当前类已装入个数
		sb.append(QUOTATION).append("LCC").append(QUOTATION).append(COLON).append(QUOTATION).append(getLoadedClassCount()).append(QUOTATION).append(COMMA);
		//已装入类的总数
		sb.append(QUOTATION).append("TLCC").append(QUOTATION).append(COLON).append(QUOTATION).append(getTotalLoadedClassCount()).append(QUOTATION).append(COMMA);
		//已卸载类的总数
		sb.append(QUOTATION).append("UCC").append(QUOTATION).append(COLON).append(QUOTATION).append(getUnloadedClassCount()).append(QUOTATION).append(COMMA);
		//获取非堆栈内存大小 
		sb.append(QUOTATION).append("NHMU").append(QUOTATION).append(COLON).append(QUOTATION).append(getNonHeapMemoryUsage()).append(QUOTATION).append(COMMA);
		//获取堆栈内存大小
		sb.append(QUOTATION).append("HMU").append(QUOTATION).append(COLON).append(QUOTATION).append(getHeapMemoryUsage()).append(QUOTATION).append(COMMA);
		//获取最大非堆栈内存大小 
		sb.append(QUOTATION).append("MNHMU").append(QUOTATION).append(COLON).append(QUOTATION).append(getMaxNonHeapMemoryUsage()).append(QUOTATION).append(COMMA);
		//获取最大堆栈内存大小
		sb.append(QUOTATION).append("MHMU").append(QUOTATION).append(COLON).append(QUOTATION).append(getMaxHeapMemoryUsage()).append(QUOTATION).append(COMMA);
		//JVM占cpu的百分比 
		sb.append(QUOTATION).append("CPU").append(QUOTATION).append(COLON).append(QUOTATION).append(getCpu()).append(QUOTATION);
		return sb.append("}").toString();
	}

	public int getJvmInstanceCode() {
		return Math.abs((getHostName() + getStartPath() + getApplicationPath()).hashCode());
	}
	
	public static void main(String[] args) {
		final LocalJvmInfoPicker dd = new LocalJvmInfoPicker();
		new Thread(){
			@Override
			public void run() {
				
				while(true)
				{
					System.out.println(dd.pickJvmRumtimeInfo());
					try {
						sleep(5000L);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}.start();
		Object o = new Object();
		synchronized (o) {
			try {
				o.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
