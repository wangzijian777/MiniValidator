package com.jd.jdce.test;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class HttpTest {
	
	
	private static final String path = "E:/svn/branches/program/jd_cloudeye_ServiceCenterPlatform_1.0/CscpServices/ServiceInterface/src/test/resources/";
	
	public static void main(String[] args) throws IOException {
//		consistency.token=f50f0eb42a8b128e0837b9cb1764cb04
//		as.token=a99465917fb1ccc54455efa355ae81dc
//		aliveState.token=8102b22a5e81e840176d9f381ec6f837
		StringBuilder headerSB = new StringBuilder();
		StringBuilder bodySB = new StringBuilder();
		readFile(headerSB, path + "header.txt");
		readFile(bodySB,  path + "body.txt");
		String uri = "";
//		uri = "http://10.28.176.21:80/csc/queryAliveState";//EC2存活状态查询（CSP）
//		uri = "http://127.0.0.1:8080/CscpServiceCenter/consistency";//同步接口（CSP）
		uri = "http://10.23.54.166:8080/CscpServiceCenter/consistency";//同步接口（CSP）
//		uri = "http://10.28.164.106:8080/CscpServiceCenter/consistencyAll";//同步接口（CSP）
//		uri = "http://192.168.192.153:8080/CscpServiceCenter/consistency";//同步接口（CSP）
//		uri = "http://127.0.0.1:8080/CscpServiceCenter/asQuery";//as查询（CSP）
//		uri = "http://10.23.54.166:8080/CscpServiceCenter/asQuery";//as查询（CSP）
//		uri = "http://10.28.176.21:80/csc/asQuery";//数据采集（CDRP）
//		uri = "";
		String[] headerItem = headerSB.toString().split("\\&");
		List<String[]> headerList = new ArrayList<String[]>();
		for(String item : headerItem)
		{
			String[] itemArray = item.split("\\=");
			if(itemArray.length == 2)
			{
				headerList.add(itemArray);
			}
		}
		String ret = SimpleHttpClient.httpPostText(uri, bodySB.toString(), headerList.toArray(new String[10][10]), "utf-8");
		System.out.println(ret);
	}
	
	private static void readFile(StringBuilder sb,String fileName)
	{
		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		try{
			fis = new FileInputStream(fileName);
			isr = new InputStreamReader(fis);
			br = new BufferedReader(isr);
			String line = null;
			boolean sign = false;
			while((line = br.readLine()) != null)
			{
				line = line.trim();
				if(line.startsWith("#") || line.startsWith("//"))
				{			
					continue;
				}
				int index = 0;
				if(!sign)
				{
					line = line.replaceAll("(/\\*)(.*)(\\*/)", "");
					index = line.indexOf("/*");
					if(index != -1)
					{
						line = line.substring(0,index);
						sign = true;
					}
					else
					{
						sign = false;
					}
				}
				else
				{
					index = line.indexOf("*/");
					if(index != -1)
					{
						line = line.substring(index + 2,line.length());
					}
					else
					{
						continue;
					}
					line = line.replaceAll("(/\\*)(.*)(\\*/)", "");
					index = line.indexOf("/*");
					if(index != -1)
					{
						line = line.substring(0,index);
						sign = true;
					}
					else
					{
						sign = false;
					}
				}
				sb.append(line);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
			if(fis != null)
			{
				try {
					fis.close();
				} catch (IOException e) {
				}
			}
			if(isr != null)
			{
				try {
					isr.close();
				} catch (IOException e) {
				}
			}
			if(br != null)
			{
				try {
					br.close();
				} catch (IOException e) {
				}
			}
		}
	}

}
