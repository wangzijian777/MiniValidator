package com.jd.jdce.test;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.jd.cloudeye.cscp.service.model.ASQuery;
import com.jd.cloudeye.cscp.service.model.AliveStateQuery;
import com.jd.cloudeye.cscp.service.model.CloudQuery;
import com.jd.cloudeye.cscp.service.model.Metrics;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

public class ELBCilent {
	
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
	
	private static final int EC2 = 1;

	private static final int ELB = 2;
	
	private static final int Cache = 3;
	
	private static final int AS = 4;

	private static final int EBS = 5;

	private static final int JDS = 6;
	
	private static final int JSS = 7;
	
	private static final int EC2ALive = 9;
	
	private static final String AS_TOKEN = "a99465917fb1ccc54455efa355ae81dc";
	
	private static final String ALIVESTATE_TOKEN = "8102b22a5e81e840176d9f381ec6f837";
	
	public static void main(String[] args) {
		
		int sgin = ELB;
		
		switch (sgin) {
		case EC2:
			testEC2();
			break;
		case ELB:
			testELB();
			break;
		case Cache:
			testCache();
			break;
		case AS:
			testAS();
			break;
		case EBS:
			testEBS();
			break;
		case JDS:
			testJDS();
			break;
		case JSS:
			testJSS();
			break;
		case EC2ALive:
			testEC2ALive();
			break;
		default:
			break;
		}
	}
	
	//method=create&userId=jduser&serviceType=AS&clusterId=15&clusterName=assda&instanceId=2A-Bc2DF&intanceName=192.168.20.107&eventTime=20130311163114231
	private static void testEC2()
	{
		try {
			String ret = SimpleHttpClient.httpPostText(//POST
					"http://127.0.0.1:8080/CscpServiceCenter/consistency",//URI
//					"http://10.28.176.55:8080/CscpServiceCenter/consistency",//URI
					new String[][]{//parameters
						{"method","create"},
						{"userId","baiyunqitest"},
						{"serviceType","EC2"},
						{"clusterId",""},
						{"clusterName",""},
						{"instanceId","EC2_001,EC2_002"},
						{"instanceName","EC2_001,EC2_002"},
						{"eventTime",sdf.format(new Date())}
					},
					new String[][]{{"token","f50f0eb42a8b128e0837b9cb1764cb04"}},//headers -- token
					"utf-8");//character set
			System.out.println(ret);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static void testJSS()
	{
		try {
			String ret = SimpleHttpClient.httpPostText(//POST
					"http://127.0.0.1:8080/CscpServiceCenter/consistency",//URI
//					"http://10.28.176.55:8080/CscpServiceCenter/consistency",//URI
					new String[][]{//parameters
						{"method","update"},
						{"userId","baiyunqitest"},
						{"serviceType","JSS"},
						{"clusterId",""},
						{"clusterName",""},
						{"instanceId",""},
						{"instanceName",""},
						{"eventTime",sdf.format(new Date())}
					},
					new String[][]{{"token","f50f0eb42a8b128e0837b9cb1764cb04"}},//headers -- token
					"utf-8");//character set
			System.out.println(ret);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static void testELB()
	{

		
		try {
			String ret = SimpleHttpClient.httpPostText(//POST
//					"http://10.28.176.55:8080/CscpServiceCenter/consistency",//URI
					"http://192.168.192.150:8080/CscpServiceCenter/consistency",//URI"/CscpServiceCenter/consistency 
//					"http://10.28.170.58:80/CscpServiceCenter/consistency",//URI"/CscpServiceCenter/consistency 

					new String[][]{//parameters
						{"method","create"},
						{"userId","hoopy"},
						{"serviceType","AS"},
						{"clusterId","19"},
						{"clusterName","cagent-test"},
						{"instanceId","34-Bc4DF"},
						{"instanceName","hoopy-01"},
						{"eventTime",sdf.format(new Date())}
					},
					new String[][]{{"token","f50f0eb42a8b128e0837b9cb1764cb04"}},//headers -- token
					"utf-8");//character set
			System.out.println(ret);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void testEBS()
	{
		try {
			String ret = SimpleHttpClient.httpPostText(//POST
//					"http://10.28.176.55:8080/CscpServiceCenter/consistency",//URI
					"http://127.0.0.1:8080/CscpServiceCenter/consistency",//URI"/CscpServiceCenter/consistency 
//					"http://10.28.170.58:80/CscpServiceCenter/consistency",//URI"/CscpServiceCenter/consistency 
					"method=create&userId=baiyunqitest&serviceTye=EBS&instanceId=46a66acb-514e-450b-b316-fc933970eee1&instanceName=972123&eventTime=20130314105032734",
//					new String[][]{//parameters
//							{"method","create"},
//							{"userId","baiyunqitest"},
//							{"serviceType","Cache"},
////						{"clusterId","elb001"},
////						{"clusterName","elb001"},
//							{"instanceId","001"},
//							{"instanceName","mycache1"},
//							{"eventTime",sdf.format(new Date())}
//					},
					new String[][]{{"token","f50f0eb42a8b128e0837b9cb1764cb04"}},//headers -- token
			"utf-8");//character set
			System.out.println(ret);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void testCache()
	{

		
		try {
			String ret = SimpleHttpClient.httpPostText(//POST
//					"http://10.28.176.55:8080/CscpServiceCenter/consistency",//URI
					"http://10.28.170.58:80/CscpServiceCenter/consistency",//URI
					new String[][]{//parameters
						{"method","create"},
						{"userId","baiyunqitest"},
						{"serviceType","AS"},
						{"clusterId","AS001"},
						{"clusterName","AS001"},
						{"instanceId","QAZXSWEDC"},
						{"instanceName","my_EC2_01"},
						{"eventTime",sdf.format(new Date())}
					},
					new String[][]{{"token","f50f0eb42a8b128e0837b9cb1764cb04"}},//headers -- token
					"utf-8");//character set
			System.out.println(ret);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void testJDS()
	{

		
		try {
			String ret = SimpleHttpClient.httpPostText(//POST
//					"http://10.28.176.55:8080/CscpServiceCenter/consistency",//URI
					"http://127.0.0.1:8080/CscpServiceCenter/consistency",//URI
//					"http://10.28.170.58:80/CscpServiceCenter/consistency",//URI
//					"method=update&userId=baiyunqitest&serviceType=JDS&eventTime=20130314113711000&instanceId=2013&intanceName=中文测试_修改名称",
					new String[][]{//parameters
						{"method","update"},
						{"userId","baiyunqitest"},
						{"serviceType","JDS"},
						{"clusterId",""},
						{"clusterName",""},
						{"instanceId","77"},
						{"instanceName","中文正文"},
						{"eventTime",sdf.format(new Date())}
					},
					new String[][]{{"token","f50f0eb42a8b128e0837b9cb1764cb04"}},//headers -- token
					"utf-8");//character set
			System.out.println(ret);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void testEC2ALive()
	{
		AliveStateQuery query = new AliveStateQuery();
		query.setRequestTime(CSCPFaceServiceUtil.getTimeOfNow(CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT));
		query.setServiceType("EC2");
		List<String> instanceIds = new ArrayList<String>();
		query.setInstanceIds(instanceIds);
		instanceIds.add("QAZXSWEDC");
		try {
			String ret = SimpleHttpClient.httpPostText(//POST
//					"http://10.28.170.58:80/CscpServiceCenter/asQuery",//URI
					"http://10.28.176.55:8080/CscpServiceCenter/queryAliveState",//URI
//					"http://127.0.0.1:80/CscpServiceCenter/queryAliveState",//URI
//					"{\"Data\":[{\"ASGroupID\":\"1\",\"MetricsData\":[{\"Computor\":\"avg\",\"Metrics\":\"EC2_CPUtilization\"}]}],\"Period\":\"1\",\"TimeInterval\":\"1\"} ",
					JSONObject.toJSONString(query),
					new String[][]{{"token",ALIVESTATE_TOKEN}},//headers -- token
					"utf-8");//character set
			System.out.println(ret);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void testAS()
	{

		ASQuery query = new ASQuery();
		query.setPeriod("d1");
		query.setTimeInterval("3d");
		CloudQuery cloudQuery = new CloudQuery(); 
		List<CloudQuery> data = new ArrayList<CloudQuery>();
		query.setData(data);
		data.add(cloudQuery);
		cloudQuery.setASGroupID("AS001");
		List<Metrics> metricsData = new ArrayList<Metrics>();
		cloudQuery.setMetricsData(metricsData);
		Metrics metric = new Metrics();
		metricsData.add(metric);
		metric.setComputor("sum");
		metric.setMetrics("EC2_MemAvailable");
		try {
			String ret = SimpleHttpClient.httpPostText(//POST
//					"http://10.28.170.58:80/CscpServiceCenter/asQuery",//URI
//					"http://10.28.176.55:8080/CscpServiceCenter/asQuery",//URI
					"http://127.0.0.1:8080/CscpServiceCenter/asQuery",//URI
//					"{\"Data\":[{\"ASGroupID\":\"1\",\"MetricsData\":[{\"Computor\":\"avg\",\"Metrics\":\"EC2_CPUtilization\"}]}],\"Period\":\"1\",\"TimeInterval\":\"1\"} ",
					JSONObject.toJSONString(query),
					new String[][]{{"token",AS_TOKEN}},//headers -- token
					"utf-8");//character set
			System.out.println(ret);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
