package com.jd.cloudeye.cscp.service.model;

import java.util.Date;

/**
 * 服务实例信息 
 */
public class ServerInstanceInfo {
	
	/**
	 * 自增id
	 */
	private long id;
	
	/**
	 * 用户ID
	 */
	private String userId;
	
	/**
	 * 服务类型
	 */
	private String serviceType;
	
	/**
	 * 实例ID
	 */
	private String instanceId;
	
	/**
	 * 实例名称
	 */
	private String instanceName;
	
	/**
	 * 事件时间
	 */
	private Date eventTime;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public Date getEventTime() {
		return eventTime;
	}

	public void setEventTime(Date eventTime) {
		this.eventTime = eventTime;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

}
