package com.jd.cloudeye.cscp.service.model;

/**
 * 被删除的服务实例 
 */
public class DeleteInstance {
	
	/**
	 * 自增id 
	 */
	private long id;
	
	/**
	 * 实例id 
	 */
	private String instanceId;
	
	/**
	 * 服务类型 
	 */
	private String serviceType;
	
	/**
	 * 用户id 
	 */
	private String userId;
	
	public DeleteInstance(long id,String instanceId,String serviceType,String userId)
	{
		this.id = id;
		this.instanceId = instanceId;
		this.serviceType = serviceType;
		this.userId = userId;
	}
	
	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
