package com.jd.cloudeye.cscp.service.model;

import java.util.ArrayList;

import java.util.List;

/**
 * AS查询结果
 */
public class ASResult {
	
	/**
	 * 状态 
	 */
	private String state;
	
	/**
	 * 状态描述 
	 */
	private String message;
	
	/**
	 * 反馈时间
	 */
	private String responseTime ;
	
	/**
	 * 反馈结果集合 
	 */
	private List<CloudResult> data = new ArrayList<CloudResult>();
	
	public void addResult(CloudResult result)
	{
		data.add(result);
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}

	public List<CloudResult> getData() {
		return data;
	}

	public void setData(List<CloudResult> data) {
		this.data = data;
	}
}
