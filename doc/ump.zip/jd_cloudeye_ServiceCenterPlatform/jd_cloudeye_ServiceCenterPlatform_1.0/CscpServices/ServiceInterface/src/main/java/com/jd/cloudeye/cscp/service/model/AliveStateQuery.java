package com.jd.cloudeye.cscp.service.model;

import java.util.List;

/**
 * 实例存活查询请求 POJO
 * 
 * @author chenhualiang
 * @since 2013-03-10
 */
public class AliveStateQuery {
	
	/**
	 * 用户ID 
	 */
	private String userId;
	
	/**
	 * 服务类型
	 */
	private String serviceType;
	
	/**
	 * 请求时间
	 */
	private String requestTime;

	/**
	 * 查询实例 
	 */
	private List<String> instanceIds;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}

	public List<String> getInstanceIds() {
		return instanceIds;
	}

	public void setInstanceIds(List<String> instanceIds) {
		this.instanceIds = instanceIds;
	}
	
}
