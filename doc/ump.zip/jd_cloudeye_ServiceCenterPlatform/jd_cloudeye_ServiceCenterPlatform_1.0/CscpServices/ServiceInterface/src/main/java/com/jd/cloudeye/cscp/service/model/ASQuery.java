package com.jd.cloudeye.cscp.service.model;

import java.util.ArrayList;
import java.util.List;

/**
 * AS请求 
 */
public class ASQuery {
	
	/**
	 * 时间间隔
	 */
	private String Period;
	
	/**
	 * 多少个时间频率
	 */
	private String TimeInterval;
	
	/**
	 * 请求的集群集合 
	 */
	private List<CloudQuery> Data = new ArrayList<CloudQuery>();

	public String getPeriod() {
		return Period;
	}

	public void setPeriod(String period) {
		Period = period;
	}

	public String getTimeInterval() {
		return TimeInterval;
	}

	public void setTimeInterval(String timeInterval) {
		TimeInterval = timeInterval;
	}

	public List<CloudQuery> getData() {
		return Data;
	}

	public void setData(List<CloudQuery> data) {
		Data = data;
	}
	
}