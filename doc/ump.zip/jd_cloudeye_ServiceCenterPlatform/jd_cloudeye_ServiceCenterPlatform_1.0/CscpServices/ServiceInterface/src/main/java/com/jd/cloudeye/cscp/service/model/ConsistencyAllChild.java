package com.jd.cloudeye.cscp.service.model;

import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

/**
 * 全量同步子实例信息 
 */
public class ConsistencyAllChild {
	
	/**
	 * 实例ID 
	 */
	private String childId;
	
	/**
	 * 实例名称 
	 */
	private String childName;

	public String getChildId() {
		return childId;
	}

	public void setChildId(String childId) {
		this.childId = CSCPFaceServiceUtil.getStringFromObject(childId);
	}

	public String getChildName() {
		return childName;
	}

	public void setChildName(String childName) {
		this.childName = CSCPFaceServiceUtil.getStringFromObject(childName);
	}
	
}