package com.jd.cloudeye.cscp.service.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * http工具类  2013-05-08
 */
public class SimpleHttpClient{

	/**
	 * 发送post请求
	 */
	public static String httpPostText(String uri,String[][] parameters,String[][] headers,String charset) throws IOException{
	    if(charset == null)
        {
            charset = "UTF8";
        }
	    StringBuilder content = new StringBuilder();
		InputStream in = null;
		InputStreamReader isr = null;
		HttpURLConnection conn = null;
		boolean success = false;
		try{
			if(parameters != null && parameters.length > 0)
			{
				readParameters(parameters, content, null);
			}
			URL url = new URL(uri);
			conn = (HttpURLConnection) url.openConnection();
			setHeader(conn, headers);
			conn.setConnectTimeout(60000);
			conn.setUseCaches(false);
			HttpURLConnection.setFollowRedirects(true);   
			conn.setInstanceFollowRedirects(true);
			conn.setRequestProperty("Charset", charset); 
//			conn.setRequestProperty("Content-Type", "application/json"); 
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			doOutput(conn, content.toString().getBytes());
			content.delete(0, content.length());
			in = conn.getInputStream();
			isr = new InputStreamReader(in,charset);
			readInputStream(isr, content);
			success = true;
		}catch (IOException e) {
			throw e;
		}
		finally
		{
			if(in != null)
			{
				in.close();
			}
			if(isr != null)
			{
				isr.close();
			}
			if(conn != null)
			{
				conn.disconnect();
			}
		}
		if(success)
		{
			return content.toString();
		}
		else
		{
			return "";
		}
	}
	
	/**
	 * 发送post请求
	 */
	public static String httpPostText(String uri,String body,String[][] headers,String charset) throws IOException{
	    if(charset == null)
        {
            charset = "UTF8";
        }
	    StringBuilder content = new StringBuilder();
		InputStream in = null;
		InputStreamReader isr = null;
		HttpURLConnection conn = null;
		boolean success = false;
		try{
			if(body != null && body.length() > 0)
			{
				content.append(body);
			}
			URL url = new URL(uri);
			conn = (HttpURLConnection) url.openConnection();
			setHeader(conn, headers);
			conn.setConnectTimeout(60000);
			conn.setUseCaches(false);
			HttpURLConnection.setFollowRedirects(true);   
			conn.setInstanceFollowRedirects(true);
			conn.setRequestProperty("Charset", charset); 
//			conn.setRequestProperty("Content-Type", "application/json"); 
			conn.setDoInput(true);
			conn.setRequestMethod("POST");
			doOutput(conn, content.toString().getBytes());
			content.delete(0, content.length());
			in = conn.getInputStream();
			isr = new InputStreamReader(in,charset);
			readInputStream(isr, content);
			success = true;
		}catch (IOException e) {
			throw e;
		}
		finally
		{
			if(in != null)
			{
				in.close();
			}
			if(isr != null)
			{
				isr.close();
			}
			if(conn != null)
			{
				conn.disconnect();
			}
		}
		if(success)
		{
			return content.toString();
		}
		else
		{
			return "";
		}
	}
	
	/**
	 * 设置header
	 * header 中也可以包含header[0]='Cookie';header[1]=CookieValues
	 */
	private static void setHeader(HttpURLConnection conn,String[][] headers)
	{
		if(conn != null && headers != null && headers.length != 0)
		{
			for(String[] header : headers)
			{
				if(header == null || header.length != 2 || header[0] == null || header[1] == null)
				{
					continue;
				}
				conn.setRequestProperty(header[0], header[1]);
			}
		}
	}

	/**
	 * 发送get请求
	 */
	public static String httpGetText(String uri,String[][] parameters,String[][] headers,
			String charset) throws IOException{
		StringBuilder content = new StringBuilder();
		InputStream in = null;
		InputStreamReader isr = null;
		HttpURLConnection conn = null;
		boolean success = false;
		try{
			if(parameters != null && parameters.length > 0)
			{
				readParameters(parameters, content, charset);
			}
			if(charset == null)
			{
				charset = "UTF8";
			}
			URL url = new URL(uri + "?" + content.toString());
			conn = (HttpURLConnection) url.openConnection();
			setHeader(conn, headers);
			conn.setConnectTimeout(60000);
			conn.setRequestMethod("GET");
			conn.setDoInput(true);
			content.delete(0, content.length());
			in = conn.getInputStream();
			isr = new InputStreamReader(in,charset);
			readInputStream(isr, content);
			success = true;
		}catch (IOException e) {
			throw e;
		}
		finally
		{
			if(in != null)
			{
				in.close();
			}
			if(isr != null)
			{
				isr.close();
			}
			if(conn != null)
			{
				conn.disconnect();
			}
		}
		if(success)
		{
			return content.toString();
		}
		else
		{
			return "";
		}
	}
	
	/**
	 * 读流 
	 */
	private static void readInputStream(InputStreamReader isr,StringBuilder content) throws IOException
	{
		int len = 1024 ;
		char[] buffer = new char[len];
		while((len = isr.read(buffer, 0, len)) != -1)
		{
			content.append(buffer,0,len);
		}
	}
	
	/**
	 * 输出 
	 */
	private static void doOutput(HttpURLConnection conn,byte[] buffer) throws IOException
	{
		conn.setDoOutput(true);
		conn.getOutputStream().write(buffer);
		conn.getOutputStream().flush();
		conn.getOutputStream().close();
	}
	
	/**
	 * 参数处理
	 */
	private static void readParameters(String[][] parameters,StringBuilder content,String charset) throws UnsupportedEncodingException
	{
		if(parameters == null || parameters.length == 0)
		{
			return;
		}
		for(String[] param : parameters)
		{
			if(param == null || param.length != 2 || param[0] == null || param[1] == null)
			{
				continue;
			}
			if(content.length() > 0 )
			{
				content.append("&");
			}
			if(charset != null)
			{
				content.append(param[0]).append("=").append(URLEncoder.encode(param[1], charset));
			}
			else
			{
				content.append(param[0]).append("=").append(param[1]);
			}
		}
	}

}
