package com.jd.cloudeye.cscp.service.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.common.CommonConstance;
import com.jd.cloudeye.cscp.common.db.RedisManager;
import com.jd.cloudeye.cscp.service.model.ASQuery;
import com.jd.cloudeye.cscp.service.model.EC2Info;
import com.jd.cloudeye.cscp.service.model.CloudQuery;
import com.jd.cloudeye.cscp.service.model.Metrics;
import com.jd.cloudeye.cscp.service.model.Result;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

/**
 * as 查询数据访问处理类
 * 
 * @author chenhualiang
 * @since 2013-03-8
 */
@Repository("asQueryDao")
public class ASQueryDao {
	
	private static final Logger log = Logger.getLogger(ASQueryDao.class);

	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private RedisManager redisManager;
	
	/**
	 * 允许当前时间与redis延迟 时间（单位：分钟）
	 */
	@Value("${asQuery.lazzyTime}")
	private int asQueryLazzyTime;
	
	private Map<String,String> metricsCache = new HashMap<String,String>();
	
	private long metricsUpdateTime = 0;

	/**
	 * AS查询接口(数据库查询) 
	 * 
	 *  <p>
	 *  当查询的时间超过一个小时，将从mysql中查询
	 *  </p>
	 * 
	 * @param metricsMap Metrics的快速查找映射
	 * @param query 本次AS请求条件
	 * @param cloudQuery 本任务查询的集群查询条件
	 * @param instanceList 本集群下所有的EC2实例
	 * 
	 * @author chenhualiang
	 * @since 2013-03-8
	 */
	public void executeASQueryFromDB(Map<String, Metrics> metricsMap,ASQuery query,CloudQuery cloudQuery,List<EC2Info> instanceList) {
		String sql = "select jce_metrics_code as Metrics,DATE_FORMAT(jce_anly_time,'%Y%m%d%H%i') as time , " +
				"avg(jce_avg_value) as avg_value,max(jce_max_value) as max_value, " +
				"min(jce_min_value) as min_value,sum(jce_avg_value) as sum_value " +
				"from jce_ec2_dataresult_1m " +
				"where DATE_FORMAT(jce_anly_time,'%Y-%m-%d %H:%i') <= ? " +
				"and DATE_FORMAT(jce_anly_time,'%Y-%m-%d %H:%i') > ? " +
				"and jce_usin_id in ([jceUsinId]) " +
				"group by DATE_FORMAT(jce_anly_time,'%Y%m%d%H%i'),jce_metrics_code " +
				"order by DATE_FORMAT(jce_anly_time,'%Y%m%d%H%i') limit ?";
		//查询条件和sql组装
		List<Object> ragsList = new ArrayList<Object>();
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		ragsList.add(sdf.format(cal.getTime()));
		int period = Integer.parseInt(query.getPeriod());
		int timeInterval = Integer.parseInt(query.getTimeInterval());
		cal.add(Calendar.MINUTE, 0 - period * timeInterval - asQueryLazzyTime);
		ragsList.add(sdf.format(cal.getTime()));
		
		StringBuilder ids = new StringBuilder();
		for(EC2Info ec2 : instanceList)
		{
			if(ids.length() > 0 )
			{
				ids.append(",");
			}
			ids.append("?");
			ragsList.add(ec2.getInstanceID());
		}
		ragsList.add(timeInterval);
		sql = sql.replace("[jceUsinId]", ids.toString());
		if(log.isDebugEnabled())
		{
			log.debug("####as query####sql=" + sql);
			log.debug("####as query####args=" + ragsList.toString());
		}
		Object[] args = ragsList.toArray();
		//查询
		List<Map<String, Object>> retList = jdbcTemplate.queryForList(sql, args);
		if(retList != null && !retList.isEmpty())
		{
			for(Map<String, Object> line : retList)
			{
				String key = cloudQuery.getASGroupID() + "#" + line.get("Metrics").toString();
				Set<String> computorSet = CSCPFaceServiceUtil.COMPUTOR_NAME_MAP.keySet();
				for(String computorKey : computorSet)
				{
					//通过映射快速定位到Metrics
					Metrics metrics = metricsMap.get(key + "#" + computorKey);
					if(metrics == null)
					{
						continue;
					}
					//添加值
					metrics.addData(new String[]{
							line.get("time").toString(),
							line.get(CSCPFaceServiceUtil.COMPUTOR_NAME_MAP.get(computorKey)).toString()}
						);
				}
			}
		}
	}
	
	/**
	 * ELB查询接口（数据库查询）
	 * @param metricsMap
	 * @param query
	 * @param cloudQuery
	 * @param elbId
	 * @author cdxuxiaolong
	 * @date 2013-12-11
	 */
	public void executeELBQueryFromDB(Map<String, Metrics> metricsMap,ASQuery query,CloudQuery cloudQuery,EC2Info elbInfo) {
        String sql = "select jce_metrics_code as Metrics,DATE_FORMAT(jce_anly_time,'%Y%m%d%H%i') as time , " +
                "avg(jce_avg_value) as avg_value,max(jce_max_value) as max_value, " +
                "min(jce_min_value) as min_value,sum(jce_avg_value) as sum_value " +
                "from jce_elb_dataresult_1m " +
                "where DATE_FORMAT(jce_anly_time,'%Y-%m-%d %H:%i') <= ? " +
                "and DATE_FORMAT(jce_anly_time,'%Y-%m-%d %H:%i') > ? " +
                "and jce_usin_id=? " +
                "group by DATE_FORMAT(jce_anly_time,'%Y%m%d%H%i'),jce_metrics_code " +
                "order by DATE_FORMAT(jce_anly_time,'%Y%m%d%H%i') limit ?";
        //查询条件和sql组装
        List<Object> ragsList = new ArrayList<Object>();
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        ragsList.add(sdf.format(cal.getTime()));
        int period = Integer.parseInt(query.getPeriod());
        int timeInterval = Integer.parseInt(query.getTimeInterval());
        cal.add(Calendar.MINUTE, 0 - period * timeInterval - asQueryLazzyTime);
        ragsList.add(sdf.format(cal.getTime()));
        ragsList.add(elbInfo.getInstanceID());
        ragsList.add(timeInterval);
        if(log.isDebugEnabled())
        {
            log.debug("####as query####sql=" + sql);
            log.debug("####as query####args=" + ragsList.toString());
        }
        Object[] args = ragsList.toArray();
        //查询
        List<Map<String, Object>> retList = jdbcTemplate.queryForList(sql, args);
        if(retList != null && !retList.isEmpty())
        {
            for(Map<String, Object> line : retList)
            {
                String key = cloudQuery.getASGroupID() + "#" + line.get("Metrics").toString();
                Set<String> computorSet = CSCPFaceServiceUtil.COMPUTOR_NAME_MAP.keySet();
                for(String computorKey : computorSet)
                {
                    //通过映射快速定位到Metrics
                    Metrics metrics = metricsMap.get(key + "#" + computorKey);
                    if(metrics == null)
                    {
                        continue;
                    }
                    //添加值
                    metrics.addData(new String[]{
                            line.get("time").toString(),
                            line.get(CSCPFaceServiceUtil.COMPUTOR_NAME_MAP.get(computorKey)).toString()}
                        );
                }
            }
        }
    }

	/**
	 * 查询一个集群下所有的EC2实例
	 * 
	 * @param cloudQuery 集群查询条件
	 * 
	 * @return List<EC2Info> EC2集合信息
	 * 
	 * @author chenhualiang
	 * @since 2013-03-8
	 */
	public List<EC2Info> queryASCloudInfo(CloudQuery cloudQuery) {
		
		String sql = "select si1.jce_boss_user_id as userID,si1.id as instanceID,si1.jce_instance_key as instanceCode " +
				"from jce_cluster_instance as ci right join jce_service_instance as si1 on si1.id = ci.jce_instance_id " +
				"right join jce_service_instance as si2 on si2.id = ci.jce_cluster_id " +
				"where si1.is_valid = '1' and si2.is_valid = '1' and ci.is_valid = '1' and " +
				"si2.jce_service_code = 'AS' and si1.jce_service_code = 'EC2' and si2.jce_instance_key = ?";
		//查询
		List<Map<String, Object>> retList = jdbcTemplate.queryForList(sql, cloudQuery.getASGroupID());
		if(retList != null && retList.size() > 0)
		{
			//组装EC2信息
			List<EC2Info> data = new ArrayList<EC2Info>();
			for(Map<String, Object> item : retList)
			{
				EC2Info ec2 = new EC2Info();
				ec2.setCluserID(cloudQuery.getASGroupID());
				long instanceID = (Long)item.get("instanceID");
				ec2.setInstanceID(instanceID);
				String userID = CSCPFaceServiceUtil.getStringFromObject(item.get("userID"));
				if(CSCPFaceServiceUtil.isEmpty(userID))
				{
					continue;
				}
				ec2.setUserID(userID);
				String instanceCode = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceCode"));
				if(CSCPFaceServiceUtil.isEmpty(instanceCode))
				{
					continue;
				}
				ec2.setInstanceCode(instanceCode);
				data.add(ec2);
			}
			return data;
		}
		return null;
	}
	
	/**
	 * 查询AS对应的ELB的id
	 * @param cloudQuery
	 * @return
	 * @author cdxuxiaolong
	 * @date 2013-12-11
	 */
	public EC2Info queryElbIdOfAs(String asId) {
	    String sql = "select a.jce_boss_user_id as userID,a.id as instanceID,a.jce_instance_key as instanceCode from jce_service_instance a,"
	        + "jce_cluster_instance b,jce_service_instance c where a.id=b.jce_instance_id and a.jce_service_code='ELB' and b.jce_cluster_id=c.id" +
	        		" and c.jce_instance_key=? and c.jce_service_code='JECS'";
	    
	  //查询
        List<Map<String, Object>> retList = jdbcTemplate.queryForList(sql, asId);
        if(retList != null && retList.size() > 0)
        {
            //组装ELB信息
            EC2Info data = new EC2Info();
            Map<String, Object> item = retList.get(0);
            data.setCluserID(asId);
            long instanceID = (Long)item.get("instanceID");
            data.setInstanceID(instanceID);
            String userID = CSCPFaceServiceUtil.getStringFromObject(item.get("userID"));
            if(CSCPFaceServiceUtil.isEmpty(userID))
            {
                return null;
            }
            data.setUserID(userID);
            String instanceCode = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceCode"));
            if(CSCPFaceServiceUtil.isEmpty(instanceCode))
            {
                return null;
            }
            data.setInstanceCode(instanceCode);
            return data;
        }
        return null;
	}

	/**
	 * 查询EC2的所有指标 
	 */
	private List<String> queryMetricsOfEC2()
	{
		synchronized (metricsCache) {
			if(System.currentTimeMillis() - metricsUpdateTime < CSCPFaceServiceUtil.METRICS_EC2_CACHE_TIME)
			{
				//将EC2的属性过滤出来
				List<String> list = new ArrayList<String>();
				for(String key : metricsCache.keySet())
				{
					if(key.startsWith("EC2_"))
					{
						list.add(key);
					}
				}
				return list;
			}
			loadMetrics();
			//将EC2的属性过滤出来
			List<String> list = new ArrayList<String>();
			for(String key : metricsCache.keySet())
			{
				if(key.startsWith("EC2_"))
				{
					list.add(key);
				}
			}
			return list;
		}
	}
	
	/**
	 * 查询ELB的指标
	 * @return
	 * @author cdxuxiaolong
	 * @date 2013-12-11
	 */
	private List<String> queryMetricsOfElb()
    {
        synchronized (metricsCache) {
            if(System.currentTimeMillis() - metricsUpdateTime < CSCPFaceServiceUtil.METRICS_ELB_CACHE_TIME)
            {
                //将ELB的属性过滤出来
                List<String> list = new ArrayList<String>();
                for(String key : metricsCache.keySet())
                {
                    if(key.startsWith("ELB_"))
                    {
                        list.add(key);
                    }
                }
                return list;
            }
            loadMetrics();
            //将ELB的属性过滤出来
            List<String> list = new ArrayList<String>();
            for(String key : metricsCache.keySet())
            {
                if(key.startsWith("ELB_"))
                {
                    list.add(key);
                }
            }
            return list;
        }
    }
	
	/**
	 * 根据指标标示取得指标名称
	 */
	public String getMetricsName(String metricsType)
	{
		if(CSCPFaceServiceUtil.isEmpty(metricsType))
		{
			return null;
		}
		//修改线程安全问题
		String metricsName = metricsCache.get(metricsType);
		if(metricsName != null && metricsName.length() > 0)
		{
			return metricsName;
		}
		synchronized (metricsCache) {
			metricsName = metricsCache.get(metricsType);
			if(metricsName != null && metricsName.length() > 0)
			{
				return metricsName;
			}
			if(System.currentTimeMillis() - metricsUpdateTime > CSCPFaceServiceUtil.SERICE_TYPE_CACHE_TIME)
			{
				loadMetrics();
				return metricsCache.get(metricsType);
			}
			else
			{
				return null;
			}
		}
	}
	
	/**
	 * 加载指标与指标名的映射
	 */
	private void loadMetrics() {
		try{
			//修改sql，从只加载EC2修改为加载所有指标
			String sql = "select jce_dictionary_code,jce_dictionary_value from jce_dictionary";
			List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
			if(list != null && !list.isEmpty())
			{
				metricsCache.clear();
				for(Map<String, Object> item : list)
				{
					Object code = item.get("jce_dictionary_code");
					Object value = item.get("jce_dictionary_value");
					if(code != null && value != null)
					{
						metricsCache.put(code.toString(), value.toString());
					}
				}
				metricsUpdateTime = System.currentTimeMillis();
			}
		}catch (Exception e) {
			log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ASQueryDao"), e);
		}
	}

	/**
	 *  AS查询（数据来源于redis）
	 *  
	 *  <p>
	 *  当查询的时间在一个小时以内，将从redis中查询
	 *  </p>
	 *  
	 * @param metricsMap Metrics的快速查找映射
	 * @param query 本次AS请求条件
	 * @param cloudQuery 本任务查询的集群查询条件
	 * @param instanceList 本集群下所有的EC2实例
	 * 
	 * @author chenhualiang
	 * @since 2013-03-08
	 */
	public void executeASQueryFromRadis(Map<String, Metrics> metricsMap,
			ASQuery query, CloudQuery cloudQuery, List<EC2Info> instanceList) {
		//EC2的所有指标
		List<String> metrics = queryMetricsOfEC2();
		if(metrics == null || metrics.isEmpty())
		{
			return ;
		}
		int index = 0;
		int timeInterval = Integer.parseInt(query.getTimeInterval());
		int period = Integer.parseInt(query.getPeriod());
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, 0 - timeInterval * period - asQueryLazzyTime);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		Date startTime = cal.getTime();
		String startTimeStr = CSCPFaceServiceUtil.getTime(startTime, CSCPFaceServiceUtil.MINUTE_TIME_FORMAT);
		Map<String, Result> resultMap = new TreeMap<String, Result>(new Comparator<String>() {

					@Override
					public int compare(String o1, String o2) {
						return 0 - o1.compareTo(o2);
					}
		});
		for(String metric : metrics)
		{
			//过滤未查询的指标
			String tmpkey = cloudQuery.getASGroupID() + "#" + metric + "#";
			if(!(metricsMap.containsKey(tmpkey + "MAX") || 
					metricsMap.containsKey(tmpkey + "MIN") || 
					metricsMap.containsKey(tmpkey + "AVG") || 
					metricsMap.containsKey(tmpkey + "SUM")))
			{
				continue;
			}
			for(EC2Info ec2 : instanceList)
			{
				//查询redis
				StringBuilder metricsKey = new StringBuilder(CommonConstance.SERVICE_EC2);
				metricsKey.append(CommonConstance.KEY_SPLIT).append(CommonConstance.KNULL)
				        .append(CommonConstance.KEY_SPLIT).append(ec2.getInstanceCode())
				        .append(CommonConstance.KEY_SPLIT).append(metric);
				List<String> resultList = redisManager.getCacheAnalyResult(metricsKey.toString(), index, timeInterval);
				if(resultList == null || resultList.isEmpty())
				{
					continue;
				}
				for(int i = 0; i < resultList.size() ; i ++)
				{
					//解析查询结果
					String data = resultList.get(i);
					if(CSCPFaceServiceUtil.isEmpty(data) || !data.matches("[^#]+((#)[^#]+){4}"))
					{
						continue;
					}
					String[] items = data.split("#");
					double max = 0;
					double min = 0;
					double avg = 0;
					double sum = 0;
					try{
						Date  resultTime = CSCPFaceServiceUtil.getTime(items[0], CSCPFaceServiceUtil.MINUTE_TIME_FORMAT);
						if(resultTime == null || resultTime.before(startTime))
						{
							break;
						}
						max = Double.parseDouble(items[1]);
						min = Double.parseDouble(items[2]);
						avg = Double.parseDouble(items[3]);
						sum = Double.parseDouble(items[3]);
					}catch (Exception e) {
						continue;
					}
					Result result = resultMap.get(items[0]);
					if(result == null)
					{
						result = new Result(max, min, avg, sum);
						resultMap.put(items[0], result);
					}
					else{
						result.add(max, min, avg, sum);
					}
				}
			}
			List<String> timeList = new ArrayList<String>(resultMap.keySet());
			int length = timeList.size();
			length = length > timeInterval ? timeInterval : length;
			int i = 0 ;
			for(String time : timeList)
			{
				Result result = resultMap.remove(time);
				i ++ ;
				if(i > length || time.compareTo(startTimeStr) < 0)
				{
					continue;
				}
				//从映射中快速查找Metrics，并完成结果设置
				String key = cloudQuery.getASGroupID() + "#" + metric + "#";
				Metrics metricsCache = metricsMap.get(key + "MAX");
				if(metricsCache != null)
				{
					metricsCache.addData(new String[]{time,String.valueOf(result.getMax())});
				}
				metricsCache = metricsMap.get(key + "MIN");
				if(metricsCache != null)
				{
					metricsCache.addData(new String[]{time,String.valueOf(result.getMin())});
				}
				metricsCache = metricsMap.get(key + "AVG");
				if(metricsCache != null)
				{
					metricsCache.addData(new String[]{time,String.valueOf(result.getAvg())});
				}
				metricsCache = metricsMap.get(key + "SUM");
				if(metricsCache != null)
				{
					metricsCache.addData(new String[]{time,String.valueOf(result.getSum())});
				}
			}
		}
		
	}
	
	/**
	 *  ELB查询（数据来源于redis）
     *  
     *  <p>
     *  当查询的时间在一个小时以内，将从redis中查询
     *  </p>
	 * @param metricsMap
	 * @param query
	 * @param cloudQuery
	 * @param elbId ELB的id
	 * @author cdxuxiaolong
	 * @date 2013-12-11
	 */
    public void executeELBQueryFromRadis(Map<String, Metrics> metricsMap, ASQuery query, CloudQuery cloudQuery,
                                        EC2Info elbInfo) {
        //ELB的所有指标
        List<String> metrics = queryMetricsOfElb();
        if (metrics == null || metrics.isEmpty()) {
            return;
        }
        int index = 0;
        int timeInterval = Integer.parseInt(query.getTimeInterval());
        int period = Integer.parseInt(query.getPeriod());
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MINUTE, 0 - timeInterval * period - asQueryLazzyTime);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date startTime = cal.getTime();
        String startTimeStr = CSCPFaceServiceUtil.getTime(startTime, CSCPFaceServiceUtil.MINUTE_TIME_FORMAT);
        Map<String, Result> resultMap = new TreeMap<String, Result>(new Comparator<String>() {

            @Override
            public int compare(String o1, String o2) {
                return 0 - o1.compareTo(o2);
            }
        });
        for (String metric : metrics) {
            //过滤未查询的指标
            String tmpkey = cloudQuery.getASGroupID() + "#" + metric + "#";
            if (!(metricsMap.containsKey(tmpkey + "MAX") || metricsMap.containsKey(tmpkey + "MIN")
                    || metricsMap.containsKey(tmpkey + "AVG") || metricsMap.containsKey(tmpkey + "SUM"))) {
                continue;
            }
            //查询redis
            StringBuilder metricsKey = new StringBuilder(CommonConstance.SERVICE_ELB);
            metricsKey.append(CommonConstance.KEY_SPLIT).append(elbInfo.getUserID())
                    .append(CommonConstance.KEY_SPLIT).append(elbInfo.getInstanceCode())
                    .append(CommonConstance.KEY_SPLIT).append(metric);
            List<String> resultList = redisManager.getCacheAnalyResult(metricsKey.toString(), index, timeInterval);
            if (resultList == null || resultList.isEmpty()) {
                continue;
            }
            for (int i = 0; i < resultList.size(); i++) {
                //解析查询结果
                String data = resultList.get(i);
                if (CSCPFaceServiceUtil.isEmpty(data) || !data.matches("[^#]+((#)[^#]+){4}")) {
                    continue;
                }
                String[] items = data.split("#");
                double max = 0;
                double min = 0;
                double avg = 0;
                double sum = 0;
                try {
                    Date resultTime = CSCPFaceServiceUtil.getTime(items[0], CSCPFaceServiceUtil.MINUTE_TIME_FORMAT);
                    if (resultTime == null || resultTime.before(startTime)) {
                        break;
                    }
                    max = Double.parseDouble(items[1]);
                    min = Double.parseDouble(items[2]);
                    avg = Double.parseDouble(items[3]);
                    sum = Double.parseDouble(items[3]);
                } catch (Exception e) {
                    continue;
                }
                Result result = resultMap.get(items[0]);
                if (result == null) {
                    result = new Result(max, min, avg, sum);
                    resultMap.put(items[0], result);
                } else {
                    result.add(max, min, avg, sum);
                }
            }
            List<String> timeList = new ArrayList<String>(resultMap.keySet());
            int length = timeList.size();
            length = length > timeInterval ? timeInterval : length;
            int i = 0;
            for (String time : timeList) {
                Result result = resultMap.remove(time);
                i++;
                if (i > length || time.compareTo(startTimeStr) < 0) {
                    continue;
                }
                //从映射中快速查找Metrics，并完成结果设置
                String key = cloudQuery.getASGroupID() + "#" + metric + "#";
                Metrics metricsCache = metricsMap.get(key + "MAX");
                if (metricsCache != null) {
                    metricsCache.addData(new String[] { time, String.valueOf(result.getMax()) });
                }
                metricsCache = metricsMap.get(key + "MIN");
                if (metricsCache != null) {
                    metricsCache.addData(new String[] { time, String.valueOf(result.getMin()) });
                }
                metricsCache = metricsMap.get(key + "AVG");
                if (metricsCache != null) {
                    metricsCache.addData(new String[] { time, String.valueOf(result.getAvg()) });
                }
                metricsCache = metricsMap.get(key + "SUM");
                if (metricsCache != null) {
                    metricsCache.addData(new String[] { time, String.valueOf(result.getSum()) });
                }
            }
        }

    }

}
