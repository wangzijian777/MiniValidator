package com.jd.cloudeye.cscp.service.bo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.cscp.service.dao.AliveStateDao;
import com.jd.cloudeye.cscp.service.model.AliveStateQuery;
import com.jd.cloudeye.cscp.service.model.AliveStateResult;

/**
 * 服务实例存活查询
 * 
 * @author chenhualiang
 * @since 2013-03-12
 */
@Component("aliveStateBo")
public class AliveStateBo {
	
	@Autowired
	private AliveStateDao aliveStateDao;

	/**
	 * 查询实例存活状态
	 * 
	 * @param query 查询条件
	 * 
	 * @author chenhualiang
	 * @since 2013-03-12
	 */
	public AliveStateResult queryAliveState(AliveStateQuery query) {
		AliveStateResult result = new AliveStateResult(query.getInstanceIds());
		aliveStateDao.resetAliveState(query,result);
		return result;
	}

}
