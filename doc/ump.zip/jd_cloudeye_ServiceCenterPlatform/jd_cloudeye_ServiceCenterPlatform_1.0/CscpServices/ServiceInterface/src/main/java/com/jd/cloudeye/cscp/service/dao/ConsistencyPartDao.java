package com.jd.cloudeye.cscp.service.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.common.db.RedisManager;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllChild;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllInfo;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllInstance;
import com.jd.cloudeye.cscp.service.model.DeleteInstance;
import com.jd.cloudeye.cscp.service.model.ServerInstanceInfo;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

/**
 * 服务信息同步数据持久化处理类(分批次同步)
 * 
 * @author chenhualiang
 * @since 2013-03-02
 */
@Repository
public class ConsistencyPartDao {

private static final Logger log = Logger.getLogger(ConsistencyPartDao.class);
	
	@Resource(name = "transactionTemplate")
	private TransactionTemplate transactionTemplate;

	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private ServerConsistencyDao serverConsistencyDao;
	
	@Autowired
	private RedisManager redisManager;
	
	@Resource(name="commonTaskExecutor")
	private TaskExecutor commonTaskExecutor; 

	public int consistencyAll(final ConsistencyAllInfo requestInfo) {
		final Date eventTime = CSCPFaceServiceUtil.getTime(requestInfo.getRequestTime(), CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT);
		final LinkedList<String[]> createRelationshipList = new LinkedList<String[]>();
		final List<String> ids = new ArrayList<String>();
		int ret = this.transactionTemplate.execute(new TransactionCallback<Integer>() {

			public Integer doInTransaction(
					TransactionStatus transactionStatus) {
				if("ELB".equals(requestInfo.getServiceType()) || 
						"AS".equals(requestInfo.getServiceType()))
				{
					return consistencyCluster(requestInfo,eventTime,transactionStatus,createRelationshipList,ids);
				}
				else if("EC2".equals(requestInfo.getServiceType()))
				{
					return consistencyInstanceOfCluster(requestInfo,eventTime,transactionStatus,ids);
				}
				else if("JECS".equals(requestInfo.getServiceType()))
				{
					return consistencyJECS(requestInfo,eventTime,transactionStatus,createRelationshipList,ids);
				}
				else
				{
					return consistencyInstance(requestInfo,eventTime,transactionStatus,ids);
				}
			}

		});
		if(!createRelationshipList.isEmpty())
		{
			ret += this.transactionTemplate.execute(new TransactionCallback<Integer>() {
				 
				 public Integer doInTransaction(TransactionStatus transactionStatus) {
					 
					 if("JECS".equals(requestInfo.getServiceType()))
					 {
						 return createRelationship(createRelationshipList,eventTime,requestInfo.getServiceType(),new String[]{"JECS","AS","ELB"},transactionStatus);
					 }
					 else
					 {
						 return createRelationship(createRelationshipList,eventTime,requestInfo.getServiceType(),new String[]{requestInfo.getServiceType(),"EC2"},transactionStatus);
					 }
				 }

			 });
		}
		//将本次的所有同步实例id，写入该批次的redis key中
		String key = "ConsistencyPart_" + requestInfo.getServiceType() + "_" + requestInfo.getSyncIndex() + "_" + requestInfo.getSyncTotal() + "_" + requestInfo.getSyncSeq();
		redisManager.setKeyList(key,ids);
		redisManager.expire(key, 5400);//1个半小时过期 1.5 * 60 * 60 = 5400
		//如果该批次同步为最后一批次全量同步
		if(requestInfo.getSyncTotal() > 1 && requestInfo.getSyncIndex() == requestInfo.getSyncTotal())
		{
			commonTaskExecutor.execute(new Runnable() {
				
				int count = 0;
				
				private static final int MAX_COUNT_2_TEST = 10;
				
				@Override
				public void run() {
					count ++;
					while(count <= MAX_COUNT_2_TEST)
					{
						try{
							boolean flag = removeInstanceOfParts(requestInfo,eventTime);
							if(flag)
							{
								if("EC2".equals(requestInfo.getServiceType()))
								{
									serverConsistencyDao.sendEC2ipToGather();
								}
								return ;
							}
							else
							{
								Thread.sleep(30000L);
							}
						}
						catch (Exception e) {
							log.warn(CommonLogUtil.makeErrorHead("ServiceInterface", "ConsistencyPartDao"),e);
						}
						finally{
							count ++;
						}
					}
					log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "ConsistencyPartDao", "consistencyAll") + " " + MAX_COUNT_2_TEST  + " times required but can't mapping ;serviceType = " + requestInfo.getServiceType());
				}
				
			});
		}
		return ret;
	}
	
	private int consistencyJECS(ConsistencyAllInfo requestInfo,
			Date eventTime, TransactionStatus transactionStatus,LinkedList<String[]> createRelationshipList,List<String> ids) {
		int ret = 0;
		Map<String, ServerInstanceInfo> instanceMap = queryInstance(requestInfo,eventTime, transactionStatus);
		Map<String, String> relationshipMap = queryRelationship(requestInfo,eventTime, new String[] {"AS","ELB"},transactionStatus);
		//用于新增的服务实体队列
		LinkedList<ConsistencyAllInstance> createList = new LinkedList<ConsistencyAllInstance>();
		//用于修改的服务实体队列
		LinkedList<ConsistencyAllInstance> updateList = new LinkedList<ConsistencyAllInstance>();
		
//		LinkedList<String[]> deleteRelationshipList = new LinkedList<String[]>();
		
		List<ConsistencyAllInstance> data = requestInfo.getData();
		for(ConsistencyAllInstance reqInstance : data)
		{
			String key = reqInstance.getInstanceId() + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + reqInstance.getUserId();
			ServerInstanceInfo dbInstance = instanceMap.remove(key);
			if(dbInstance == null)
			{
				createList.offer(reqInstance);
			}
			else if(!reqInstance.getInstanceName().equals(dbInstance.getInstanceName()))
			{
				updateList.offer(reqInstance);
			}
			if(dbInstance != null)
			{
				ids.add(String.valueOf(dbInstance.getId()));
			}
			if(reqInstance.getChildren() != null && !reqInstance.getChildren().isEmpty())
			{
				for(ConsistencyAllChild child : reqInstance.getChildren())
				{
					String clusterId = relationshipMap.remove(child.getChildId());
					if(!CSCPFaceServiceUtil.isEmpty(clusterId))
					{
						relationshipMap.remove(clusterId);
					}
					if(CSCPFaceServiceUtil.isEmpty(clusterId) || !reqInstance.getInstanceId().equals(clusterId))
					{
						createRelationshipList.add(new String[]{child.getChildId(),reqInstance.getInstanceId(),"ELB"});
						createRelationshipList.add(new String[]{reqInstance.getInstanceId(),reqInstance.getInstanceId(),"AS"});
					}
				}
			}
		}
		
//		  Set<String> keySet = relationshipMap.keySet();
//        for(String childId : keySet)
//        {
//            deleteRelationshipList.add(new String[]{childId,relationshipMap.get(childId)});
//        }
        
		ret += saveInstanceData(createList, requestInfo.getServiceType(), eventTime,transactionStatus,ids);
		ret += updateInstanceData(updateList, requestInfo.getServiceType(), eventTime,transactionStatus);
//		ret += deleteRelationship(deleteRelationshipList,requestInfo.getServiceType(),new String[] {"AS","ELB"}, transactionStatus);
		return ret;
	}
	
	private Integer createRelationship(
			LinkedList<String[]> createRelationshipList,
			Date eventTime, String serviceType,String[] childrenType,
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(createRelationshipList == null)
		{
			return ret;
		}
		Map<String, Long> instanceIdMap = queryInstanceId(childrenType,transactionStatus);
		String sql = "insert into jce_cluster_instance (jce_cluster_id,jce_instance_id,create_time,update_time,is_valid) values (?,?,?,?,?)";
		try{
			String[] relationship = null;
			while((relationship = createRelationshipList.poll()) != null)
			{
				Long clusterId = instanceIdMap.get(relationship[1] + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + serviceType);
				Long instanceId = instanceIdMap.get(relationship[0] + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + relationship[2]);
				if(clusterId == null || instanceId == null)
				{
					continue;
				}
				ret += jdbcTemplate.update(sql,clusterId,instanceId,eventTime,eventTime,(byte)1);
				if("JECS".equals(serviceType) && !"AS".equals(relationship[2]))
				{
					redisManager.setKeyValue("JECS_RELATION#ELB#" + relationship[0], relationship[1]);
					redisManager.setKeyValue("JECS_RELATION#JECS#" + relationship[1], relationship[0]);
				}
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when createRelationship exception",e);
		}
		return ret;
	}
	
	@SuppressWarnings("unused")
	private Map<String, Long> queryInstanceId(String[] childrenType,TransactionStatus transactionStatus) {
		String sql = "select id,jce_service_code as serviceType,jce_instance_key as instanceId " +
				"from jce_service_instance where is_valid = '1' and jce_service_code in ('NULL'";
		for(String item : childrenType)
		{
			sql += ",?";
		}
		sql += ")";
		try{
			List<Map<String, Object>> datas = jdbcTemplate.queryForList(sql,(Object[])childrenType);
			Map<String, Long> instanceIdMap = new HashMap<String, Long>();
			if(datas != null && !datas.isEmpty())
			{
				
				for(Map<String, Object> item : datas)
				{
					String instanceId = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceId"));
					String dbServiceType = CSCPFaceServiceUtil.getStringFromObject(item.get("serviceType"));
					Long id = (Long)item.get("id");
					if(
						CSCPFaceServiceUtil.isEmpty(instanceId)||
						CSCPFaceServiceUtil.isEmpty(dbServiceType)||
						id == null
					)
					{
						continue;
					}
					instanceIdMap.put(instanceId + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + dbServiceType, id);
				}
			}
			return instanceIdMap;
		}
		catch (Exception e) {
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when consistencyInstance exception",e);
		}
	}

	private int consistencyInstance(ConsistencyAllInfo requestInfo,Date eventTime,
			TransactionStatus transactionStatus,List<String> ids) {
		int ret = 0;
		Map<String, ServerInstanceInfo> instanceMap = queryInstance(requestInfo,eventTime, transactionStatus);
		//用于新增的服务实体队列
		LinkedList<ConsistencyAllInstance> createList = new LinkedList<ConsistencyAllInstance>();
		//用于修改的服务实体队列
		LinkedList<ConsistencyAllInstance> updateList = new LinkedList<ConsistencyAllInstance>();
		
		List<ConsistencyAllInstance> data = requestInfo.getData();
		for(ConsistencyAllInstance reqInstance : data)
		{
			String key = reqInstance.getInstanceId() + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + reqInstance.getUserId();
			ServerInstanceInfo dbInstance = instanceMap.remove(key);
			if(dbInstance == null)
			{
				createList.offer(reqInstance);
			}
			else if(!reqInstance.getInstanceName().equals(dbInstance.getInstanceName()))
			{
				updateList.offer(reqInstance);
			}
			if(dbInstance != null)
			{
				ids.add(String.valueOf(dbInstance.getId()));
			}
		}
		ret += saveInstanceData(createList, requestInfo.getServiceType(), eventTime,transactionStatus,ids);
		ret += updateInstanceData(updateList, requestInfo.getServiceType(), eventTime,transactionStatus);
		return ret;
	}
	
	

	private int updateInstanceData(
			LinkedList<ConsistencyAllInstance> updateList, String serviceType,
			Date eventTime,TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(updateList == null)
		{
			return ret;
		}
		String sql = "update jce_service_instance as si " +
		"set si.update_time = ?,si.jce_instance_name = ? " +
		"where si.is_valid = '1' and si.jce_instance_key = ? and si.jce_boss_user_id = ? and si.jce_service_code = ?";
		try{
			ConsistencyAllInstance instance = null;
			while((instance = updateList.poll()) != null)
			{
				ret += jdbcTemplate.update(sql, eventTime,instance.getInstanceName(),
						instance.getInstanceId(),instance.getUserId(),serviceType
						);
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when updateInstanceName exception",e);
		}
		return ret;
	}

	private int saveInstanceData(
			LinkedList<ConsistencyAllInstance> createList,
			String serviceType,
			Date eventTime,
			TransactionStatus transactionStatus,List<String> ids) {
		
		int ret = 0 ;
		if(createList == null)
		{
			return ret;
		}
		ConsistencyAllInstance instance = null;
		String sql = "insert into jce_service_instance "
			+ "(jce_boss_user_id,jce_boss_user_name,jce_service_code,"
			+ "jce_instance_key,jce_instance_name,create_time,update_time,is_valid)"
			+ "values(?,?,?,?,?,?,?,?)";
		try{
			while((instance = createList.poll()) != null)
			{
				if(ids == null)
				{
					ret+= jdbcTemplate.update(
						sql,
						instance.getUserId(),CSCPFaceServiceUtil.NULL,
						serviceType,instance.getInstanceId(),instance.getInstanceName(),
						eventTime,eventTime,(byte) 1);
				}
				else
				{
					long id = insertRow(sql, instance.getUserId(),CSCPFaceServiceUtil.NULL,
							serviceType,instance.getInstanceId(),instance.getInstanceName(),
							eventTime,eventTime,(byte) 1);
					ids.add(String.valueOf(id));
				}
			}
		}
		catch (Exception e) {
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when saveInstance exception",e);
		}
		return ret ;
	}
	
	private long insertRow(final String sql,final Object... args) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			
			public PreparedStatement createPreparedStatement(Connection con)
					throws SQLException {
				PreparedStatement ps = con.prepareStatement(sql);
				for(int i = 1 ; i <= args.length ; i ++)
				{
					ps.setObject(i, args[i - 1]);
				}
				return ps;
			}
			
		}, keyHolder);
		return keyHolder.getKey().longValue();
	}
	

	private Map<String, ServerInstanceInfo> queryInstance(ConsistencyAllInfo requestInfo,Date eventTime,
			TransactionStatus transactionStatus)
	{
		String sql = "select id,jce_instance_key as instanceId," +
		"jce_instance_name as instanceName," +
		"jce_boss_user_id as userId " +
		"from jce_service_instance where is_valid = '1' and jce_service_code = ?";
		try{
			List<Map<String, Object>> datas = jdbcTemplate.queryForList(sql, requestInfo.getServiceType());
			Map<String, ServerInstanceInfo> instanceMap = new HashMap<String, ServerInstanceInfo>();
			if(datas != null && !datas.isEmpty())
			{
				
				for(Map<String, Object> item : datas)
				{
					String instanceId = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceId"));
					String instanceName = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceName"));
					String userId = CSCPFaceServiceUtil.getStringFromObject(item.get("userId"));
					long id = (Long)item.get("id");
					if(
						CSCPFaceServiceUtil.isEmpty(instanceId)||
						CSCPFaceServiceUtil.isEmpty(instanceName)||
						CSCPFaceServiceUtil.isEmpty(userId)
					)
					{
						continue;
					}
					ServerInstanceInfo instance = new ServerInstanceInfo();
					instance.setId(id);
					instance.setEventTime(eventTime);
					instance.setInstanceId(instanceId);
					instance.setInstanceName(instanceName);
					instance.setServiceType(requestInfo.getServiceType());
					instance.setUserId(userId);
					instanceMap.put(instanceId + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + userId, instance);
				}
			}
			return instanceMap;
		}
		catch (Exception e) {
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when consistencyInstance exception",e);
		}
	}

	private Map<String, ServerInstanceInfo> queryInstance(ConsistencyAllInfo requestInfo,Date eventTime){
		String sql = "select id,jce_instance_key as instanceId," +
		"jce_instance_name as instanceName," +
		"jce_boss_user_id as userId " +
		"from jce_service_instance where is_valid = '1' and jce_service_code = ?";
		try{
			List<Map<String, Object>> datas = jdbcTemplate.queryForList(sql, requestInfo.getServiceType());
			Map<String, ServerInstanceInfo> instanceMap = new HashMap<String, ServerInstanceInfo>();
			if(datas != null && !datas.isEmpty())
			{
				
				for(Map<String, Object> item : datas)
				{
					String instanceId = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceId"));
					String instanceName = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceName"));
					String userId = CSCPFaceServiceUtil.getStringFromObject(item.get("userId"));
					long id = (Long)item.get("id");
					if(
							CSCPFaceServiceUtil.isEmpty(instanceId)||
							CSCPFaceServiceUtil.isEmpty(instanceName)||
							CSCPFaceServiceUtil.isEmpty(userId)
					)
					{
						continue;
					}
					ServerInstanceInfo instance = new ServerInstanceInfo();
					instance.setId(id);
					instance.setEventTime(eventTime);
					instance.setInstanceId(instanceId);
					instance.setInstanceName(instanceName);
					instance.setServiceType(requestInfo.getServiceType());
					instance.setUserId(userId);
					instanceMap.put(String.valueOf(id), instance);
				}
			}
			return instanceMap;
		}
		catch (Exception e) {
			throw new RuntimeException("when consistencyInstance exception",e);
		}
	}
	
	
	private int consistencyInstanceOfCluster(
			ConsistencyAllInfo requestInfo, Date eventTime,
			TransactionStatus transactionStatus,List<String> ids) {
		int ret = 0;
		Map<String, ServerInstanceInfo> instanceMap = queryInstance(requestInfo,eventTime, transactionStatus);
		//用于新增的服务实体队列
		LinkedList<ConsistencyAllInstance> createList = new LinkedList<ConsistencyAllInstance>();
		//用于修改的服务实体队列
		LinkedList<ConsistencyAllInstance> updateList = new LinkedList<ConsistencyAllInstance>();
		
		List<ConsistencyAllInstance> data = requestInfo.getData();
		for(ConsistencyAllInstance reqInstance : data)
		{
			String key = reqInstance.getInstanceId() + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + reqInstance.getUserId();
			ServerInstanceInfo dbInstance = instanceMap.remove(key);
			if(dbInstance == null)
			{
				createList.offer(reqInstance);
			}
			else if(!reqInstance.getInstanceName().equals(dbInstance.getInstanceName()))
			{
				updateList.offer(reqInstance);
			}
			if(dbInstance != null)
			{
				ids.add(String.valueOf(dbInstance.getId()));
			}
		}
		ret += saveInstanceData(createList, requestInfo.getServiceType(), eventTime,transactionStatus,ids);
		ret += updateInstanceData(updateList, requestInfo.getServiceType(), eventTime,transactionStatus);
		return ret;
	}
	
	

	private int consistencyCluster(ConsistencyAllInfo requestInfo,Date eventTime,
			TransactionStatus transactionStatus,LinkedList<String[]> createRelationshipList,List<String> ids) {
		int ret = 0;
		Map<String, ServerInstanceInfo> instanceMap = queryInstance(requestInfo,eventTime, transactionStatus);
		Map<String, String> relationshipMap = queryRelationship(requestInfo,eventTime, new String[]{"EC2"} ,transactionStatus);
		//用于新增的服务实体队列
		LinkedList<ConsistencyAllInstance> createList = new LinkedList<ConsistencyAllInstance>();
		//用于修改的服务实体队列
		LinkedList<ConsistencyAllInstance> updateList = new LinkedList<ConsistencyAllInstance>();
		
		
//		LinkedList<String[]> deleteRelationshipList = new LinkedList<String[]>();
		
		List<ConsistencyAllInstance> data = requestInfo.getData();
		for(ConsistencyAllInstance reqInstance : data)
		{
			String key = reqInstance.getInstanceId() + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + reqInstance.getUserId();
			ServerInstanceInfo dbInstance = instanceMap.remove(key);
			if(dbInstance == null)
			{
				createList.offer(reqInstance);
			}
			else if(!reqInstance.getInstanceName().equals(dbInstance.getInstanceName()))
			{
				updateList.offer(reqInstance);
			}
			if(dbInstance != null)
			{
				ids.add(String.valueOf(dbInstance.getId()));
			}
			if(reqInstance.getChildren() != null && !reqInstance.getChildren().isEmpty())
			{
				for(ConsistencyAllChild child : reqInstance.getChildren())
				{
					String clusterId = relationshipMap.remove(child.getChildId());
					if(CSCPFaceServiceUtil.isEmpty(clusterId) || !reqInstance.getInstanceId().equals(clusterId))
					{
						createRelationshipList.add(new String[]{child.getChildId(),reqInstance.getInstanceId(),"EC2"});
					}
				}
			}
		}
		
//		  Set<String> keySet = relationshipMap.keySet();
//        for(String childId : keySet)
//        {
//            deleteRelationshipList.add(new String[]{childId,relationshipMap.get(childId)});
//        }
		ret += saveInstanceData(createList, requestInfo.getServiceType(), eventTime,transactionStatus,ids);
		ret += updateInstanceData(updateList, requestInfo.getServiceType(), eventTime,transactionStatus);
//		ret += deleteRelationship(deleteRelationshipList,requestInfo.getServiceType(),new String[]{"EC2"}, transactionStatus);
		return ret;
	}

//	private int deleteRelationship(LinkedList<String[]> deleteRelationshipList,String serviceType,String[] childrenType,
//			TransactionStatus transactionStatus) {
//		int ret = 0 ;
//		if(deleteRelationshipList == null)
//		{
//			return ret;
//		}
//		StringBuilder sql = new StringBuilder();
//		sql.append("DELETE ci.* FROM jce_cluster_instance AS ci RIGHT JOIN jce_service_instance AS si1 ON si1.id = ci.jce_cluster_id RIGHT JOIN jce_service_instance AS si2 ON si2.id = ci.jce_instance_id ");
//		sql.append("WHERE ci.is_valid = '1' AND si1.is_valid = '1' AND si2.is_valid = '1' AND si1.jce_instance_key = ? AND si1.jce_service_code = ? AND si2.jce_instance_key = ? AND si2.jce_service_code in ('NULL'");
//		for(String childType : childrenType)
//		{
//			sql.append(",'").append(childType).append("'");
//		}
//		sql.append(")");
//		try{
//			String[] relationship = null;
//			while((relationship = deleteRelationshipList.poll()) != null)
//			{
//				ret += jdbcTemplate.update(sql.toString(), relationship[1],serviceType,relationship[0]);
//			}
//		}
//		catch (Throwable e) {
//			//处理异常
//			transactionStatus.setRollbackOnly();
//			throw new RuntimeException("when deleteRelationship exception",e);
//		}
//		return ret;
//	}
	
	private boolean removeInstanceOfParts(
			final ConsistencyAllInfo requestInfo,final Date eventTime) {
		for(int index = 1 ; index <= requestInfo.getSyncTotal() ; index ++)
		{
			String key = "ConsistencyPart_" + requestInfo.getServiceType() + "_" + index + "_" + requestInfo.getSyncTotal() + "_" + requestInfo.getSyncSeq();
			if(!redisManager.exists(key))
			{
				return false;
			}
		}
		Map<String, ServerInstanceInfo> instanceDB = queryInstance(requestInfo,eventTime);
		for(int index = 1 ; index <= requestInfo.getSyncTotal() ; index ++)
		{
			String key = "ConsistencyPart_" + requestInfo.getServiceType() + "_" + index + "_" + requestInfo.getSyncTotal() + "_" + requestInfo.getSyncSeq();
			List<String> instanceItem = redisManager.getKeyList(key);
			if(log.isDebugEnabled())
			{
				log.debug(key + "===>" + instanceItem);
			}
			for(String instance : instanceItem)
			{
				instanceDB.remove(instance);
			}
		}
		final LinkedList<ServerInstanceInfo> deleteList = new LinkedList<ServerInstanceInfo>();
		deleteList.addAll(instanceDB.values());
		this.transactionTemplate.execute(new TransactionCallback<Integer>() {
			
			public Integer doInTransaction(
					TransactionStatus transactionStatus) {
					int ret = 0;
					if("ELB".equals(requestInfo.getServiceType()) || 
							"AS".equals(requestInfo.getServiceType()))
					{
						ret += deleteCluster(deleteList, eventTime,transactionStatus);
					}
					else if("EC2".equals(requestInfo.getServiceType()))
					{
						ret += deleteInstanceOfCluster(deleteList,transactionStatus);
					}
					else if("JECS".equals(requestInfo.getServiceType()))
					{
						ret += deleteCluster(deleteList, eventTime,transactionStatus);
					}
					else
					{
						ret += deleteInstanceData(deleteList,transactionStatus);
					}
					if(ret > 0 && !deleteList.isEmpty())
					{
						removeInstanceData(deleteList);
					}
					return ret;
				}
			});
		return true;
	}
	
	private int deleteInstanceData(
			LinkedList<ServerInstanceInfo> deleteList, 
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(deleteList == null)
		{
			return ret;
		}
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE si.* FROM jce_service_instance as si ");
		sql.append("WHERE si.is_valid = '1' AND si.jce_boss_user_id = ? AND si.jce_service_code = ? AND si.jce_instance_key = ?");
		
		try{
			ServerInstanceInfo instance = null;
			LinkedList<ServerInstanceInfo> temp = new LinkedList<ServerInstanceInfo>(deleteList);
			while((instance = temp.poll()) != null)
			{
				ret += jdbcTemplate.update(sql.toString(), instance.getUserId(),instance.getServiceType(), instance.getInstanceId());
				log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "ConsistencyPartDao", "deleteCluster") + "{userId:" + instance.getUserId() + ",serviceType:" + instance.getServiceType() + ",instanceId:" + instance.getInstanceId() + ",flag:" + CSCPFaceServiceUtil.NOT_CLUSTER_INSTANCE + "}");
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when deleteInstance exception",e);
		}
		return ret;
	}
	
	private int deleteInstanceOfCluster(
			LinkedList<ServerInstanceInfo> deleteList,
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(deleteList == null)
		{
			return ret;
		}
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE ci.*, si.* FROM jce_service_instance as si LEFT JOIN jce_cluster_instance AS ci ON si.id = ci.jce_instance_id ");
		sql.append("WHERE si.is_valid = '1' AND si.jce_service_code = ? AND si.jce_instance_key = ?");
		try{
			ServerInstanceInfo instance = null;
			LinkedList<ServerInstanceInfo> deleteListTemp = new LinkedList<ServerInstanceInfo>(deleteList);
			while((instance = deleteListTemp.poll()) != null)
			{
				ret += jdbcTemplate.update(sql.toString(), instance.getServiceType(), instance.getInstanceId());
				log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "ConsistencyPartDao", "deleteCluster") + "{userId:" + instance.getUserId() + ",serviceType:" + instance.getServiceType() + ",instanceId:" + instance.getInstanceId() + ",flag:" + CSCPFaceServiceUtil.EC2_IN_CLUSTER + "}");
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when deleteInstance exception",e);
		}
		return ret;
	}
	
	private void removeInstanceData(LinkedList<ServerInstanceInfo> deleteList) {
		if(deleteList == null || deleteList.isEmpty())
		{
			return ;
		}
		ServerInstanceInfo info = null;
		while ((info = deleteList.poll()) != null)
		{
			serverConsistencyDao.removeServiceInstance(
					new DeleteInstance(info.getId(), info.getInstanceId(), info.getServiceType(), info.getUserId()));
		}
	}

	private int deleteCluster(LinkedList<ServerInstanceInfo> deleteList,Date eventTime,
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(deleteList == null)
		{
			return ret;
		}
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE si.*,ci.* FROM jce_service_instance AS si LEFT JOIN jce_cluster_instance AS ci ON si.id = ci.jce_cluster_id ");
		sql.append("WHERE si.is_valid = '1' AND si.jce_boss_user_id = ? AND si.jce_service_code = ? AND si.jce_instance_key = ?");
		try{
			ServerInstanceInfo instance = null;
			LinkedList<ServerInstanceInfo> deleteListTemp = new LinkedList<ServerInstanceInfo>(deleteList);
			while((instance = deleteListTemp.poll()) != null)
			{
				ret += jdbcTemplate.update(
						sql.toString(),
						instance.getUserId(),instance.getServiceType(),instance.getInstanceId());
				log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "ConsistencyPartDao", "deleteCluster") + "{userId:" + instance.getUserId() + ",serviceType:" + instance.getServiceType() + ",instanceId:" + instance.getInstanceId() + ",flag:" + CSCPFaceServiceUtil.INSTANCE_OF_CLUSTER + "}");
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when deleteInstance exception",e);
		}
		return ret;
	}

	private Map<String, String> queryRelationship(
			ConsistencyAllInfo requestInfo, Date eventTime,String[] childrenType,
			TransactionStatus transactionStatus) {
		Map<String, String> relationshipMap = new HashMap<String, String>();
		String sql = "select si1.jce_instance_key as clusterId ,si2.jce_instance_key as instanceId " +
			"from jce_cluster_instance as ci left join jce_service_instance as si1 on si1.id = ci.jce_cluster_id " +
			"left join jce_service_instance as si2 on si2.id = ci.jce_instance_id " + 
			"where ci.is_valid = '1' and si1.is_valid = '1' and si2.is_valid = '1' and si1.jce_service_code = ? and si2.jce_service_code in ('NULL'";
		for(String serviceType : childrenType)
		{
			sql += ",'" + serviceType + "'";
		}
		sql += ")";
		try{
			SqlRowSet srs = jdbcTemplate.queryForRowSet(sql, requestInfo.getServiceType());
			if(srs != null)
			{
				while (srs.next())
				{
					String clusterId = srs.getString("clusterId");
					String instanceId = srs.getString("instanceId");
					if(CSCPFaceServiceUtil.isEmpty(clusterId) || CSCPFaceServiceUtil.isEmpty(instanceId))
					{
						continue;
					}
					relationshipMap.put(instanceId,clusterId);
				}
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when queryRelationship exception",e);
		}
		return relationshipMap;
	}

}