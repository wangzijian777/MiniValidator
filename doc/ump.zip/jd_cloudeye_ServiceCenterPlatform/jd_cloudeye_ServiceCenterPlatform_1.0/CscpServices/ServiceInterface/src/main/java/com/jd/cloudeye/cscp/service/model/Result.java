package com.jd.cloudeye.cscp.service.model;


/**
 * 计算结果 
 */
public class Result {
	
	/**
	 * 最大值 
	 */
	private double max;
	
	/**
	 * 最小值 
	 */
	private double min;
	
	/**
	 * 平均值 
	 */
	private double avg;
	
	/**
	 * 累计值 
	 */
	private double sum;
	
	/**
	 * 个数 
	 */
	private int count;
	
	/**
	 * 构造 实例的计算数据
	 */
	public Result(double max,double min,double avg,double sum)
	{
		this.avg = avg;
		this.max = max;
		this.min = min;
		this.sum = sum;
		count ++;
	}
	
	/**
	 * 一个实例参加计算
	 */
	public void add(double max,double min,double avg,double sum)
	{
		
		this.avg += avg;
		if(this.max < max)
		{
			this.max = max;
		}
		if(this.min > min)
		{
			this.min = min;
		}
		this.sum += sum;
		count ++;
	}

	public double getMax() {
		return max;
	}

	public double getMin() {
		return min;
	}

	public double getAvg() {
		if(count == 0)
		{
			return 0;
		}
		return avg / count;
	}

	public double getSum() {
		return sum;
	}

	public int getCount() {
		return count;
	}
	
}
