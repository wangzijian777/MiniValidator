package com.jd.cloudeye.cscp.service.model;

import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

/**
 * 服务实例同步返回状态
 * 
 * @author chenhualiang
 * @since 2013-03-01
 */
public enum ServerConsistencyState{
	
	////////////items/////////////
	
	/**
	 * 服务实例同步失败 
	 */
	Fail(0,"fail"),
	
	/**
	 * 服务实例同步成功
	 */
	Success(1,"success"),
	
	/**
	 * 服务实例同步参数错误
	 */
	Illegal(2,"parameter illegal"),
	
	/**
	 * 访问超时 
	 */
	Timeout(3,"time out"),
	
	/**
	 * 空操作 
	 */
	DoNothing(4,"do nothing");
	
	////////////fields////////////
	
	/**
	 * 服务实例同步返回状态码
	 */
	private int code;
	
	/**
	 * 服务实例同步返回状信息说明
	 */
	private String info;
	
	//构造函数
	ServerConsistencyState(int code,String info)
	{
		this.code = code;
		this.info = info;
	}

	/**
	 * 服务实例同步返回状态描述
	 */
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("{\"state\":\"");
		sb.append(code);
		sb.append("\",\"message\":\"");
		sb.append(info);
		sb.append("\",\"responseTime\": \"");
		sb.append(CSCPFaceServiceUtil.getTimeOfNow(CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT));
		sb.append("\"}");
		return sb.toString();
	}

}
