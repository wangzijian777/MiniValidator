package com.jd.cloudeye.cscp.service.model;

/***
 * EC2信息 
 */
public class EC2Info {
	
	/**
	 * 用户ID 
	 */
	private String userID;
	
	/**
	 * 集群ID
	 */
	private String cluserID;
	
	/**
	 * 实例ID（DB src） 
	 */
	private long instanceID;
	
	/**
	 * 实例ID（EC2 src） 
	 */
	private String instanceCode;
	
	public String getInstanceCode() {
		return instanceCode;
	}

	public void setInstanceCode(String instanceCode) {
		this.instanceCode = instanceCode;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getCluserID() {
		return cluserID;
	}

	public void setCluserID(String cluserID) {
		this.cluserID = cluserID;
	}

	public long getInstanceID() {
		return instanceID;
	}

	public void setInstanceID(long instanceID) {
		this.instanceID = instanceID;
	}
}
