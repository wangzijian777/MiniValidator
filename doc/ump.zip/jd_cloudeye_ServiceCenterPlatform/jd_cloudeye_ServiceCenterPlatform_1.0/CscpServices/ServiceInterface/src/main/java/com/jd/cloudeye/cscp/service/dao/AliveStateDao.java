package com.jd.cloudeye.cscp.service.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.jd.cloudeye.cscp.common.db.RedisManager;
import com.jd.cloudeye.cscp.service.model.AliveStateQuery;
import com.jd.cloudeye.cscp.service.model.AliveStateResult;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

/**
 * 实体存活查询数据操作类 
 * 
 * @author chenhualiang
 * @since 2013-03-12
 */
@Repository("aliveStateDao")
public class AliveStateDao {
	
	@Autowired
	private RedisManager redisManager;
	
	@Value("${ec2.maxAliveTime}")
	private long maxAliveTime;

	/**
	 * 查询存活状态并设置到结果集中
	 * 
	 * @param query 查询条件
	 * @param result 查询结果
	 * 
	 * @author chenhualiang
	 * @since 2013-03-12
	 */
	public void resetAliveState(AliveStateQuery query,AliveStateResult result) {
		//radis中查询所有势力状态
		Map<String, String> aliveStateMap = redisManager.hGetAll(query.getServiceType() + "_" + CSCPFaceServiceUtil.ALIVE_KEY);
		if(aliveStateMap == null || aliveStateMap.isEmpty())
		{
			return ;
		}
		List<String[]> instancesAliveState = result.getData();
		long now = System.currentTimeMillis();
		for(String[] istate : instancesAliveState)
		{
			if(CSCPFaceServiceUtil.isEmpty(istate[0]))
			{
				continue;
			}
			//查找对应实例的最近一次心跳时间
			String state = aliveStateMap.get(istate[0]);
			if(CSCPFaceServiceUtil.isEmpty(state) || !state.matches("\\d+"))
			{
				continue;
			}
			long aliveTime = Long.parseLong(state);
			//判断心跳是否在有效范围内
			if(now - aliveTime > maxAliveTime)
			{
				istate[1] = CSCPFaceServiceUtil.UNALIVE_STATE;
			}
			else
			{
				istate[1] = CSCPFaceServiceUtil.ALIVE_STATE;
			}
		}
	}

}
