package com.jd.cloudeye.cscp.service.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.bind.annotation.InitBinder;

import com.alibaba.fastjson.JSONObject;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.common.db.RedisManager;
import com.jd.cloudeye.cscp.gather.Center.SetIpList;
import com.jd.cloudeye.cscp.service.bo.ServerConsistencyBo;
import com.jd.cloudeye.cscp.service.model.DeleteInstance;
import com.jd.cloudeye.cscp.service.model.ServerInfo;
import com.jd.cloudeye.cscp.service.model.ServerInstanceInfo;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * 服务信息同步数据持久化处理类
 * 
 * @author chenhualiang
 * @since 2013-03-02
 */
@Repository
public class ServerConsistencyDao {

	@Resource(name = "transactionTemplate")
	private TransactionTemplate transactionTemplate;

	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Resource(name = "serverConsistencyBo")
	private ServerConsistencyBo serverConsistencyBo;
	
	@Autowired
	private RedisManager redisManager;
	
	@Autowired
	private SetIpList setIpList;
	
	private static final LinkedBlockingQueue<DeleteInstance> deleteInstanceQueue = new LinkedBlockingQueue<DeleteInstance>();
	
	private static final Logger log = Logger.getLogger(ServerConsistencyDao.class);
	
	/**
	 * 服务缓存集合 
	 */
	private Map<String,String> serviceTypeCache = new HashMap<String,String>();
	
	/**
	 * 最后一次更新 服务缓存集合 时间
	 */
	private long lastUpdateCacheTime = 0;
	
	@Resource(name="commonTaskExecutor")
	private TaskExecutor commonTaskExecutor; 
	
	/**
	 * 删除服务实例的记录信息的队列 
	 */
	@SuppressWarnings("unused")
	private final DeleteInstanceThread deleteInstanceThread = new DeleteInstanceThread();
	
	/**
	 * 校验服务类型
	 * 
	 * @param serviceType 参加校验的服务类型
	 * 
	 * @return boolean 是否合法
	 * 
	 * @author chenhualiang
	 * @since 2013-03-20
	 */
	public boolean isValidServiceType(String serviceType)
	{
		if(CSCPFaceServiceUtil.isEmpty(serviceType))
		{
			return false;
		}
		if(serviceTypeCache.containsKey(serviceType))
		{
			return true;
		}
		synchronized (serviceTypeCache) {
			if(serviceTypeCache.containsKey(serviceType))
			{
				return true;
			}
			if(System.currentTimeMillis() - lastUpdateCacheTime > CSCPFaceServiceUtil.SERICE_TYPE_CACHE_TIME)
			{
				loadServiceType();
				return serviceTypeCache.containsKey(serviceType);
			}
			else
			{
				return false;
			}
		}
	}
	
	/**
	 * 通过serviceType的英文描述获取其中文描述 
	 */
	public String getServiceName(String serviceType)
	{
		if(CSCPFaceServiceUtil.isEmpty(serviceType))
		{
			return null;
		}
		String serviceName = serviceTypeCache.get(serviceType);
		if(!CSCPFaceServiceUtil.isEmpty(serviceName))
		{
			return serviceName;
		}
		synchronized (serviceTypeCache) {
			serviceName = serviceTypeCache.get(serviceType);
			if(!CSCPFaceServiceUtil.isEmpty(serviceName))
			{
				return serviceName;
			}
			if(System.currentTimeMillis() - lastUpdateCacheTime > CSCPFaceServiceUtil.SERICE_TYPE_CACHE_TIME)
			{
				loadServiceType();
				return serviceTypeCache.get(serviceType);
			}
			else
			{
				return null;
			}
		}
	}

	/**
	 * 加载服务类型 
	 */
	@InitBinder
	public void loadServiceType() {
		try{
			String sql = "SELECT jce_dictionary_code ,jce_dictionary_value FROM jce_dictionary where jce_level = '-1'";
			List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
			if(list != null && !list.isEmpty())
			{
				serviceTypeCache.clear();
				for(Map<String, Object> item : list)
				{
					Object code = item.get("jce_dictionary_code");
					Object value = item.get("jce_dictionary_value");
					if(code != null && value != null)
					{
						serviceTypeCache.put(code.toString(), value.toString());
					}
				}
				lastUpdateCacheTime = System.currentTimeMillis();
			}
		}catch (Exception e) {
			log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ASQueryDao") + " load service type from db exception",e);
		}
	}
	
	/**
	 * 查询服务实例的ID
	 * 
	 * @param args 查询参数
	 * 
	 * @return long 0标示没有查询到；其他标示查询到的ID
	 * 
	 * @author chenhualiang
	 * @since 2013-03-02
	 */
	public long queryInstanceId(Object[] args) {
		StringBuilder sql = new StringBuilder();
		sql.append("select id from jce_service_instance ");
		sql.append("where is_valid = '1' and jce_boss_user_id = ? and jce_service_code = ? and jce_instance_key = ? limit 1");
		try{
			return jdbcTemplate.queryForLong(sql.toString(), args[0],args[2],args[3]);
		}
		catch (Exception e) {
			//NULL point 标示没有查询到数据
			return 0;
		}
	}

	/**
	 * 更新服务实例信息
	 * 
	 * @param info 同步服务实例信息
	 * 
	 * @author chenhualiang
	 * @since 2013-03-02
	 */
	public int updateName(final ServerInfo info) {

		return this.transactionTemplate.execute(new TransactionCallback<Integer>() {

			public Integer doInTransaction(
					TransactionStatus transactionStatus) {
				try{
					String sql = "update jce_service_instance as si " +
						"set si.update_time = ?,si.jce_instance_name = ? " +
						"where si.is_valid = '1' and si.jce_instance_key = ? and si.jce_boss_user_id = ? and si.jce_service_code = ?";
					List<Object> argsList = new ArrayList<Object>();
					argsList.add(info.getEventTime());
					if("JSS".equals(info.getServiceType()) || "JHbase".equalsIgnoreCase(info.getServiceType()))
					{
						return 0;
					}
					else if(CSCPFaceServiceUtil.isEmpty(info.getClusterId()))
					{
						argsList.add(info.getInstanceName());
						argsList.add(info.getInstanceId());
					}
					else if(CSCPFaceServiceUtil.isEmpty(info.getInstanceId()))
					{
						argsList.add(info.getClusterName());
						argsList.add(info.getClusterId());
					}
					else
					{
						return 0;
					}
					argsList.add(info.getUserId());
					argsList.add(info.getServiceType());
					return jdbcTemplate.update(sql, argsList.toArray());
				
				}
				catch (Throwable e) {
					//处理异常
					transactionStatus.setRollbackOnly();
					throw new RuntimeException("when updateName exception",e);
				}
			}
			

		});

	}
	
	/**
	 * 新增服务实例信息
	 * 
	 * @param info 
	 * 
	 * @author chenhualiang
	 * @since 2013-03-02
	 */
	private long[] insertInstance(final ServerInstanceInfo info) {
		String sql = "insert into jce_service_instance "
				+ "(jce_boss_user_id,jce_boss_user_name,jce_service_code,"
				+ "jce_instance_key,jce_instance_name,create_time,update_time,is_valid)"
				+ "values(?,?,?,?,?,?,?,?)";
		Object[] args = new Object[8];
		String[] instanceIds = info.getInstanceId().split(",");
		String[] instanceNames = info.getInstanceName().split(",");
		long[] ids = new long[instanceIds.length];
		for(int i = 0 ; i < instanceIds.length ; i ++)
		{
			args[0] = info.getUserId();
			args[1] = CSCPFaceServiceUtil.NULL;
			args[2] = info.getServiceType();
			args[3] = instanceIds[i];
			args[4] = instanceNames[i];
			args[5] = info.getEventTime();
			args[6] = info.getEventTime();
			args[7] = (byte) 1;
			long id = queryInstanceId(args);
			if(id > 0)
			{
				ids[i] = id;
			}
			else
			{
				ids[i] = insertRow(sql, args);
			}
		}
		return ids;
	}
	
	/**
	 * 新增关联关系
	 */
	private void insertClusterWithInstance(long clusterId,
			long instanceIds[], ServerInfo info) {
		String sql = "insert into jce_cluster_instance (jce_cluster_id,jce_instance_id,create_time,update_time,is_valid) "+
		"select ?,?,?,?,? from DUAL where (select count(1) from jce_cluster_instance where jce_cluster_id = ? and jce_instance_id = ? " +
		"and is_valid = '1') = 0";
		for(long instanceId : instanceIds)
		{
			jdbcTemplate.update(sql, clusterId,instanceId,info.getEventTime(),info.getEventTime(),1,clusterId,instanceId);
		}
	}
	
	/**
	 * 删除服务实例信息
	 * 
	 * @param userId 用户ID
	 * @param serviceType 服务类型
	 * @param instanceId 实例ID
	 * @param eventTime 事件时间
	 * @param flag 处理分类(0:删除非集群关系实例;1:删除实例以及其关联关系;2:删除集群以及其关联关系,3:删除关联关系)
	 */
	public int deleteInstance(String userId,String serviceType,String instanceId ,int flag) {
		StringBuilder sql = new StringBuilder();
		List<Object> argsList = new ArrayList<Object>();
		if(flag == CSCPFaceServiceUtil.NOT_CLUSTER_INSTANCE)//删除非集群关系实例
		{
//			sql.append("update jce_service_instance as si ");
//			sql.append("set si.is_valid = '0' ,si.update_time = ? ");
//			sql.append("where si.is_valid = '1' and si.jce_boss_user_id = ? and si.jce_service_code = ? and si.jce_instance_key in ('-999'");
			
			// modified by baiyunqi 20130408
			sql.append("DELETE si.* FROM jce_service_instance as si ");
			sql.append("WHERE si.is_valid = '1' AND si.jce_boss_user_id = ? AND si.jce_service_code = ? AND si.jce_instance_key IN ('-999'");

		}
		else if(flag == CSCPFaceServiceUtil.EC2_IN_CLUSTER)//删除实例以及其关联关系
		{
//			sql.append("update jce_service_instance as si left join jce_cluster_instance as ci on si.id = ci.jce_instance_id ");
//			sql.append("set si.is_valid = '0',ci.is_valid = '0',si.update_time = ?,ci.update_time = (case when ci.is_valid = '1' then ? else ci.update_time end) ");
//			sql.append("where si.is_valid = '1' and si.jce_boss_user_id = ? and si.jce_service_code = ? and si.jce_instance_key in ('-999'");
			
			// modified by baiyunqi 20130408
			sql.append("DELETE si.*, ci.* FROM jce_service_instance AS si LEFT JOIN jce_cluster_instance AS ci ON si.id = ci.jce_instance_id ");
			sql.append("WHERE si.is_valid = '1' AND si.jce_boss_user_id = ? AND si.jce_service_code = ? AND si.jce_instance_key IN ('-999'");
			
		}
		else if(flag == CSCPFaceServiceUtil.INSTANCE_OF_CLUSTER)//删除集群以及其关联关系
		{
//			sql.append("update jce_service_instance as si left join jce_cluster_instance as ci on si.id = ci.jce_cluster_id ");
//			sql.append("set si.is_valid = '0',ci.is_valid = '0',si.update_time = ?,ci.update_time = (case when ci.is_valid = '1' then ? else ci.update_time end) ");
//			sql.append("where si.is_valid = '1' and si.jce_boss_user_id = ? and si.jce_service_code = ? and si.jce_instance_key in ('-999'");
			
			// modified by baiyunqi 20130408
			sql.append("DELETE si.*, ci.* FROM jce_service_instance AS si LEFT JOIN jce_cluster_instance AS ci ON si.id = ci.jce_cluster_id ");
			sql.append("WHERE si.is_valid = '1' AND si.jce_boss_user_id = ? AND si.jce_service_code = ? AND si.jce_instance_key IN ('-999'");
			
		}
		else if(flag == CSCPFaceServiceUtil.RELATIONSHIP_INSTANCE_WITH_CLUSTER)//删除关联关系
		{
//			sql.append("update jce_cluster_instance as ci right join jce_service_instance as si1 on si1.id = ci.jce_cluster_id right join jce_service_instance as si2 on si2.id = ci.jce_instance_id ");
//			sql.append("set ci.is_valid = '0',ci.update_time = ? ");
//			sql.append("where ci.is_valid = '1' and si1.is_valid = '1' and si2.is_valid = '1' and si1.jce_instance_key = ? and si1.jce_boss_user_id = ? and si2.jce_boss_user_id = ? and si1.jce_service_code = ? and si2.jce_service_code = 'EC2' and si2.jce_instance_key in ('-999'");
			// modified by baiyunqi 20130408
			sql.append("DELETE ci.* FROM jce_cluster_instance AS ci RIGHT JOIN jce_service_instance AS si1 ON si1.id = ci.jce_cluster_id RIGHT JOIN jce_service_instance AS si2 ON si2.id = ci.jce_instance_id ");
			// modified by cdchenhl 20130618
			if("JECS".equals(serviceType))
			{
				sql.append("WHERE ci.is_valid = '1' AND si1.is_valid = '1' AND si2.is_valid = '1' AND si1.jce_instance_key = ? AND si1.jce_boss_user_id = ? AND si2.jce_boss_user_id = ? AND si1.jce_service_code = ? AND si2.jce_service_code in ('AS','ELB') AND si2.jce_instance_key IN ('-999'");
			}
			else
			{
				sql.append("WHERE ci.is_valid = '1' AND si1.is_valid = '1' AND si2.is_valid = '1' AND si1.jce_instance_key = ? AND si1.jce_boss_user_id = ? AND si2.jce_boss_user_id = ? AND si1.jce_service_code = ? AND si2.jce_service_code = 'EC2' AND si2.jce_instance_key IN ('-999'");
			}
			argsList.add(instanceId.substring(0, instanceId.indexOf(",")));
			instanceId = instanceId.substring(instanceId.indexOf(",") + 1);
			argsList.add(userId);
		}
		argsList.add(userId);
		argsList.add(serviceType);
		String[] items = instanceId.split(",");
		for(String item : items)
		{
			sql.append(" , ?");
			argsList.add(item);
		}
		sql.append(" )");
		Object[] args = argsList.toArray();
		int ret = jdbcTemplate.update(sql.toString(), args);
		log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "ServerConsistencyDao", "deleteInstance") + "{userId:" + userId + ",serviceType:" + serviceType + ",instanceId:" + instanceId + ",flag:" + flag + "}");
		return ret;
	}
	
	/**
	 * 查询 服务实体类的主键
	 * 
	 * @param userId 用户ID
	 * @param serviceType 服务类型
	 * @param instanceId 实例
	 * 
	 * @return boolean 返回
	 */
	private long[] queryKey(String userId, String serviceType,String instanceId) {
		List<String> argsList = new ArrayList<String>();
		StringBuilder sql = new StringBuilder();
		sql.append("select id from jce_service_instance ");
		sql.append("where is_valid = '1' and jce_boss_user_id = ? and jce_service_code = ? and jce_instance_key in ('-999'");
		argsList.add(userId);
		argsList.add(serviceType);
		if(CSCPFaceServiceUtil.isEmpty(instanceId))
		{
			argsList.add(CSCPFaceServiceUtil.NULL);
		}
		else
		{
			String[] items = instanceId.split(",");
			for(String item : items)
			{
				sql.append(" ,?");
				argsList.add(item);
			}
		}
		sql.append(")");
		Object[] args = argsList.toArray();
		List<Map<String, Object>> result = jdbcTemplate.queryForList(sql.toString(), args);
		long[] ids = new long[result.size()];
		for(int i = 0 ; i < ids.length ; i ++)
		{
			ids[i] = (Long)result.get(i).get("id");
		}
		return ids;
	}
	
	/**
	 * 组装服务实例 
	 */
	private ServerInstanceInfo createInfo(ServerInfo info,boolean isInstance)
	{
		ServerInstanceInfo instance = new ServerInstanceInfo();
		instance.setUserId(info.getUserId());
		instance.setEventTime(info.getEventTime());
		if(isInstance)
		{
			if(CSCPFaceServiceUtil.isEmpty(info.getInstanceId()))
			{
				instance.setInstanceId(CSCPFaceServiceUtil.NULL);
			}
			else
			{
				instance.setInstanceId(info.getInstanceId());
			}
			if(CSCPFaceServiceUtil.isEmpty(info.getInstanceName()))
			{
				instance.setInstanceName(CSCPFaceServiceUtil.NULL);
			}
			else
			{
				instance.setInstanceName(info.getInstanceName());
			}
		}
		else
		{
			if(CSCPFaceServiceUtil.isEmpty(info.getClusterId()))
			{
				instance.setInstanceId(CSCPFaceServiceUtil.NULL);
			}
			else
			{
				instance.setInstanceId(info.getClusterId());
			}
			if(CSCPFaceServiceUtil.isEmpty(info.getClusterName()))
			{
				instance.setInstanceName(CSCPFaceServiceUtil.NULL);
			}
			else
			{
				instance.setInstanceName(info.getClusterName());
			}
		}
		instance.setServiceType(info.getServiceType());
		return instance;
	}
	

	//插入一行数据
	public long insertRow(final String sql,final Object[] args) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			
			public PreparedStatement createPreparedStatement(Connection con)
					throws SQLException {
				PreparedStatement ps = con.prepareStatement(sql);
				for(int i = 1 ; i <= args.length ; i ++)
				{
					ps.setObject(i, args[i - 1]);
				}
				return ps;
			}
			
		}, keyHolder);
		return keyHolder.getKey().longValue();
	}

	/**
	 * 删除服务实例信息
	 * 
	 * @param info 服务实例信息
	 * 
	 * @author chenhualiang
	 * @since 2013-03-02
	 */
	public int delete(final ServerInfo info) {
		final StringBuilder sign = new StringBuilder();
		long[] toDelIds = null;
		if((CSCPFaceServiceUtil.isEmpty(info.getClusterId()) || CSCPFaceServiceUtil.isEmpty(info.getInstanceId())))
		{
			String sourceId = null;
			if(!CSCPFaceServiceUtil.isEmpty(info.getClusterId()))
			{
				sourceId = info.getClusterId();
			}
			else if(!CSCPFaceServiceUtil.isEmpty(info.getInstanceId()))
			{
				sourceId = info.getInstanceId();
			}
			toDelIds = queryKey(info.getUserId(), info.getServiceType(), sourceId);
		}
		int ret = this.transactionTemplate.execute(new TransactionCallback<Integer>() {

			public Integer doInTransaction(
					TransactionStatus transactionStatus) {
				try{
					int ret = 0;
					//JSS & JHbase 服务实例
					if("JSS".equals(info.getServiceType()) || "JHbase".equalsIgnoreCase(info.getServiceType()))
					{
						ret = deleteInstance(
								info.getUserId(), 
								info.getServiceType(), 
								CSCPFaceServiceUtil.NULL, 
								
								CSCPFaceServiceUtil.NOT_CLUSTER_INSTANCE);
					}
					//普通实例服务
					else if(!"EC2".equals(info.getServiceType()) && 
							!"ELB".equals(info.getServiceType()) && 
							!"JECS".equals(info.getServiceType()) && 
							!"AS".equals(info.getServiceType()))
					{
						ret = deleteInstance(
								info.getUserId(), 
								info.getServiceType(), 
								info.getInstanceId(), 
								
								CSCPFaceServiceUtil.NOT_CLUSTER_INSTANCE);
					}
					//EC2服务实例
					else if(CSCPFaceServiceUtil.isEmpty(info.getClusterId()))
					{
						ret = deleteInstance(
								info.getUserId(), 
								info.getServiceType(), 
								info.getInstanceId(), 
								
								CSCPFaceServiceUtil.EC2_IN_CLUSTER);
						sign.append("true");
					}
					//ELB或AS或JECS服务实例
					else if(CSCPFaceServiceUtil.isEmpty(info.getInstanceId()))
					{
						ret = deleteInstance(
								info.getUserId(), 
								info.getServiceType(), 
								info.getClusterId(), 
								
								CSCPFaceServiceUtil.INSTANCE_OF_CLUSTER);
					}
					else
					{
						//删除EC2与AS或ELB的关系 或 ELB AS 与 JECS的关系
						ret = deleteInstance(
								info.getUserId(), 
								info.getServiceType(), 
								info.getClusterId() + "," + info.getInstanceId(), 
								CSCPFaceServiceUtil.RELATIONSHIP_INSTANCE_WITH_CLUSTER);
					}
					return ret;
				}
				catch (Throwable e) {
					log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao"), e);
					transactionStatus.setRollbackOnly();
					throw new RuntimeException("when delete exception",e);
				}
			}
		});
		if(sign.toString().length() > 0 && ret > 0)
		{
			sendEC2ipToGather();
		}
		if(toDelIds != null && toDelIds.length > 0 && ret > 0)
		{
			String[] toDeletedArray = null;
			if(!CSCPFaceServiceUtil.isEmpty(info.getClusterId()))
			{
				toDeletedArray = info.getClusterId().split(",");
			}
			else if(!CSCPFaceServiceUtil.isEmpty(info.getInstanceId()))
			{
				toDeletedArray = info.getInstanceId().split(",");
			}
			if(toDeletedArray == null )
			{
				return ret;
			}
			for(int i = 0 ; i < toDeletedArray.length && i < toDelIds.length; i ++)
			{
				String clusterId = toDeletedArray[i];
				long id = toDelIds[i];
				DeleteInstance delInstance = new DeleteInstance(id,clusterId,info.getServiceType(),info.getUserId());
				removeServiceInstance(delInstance);
			}
		}
		return ret;
	}
	
	/**
	 * 删除与实例相关的历史，配置数据 
	 */
	public void removeServiceInstance(DeleteInstance delInstance)
	{
		deleteInstanceQueue.offer(delInstance);
	}
	
	/**
	 * 删除与实例相关的历史，配置数据 
	 */
	public int deleteServiceInstance(final DeleteInstance delInstance)
	{
		int ret = this.transactionTemplate.execute(new TransactionCallback<Integer>() {

			public Integer doInTransaction(TransactionStatus transactionStatus) {
				int ret = 0;
				try{
					ret = removeRule(delInstance);
					ret += removeDataResult(delInstance);
				}catch (Exception e) {
					log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao"), e);
					transactionStatus.setRollbackOnly();
					throw new RuntimeException("when delete exception",e);
				}
				return ret;
			}
		});
		if(ret > 0 && "JECS".equals(delInstance.getServiceType()))
		{
			String ELB_id = redisManager.getKeyValue("JECS_RELATION#JECS#" +  delInstance.getInstanceId());
			if(!CSCPFaceServiceUtil.isEmpty(ELB_id))
			{
				redisManager.expire("JECS_RELATION#ELB#" +  ELB_id, 1);
				redisManager.expire("JECS_RELATION#JECS#" + delInstance.getInstanceId(), 1);
			}
//			redisManager.expire("JECS_RELATION#AS#" + delInstance.getInstanceId(), 1);
		}
		return ret;
	}
	
	public int removeTableDatas(String field,String table,List<Long> ids)
	{
		if(ids == null || ids.isEmpty())
		{
			return 0;
		}
		String sql = "DELETE FROM %1$s WHERE %2$s in ('-999'";
		for(long id : ids)
		{
			sql = sql + ",'" + id + "'";
		}
		sql = sql + ")";
		sql = String.format(sql, table,field);
		return jdbcTemplate.update(sql);
	}
	
	public List<Long> queryTableDatas(String field,String table,String idField,List<Long> ids)
	{
		if(ids == null || ids.isEmpty())
		{
			return new ArrayList<Long>();
		}
		String sql = "SELECT %1$s FROM %2$s WHERE %3$s in ('-999'";
		for(long id : ids)
		{
			sql = sql + ",'" + id + "'";
		}
		sql = sql + ")";
		sql = String.format(sql,idField,table,field);
		return jdbcTemplate.queryForList(sql,Long.class);
	}
	
	public int removeRule(DeleteInstance delInstance)
	{
		List<Long> instanceList = new ArrayList<Long>();
		instanceList.add(delInstance.getId());
		int ret = 0;
		//读取服务实例告警规则id集合
		List<Long> ruleList = queryTableDatas("jce_usin_id", "jce_alarm_rule", "id", instanceList);
		//读取服务实例告警规则明细id集合
		List<Long> ruleDetailList = queryTableDatas("jce_alarm_rule_id", "jce_alarm_rule_detail", "id", ruleList);
		//删除告警历史记录
		ret = removeTableDatas("jce_alarm_rule_detail_id", "jce_alarm_his", ruleDetailList);
		//删除服务实例告警规则明细
		ret += removeTableDatas("jce_alarm_rule_id", "jce_alarm_rule_detail", ruleList);
		//删除服务实例告警规则
		ret += removeTableDatas("jce_usin_id", "jce_alarm_rule", instanceList);
		return ret;
	}
	
	/**
	 * 删除数据结果表 
	 */
	public int removeDataResult(DeleteInstance delInstance)
	{
		String sql = "DELETE FROM jce_%1$s_dataresult_1m WHERE jce_usin_id = ?";
		sql = String.format(sql, delInstance.getServiceType().toLowerCase());
		return jdbcTemplate.update(sql, delInstance.getId());
	}

	/**
	 * 向 Gather 发送EC2 IP信息
	 */
	public void sendEC2ipToGather() {
		
		commonTaskExecutor.execute(new Runnable() {
			@Override
			public void run() {
				try{
					String sql = "select jce_instance_key from jce_service_instance where is_valid = '1' and jce_service_code = 'EC2'";
					List<String> vmlist = jdbcTemplate.queryForList(sql, String.class);
					if(vmlist == null || vmlist.isEmpty())
					{
						return ;
					}
					setIpList.setIPList(vmlist);
				}catch (Throwable e) {
					log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao"),e);
				}
			}
		});
	}

	/**
	 * 创建普通服务实例（非AS ELB EC2，即没有集群关系的实例）
	 * 
	 * @param info 同步请求数据
	 * 
	 * @author chenhualiang
	 * @since 2013-03-05
	 */
	public void createSimpleInstance(final ServerInfo info) {
		int ret = this.transactionTemplate.execute(new TransactionCallback<Integer>() {

			public Integer doInTransaction(
					TransactionStatus transactionStatus) {
				try{
					ServerInstanceInfo instance = createInfo(info, true);
					long[] ids = insertInstance(instance);
					return ids.length;
				}
				catch (Throwable e) {
					//异常回滚
					log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao"), e);
					transactionStatus.setRollbackOnly();
					throw new RuntimeException("when createSimpleInstance exception",e);
				}
			}
		});
		if("EC2".equalsIgnoreCase(info.getServiceType()) && ret > 0)
		{
			sendEC2ipToGather();
		}
	}

	/**
	 * 创建集群实例，并创建它与其下的EC2的关系
	 * 
	 * @param info 同步请求数据
	 * 
	 * @author chenhualiang
	 * @since 2013-03-05
	 */
	public void createClusterAndInstance(final ServerInfo info) {
		
		this.transactionTemplate.execute(new TransactionCallback<Integer>() {

			public Integer doInTransaction(
					TransactionStatus transactionStatus) {
				try{
					//是否EC2已经被创建
					if(!isExistAllInstances(info)){
						ServerInstanceInfo instance = createInfo(info, false);
						insertInstance(instance);
						Calendar cal = Calendar.getInstance();
						cal.setTime(info.getEventTime());
						cal.add(Calendar.MINUTE, 10);
						if(new Date().before(cal.getTime()))
						{
							//返回延迟处理队列
							serverConsistencyBo.addServerInfo(info);
						}
						else
						{
							//超时未获得EC2同步信息数据，丢弃本次请求
							log.warn(CommonLogUtil.makeWarnHead(
									"ServiceInterface", 
									"ServerConsistencyDao", 
									"createClusterAndInstance")
									+ "warn:consistency data losed when data time out,consistencyData=" 
									+ JSONObject.toJSONString(info));
						}
						return 0;
					}
					ServerInstanceInfo instance = createInfo(info, false);
					//保存AS或ELB实例 并返回ID
					long clusterId = insertInstance(instance)[0];
					//查询关联的EC2实例ID
					long[] instanceIds = queryKey(info.getUserId(),"EC2",info.getInstanceId());
					//创建集群关系
					insertClusterWithInstance(clusterId, instanceIds, info);
				}
				catch (Throwable e) {
					log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao"), e);
					transactionStatus.setRollbackOnly();
					throw new RuntimeException("when createClusterAndInstance exception",e);
				}
				return 0;
			}
			
		});
		
	}
	
	/**
	 * 查询是否一个集群下的所有的实例都存在
	 * 
	 * @param info 同步请求数据
	 * 
	 * @return boolean 是否存在。true：存在；false：不存在
	 */
	private boolean isExistAllInstances(ServerInfo info) {
		List<String> argsList = new ArrayList<String>();
		StringBuilder sql = new StringBuilder();
		sql.append("select count(1) as rowCount from jce_service_instance ");
		sql.append("where is_valid = '1' and jce_boss_user_id = ? and jce_service_code = 'EC2' and jce_instance_key in ('-999'");
		argsList.add(info.getUserId());
		int count = 0 ;
		//请求数据中要求的EC2组
		String[] items = info.getInstanceId().split(",");
		for(String item : items)
		{
			item = item.trim();
			if(CSCPFaceServiceUtil.isEmpty(item) || argsList.contains(item) )
			{
				continue;
			}
			argsList.add(item);
			sql.append(" , ?");
			count ++;
		}
		Object[] args = argsList.toArray();
		sql.append(" )");
		List<Map<String, Object>> result = jdbcTemplate.queryForList(sql.toString(), args);
		if (result == null || result.isEmpty()) {
			return false;
		} else {
			Long rowCount = (Long) result.get(0).get("rowCount");
			//预期结果与查询结果 对比
			return rowCount.intValue() == count;
		}
	}

	/**
	 * 创建JECS服务实例
	 */
	public void createJECSInstance(final ServerInfo info) {
		
		this.transactionTemplate.execute(new TransactionCallback<Integer>() {

			public Integer doInTransaction(
					TransactionStatus transactionStatus) {
				try{
					ServerInstanceInfo instance = createInfo(info, false);
					//保存JECS实例 并返回ID
					long clusterId = insertInstance(instance)[0];
					//查询关联的AS和ELB实例ID
					long[] instanceIds = new long[2];
					instanceIds[1] = queryKey(info.getUserId(),"ELB",info.getInstanceId())[0];
					instanceIds[0] = queryKey(info.getUserId(),"AS",info.getClusterId())[0];
					//创建集群关系
					insertClusterWithInstance(clusterId, instanceIds, info);
					redisManager.setKeyValue("JECS_RELATION#ELB#" +  info.getInstanceId(), info.getClusterId());
					redisManager.setKeyValue("JECS_RELATION#JECS#" + info.getClusterId(), info.getInstanceId());
//					redisManager.setKeyValue("JECS_RELATION#AS#" + info.getClusterId(), info.getClusterId());
				}
				catch (Throwable e) {
					log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao"), e);
					transactionStatus.setRollbackOnly();
					throw new RuntimeException("when createJECSInstance exception",e);
				}
				return 0;
			}
			
		});
	}
	
	private class DeleteInstanceThread extends Thread{
		
		private DeleteInstanceThread()
		{
			setName("DeleteInstanceThread");
			setDaemon(true);
			start();
		}
		
		@Override
		public void run() {
			
				while(true)
				{
					try{
						DeleteInstance delInstance = null;
						//阻塞取出deleteInstanceQueue队列中的数据
						while((delInstance = deleteInstanceQueue.take()) != null)
						{
							CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.ServiceInterface.deleteServiceInstanceDetail", false, true);
							try {
								//执行删除
								deleteServiceInstance(delInstance);
							} catch (Throwable e) {
								Profiler.functionError(callerInfo);
								log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao_1"), e);
							}
							finally
							{
								Profiler.registerInfoEnd(callerInfo);
								try {
									sleep(1L);
								} catch (InterruptedException e1) {
									log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao_2"), e1);
								}
							}
						}
					} catch (Throwable e) {
						log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao_3"), e);
						try {
							sleep(10000L);
						} catch (InterruptedException e1) {
							log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao_4"), e1);
						}
					}
					finally
					{
						try {
							sleep(1000L);
						} catch (InterruptedException e1) {
							log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyDao_5"), e1);
						}
					}
				}
		}
		
	}
	
}