package com.jd.cloudeye.cscp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONObject;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.service.bo.ASQueryBo;
import com.jd.cloudeye.cscp.service.model.ASQuery;
import com.jd.cloudeye.cscp.service.model.CloudQuery;
import com.jd.cloudeye.cscp.service.model.Metrics;
import com.jd.cloudeye.cscp.service.model.ServerConsistencyState;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


/***
 * AS指标查询接口 
 * 
 * @author chenhualiang
 * @since 2013-03-8
 */
@Controller
@RequestMapping("/asQuery")
public class ASQueryService {
	
	
	private static final Logger log = Logger.getLogger(ASQueryService.class);
	
	@Value("${as.token}")
	private String asToken;
	
	@Autowired
	private ASQueryBo asQueryBo;
	
	
	/**
	 * AS指标查询
	 * 
	 * @param response
	 * @param requestToken 从head传过来的验证token
	 * @param clusterMetrics 查询请求文本
	 * 
	 * @author chenhualiang
	 * @since 2013-03-8
	 * 
	 */
	@RequestMapping(method = RequestMethod.POST)
	public void asQuery(
			HttpServletResponse response,
			//服务器验证token
			@RequestHeader(value = "token",required = false) String requestToken,
			@RequestBody String clusterMetrics
			)
	{
		CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.ServiceInterface.asQuery", false, true);
		if(log.isDebugEnabled())
		{
			log.debug("******as query:" + clusterMetrics + "||||||||requestToken=" + requestToken);
		}
		//token 校验
		if(!CSCPFaceServiceUtil.isEmpty(asToken) && !CSCPFaceServiceUtil.isEmpty(requestToken))
		{
			if(CSCPFaceServiceUtil.isEmpty(requestToken) ||
				!requestToken.equalsIgnoreCase(asToken))
			{
				log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "ASQueryService", "asQuery") + " token is not right :" + requestToken);
				//反馈信息
				sendMessage(response, ServerConsistencyState.Fail.toString());
				Profiler.registerInfoEnd(callerInfo);
				return ;
			}
		}
		else
		{
			if(CSCPFaceServiceUtil.isEmpty(requestToken))
			{
				log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "ASQueryService", "asQuery") + "no token request :" + clusterMetrics);
			}
		}
		String retContent = null;
		try{
			retContent = queryASInfo(clusterMetrics);
		}
		catch (Exception e) {
			Profiler.functionError(callerInfo);
			retContent = ServerConsistencyState.Fail.toString();
			log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ASQueryService"),e);
		}
		sendMessage(response, retContent);
		Profiler.registerInfoEnd(callerInfo);
	}
	
	/**
	 * as查询
	 * 
	 * @param clusterMetrics 请求数据
	 * 
	 * @return String 反馈数据
	 * 
	 * @author chenhualiang
	 * @since 2013-03-06
	 */
	private String queryASInfo(String clusterMetrics) {
		ASQuery query = null;
		try{
			query = JSONObject.parseObject(clusterMetrics, ASQuery.class);
		}catch (Exception e) {
			log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "ASQueryService", "queryASInfo") + "request body format is not right :" + clusterMetrics);
			return ServerConsistencyState.Illegal.toString();
		}
		Map<String, Metrics> metricsMap = checkASQuery(query);
		if(metricsMap != null)
		{
			return asQueryBo.doASQuery(metricsMap,query);
		}
		log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "ASQueryService", "queryASInfo") + "request body format is not right :" + clusterMetrics);
		return ServerConsistencyState.Illegal.toString();
	}
	
	/**
	 * AS查询参数校验 
	 * 
	 * @param query 
	 * 
	 * @return boolean 是否校验成功 true：校验成功；false：校验失败
	 */
	private Map<String, Metrics> checkASQuery(ASQuery query) {
		
		if(query == null)
		{
			return null;
		}
		if(CSCPFaceServiceUtil.isEmpty(query.getPeriod()) || !query.getPeriod().matches("\\d+"))
		{
			return null;
		}
		if(CSCPFaceServiceUtil.isEmpty(query.getTimeInterval()) || !query.getTimeInterval().matches("\\d+"))
		{
			return null;
		}
		if(query.getData() == null || query.getData().isEmpty())
		{
			return null;
		}
		Map<String, Metrics> metricsMap = new HashMap<String, Metrics>();
		for(CloudQuery cloud : query.getData())
		{
			if(CSCPFaceServiceUtil.isEmpty(cloud.getASGroupID()))
			{
				return null;
			}
			
			//EC2 Metrics
			if(cloud.getMetricsData() != null && !cloud.getMetricsData().isEmpty())
			{
				for(Metrics metrics : cloud.getMetricsData())
				{
					if(CSCPFaceServiceUtil.isEmpty(metrics.getMetrics()))
					{
						return null;
					}
					String computor = metrics.getComputor();
					if(CSCPFaceServiceUtil.isEmpty(computor))
					{
						return null;
					}
					computor = metrics.getComputor().toUpperCase();
					if(CSCPFaceServiceUtil.COMPUTOR_NAME_MAP.containsKey(computor))
					{
						metrics.setComputor(computor);
						metricsMap.put(cloud.getASGroupID() + "#" + metrics.getMetrics() + "#" + computor, metrics);
					}
					else
					{
						return null;
					}
					metrics.setData(new ArrayList<String[]>());
				}
			}
			
			//ELB Metrics
			if(cloud.getELBMetricsData() != null && !cloud.getELBMetricsData().isEmpty())
            {
                for(Metrics metrics : cloud.getELBMetricsData())
                {
                    if(CSCPFaceServiceUtil.isEmpty(metrics.getMetrics()))
                    {
                        return null;
                    }
                    String computor = metrics.getComputor();
                    if(CSCPFaceServiceUtil.isEmpty(computor))
                    {
                        return null;
                    }
                    computor = metrics.getComputor().toUpperCase();
                    if(CSCPFaceServiceUtil.COMPUTOR_NAME_MAP.containsKey(computor))
                    {
                        metrics.setComputor(computor);
                        metricsMap.put(cloud.getASGroupID() + "#" + metrics.getMetrics() + "#" + computor, metrics);
                    }
                    else
                    {
                        return null;
                    }
                    metrics.setData(new ArrayList<String[]>());
                }
            }
		}
		return metricsMap;
	}
	
	/**
	 * 反馈数据 
	 */
	private void sendMessage(HttpServletResponse response,String content)
	{
		response.setContentType("application/json;charset=UTF-8");
		try{
			log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "ASQueryService", "sendMessage") + content);
			response.getWriter().write(content);
			response.getWriter().flush();
			response.getWriter().close();
		}catch (Exception e) {
		}
	}
}
