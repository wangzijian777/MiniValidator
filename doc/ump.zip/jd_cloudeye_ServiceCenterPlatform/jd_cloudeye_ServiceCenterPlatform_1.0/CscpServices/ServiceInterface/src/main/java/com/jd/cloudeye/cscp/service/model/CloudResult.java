package com.jd.cloudeye.cscp.service.model;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * AS查询集群查询结果集
 */
public class CloudResult {
	
	/**
	 * 集群ID
	 */
	private String ASGroupID;
	
	/**
	 * 查询EC2指标及结果集合 
	 */
	private List<Metrics> ResultData;
	
	/**
     * 查询ELB指标及结果集合 
     */
    private List<Metrics> ELBResultData;
	
	public CloudResult(){}
	
	public CloudResult(CloudQuery query){
		this.ASGroupID = query.getASGroupID();
		this.ResultData = query.getMetricsData();
		this.ELBResultData = query.getELBMetricsData();
	}

	@JSONField(name = "ASGroupID")
	public String getASGroupID() {
		return ASGroupID;
	}

	public void setASGroupID(String aSGroupID) {
		ASGroupID = aSGroupID;
	}

	@JSONField(name = "ResultData")
	public List<Metrics> getResultData() {
		return ResultData;
	}

	public void setResultData(List<Metrics> ResultData) {
		this.ResultData = ResultData;
	}

	@JSONField(name = "ELBResultData")
    public List<Metrics> getELBResultData() {
        return ELBResultData;
    }

    public void setELBResultData(List<Metrics> eLBResultData) {
        ELBResultData = eLBResultData;
    }

}
