package com.jd.cloudeye.cscp.service.model;

import java.util.ArrayList;
import java.util.List;

import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

/**
 * 服务实例存活反馈 
 */
public class AliveStateResult {
	
	/**
	 * 反馈状态
	 */
	private String state;
	
	/**
	 * 反馈状态描述
	 */
	private String message;
	
	/**
	 * 反馈时间
	 */
	private String responseTime;
	
	/**
	 * 反馈结果集
	 */
	private List<String[]> data = new ArrayList<String[]>();
	
	public AliveStateResult(){}

	public AliveStateResult(List<String> instanceIds) {
		for(String instanceId : instanceIds)
		{
			data.add(new String[]{instanceId,CSCPFaceServiceUtil.UNKNOW_STATE});
		}
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}

	public List<String[]> getData() {
		return data;
	}

	public void setData(List<String[]> data) {
		this.data = data;
	}
	
}
