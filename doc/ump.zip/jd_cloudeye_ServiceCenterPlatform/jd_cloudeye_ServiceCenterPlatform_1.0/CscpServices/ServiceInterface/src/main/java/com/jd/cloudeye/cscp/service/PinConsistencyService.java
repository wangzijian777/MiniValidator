package com.jd.cloudeye.cscp.service;

import java.io.IOException;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.concurrent.CountDownLatch;
//import java.util.concurrent.TimeUnit;

//import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.service.model.ServerConsistencyState;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;
import com.jd.cloudeye.cscp.service.util.SimpleHttpClient;
import com.jd.common.web.cookie.CookieCipherTools;


/**
 * server实例同步接口 (带pin)
 * 
 * @author chenhualiang
 * @since 2013-05-08
 */
@Controller
@RequestMapping("/consistencyPIN")
public class PinConsistencyService {
	
	private static final Logger log = Logger.getLogger(PinConsistencyService.class);
	
	@Autowired
	private ServerConsistencyService serverConsistencyService;
	
	@Autowired
	private CookieCipherTools cookieCipherTools;
	
//	@Resource(name="pinTaskExecutor")
//	private TaskExecutor pinTaskExecutor; 
	
	@Value("${cookie.cipher.key}")
	private String cookieCipherKey;
	
	@Value("${boss.accessable.url}")
	private String bossAccessableUrl;

	/**
	 * server实例同步接口 (带pin)
	 * 
	 * @param response HttpServletResponse
	 * @param requestToken 客户端请求携带的token值
	 * 
	 * @param method 通知事件create：创建事件;delete：删除事件;update：修改事件
	 * @param pin 用户pin
	 * @param serviceType 服务类型
	 * @param clusterId 集群ID
	 * @param clusterName 集群名称
	 * @param instanceId 服务实例ID
	 * @param intanceName 服务实例名称
	 * @param instanceName 服务实例名称
	 * @param eventTime 事件触发时间 yyyyMMddHHmmssSSS
	 * 
	 * @author chenhualiang
	 * @since 2013-02-28
	 */
	@RequestMapping(method = RequestMethod.POST,params = "method")
	public void consistency(
			HttpServletResponse response,
			//服务器验证token
			@RequestHeader(value = "token",required = false) String requestToken,
			//各种参数
			@RequestParam(value = "method",required = false) String method,
			@RequestParam(value = "pin",required = false) String pin,
			@RequestParam(value = "serviceType",required = false) String serviceType,
			@RequestParam(value = "clusterId",required = false) String clusterId,
			@RequestParam(value = "clusterName",required = false) String clusterName,
			@RequestParam(value = "instanceId",required = false) String instanceId,
			@RequestParam(value = "intanceName",required = false) String intanceName,
			@RequestParam(value = "instanceName",required = false) String instanceName,
			@RequestParam(value = "eventTime",required = false) String eventTime
			)
	{
		log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "PinConsistencyService", "consistency") 
				+ "{method=" + method + 
				",pin=" + pin + 
				",serviceType=" + serviceType + 
				",clusterId=" + clusterId + 
				",clusterName=" + clusterName + 
				",instanceId=" + instanceId + 
				",intanceName=" + intanceName + 
				",instanceName=" + instanceName + 
				",eventTime=" + eventTime + 
				",requestToken=" + requestToken + "}");
		
		try{
			if(isAccessable(pin))
			{
				String userId = cookieCipherTools.decrypt(pin, cookieCipherKey);
				serverConsistencyService.consistency(response, requestToken, method, 
						userId, serviceType, clusterId, 
						clusterName, instanceId, intanceName, 
						instanceName, eventTime);
			}
			else{
				sendMessage(response, ServerConsistencyState.Fail.toString());
			}
		}
		catch (Exception e) {
			log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "PinConsistencyService"), e);
			sendMessage(response, ServerConsistencyState.Fail.toString());
		}
	}

	/**
	 * 判断pin是否能云鼎云擎可访问
	 * 
	 * @param pin 用户pin
	 * 
	 * @return boolean 
	 */
	private boolean isAccessable(final String pin) throws IOException {
		if(CSCPFaceServiceUtil.isEmpty(pin))
		{
			return false;
		}
//		final CountDownLatch queryCount = new CountDownLatch(2);
//		final Map<String, Boolean> stat = new HashMap<String, Boolean>();
//		stat.put("hosting", false);
//		stat.put("appengine", false);
//		查询是否能访问| hosting | 云鼎 |
		if(isAccessable("hosting",pin))
		{
			return true;
		}
//		//查询是否能访问| appengine | 云擎 |
		if(isAccessable("appengine",pin))
		{
			return true;
		}
		return false;
//		查询是否能访问| hosting | 云鼎 |
//		pinTaskExecutor.execute(new Runnable() {
//			
//			@Override
//			public void run() {
//				try{
//					stat.put("hosting",isAccessable("hosting",pin));
//				}catch (Throwable e) {
//					log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "PinConsistencyService|hosting"),e);
//				}
//				finally
//				{
//					queryCount.countDown();
//				}
//			}
//
//			
//		});
//		//查询是否能访问| appengine | 云擎 |
//		pinTaskExecutor.execute(new Runnable() {
//			
//			@Override
//			public void run() {
//				try{
//					stat.put("appengine",isAccessable("appengine",pin));
//				}catch (Throwable e) {
//					log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "PinConsistencyService|appengine"),e);
//				}
//				finally
//				{
//					queryCount.countDown();
//				}
//			}
//		});
//		//设置访问超时时间为30秒
//		try {
//			queryCount.await(30, TimeUnit.SECONDS);
//		} catch (Exception e) {
//			return false;
//		}
//		return stat.get("hosting") || stat.get("appengine");
	}
	
	/**
	 * 调用boss接口判断用户pin是否能够访问目标服务 
	 */
	private Boolean isAccessable(String categoryscde, String pin) throws IOException {
		String ret = SimpleHttpClient.httpPostText(bossAccessableUrl,
				new String[][]{
				{"pin",pin},
				{"categoryscde",categoryscde},
				{"ename","jms"}
				}, 
				new String[][]{},
				"utf-8");
		log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "PinConsistencyService", "isAccessable('" 
				+ categoryscde + "','" + pin + "')") + ret);
		if(CSCPFaceServiceUtil.isEmpty(ret))
		{
			return false;
		}
		JSONObject obj = JSON.parseObject(ret);
		if(obj == null)
		{
			return false;
		}
		int code = obj.getIntValue("code");
		JSONObject serviceInfo = obj.getJSONObject("serviceInfo");
		if(serviceInfo == null || code != 200)
		{
			return false;
		}
		int status = serviceInfo.getIntValue("status");
		int available = serviceInfo.getIntValue("available");
		if(status != 1)
		{
			String info = "unknown";
			switch (status) {
			case 0:
				info = "unstart";
				break;
			case 1:
				info = "running";
				break;
			case 2:
				info = "shutdown";
				break;
			default:
				break;
			}
			log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "PinConsistencyService", "isAccessable&status") + info);
			return false;
		}
		if(available != 1)
		{
			String info = "unknown";
			switch (available) {
			case 0:
				info = "unused";
				break;
			case 1:
				info = "useing";
				break;
			case 2:
				info = "refuse";
				break;
			default:
				break;
			}
			log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "PinConsistencyService", "isAccessable&available") + info);
			return false;
		}
		return true;
	}
	
	/**
	 * 反馈数据 
	 */
	private void sendMessage(HttpServletResponse response,String content)
	{
		response.setContentType("application/json;charset=UTF-8");
		try{
			log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "PinConsistencyService", "sendMessage") + content);
			response.getWriter().write(content);
			response.getWriter().flush();
			response.getWriter().close();
		}catch (Exception e) {
		}
	}
}
