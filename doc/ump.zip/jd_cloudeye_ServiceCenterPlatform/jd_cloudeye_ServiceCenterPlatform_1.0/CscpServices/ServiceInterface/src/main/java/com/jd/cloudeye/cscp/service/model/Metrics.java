package com.jd.cloudeye.cscp.service.model;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * AS查询指标 
 */
public class Metrics {
	
	/**
	 * 指标 
	 */
	private String Metrics;
	
	/**
	 * 聚合计算规则 
	 */
	private String Computor;
	
	/***
	 * 查询结果集 
	 */
	private List<String[]> Data;

	@JSONField(name = "Metrics")
	public String getMetrics() {
		return Metrics;
	}
	
	public void addData(String[] data)
	{
		if(Data == null)
		{
			Data = new ArrayList<String[]>();
		}
		Data.add(data);
	}

	public void setMetrics(String metrics) {
		Metrics = metrics;
	}

	@JSONField(name = "Computor")
	public String getComputor() {
		return Computor;
	}

	public void setComputor(String computor) {
		Computor = computor;
	}

	@JSONField(name = "Data")
	public List<String[]> getData() {
		return Data;
	}

	public void setData(List<String[]> data) {
		Data = data;
	}
}
