package com.jd.cloudeye.cscp.service.model;

import java.util.Date;

/**
 * 服务器实例信息
 * 
 * @author chenhualiang
 * @since 2013-02-28
 */
public class ServerInfo {

	/**
	 * 通知事件create：创建事件;delete：删除事件;update：修改事件
	 */
	private String method;
	
	/**
	 * 用户ID
	 */
	private String userId;
	
	/**
	 * 服务类型
	 */
	private String serviceType;
	
	/**
	 * 集群ID
	 */
	private String clusterId;
	
	/**
	 * 集群名称
	 */
	private String clusterName;
	
	/**
	 * 实例ID
	 */
	private String instanceId;
	
	/**
	 * 实例名称
	 */
	private String instanceName;
	
	/**
	 * 事件时间
	 */
	private Date eventTime;

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getClusterId() {
		return clusterId;
	}

	public void setClusterId(String clusterId) {
		this.clusterId = clusterId;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public Date getEventTime() {
		return eventTime;
	}

	public void setEventTime(Date eventTime) {
		this.eventTime = eventTime;
	}
	
}
