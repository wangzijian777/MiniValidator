package com.jd.cloudeye.cscp.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;

/**
 * 用户过滤不保存的（用戶及服務） 
 */
@Component
public class UserServiceTypeFilter {
	
	
	private static Logger log = Logger.getLogger(UserServiceTypeFilter.class);
	
	/**
	 * key=value
	 * value 描述如下
	 * serviceType1:userid1,userid2;serviceType2:userid3,userid4
	 */
	@Value("${filter.userAndServiceType}")
	private String filterContent;
	
	private Map<String, Set<String>> filterMapping = new HashMap<String, Set<String>>();
	
	private boolean init ;
	
	private CountDownLatch count = new CountDownLatch(1);
	
	/**
	 *  过滤方法
	 *  
	 * @param userId 用户ID
	 * @param serviceType 服务类型 
	 *  
	 *  @author chenhualiang
	 */
	public boolean filter(String userId,String serviceType)
	{
		if(!init)
		{
			try {
				count.await();
			} catch (InterruptedException e) {
			}
		}
		Set<String> mapValue = filterMapping.get(serviceType);
		if(mapValue != null)
		{
			if(mapValue.contains(userId.toLowerCase()))
			{
				if(log.isDebugEnabled())
				{
					log.debug(CommonLogUtil.makeInfoHead("ServiceInterface", "UserServiceTypeFilter","userId=" + userId + "&serviceType=" + serviceType ));
				}
				return true;
			}			
		}
		return false;
	}
	
	@PostConstruct
	public void init()
	{
		if(filterContent != null && filterContent.length() > 0)
		{
			String[] eachService = filterContent.split(";");
			for(int i=0;i<eachService.length;i++){
				String serviceName = eachService[i].substring(0, eachService[i].indexOf(":"));
				String serviceUsers = eachService[i].substring(eachService[i].indexOf(":")+1, eachService[i].length());
				String[] serviceAllUser = serviceUsers.split(",");
				Set<String> filterMapVaule = new HashSet<String>();
				for(int j=0;j<serviceAllUser.length;j++){
					filterMapVaule.add(serviceAllUser[j].toLowerCase());
				}
				filterMapping.put(serviceName, filterMapVaule);
			}
		}
		init = true;
		count.countDown();
	}

}
