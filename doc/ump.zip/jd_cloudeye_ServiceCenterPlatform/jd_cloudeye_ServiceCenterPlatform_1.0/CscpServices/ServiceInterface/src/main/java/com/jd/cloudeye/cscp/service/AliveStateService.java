package com.jd.cloudeye.cscp.service;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSON;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.service.bo.AliveStateBo;
import com.jd.cloudeye.cscp.service.model.AliveStateQuery;
import com.jd.cloudeye.cscp.service.model.AliveStateResult;
import com.jd.cloudeye.cscp.service.model.ServerConsistencyState;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * 服务实例存活查询接口类 
 * 
 * 
 * @author chenhualiang
 * @since 2013-03-12
 */
@Controller
@RequestMapping("/queryAliveState")
public class AliveStateService {
	
	private static final Logger log = Logger.getLogger(AliveStateService.class);
	
	@Value("${aliveState.token}")
	private String aliveStateToken;
	
	@Autowired
	private AliveStateBo aliveStateBo;
	
	/**
	 * 查询服务实例存活
	 * 
	 * @param response
	 * @param requestToken 服务使用鉴权的token
	 * @param bodyMessage 请求的body数据
	 * 
	 */
	@RequestMapping(method = RequestMethod.POST)
	public void queryAliveState(
			HttpServletResponse response,
			//服务器验证token
			@RequestHeader(value = "token",required = false) String requestToken,
			@RequestBody String bodyMessage
			)
	{
		CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.ServiceInterface.queryAliveState", false, true);
		if(log.isDebugEnabled())
		{
			log.debug("******alive query:" + bodyMessage + "||||||||requestToken=" + requestToken);
		}
		//token 校验
		if(!CSCPFaceServiceUtil.isEmpty(aliveStateToken) && !CSCPFaceServiceUtil.isEmpty(requestToken))
		{
			if(CSCPFaceServiceUtil.isEmpty(requestToken) ||
				!requestToken.equalsIgnoreCase(aliveStateToken))
			{
				//反馈信息
				sendMessage(response, ServerConsistencyState.Fail.toString());
				Profiler.registerInfoEnd(callerInfo);
				return ;
			}
		}
		else
		{
			if(CSCPFaceServiceUtil.isEmpty(requestToken))
			{
				log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "AliveStateService", "queryAliveState") + "no token request :" + bodyMessage);
			}
		}
		String retContent = null;
		try{
			retContent = queryAliveState(bodyMessage);
		}catch (Throwable e) {
			Profiler.functionError(callerInfo);
			retContent = ServerConsistencyState.Fail.toString();
			log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "AliveStateService"),e);
		}
		sendMessage(response, retContent);
		Profiler.registerInfoEnd(callerInfo);
	}
	
	/**
	 * 解析验证并查询服务实例的状态
	 * 
	 * @param bodyMessage 请求数据
	 * 
	 * @author chenhualiang
	 * @since 2013-03-12
	 */
	private String queryAliveState(String bodyMessage) {
		AliveStateQuery query = null;
		try{
			query = JSON.parseObject(bodyMessage, AliveStateQuery.class);
		}catch (Exception e) {
			// TODO: Nothing
		}
		if(!check(query))
		{
			return  ServerConsistencyState.Illegal.toString();
		}
		AliveStateResult result = null;
		result = aliveStateBo.queryAliveState(query);
		result.setResponseTime(CSCPFaceServiceUtil.getTimeOfNow(CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT));
		result.setMessage("success");
		result.setState("1");
		return JSON.toJSONString(result);
	}

	
	/**
	 * 数据校验 
	 */
	private boolean check(AliveStateQuery query) {
		if(query == null)
		{
			return false;
		}
		if(CSCPFaceServiceUtil.isEmpty(query.getServiceType()))
		{
			return false;
		}
		if(!CSCPFaceServiceUtil.ALIVE_KEY_SERVICE_SET.contains(query.getServiceType()))
		{
			return false;
		}
		if(!CSCPFaceServiceUtil.checkTime(query.getRequestTime(), CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT))
		{
			return false;
		}
		if(query.getInstanceIds() == null || query.getInstanceIds().isEmpty())
		{
			return false;
		}
		return true;
	}

	/**
	 * 反馈数据
	 */
	private void sendMessage(HttpServletResponse response,String content)
	{
		response.setContentType("application/json;charset=UTF-8");
		try{
			log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "AliveStateService", "sendMessage") + content);
			response.getWriter().write(content);
			response.getWriter().flush();
			response.getWriter().close();
		}catch (Exception e) {
		}
	}

}
