package com.jd.cloudeye.cscp.service.bo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.service.dao.ServerConsistencyDao;
import com.jd.cloudeye.cscp.service.model.ServerInfo;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

/**
 * 服务实例同步服务处理类
 * 
 * @author chenhualiang
 * @since 2013-03-1
 */
@Component
public class ServerConsistencyBo {
	
	private static Logger log = Logger.getLogger(ServerConsistencyBo.class);
	
	
	@Autowired
	private ServerConsistencyDao serverConsistencyDao;
	
	/**
	 * AS或ELB提前到达的同步请求数据 
	 */
	private  BlockingQueue<ServerInfo> serverInfoQueue = new LinkedBlockingQueue<ServerInfo>();
	
	/**
	 * 每隔1秒钟执行一次的，处理 AS或ELB提前到达的同步请求数据 
	 */
	private Thread clusterThread ;
	
	//默认的构造方法
	public ServerConsistencyBo()
	{
		clusterThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(true)
				{
					try{
						synchronized (serverInfoQueue) {
							//提前到达数据是否为空，为空表示无需处理
							if(serverInfoQueue.isEmpty())
							{
								continue;
							}
							//获取并处理
							ServerInfo info = serverInfoQueue.poll();
							serverConsistencyDao.createClusterAndInstance(info);
						}
					}catch (Throwable e) {
						log.error(CommonLogUtil.makeErrorHead("AlarmAnalysisCenter", "ServerConsistencyBo"), e);
					}
					finally
					{
						try {
							Thread.sleep(10000l);
						} catch (InterruptedException e) {
						}
					}
				}
				
			}
		});
		clusterThread.setDaemon(true);
		clusterThread.start();
	}
	
	/**
	 * 校验服务类型
	 * 
	 * @param serviceType 参加校验的服务类型
	 * 
	 * @return boolean 是否合法
	 * 
	 * @author chenhualiang
	 * @since 2013-03-20
	 */
	public boolean isValidServiceType(String serviceType)
	{
		return serverConsistencyDao.isValidServiceType(serviceType);
	}
	
	/**
	 * 添加判定为 AS或ELB提前请求同步数据 
	 */
	public void addServerInfo(ServerInfo info)
	{
		serverInfoQueue.offer(info);
	}
	
	/**
	 * 新增或更新服务实例
	 * 
	 * @param info 服务实例信息
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public void createOrUpdateServer(ServerInfo info) {
		if("ELB".equals(info.getServiceType()) || "AS".equals(info.getServiceType()))
		{
			serverConsistencyDao.createClusterAndInstance(info);
		}
		else if("JECS".equals(info.getServiceType()))
		{
			serverConsistencyDao.createJECSInstance(info);
		}
		else
		{
			serverConsistencyDao.createSimpleInstance(info);
		}
	}
	
	/**
	 * 新增或更新服务实例
	 * 
	 * @param info 服务实例信息
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public int updateServerName(ServerInfo info) {
		return serverConsistencyDao.updateName(info);
	}

	/**
	 * 移除服务实例
	 * 
	 * @param info 服务实例信息
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public int removeServer(ServerInfo info) {
		int count = 0;
		if(("ELB".equals(info.getServiceType()) || "AS".equals(info.getServiceType())))
		{
			if(!serverInfoQueue.isEmpty())
			{
				synchronized (serverInfoQueue)
				{
					if(!serverInfoQueue.isEmpty())
					{
						List<ServerInfo> list = new ArrayList<ServerInfo>(serverInfoQueue);
						for(ServerInfo item : list)
						{
							
							if(item.getClusterId().endsWith(info.getClusterId()))
							{
								if(CSCPFaceServiceUtil.isEmpty(info.getInstanceId()))
								{
									item.setEventTime(new Date(0));
									serverInfoQueue.remove(item);
									count ++;
								}
								else
								{
									String[] ids = info.getInstanceId().split(",");
									String[] cacheIds = item.getInstanceId().split(",");
									String[] cacheNames = item.getInstanceName().split(",");
									StringBuilder idSb = new StringBuilder();
									StringBuilder nameSb = new StringBuilder();
									for(int i = 0;i < cacheIds.length ;i++)
									{
										String cacheId = cacheIds[i];
										String cacheName = cacheNames[i];
										boolean isBreak = false;
										for(String id : ids )
										{
											if(!cacheId.equals(id))
											{
												isBreak = true;
												break;
											}
										}
										if(isBreak)
										{
											continue;
										}
										if(idSb.length() > 0)
										{
											idSb.append(",");
										}
										idSb.append(cacheId);
										if(nameSb.length() > 0)
										{
											nameSb.append(",");
										}
										nameSb.append(cacheName);
										count ++;
									}
									item.setInstanceId(idSb.toString());
									item.setInstanceName(nameSb.toString());
								}
								break;
							}
						}
					}
				}
			}
		}
		return serverConsistencyDao.delete(info) + count;
	}

}
