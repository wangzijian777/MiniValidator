package com.jd.cloudeye.cscp.service;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.fastjson.JSON;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.service.bo.ServerConsistencyBo;
import com.jd.cloudeye.cscp.service.model.ServerConsistencyState;
import com.jd.cloudeye.cscp.service.model.ServerInfo;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


/**
 * server实例同步接口 
 * 
 * @author chenhualiang
 * @since 2013-02-28
 */
@Controller
@RequestMapping("/consistency")
public class ServerConsistencyService {
	
	private static final Logger log = Logger.getLogger(ServerConsistencyService.class);
	
	@Autowired
	private ServerConsistencyBo serverConsistencyBo;
	
	@Value("${consistency.token}")
	private String consistencyToken;
	
	@Autowired
	private UserServiceTypeFilter userServiceTypeFilter;
	
	/**
	 * server实例同步接口 
	 * 
	 * @param response HttpServletResponse
	 * @param requestToken 客户端请求携带的token值
	 * 
	 * @param method 通知事件create：创建事件;delete：删除事件;update：修改事件
	 * @param userId 用户ID
	 * @param serviceType 服务类型
	 * @param clusterId 集群ID
	 * @param clusterName 集群名称
	 * @param instanceId 服务实例ID
	 * @param intanceName 服务实例名称
	 * @param instanceName 服务实例名称
	 * @param eventTime 事件触发时间 yyyyMMddHHmmssSSS
	 * 
	 * @author chenhualiang
	 * @since 2013-02-28
	 */
	@RequestMapping(method = RequestMethod.POST,params = "method")
	public void consistency(
			HttpServletResponse response,
			//服务器验证token
			@RequestHeader(value = "token",required = false) String requestToken,
			//各种参数
			@RequestParam(value = "method",required = false) String method,
			@RequestParam(value = "userId",required = false) String userId,
			@RequestParam(value = "serviceType",required = false) String serviceType,
			@RequestParam(value = "clusterId",required = false) String clusterId,
			@RequestParam(value = "clusterName",required = false) String clusterName,
			@RequestParam(value = "instanceId",required = false) String instanceId,
			@RequestParam(value = "intanceName",required = false) String intanceName,
			@RequestParam(value = "instanceName",required = false) String instanceName,
			@RequestParam(value = "eventTime",required = false) String eventTime
			)
	{
		CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.ServiceInterface.consistency", false, true);
		log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "ServerConsistencyService", "consistency") 
				+ "{method=" + method + 
				",userId=" + userId + 
				",serviceType=" + serviceType + 
				",clusterId=" + clusterId + 
				",clusterName=" + clusterName + 
				",instanceId=" + instanceId + 
				",intanceName=" + intanceName + 
				",instanceName=" + instanceName + 
				",eventTime=" + eventTime + 
				",requestToken=" + requestToken + "}");
		//token 校验
		if(!CSCPFaceServiceUtil.isEmpty(consistencyToken) && !CSCPFaceServiceUtil.isEmpty(requestToken))
		{
			if(CSCPFaceServiceUtil.isEmpty(requestToken) ||
				!requestToken.equalsIgnoreCase(consistencyToken))
			{
				//反馈信息
				log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyService") + "token error");
				sendMessage(response, ServerConsistencyState.Fail.toString());
				Profiler.registerInfoEnd(callerInfo);
				return ;
			}
		}
		else
		{
			if(CSCPFaceServiceUtil.isEmpty(requestToken))
			{
				log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "ServerConsistencyService", "consistency") + "no token request :" + serviceType);
			}
			if(CSCPFaceServiceUtil.isEmpty(consistencyToken))
			{
				log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "ServerConsistencyService", "consistency") + "no token in server ");
			}
		}
		//容错处理
		if(!CSCPFaceServiceUtil.isEmpty(intanceName))
		{
			instanceName = intanceName;
		}
		String retContent = null;
		try{
			//业务处理
			retContent = consistency(
				method,userId,
				serviceType,clusterId,
				clusterName,instanceId,
				instanceName,eventTime
				);
		}catch (Throwable e) {
			log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ServerConsistencyService") + "consistency error",e);
			retContent = ServerConsistencyState.Fail.toString();
			Profiler.functionError(callerInfo);
		}
		//反馈信息
		sendMessage(response, retContent) ;
		Profiler.registerInfoEnd(callerInfo);
	}
	
	/**
	 * server实例同步业务处理
	 * 
	 * @param method 通知事件create：创建事件;delete：删除事件;update：修改事件
	 * @param userId 用户ID
	 * @param serviceType 服务类型
	 * @param clusterId 集群ID
	 * @param clusterName 集群名称
	 * @param instanceId 服务实例ID
	 * @param intanceName 服务实例名称
	 * @param eventTime 事件触发时间 yyyyMMddHHmmssSSS
	 * 
	 * @return String 处理结果
	 * <pre>处理结果格式：
	 * {"state":"1","message":"success","responseTime":"20130222100355195"}
	 * 
	 * 解释说明:
	 * state = 0：系统异常;1：成功;2 : 参数无效
	 * message 当state=0时，反馈“fail”；当state=1时，反馈“success”；当state=2时，反馈“parameter illegal”；
	 * responseTime 响应时间，格式:yyyyMMddHHmmssSSS
	 * </pre>
	 * @author chenhualiang
	 * @since 2013-02-28
	 */
	private String consistency(String method, String userId,
			String serviceType, String clusterId, String clusterName,
			String instanceId, String intanceName, String eventTime) {
		StringBuilder content = new StringBuilder();
		//参数组装并验证
		ServerInfo info = createInfo(method, userId, 
				serviceType, clusterId, clusterName, instanceId, 
				intanceName, eventTime);
		if(log.isDebugEnabled())
		{
			log.debug("***consistency request content=" + JSON.toJSONString(info));
		}
		if(info != null)
		{
			/**
			 * 对user & serviceType 进行过滤
			 * 
			 *  2013-07-29
			 */
			if(userServiceTypeFilter.filter(userId, serviceType))
			{
				return ServerConsistencyState.Success.toString();
			}
			try{
				if("create".equalsIgnoreCase(method))
				{
					//更新或新增服务实例
					serverConsistencyBo.createOrUpdateServer(info);
					content.append(ServerConsistencyState.Success.toString());
				}
				else if("update".equalsIgnoreCase(method))
				{
					//修改服务实例名字
					if(serverConsistencyBo.updateServerName(info) > 0){
						content.append(ServerConsistencyState.Success.toString());
					}
				}
				else if("delete".equalsIgnoreCase(method))
				{
					//移除服务实例
					if(serverConsistencyBo.removeServer(info) > 0)
					{
						content.append(ServerConsistencyState.Success.toString());
					}
				}
				//失败
				if(content.length() == 0)
				{
					content.append(ServerConsistencyState.DoNothing.toString());
				}
			}catch (Exception e) {
				//失败反馈
				content.append(ServerConsistencyState.Fail.toString());
			}
		}
		else
		{
			//参数错误
			return ServerConsistencyState.Illegal.toString();
		}
		return content.toString();
	}
	
	/**
	 * 参数组装并验证
	 */
	private ServerInfo createInfo(String method, String userId,
			String serviceType, String clusterId, String clusterName,
			String instanceId, String instanceName, String eventTime)
	{
		ServerInfo info = new ServerInfo();
		boolean pass = false;
		while(!pass)
		{
			//各种验证
			//事件类型必须为create、update或delete，且不能为空 
			if(CSCPFaceServiceUtil.isEmpty(method) ||
				!(method.equalsIgnoreCase("create") ||
				method.equalsIgnoreCase("update") ||
				method.equalsIgnoreCase("delete")) 
			)
			{
				break;
			}
			else
			{
				info.setMethod(method);
			}
			//用户ID不能为空
			if(CSCPFaceServiceUtil.isEmpty(userId))
			{
				break;
			}
			else
			{
				info.setUserId(userId);
			}
			//服务类型不能为空
			if(!serverConsistencyBo.isValidServiceType(serviceType))
			{
				break;
			}
			else
			{
				info.setServiceType(serviceType);
			}
			if("JSS".equals(serviceType) || "JHbase".equalsIgnoreCase(serviceType))
			{
				clusterId = "";
				instanceId = "";
				clusterName = "";
				instanceName = "";
			}
			//有服务ID必有服务名称
			if(method.equalsIgnoreCase("create") && method.equalsIgnoreCase("update") && 
					!CSCPFaceServiceUtil.isEmpty(clusterId) && CSCPFaceServiceUtil.isEmpty(clusterName))
			{
				break;
			}
			else
			{
				if(!CSCPFaceServiceUtil.isEmpty(clusterId) && !CSCPFaceServiceUtil.isEmpty(clusterName) && 
						clusterId.split(",").length != clusterName.split(",").length)
				{
					break;
				}
				info.setClusterId(clusterId);
				info.setClusterName(clusterName);
			}
			//有集群必有服务实例
			if(method.equalsIgnoreCase("create") && !CSCPFaceServiceUtil.isEmpty(clusterId) && CSCPFaceServiceUtil.isEmpty(instanceId))
			{
				break;
			}
			//有服务实例ID必有服务实例名称
			if(!CSCPFaceServiceUtil.isEmpty(instanceId) && !CSCPFaceServiceUtil.isEmpty(instanceName) && 
					instanceId.split(",").length != instanceName.split(",").length)
			{
				break;
			}
			info.setInstanceId(instanceId);
			info.setInstanceName(instanceName);
			//时间事件验证
			if(CSCPFaceServiceUtil.isEmpty(eventTime) ||
				!CSCPFaceServiceUtil.checkTime(eventTime, CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT)
			)
			{
				break;
			}
			else
			{
				info.setEventTime(CSCPFaceServiceUtil.getTime(eventTime,CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT));
			}
			//AS 数据和ELB数据 必须存在clusterId & clusterId
			if("AS".equals(serviceType) || "ELB".equals(serviceType) || "JECS".equals(serviceType))
			{
				if(CSCPFaceServiceUtil.isEmpty(clusterId) || CSCPFaceServiceUtil.isEmpty(clusterName))
				{
					break;
				}
			}
			pass = true;
		}
		//验证通过
		if(pass)
		{
			return info;
		}
		//验证不通过,参数错误
		else
		{
			return null;
		}
	}
	
	/**
	 * 反馈数据 
	 */
	private void sendMessage(HttpServletResponse response,String content)
	{
		response.setContentType("application/json;charset=UTF-8");
		try{
			log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "ServerConsistencyService", "sendMessage") + content);
			response.getWriter().write(content);
			response.getWriter().flush();
			response.getWriter().close();
		}catch (Exception e) {
		}
	}
}
