package com.jd.cloudeye.cscp.service.bo;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.service.dao.ConsistencyAllDao;
import com.jd.cloudeye.cscp.service.dao.ConsistencyPartDao;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllInfo;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * 服务实例同步服务处理类
 * 
 * @author chenhualiang
 * @since 2013-03-1
 */
@Component
public class ConsistencyAllBo {
	
	private static final Logger log = Logger.getLogger(ConsistencyAllBo.class);
	
	@Autowired
	private ConsistencyAllDao consistencyAllDao;
	
	@Autowired
	private ConsistencyPartDao consistencyPartDao;
	
	@Resource(name="commonTaskExecutor")
	private TaskExecutor commonTaskExecutor; 

	public void consistencyAll(final ConsistencyAllInfo requestInfo) {
		
		//全量非批次同步
		if(requestInfo.getSyncTotal() <= 1)
		{
			commonTaskExecutor.execute(new Runnable() {
				
				@Override
				public void run() {
					CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.ServiceInterface.doConsistencyAll_all", false, true);
					try{
						consistencyAllDao.consistencyAll(requestInfo);
					}catch (Throwable e) {
						log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ConsistencyAllBo"), e);
						Profiler.functionError(callerInfo);
					}
					finally
					{
						Profiler.registerInfoEnd(callerInfo);
					}
				}
				
			});
		}
		//全量分批次同步
		else
		{
			commonTaskExecutor.execute(new Runnable() {
				
				@Override
				public void run() {
					CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.ServiceInterface.doConsistencyAll_part", false, true);
					try{
						consistencyPartDao.consistencyAll(requestInfo);
					}catch (Throwable e) {
						log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ConsistencyAllBo"), e);
						Profiler.functionError(callerInfo);
					}
					finally
					{
						Profiler.registerInfoEnd(callerInfo);
					}
				}
				
			});
		}
	}

}
