package com.jd.cloudeye.cscp.sc.common.spring;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import com.jd.ump.profiler.proxy.Profiler;

/**
 * CSC系统心跳 
 */
@Component
public class SystemInitBean implements InitializingBean{

	@Override
	public void afterPropertiesSet() throws Exception {
		Profiler.InitHeartBeats("JDCE.CSC.heartbeat");
	}
	

}
