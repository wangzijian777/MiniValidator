package com.jd.cloudeye.cscp.ac.service.impl;

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.ac.mail.Mail;
import com.jd.cloudeye.cscp.ac.mail.SMSWebServiceSoap;
import com.jd.cloudeye.cscp.ac.service.SendEmailAndPhone;
import com.jd.cloudeye.cscp.ac.vo.AlarmCenterUtil;
import com.jd.mobilephonemsg.sender.ws.server.newmessageservice.Message;
import com.jd.mobilephonemsg.sender.ws.server.newmessageservice.MmsResult;
import com.jd.mobilephonemsg.sender.ws.server.newmessageservice.NewMessageSender;
import com.jd.test.InforService;
import com.jd.test.InforServiceImplService;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

public class SendEmailAndPhoneImpl implements SendEmailAndPhone {

	private Log log = LogFactory.getLog(SendEmailAndPhoneImpl.class);
	
	private SMSWebServiceSoap sMSWebServiceSoap;
	private NewMessageSender newMessageSender;
	
	private String phoneFlag;
	
	public String getPhoneFlag() {
		return phoneFlag;
	}
	public void setPhoneFlag(String phoneFlag) {
		this.phoneFlag = phoneFlag;
	}
	public SMSWebServiceSoap getsMSWebServiceSoap() {
		return sMSWebServiceSoap;
	}
	public void setsMSWebServiceSoap(SMSWebServiceSoap sMSWebServiceSoap) {
		this.sMSWebServiceSoap = sMSWebServiceSoap;
	}
	public NewMessageSender getNewMessageSender() {
		return newMessageSender;
	}
	public void setNewMessageSender(NewMessageSender newMessageSender) {
		this.newMessageSender = newMessageSender;
	}
	/**
	 * 调用公司接口发送手机短信信息
	 * @param mobiles 手机号码，多个号码间用","分开
	 * @param body	短信内容
	 */
	public void sendNetWorkMessage(String mobiles, String body) {
		CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.AlarmCenter.sendNetWorkMessage", false, true);
		try {
			Message message = new Message();
			message.setMobileNum(mobiles);
			message.setMsgContent(body);
			message.setSenderNum(phoneFlag);
			message.setOrderId("");
			log.info("mobiles is: "+mobiles);
			log.info("alarm content is: "+body);
			log.info("phoneFlag is: "+phoneFlag);
			MmsResult mmsResult = newMessageSender.sentMessage(message);
			if(!"1".equals(mmsResult.getReceiptNum())) {
				log.error(CommonLogUtil.makeErrorHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SEND_CLASSNAME) + "公司发送手机短信接口异常，返回：" + mmsResult.getReceiptDesc());
			}
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			log.error(CommonLogUtil.makeErrorHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SEND_CLASSNAME) + "调用公司接口发送手机短信异常", e);
		}
		Profiler.registerInfoEnd(callerInfo);
	}
	
	 /**
     * 调用公司邮件接口发送邮件
     * @param subject 邮件主题
     * @param body 邮件内容
     * @param address 收件地址
     */
    public void sendNetWorkEmail(String subject, String body, String address) {
    	CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.AlarmCenter.sendemail", false, true);
    	try {
			Mail mail = new Mail();
			mail.setMailSubject(subject);
			mail.setMailBody(body);
			mail.setMailAddress(address);
			sMSWebServiceSoap.sendMail(mail);
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			log.error(CommonLogUtil.makeErrorHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SEND_CLASSNAME) + "调用公司接口发送邮件异常：", e);
		}
		Profiler.registerInfoEnd(callerInfo);
    }
    
    /**
     * 供测试使用
     * @param type
     * @param address
     * @param subject
     * @param context
     * @return
     */
    private InforService test(int type,String address,String subject,String context) {
    	String token = "b07608ca2d55e132cbb23f271aa15526";
    	String url = "http://alarm.ump.360buy.com/ServiceCenter/ws/Infor?wsdl";
    	InforServiceImplService inforServiceImplService;
		try {
			inforServiceImplService = new InforServiceImplService(new URL(url));
			InforService port = inforServiceImplService.getInforServiceImplPort(); 
			if(type == 1) {
				port.sendMail(token, address, subject, context);
			} else if(type == 2) {
				port.sendSMS(token, address, context, "");
			}
			return port;
		} catch (MalformedURLException e) {
			e.printStackTrace();
			return null;
		}
    }
}
