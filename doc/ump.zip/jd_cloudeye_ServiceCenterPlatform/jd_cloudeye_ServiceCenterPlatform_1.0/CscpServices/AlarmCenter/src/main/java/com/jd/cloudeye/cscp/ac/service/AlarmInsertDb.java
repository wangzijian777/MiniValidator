package com.jd.cloudeye.cscp.ac.service;

import java.util.List;

import com.jd.cloudeye.cscp.ac.vo.AlarmInfo;

public interface AlarmInsertDb {

	/**
	 * 向数据库中插入报警信息
	 * @param alarmInfoList
	 */
	void insertAlarmToDb(final List<AlarmInfo> alarmInfoList);
}
