package com.jd.cloudeye.cscp.ac.service.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.ac.service.AlarmInsertDb;
import com.jd.cloudeye.cscp.ac.service.SendEmail;
import com.jd.cloudeye.cscp.ac.service.SendEmailAndPhone;
import com.jd.cloudeye.cscp.ac.vo.AlarmCenterUtil;
import com.jd.cloudeye.cscp.ac.vo.AlarmInfo;
import com.jd.cloudeye.cscp.ac.vo.EmailMoreParam;
import com.jd.cloudeye.cscp.ac.vo.EmailOneParam;

public class SendEmailImpl implements SendEmail {

	private Log log = LogFactory.getLog(SendEmailImpl.class);
	
	private AlarmInsertDb alarmInsertDb;
	
	private SendEmailAndPhone sendEmailAndPhone;
	
	public AlarmInsertDb getAlarmInsertDb() {
		return alarmInsertDb;
	}

	public void setAlarmInsertDb(AlarmInsertDb alarmInsertDb) {
		this.alarmInsertDb = alarmInsertDb;
	}

	public SendEmailAndPhone getSendEmailAndPhone() {
		return sendEmailAndPhone;
	}

	public void setSendEmailAndPhone(SendEmailAndPhone sendEmailAndPhone) {
		this.sendEmailAndPhone = sendEmailAndPhone;
	}

	/**
     * 云监控单个主题、内容发送邮件接口
     * @param emailParam.subject 		--------邮件主题
     * @param emailParam.body 			--------邮件内容
     * @param emailParam.address 		--------收件地址，地址支持批量，地址间用英文","分割
     * @param emailParam.alarmConfigId  --------报警配置ID
     */
    public void sendOneTopic(EmailOneParam emailOneParam) {
    	String subject = emailOneParam.getSubject();
    	String body = emailOneParam.getBody();
    	String address = emailOneParam.getAddress();
    	BigInteger alarmConfigId = emailOneParam.getAlarmConfigId();
    	if(subject != null && !"".equals(subject.trim()) && body != null && !"".equals(body.trim()) && address != null && !"".equals(address.trim()) && alarmConfigId != null)  {
    		//1、发送邮件
    		String[] addrs = address.split(",");
    		Set<String> emailSet = new HashSet<String>();
    		for (String addr : addrs) {
    			emailSet.add(addr.trim());
			}
    		for (String email : emailSet) {
    			if(email != null && !"".equals(email.trim())) {
    				sendEmailAndPhone.sendNetWorkEmail(subject.trim(), body.trim(), email.trim());
    			} else {
    				log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SENDEMAIL_CLASSNAME, AlarmCenterUtil.SENDONE_METHOD_NAME) + "单条发送邮件时存在有不合法的邮件信息");
    			}
			}
    		//2、写入数据库
    		List<AlarmInfo> alarmInfoList = new ArrayList<AlarmInfo>();
			AlarmInfo alarmInfo = new AlarmInfo();
			alarmInfo.setAlarmConfigId(alarmConfigId);
			alarmInfoList.add(alarmInfo);
			alarmInsertDb.insertAlarmToDb(alarmInfoList);
		} else {
			log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SENDEMAIL_CLASSNAME, AlarmCenterUtil.SENDONE_METHOD_NAME) + "发送邮件时调用sendOne方法存在有不合法的邮件信息");
		}
    }
    
	/**
     * 云监控批量发送邮件接口
     * @param emailList 批量发送邮件信息
     * 			emailMoreParam 参数说明实例：
     * 				emailOneParam = emailMoreParam.get(0)
     * 				emailOneParam.subject 		--------邮件主题
     *  			emailOneParam.body 			--------邮件内容
     *  			emailOneParam.address 		--------收件地址	
     * 				emailParam.alarmConfigId    --------报警配置ID
     */
	public void sendMoreTopic(EmailMoreParam emailMoreParam) {
		List<EmailOneParam> emailList = emailMoreParam.getEmailList();
    	if(emailList != null && emailList.size() > 0) {
    		//1、发送邮件
    		List<AlarmInfo> alarmInfoList = new ArrayList<AlarmInfo>();
    		AlarmInfo alarmInfo = null;
    		for (EmailOneParam tempEmailParam : emailList) {
				String subject = tempEmailParam.getSubject();
				String body = tempEmailParam.getBody();
				String address = tempEmailParam.getAddress();
				BigInteger alarmConfigId = tempEmailParam.getAlarmConfigId();
				if(subject != null && !"".equals(subject.trim()) && body != null && !"".equals(body.trim()) && address != null && !"".equals(address.trim()) && alarmConfigId != null)  {
					sendEmailAndPhone.sendNetWorkEmail(subject.trim(), body.trim(), address.trim());
					alarmInfo = new AlarmInfo();
					alarmInfo.setAlarmConfigId(alarmConfigId);
					alarmInfoList.add(alarmInfo);
				} else {
					log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SENDEMAIL_CLASSNAME, AlarmCenterUtil.SENDMORE_METHOD_NAME) + "批量发送邮件时存在有不合法的邮件信息");
					continue;
				}
			}
    		//2、写入数据库
    		if(alarmInfoList.size() > 0) {
    			alarmInsertDb.insertAlarmToDb(alarmInfoList);
    		}
    	} else {
    		log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SENDEMAIL_CLASSNAME, AlarmCenterUtil.SENDMORE_METHOD_NAME) + "调用批量发送邮件接口时参数为空");
    	}
    }
}
