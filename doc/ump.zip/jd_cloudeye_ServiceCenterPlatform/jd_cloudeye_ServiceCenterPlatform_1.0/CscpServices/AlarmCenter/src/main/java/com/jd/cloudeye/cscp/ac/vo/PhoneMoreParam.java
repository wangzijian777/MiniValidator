package com.jd.cloudeye.cscp.ac.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PhoneMoreParam implements Serializable {

	private static final long serialVersionUID = 3735624241915866355L;

	/**
	 * 手机号码、内容集合
	 */
	private List<PhoneOneParam> phoneOneParamList;
	
	/**
	 * 备用字段
	 */
	private String reserve;

	public String getReserve() {
		return reserve;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public List<PhoneOneParam> getPhoneOneParamList() {
		return phoneOneParamList;
	}

	public void setPhoneOneParamList(List<PhoneOneParam> phoneOneParamList) {
		this.phoneOneParamList = phoneOneParamList;
	}
	
	public void add(PhoneOneParam phoneOneParam) {
		if(phoneOneParamList == null) {
			phoneOneParamList = new ArrayList<PhoneOneParam>();
		}
		phoneOneParamList.add(phoneOneParam);
	}
}
