package com.jd.cloudeye.cscp.ac.service;

import javax.jws.WebService;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.jd.cloudeye.cscp.ac.vo.EmailMoreParam;
import com.jd.cloudeye.cscp.ac.vo.EmailOneParam;

@Path("/sendEmail")
@Produces("application/xml")
@Consumes("application/xml")
@WebService
public interface SendEmail {

	/**
     * 云监控单个主题、内容发送邮件接口
     * @param emailOneParam.subject 		--------邮件主题
     * @param emailOneParam.body 			--------邮件内容
     * @param emailOneParam.address 		--------收件地址，地址支持批量，地址间用英文","分割
     * @param emailParam.alarmConfigId      --------报警配置ID
     */
	@POST
	@Path("/sendOneTopic")
    void sendOneTopic(EmailOneParam emailOneParam);
	
	/**
     * 云监控批量发送邮件接口
     * @param emailList 批量发送邮件信息
     * 			emailMoreParam 参数说明实例：
     * 				emailOneParam = emailMoreParam.get(0)
     * 				emailOneParam.subject 		--------邮件主题
     *  			emailOneParam.body 			--------邮件内容
     *  			emailOneParam.address 		--------收件地址	
     *  			emailParam.alarmConfigId    --------报警配置ID
     */
	@POST
	@Path("/sendMoreTopic")
    void sendMoreTopic(EmailMoreParam emailMoreParam);
}