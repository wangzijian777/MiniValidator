package com.jd.cloudeye.cscp.ac.service.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.ac.service.AlarmInsertDb;
import com.jd.cloudeye.cscp.ac.service.SendEmailAndPhone;
import com.jd.cloudeye.cscp.ac.service.SendPhoneMessage;
import com.jd.cloudeye.cscp.ac.vo.AlarmCenterUtil;
import com.jd.cloudeye.cscp.ac.vo.AlarmInfo;
import com.jd.cloudeye.cscp.ac.vo.PhoneMoreParam;
import com.jd.cloudeye.cscp.ac.vo.PhoneOneParam;

public class SendPhoneMessageImpl implements SendPhoneMessage {

	private Log log = LogFactory.getLog(SendPhoneMessageImpl.class);
	
	private AlarmInsertDb alarmInsertDb;
	
	private SendEmailAndPhone sendEmailAndPhone;
	
	public AlarmInsertDb getAlarmInsertDb() {
		return alarmInsertDb;
	}

	public void setAlarmInsertDb(AlarmInsertDb alarmInsertDb) {
		this.alarmInsertDb = alarmInsertDb;
	}

	public SendEmailAndPhone getSendEmailAndPhone() {
		return sendEmailAndPhone;
	}

	public void setSendEmailAndPhone(SendEmailAndPhone sendEmailAndPhone) {
		this.sendEmailAndPhone = sendEmailAndPhone;
	}

	/**
     * 云监控批量发送手机短信接口(同一内容发送至不同手机号码)
     * @param phoneOneParam.address          批量发送手机号码，地址支持批量，地址间用英文","分割
     * @param phoneOneParam.body	                        短信内容
     * @param phoneOneParam.alarmConfigId    报警配置ID
     */
	public void sendOneTopic(PhoneOneParam phoneOneParam) {
		String mobiles = phoneOneParam.getAddress();
		String body = phoneOneParam.getBody();
		BigInteger alarmConfigId = phoneOneParam.getAlarmConfigId();
		if(mobiles != null && !"".equals(mobiles) && body != null && !"".equals(body.trim()) && alarmConfigId != null && mobiles.length() < 60000) {
			Set<String> phoneSet = new HashSet<String>();
			StringBuffer phones = new StringBuffer();
			//1、发送短信
			String[] addrs = mobiles.split(",");
    		for (String addr : addrs) {
    			phoneSet.add(addr.trim());
			}
			for (String phone : phoneSet) {
				if(phone != null && !"".equals(phone.trim()) && phone.trim().length() == 11) {
					phones.append(",").append(phone.trim());
				}
			}
			//2、写入数据库
			if(phones.length() > 0) {
				int intl = body.trim().length() / 320;
				int intm = body.trim().length() % 320;
				int arrLen = intl + (intm > 0 ? 1 : 0);
				for (int i = 0; i < arrLen; i++) {
					if(i == arrLen - 1) {
						sendEmailAndPhone.sendNetWorkMessage(phones.toString().substring(1), body.trim().substring(320 * i));
					} else {
						sendEmailAndPhone.sendNetWorkMessage(phones.toString().substring(1), body.trim().substring(320 * i, 320 * (i+1)));
					}
				}
				List<AlarmInfo> alarmInfoList = new ArrayList<AlarmInfo>();
				AlarmInfo alarmInfo = new AlarmInfo();
				alarmInfo.setAlarmConfigId(alarmConfigId);
				alarmInfoList.add(alarmInfo);
				alarmInsertDb.insertAlarmToDb(alarmInfoList);
			} else {
				log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SENDPHONE_CLASSNAME, AlarmCenterUtil.SENDONE_METHOD_NAME) + "批量发送手机短信时，传入手机号码不对");
			}
		} else {
			log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SENDPHONE_CLASSNAME, AlarmCenterUtil.SENDONE_METHOD_NAME) + "调用手机短信接口参数不正确");
		}
	}
	
	/**
     * 云监控批量发送手机短信接口(号码、内容不一致)
     * @param phoneMoreParam 批量发送邮件信息
     * 			phoneMoreParam 参数说明实例：
     * 				phoneOneParam = phoneMoreParam.get(0)
     * 				honeOneParam.address            批量发送手机号码
     * 				phoneOneParam.body	                                短信内容
     * 				phoneOneParam.alarmConfigId     报警配置ID
     */
	public void sendMoreTopic(PhoneMoreParam phoneMoreParam) {
		List<PhoneOneParam> phoneList = phoneMoreParam.getPhoneOneParamList();
		if(phoneList != null && phoneList.size() > 0) {
			//1、发送短信
			List<AlarmInfo> alarmInfoList = new ArrayList<AlarmInfo>();
			AlarmInfo alarmInfo = null;
			for (PhoneOneParam phoneOneParam : phoneList) {
				String mobile = phoneOneParam.getAddress();
				String body = phoneOneParam.getBody();
				BigInteger alarmConfigId = phoneOneParam.getAlarmConfigId();
				if(mobile != null && !"".equals(mobile.trim()) && mobile.trim().length() == 11 && body != null && !"".equals(body.trim())) {
					int intl = body.trim().length() / 320;
					int intm = body.trim().length() % 320;
					int arrLen = intl + (intm > 0 ? 1 : 0);
					for (int i = 0; i < arrLen; i++) {
						if(i == arrLen - 1) {
							sendEmailAndPhone.sendNetWorkMessage(mobile.trim(), body.trim().substring(320 * i));
						} else {
							sendEmailAndPhone.sendNetWorkMessage(mobile.trim(), body.trim().substring(320 * i, 320 * (i+1)));
						}
					}
					alarmInfo = new AlarmInfo();
					alarmInfo.setAlarmConfigId(alarmConfigId);
					alarmInfoList.add(alarmInfo);
				} else {
					log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SENDPHONE_CLASSNAME, AlarmCenterUtil.SENDMORE_METHOD_NAME) + "批量发送手机短信时，存在不合法的手机信息");
				}
			}
			//2、写入数据库
			if(alarmInfoList.size() > 0) {
				alarmInsertDb.insertAlarmToDb(alarmInfoList);
			}
		} else {
			log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.SENDPHONE_CLASSNAME, AlarmCenterUtil.SENDMORE_METHOD_NAME) + "批量发送手机短信时，参数错误");
		}
	}
}
