package com.jd.cloudeye.cscp.ac.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AlarmNoticeMoreParam implements Serializable {

	private static final long serialVersionUID = 8383624233455801646L;

	/**
	 * 发送邮件具体信息集合
	 */
	private List<AlarmNoticeOneParam> alarmNoticeOneParamList;
	
	/**
	 * 备用字段
	 */
	private String reserve;

	public List<AlarmNoticeOneParam> getAlarmNoticeOneParamList() {
		return alarmNoticeOneParamList;
	}

	public void setAlarmNoticeOneParamList(
			List<AlarmNoticeOneParam> alarmNoticeOneParamList) {
		this.alarmNoticeOneParamList = alarmNoticeOneParamList;
	}

	public String getReserve() {
		return reserve;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public void add(AlarmNoticeOneParam alarmNoticeOneParam) {
		if(alarmNoticeOneParamList == null) {
			alarmNoticeOneParamList = new ArrayList<AlarmNoticeOneParam>();
		}
		alarmNoticeOneParamList.add(alarmNoticeOneParam);
	}
}
