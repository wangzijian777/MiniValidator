@javax.xml.bind.annotation.XmlSchema(namespace = "http://360buy.com/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.jd.cloudeye.cscp.ac.mail;
