package com.jd.cloudeye.cscp.ac.vo;

import java.io.Serializable;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AlarmNoticeOneParam implements Serializable {

	private static final long serialVersionUID = 220110968682712895L;

	/**
	 * 主题
	 */
	private String subject;
	
	/**
	 * 正文
	 */
	private String body;
	
	/**
	 * 通用收件人
	 */
	private String address;
	
	/**
	 * 电话收件人
	 */
	private String phoneAddress;
	
	/**
	 * 邮件收件人
	 */
	private String emailAddress;
	
	/**
	 * 报警配置ID
	 */
	private BigInteger alarmConfigId;
	
	/**
	 * 报警类型
	 */
	private int type;
	
	/**
	 * 备用字段
	 */
	private String reserve;
	
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneAddress() {
		return phoneAddress;
	}

	public void setPhoneAddress(String phoneAddress) {
		this.phoneAddress = phoneAddress;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getReserve() {
		return reserve;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public BigInteger getAlarmConfigId() {
		return alarmConfigId;
	}

	public void setAlarmConfigId(BigInteger alarmConfigId) {
		this.alarmConfigId = alarmConfigId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
}
