package com.jd.cloudeye.cscp.ac.service.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.ac.service.AlarmInsertDb;
import com.jd.cloudeye.cscp.ac.service.AlarmNoticeService;
import com.jd.cloudeye.cscp.ac.service.SendEmailAndPhone;
import com.jd.cloudeye.cscp.ac.vo.AlarmCenterUtil;
import com.jd.cloudeye.cscp.ac.vo.AlarmInfo;
import com.jd.cloudeye.cscp.ac.vo.AlarmNoticeMoreParam;
import com.jd.cloudeye.cscp.ac.vo.AlarmNoticeOneParam;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

public class AlarmNoticeServiceImpl implements AlarmNoticeService {

	private Log log = LogFactory.getLog(AlarmNoticeServiceImpl.class);
	
	private AlarmInsertDb alarmInsertDb;
	
	private SendEmailAndPhone sendEmailAndPhone;
	
	public AlarmInsertDb getAlarmInsertDb() {
		return alarmInsertDb;
	}

	public void setAlarmInsertDb(AlarmInsertDb alarmInsertDb) {
		this.alarmInsertDb = alarmInsertDb;
	}

	public SendEmailAndPhone getSendEmailAndPhone() {
		return sendEmailAndPhone;
	}

	public void setSendEmailAndPhone(SendEmailAndPhone sendEmailAndPhone) {
		this.sendEmailAndPhone = sendEmailAndPhone;
	}

	/**
	 * @param alarmNoticeMoreParam.getAlarmNoticeOneParamList()为List<AlarmNoticeOneParam>
	 * 		其中AlarmNoticeOneParam包含
	 *  		alarmNoticeOneParam.subject主题
	 *  		alarmNoticeOneParam.body正文
	 *  		alarmNoticeOneParam.address发送地址
	 *  		alarmNoticeOneParam.alarmConfigId报警规则id
	 */
	public void sendAlarmNotice(AlarmNoticeMoreParam alarmNoticeMoreParam) {
		List<AlarmNoticeOneParam> alarmNoticeOneParamList = alarmNoticeMoreParam.getAlarmNoticeOneParamList();
		List<AlarmInfo> alarmInfoList = new ArrayList<AlarmInfo>();
    	if(alarmNoticeOneParamList != null && alarmNoticeOneParamList.size() > 0) {
    		CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.AlarmCenter.sendAlarmNotice", false, true);
    		try {
				AlarmInfo alarmInfo = null;
				for (AlarmNoticeOneParam alarmNoticeOneParam : alarmNoticeOneParamList) {
					String body = alarmNoticeOneParam.getBody();
					String subject = alarmNoticeOneParam.getSubject();
					String address = alarmNoticeOneParam.getAddress();
					BigInteger alarmConfigId = alarmNoticeOneParam.getAlarmConfigId();
					int type = alarmNoticeOneParam.getType();
					if(type == 1) {//发送短信
						if(body != null && !"".equals(body.trim()) && address != null && !"".equals(address.trim()) && alarmConfigId != null)  {
							int intl = body.trim().length() / 320;
							int intm = body.trim().length() % 320;
							int arrLen = intl + (intm > 0 ? 1 : 0);
							for (int i = 0; i < arrLen; i++) {
								if(i == arrLen - 1) {
									sendEmailAndPhone.sendNetWorkMessage(address.trim(), body.trim().substring(320 * i));
								} else {
									sendEmailAndPhone.sendNetWorkMessage(address.trim(), body.trim().substring(320 * i, 320 * (i+1)));
								}
							}
							alarmInfo = new AlarmInfo();
							alarmInfo.setAlarmConfigId(alarmConfigId);
							alarmInfoList.add(alarmInfo);
						} else {
							log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.ALARM_CLASSNAME, AlarmCenterUtil.ALARM_METHOD_NAME) + "发送邮件时调用sendOne方法存在有不合法的邮件信息");
						}
					} else if(type == 2) {//发送邮件
						if(subject != null && !"".equals(subject.trim()) && body != null && !"".equals(body.trim()) && address != null && !"".equals(address.trim()) && alarmConfigId != null)  {
							sendEmailAndPhone.sendNetWorkEmail(subject, body, address);
							alarmInfo = new AlarmInfo();
							alarmInfo.setAlarmConfigId(alarmConfigId);
							alarmInfoList.add(alarmInfo);
						} else {
							log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.ALARM_CLASSNAME, AlarmCenterUtil.ALARM_METHOD_NAME) + "批量发送邮件时存在有不合法的邮件信息");
						}
					} else if(type == 3) {//发送邮件和短信
						address = alarmNoticeOneParam.getEmailAddress();
						if(body != null && !"".equals(body.trim()) && address != null && !"".equals(address.trim()) && alarmConfigId != null)  {
							int intl = body.trim().length() / 320;
							int intm = body.trim().length() % 320;
							int arrLen = intl + (intm > 0 ? 1 : 0);
							for (int i = 0; i < arrLen; i++) {
								if(i == arrLen - 1) {
									sendEmailAndPhone.sendNetWorkMessage(address.trim(), body.trim().substring(320 * i));
								} else {
									sendEmailAndPhone.sendNetWorkMessage(address.trim(), body.trim().substring(320 * i, 320 * (i+1)));
								}
							}
						} else {
							log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.ALARM_CLASSNAME, AlarmCenterUtil.ALARM_METHOD_NAME) + "发送邮件时调用sendOne方法存在有不合法的邮件信息");
						}
						address = alarmNoticeOneParam.getPhoneAddress();
						if(subject != null && !"".equals(subject.trim()) && body != null && !"".equals(body.trim()) && address != null && !"".equals(address.trim()) && alarmConfigId != null)  {
							sendEmailAndPhone.sendNetWorkEmail(subject, body, address);
						} else {
							log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.ALARM_CLASSNAME, AlarmCenterUtil.ALARM_METHOD_NAME) + "批量发送邮件时存在有不合法的邮件信息");
						}
						alarmInfo = new AlarmInfo();
						alarmInfo.setAlarmConfigId(alarmConfigId);
						alarmInfoList.add(alarmInfo);
					} else {
						log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.ALARM_CLASSNAME, AlarmCenterUtil.ALARM_METHOD_NAME) + "调用批量发送邮件接口时发送方式错误");
					}
				}
				//2、写入数据库
				if(alarmInfoList.size() > 0) {
					alarmInsertDb.insertAlarmToDb(alarmInfoList);
				}
			} catch (Exception e) {
				Profiler.functionError(callerInfo);
				log.info(CommonLogUtil.makeInfoHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.ALARM_CLASSNAME, AlarmCenterUtil.ALARM_METHOD_NAME) + "报警中心模块异常");
			}
			Profiler.registerInfoEnd(callerInfo);
    	}
	}

}
