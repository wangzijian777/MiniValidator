
package com.jd.mobilephonemsg.sender.ws.server.newmessageservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.jd.mobilephonemsg.sender.ws.server.newmessageservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SentMessage_QNAME = new QName("http://newMessageService.server.ws.sender.mobilePhoneMsg.jd.com/", "SentMessage");
    private final static QName _SentMessageResponse_QNAME = new QName("http://newMessageService.server.ws.sender.mobilePhoneMsg.jd.com/", "SentMessageResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.jd.mobilephonemsg.sender.ws.server.newmessageservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link MmsResult }
     * 
     */
    public MmsResult createMmsResult() {
        return new MmsResult();
    }

    /**
     * Create an instance of {@link SentMessage }
     * 
     */
    public SentMessage createSentMessage() {
        return new SentMessage();
    }

    /**
     * Create an instance of {@link Message }
     * 
     */
    public Message createMessage() {
        return new Message();
    }

    /**
     * Create an instance of {@link SentMessageResponse }
     * 
     */
    public SentMessageResponse createSentMessageResponse() {
        return new SentMessageResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SentMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://newMessageService.server.ws.sender.mobilePhoneMsg.jd.com/", name = "SentMessage")
    public JAXBElement<SentMessage> createSentMessage(SentMessage value) {
        return new JAXBElement<SentMessage>(_SentMessage_QNAME, SentMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SentMessageResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://newMessageService.server.ws.sender.mobilePhoneMsg.jd.com/", name = "SentMessageResponse")
    public JAXBElement<SentMessageResponse> createSentMessageResponse(SentMessageResponse value) {
        return new JAXBElement<SentMessageResponse>(_SentMessageResponse_QNAME, SentMessageResponse.class, null, value);
    }

}
