@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.ea.ump.jd.com/")
package com.jd.test;
