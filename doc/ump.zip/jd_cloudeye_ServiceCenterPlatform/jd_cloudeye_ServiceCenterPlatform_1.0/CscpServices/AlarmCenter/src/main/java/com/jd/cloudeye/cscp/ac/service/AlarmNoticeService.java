package com.jd.cloudeye.cscp.ac.service;

import javax.jws.WebService;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.jd.cloudeye.cscp.ac.vo.AlarmNoticeMoreParam;

@Path("/alarmNoticeService")
@Produces("application/xml")
@Consumes("application/xml")
@WebService
public interface AlarmNoticeService {

	/**
	 * @param alarmNoticeMoreParam.getAlarmNoticeOneParamList()为List<AlarmNoticeOneParam>
	 * 		其中AlarmNoticeOneParam包含
	 *  		alarmNoticeOneParam.subject主题
	 *  		alarmNoticeOneParam.body正文
	 *  		alarmNoticeOneParam.address发送地址
	 *  		alarmNoticeOneParam.alarmConfigId报警规则id
	 */
	@POST
	@Path("/sendAlarmNotice")
	void sendAlarmNotice(AlarmNoticeMoreParam alarmNoticeMoreParam);
}
