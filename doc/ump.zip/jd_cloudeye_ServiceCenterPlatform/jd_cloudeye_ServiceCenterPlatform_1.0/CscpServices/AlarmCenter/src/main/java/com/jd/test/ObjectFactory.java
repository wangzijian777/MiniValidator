
package com.jd.test;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.jd.test package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SendRTXResponse_QNAME = new QName("http://service.ea.ump.jd.com/", "sendRTXResponse");
    private final static QName _SendSMSResponse_QNAME = new QName("http://service.ea.ump.jd.com/", "sendSMSResponse");
    private final static QName _SendRTX_QNAME = new QName("http://service.ea.ump.jd.com/", "sendRTX");
    private final static QName _SendMailResponse_QNAME = new QName("http://service.ea.ump.jd.com/", "sendMailResponse");
    private final static QName _SendSMS_QNAME = new QName("http://service.ea.ump.jd.com/", "sendSMS");
    private final static QName _SendMail_QNAME = new QName("http://service.ea.ump.jd.com/", "sendMail");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.jd.test
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SendSMS }
     * 
     */
    public SendSMS createSendSMS() {
        return new SendSMS();
    }

    /**
     * Create an instance of {@link SendRTX }
     * 
     */
    public SendRTX createSendRTX() {
        return new SendRTX();
    }

    /**
     * Create an instance of {@link SendMail }
     * 
     */
    public SendMail createSendMail() {
        return new SendMail();
    }

    /**
     * Create an instance of {@link SendMailResponse }
     * 
     */
    public SendMailResponse createSendMailResponse() {
        return new SendMailResponse();
    }

    /**
     * Create an instance of {@link SendRTXResponse }
     * 
     */
    public SendRTXResponse createSendRTXResponse() {
        return new SendRTXResponse();
    }

    /**
     * Create an instance of {@link SendSMSResponse }
     * 
     */
    public SendSMSResponse createSendSMSResponse() {
        return new SendSMSResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendRTXResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.ea.ump.jd.com/", name = "sendRTXResponse")
    public JAXBElement<SendRTXResponse> createSendRTXResponse(SendRTXResponse value) {
        return new JAXBElement<SendRTXResponse>(_SendRTXResponse_QNAME, SendRTXResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendSMSResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.ea.ump.jd.com/", name = "sendSMSResponse")
    public JAXBElement<SendSMSResponse> createSendSMSResponse(SendSMSResponse value) {
        return new JAXBElement<SendSMSResponse>(_SendSMSResponse_QNAME, SendSMSResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendRTX }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.ea.ump.jd.com/", name = "sendRTX")
    public JAXBElement<SendRTX> createSendRTX(SendRTX value) {
        return new JAXBElement<SendRTX>(_SendRTX_QNAME, SendRTX.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendMailResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.ea.ump.jd.com/", name = "sendMailResponse")
    public JAXBElement<SendMailResponse> createSendMailResponse(SendMailResponse value) {
        return new JAXBElement<SendMailResponse>(_SendMailResponse_QNAME, SendMailResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendSMS }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.ea.ump.jd.com/", name = "sendSMS")
    public JAXBElement<SendSMS> createSendSMS(SendSMS value) {
        return new JAXBElement<SendSMS>(_SendSMS_QNAME, SendSMS.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SendMail }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.ea.ump.jd.com/", name = "sendMail")
    public JAXBElement<SendMail> createSendMail(SendMail value) {
        return new JAXBElement<SendMail>(_SendMail_QNAME, SendMail.class, null, value);
    }

}
