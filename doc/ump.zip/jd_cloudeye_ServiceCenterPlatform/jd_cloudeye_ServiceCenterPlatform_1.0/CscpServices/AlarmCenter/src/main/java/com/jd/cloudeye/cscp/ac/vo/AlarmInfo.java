package com.jd.cloudeye.cscp.ac.vo;

import java.io.Serializable;
import java.math.BigInteger;

public class AlarmInfo implements Serializable {

	private static final long serialVersionUID = -6837404039256370445L;

	/**
	 * 报警配置ID
	 */
	private BigInteger alarmConfigId;
	
	public BigInteger getAlarmConfigId() {
		return alarmConfigId;
	}

	public void setAlarmConfigId(BigInteger alarmConfigId) {
		this.alarmConfigId = alarmConfigId;
	}
}
