package com.jd.cloudeye.cscp.ac.service.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.ac.service.AlarmInsertDb;
import com.jd.cloudeye.cscp.ac.vo.AlarmCenterUtil;
import com.jd.cloudeye.cscp.ac.vo.AlarmInfo;

public class AlarmInsertDbImpl implements AlarmInsertDb {

	private Log log = LogFactory.getLog(AlarmInsertDbImpl.class);
	
	private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
	 * 向数据库中插入报警信息
	 * @param alarmInfoList
	 */
	public void insertAlarmToDb(final List<AlarmInfo> alarmInfoList) {
		String sql = "insert into jce_alarm_his(jce_alarm_rule_detail_id,jce_send_flag,create_time,is_valid) values (?,?,?,1)";
		try {
			this.jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				public void setValues(PreparedStatement ps,int i)throws SQLException {
			    	ps.setBigDecimal(1, new BigDecimal(alarmInfoList.get(i).getAlarmConfigId()));  
			    	ps.setInt(2, 1); 
			    	ps.setTimestamp(3, new Timestamp(new Date().getTime()));
			    }
				public int getBatchSize() {
					return alarmInfoList.size();
			    }
			});
		} catch (Exception e) {
			log.error(CommonLogUtil.makeErrorHead(AlarmCenterUtil.MODULE_NAME, AlarmCenterUtil.INSERTDB__CLASSNAME) + "将报警信息插入数据库表中异常", e);
		}
	}
}
