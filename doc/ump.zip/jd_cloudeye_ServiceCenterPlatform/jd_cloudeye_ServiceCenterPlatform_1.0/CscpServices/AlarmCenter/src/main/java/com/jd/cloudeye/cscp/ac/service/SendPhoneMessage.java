package com.jd.cloudeye.cscp.ac.service;

import javax.jws.WebService;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.jd.cloudeye.cscp.ac.vo.PhoneMoreParam;
import com.jd.cloudeye.cscp.ac.vo.PhoneOneParam;

@Path("/sendPhone")
@Produces("application/xml")
@Consumes("application/xml")
@WebService
public interface SendPhoneMessage {

	/**
     * 云监控批量发送手机短信接口(同一内容发送至不同手机号码)
     * @param phoneOneParam.address          批量发送手机号码，地址支持批量，地址间用英文","分割
     * @param phoneOneParam.body	                        短信内容
     * @param phoneOneParam.alarmConfigId    报警配置ID
     */
	@POST
	@Path("/sendOneTopic")
	void sendOneTopic(PhoneOneParam phoneOneParam);
	
	/**
    * 云监控批量发送手机短信接口(号码、内容不一致)
     * @param phoneMoreParam 批量发送邮件信息
     * 			phoneMoreParam 参数说明实例：
     * 				phoneOneParam = phoneMoreParam.get(0)
     * 				honeOneParam.address            批量发送手机号码
     * 				phoneOneParam.body	                                短信内容
     * 				phoneOneParam.alarmConfigId     报警配置ID
     */
	@POST
	@Path("/sendMoreTopic")
	void sendMoreTopic(PhoneMoreParam phoneMoreParam);
}
