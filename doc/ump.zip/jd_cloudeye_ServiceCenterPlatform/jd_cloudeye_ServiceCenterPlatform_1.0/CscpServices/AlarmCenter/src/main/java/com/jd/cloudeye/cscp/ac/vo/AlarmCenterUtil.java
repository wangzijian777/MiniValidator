package com.jd.cloudeye.cscp.ac.vo;

public class AlarmCenterUtil {

	/**
	 * 发送邮件类名称
	 */
	public static final String SENDEMAIL_CLASSNAME = "SendEmailImpl"; 
	
	/**
	 * 发送短信类名称
	 */
	public static final String SENDPHONE_CLASSNAME = "SendPhoneMessageImpl"; 
	
	/**
	 * 发送邮件短信类名称
	 */
	public static final String SEND_CLASSNAME = "SendEmailAndPhoneImpl";
	
	/**
	 * 报警接口类名称
	 */
	public static final String ALARM_CLASSNAME = "AlarmNoticeServiceImpl";
	
	/**
	 * 插入数据库类名称
	 */
	public static final String INSERTDB__CLASSNAME = "AlarmInsertDbImpl";
	
	/**
	 * 模块名称
	 */
	public static final String MODULE_NAME = "报警中心"; 
	
	/**
	 * 发送多主题方法名
	 */
	public static final String SENDMORE_METHOD_NAME = "sendMoreTopic";
	
	/**
	 * 发送一个主题方法名
	 */
	public static final String SENDONE_METHOD_NAME = "sendOneTopic";
	
	/**
	 * 报警方法名称
	 */
	public static final String ALARM_METHOD_NAME = "sendAlarmNotice";
}
