@javax.xml.bind.annotation.XmlSchema(namespace = "http://newMessageService.server.ws.sender.mobilePhoneMsg.jd.com/")
package com.jd.mobilephonemsg.sender.ws.server.newmessageservice;
