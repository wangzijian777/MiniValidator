package com.jd.cloudeye.cscp.ac.service;


public interface SendEmailAndPhone {

	/**
	 * 调用公司接口发送手机短信信息
	 * @param mobiles 手机号码，多个号码间用","分开
	 * @param body	短信内容
	 */
	void sendNetWorkMessage(String mobiles, String body);
	
	 /**
     * 调用公司邮件接口发送邮件
     * @param subject 邮件主题
     * @param body 邮件内容
     * @param address 收件地址
     */
    void sendNetWorkEmail(String subject, String body, String address);
}
