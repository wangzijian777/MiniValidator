package com.jd.cloudeye.cscp.ac.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EmailMoreParam implements Serializable {

	private static final long serialVersionUID = -1580158167320929632L;
	
	/**
	 * 发送邮件具体信息集合
	 */
	private List<EmailOneParam> emailList;
	
	/**
	 * 备用字段
	 */
	private String reserve;
	
	public List<EmailOneParam> getEmailList() {
		return emailList;
	}

	public void setEmailList(List<EmailOneParam> emailList) {
		this.emailList = emailList;
	}
	
	public String getReserve() {
		return reserve;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public void add(EmailOneParam emailOneParam) {
		if(emailList == null) {
			emailList = new ArrayList<EmailOneParam>();
		}
		emailList.add(emailOneParam);
	}
}
