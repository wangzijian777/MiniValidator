package com.jd.cloudeye.cscp.ac.vo;

import java.io.Serializable;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EmailOneParam implements Serializable {

	private static final long serialVersionUID = 4408216962594853212L;

	/**
	 * 邮件主题
	 */
	private String subject;
	
	/**
	 * 邮件正文
	 */
	private String body;
	
	/**
	 * 收件人
	 */
	private String address;
	
	/**
	 * 报警配置ID
	 */
	private BigInteger alarmConfigId;
	
	/**
	 * 备用字段
	 */
	private String reserve;
	
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getReserve() {
		return reserve;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public BigInteger getAlarmConfigId() {
		return alarmConfigId;
	}

	public void setAlarmConfigId(BigInteger alarmConfigId) {
		this.alarmConfigId = alarmConfigId;
	}
}
