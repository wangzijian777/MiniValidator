package com.jd.cloudeye.cscp.ac.vo;

import java.io.Serializable;
import java.math.BigInteger;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PhoneOneParam implements Serializable {

	private static final long serialVersionUID = -4457266733349593264L;

	/**
	 * 短信内容
	 */
	private String body;
	
	/**
	 * 短信收信人
	 */
	private String address;
	
	/**
	 * 报警配置ID
	 */
	private BigInteger alarmConfigId;
	
	/**
	 * 备用字段
	 */
	private String reserve;

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getReserve() {
		return reserve;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public BigInteger getAlarmConfigId() {
		return alarmConfigId;
	}

	public void setAlarmConfigId(BigInteger alarmConfigId) {
		this.alarmConfigId = alarmConfigId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
