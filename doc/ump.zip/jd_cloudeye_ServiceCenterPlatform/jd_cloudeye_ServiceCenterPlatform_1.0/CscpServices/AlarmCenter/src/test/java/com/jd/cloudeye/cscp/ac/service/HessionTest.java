package com.jd.cloudeye.cscp.ac.service;

import java.math.BigInteger;
import java.net.MalformedURLException;

import org.junit.Test;

import com.caucho.hessian.client.HessianProxyFactory;
import com.jd.cloudeye.cscp.ac.vo.EmailMoreParam;
import com.jd.cloudeye.cscp.ac.vo.EmailOneParam;
import com.jd.cloudeye.cscp.ac.vo.PhoneMoreParam;
import com.jd.cloudeye.cscp.ac.vo.PhoneOneParam;

public class HessionTest {

	@Test
	public void emailOneTest() {
		String url = "http://localhost:8089/hessian/sendEmailHession";
		HessianProxyFactory factory = new HessianProxyFactory();
		try {
			SendEmail sendEmail = (SendEmail)factory.create(SendEmail.class,url);
			EmailOneParam emailOneParam = new EmailOneParam();
			emailOneParam.setSubject("测试");
			emailOneParam.setBody("正文");
			emailOneParam.setAlarmConfigId(new BigInteger("3333111111111111"));
			emailOneParam.setAddress("dengboinfo@360buy.com,dda@123.com");
			sendEmail.sendOneTopic(emailOneParam);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void emailMoreTest() {
		String url = "http://localhost:8089/hessian/sendEmailHession";
		HessianProxyFactory factory = new HessianProxyFactory();
		try {
			SendEmail sendEmail = (SendEmail)factory.create(SendEmail.class,url);
			EmailMoreParam em = new EmailMoreParam();
			EmailOneParam emailOneParam = new EmailOneParam();
			emailOneParam.setSubject("测试");
			emailOneParam.setBody("正文");
			emailOneParam.setAlarmConfigId(new BigInteger("3333111111111112"));
			emailOneParam.setAddress("dengboinfo@360buy.com");
			em.add(emailOneParam);
			emailOneParam = new EmailOneParam();
			emailOneParam.setSubject("测试2");
			emailOneParam.setBody("正文2");
			emailOneParam.setAlarmConfigId(new BigInteger("33331111111113"));
			emailOneParam.setAddress("dengboinfo1@360buy.com");
			em.add(emailOneParam);
			sendEmail.sendMoreTopic(em);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void phoneSendOneTopicTest() {
		String url = "http://localhost:8089/hessian/sendPhoneMessageHession";
		HessianProxyFactory factory = new HessianProxyFactory();
		try {
			SendPhoneMessage sendPhoneMessage = (SendPhoneMessage)factory.create(SendPhoneMessage.class,url);
			PhoneOneParam phoneOneParam = new PhoneOneParam();
			phoneOneParam.setAddress("13666666666,13888888888");
			phoneOneParam.setAlarmConfigId(new BigInteger("33331111111114"));
			phoneOneParam.setBody("url存活报警信息");
			sendPhoneMessage.sendOneTopic(phoneOneParam);
			System.out.println("aaaaaaaaaaaaaaaaaaaa");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void phoneSendMoreTopicTest() {
		String url = "http://localhost:8089/hessian/sendPhoneMessageHession";
		HessianProxyFactory factory = new HessianProxyFactory();
		try {
			SendPhoneMessage sendPhoneMessage = (SendPhoneMessage)factory.create(SendPhoneMessage.class,url);
			PhoneMoreParam phoneMoreParam = new PhoneMoreParam();
			PhoneOneParam phoneOneParam = new PhoneOneParam();
			phoneOneParam.setAddress("13666666666");
			phoneOneParam.setAlarmConfigId(new BigInteger("333311111115"));
			phoneOneParam.setBody("url存活报警信息");
			phoneMoreParam.add(phoneOneParam);
			phoneOneParam = new PhoneOneParam();
			phoneOneParam.setAddress("13888888888");
			phoneOneParam.setAlarmConfigId(new BigInteger("33331111111116"));
			phoneOneParam.setBody("port存活报警信息");
			phoneMoreParam.add(phoneOneParam);
			sendPhoneMessage.sendMoreTopic(phoneMoreParam);
			System.out.println("aaaaaaaaaaaaaaaaaaaa");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
}
