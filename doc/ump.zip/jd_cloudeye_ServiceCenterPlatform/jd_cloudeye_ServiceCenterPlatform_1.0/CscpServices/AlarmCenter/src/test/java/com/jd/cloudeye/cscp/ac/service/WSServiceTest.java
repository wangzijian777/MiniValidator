package com.jd.cloudeye.cscp.ac.service;

import java.math.BigInteger;

import org.junit.Test;

import com.jd.cloudeye.cscp.ac.vo.AlarmNoticeMoreParam;
import com.jd.cloudeye.cscp.ac.vo.AlarmNoticeOneParam;
import com.jd.cloudeye.cscp.ac.vo.EmailMoreParam;
import com.jd.cloudeye.cscp.ac.vo.EmailOneParam;
import com.jd.cloudeye.cscp.ac.vo.PhoneMoreParam;
import com.jd.cloudeye.cscp.ac.vo.PhoneOneParam;

public class WSServiceTest {
	
	@Test
	public void CXFClientEmailOneTopicTest() {
		EmailOneParam emailOneParam = new EmailOneParam();
		emailOneParam.setSubject("测试");
		emailOneParam.setBody("正文");
		emailOneParam.setAlarmConfigId(new BigInteger("44422222222221"));
		emailOneParam.setAddress("dengboinfo@360buy.com,ddd@360buy.com");
		RESTFulClient.post("sendEmail/sendOneTopic",emailOneParam,null);
		System.out.println("aaaaaaaaaaaaaaaaaaaa");
	}
	
	@Test
	public void CXFClientEmailMoreTopicTest() {
		EmailMoreParam em = new EmailMoreParam();
		EmailOneParam emailOneParam = new EmailOneParam();
		emailOneParam.setSubject("测试1");
		emailOneParam.setBody("正文1");
		emailOneParam.setAlarmConfigId(new BigInteger("4442222222"));
		emailOneParam.setAddress("dengboinfo@360buy.com");
		em.add(emailOneParam);
		emailOneParam = new EmailOneParam();
		emailOneParam.setSubject("测试2");
		emailOneParam.setBody("正文2");
		emailOneParam.setAlarmConfigId(new BigInteger("44422222222223"));
		emailOneParam.setAddress("dengboinfo1@360buy.com");
		em.add(emailOneParam);
		RESTFulClient.post("sendEmail/sendMoreTopic",em,null);
		System.out.println("aaaaaaaaaaaaaaaaaaaa");
	}
	
	@Test
	public void CXFClientPhoneOneTopicTest() {
		PhoneOneParam phoneOneParam = new PhoneOneParam();
		phoneOneParam.setAddress("13666666666,13888888888");
		phoneOneParam.setBody("url存活报警信息");
		phoneOneParam.setAlarmConfigId(new BigInteger("4444222222224"));
		RESTFulClient.post("sendPhone/sendOneTopic",phoneOneParam,null);
		System.out.println("aaaaaaaaaaaaaaaaaaaa");
	}
	
	@Test
	public void CXFClientPhoneMoreTopicTest() {
		PhoneMoreParam phoneMoreParam = new PhoneMoreParam();
		PhoneOneParam phoneOneParam = new PhoneOneParam();
		phoneOneParam.setAddress("13666666666");
		phoneOneParam.setBody("url存活报警信息");
		phoneOneParam.setAlarmConfigId(new BigInteger("4444222222225"));
		phoneMoreParam.add(phoneOneParam);
		phoneOneParam = new PhoneOneParam();
		phoneOneParam.setAddress("13888888888");
		phoneOneParam.setBody("port存活报警信息");
		phoneOneParam.setAlarmConfigId(new BigInteger("444422222226"));
		phoneMoreParam.add(phoneOneParam);
		RESTFulClient.post("sendPhone/sendMoreTopic",phoneMoreParam,null);
		System.out.println("aaaaaaaaaaaaaaaaaaaa");
	}
	
	@Test
	public void CXFClientPhoneAndMessageTest() {
		AlarmNoticeMoreParam alarmNoticeMoreParam = new AlarmNoticeMoreParam();
		AlarmNoticeOneParam alarmNoticeOneParam = new AlarmNoticeOneParam();
		alarmNoticeOneParam.setPhoneAddress("13666666666");
		alarmNoticeOneParam.setEmailAddress("dengboinfo@360buy.com");
		alarmNoticeOneParam.setBody("url存活报警信息");
		alarmNoticeOneParam.setSubject("测试");
		alarmNoticeOneParam.setAlarmConfigId(new BigInteger("777222222225"));
		alarmNoticeOneParam.setType(3);
		alarmNoticeMoreParam.add(alarmNoticeOneParam);
		RESTFulClient.post("alarmNoticeService/sendAlarmNotice",alarmNoticeMoreParam,null);
		System.out.println("aaaaaaaaaaaaaaaaaaaa");
	}
}

