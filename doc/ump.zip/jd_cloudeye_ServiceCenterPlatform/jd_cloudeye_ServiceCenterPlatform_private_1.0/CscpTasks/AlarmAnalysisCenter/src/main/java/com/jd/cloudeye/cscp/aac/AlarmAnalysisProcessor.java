package com.jd.cloudeye.cscp.aac;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.common.util.AlarmNoticeOneParam;
import com.jd.cloudeye.cscp.common.CommonConstance;
import com.jd.cloudeye.cscp.common.db.RedisManager;
import com.jd.cloudeye.cscp.service.dao.ASQueryDao;
import com.jd.cloudeye.cscp.service.dao.ServerConsistencyDao;
import com.jd.cloudeye.cscp.util.AnalysisConsts;
import com.jd.cloudeye.cscp.util.EmailContent;
import com.jd.cloudeye.cscp.util.ToolBox;
import com.jd.cloudeye.maas.center.MetricsAlarmAnalysisInfo;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
@Component
public class AlarmAnalysisProcessor implements AnalysisProcessor {
	
	private static final Logger LOG = LoggerFactory.getLogger(AlarmAnalysisProcessor.class);
	@Resource(name="redisManager")
	private RedisManager redisManager;
	
	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private ServerConsistencyDao serverConsistencyDao;
	
	@Autowired
	private ASQueryDao asQueryDao;
	
	private static final String CLASSNAME = "AlarmAnalysisProcessor";
	
	@Override
	public void process(MetricsAlarmAnalysisInfo task) {
		//自监
		CallerInfo callerInfo = null;
		//userid
		String userid = task.getUserId();
		if(userid == null || userid.equals("")){
			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") + " userid is empty ");
			}
			return;
		}
		
		//ServiceCode
		String serviceCode = task.getServiceCode();
		if(serviceCode == null || serviceCode.equals("")){
			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") + " serviceCode is empty ");
			}
			return;
		}
		
		//InstanceId
		String instanceId = task.getInstanceId();
		if(instanceId == null || instanceId.equals("")){
			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") + " instanceId is empty ");
			}
			return;
		}
		//MetricsCode
		String metricsCode = task.getMetricsCode();
		if(metricsCode == null || metricsCode.equals("")){
			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") + " metricsCode is empty ");
			}
			return;
		}
		
		//task rate
		long taskRate = task.getPeriod();
		
		//task time
		long taskTime = task.getTaskTime();
		
		//用于到报警分析模块 redis 查找数据 的 key
		String alarmAnalysisKey =  AnalysisConsts.ALARM_KEYFIX + CommonConstance.KEY_SPLIT 
		+ userid + CommonConstance.KEY_SPLIT 
		+ serviceCode + CommonConstance.KEY_SPLIT 
		+ instanceId ;
		
		//报警规则id
		long rulid = task.getAlarmRuleId();
		
		String uniqueMetricsCode = rulid + CommonConstance.KEY_SPLIT + metricsCode;
		//日志片段
		String logPart = " & redis key :=" + alarmAnalysisKey + " & field :=" + uniqueMetricsCode;
		
		try{
			callerInfo = Profiler.registerInfo("jms.CSC.AlarmAnalysis.process", true, true);
			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
						+ "[START WORK.....] " +logPart 
						+ ", task rate :=" + taskRate
						+ ", task time :=" + taskTime);
			}
			//从redis中取出的值 格式 time|count|rate
			String value = redisManager.getHvalue(alarmAnalysisKey, uniqueMetricsCode);
			
			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
						+ " get from redis & value := " + value + logPart );
			}
			
			long [] valueArr = new long [3];
			//redis中无key对应的数据，构造一个value值
			if(value == null || value.trim().length() == 0){
				valueArr[0] = AnalysisConsts.VALUE_ZERO;
				valueArr[1] = AnalysisConsts.VALUE_ZERO;
				if(LOG.isDebugEnabled()){
					LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
							+ logPart + " not exists in redis ");
				}
			}else{//redis 中key对应有值，判断rate，更新count值
				if(value.split(AnalysisConsts.VALUE_SEPARATOR).length == 3){
					valueArr[0] = Long.valueOf(value.split(AnalysisConsts.VALUE_SEPARATOR)[0]);
					if(Long.valueOf(value.split(AnalysisConsts.VALUE_SEPARATOR)[2]) == taskRate){//频率相等
						valueArr[1] = Long.valueOf(value.split(AnalysisConsts.VALUE_SEPARATOR)[1]);
					}else{//频率不等
						valueArr[1] = AnalysisConsts.VALUE_ZERO;
						if(LOG.isDebugEnabled()){
							LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
									+ logPart + " rate diffrents,it will be changed !! & old rate:=" 
									+ value.split(AnalysisConsts.VALUE_SEPARATOR)[1]);
						}
					}
				}else{
					if(LOG.isErrorEnabled()){
						LOG.error(CommonLogUtil.makeErrorHead(AnalysisConsts.MODULE_NAME, CLASSNAME) 
								+ " invalid value in redis " + logPart);
					}
//				TODO:是否需要set 0|0|rate到redis？？
					throw new NumberFormatException(" invalid value in redis & value = " + value);
				}
			}
			//始终更新为taskRate
			valueArr[2] = taskRate;
			
			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
						+ " after compare rate, redis value is " + Arrays.toString(valueArr) + logPart);
			}
			
			if(compareThreshold(task)){//达到阀值
				valueArr[1] = valueArr[1] + 1;
				if(LOG.isDebugEnabled()){
					LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
							+ " achieve threshold value ! " + logPart + " & now values = " + Arrays.toString(valueArr));
				}
			}else{
				valueArr[1] = AnalysisConsts.VALUE_ZERO;
				if(LOG.isDebugEnabled()){
					LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
							+ " not achieve threshold value ~ " + logPart + " & now values = " + Arrays.toString(valueArr));
				}
			}
			
			//任务中的报警间隔
			long taskInvnternal = Long.valueOf(task.getAlarmRuleDetail().values().iterator().next().split(CommonConstance.TASK_CONTENT_SEPARATOR)[3]);
			
			//距离上次报警的时间间隔 -分钟
			long alarmInvnternal = (taskTime - valueArr[0]) / 1000 / 60;

			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
						+ " before alarm judge, taskInvnternal=" + taskInvnternal 
						+ ", alarmInvnternal = " + alarmInvnternal
						+ ", values = " + Arrays.toString(valueArr) 
						+ ", ContinualOccurs " + task.getContinualOccurs() + logPart);
			}
			//是否报警
			List<AlarmNoticeOneParam> alarmContentList = null;
			if(valueArr[1] >= task.getContinualOccurs() && alarmInvnternal >= taskInvnternal){
				valueArr[0] = taskTime;
				valueArr[1] = AnalysisConsts.VALUE_ZERO;
				alarmContentList = pinAlarmInfo(task);
				
				//发送报警
				if(alarmContentList != null && alarmContentList.size() > 0){
					if(LOG.isDebugEnabled()){
						LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") + " [ALARM-TAG_START] send alarm ! 4" + logPart);
					}
					ToolBox.sendAlarm(alarmContentList);
					if(LOG.isDebugEnabled()){
						LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") + " [ALARM-TAG_END] send alarm ! 4" + logPart);
					}
				}

				if(LOG.isDebugEnabled()){
					LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
							+" [JUDGE-TAG] alarm judge ..... "+ logPart
							+  " values = " + Arrays.toString(valueArr)
							+ " and alarm list SIZE =" + alarmContentList.size());
				}
			}
			
			//回写到redis
			if(valueArr != null && (valueArr[0] + valueArr[1]) > 0){
				redisManager.setHKeyValue(alarmAnalysisKey, uniqueMetricsCode, 
						  valueArr[0] + AnalysisConsts.JUST_VALUE_SEPARATOR
						+ valueArr[1] + AnalysisConsts.JUST_VALUE_SEPARATOR
						+ valueArr[2] );
				if(LOG.isDebugEnabled()){
					LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
							+ " set into redis ,value :="+Arrays.toString(valueArr) + logPart);
				}
			}
			
		}catch(NumberFormatException e1){
			Profiler.functionError(callerInfo);
			redisManager.setHKeyValue(alarmAnalysisKey, uniqueMetricsCode, 
					  AnalysisConsts.VALUE_ZERO + AnalysisConsts.JUST_VALUE_SEPARATOR
					+ AnalysisConsts.VALUE_ZERO + AnalysisConsts.JUST_VALUE_SEPARATOR
					+ taskRate );
			if(LOG.isDebugEnabled()){
				LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "process") 
						+ " redis value format error " + logPart 
						+ " it will be reset in redis ,like 0|0|rate " + e1);
			}
		}catch(Exception e){
			Profiler.functionError(callerInfo);
			if(LOG.isErrorEnabled()){
				LOG.error(CommonLogUtil.makeErrorHead(AnalysisConsts.MODULE_NAME, CLASSNAME) + "unknown error! " + e);
			}
		}finally{
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	/**
	 * 拼接报警信息
	 * @param task
	 * @return
	 */
	private List<AlarmNoticeOneParam> pinAlarmInfo(MetricsAlarmAnalysisInfo task){
		List<AlarmNoticeOneParam> alarmNoticeOneParamList = new ArrayList<AlarmNoticeOneParam>();
		Iterator<Map.Entry<Long,String>> rlueDetalIto = task.getAlarmRuleDetail().entrySet().iterator();
		Entry<Long, String> tmpEntry = null;
		String [] content = null;
		while(rlueDetalIto.hasNext()){
			tmpEntry = rlueDetalIto.next();
			content = tmpEntry.getValue().split(CommonConstance.TASK_CONTENT_SEPARATOR);
			AlarmNoticeOneParam alarmNotice = new AlarmNoticeOneParam();
			alarmNotice.setAddress(content[1]);
			alarmNotice.setType(Integer.valueOf(content[0]));
			alarmNotice.setAlarmConfigId(BigInteger.valueOf(tmpEntry.getKey()));
			alarmNotice.setBody(content[2]);
			if(CommonConstance.EML_FLAG.equals(content[0])){
				alarmNotice.setSubject(AnalysisConsts.EMALSUBJECT);
				String serviceName = serverConsistencyDao.getServiceName(task.getServiceCode());
				String metricsName = asQueryDao.getMetricsName(task.getMetricsCode());
				String instanceName = getInstanceName(task.getUserId(), task.getServiceCode(), task.getInstanceId());
				//组织报警邮件内容
				EmailContent emailContent = new EmailContent(AnalysisConsts.EMALSUBJECT,
						serviceName,instanceName,metricsName,
						content[2],ToolBox.dateUtil4String(task.getTaskTime()),
//						AnalysisConsts.JMS_URL
						null
						);
				emailContent.setRemark("");
				LOG.info("[EMAIL CONTENT]=" + emailContent.toString());
				alarmNotice.setBody(emailContent.toString());
			}
//			TODO 如果type == 3，加下面代码，并且在上面判断增加==3的情况
			/*if(Integer.valueOf(content[0]) == 3){
				alarmNotice.setPhoneAddress(content[1].split(AnalysisConsts.ADDRESS_SEPARATOR)[0]);
				alarmNotice.setEmailAddress(content[1].split(AnalysisConsts.ADDRESS_SEPARATOR)[1]);
			}*/
			alarmNoticeOneParamList.add(alarmNotice);
		}
		return alarmNoticeOneParamList;
	}
	
	/**
	 * 比较阀值
	 * @param task
	 * @return
	 */
	private boolean compareThreshold(MetricsAlarmAnalysisInfo task){
		StringBuffer sql = new StringBuffer(50); 
		String staticsLower =task.getStatics().toLowerCase();
		sql.append("select count(1) num, ").append(staticsLower).append("(a.jce_"+staticsLower+"_value) as aggvalue from  ")
			.append(CommonConstance.TABLE_PREFIX).append(task.getServiceCode().toLowerCase()).append(CommonConstance.TABLE_POSTFIX)
			.append(" a where a.jce_usin_id = ? ")
			.append(" and a.jce_metrics_code = ? ")
			.append(" and jce_anly_time between ? and ? ");
		
		long taskTime = task.getTaskTime();
		long startTime = taskTime - task.getPeriod() * 1000 * 60 ;
		
		final Object[] paramsForSelect = new Object[] { task.getUsinId(), task.getMetricsCode(), 
				ToolBox.dateUtil(startTime), ToolBox.dateUtil(taskTime)};
		
		if(LOG.isDebugEnabled()){
			LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "compareThreshold") 
					+ " UsinId:" + task.getUsinId() + " ; metricsCode :=" + task.getMetricsCode() 
					+ ", startTime : " + ToolBox.dateUtil(startTime) + " ,endTime : " + ToolBox.dateUtil(taskTime));
		}
		Map<String, Object> row = jdbcTemplate.queryForMap(sql.toString(), paramsForSelect);
		//数据行数计数
		long count = ((Long) row.get("num")).longValue();
		//聚合后的结果值
		double aggValue = 0;
		if(row.get("aggvalue") != null){
			aggValue = ((Double) row.get("aggvalue")).doubleValue();
		}
		//阀值
		long threshold = task.getThreshold();
		int compareSign = task.getComputors();

		if(LOG.isDebugEnabled()){
			LOG.debug(CommonLogUtil.makeWarnHead(AnalysisConsts.MODULE_NAME, CLASSNAME, "compareThreshold") 
					+ " metricsCode :=" + task.getMetricsCode() 
					+ " thrvalue:" + threshold + " ; aggValue :" + aggValue + ", count : " + count + " ,compareSign : " + compareSign);
		}
		//比较
		if(compareSign == AnalysisConsts.COMPARESIGN_EQUAL && (count > AnalysisConsts.VALUE_ZERO && threshold == aggValue)){//= 
			return true;
		}else if(compareSign == AnalysisConsts.COMPARESIGN_SMALLER  && (count > AnalysisConsts.VALUE_ZERO && threshold > aggValue)){//<
			return true;
		}else if(compareSign == AnalysisConsts.COMPARESIGN_GREATER && (count > AnalysisConsts.VALUE_ZERO && threshold < aggValue)){//>
			return true;
		}
		
		return false;
	}
	
	/**
	 * 通过用户 服务 
	 */
	public String getInstanceName(String userId,String ServiceType,String instanceCode)
	{
		String sql = "select jce_instance_name from jce_service_instance " +
				"where jce_boss_user_id = ? and jce_service_code = ? and jce_instance_key = ? " +
				"and jce_instance_name <> 'KNULL' and jce_instance_name is not null and is_valid = 1";
		
		List<String> list = null;
		try{
			list = jdbcTemplate.queryForList(sql,String.class,userId,ServiceType,instanceCode);
		}catch (Exception e) {
			LOG.error(CommonLogUtil.makeErrorHead("AlarmAnalysisCenter", "AlarmAnalysisProcessor"), e);
		}
		if(list != null && !list.isEmpty())
		{
			return list.get(0);
		}
		return null;
	}
	
}
