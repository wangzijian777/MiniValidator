package com.jd.cloudeye.cscp.dac.db;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.common.CommonConstance;
import com.jd.cloudeye.cscp.dac.vo.MetricAnalysisVO;

@Component
public class DataBaseManager 
{
	private final static Logger LOGGER = LoggerFactory.getLogger(DataBaseManager.class);
	private final static String CLASS_NAME = "DataBaseManager";
	
	@Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;
	
	public int insertAnalysisResult(MetricAnalysisVO maVO,String tableName)
	{
		try
		{
			String sql = "insert into "+tableName+"(jce_usin_id,jce_metrics_code,jce_avg_value,jce_max_value,jce_min_value,jce_sum_value,jce_anly_time,create_time)" +
					" values(?,?,?,?,?,?,?,now())";
			Object [] param = new Object[]{maVO.getUsinId(),maVO.getMetricsCode(),maVO.getAvgValue(),maVO.getMaxValue(),maVO.getMinValue(),maVO.getSumValue(),maVO.getAnalysisTime()};
			return jdbcTemplate.update(sql, param);
		}
		catch(Exception e)
		{
			LOGGER.error(CommonLogUtil.makeErrorHead(CommonConstance.MODULE_DAC, CLASS_NAME)+"data insert error!",e);
		}
		return 0;
	}
}
