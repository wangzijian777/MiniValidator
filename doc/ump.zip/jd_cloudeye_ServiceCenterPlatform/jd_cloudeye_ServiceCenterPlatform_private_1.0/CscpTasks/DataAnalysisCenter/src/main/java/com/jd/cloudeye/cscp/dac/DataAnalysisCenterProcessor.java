package com.jd.cloudeye.cscp.dac;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.common.CommonConstance;
import com.jd.cloudeye.cscp.common.db.RedisManager;
import com.jd.cloudeye.cscp.dac.db.DataBaseManager;
import com.jd.cloudeye.cscp.dac.vo.MetricAnalysisVO;
import com.jd.cloudeye.mdas.center.MetricsDataAnalysisInfo;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Component
public class DataAnalysisCenterProcessor 
{
	private final static Logger LOGGER = LoggerFactory.getLogger(DataAnalysisCenterProcessor.class);
	private final static String CLASS_NAME = "DataAnalysisCenterProcessor";
	
	@Resource(name="redisManager")
	private RedisManager redisManager; 
	
	@Resource(name="dataBaseManager")
	private DataBaseManager dataBaseManager;
	
	
	public void processor(MetricsDataAnalysisInfo task)
	{
		CallerInfo callerInfo = null;
		try
		{
			callerInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.processor", false, true);
			
			CallerInfo metricsKeyCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.constructMetricsKey", false, true);
			String metricsKey = constructMetricsKey(task);
			Profiler.registerInfoEnd(metricsKeyCallInfo);
			
			String formatTime = convertTime(task.getTaskTime());
			
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("[START] analysis metrics key is ["+metricsKey+"]time["+formatTime+"]");
			
			CallerInfo fetchAnalysisDataCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.fetchAnalysisData", false, true);
			Map<String,String> analysisData = fetchAnalysisData(metricsKey,task.getTaskTime());
			Profiler.registerInfoEnd(fetchAnalysisDataCallInfo);
			
			if(analysisData != null && analysisData.size() > 0)
			{
				CallerInfo calculateValueCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.calculateValue", false, true);
				double[] analysisResult = calculateValue(analysisData);
				Profiler.registerInfoEnd(calculateValueCallInfo);
				
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("["+metricsKey+"]calculate result is max["+analysisResult[CommonConstance.MAX]+"]min["+analysisResult[CommonConstance.MIN]+"]avg["+analysisResult[CommonConstance.AVG]+"]sum["+analysisResult[CommonConstance.SUM]+"]");
				
				long cacheLength = cacheLastResultData(analysisResult,metricsKey,formatTime);
				
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("metricsKey["+metricsKey+"]time["+formatTime+"]cache length["+cacheLength+"]");
				
				CallerInfo insertAnalysisResultCallInfo = Profiler.registerInfo("jms.CSC.DataAnalysisCenter.insertAnalysisResult", false, true);
				dataBaseManager.insertAnalysisResult(constructResultVO(task,analysisResult), constructTableName(task.getServiceCode()));
				Profiler.registerInfoEnd(insertAnalysisResultCallInfo);
				
				if(LOGGER.isDebugEnabled())
					LOGGER.debug("[END] analysis metrics key is ["+metricsKey+"]time["+formatTime+"]");
			}
			else
			{
			    if(LOGGER.isDebugEnabled()) {
			        LOGGER.debug(CommonLogUtil.makeWarnHead(CommonConstance.MODULE_DAC, CLASS_NAME, "processor")+"key["+metricsKey+"]time["+formatTime+"]don't data in redis!");
			    }
			}
		}
		catch(DacException dac)
		{
			Profiler.functionError(callerInfo);
			LOGGER.warn(dac.getMessage());
		}
		catch(Exception e)
		{
			Profiler.functionError(callerInfo);
			LOGGER.error(CommonLogUtil.makeErrorHead(CommonConstance.MODULE_DAC, CLASS_NAME) + "analysis task error!["+task.toString()+"]",e);
		}
		finally
		{
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	private MetricAnalysisVO constructResultVO(MetricsDataAnalysisInfo task,double[] analysisResult)
	{
		MetricAnalysisVO maVO = new MetricAnalysisVO();
		maVO.setAnalysisTime(new Date(task.getTaskTime()));
		maVO.setAvgValue(analysisResult[CommonConstance.AVG]);
		maVO.setMaxValue(analysisResult[CommonConstance.MAX]);
		maVO.setMetricsCode(task.getMetricsCode());
		maVO.setMinValue(analysisResult[CommonConstance.MIN]);
		maVO.setSumValue(analysisResult[CommonConstance.SUM]);
		maVO.setUsinId(Long.valueOf(task.getUsinId()));
		return maVO;
	}
	
	private String constructMetricsKey(MetricsDataAnalysisInfo task)
	{
		StringBuilder metricsKey = new StringBuilder(task.getServiceCode());
		metricsKey.append(CommonConstance.KEY_SPLIT).append(task.getServiceCode().equals(CommonConstance.SERVICE_EC2)?CommonConstance.KNULL:task.getUserId())
		        .append(CommonConstance.KEY_SPLIT).append(task.getInstanceId())
		        .append(CommonConstance.KEY_SPLIT).append(task.getMetricsCode());
		return metricsKey.toString();
	}
	
	private Map<String,String> fetchAnalysisData(String metricsKey,long time)
	{
		return redisManager.hGetAll(metricsKey + CommonConstance.KEY_SPLIT + convertTime(time));
	}
	
	/**
	 * 根据数据接收中心缓存的一分钟原始数据，取最大值，最小值，平均值，求和的计算
	 * @param sourceLog
	 * @return
	 */
	private double[] calculateValue(Map<String,String> sourceLog) throws DacException
	{
		double [] result = new double[4];
		double maxValue = 0;
		double minValue = 0;
		double avgValue = 0;
		double sumValue = 0;
		int count = 0;
		
		if(LOGGER.isDebugEnabled())
			LOGGER.debug("analysis source data print :");
		
		for(Entry<String,String> entry:sourceLog.entrySet())
		{
			if(LOGGER.isDebugEnabled())
				LOGGER.debug("source data time["+entry.getKey()+"]value["+entry.getValue()+"]");
			
			if(entry.getValue() == null || "".equals(entry.getValue()))
			{
				continue;
			}
			
			double value = Double.valueOf(entry.getValue());
			if(count == 0)
			{
				maxValue = value;
				minValue = value;
			}
			sumValue += value;
			maxValue = Math.max(maxValue, value);
			minValue = Math.min(minValue, value);
			count++;
		}
		
		if(count == 0)
			throw new DacException(CommonLogUtil.makeWarnHead(CommonConstance.MODULE_DAC, CLASS_NAME, "calculateValue")+"all metrics value is null,please check!");
		
		avgValue = new BigDecimal(sumValue).divide(new BigDecimal(count),1,RoundingMode.HALF_UP).doubleValue();
		result[CommonConstance.MAX] = formatNumber(maxValue);
		result[CommonConstance.MIN] = formatNumber(minValue);
		result[CommonConstance.AVG] = formatNumber(avgValue);
		result[CommonConstance.SUM] = formatNumber(sumValue);
		return result;
	}
	
	/**
	 * 将分析结果缓存到redis中，只缓存最近88分钟的数据,供AS接口和报警分析直接在缓存中获取，不用查询一次数据库
	 * @param analysisResult
	 * @param metricsKey
	 * @return
	 */
	private long cacheLastResultData(double[] analysisResult,String metricsKey,String formatTime)
	{
		StringBuilder cacheResult = new StringBuilder(formatTime);
		cacheResult.append(CommonConstance.KEY_SPLIT).append(String.valueOf(analysisResult[CommonConstance.MAX]))
				   .append(CommonConstance.KEY_SPLIT).append(analysisResult[CommonConstance.MIN])
		           .append(CommonConstance.KEY_SPLIT).append(analysisResult[CommonConstance.AVG])
		           .append(CommonConstance.KEY_SPLIT).append(analysisResult[CommonConstance.SUM]);
		return redisManager.cacheAnalysisResult(metricsKey, cacheResult.toString());
	}
	
	/**
	 * 把分析任务中的long性时间解析成字符串时间yyyyMMddHHmm
	 * @param time
	 * @return
	 */
	private String convertTime(long time)
	{
		return DateFormatUtils.format(time,CommonConstance.DATA_FORMAT_YYYYMMDDHHMM);
	}
	
	/**
	 * 根据服务名拼装结果表
	 * @param serverName
	 * @return
	 */
	private String constructTableName(String serverName)
	{
		
		return CommonConstance.TABLE_PREFIX + serverName.toLowerCase() + CommonConstance.TABLE_POSTFIX;
	}
	
	/**
	 * 格式化double数字保留两位小数
	 * @param num
	 * @return
	 */
	public Double formatNumber(Double num)
	{
		return new BigDecimal(num).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}
	
//	public static void main(String [] args) throws DacException
//	{
//		DataAnalysisCenterProcessor dac = new DataAnalysisCenterProcessor();
//		MetricsDataAnalysisInfo me = new MetricsDataAnalysisInfo();
//		me.setClusterId("");
//		me.setInstanceId("10.23.33.443");
//		me.setMetricsCode("cup");
//		me.setServiceCode("EBS");
//		me.setTaskTime(System.currentTimeMillis());
//		me.setUserId("lifang");
//		me.setUsinId("333");
//		Map<String,String> map = new HashMap<String,String>();
//		map.put("00", "");
//		map.put("10", "");
//		map.put("20", "");
//		map.put("30", "");
//		map.put("40", "");
//		map.put("50", "6");
//		System.out.println(dac.constructTableName("EC2"));
//	}
}
