package com.jd.cloudeye.cscp.service.dao;


import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.jd.cloudeye.cscp.common.db.RedisManager;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllChild;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllInfo;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllInstance;
import com.jd.cloudeye.cscp.service.model.ServerInstanceInfo;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;

/**
 * 服务信息同步数据持久化处理类(分批次同步)
 * 
 * @author chenhualiang
 * @since 2013-03-02
 */
@Repository
public class ConsistencyPartDao {

	private static final Logger log = Logger.getLogger(ConsistencyPartDao.class);
	
	@Resource(name = "transactionTemplate")
	private TransactionTemplate transactionTemplate;

	@Resource(name = "jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private RedisManager redisManager;
	
	@Autowired
	private ServerConsistencyDao serverConsistencyDao;

	public int consistencyAll(final ConsistencyAllInfo requestInfo) {
		final Date eventTime = CSCPFaceServiceUtil.getTime(requestInfo.getRequestTime(), CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT);
		final LinkedList<String[]> createRelationshipList = new LinkedList<String[]>();
		int ret = this.transactionTemplate.execute(new TransactionCallback<Integer>() {

			public Integer doInTransaction(
					TransactionStatus transactionStatus) {
				if("ELB".equals(requestInfo.getServiceType()) || 
						"AS".equals(requestInfo.getServiceType()))
				{
					return consistencyCluster(requestInfo,eventTime,transactionStatus,createRelationshipList);
				}
				else if("EC2".equals(requestInfo.getServiceType()))
				{
					return consistencyInstanceOfCluster(requestInfo,eventTime,transactionStatus);
				}
				else
				{
					return consistencyInstance(requestInfo,eventTime,transactionStatus);
				}
			}

		});
		if("EC2".equals(requestInfo.getServiceType()) && ret > 0)
		{
			serverConsistencyDao.sendEC2ipToGather();
		}
		if(!createRelationshipList.isEmpty())
		{
			ret += this.transactionTemplate.execute(new TransactionCallback<Integer>() {
				 
				 public Integer doInTransaction(
							TransactionStatus transactionStatus) {
					 return createRelationship(createRelationshipList,eventTime,requestInfo.getServiceType(),transactionStatus);
				 }

			 });
		}
		
		return ret;
	}
	
	public String save2Redis(ConsistencyAllInfo requestInfo)
	{
		String key = "";
		return key;
	}
	
	public void remove(String key)
	{
		
	}
	
	private Integer createRelationship(
			LinkedList<String[]> createRelationshipList,
			Date eventTime, String serviceType,
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(createRelationshipList == null)
		{
			return ret;
		}
		Map<String, Long> instanceIdMap = queryInstanceId(serviceType,transactionStatus);
		String sql = "insert into jce_cluster_instance (jce_cluster_id,jce_instance_id,create_time,update_time,is_valid) values (?,?,?,?,?)";
		try{
			String[] relationship = null;
			while((relationship = createRelationshipList.poll()) != null)
			{
				Long clusterId = instanceIdMap.get(relationship[1] + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + serviceType);
				Long instanceId = instanceIdMap.get(relationship[0] + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + "EC2");
				if(clusterId == null || instanceId == null)
				{
					continue;
				}
				ret += jdbcTemplate.update(sql,clusterId,instanceId,eventTime,eventTime,(byte)1);
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when createRelationship exception",e);
		}
		return ret;
	}
	
	private Map<String, Long> queryInstanceId(String serviceType,TransactionStatus transactionStatus) {
		String sql = "select id,jce_service_code as serviceType,jce_instance_key as instanceId " +
				"from jce_service_instance where is_valid = '1' and (jce_service_code = 'EC2' or jce_service_code = ?)";
		try{
			List<Map<String, Object>> datas = jdbcTemplate.queryForList(sql,serviceType);
			Map<String, Long> instanceIdMap = new HashMap<String, Long>();
			if(datas != null && !datas.isEmpty())
			{
				
				for(Map<String, Object> item : datas)
				{
					String instanceId = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceId"));
					String dbServiceType = CSCPFaceServiceUtil.getStringFromObject(item.get("serviceType"));
					Long id = (Long)item.get("id");
					if(
						CSCPFaceServiceUtil.isEmpty(instanceId)||
						CSCPFaceServiceUtil.isEmpty(dbServiceType)||
						id == null
					)
					{
						continue;
					}
					instanceIdMap.put(instanceId + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + dbServiceType, id);
				}
			}
			return instanceIdMap;
		}
		catch (Exception e) {
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when consistencyInstance exception",e);
		}
	}

	private int consistencyInstance(ConsistencyAllInfo requestInfo,Date eventTime,
			TransactionStatus transactionStatus) {
		int ret = 0;
		Map<String, ServerInstanceInfo> instanceMap = queryInstance(requestInfo,eventTime, transactionStatus);
		//用于新增的服务实体队列
		LinkedList<ConsistencyAllInstance> createList = new LinkedList<ConsistencyAllInstance>();
		//用于修改的服务实体队列
		LinkedList<ConsistencyAllInstance> updateList = new LinkedList<ConsistencyAllInstance>();
		
		List<ConsistencyAllInstance> data = requestInfo.getData();
		for(ConsistencyAllInstance reqInstance : data)
		{
			String key = reqInstance.getInstanceId() + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + reqInstance.getUserId();
			ServerInstanceInfo dbInstance = instanceMap.remove(key);
			if(dbInstance == null)
			{
				createList.offer(reqInstance);
			}
			else if(!reqInstance.getInstanceName().equals(dbInstance.getInstanceName()))
			{
				updateList.offer(reqInstance);
			}
		}
		ret += saveInstanceData(createList, requestInfo.getServiceType(), eventTime,transactionStatus);
		ret += updateInstanceData(updateList, requestInfo.getServiceType(), eventTime,transactionStatus);
		return ret;
	}
	
	private int deleteInstanceData(
			LinkedList<ServerInstanceInfo> deleteList, 
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(deleteList == null)
		{
			return ret;
		}
		StringBuilder sql = new StringBuilder();
//		sql.append("update jce_service_instance as si ");
//		sql.append("set si.is_valid = '0' ,si.update_time = ? ");
//		sql.append("where si.is_valid = '1' and si.jce_boss_user_id = ? and si.jce_service_code = ? and si.jce_instance_key = ?");
		// modified by baiyunqi 20130408
		sql.append("DELETE si.* FROM jce_service_instance as si ");
		sql.append("WHERE si.is_valid = '1' AND si.jce_boss_user_id = ? AND si.jce_service_code = ? AND si.jce_instance_key = ?");
		
		try{
			ServerInstanceInfo instance = null;
			while((instance = deleteList.poll()) != null)
			{
					ret += jdbcTemplate.update(sql.toString(), instance.getUserId(),instance.getServiceType(), instance.getInstanceId());
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when deleteInstance exception",e);
		}
		return ret;
	}

	private int updateInstanceData(
			LinkedList<ConsistencyAllInstance> updateList, String serviceType,
			Date eventTime,TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(updateList == null)
		{
			return ret;
		}
		String sql = "update jce_service_instance as si " +
		"set si.update_time = ?,si.jce_instance_name = ? " +
		"where si.is_valid = '1' and si.jce_instance_key = ? and si.jce_boss_user_id = ? and si.jce_service_code = ?";
		try{
			ConsistencyAllInstance instance = null;
			while((instance = updateList.poll()) != null)
			{
				ret += jdbcTemplate.update(sql, eventTime,instance.getInstanceName(),
						instance.getInstanceId(),instance.getUserId(),serviceType
						);
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when updateInstanceName exception",e);
		}
		return ret;
	}

	private int saveInstanceData(
			LinkedList<ConsistencyAllInstance> createList,
			String ServiceType,
			Date eventTime,
			TransactionStatus transactionStatus) {
		
		int ret = 0 ;
		if(createList == null)
		{
			return ret;
		}
		ConsistencyAllInstance instance = null;
		String sql = "insert into jce_service_instance "
			+ "(jce_boss_user_id,jce_boss_user_name,jce_service_code,"
			+ "jce_instance_key,jce_instance_name,create_time,update_time,is_valid)"
			+ "values(?,?,?,?,?,?,?,?)";
		try{
			while((instance = createList.poll()) != null)
			{
				ret+= jdbcTemplate.update(
					sql, 
					instance.getUserId(),CSCPFaceServiceUtil.NULL,
					ServiceType,instance.getInstanceId(),instance.getInstanceName(),
					eventTime,eventTime,(byte) 1);
			}
		}
		catch (Exception e) {
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when saveInstance exception",e);
		}
		return ret ;
	}
	

	private Map<String, ServerInstanceInfo> queryInstance(ConsistencyAllInfo requestInfo,Date eventTime,
			TransactionStatus transactionStatus)
	{
		String sql = "select jce_instance_key as instanceId," +
		"jce_instance_name as instanceName," +
		"jce_boss_user_id as userId " +
		"from jce_service_instance where is_valid = '1' and jce_service_code = ?";
		try{
			List<Map<String, Object>> datas = jdbcTemplate.queryForList(sql, requestInfo.getServiceType());
			Map<String, ServerInstanceInfo> instanceMap = new HashMap<String, ServerInstanceInfo>();
			if(datas != null && !datas.isEmpty())
			{
				
				for(Map<String, Object> item : datas)
				{
					String instanceId = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceId"));
					String instanceName = CSCPFaceServiceUtil.getStringFromObject(item.get("instanceName"));
					String userId = CSCPFaceServiceUtil.getStringFromObject(item.get("userId"));
					if(
						CSCPFaceServiceUtil.isEmpty(instanceId)||
						CSCPFaceServiceUtil.isEmpty(instanceName)||
						CSCPFaceServiceUtil.isEmpty(userId)
					)
					{
						continue;
					}
					ServerInstanceInfo instance = new ServerInstanceInfo();
					instance.setEventTime(eventTime);
					instance.setInstanceId(instanceId);
					instance.setInstanceName(instanceName);
					instance.setServiceType(requestInfo.getServiceType());
					instance.setUserId(userId);
					instanceMap.put(instanceId + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + userId, instance);
				}
			}
			return instanceMap;
		}
		catch (Exception e) {
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when consistencyInstance exception",e);
		}
	}
	
	
	private int consistencyInstanceOfCluster(
			ConsistencyAllInfo requestInfo, Date eventTime,
			TransactionStatus transactionStatus) {
		int ret = 0;
		Map<String, ServerInstanceInfo> instanceMap = queryInstance(requestInfo,eventTime, transactionStatus);
		//用于新增的服务实体队列
		LinkedList<ConsistencyAllInstance> createList = new LinkedList<ConsistencyAllInstance>();
		//用于修改的服务实体队列
		LinkedList<ConsistencyAllInstance> updateList = new LinkedList<ConsistencyAllInstance>();
		
		List<ConsistencyAllInstance> data = requestInfo.getData();
		for(ConsistencyAllInstance reqInstance : data)
		{
			String key = reqInstance.getInstanceId() + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + reqInstance.getUserId();
			ServerInstanceInfo dbInstance = instanceMap.remove(key);
			if(dbInstance == null)
			{
				createList.offer(reqInstance);
			}
			else if(!reqInstance.getInstanceName().equals(dbInstance.getInstanceName()))
			{
				updateList.offer(reqInstance);
			}
		}
		ret += saveInstanceData(createList, requestInfo.getServiceType(), eventTime,transactionStatus);
		ret += updateInstanceData(updateList, requestInfo.getServiceType(), eventTime,transactionStatus);
		return ret;
	}
	
	private int deleteInstanceOfCluster(
			LinkedList<ServerInstanceInfo> deleteList,
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(deleteList == null)
		{
			return ret;
		}
		StringBuilder sql = new StringBuilder();
//		sql.append("update jce_service_instance as si left join jce_cluster_instance as ci on si.id = ci.jce_instance_id ");
//		sql.append("set si.is_valid = '0',ci.is_valid = '0',si.update_time = ?,ci.update_time = (case when ci.is_valid = '1' then ? else ci.update_time end) ");
//		sql.append("where si.is_valid = '1' and si.jce_service_code = ? and si.jce_instance_key = ?");
		
		// modified by baiyunqi 20130408
		sql.append("DELETE ci.*, si.* FROM jce_service_instance as si LEFT JOIN jce_cluster_instance AS ci ON si.id = ci.jce_instance_id ");
		sql.append("WHERE si.is_valid = '1' AND si.jce_service_code = ? AND si.jce_instance_key = ?");
		try{
			ServerInstanceInfo instance = null;
			while((instance = deleteList.poll()) != null)
			{
				ret += jdbcTemplate.update(sql.toString(), instance.getServiceType(), instance.getInstanceId());
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when deleteInstance exception",e);
		}
		return ret;
	}

	private int consistencyCluster(ConsistencyAllInfo requestInfo,Date eventTime,
			TransactionStatus transactionStatus,LinkedList<String[]> createRelationshipList) {
		int ret = 0;
		Map<String, ServerInstanceInfo> instanceMap = queryInstance(requestInfo,eventTime, transactionStatus);
		Map<String, String> relationshipMap = queryRelationship(requestInfo,eventTime, transactionStatus);
		//用于新增的服务实体队列
		LinkedList<ConsistencyAllInstance> createList = new LinkedList<ConsistencyAllInstance>();
		//用于修改的服务实体队列
		LinkedList<ConsistencyAllInstance> updateList = new LinkedList<ConsistencyAllInstance>();
		
		List<ConsistencyAllInstance> data = requestInfo.getData();
		for(ConsistencyAllInstance reqInstance : data)
		{
			String key = reqInstance.getInstanceId() + CSCPFaceServiceUtil.INSTATNCE_MAP_SKY + reqInstance.getUserId();
			ServerInstanceInfo dbInstance = instanceMap.remove(key);
			if(dbInstance == null)
			{
				createList.offer(reqInstance);
			}
			else if(!reqInstance.getInstanceName().equals(dbInstance.getInstanceName()))
			{
				updateList.offer(reqInstance);
			}
			
			if(reqInstance.getChildren() != null && !reqInstance.getChildren().isEmpty())
			{
				for(ConsistencyAllChild child : reqInstance.getChildren())
				{
					String clusterId = relationshipMap.remove(child.getChildId());
					if(CSCPFaceServiceUtil.isEmpty(clusterId) || !reqInstance.getInstanceId().equals(clusterId))
					{
						createRelationshipList.add(new String[]{child.getChildId(),reqInstance.getInstanceId()});
					}
				}
			}
		}
		ret += saveInstanceData(createList, requestInfo.getServiceType(), eventTime,transactionStatus);
		ret += updateInstanceData(updateList, requestInfo.getServiceType(), eventTime,transactionStatus);
		return ret;
	}

	private int deleteRelationship(LinkedList<String[]> deleteRelationshipList,String serviceType,
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(deleteRelationshipList == null)
		{
			return ret;
		}
		StringBuilder sql = new StringBuilder();
//		sql.append("update jce_cluster_instance as ci right join jce_service_instance as si1 on si1.id = ci.jce_cluster_id right join jce_service_instance as si2 on si2.id = ci.jce_instance_id ");
//		sql.append("set ci.is_valid = '0',ci.update_time = ? ");
//		sql.append("where ci.is_valid = '1' and si1.is_valid = '1' and si2.is_valid = '1' and si1.jce_instance_key = ? and si1.jce_service_code = ? and si2.jce_service_code = 'EC2' and si2.jce_instance_key = ?");
		
		// modified by baiyunqi 20130408
		sql.append("DELETE ci.* FROM jce_cluster_instance AS ci RIGHT JOIN jce_service_instance AS si1 ON si1.id = ci.jce_cluster_id RIGHT JOIN jce_service_instance AS si2 ON si2.id = ci.jce_instance_id ");
		sql.append("WHERE ci.is_valid = '1' AND si1.is_valid = '1' AND si2.is_valid = '1' AND si1.jce_instance_key = ? AND si1.jce_service_code = ? AND si2.jce_service_code = 'EC2' AND si2.jce_instance_key = ?");

		try{
			String[] relationship = null;
			while((relationship = deleteRelationshipList.poll()) != null)
			{
				ret += jdbcTemplate.update(sql.toString(), relationship[1],serviceType,relationship[0]);
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when deleteRelationship exception",e);
		}
		return ret;
	}

	private int deleteCluster(LinkedList<ServerInstanceInfo> deleteList,String serviceType,Date eventTime,
			TransactionStatus transactionStatus) {
		int ret = 0 ;
		if(deleteList == null)
		{
			return ret;
		}
		StringBuilder sql = new StringBuilder();
//		sql.append("update jce_service_instance as si left join jce_cluster_instance as ci on si.id = ci.jce_cluster_id ");
//		sql.append("set si.is_valid = '0',ci.is_valid = '0',si.update_time = ?, ci.update_time = (case when ci.is_valid = '1' then ? else ci.update_time end) ");
//		sql.append("where si.is_valid = '1' and si.jce_boss_user_id = ? and si.jce_service_code = ? and si.jce_instance_key = ?");
		
		// modified by baiyunqi 20130408
		sql.append("DELETE si.*,ci.* FROM jce_service_instance AS si LEFT JOIN jce_cluster_instance AS ci ON si.id = ci.jce_cluster_id ");
		sql.append("WHERE si.is_valid = '1' AND si.jce_boss_user_id = ? AND si.jce_service_code = ? AND si.jce_instance_key = ?");
		try{
			ServerInstanceInfo instance = null;
			while((instance = deleteList.poll()) != null)
			{
				ret += jdbcTemplate.update(
						sql.toString(),
						instance.getUserId(),instance.getServiceType(),instance.getInstanceId());
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when deleteInstance exception",e);
		}
		return ret;
	}

	private Map<String, String> queryRelationship(
			ConsistencyAllInfo requestInfo, Date eventTime,
			TransactionStatus transactionStatus) {
		Map<String, String> relationshipMap = new HashMap<String, String>();
		String sql = "select si1.jce_instance_key as clusterId ,si2.jce_instance_key as instanceId " +
			"from jce_cluster_instance as ci left join jce_service_instance as si1 on si1.id = ci.jce_cluster_id " +
			"left join jce_service_instance as si2 on si2.id = ci.jce_instance_id " + 
			"where ci.is_valid = '1' and si1.is_valid = '1' and si2.is_valid = '1' and si2.jce_service_code = 'EC2' " +
			"and si1.jce_service_code = ?";
		try{
			SqlRowSet srs = jdbcTemplate.queryForRowSet(sql, requestInfo.getServiceType());
			if(srs != null)
			{
				while (srs.next())
				{
					String clusterId = srs.getString("clusterId");
					String instanceId = srs.getString("instanceId");
					if(CSCPFaceServiceUtil.isEmpty(clusterId) || CSCPFaceServiceUtil.isEmpty(instanceId))
					{
						continue;
					}
					relationshipMap.put(instanceId,clusterId);
				}
			}
		}
		catch (Throwable e) {
			//处理异常
			transactionStatus.setRollbackOnly();
			throw new RuntimeException("when queryRelationship exception",e);
		}
		return relationshipMap;
	}

}