package com.jd.cloudeye.cscp.service.model;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * AS查询集群查询结果集
 */
public class CloudResult {
	
	/**
	 * 集群ID
	 */
	private String ASGroupID;
	
	/**
	 * 查询指标及结果集合 
	 */
	private List<Metrics> ResultData;
	
	public CloudResult(){}
	
	public CloudResult(CloudQuery query){
		this.ASGroupID = query.getASGroupID();
		this.ResultData = query.getMetricsData();
	}

	@JSONField(name = "ASGroupID")
	public String getASGroupID() {
		return ASGroupID;
	}

	public void setASGroupID(String aSGroupID) {
		ASGroupID = aSGroupID;
	}

	@JSONField(name = "ResultData")
	public List<Metrics> getResultData() {
		return ResultData;
	}

	public void setResultData(List<Metrics> ResultData) {
		this.ResultData = ResultData;
	}

}
