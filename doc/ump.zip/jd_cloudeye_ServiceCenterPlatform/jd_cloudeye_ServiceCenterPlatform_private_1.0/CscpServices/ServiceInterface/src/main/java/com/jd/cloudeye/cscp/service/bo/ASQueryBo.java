package com.jd.cloudeye.cscp.service.bo;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.service.dao.ASQueryDao;
import com.jd.cloudeye.cscp.service.model.ASQuery;
import com.jd.cloudeye.cscp.service.model.ASResult;
import com.jd.cloudeye.cscp.service.model.CloudResult;
import com.jd.cloudeye.cscp.service.model.EC2Info;
import com.jd.cloudeye.cscp.service.model.CloudQuery;
import com.jd.cloudeye.cscp.service.model.Metrics;
import com.jd.cloudeye.cscp.service.model.ServerConsistencyState;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * AS查询业务处理类
 * 
 * @author chenhualiang
 * @serial 2013-03-8
 */
@Component("asQueryBo")
public class ASQueryBo {
	
	private static final Logger log = Logger.getLogger(ASQueryBo.class);
	
	@Autowired
	private ASQueryDao asQueryDao;
	
	@Resource(name="asTaskExecutor")
	private TaskExecutor asTaskExecutor; 
	
	/**
	 * as查询
	 * 
	 * @param query 查询参数
	 * @param metricsMap 快速查找Metrics
	 * 
	 * @return String 查询结果
	 * 
	 * @author chenhualiang
	 * @since 2013-03-9
	 */
	public String doASQuery(final Map<String, Metrics> metricsMap ,final ASQuery query) {
		//监控每个线程是否处理完成
		final CountDownLatch countKey = new CountDownLatch(query.getData().size());
		//判断该用哪种查询方式(redis查询还是mysql查询)
		final Integer plan = choosePlan(query);
		for(final CloudQuery cloudQuery : query.getData())
		{
			asTaskExecutor.execute(new Runnable() {
				
				@Override
				public void run() {
					CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.ServiceInterface.doASQuery", false, true);
					try{
						//查询集群下的所有EC2实例
						List<EC2Info> instanceList = asQueryDao.queryASCloudInfo(cloudQuery);
						if(instanceList == null || instanceList.isEmpty())
						{
							return ;
						}
						switch (plan) {
						//查询mysql数据库
						case CSCPFaceServiceUtil.AS_QUERY_PLAN_DB:
							asQueryDao.executeASQueryFromDB(metricsMap,query,cloudQuery,instanceList);
							break;
						//查询redis
						case CSCPFaceServiceUtil.AS_QUERY_PLAN_RADIS:
							asQueryDao.executeASQueryFromRadis(metricsMap,query,cloudQuery,instanceList);
							break;
						//默认查询数据库
						default:
							asQueryDao.executeASQueryFromDB(metricsMap,query,cloudQuery,instanceList);
							break;
						}
					}
					catch(Throwable e)
					{
						log.error(CommonLogUtil.makeErrorHead("ServiceIntface", "ASQueryBo"),e);
						Profiler.functionError(callerInfo);
					}
					finally
					{
						countKey.countDown();
						Profiler.registerInfoEnd(callerInfo);
					}
				}
				
			});
		}
		try {
			//查询超时时间为60秒钟
			countKey.await(CSCPFaceServiceUtil.SECONDS_OF_ONE_MINUTE, TimeUnit.SECONDS);
			ASResult result = new ASResult();
			result.setMessage("success");
			result.setState("1");
			result.setResponseTime(CSCPFaceServiceUtil.getTimeOfNow(CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT));
			if(query.getData() != null && !query.getData().isEmpty())
			{
				for(CloudQuery cloudQuery : query.getData())
				{
					result.addResult(new CloudResult(cloudQuery));
				}
			}
			return JSON.toJSONString(result);
		} catch (InterruptedException e) {
			log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ASQueryBo") + " as query time out");
			return ServerConsistencyState.Timeout.toString();
		}
	}
	
	/**
	 * 判断采用哪种查询方案 
	 */
	private int choosePlan(ASQuery query) {
		int period = Integer.parseInt(query.getPeriod());
		int timeInterval = Integer.parseInt(query.getTimeInterval());
		if(period * timeInterval > CSCPFaceServiceUtil.EC2_RADIS_CACHE_TIME)
		{
			return CSCPFaceServiceUtil.AS_QUERY_PLAN_DB;
		}
		else
		{
			return CSCPFaceServiceUtil.AS_QUERY_PLAN_RADIS;
		}
	}
	
}
