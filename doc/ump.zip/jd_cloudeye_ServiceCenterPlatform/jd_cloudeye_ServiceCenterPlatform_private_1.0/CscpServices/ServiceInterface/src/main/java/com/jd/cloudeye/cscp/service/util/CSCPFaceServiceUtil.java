package com.jd.cloudeye.cscp.service.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

/**
 * 云监控接口服务工具类
 * 
 * @author chenhualiang
 * @since 2013-03-01
 */
public class CSCPFaceServiceUtil {
	
	/**
	 * 数据库特殊字段空值代替字符串 
	 */
	public static final String NULL = "KNULL";
	
	/**
	 * 不需要存在
	 */
	public static final String NOT_EXIST = "NOT_EXIST";
	
	/**
	 * 时间格式表达式（简单时间） 
	 */
	public static final String SIMPLE_TIME_FORMAT = "yyyyMMddHHmmssSSS";

	/**
	 * 只到分钟的时间格式表达式
	 */
	public static final String MINUTE_TIME_FORMAT = "yyyyMMddHHmm";

	/**
	 * 1分钟的秒数
	 */
	public static final int SECONDS_OF_ONE_MINUTE = 60;
	
	/**
	 * 实例存活key
	 */
	public static final String ALIVE_KEY = "AliveTime";
	
	public static final Set<String> ALIVE_KEY_SERVICE_SET = new HashSet<String>();
	static{
		ALIVE_KEY_SERVICE_SET.add("EC2");
	}
	
	public static final String INSTATNCE_MAP_SKY = "##@##";
	
	/**
	 * 实例状态未知
	 */
	public static final String UNKNOW_STATE = "-1";
	
	/**
	 * 实例状态存活
	 */
	public static final String ALIVE_STATE = "1";

	/**
	 * 实例状态不存活
	 */
	public static final String UNALIVE_STATE = "0";
	
	/**
	 * EC2指标更新时间5分钟 
	 */
	public static final int METRICS_EC2_CACHE_TIME = 300000;

	/**
	 * SERICE_TYPE指标更新时间1分钟 
	 */
	public static final int SERICE_TYPE_CACHE_TIME = 60000;

	/**
	 * 非集群实例标志
	 */
	public static final int NOT_CLUSTER_INSTANCE = 0;

	/**
	 * EC2实例标志
	 */
	public static final int EC2_IN_CLUSTER = 1;

	/**
	 * 集群实例标志
	 */
	public static final int INSTANCE_OF_CLUSTER = 2;

	/**
	 * 集群实例关系标志
	 */
	public static final int RELATIONSHIP_INSTANCE_WITH_CLUSTER = 3;
	
	/**
	 * JECS群实例标志
	 */
	public static final int JECS_IN_CLUSTER = 4;
	
	/**
	 * as查询统计计算规则 映射
	 */
	public static Map<String, String> COMPUTOR_NAME_MAP ;
	static{
		COMPUTOR_NAME_MAP = new HashMap<String, String>();
		COMPUTOR_NAME_MAP.put("SUM", "sum_value");
		COMPUTOR_NAME_MAP.put("AVG", "avg_value");
		COMPUTOR_NAME_MAP.put("MAX", "max_value");
		COMPUTOR_NAME_MAP.put("MIN", "min_value");
	}
	
	/**
	 * as查询方案  查询数据库
	 */
	public static final int AS_QUERY_PLAN_DB = 0;

	/**
	 * as查询方案  查询radis
	 */
	public static final int AS_QUERY_PLAN_RADIS = 1;
	
	/**
	 * EC2在radis中缓存的时间长度 （单位：分钟）  
	 */
	public static final int EC2_RADIS_CACHE_TIME = 60;
	
	/**
	 * 获取当期时间的格式化时间字符串
	 * 
	 * @param pattern 时间格式
	 * 
	 * @return String 时间的格式化字符串
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public static String getTimeOfNow(String pattern)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(System.currentTimeMillis());
	}
	
	/**
	 * 获取指定时间的格式化时间字符串
	 * 
	 * @param time 时间
	 * @param pattern 时间格式
	 * 
	 * @return String 时间的格式化字符串
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public static String getTime(Date time,String pattern)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(time);
	}
	
	/**
	 * 判断字符串是否为空或空串（&trim）
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public static boolean isEmpty(String str)
	{
		return str == null || "".equals(str.trim());
	}
	
	/**
	 * 检查时间字符串是否与时间格式串匹配
	 * 
	 * @param timeStr 时间字符串
	 * @param pattern 时间格式串
	 * 
	 * @return boolean true:匹配;false:不匹配
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public static boolean checkTime(String timeStr , String pattern)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		try {
			sdf.parse(timeStr);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	/**
	 * 获取时间格式串匹配的时间
	 * 
	 * @param timeStr 时间字符串
	 * @param pattern 时间格式串
	 * 
	 * @return Date 时间
	 * 
	 * @author chenhualiang
	 * @since 2013-03-01
	 */
	public static Date getTime(String timeStr , String pattern)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		try {
			return sdf.parse(timeStr);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 通过Object获取它的字符串表示
	 * 
	 * @param data 目标对象
	 * 
	 * @return String 目标对象的字符串表示
	 */
	public static String getStringFromObject(Object data)
	{
		if(data == null)
		{
			return null;
		}
		return data.toString().trim();
	}
	
	/**
	 * 打印超长数据 
	 */
	public static void printLog(Logger log,String head,String body)
	{
		int headLength = head.length();
		int bodyLength = body.length();
		int logHeadLength = 150;
		if(headLength + bodyLength + logHeadLength>= 2000)
		{
			int step = 2000 - headLength - logHeadLength;
			for(int i = 0 ; i < bodyLength ; i += step )
			{
				String str = "";
				if(i + step > bodyLength)
				{
					str = head + body.substring(i);
				}
				else
				{
					str = head + body.substring(i, i + step);
				}
				log.info(str);
			}
		}
		else
		{
			log.info(head + body);
		}
	}
	
}
