package com.jd.cloudeye.cscp.service.model;

import java.util.List;

/**
 * AS查询集群查询数据 
 */
public class CloudQuery {
	
	/**
	 * 集群ID 
	 */
	private String ASGroupID;
	
	/**
	 * 请求指令集合 
	 */
	private List<Metrics> MetricsData;

	public String getASGroupID() {
		return ASGroupID;
	}

	public void setASGroupID(String aSGroupID) {
		ASGroupID = aSGroupID;
	}

	public List<Metrics> getMetricsData() {
		return MetricsData;
	}

	public void setMetricsData(List<Metrics> metricsData) {
		MetricsData = metricsData;
	}
}
