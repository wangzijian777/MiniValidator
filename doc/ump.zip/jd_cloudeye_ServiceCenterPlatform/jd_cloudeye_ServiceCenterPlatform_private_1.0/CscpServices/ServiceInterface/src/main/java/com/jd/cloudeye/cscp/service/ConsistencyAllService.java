package com.jd.cloudeye.cscp.service;

import java.util.Iterator;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSON;
import com.jd.cloudeye.common.CommonLogUtil;
import com.jd.cloudeye.cscp.service.bo.ConsistencyAllBo;
import com.jd.cloudeye.cscp.service.bo.ServerConsistencyBo;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllChild;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllInfo;
import com.jd.cloudeye.cscp.service.model.ConsistencyAllInstance;
import com.jd.cloudeye.cscp.service.model.ServerConsistencyState;
import com.jd.cloudeye.cscp.service.util.CSCPFaceServiceUtil;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


/**
 * server实例同步接口 
 * 
 * @author chenhualiang
 * @since 2013-02-28
 */
@Controller
@RequestMapping("/consistencyAll")
public class ConsistencyAllService {
	
	private static final Logger log = Logger.getLogger(ConsistencyAllService.class);
	
	@Autowired
	private ConsistencyAllBo consistencyAllBo;
	
	@Autowired
	private ServerConsistencyBo serverConsistencyBo;
	
	@Value("${consistency.token}")
	private String consistencyToken;
	
	@Autowired
	private UserServiceTypeFilter userServiceTypeFilter;
	
	/**
	 * server实例全量同步接口 
	 * 
	 * @param response HttpServletResponse
	 * @param requestToken 客户端请求携带的token值
	 * @param requestMessage 请求内容
	 * 
	 * @author chenhualiang
	 * @since 2013-02-28
	 */
	@RequestMapping(method = RequestMethod.POST)
	public void consistencyAll(
			HttpServletResponse response,
			//服务器验证token
			@RequestHeader(value = "token",required = false) String requestToken,
			//各种参数
			@RequestBody  String requestMessage
			)
	{
		CallerInfo callerInfo = Profiler.registerInfo("jms.CSC.ServiceInterface.consistencyAll", false, true);
		CSCPFaceServiceUtil.printLog(log, CommonLogUtil.makeInfoHead("ServiceInterface", "ConsistencyAllService", "consistencyAll"), 
				requestMessage +  "|||,requestToken=" + requestToken);
		//token 校验
		if(!CSCPFaceServiceUtil.isEmpty(consistencyToken) && !CSCPFaceServiceUtil.isEmpty(requestToken))
		{
			if(CSCPFaceServiceUtil.isEmpty(requestToken) ||
				!requestToken.equalsIgnoreCase(consistencyToken))
			{
				//反馈信息
				log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ConsistencyAllService") + "token error");
				sendMessage(response, ServerConsistencyState.Fail.toString());
				Profiler.registerInfoEnd(callerInfo);
				return ;
			}
		}
		else
		{
			if(CSCPFaceServiceUtil.isEmpty(requestToken))
			{
				CSCPFaceServiceUtil.printLog(log, CommonLogUtil.makeInfoHead("ServiceInterface", "ConsistencyAllService", "consistencyAll"), 
						"no token request :" + requestMessage +  "|||,requestToken=" + requestToken);
			}
			if(CSCPFaceServiceUtil.isEmpty(consistencyToken))
			{
				log.warn(CommonLogUtil.makeWarnHead("ServiceInterface", "ConsistencyAllService", "consistencyAll") + "no token in server ");
			}
		}
		if(CSCPFaceServiceUtil.isEmpty(requestMessage) )
		{
			sendMessage(response, ServerConsistencyState.Illegal.toString());
			Profiler.registerInfoEnd(callerInfo);
			return ;
		}
		ConsistencyAllInfo requestInfo = null;
		try{
			requestInfo = JSON.parseObject(requestMessage,ConsistencyAllInfo.class);
		}catch (Throwable e) {
			log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ConsistencyAllService") ,e);
		}
		//业务处理
		String retContent = null;
		if(check(requestInfo))
		{
			try{
				retContent = consistency(requestInfo);
			}catch (Throwable e) {
				log.error(CommonLogUtil.makeErrorHead("ServiceInterface", "ConsistencyAllService") + "consistencyAll error",e);
				retContent = ServerConsistencyState.Fail.toString();
				Profiler.functionError(callerInfo);
			}
		}
		else
		{
			retContent = ServerConsistencyState.Illegal.toString();
		}
		//反馈信息
		sendMessage(response, retContent) ;
		Profiler.registerInfoEnd(callerInfo);
	}
	
	private boolean check(ConsistencyAllInfo requestInfo) {
		if(requestInfo == null)
		{
			return false;
		}
		if(requestInfo.getData() == null || requestInfo.getData().isEmpty())
		{
			return false;
		}
		if(!serverConsistencyBo.isValidServiceType(requestInfo.getServiceType()))
		{
			return false;
		}
		if(requestInfo.getSyncTotal() > 1 && CSCPFaceServiceUtil.isEmpty(requestInfo.getSyncSeq()))
		{
			return false;
		}
		if(requestInfo.getSyncTotal() < requestInfo.getSyncIndex() 
				|| requestInfo.getSyncTotal() < 1 
				||  requestInfo.getSyncIndex() < 1)
		{
			return false;
		}
		if(!CSCPFaceServiceUtil.checkTime(requestInfo.getRequestTime(), CSCPFaceServiceUtil.SIMPLE_TIME_FORMAT))
		{
			return false;
		}
		boolean isCluster = false;
		if("AS".equals(requestInfo.getServiceType()) || "ELB".equals(requestInfo.getServiceType()))
		{
			isCluster = true;
		}
		Iterator<ConsistencyAllInstance> it = requestInfo.getData().iterator();
		while(it.hasNext())
		{
			ConsistencyAllInstance item = it.next();
			/**
			 * 对user & serviceType 进行过滤
			 * 
			 *  2013-07-29
			 */
			if(userServiceTypeFilter.filter(item.getUserId(), requestInfo.getServiceType()))
			{
				//to delete item from requestInfo.getData()
				it.remove();
				continue;
			}
			if(
					CSCPFaceServiceUtil.isEmpty(item.getUserId()))
			{
				return false;
			}
			if(!("JSS".equalsIgnoreCase(requestInfo.getServiceType()) || "JHbase".equalsIgnoreCase(requestInfo.getServiceType()))&&
					(CSCPFaceServiceUtil.isEmpty(item.getInstanceId()) || 
					CSCPFaceServiceUtil.isEmpty(item.getInstanceName())))
			{
				return false;
			}
			if("JSS".equalsIgnoreCase(requestInfo.getServiceType())|| "JHbase".equalsIgnoreCase(requestInfo.getServiceType()))
			{
				item.setInstanceId(CSCPFaceServiceUtil.NULL);
				item.setInstanceName(CSCPFaceServiceUtil.NULL);
			}
			if(isCluster)
			{
				if(item.getChildren() != null)
				{
					for(ConsistencyAllChild child : item.getChildren())
					{
						if(CSCPFaceServiceUtil.isEmpty(child.getChildId()))
						{
							return false;
						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * server实例全量同步业务处理
	 * 
	 * @param requestInfo 全量同步请求
	 * 
	 * @return String 处理结果
	 * <pre>处理结果格式：
	 * {"state":"1","message":"success","responseTime":"20130222100355195"}
	 * 
	 * 解释说明:
	 * state = 0：系统异常;1：成功;2 : 参数无效
	 * message 当state=0时，反馈“fail”；当state=1时，反馈“success”；当state=2时，反馈“parameter illegal”；
	 * responseTime 响应时间，格式:yyyyMMddHHmmssSSS
	 * </pre>
	 * @author chenhualiang
	 * @since 2013-02-28
	 */
	private String consistency(ConsistencyAllInfo requestInfo) {
		consistencyAllBo.consistencyAll(requestInfo);
		return ServerConsistencyState.Success.toString();
	}
	
	/**
	 * 反馈数据 
	 */
	private void sendMessage(HttpServletResponse response,String content)
	{
		response.setContentType("application/json;charset=UTF-8");
		try{
			log.info(CommonLogUtil.makeInfoHead("ServiceInterface", "ConsistencyAllService", "sendMessage") + content);
			response.getWriter().write(content);
			response.getWriter().flush();
			response.getWriter().close();
		}catch (Exception e) {
		}
	}
}
