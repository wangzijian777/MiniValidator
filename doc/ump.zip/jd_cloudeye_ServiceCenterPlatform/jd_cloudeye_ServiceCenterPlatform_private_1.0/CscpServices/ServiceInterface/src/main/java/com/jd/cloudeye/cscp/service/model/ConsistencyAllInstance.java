package com.jd.cloudeye.cscp.service.model;

import java.util.List;

/**
 * 全量同步的服务实例 
 */
public class ConsistencyAllInstance {
	
	/**
	 * 用户ID 
	 */
	private String userId;
	
	/**
	 * 实例ID 
	 */
	private String instanceId;
	
	/**
	 * 实例名称 
	 */
	private String instanceName;
	
	/**
	 * 群组子实例 
	 */
	private List<ConsistencyAllChild> children;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public List<ConsistencyAllChild> getChildren() {
		return children;
	}

	public void setChildren(List<ConsistencyAllChild> children) {
		this.children = children;
	}

}
