package com.jd.cloudeye.cscp.service.model;

import java.util.List;

/**
 * 全量同步请求 
 */
public class ConsistencyAllInfo {
	
	/**
	 * 服务类型 
	 */
	private String serviceType ;
	
	/**
	 * 请求时间
	 */
	private String requestTime;
	
	/**
	 * 分段请求的第几部分；不分段时，syncIndex = 1；syncTotal = 1
	 */
	private int syncIndex = 1;
	
	/**
	 * 分段请求总共有几部分；不分段时，syncIndex = 1；syncTotal = 1
	 */
	private int syncTotal = 1;
	
	/**
	 * 分段请求同组序号，即同一批次的请求使用同一个序号(最好保证一段时间内唯一)
	 */
	private String syncSeq;
	
	/**
	 * 同步数据 
	 */
	private List<ConsistencyAllInstance> data;

	public int getSyncIndex() {
		return syncIndex;
	}

	public void setSyncIndex(int syncIndex) {
		this.syncIndex = syncIndex;
	}

	public int getSyncTotal() {
		return syncTotal;
	}

	public void setSyncTotal(int syncTotal) {
		this.syncTotal = syncTotal;
	}

	public String getSyncSeq() {
		return syncSeq;
	}

	public void setSyncSeq(String syncSeq) {
		this.syncSeq = syncSeq;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}

	public List<ConsistencyAllInstance> getData() {
		return data;
	}

	public void setData(List<ConsistencyAllInstance> data) {
		this.data = data;
	}
}
