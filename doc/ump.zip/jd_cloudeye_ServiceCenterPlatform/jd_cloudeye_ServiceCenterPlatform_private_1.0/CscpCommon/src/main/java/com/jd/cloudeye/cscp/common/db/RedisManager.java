package com.jd.cloudeye.cscp.common.db;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.jd.cachecloud.driver.jedis.ShardedXCommands;
import com.jd.cloudeye.cscp.common.CommonConstance;

@Component
public class RedisManager 
{
	private static final String PREFIX = "JDCE";
	private static final String PREFIX_CACHE = "DBMC";
	
	@Resource(name = "redisClient") 
	private ShardedXCommands redisClient;
	
	public Map<String,String> hGetAll(String key)
	{
		return redisClient.hgetAll(PREFIX + CommonConstance.KEY_SPLIT + key);
	}
	
	public long cacheAnalysisResult(String metricsKey,String value)
	{
		String cacheKey = PREFIX + CommonConstance.KEY_SPLIT + PREFIX_CACHE + CommonConstance.KEY_SPLIT + metricsKey;
		long length = redisClient.llen(cacheKey);
		if(length > 87)
		{
			redisClient.rpop(cacheKey);
		}
		return redisClient.lpush(cacheKey, value);
	}
	
	
	public List<String> getCacheAnalyResult(String metricsKey,int index,int length)
	{
		String cacheKey = PREFIX + CommonConstance.KEY_SPLIT + PREFIX_CACHE + CommonConstance.KEY_SPLIT + metricsKey;
		List<String> result = redisClient.lrange(cacheKey, index, index + length);
		if(result == null || result.isEmpty())
		{
			return new ArrayList<String>();
		}
		return result;
	}
	
	/**
	 * 通过指定的key,field查找value--适用于hashs类型
	 * @param key
	 * @param field
	 * @return
	 */
	public String getHvalue(String key,String field){
		return redisClient.hget(PREFIX + CommonConstance.KEY_SPLIT + key, field);
	}
	
	/**
	 * 设置KV值
	 * @param key
	 * @param field
	 * @param value
	 */
	public void setHKeyValue(String key,String field,String value){
		redisClient.hset(PREFIX + CommonConstance.KEY_SPLIT + key, field, value);
	}
	
	/**
	 * 设置KV值
	 * @param key
	 * @param value
	 */
	public void setKeyValue(String key,String value){
		redisClient.set(key, value);
	}
	
	/**
	 * 获取KV值
	 * @param key
	 */
	public String getKeyValue(String key){
		return redisClient.get(key);
	}
	
	/**
	 * 设置过期
	 * @param key
	 * @param value
	 */
	public void expire(String key,int seconds){
		redisClient.expire(key, seconds);
	}

}
