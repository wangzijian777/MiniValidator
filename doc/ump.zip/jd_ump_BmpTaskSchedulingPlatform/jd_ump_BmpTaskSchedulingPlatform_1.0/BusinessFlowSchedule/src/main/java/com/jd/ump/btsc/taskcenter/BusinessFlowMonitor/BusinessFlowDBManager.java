package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.alibaba.fastjson.JSON;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;


/**
 * 从数据库获得所有业务流程监控配置信息
 * 
 * @author duliang
 * @date 2013-10-22 
 */
public class BusinessFlowDBManager {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(BusinessFlowDBManager.class);
    private JdbcTemplate jdbcTemplate;

    /**
     * 数据库注册连接
     */
    public BusinessFlowDBManager() {
    	this.jdbcTemplate = SwitchMasterSlave.TaskSchedulingCenterManagers.getJdbcTemplate();
    }

    
    /**
     * 查询每天分析一次的配置信息
     * 数据格式：BusinessFlowConfigInfo
     */
    public  List<BusinessFlowConfigInfo> getBusinessFlowInfoFromDB() {
    	
    	List<BusinessFlowConfigInfo> businessFlowConfigInfoList = new ArrayList<BusinessFlowConfigInfo>();
    	HashMap<String,String> flowNodeConfigMap = new HashMap<String,String>();
    	HashMap<String,Map<String,String>> flowNodeMap = new HashMap<String,Map<String,String>>();
    	flowNodeConfigMap = getFlowNodeConfig();
    	flowNodeMap = getFlowNode();
    	Set<String> combinedSet = getFlowNodeAlarmConfig();
    	if(flowNodeConfigMap.size()>0){
    		for(Map.Entry<String, String> entry : flowNodeConfigMap.entrySet()) {
    			String flowIdAndNodeId = entry.getKey();
    			if(flowNodeMap.containsKey(flowIdAndNodeId)){
    				String flowId = flowIdAndNodeId.split("#")[0];
    				String nodeId = flowIdAndNodeId.split("#")[1];
    				String timeOut = entry.getValue();
    				String nodeName = flowNodeMap.get(flowIdAndNodeId).get("nodeName");
    				String dataKey = flowNodeMap.get(flowIdAndNodeId).get("dataKey");
    				String seqNo = flowNodeMap.get(flowIdAndNodeId).get("seqNo");
    				String previousNode = flowNodeMap.get(flowIdAndNodeId).get("previousNode");
    				String flowAppId = flowNodeMap.get(flowIdAndNodeId).get("flowAppId");
    				String flowName = flowNodeMap.get(flowIdAndNodeId).get("flowName");
    				
    				HashMap<String,String> upstreamMap = new HashMap<String,String>();
    				HashMap<String,String> downstreamMap = new HashMap<String,String>();
    				
    				//获取当前流程所属应用的名称
    				HashMap<String,String> hm =  getAppNameAndAlarmNodes(flowAppId,nodeId,flowId);
    				if(hm.size()!=2)
    					continue;
    				
    				//上游节点
    				upstreamMap = getNodeInfoByNodeId(previousNode);
    				
    				//下游节点
    				downstreamMap.put("nodeId", nodeId);
    				downstreamMap.put("nodeName", nodeName);
    				downstreamMap.put("dataKey", dataKey);
    				downstreamMap.put("seqNo", seqNo);
    				
    				BusinessFlowConfigInfo businessFlowConfigInfo = new BusinessFlowConfigInfo();
    				businessFlowConfigInfo.setFlowId(flowId);
    				businessFlowConfigInfo.setFlowAppName(hm.get("flowAppName"));
    				businessFlowConfigInfo.setAlarmNodes(hm.get("alarmNodes"));
    				businessFlowConfigInfo.setFlowName(flowName);
    				businessFlowConfigInfo.setTimeOut(timeOut);
    				StringBuilder sb = new StringBuilder();
    				if(hm.get("alarmNodes") != null && !hm.get("alarmNodes").trim().equals(""))
    				{
	    				String[] alarmNodes = hm.get("alarmNodes").split(",");
	    				for(String alarmNode : alarmNodes)
	    				{
	    					sb.append(combinedSet.contains(flowId + "#" + alarmNode)?1:0).append(",");
	    				}
	    				if(sb.length() > 0)
	    				{
	    					sb.deleteCharAt(sb.length() - 1);
	    				}
    				}
    				businessFlowConfigInfo.setIsCombined(sb.toString());
    				businessFlowConfigInfo.setDownstreamMap(downstreamMap);
    				if(upstreamMap.size()>0){
    					businessFlowConfigInfo.setUpstreamMap(upstreamMap);
    				}
    				businessFlowConfigInfoList.add(businessFlowConfigInfo);
    			}
    		}
    	}
    	if(LOGGER.isDebugEnabled())
    	{
    		LOGGER.debug("businessFlowConfigInfoList=" + JSON.toJSONString(businessFlowConfigInfoList));
    	}
    	return businessFlowConfigInfoList;
    }
    
    
    
    
    public Set<String> getFlowNodeAlarmConfig() {
    	Set<String> combinedSet = new HashSet<String>();
    	String sql = "select concat(flow_id,'#',node_id) as flowNodeKey from biz_flow_alarm_config where combined_cycle > 0";
    	List<String> ret = jdbcTemplate.query(sql, new RowMapper<String>(){

			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString(1);
			}});
    	
    	if(ret != null && !ret.isEmpty())
    	{
    		combinedSet.addAll(ret);
    	}
		return combinedSet;
	}
    
    public Set<String> getFlowNodeAlarmFiveConfig(String startTime, String endTime) {
    	Set<String> combinedTempSet = new HashSet<String>();
    	Set<String> combinedSet = new HashSet<String>();
    	String sql = "select concat(fac.flow_id,'#',fac.node_id) as flowNodeKey from biz_flow_alarm_config fac " +
    			"inner join biz_flow_alarm_meg fam on fac.flow_id = fam.flow_id and fac.node_id = fam.node_id " +
    			"where fac.combined_cycle = 5 group by flowNodeKey";
    	List<String> ret = jdbcTemplate.query(sql, new RowMapper<String>(){
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString(1);
			}});
    	if(ret != null && !ret.isEmpty())
    	{
    		combinedTempSet.addAll(ret);
    		for (String combined : combinedTempSet) {
    			combined = combined + "#" +startTime + "#" + endTime;
    			combinedSet.add(combined);
    		}
    		String updateSql = " update biz_flow_alarm_meg set is_alarmed = 'SENDING' where is_combine = 1 and create_time >= ? and create_time <= ?";
    		jdbcTemplate.update(updateSql,startTime,endTime);
    	}
		return combinedSet;
	}
    public Set<String> getFlowNodeAlarmTenConfig(String startTime, String endTime) {
    	Set<String> combinedTempSet = new HashSet<String>();
    	Set<String> combinedSet = new HashSet<String>();
    	String sql = "select concat(fac.flow_id,'#',fac.node_id) as flowNodeKey from biz_flow_alarm_config fac " +
    			"inner join biz_flow_alarm_meg fam on fac.flow_id = fam.flow_id and fac.node_id = fam.node_id " +
    			"where fac.combined_cycle = 10 group by flowNodeKey";
    	List<String> ret = jdbcTemplate.query(sql, new RowMapper<String>(){

			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString(1);
			}});
    	
    	if(ret != null && !ret.isEmpty())
    	{
    		combinedTempSet.addAll(ret);
    		for (String combined : combinedTempSet) {
    			combined = combined + "#" +startTime + "#" + endTime;
    			combinedSet.add(combined);
    		}
    		String updateSql = " update biz_flow_alarm_meg set is_alarmed = 'SENDING' where is_combine = 1 and create_time >= ? and create_time <= ?";
    		jdbcTemplate.update(updateSql,startTime,endTime);
    	}
		return combinedSet;
	}
    public Set<String> getFlowNodeAlarmThirtyConfig(String startTime, String endTime) {
    	Set<String> combinedTempSet = new HashSet<String>();
    	Set<String> combinedSet = new HashSet<String>();
    	String sql = "select concat(fac.flow_id,'#',fac.node_id) as flowNodeKey from biz_flow_alarm_config fac " +
    			"inner join biz_flow_alarm_meg fam on fac.flow_id = fam.flow_id and fac.node_id = fam.node_id " +
    			"where fac.combined_cycle = 30 group by flowNodeKey";
    	List<String> ret = jdbcTemplate.query(sql, new RowMapper<String>(){

			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString(1);
			}});
    	
    	if(ret != null && !ret.isEmpty())
    	{
    		combinedTempSet.addAll(ret);
    		for (String combined : combinedTempSet) {
    			combined = combined + "#" +startTime + "#" + endTime;
    			combinedSet.add(combined);
    		}
    		String updateSql = "update biz_flow_alarm_meg set is_alarmed = 'SENDING' where is_combine = 1 and create_time >= ? and create_time <= ?";
    		jdbcTemplate.update(updateSql,startTime,endTime);
    	}
		return combinedSet;
	}

	/**
     * 查询报警配置表
     * @return
     */
    public HashMap<String,String> getFlowNodeConfig(){
    	
    	HashMap<String,String> flowNodeConfigMap = new HashMap<String,String>();
    	HashMap<String,String> timeoutAlarmMap = new HashMap<String,String>();
    	HashMap<String,String> timeoutMap = new HashMap<String,String>();
    	
    	String sql1 = " select keyword,keyvalue,flow_id,node_id from biz_flow_node_config where keyword =? and keyvalue =? ";
		Object[] paramsForSelect1 = new Object[] { BusinessFlowUtil.KEY_WORD_TIMEOUT_ALARM, BusinessFlowUtil.VALID};
		List<Map<String, Object>> tpRows1 = this.jdbcTemplate.queryForList(sql1,paramsForSelect1);
		if (tpRows1.size() > 0) {
		    for (Map<String, Object> row : tpRows1) {
		    	long flowId = ((Long)row.get("flow_id")).longValue();
		    	long nodeId = ((Long)row.get("node_id")).longValue();
		    	String keyvalue = (String)row.get("keyvalue");
		    	
		    	String mapKey = Long.toString(flowId) + "#" + Long.toString(nodeId) ;
		    	timeoutAlarmMap.put(mapKey, keyvalue);
		    }
		}
		LOGGER.info(" Catch TimeoutAlarm Map Size : " + timeoutAlarmMap.size() + "###" + JSON.toJSONString(timeoutAlarmMap));
		
		
		String sql2 = " select keyword,keyvalue,flow_id,node_id from biz_flow_node_config where keyword =? and keyvalue is not null  ";
		Object[] paramsForSelect2 = new Object[] { BusinessFlowUtil.KEY_WORD_TIMEOUT };
		List<Map<String, Object>> tpRows2 = this.jdbcTemplate.queryForList(sql2,paramsForSelect2);
		if (tpRows2.size() > 0) {
		    for (Map<String, Object> row : tpRows2) {
		    	long flowId = ((Long)row.get("flow_id")).longValue();
		    	long nodeId = ((Long)row.get("node_id")).longValue();
		    	String keyvalue = (String)row.get("keyvalue");
		    	
		    	String mapKey = Long.toString(flowId) + "#" + Long.toString(nodeId) ;
		    	timeoutMap.put(mapKey, keyvalue);
		    } 
		}
		LOGGER.info(" Catch Timeout Map Size : " + timeoutMap.size() + "###" + JSON.toJSONString(timeoutMap));
		
		if(timeoutAlarmMap.size()>0){
			for(Map.Entry<String, String> entry: timeoutAlarmMap.entrySet()) {
				String key = entry.getKey();
				if(timeoutMap.containsKey(key)){
					flowNodeConfigMap.put(key, timeoutMap.get(key));
				}
			} 
		}
		LOGGER.info(" Catch FlowNodeConfig Map Size : " + flowNodeConfigMap.size() + "###" + JSON.toJSONString(flowNodeConfigMap));
		
		return flowNodeConfigMap;
    }
    
    
    
    /**
     * 查询流程节点表
     * @return
     */
    public HashMap<String,Map<String,String>> getFlowNode(){
    	
    	HashMap<String,Map<String,String>> flowNodeMap = new HashMap<String,Map<String,String>>();
    	
    	String sql = " select fn.id,fn.previous_node,fn.flow_id,fn.node_name,fn.data_key,fn.seq_no,f.app_id,f.flow_name from biz_flow_node fn ,biz_flow f where fn.flow_id = f.id and f.flow_status = 1 ";
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql);
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
		    	long nodeId = ((Long)row.get("id")).longValue();
		    	long previousNode = ((Long)row.get("previous_node")).longValue();
		    	long flowId = ((Long)row.get("flow_id")).longValue();
		    	String nodeName = (String)row.get("node_name");
		    	String dataKey = (String)row.get("data_key");
		    	int seqNo = ((Integer)row.get("seq_no")).intValue();
		    	int flowAppId = ((Integer)row.get("app_id")).intValue();
		    	String flowName = (String)row.get("flow_name");
		    	
		    	HashMap<String,String> nodeMap = new HashMap<String,String>();
		    	nodeMap.put("nodeId",Long.toString(nodeId));
		    	nodeMap.put("previousNode",Long.toString(previousNode));
		    	nodeMap.put("flowId",Long.toString(flowId));
		    	nodeMap.put("nodeName",nodeName);
		    	nodeMap.put("dataKey",dataKey);
		    	nodeMap.put("seqNo",Integer.toString(seqNo));
		    	nodeMap.put("flowAppId",Integer.toString(flowAppId));
		    	nodeMap.put("flowName",flowName);
		    	
		    	String flowNodeMapKey = Long.toString(flowId) + "#" + Long.toString(nodeId);
		    	flowNodeMap.put(flowNodeMapKey , nodeMap);
		    }
		}
		
		LOGGER.info(" Catch flowNode Map Size : " + flowNodeMap.size() + "###" + JSON.toJSONString(flowNodeMap));
		
		return flowNodeMap;
    }
    
    
    /**
     * 根据nodeId查询节点信息表
     * @return
     */
    public HashMap<String,String> getNodeInfoByNodeId(String nodeId){
    	
    	HashMap<String,String> upstreamMap = new HashMap<String,String>();
    	
    	String sql = " select node_name,data_key,seq_no from biz_flow_node where id = ? ";
		Object[] paramsForSelect = new Object[] { Long.parseLong(nodeId) };
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
		    	upstreamMap.put("nodeId",nodeId);
		    	upstreamMap.put("nodeName",(String)row.get("node_name"));
		    	upstreamMap.put("dataKey",(String)row.get("data_key"));
		    	upstreamMap.put("seqNo",Integer.toString(((Integer)row.get("seq_no")).intValue()));
		    }
		}
		return upstreamMap;
    }
    
    
    /**
     * 通过应用ID查询应用名称,通过nodeId,flowId查询报警节点
     * @param flowAppId
     * @param nodeId
     * @param flowId
     * @return
     */
    public HashMap<String,String> getAppNameAndAlarmNodes(String flowAppId,String nodeId,String flowId){
    	
    	HashMap<String,String> hm = new HashMap<String,String>();
    	String flowAppName = "";
    	String alarmNodes = "";
    	
    	String sql1 = " select a_appname from ump_appserver where id = ? and a_status=? ";
		Object[] paramsForSelect1 = new Object[] { Integer.parseInt(flowAppId),BusinessFlowUtil.VALID };
		List<Map<String, Object>> tpRows1 = this.jdbcTemplate.queryForList(sql1,paramsForSelect1);
		if (tpRows1.size() > 0) {
		    for (Map<String, Object> row : tpRows1) {
		    	flowAppName = (String)row.get("a_appname");
		    }
		} 
		
		String sql2 = " select timeout_nodes from biz_flow_alarm_config where flow_id=? and node_id=? ";
		Object[] paramsForSelect2 = new Object[] { Long.parseLong(flowId),Long.parseLong(nodeId) };
		List<Map<String, Object>> tpRows2 = this.jdbcTemplate.queryForList(sql2,paramsForSelect2);
		if (tpRows2.size() > 0) {
		    for (Map<String, Object> row : tpRows2) {
		    	alarmNodes = (String)row.get("timeout_nodes");
		    }
		}
		
		if("".equals(alarmNodes)){
			alarmNodes = nodeId;
		}
		
		if(!"".equals(flowAppName)){
			hm.put("flowAppName", flowAppName);
			hm.put("alarmNodes", alarmNodes);
		}
		
		return hm;
    }
    
    
    
    
    /**
     * 查询报警信息表
     * @return
     */
    public List<String> getAllAlarmId(){
    	
    	List<String> alarmIdList = new ArrayList<String>();
    	try{
    		String sql = " select id from biz_flow_alarm_meg where is_alarmed= ? and is_combine = 0 order by id desc limit 0,100";
    		Object[] paramsForSelect = new Object[] { BusinessFlowUtil.ALARM_FLAG_READY };
    		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
    		String ids = "";
    		if (tpRows.size() > 0) {
    		    for (Map<String, Object> row : tpRows) {
    		    	alarmIdList.add(((Long)row.get("id")).toString());
    		    	ids = ids + ((Long)row.get("id")).toString() + "," ;
    		    }
    		   ids = ids.substring(0, ids.length()-1) ;
    		   String updateSql = " update biz_flow_alarm_meg set is_alarmed = 'SENDING' where id in ( " + ids + " )";
    		   this.jdbcTemplate.update(updateSql);
    		}
    	}catch(Exception e){
    		LOGGER.error(" Get All AlarmId from DB is Error!",e);
    	}
    	
		return alarmIdList;
    }


	public List<String> getAllFlowNodeHealthConfig() {
		List<String> alarmIdList = null;
    	try{
    		String sql = "select distinct concat(n.id,'|',n.seq_no,'|',n.flow_id) from biz_flow_node n left join biz_flow f on f.id = n.flow_id where f.flow_status = 1";
    		
    		alarmIdList = this.jdbcTemplate.query(sql, new RowMapper<String> (){

				@Override
				public String mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					return rs.getString(1);
				}});
    		
    	}catch(Exception e){
    		LOGGER.error("getAllFlowNodeHealthConfigIsError",e);
    	}
    	
		return alarmIdList;
	}
    
}