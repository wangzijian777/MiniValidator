package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Set;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.ThreadPoolManager;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;


public class BusinessFlowCombinedAlarmFiveTimer extends TimerTask {
    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessFlowCombinedAlarmFiveTimer.class);
    private ThreadPoolManager threadPoolManagerAT;
    public BusinessFlowCombinedAlarmFiveTimer() {
    	this.threadPoolManagerAT = new ThreadPoolManager(5);
    }
    
    /**
     * 时间频率：5分钟
     * 任务内容：flowId|nodeId|startTime|endTime
     * 任务开始时间：每5分钟第30秒
     */
    @Override
    public void run() {
	
    	CallerInfo callerInfo = null;
    	Calendar now = Calendar.getInstance();
    	long sendDataTimePoint = now.getTime().getTime();
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessFlowCombinedAlarmFiveTimer", false, true);
			Long startTime = sendDataTimePoint - TimeUnit.MINUTES.toMillis(5);
			Long endTime = sendDataTimePoint;
			SimpleDateFormat DATE_FORMAT_FULL = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Set<String> alarmInfoList = new BusinessFlowDBManager().getFlowNodeAlarmFiveConfig(DATE_FORMAT_FULL.format(startTime), DATE_FORMAT_FULL.format(endTime));
		    if(SwitchMasterSlave.sendDataStatus){
		    	if(alarmInfoList.size()>0){
		    		BusinessFlowCombinedObject bfc = new BusinessFlowCombinedObject();
		    		bfc.setData(alarmInfoList);
		    		threadPoolManagerAT.execute(sendDataByMQ(bfc));
		    	}
		    }
		} catch (Exception e) {
		    SwitchMasterSlave.scanDBStatus = false;
		    Profiler.functionError(callerInfo);
		    LOGGER.error("BusinessFlowCombinedAlarmFiveTimer Timer ERROR at :" + ToolBox.fomartTime(sendDataTimePoint),e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }

    
    /**
     * 调用MQ接口发送数据
     */
    private Runnable sendDataByMQ(final BusinessFlowCombinedObject task) {
    	return new Runnable() {
    		public void run() {
    			try {
    				if (task!=null && !"".equals(task)) {
    					SwitchMasterSlave.MQManager.sendObjectToMQ(BusinessFlowUtil.BUSINESS_FLOW_ALARM_COMBINED_TASK_QUEUE, task);
    					if(LOGGER.isDebugEnabled()) 
    						LOGGER.debug("BusinessFlowCombinedAlarmFiveTimer sendDataByMQ : " + task );
    				}
    			} catch (Exception e) {
    				LOGGER.error("BusinessFlowCombinedAlarmFiveTimer SendData ERROR: " + task, e);
    			}
    		}
    	};
    }
}
