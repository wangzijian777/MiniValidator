package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.util.Calendar;
import java.util.List;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.ThreadPoolManager;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;

/**
 * 发送业务流程监控报警任务
 * @date 2013-10-28
 * @author duliang 
 */ 
public class BusinessFlowAlarmTimer extends TimerTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessFlowAlarmTimer.class);
    private ThreadPoolManager threadPoolManagerAT;
    
    public BusinessFlowAlarmTimer() {
    	this.threadPoolManagerAT = new ThreadPoolManager(5);
    }

    
    /**
     * 时间频率：5秒
     * 任务内容：alarmId|taskTime
     * 任务开始时间：每分钟第0秒
     */
    @Override
    public void run() {
	
    	CallerInfo callerInfo = null;
		// 设置发送任务的时间点(任务时间为5秒的整数倍)
    	Calendar now = Calendar.getInstance();
		now.set(Calendar.MILLISECOND, 0);
    	long sendDataTimePoint = now.getTime().getTime();
    	
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessFlowAlarmTimer", false, true);
			List<String> alarmIdList = new BusinessFlowDBManager().getAllAlarmId();
		    if(SwitchMasterSlave.sendDataStatus){
			    	if(alarmIdList.size()>0){
			    		for(String alarmId : alarmIdList){
			    			if(alarmId!=null && !"".equals(alarmId)){
			    				String task = alarmId + "|" + Long.toString(sendDataTimePoint);
			    				threadPoolManagerAT.execute(sendDataByMQ(task));
			    			}
			    		}
			    	}
		    }
		} catch (Exception e) {
		    SwitchMasterSlave.scanDBStatus = false;
		    Profiler.functionError(callerInfo);
		    LOGGER.error("BusinessFlowAlarm Timer ERROR at :" + ToolBox.fomartTime(sendDataTimePoint),e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }

    
    /**
     * 调用MQ接口发送数据
     */
    private Runnable sendDataByMQ(final String task) {
    	return new Runnable() {
    		public void run() {
    			try {
    				if (task!=null && !"".equals(task)) {
    					SwitchMasterSlave.MQManager.sendDataToMQ(BusinessFlowUtil.BUSINESS_FLOW_ALARM_TASK_QUEUE, task);
    					
    					if(LOGGER.isDebugEnabled()) 
    						LOGGER.debug("BusinessFlowAlarm sendDataByMQ : " + task );
    				}
    			} catch (Exception e) {
    				LOGGER.error("BusinessFlowAlarm SendData ERROR: " + task, e);
    			}
    		}
    	};
    }

    
}
