package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.io.Serializable;
import java.util.HashMap;

public class BusinessFlowConfigInfo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String flowId;		//流程ID
	private String timeOut;	//超时时间
	private long taskTime;	//任务时间
	private HashMap<String,String> upstreamMap;		//上游节点信息(nodeId,nodeName,dataKey,seqNo)
	private HashMap<String,String> downstreamMap;		//下游节点信息(nodeId,nodeName,dataKey,seqNo)
	private String flowAppName;				//流程所属应用名称
	private String alarmNodes;			//需要发送报警的节点ID
	private String flowName;			//流程名称
	private String isCombined;
	
	public String getIsCombined() {
		return isCombined;
	}
	public void setIsCombined(String isCombined) {
		this.isCombined = isCombined;
	}
	public String getFlowId() {
		return flowId;
	}
	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}
	public String getTimeOut() {
		return timeOut;
	}
	public void setTimeOut(String timeOut) {
		this.timeOut = timeOut;
	}
	public long getTaskTime() {
		return taskTime;
	}
	public void setTaskTime(long taskTime) {
		this.taskTime = taskTime;
	}
	public HashMap<String, String> getUpstreamMap() {
		return upstreamMap;
	}
	public void setUpstreamMap(HashMap<String, String> upstreamMap) {
		this.upstreamMap = upstreamMap;
	}
	public HashMap<String, String> getDownstreamMap() {
		return downstreamMap;
	}
	public void setDownstreamMap(HashMap<String, String> downstreamMap) {
		this.downstreamMap = downstreamMap;
	}
	public String getFlowAppName() {
		return flowAppName;
	}
	public void setFlowAppName(String flowAppName) {
		this.flowAppName = flowAppName;
	}
	public String getAlarmNodes() {
		return alarmNodes;
	}
	public void setAlarmNodes(String alarmNodes) {
		this.alarmNodes = alarmNodes;
	}
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	
}