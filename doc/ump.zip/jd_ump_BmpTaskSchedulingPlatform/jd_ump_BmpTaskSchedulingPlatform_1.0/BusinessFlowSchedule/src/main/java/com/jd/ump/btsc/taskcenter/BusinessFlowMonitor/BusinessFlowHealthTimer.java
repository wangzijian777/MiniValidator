package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.util.Calendar;
import java.util.List;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.ThreadPoolManager;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;

public class BusinessFlowHealthTimer extends TimerTask{
	
	private final static Logger LOGGER = LoggerFactory.getLogger(BusinessFlowHealthTimer.class);
    
	private ThreadPoolManager threadPoolManagerAT;
    
    public BusinessFlowHealthTimer() {
    	this.threadPoolManagerAT = new ThreadPoolManager(5);
    }

	@Override
	public void run() {
		
		CallerInfo callerInfo = null;
		// 设置发送任务的时间点(任务时间为5秒的整数倍)
    	Calendar now = Calendar.getInstance();
		now.set(Calendar.MILLISECOND, 0);
		now.set(Calendar.SECOND, 0);
		now.add(Calendar.MINUTE, -1);
    	long sendDataTimePoint = now.getTime().getTime();
    	
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessFlowHealthTimer", false, true);
			List<String> flowHealthList = new BusinessFlowDBManager().getAllFlowNodeHealthConfig();
		    if(SwitchMasterSlave.sendDataStatus){
		    	if(flowHealthList.size()>0){
		    		for(String item : flowHealthList){
		    			if(item!=null && !"".equals(item)){
		    				String task = item + "|" + Long.toString(sendDataTimePoint);
		    				threadPoolManagerAT.execute(sendDataByMQ(task));
		    			}
		    		}
		    	}
		    }
		} catch (Exception e) {
		    SwitchMasterSlave.scanDBStatus = false;
		    Profiler.functionError(callerInfo);
		    LOGGER.error("BusinessFlowHealth Timer ERROR at :" + ToolBox.fomartTime(sendDataTimePoint),e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	/**
     * 调用MQ接口发送数据
     */
    private Runnable sendDataByMQ(final String task) {
    	return new Runnable() {
    		public void run() {
    			try {
    				if (task!=null && !"".equals(task)) {
    					SwitchMasterSlave.MQManager.sendDataToMQ(BusinessFlowUtil.BUSINESS_FLOW_HEALTH_TASK_QUEUE, task);
    					
    					if(LOGGER.isDebugEnabled()) 
    						LOGGER.debug("BusinessFlowHealth sendDataByMQ : " + task );
    				}
    			} catch (Exception e) {
    				LOGGER.error("BusinessFlowHealth SendData ERROR: " + task, e);
    			}
    		}
    	};
    }

}
