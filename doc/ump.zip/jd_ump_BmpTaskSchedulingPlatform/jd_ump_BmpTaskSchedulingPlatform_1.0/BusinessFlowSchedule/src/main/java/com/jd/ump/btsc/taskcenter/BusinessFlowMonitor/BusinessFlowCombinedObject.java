package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class BusinessFlowCombinedObject implements Serializable{

	private static final long serialVersionUID = 1L;
	Set<String> data = new HashSet<String>();
	
	public Set<String> getData() {
		return data;
	}
	public void setData(Set<String> data) {
		this.data = data;
	}
}
