package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.util.Timer;

import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.Source;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * 业务监控中心任务调度
 * 
 * @date 2013-10-28 
 * @author duliang
 */
public class BusinessFlowMonitorCenter implements Source {
 
	/**
	 * 业务流程监控任务调度入口
	 */
	public void open() {
		Profiler.registerJVMInfo("ump.BTSC.jvm");
		Profiler.InitHeartBeats("ump.BTSC.alive");
		openBusinessFlowAnalysisTimer();
		openBusinessFlowAlarmTimer();
		openBusinessFlowHealthTimer();
		openBusinessFlowCombinedAlarmFiveTimer();
		openBusinessFlowCombinedAlarmTenTimer();
		openBusinessFlowCombinedAlarmThirtyTimer();
	}
	
	
	/**
	 * 开启流程健康度定时器
	 * 超时判断频率：1分钟
	 * 首次下发任务时间为1分钟后启动的20秒
	 */
	public void openBusinessFlowHealthTimer() {
		Timer businessFlowHealthTimer = new Timer("businessFlowHealthTimer");
		businessFlowHealthTimer.scheduleAtFixedRate(new BusinessFlowHealthTimer(),
				BusinessFlowUtil.getNextMinuteForInitial(0,30),BusinessFlowUtil.BUSINESS_FLOW_HEALTH_TIMEPERIOD);
	}

	/**
	 * 开启超时判断定时器
	 * 超时判断频率：1分钟
	 * 首次下发任务时间为启动一分钟后的40秒
	 */
	public void openBusinessFlowAnalysisTimer(){
		Timer businessFlowAnalysisTimer = new Timer("businessFlowAnalysisTimer");
		businessFlowAnalysisTimer.scheduleAtFixedRate(new BusinessFlowAnalysisTimer(),
				BusinessFlowUtil.getNextMinuteForInitial(0,20),BusinessFlowUtil.BUSINESS_FLOW_ANALYSIS_TIMEPERIOD);
	}
	
	
	/**
	 * 开启报警定时器
	 * 报警任务定时器：5秒
	 * 首次下发任务时间为启动一分钟后的00秒
	 */
	public void openBusinessFlowAlarmTimer(){
		Timer businessFlowAlarmTimer = new Timer("businessFlowAlarmTimer");
		businessFlowAlarmTimer.scheduleAtFixedRate(new BusinessFlowAlarmTimer(),
				BusinessFlowUtil.getNextMinuteForInitial(1,0),BusinessFlowUtil.BUSINESS_FLOW_ALARM_TIMEPERIOD);
	}
	
	/**
	 * 开启合并报警5分钟定时器
	 * 报警任务定时器：5分钟
	 * 首次下发任务时间为启动的30秒
	 */
	public void openBusinessFlowCombinedAlarmFiveTimer(){
		Timer businessFlowCombinedAlarmFiveTimer = new Timer("businessFlowCombinedAlarmFiveTimer");
		businessFlowCombinedAlarmFiveTimer.scheduleAtFixedRate(new BusinessFlowCombinedAlarmFiveTimer(),
				BusinessFlowUtil.getNextMinuteForInitial(0,30),BusinessFlowUtil.BUSINESS_FLOW_COMBINED_FIVE_ALARM_TIMEPERIOD);
	}
	
	/**
	 * 开启合并报警10分钟定时器
	 * 报警任务定时器：10分钟
	 * 首次下发任务时间为启动的30秒
	 */
	public void openBusinessFlowCombinedAlarmTenTimer(){
		Timer businessFlowCombinedAlarmTenTimer = new Timer("businessFlowCombinedAlarmTenTimer");
		businessFlowCombinedAlarmTenTimer.scheduleAtFixedRate(new BusinessFlowCombinedAlarmTenTimer(),
				BusinessFlowUtil.getNextMinuteForInitial(0,30),BusinessFlowUtil.BUSINESS_FLOW_COMBINED_TEN_ALARM_TIMEPERIOD);
	}
	
	/**
	 * 开启合并报警30分钟定时器
	 * 报警任务定时器：30分钟
	 * 首次下发任务时间为启动的30秒
	 */
	public void openBusinessFlowCombinedAlarmThirtyTimer(){
		Timer businessFlowCombinedAlarmThirtyTimer = new Timer("businessFlowCombinedAlarmThirtyTimer");
		businessFlowCombinedAlarmThirtyTimer.scheduleAtFixedRate(new BusinessFlowCombinedAlarmThirtyTimer(),
				BusinessFlowUtil.getNextMinuteForInitial(0,30),BusinessFlowUtil.BUSINESS_FLOW_COMBINED_THIRTY_ALARM_TIMEPERIOD);
	}
	
	public void close() {}

	public void connect(Sink arg0) {}

	public boolean isBlocking() {
		return false;
	}

}
