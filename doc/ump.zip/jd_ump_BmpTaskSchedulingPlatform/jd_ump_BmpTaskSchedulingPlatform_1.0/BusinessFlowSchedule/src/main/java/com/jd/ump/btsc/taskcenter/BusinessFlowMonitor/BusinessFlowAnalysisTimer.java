package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.util.Calendar;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.ThreadPoolManager;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;

/**
 * 发送固定频率的业务流程监控任务
 * 
 * @date 2013-10-28
 * @author duliang 
 */
public class BusinessFlowAnalysisTimer extends TimerTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessFlowAnalysisTimer.class);
    private ThreadPoolManager threadPoolManagerBFAT;
    
    public BusinessFlowAnalysisTimer() {
    	this.threadPoolManagerBFAT = new ThreadPoolManager(5);
    }

    
    /**
     * 时间频率：1分钟
     * 数据格式：BusinessFlowConfigInfo
     * 任务下发时间点：每分钟第40秒
     */
    @Override
    public void run() {
	
    	CallerInfo callerInfo = null;
		// 设置发送任务的时间点(任务时间为当前的整分钟点)
    	Calendar now = Calendar.getInstance();
    	now.set(Calendar.SECOND, 0);
		now.set(Calendar.MILLISECOND, 0);
    	long sendDataTimePoint = now.getTime().getTime();
    	
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessFlowAnalysisTimer", false, true);
			
		    if(SwitchMasterSlave.sendDataStatus){
		    	synchronized (LoadBusinessFlowCache.cacheBusinessFlowList) {
			    	if(LoadBusinessFlowCache.cacheBusinessFlowList.size()>0){
			    		for(BusinessFlowConfigInfo businessFlowConfigInfo : LoadBusinessFlowCache.cacheBusinessFlowList){
			    			if(businessFlowConfigInfo!=null){
			    				businessFlowConfigInfo.setTaskTime(sendDataTimePoint);
			    				threadPoolManagerBFAT.execute(sendDataByMQ(businessFlowConfigInfo));
			    			}
			    		}
			    	}
				}
		    }
		} catch (Exception e) {
		    SwitchMasterSlave.scanDBStatus = false;
		    Profiler.functionError(callerInfo);
		    LOGGER.error("BusinessFlowAnalysis Timer ERROR at :" + ToolBox.fomartTime(sendDataTimePoint),e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }

    
    /**
     * 调用MQ接口发送数据
     */
    private Runnable sendDataByMQ(final BusinessFlowConfigInfo businessFlowConfigInfo) {
    	return new Runnable() {
    		public void run() {
    			try {
    				if (businessFlowConfigInfo!=null) {
    					SwitchMasterSlave.MQManager.sendObjectToMQ(BusinessFlowUtil.BUSINESS_FLOW_ANALYSIS_TASK_QUEUE, businessFlowConfigInfo);
    					
    					if(LOGGER.isDebugEnabled()) {
    						LOGGER.debug("BusinessFlowAnalysis sendDataByMQ : " + JSON.toJSON(businessFlowConfigInfo));
    					} 
    						
    				}
    			} catch (Exception e) {
    				LOGGER.error("BusinessFlowAnalysis SendData ERROR: " + businessFlowConfigInfo.toString(), e);
    			}
    		}
    	};
    }

    
}
