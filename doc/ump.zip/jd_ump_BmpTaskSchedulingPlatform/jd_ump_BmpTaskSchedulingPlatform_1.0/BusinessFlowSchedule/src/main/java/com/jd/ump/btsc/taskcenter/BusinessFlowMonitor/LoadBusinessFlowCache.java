package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.source.TimerSource;
import com.jd.ump.tsc.common.ToolBox;

/**
 * 此任务单独运行，定时缓存业务流程监控任务
 * 
 * @author duliang
 * @date 2013-10-22 
 */
public class LoadBusinessFlowCache extends TimerSource {

	private final static Logger LOGGER = LoggerFactory.getLogger(LoadBusinessFlowCache.class);
	public static List<BusinessFlowConfigInfo> cacheBusinessFlowList = new ArrayList< BusinessFlowConfigInfo>();

	/**
	 * 程序入口
	 */
	protected void doTimerTask(Sink sink) {
		cacheBusinessFlowInfo();
	}

	/**
	 * 把业务流程监控的数据放入缓存
	 * 时间频率：5分钟
	 * 缓存时间：启动后立即缓存
	 */
	public void cacheBusinessFlowInfo() {
		try {
			
			List<BusinessFlowConfigInfo> tempList = new BusinessFlowDBManager().getBusinessFlowInfoFromDB();
			synchronized (cacheBusinessFlowList) {
				cacheBusinessFlowList.clear();
				if (tempList != null && tempList.size()>0) {
					cacheBusinessFlowList.addAll(tempList);
				}
			}

			LOGGER.info("Cache BusinessFlow |" + ToolBox.getNowTime() + " | size: " + cacheBusinessFlowList.size() + "");
			 
		} catch (Exception e) {
			LOGGER.error("Cache BusinessFlow is ERROR!!", e);
		}
	}
	
}
