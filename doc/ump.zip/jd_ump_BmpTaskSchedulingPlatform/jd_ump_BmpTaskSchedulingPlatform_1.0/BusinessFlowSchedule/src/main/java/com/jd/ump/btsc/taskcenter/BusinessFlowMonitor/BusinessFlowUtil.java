package com.jd.ump.btsc.taskcenter.BusinessFlowMonitor;

import java.util.Calendar;
import java.util.Date;

public class BusinessFlowUtil {
	
	
	
	/**
     * 业务流程健康度检测时间频率
     */
    public static final long BUSINESS_FLOW_HEALTH_TIMEPERIOD = 60000L;
	
	/**
     * 业务流程监控超时判断时间频率
     */
    public static final long BUSINESS_FLOW_ANALYSIS_TIMEPERIOD = 60000L;
     
    /**
     * 业务流程监控报警任务时间频率
     */
    public static final long BUSINESS_FLOW_ALARM_TIMEPERIOD = 5000L;
    
    /**
     * 业务流程监控合并5分钟报警任务时间频率
     */
    public static final long BUSINESS_FLOW_COMBINED_FIVE_ALARM_TIMEPERIOD = 300000L;
    /**
     * 业务流程监控合并10分钟报警任务时间频率
     */
    public static final long BUSINESS_FLOW_COMBINED_TEN_ALARM_TIMEPERIOD = 600000L;
    /**
     * 业务流程监控合并30分钟报警任务时间频率
     */
    public static final long BUSINESS_FLOW_COMBINED_THIRTY_ALARM_TIMEPERIOD = 1800000L;
    
    /**
     * 业务流程监控任务调度的队列名称
     */
    public static final String BUSINESS_FLOW_ANALYSIS_TASK_QUEUE = "BusinessFlowAnalysisQueue";
    public static final String BUSINESS_FLOW_ALARM_TASK_QUEUE = "BizAlarmTaskQueue";
    public static final String BUSINESS_FLOW_HEALTH_TASK_QUEUE = "BizFlowHealthTaskQueue";
    public static final String BUSINESS_FLOW_ALARM_COMBINED_TASK_QUEUE = "BizAlarmCombinedTaskQueue";
    
    public static final String KEY_WORD_TIMEOUT_ALARM = "nodeNo_timeout_alarm";
    public static final String KEY_WORD_TIMEOUT = "nodeNo_timeout";
    public static final String VALID = "1";
    public static final String KEY_WORD_HEALTH_CYCLE = "nodeNo_health_cycle";
    public static final String KEY_WORD_ERROR_COUNT = "nodeNo_error_count";
    public static final String KEY_WORD_TIMEOUT_COUNT = "nodeNo_timeout_count";
    
    
    /**
     * 报警标志
     */
    public static final String ALARM_FLAG_READY = "READY";
    public static final String ALARM_FLAG_FAIL = "FAIL";
    
    /**
     * 获得当前时间后N分钟的第M秒的整点时间,并且毫秒数为0，返回date
     * @param minute
     * @param second
     * @return
     */
    public static Date getNextMinuteForInitial(int minute,int second) {
		Calendar now = Calendar.getInstance();
		now.add(Calendar.MINUTE, minute);
		now.set(Calendar.SECOND, second);
		now.set(Calendar.MILLISECOND, 0);
		Date date = now.getTime();
		return date;
    }
}
