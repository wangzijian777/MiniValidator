package com.jd.ump.tsc.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public final class CommonUtil 
{
	/**
	 * 模块名字：BTSC
	 */
	public static final String APPLICATION_NAME = "BTSC";
	
	public static final String JSON_DATA_FORMAT = "yyyyMMddHHmmssSSS";
	
	/**
	 * BusinessAnalusisSchedule模块
	 */
	public static final String MODULE_BUSINESSANALYSISSCHEDULE = "BusinessAnalusisSchedule";
	
	public static String makeErrorHead(String moduleName,String className)
	{
		return "["+ APPLICATION_NAME + "#" + moduleName + "#" + className +"]";
	}
	
	public static String makeWarnHead(String moduleName,String className,String method)
	{
		return "[WARN]["+moduleName+"]["+className+"]["+method+"]";
	}
	
	public static String makeInfoHead(String moduleName,String className,String method)
	{
		return "[INFO]["+moduleName+"]["+className+"]["+method+"]";
	}
	
	public static  long dateTimeParse(String date) throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat(JSON_DATA_FORMAT);
		Date sourceDate = sdf.parse(date);
		return sourceDate.getTime();
	}
	
	/**
     * 获得N分钟的整数倍的下一个时间点,并且秒数为参数，毫秒数为0,返回date
     * @param multipleMinute
     * @return
     */
    public static Date getTimePointForMultipleMinute(int multipleMinute,int second) {
		Calendar now = Calendar.getInstance();
		now.set(Calendar.SECOND, second);
		now.set(Calendar.MILLISECOND, 0);
	
		int mimute = now.get(12);
		Date date = null;
		if (mimute % multipleMinute == 0) {
		    date = now.getTime();
		} else {
		    int newMinute = mimute + (multipleMinute - mimute % multipleMinute);
		    now.set(Calendar.MINUTE, newMinute);
		    date = now.getTime();
		}
	
		return date;
    }
	
}
