package com.jd.ump.tsc.taskcenter.BusinessMonitor;

import java.util.Calendar;
import java.util.List;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.BusinessAnalysisUtil;
import com.jd.ump.tsc.common.CommonUtil;
import com.jd.ump.tsc.common.ThreadPoolManager;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;

/**
 * 发送每小时访问一次的业务监控任务，任务内容为配置信息对象
 * 
 * @date 2012-10-11
 * @author duliang
 */
public class BusinessPerHourTimer extends TimerTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessPerHourTimer.class);
    private ThreadPoolManager threadPoolManagerBMPH;
    
    private final static String CLASS_NAME = "BusinessPerHourTimer";
    
    public BusinessPerHourTimer() {
    	this.threadPoolManagerBMPH = new ThreadPoolManager(50);
    }

    
    /**
     * 开始运行每小时访问一次的定时器,调用MQ接口发送
     * 数据格式：BusinessConfigInfo
     */
    @Override
    public void run() {
	
    	CallerInfo callerInfo = null;
		// 设置发送任务的时间点
    	Calendar now = Calendar.getInstance();
    	now.set(Calendar.SECOND, 0);
		now.set(Calendar.MILLISECOND, 0);
    	int nowMinute = now.get(Calendar.MINUTE);
    	long sendDataTimePoint = now.getTime().getTime();
    	
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessPerHourTimer", false, true);
			
		    if(SwitchMasterSlave.sendDataStatus){
		    	synchronized (LoadBusinessCache.cacheBusinessPerHourMap) {
				    if (LoadBusinessCache.cacheBusinessPerHourMap.size() > 0) {
						
				    	if(LoadBusinessCache.cacheBusinessPerHourMap.containsKey(String.valueOf(nowMinute))){
				    		List<BusinessConfigInfo> businessConfigInfoList = LoadBusinessCache.cacheBusinessPerHourMap.get(String.valueOf(nowMinute));
				    		if(businessConfigInfoList.size()>0){
				    			for (BusinessConfigInfo configInfo : businessConfigInfoList) {
									configInfo.setSendDataTimePoint(sendDataTimePoint);
									threadPoolManagerBMPH.execute(sendDataByMQ(configInfo));
								}
				    		}
				    	}
				    }
				}
		    }
		   
		} catch (Exception e) {
		    SwitchMasterSlave.scanDBStatus = false;
		    Profiler.functionError(callerInfo);
		    LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME)+ "BusinessPerHour Timer ERROR at :" + ToolBox.fomartTime(sendDataTimePoint),e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }

    
    /**
     * 调用MQ接口发送数据
     */
    private Runnable sendDataByMQ(final BusinessConfigInfo sendData) {
    	return new Runnable() {
    		public void run() {
    			try {
    				if (sendData!=null) {
    					SwitchMasterSlave.MQManager.sendObjectToMQ(BusinessAnalysisUtil.Business_Day_Hour_Minute_Queue,sendData);
    					
    					if(LOGGER.isInfoEnabled()) 
    						LOGGER.info(CommonUtil.makeInfoHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME, "sendDataByMQ") + "BusinessPerHourTimer : " + sendData.getAccessKey());
    				}
    			} catch (Exception e) {
    				LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "SendData ERROR: " + Integer.toString(sendData.getId()), e);
    			}
    		}
    	};
    }

    
}
