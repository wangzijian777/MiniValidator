package com.jd.ump.tsc.taskcenter.BusinessMonitor;

import java.util.Calendar;
import java.util.Map;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.BusinessAnalysisUtil;
import com.jd.ump.tsc.common.CommonUtil;
import com.jd.ump.tsc.common.ThreadPoolManager;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;

/**
 * 发送固定频率分析的业务监控任务，任务内容为配置信息字符串
 * 
 * @date 2012-10-16
 * @author duliang
 */
public class BusinessAlarmAnalysisTimer extends TimerTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessAlarmAnalysisTimer.class);
    private String alarmAnalysisTimePeriod;
    private ThreadPoolManager threadPoolManagerBAAT;
    
    private final static String CLASS_NAME = "BusinessAlarmAnalysisTimer";
    
    public BusinessAlarmAnalysisTimer(String alarmAnalysisTimePeriod) {
    	this.alarmAnalysisTimePeriod = alarmAnalysisTimePeriod;
    	this.threadPoolManagerBAAT = new ThreadPoolManager(150);
    }

    
    /**
     * 开始运行固定频率访问一次的定时器,调用MQ接口发送
     * 数据格式：bus_key|bus_alm_anlyrate|bus_log_sumrate|bus_log_anlyway|bus_almanlylog_mgway|time
     */
    @Override
    public void run() {
	
    	CallerInfo callerInfo = null;
		// 设置发送任务的时间点(任务时间为一分钟前的时间点)
    	Calendar now = Calendar.getInstance();
    	now.add(Calendar.MINUTE, -1);
    	now.set(Calendar.SECOND, 0);
		now.set(Calendar.MILLISECOND, 0);
    	long sendDataTimePoint = now.getTime().getTime();
    	
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessAlarmAnalysisTimer", false, true);
			
		    if(SwitchMasterSlave.sendDataStatus){
		    	synchronized (LoadBusinessCache.cacheBusinessAlarmAnalysisMap) {
						
			    	if(LoadBusinessCache.cacheBusinessAlarmAnalysisMap.containsKey(alarmAnalysisTimePeriod)){
			    		Map<String, String> map = LoadBusinessCache.cacheBusinessAlarmAnalysisMap.get(alarmAnalysisTimePeriod);
			    		for (Map.Entry<String, String> entry : map.entrySet()) {
			    			 String sendData = entry.getValue() + Long.toString(sendDataTimePoint);
							 threadPoolManagerBAAT.execute(sendDataByMQ(sendData));
			    		}
			    	}
				}
		    }
		   
		} catch (Exception e) {
		    SwitchMasterSlave.scanDBStatus = false;
		    Profiler.functionError(callerInfo);
		    LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "BusinessAlarmAnalysis Timer ERROR at :" + ToolBox.fomartTime(sendDataTimePoint),e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }

    
    /**
     * 调用MQ接口发送数据
     */
    private Runnable sendDataByMQ(final String sendData) {
    	return new Runnable() {
    		public void run() {
    			CallerInfo callerInfo = null;
    			try {
    				callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessAlarmAnalysisTimer.sendDataByMQ", false, true);
    				if (sendData!=null) {
    					SwitchMasterSlave.MQManager.sendDataToMQ(BusinessAnalysisUtil.Business_DataAnalysis_Queue,sendData);
    					if(LOGGER.isDebugEnabled()){
    						LOGGER.debug("BusinessAlarmAnalysisTimer : " + sendData);
    					}
    				}
    			} catch (Exception e) {
    				LOGGER.error("BusinessAlarmAnalysisTimer SendData ERROR: " + sendData, e);
    				Profiler.functionError(callerInfo);
    			}finally {
    				Profiler.registerInfoEnd(callerInfo);
    			}
    		}
    	};
    }

    
}
