package com.jd.ump.tsc.taskcenter.BusinessMonitor;

import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.BusinessAnalysisUtil;
import com.jd.ump.tsc.common.CommonUtil;
import com.jd.ump.tsc.common.ThreadPoolManager;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.db.LoadBusinessCacheManager;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;

/**
 * 执行每半小时一次的删除KEY的任务
 * 
 * @date 2012-10-31
 * @author duliang
 */
public class BusinessDeleteKeyTimer extends TimerTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessDeleteKeyTimer.class);
    private ThreadPoolManager threadPoolManagerBDKT;
    
    private final static String CLASS_NAME = "BusinessDeleteKeyTimer";
    
    public BusinessDeleteKeyTimer() {
    	this.threadPoolManagerBDKT = new ThreadPoolManager(5);
    }

    
    /**
     * 执行1小时一次的删除KEY的任务,调用MQ接口发送
     * 数据格式：taskKey|time
     */
    @Override
    public void run() {
	
    	CallerInfo callerInfo = null;
		// 设置发送任务的时间点为0秒0毫秒
    	Calendar now = Calendar.getInstance();
    	now.set(Calendar.SECOND, 0);
		now.set(Calendar.MILLISECOND, 0);
    	long sendDataTimePoint = now.getTime().getTime();
    	
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessDeleteKeyTimer", false, true);
			
		    if(SwitchMasterSlave.sendDataStatus){
						
		    	HashMap<String,String> cacheBusinessDeleteKeyMap = new HashMap<String, String>();
		    	cacheBusinessDeleteKeyMap = new LoadBusinessCacheManager().getDeleteKeyFromDB();
		    		if (cacheBusinessDeleteKeyMap.size() > 0) {
		    			Collection<String> c = cacheBusinessDeleteKeyMap.values();
						Iterator<String> it = c.iterator();
						for (; it.hasNext();) {
						    String sendData = it.next().toString() + Long.toString(sendDataTimePoint);
						    threadPoolManagerBDKT.execute(sendDataByMQ(sendData));
						}
			    	}
		    }
		   
		} catch (Exception e) {
		    SwitchMasterSlave.scanDBStatus = false;
		    Profiler.functionError(callerInfo);
		    LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "BusinessDeleteKey Timer ERROR at :" + ToolBox.fomartTime(sendDataTimePoint),e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }

    
    /**
     * 调用MQ接口发送数据
     */
    private Runnable sendDataByMQ(final String sendData) {
    	return new Runnable() {
    		public void run() {
    			try {
    				if (sendData!=null) {
    					SwitchMasterSlave.MQManager.sendDataToMQ(BusinessAnalysisUtil.Business_DeleteKey_Queue,sendData);
    					
    					if(LOGGER.isInfoEnabled()) 
    						LOGGER.info(CommonUtil.makeInfoHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME, "sendDataByMQ") + "BusinessDeleteKey : " + sendData );
    				}
    			} catch (Exception e) {
    				LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "SendData ERROR: " + sendData, e);
    			}
    		}
    	};
    }

    
}
