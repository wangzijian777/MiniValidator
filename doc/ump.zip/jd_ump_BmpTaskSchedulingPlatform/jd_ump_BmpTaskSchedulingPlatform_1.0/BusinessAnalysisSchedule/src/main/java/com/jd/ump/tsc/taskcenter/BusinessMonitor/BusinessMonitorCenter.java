package com.jd.ump.tsc.taskcenter.BusinessMonitor;

import java.util.Timer;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.Source;
import com.jd.ump.tsc.common.BusinessAnalysisUtil;
import com.jd.ump.tsc.common.CommonUtil;
import com.jd.ump.tsc.common.ToolBox;

/**
 * 业务监控中心任务调度
 * 
 * @date 2012-10-10
 * @author duliang
 */
public class BusinessMonitorCenter implements Source {

	/**
	 * 业务监控中心任务调度入口
	 */
	public void open() {
		openBusinessPerDayTimer();
		openBusinessPerHourTimer();
		openBusinessPerMinuteTimer();
		openBusinessAlarmAnalysisTimer();
		openBusinessCalculateHistoryTimer();
		openBusinessDeleteKeyTimer();
	}
	
	/**
	 * 开启每天访问一次的定时器
	 * 时间频率为1分钟
	 */
	public void openBusinessPerDayTimer(){
		Timer businessPerDayTimer = new Timer("BusinessPerDayTimer");
		businessPerDayTimer.scheduleAtFixedRate(new BusinessPerDayTimer(),
				ToolBox.getNextMinuteForInitial(3),BusinessAnalysisUtil.BUSINESS_TIMEPERIOD_ONE_MINUTE);
	}
	
	
	/**
	 * 开启每小时访问一次的定时器
	 * 时间频率为1分钟
	 */
	public void openBusinessPerHourTimer(){
		Timer businessPerHourTimer = new Timer("BusinessPerHourTimer");
		businessPerHourTimer.scheduleAtFixedRate(new BusinessPerHourTimer(),
				ToolBox.getNextMinuteForInitial(3),BusinessAnalysisUtil.BUSINESS_TIMEPERIOD_ONE_MINUTE);
	}
	
	
	
	/**
	 * 开启固定频率分钟访问一次的定时器
	 * 时间频率为3、5、10、15、30分钟
	 */
	public void openBusinessPerMinuteTimer(){
		
		for (int i = 0; i < LoadBusinessCache.bmpPingTimePeriodArray.length; i++) {
			
			String fixedFrequencyMinute = LoadBusinessCache.bmpPingTimePeriodArray[i];
			
		    Timer businessPerMinuteTimer = new Timer("BusinessPerMinuteTimer" +  fixedFrequencyMinute);
		    
		    long pingTimePeriod = 60000L * Integer.parseInt(fixedFrequencyMinute);
		    businessPerMinuteTimer.scheduleAtFixedRate(new BusinessPerMinuteTimer(fixedFrequencyMinute), 
		    		ToolBox.getTimePointForMultipleMinute(5),pingTimePeriod);
		}
		
	}
	
	
	/**
	 * 开启固定频率分析一次业务数据的定时器
	 * 时间频率为1,5,10,20分钟
	 */
	public void openBusinessAlarmAnalysisTimer(){
		
		for (int i = 0; i < LoadBusinessCache.bmpAlarmAnalysisPeriodArray.length; i++) {
			
			String fixedFrequencyMinute = LoadBusinessCache.bmpAlarmAnalysisPeriodArray[i];
			
		    Timer businessAnalysisTimer = new Timer("BusinessAlarmAnalysisTimer" +  fixedFrequencyMinute);
		    
		    long analysisTimePeriod = 60000L * Integer.parseInt(fixedFrequencyMinute);
		    businessAnalysisTimer.scheduleAtFixedRate(new BusinessAlarmAnalysisTimer(fixedFrequencyMinute), 
		    		CommonUtil.getTimePointForMultipleMinute(Integer.parseInt(fixedFrequencyMinute),30),analysisTimePeriod);
		}
		
	}
	
	
	/**
	 * 开启固定频率计算同比数据的定时器(每天的0点05分运行)
	 * 时间频率为24小时
	 */
	public void openBusinessCalculateHistoryTimer(){
		Timer businessCalculateHistoryTimer = new Timer("BusinessCalculateHistoryTimer");
		businessCalculateHistoryTimer.scheduleAtFixedRate(new BusinessCalculateHistoryTimer(),
				ToolBox.getTimePointForPerDayFixedHourAndMinute(0,5),BusinessAnalysisUtil.DAY_TIMEPERIOD);
	}
	
	
	/**
	 * 开启每1小时执行一次删除KEY任务的定时器
	 * 时间频率为60分钟
	 */
	public void openBusinessDeleteKeyTimer(){
		Timer businessDeleteKeyTimer = new Timer("BusinessDeleteKeyTimer");
		businessDeleteKeyTimer.scheduleAtFixedRate(new BusinessDeleteKeyTimer(),
				ToolBox.getNextMinuteForInitial(5),BusinessAnalysisUtil.KEYDELETE_TASK_TIMEPERIOD);
	}
	
	

	public void close() {}

	public void connect(Sink arg0) {}

	public boolean isBlocking() {
		return false;
	}

}
