package com.jd.ump.tsc.taskcenter.BusinessMonitor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.BusinessAnalysisUtil;
import com.jd.ump.tsc.common.CommonUtil;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.db.LoadBusinessCacheManager;
import com.jd.mas.bootstrap.Sink;
import com.jd.mas.bootstrap.source.TimerSource;

/**
 * 此任务单独运行，定时缓存业务监控中心主动访问需要的信息
 * 
 * @author duliang
 * @date 2012-10-10
 */
public class LoadBusinessCache extends TimerSource {

	private final static Logger LOGGER = LoggerFactory.getLogger(LoadBusinessCache.class);
	public static HashMap<String, List<BusinessConfigInfo>> cacheBusinessPerDayMap = new HashMap<String, List<BusinessConfigInfo>>();
	public static HashMap<String, List<BusinessConfigInfo>> cacheBusinessPerHourMap = new HashMap<String, List<BusinessConfigInfo>>();
	public static HashMap<String, List<BusinessConfigInfo>> cacheBusinessPerMinuteMap = new HashMap<String, List<BusinessConfigInfo>>();
	public static HashMap<String, Map<String, String>> cacheBusinessAlarmAnalysisMap = new HashMap<String, Map<String, String>>();
	public static HashMap<String,String> cacheBusinessCalculateHistoryDataMap = new HashMap<String, String>();
	
	
	private final static String CLASS_NAME = "LoadBusinessCache";
	
	public static String[] bmpPingTimePeriodArray = BusinessAnalysisUtil.BUS_MINUTE_FIXED_FREQUENCY.split(",");
	public static String[] bmpAlarmAnalysisPeriodArray = BusinessAnalysisUtil.BUS_ALARM_ANALYSIS_FREQUENCY.split(",");
	
	
	/**
	 * 程序入口
	 */
	protected void doTimerTask(Sink sink) {
		cacheBusinessPerDayInfo();
		cacheBusinessPerHourInfo();
		cacheBusinessPerMinuteInfo();
		cacheBusinessAlarmAnalysisInfo();
		cacheCalculateHistoryData();
	}

	
	/**
	 * 把每天访问一次的数据放入缓存
	 */
	public void cacheBusinessPerDayInfo() {
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.cacheBusinessPerDayInfo", false, true);
			synchronized (cacheBusinessPerDayMap) {
				if (cacheBusinessPerDayMap.size() > 0) {
					cacheBusinessPerDayMap.clear();
				}
				new LoadBusinessCacheManager().getBusinessPerDayInfoFromDB();
			}
			LOGGER.info(CommonUtil.makeInfoHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME, "cacheBusinessPerDayInfo") + "Cache BusinessPerDay |" + ToolBox.getNowTime() + " | size: " + cacheBusinessPerDayMap.size() + "");
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "Catch BusinessPerDay is ERROR!!", e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	
	
	/**
	 * 把每小时访问一次的数据放入缓存
	 */
	public void cacheBusinessPerHourInfo() {
		CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.cacheBusinessPerHourInfo", false, true);
			synchronized (cacheBusinessPerHourMap) {
				if (cacheBusinessPerHourMap.size() > 0) {
					cacheBusinessPerHourMap.clear();
				}
				new LoadBusinessCacheManager().getBusinessPerHourInfoFromDB();
			}
			LOGGER.info(CommonUtil.makeInfoHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME, "cacheBusinessPerHourInfo") + "Cache BusinessPerHour |" + ToolBox.getNowTime() + " | size: " + cacheBusinessPerHourMap.size() + "");
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "Catch BusinessPerHour is ERROR!!", e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
	}
	
	
	/**
     * 把按照一定频率分钟访问一次的数据放入缓存
     */
    public void cacheBusinessPerMinuteInfo() {
    	CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.cacheBusinessPerMinuteInfo", false, true);
		    synchronized (cacheBusinessPerMinuteMap) {
				if (cacheBusinessPerMinuteMap.size() > 0) {
					cacheBusinessPerMinuteMap.clear();
				}
		
				if (bmpPingTimePeriodArray.length > 0) {
				    new LoadBusinessCacheManager().getBusinessPerMinuteInfoFromDB(bmpPingTimePeriodArray);
				}
		    }
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
		    LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME)+ "Catch BusinessPerMinute is ERROR!!", e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }
	

    
    /**
     * 把按照一定频率分析业务数据的任务内容放入缓存
     */
    public void cacheBusinessAlarmAnalysisInfo() {
    	CallerInfo callerInfo = null;
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.cacheBusinessAlarmAnalysisInfo", false, true);
		    synchronized (cacheBusinessAlarmAnalysisMap) {
				if (cacheBusinessAlarmAnalysisMap.size() > 0) {
					cacheBusinessAlarmAnalysisMap.clear();
				}
		
				if (bmpAlarmAnalysisPeriodArray.length > 0) {
				    new LoadBusinessCacheManager().getBusinessAlarmAnalysisInfoFromDB(bmpAlarmAnalysisPeriodArray);
				}
		    }
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
		    LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "Catch BusinessAlarmAnalysis is ERROR!!", e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }
    
    
    /**
     * 缓存计算同比数据的任务
     */
    public void cacheCalculateHistoryData() {
    	CallerInfo callerInfo = null;
    	try {
    		callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.cacheCalculateHistoryData", false, true);
			synchronized (cacheBusinessCalculateHistoryDataMap) {
				if (cacheBusinessCalculateHistoryDataMap.size() > 0) {
					cacheBusinessCalculateHistoryDataMap.clear();
				}
				new LoadBusinessCacheManager().getCalculateHistoryDataFromDB();
			}
			LOGGER.info(CommonUtil.makeInfoHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME, "cacheCalculateHistoryData") + "Cache CalculateHistoryData |" + ToolBox.getNowTime() + " | size: " + cacheBusinessCalculateHistoryDataMap.size() + "");
		} catch (Exception e) {
			Profiler.functionError(callerInfo);
			LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "Catch CalculateHistoryData is ERROR!!", e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }
    
    
}
