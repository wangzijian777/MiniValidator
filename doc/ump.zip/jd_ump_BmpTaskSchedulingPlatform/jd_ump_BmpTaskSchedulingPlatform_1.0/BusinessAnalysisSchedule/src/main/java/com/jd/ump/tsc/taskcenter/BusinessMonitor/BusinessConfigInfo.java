package com.jd.ump.tsc.taskcenter.BusinessMonitor;

import java.io.Serializable;

public class BusinessConfigInfo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String accessKey;
	private int callType;	//接口类型
	private String url;		//接口地址
	private String method;	//WSDL的方法名称或者REST中POST方式的参数
	private int requestType;//REST方式中GET或者POST方式请求
	private int timeout;	//超时时间
	private boolean callStatus;		//访问成功标志
	private String result;		//访问结果
	private String message;		//访问信息
	private long sendDataTimePoint;		//任务时间
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	public int getCallType() {
		return callType;
	}
	public void setCallType(int callType) {
		this.callType = callType;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public int getTimeout() {
		return timeout;
	}
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}
	public boolean isCallStatus() {
		return callStatus;
	}
	public void setCallStatus(boolean callStatus) {
		this.callStatus = callStatus;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public long getSendDataTimePoint() {
		return sendDataTimePoint;
	}
	public void setSendDataTimePoint(long sendDataTimePoint) {
		this.sendDataTimePoint = sendDataTimePoint;
	}
	public int getRequestType() {
		return requestType;
	}
	public void setRequestType(int requestType) {
		this.requestType = requestType;
	}
	
}