package com.jd.ump.tsc.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jd.ump.tsc.common.BusinessAnalysisUtil;
import com.jd.ump.tsc.common.CommonUtil;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;
import com.jd.ump.tsc.taskcenter.BusinessMonitor.BusinessConfigInfo;
import com.jd.ump.tsc.taskcenter.BusinessMonitor.LoadBusinessCache;

/**
 * 从数据库获得所有需要主动访问的接口配置信息
 * 
 * @author duliang
 * @date 2012-10-10 
 */
public class LoadBusinessCacheManager {
	private final static Logger LOGGER = LoggerFactory.getLogger(LoadBusinessCacheManager.class);
    private JdbcTemplate jdbcTemplate;

    private final static String CLASS_NAME = "LoadBusinessCacheManager";
    
    /**
     * 数据库注册连接
     */
    public LoadBusinessCacheManager() {
    	this.jdbcTemplate = SwitchMasterSlave.TaskSchedulingCenterManagers.getJdbcTemplate();
    }

    
    /**
     * 查询每天分析一次的配置信息
     * 数据格式：BusinessConfigInfo
     */
    public void getBusinessPerDayInfoFromDB() {
    	
		String sql = " select c.id,c.bus_key,c.bus_active_url,c.bus_active_url_type,c.bus_active_hour,c.bus_active_min,c.bus_active_exttime,c.bus_active_metodnm,c.bus_request_type from ump_business_key_cfg c where c.bus_datacollect_way = ? and c.bus_active_rate = ? and c.bus_status = 1";
		Object[] paramsForSelect = new Object[] { BusinessAnalysisUtil.BUS_DATACOLLECT_WAY_INITIATIVECALL , BusinessAnalysisUtil.BUS_ACTIVE_RATE_DAY };
		
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
		    	
		    	String timeHour = ((Integer)row.get("bus_active_hour")).toString();
		    	String timeMunite = ((Integer)row.get("bus_active_min")).toString();
		    	BusinessConfigInfo businessConfigInfo = new BusinessConfigInfo();
			
		    	businessConfigInfo.setId(((Number)row.get("id")).intValue());
		    	businessConfigInfo.setAccessKey((String) row.get("bus_key"));
		    	businessConfigInfo.setCallType(((Integer)row.get("bus_active_url_type")).intValue());
		    	businessConfigInfo.setUrl(((String)row.get("bus_active_url")).trim());
		    	businessConfigInfo.setMethod((String)row.get("bus_active_metodnm"));
		    
		    	if((Integer)row.get("bus_active_exttime")!=null){
		    		businessConfigInfo.setTimeout(((Integer)row.get("bus_active_exttime")).intValue());
		    	}else{
		    		businessConfigInfo.setTimeout(10);
		    	}
		    	
		    	if((Integer)row.get("bus_request_type")!=null){
		    		businessConfigInfo.setRequestType(((Integer)row.get("bus_request_type")).intValue());
				}else{
					businessConfigInfo.setRequestType(0);
				}
		    	
		    	String mapKey = timeHour + ":" + timeMunite;
		    	
		    	if(LoadBusinessCache.cacheBusinessPerDayMap.containsKey(mapKey)){
		    		LoadBusinessCache.cacheBusinessPerDayMap.get(mapKey).add(businessConfigInfo);
		    	}else{
		    		List<BusinessConfigInfo> businessConfigInfoList = new ArrayList<BusinessConfigInfo>();
		    		businessConfigInfoList.add(businessConfigInfo);
		    		LoadBusinessCache.cacheBusinessPerDayMap.put(mapKey, businessConfigInfoList);
		    	}
		    
		    }
		}
    }
    
    
    /**
     * 查询每小时分析一次的配置信息
     * 数据格式：BusinessConfigInfo
     */
    public void getBusinessPerHourInfoFromDB() {
    	
		String sql = " select c.id,c.bus_key,c.bus_active_url,c.bus_active_url_type,c.bus_active_min,c.bus_active_exttime,c.bus_active_metodnm,c.bus_request_type from ump_business_key_cfg c where c.bus_datacollect_way = ? and c.bus_active_rate = ? and c.bus_status = 1 ";
		Object[] paramsForSelect = new Object[] { BusinessAnalysisUtil.BUS_DATACOLLECT_WAY_INITIATIVECALL , BusinessAnalysisUtil.BUS_ACTIVE_RATE_HOUR };
		
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
		    	
		    	String timeMunite = ((Integer)row.get("bus_active_min")).toString();
		    	BusinessConfigInfo businessConfigInfo = new BusinessConfigInfo();
			
		    	businessConfigInfo.setId(((Number)row.get("id")).intValue());
		    	businessConfigInfo.setAccessKey((String) row.get("bus_key"));
		    	businessConfigInfo.setCallType(((Integer)row.get("bus_active_url_type")).intValue());
		    	businessConfigInfo.setUrl(((String)row.get("bus_active_url")).trim());
		    	businessConfigInfo.setMethod((String)row.get("bus_active_metodnm"));
		    	
		    	if((Integer)row.get("bus_active_exttime")!=null){
		    		businessConfigInfo.setTimeout(((Integer)row.get("bus_active_exttime")).intValue());
		    	}else{
		    		businessConfigInfo.setTimeout(10);
		    	}
		    	
		    	if((Integer)row.get("bus_request_type")!=null){
		    		businessConfigInfo.setRequestType(((Integer)row.get("bus_request_type")).intValue());
				}else{
					businessConfigInfo.setRequestType(0);
				}
		    	
		    	if(LoadBusinessCache.cacheBusinessPerHourMap.containsKey(timeMunite)){
		    		LoadBusinessCache.cacheBusinessPerHourMap.get(timeMunite).add(businessConfigInfo);
		    	}else{
		    		List<BusinessConfigInfo> businessConfigInfoList = new ArrayList<BusinessConfigInfo>();
		    		businessConfigInfoList.add(businessConfigInfo);
		    		LoadBusinessCache.cacheBusinessPerHourMap.put(timeMunite, businessConfigInfoList);
		    	}
		    
		    }
		}
    }
    
    
    
    /**
     * 查询固定频率分钟访问一次的配置信息
     * @param bmpPingTimePeriodArray
     */
    public void getBusinessPerMinuteInfoFromDB(String[] bmpPingTimePeriodArray) {

		for (int i = 0; i < bmpPingTimePeriodArray.length; i++) {
	
		    //根据每个时间频率查询，一共查询5次
		    String sql = "select c.id,c.bus_key,c.bus_active_url,c.bus_active_url_type,c.bus_active_exttime,c.bus_active_metodnm,c.bus_request_type " + 
		    	" from ump_business_key_cfg c " +  
		    	" where c.bus_datacollect_way = ? and c.bus_active_rate = ? and c.bus_active_min = ? and c.bus_status = 1 ";
		    Object[] paramsForSelect = new Object[] { BusinessAnalysisUtil.BUS_DATACOLLECT_WAY_INITIATIVECALL , BusinessAnalysisUtil.BUS_ACTIVE_RATE_MINUTE, bmpPingTimePeriodArray[i] };
		    
		    List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql, paramsForSelect);
		    if (tpRows.size() > 0) {
		    	List<BusinessConfigInfo> businessConfigInfoList = new ArrayList<BusinessConfigInfo>();
				for (Map<String, Object> row : tpRows) {
					BusinessConfigInfo businessConfigInfo = new BusinessConfigInfo();
					
			    	businessConfigInfo.setId(((Number)row.get("id")).intValue());
			    	businessConfigInfo.setAccessKey((String) row.get("bus_key"));
			    	businessConfigInfo.setCallType(((Integer)row.get("bus_active_url_type")).intValue());
			    	businessConfigInfo.setUrl(((String)row.get("bus_active_url")).trim());
			    	businessConfigInfo.setMethod((String)row.get("bus_active_metodnm"));
			    	if((Integer)row.get("bus_active_exttime")!=null){
			    		businessConfigInfo.setTimeout(((Integer)row.get("bus_active_exttime")).intValue());
			    	}else{
			    		businessConfigInfo.setTimeout(10);
			    	}
				    
			    	if((Integer)row.get("bus_request_type")!=null){
			    		businessConfigInfo.setRequestType(((Integer)row.get("bus_request_type")).intValue());
					}else{
						businessConfigInfo.setRequestType(0);
					}
			    	
			    	businessConfigInfoList.add(businessConfigInfo);
				}
				LoadBusinessCache.cacheBusinessPerMinuteMap.put(bmpPingTimePeriodArray[i], businessConfigInfoList);
				LOGGER.info(CommonUtil.makeInfoHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME, "getBusinessPerMinuteInfoFromDB") + "Cache BusinessPerMinute |" + ToolBox.getNowTime() + " | " + bmpPingTimePeriodArray[i] + " | size: " + businessConfigInfoList.size() + "");
		    }
		}
    }
    
    
    
    /**
     * 查询固定频率分析业务数据的配置信息
     * @param bmpAlarmAnalysisPeriodArray
     * bus_key|bus_alm_anlyrate|bus_log_sumrate|bus_log_anlyway|bus_almanlylog_mgway|
     */
    public void getBusinessAlarmAnalysisInfoFromDB(String[] bmpAlarmAnalysisPeriodArray) {

		for (int i = 0; i < bmpAlarmAnalysisPeriodArray.length; i++) {
	
		    //根据每个时间频率查询，一共查询5次
		    String sql = "select c.bus_key,c.bus_alm_anlyrate,c.bus_log_sumrate,c.bus_log_anlyway,c.bus_almanlylog_mgway  " + 
		    	" from ump_business_key_cfg c " +  
		    	" where c.bus_datacollect_way != ? and c.bus_alm_anlyway = ? and c.bus_log_anlyway != ? and c.bus_log_sumrate= ? and c.bus_status = 1 ";
		    Object[] paramsForSelect = new Object[] { BusinessAnalysisUtil.BUS_DATACOLLECT_WAY_INITIATIVECALL , BusinessAnalysisUtil.BUS_ALM_ANLYWAY_FIXED_FREQUENCY,BusinessAnalysisUtil.BUS_LOG_ANLYWAY_ORIGINALDATA, bmpAlarmAnalysisPeriodArray[i] };
		    
		    List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql, paramsForSelect);
		    if (tpRows.size() > 0) {
		    	Map<String, String> map = new HashMap<String, String>();	//该MAP存放每个时间频率的数据,有数据才存放，没数据不存放
				for (Map<String, Object> row : tpRows) {
					String busKey = (String)row.get("bus_key");
					String busAlmAnlyrate = Integer.toString((Integer)row.get("bus_alm_anlyrate"));
					
					String busLogSumrate = "1";
					if((Integer)row.get("bus_log_sumrate")!=null){
						busLogSumrate = Integer.toString((Integer)row.get("bus_log_sumrate"));
					}
					
					String busLogAnlyway = Integer.toString((Integer)row.get("bus_log_anlyway"));
					String busAlmanlylogMgway = Integer.toString((Integer)row.get("bus_almanlylog_mgway"));
					
					String content = busKey + "|" + busAlmAnlyrate + "|" + busLogSumrate + "|" + busLogAnlyway +  "|" + busAlmanlylogMgway + "|" ;
				    map.put(busKey, content);
				}
				LoadBusinessCache.cacheBusinessAlarmAnalysisMap.put(bmpAlarmAnalysisPeriodArray[i], map);
				LOGGER.info(CommonUtil.makeInfoHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME, "getBusinessAlarmAnalysisInfoFromDB") + "Cache BusinessAlarmAnalysis |" + ToolBox.getNowTime() + " | " + bmpAlarmAnalysisPeriodArray[i] + " | size: " + map.size() + "");
		    }
		}
    }
    
    
    
    /**
     * 查询每天分析一次的配置信息
     * 数据格式：bus_key|bus_log_anlyway|
     */
    public void getCalculateHistoryDataFromDB() {
    	
//		String sql = " select a.bus_key,a.bus_log_anlyway from ump_business_key_cfg a inner join ump_business_alarm_rule b on a.bus_key = b.ar_key " + 
//					 " where (a.bus_datacollect_way = ? or a.bus_datacollect_way = ?) and (a.bus_log_anlyway = ? or a.bus_log_anlyway = ?) " + 
//					 " and b.ar_thresholdval_type = ? and b.ar_sameterm_fetway = ? and a.bus_status = 1 " ;
    	String sql = "select a.bus_log_sumrate,a.bus_key,a.bus_log_anlyway from ump_business_key_cfg a inner join ump_business_alm_cfg b on a.bus_key = b.am_key " +
    			" where (a.bus_datacollect_way = 2 or a.bus_datacollect_way = 3) and (a.bus_log_anlyway = 1 or a.bus_log_anlyway = 2 or a.bus_log_anlyway = 4) and a.bus_status = 1 " +
    			" and exists(select 1 from ump_business_alm_rule c where c.amr_key = b.am_key and (c.amr_thresholdval_source = 6 or c.amr_thresholdval_source = 7) and c.amr_sameterm_fetway = 2) ";
//		Object[] paramsForSelect = new Object[] { 
//					BusinessAnalysisUtil.BUS_DATACOLLECT_WAY_PASSIVE , 
//					BusinessAnalysisUtil.BUS_DATACOLLECT_WAY_LOG,
//					BusinessAnalysisUtil.BUS_LOG_ANLYWAY_VALUE_ACCUMULATE,
//					BusinessAnalysisUtil.BUS_LOG_ANLYWAY_COUNT_ACCUMULATE,
//					BusinessAnalysisUtil.BUS_THRESHOLDVAL_TYPE_CORRESPONDINGTIMEPERIOD,
//					BusinessAnalysisUtil.BUS_SAMETERM_FETWAY_HISTORY_AVG
//				};
		
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql);
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
		    	String busKey = (String)row.get("bus_key");
				String busLogAnlyway = Integer.toString((Integer)row.get("bus_log_anlyway"));
				String busLogSumrate = Integer.toString((Integer)row.get("bus_log_sumrate"));
		    	
		    	if(!LoadBusinessCache.cacheBusinessCalculateHistoryDataMap.containsKey(busKey)){
		    		String content = busKey + "|" + busLogAnlyway + "|" + busLogSumrate + "|";
		    		LoadBusinessCache.cacheBusinessCalculateHistoryDataMap.put(busKey, content);
		    	}
		    }
		}
    }
    
    
    
    /**
     * 查询每半小时执行一次删除任务的信息
     * 数据格式：taskKey|
     */
    public HashMap<String,String> getDeleteKeyFromDB() {
    	HashMap<String,String> cacheBusinessDeleteKeyMap = new HashMap<String, String>();
		
    	String sql = " select task_key from ump_keydelete_task where task_status = ? and TIMESTAMPDIFF(HOUR,dict_createdtime,sysdate()) > 0" ;
		Object[] paramsForSelect = new Object[] { BusinessAnalysisUtil.KEYDELETE_TASK_UNFINISHED };
		
		List<Map<String, Object>> tpRows = this.jdbcTemplate.queryForList(sql,paramsForSelect);
		if (tpRows.size() > 0) {
		    for (Map<String, Object> row : tpRows) {
		    	String taskKey = (String)row.get("task_key");
		    	
		    	if(!cacheBusinessDeleteKeyMap.containsKey(taskKey)){
		    		String content = taskKey + "|" ;
		    		cacheBusinessDeleteKeyMap.put(taskKey, content);
		    	}
		    }
		}
		
		return cacheBusinessDeleteKeyMap;
    }
    
    
}
