package com.jd.ump.tsc.common;

public class BusinessAnalysisUtil {
	
	
	 /**
     * 业务监控中心任务时间频率（1分钟）
     */
    public static final long BUSINESS_TIMEPERIOD_ONE_MINUTE = 60000L;
    
    
    /**
     * 任务调度的队列名称
     */
    public static final String Business_Day_Hour_Minute_Queue = "BusinessDayHourMinuteQueue";
    public static final String Business_DataAnalysis_Queue = "BusinessDataAnalysisQueue";
    public static final String Business_CalculateHistory_Queue = "SameTermDataCollectionQueue";
    public static final String Business_DeleteKey_Queue = "HbaseDataDeleteQueue";
    
    /**
     * 业务监控数据获取类型（主动访问）
     */
    public static final int BUS_DATACOLLECT_WAY_INITIATIVECALL = 1;
    
    /**
     * 业务监控数据获取类型（被动访问）
     */
    public static final int BUS_DATACOLLECT_WAY_PASSIVE = 2;
    
    /**
     * 业务监控数据获取类型（日志）
     */
    public static final int BUS_DATACOLLECT_WAY_LOG = 3;
    
	
	/**
	 * 业务监控主动获取数据，时间频率（天）
	 */
    public static final int BUS_ACTIVE_RATE_DAY = 1;
    
    /**
	 * 业务监控主动获取数据，时间频率（小时）
	 */
    public static final int BUS_ACTIVE_RATE_HOUR = 2;
    
    /**
	 * 业务监控主动获取数据，时间频率（分钟）
	 */
    public static final int BUS_ACTIVE_RATE_MINUTE = 3;
    
    /**
     * 业务监控按分钟访问时的固定时间频率
     */
    public static final String BUS_MINUTE_FIXED_FREQUENCY = "3,5,10,15,30";
    
    /**
     * 业务监控按固定时间频率分析
     */
    public static final String BUS_ALARM_ANALYSIS_FREQUENCY = "1,5,10,20";
    
    /**
     * 报警预警分析方式:   1:按频率分析   2:立即分析
     */
    public static final int BUS_ALM_ANLYWAY_FIXED_FREQUENCY = 1;
    
    /**
     * 数据解析方式:  1:值累加     2:次数累加     3:原始数据
     */
    public static final int  BUS_LOG_ANLYWAY_VALUE_ACCUMULATE = 1;
    public static final int  BUS_LOG_ANLYWAY_COUNT_ACCUMULATE = 2;
    public static final int  BUS_LOG_ANLYWAY_ORIGINALDATA = 3;
    
    /**
     * 报警参照值类型   1：固定值   2：字段值	 3：表达式    4：环比  5：同比
     */
    public static final int BUS_THRESHOLDVAL_TYPE_CORRESPONDINGTIMEPERIOD = 5;
    
    
    /**
     * 同比数据获取方式   1：直接取值（取同期）   2：历史平均数
     */
    public static final int BUS_SAMETERM_FETWAY_HISTORY_AVG = 2;
    
    /**
     * 天粒度时间频率(24小时)
     */
    public static final long DAY_TIMEPERIOD = 3600000L * 24;
    
    
    /**
     * 定时删除KEY任务（未删除状态）
     */
    public static final int KEYDELETE_TASK_UNFINISHED = 1;
    
    /**
     * 定时删除KEY任务频率(60分钟)
     */
    public static final long KEYDELETE_TASK_TIMEPERIOD = 60000L * 60;
    
    

}
