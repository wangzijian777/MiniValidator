package com.jd.ump.tsc.taskcenter.BusinessMonitor;

import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;
import com.jd.ump.tsc.common.BusinessAnalysisUtil;
import com.jd.ump.tsc.common.CommonUtil;
import com.jd.ump.tsc.common.ThreadPoolManager;
import com.jd.ump.tsc.common.ToolBox;
import com.jd.ump.tsc.masterslave.SwitchMasterSlave;

/**
 * 分析同比分析的任务
 * 每天在固定时间运行一次，任务内容为配置信息字符串
 * 
 * @date 2012-10-19
 * @author duliang
 */
public class BusinessCalculateHistoryTimer extends TimerTask {

    private final static Logger LOGGER = LoggerFactory.getLogger(BusinessCalculateHistoryTimer.class);
    private ThreadPoolManager threadPoolManagerBCHT;
    
    private final static String CLASS_NAME = "BusinessCalculateHistoryTimer";
    
    public BusinessCalculateHistoryTimer() {
    	this.threadPoolManagerBCHT = new ThreadPoolManager(10);
    }

    
    /**
     * 开始运行固定频率访问一次的定时器,调用MQ接口发送
     * 数据格式：bus_key|bus_log_anlyway|time
     */
    @Override
    public void run() {
	
    	CallerInfo callerInfo = null;
		// 设置发送任务的时间点(时间点为前一天的0点0分0秒0毫秒)
    	Calendar now = Calendar.getInstance();
    	now.add(Calendar.DATE, -1);
    	now.set(Calendar.HOUR_OF_DAY, 0);
    	now.set(Calendar.MINUTE, 0);
    	now.set(Calendar.SECOND, 0);
		now.set(Calendar.MILLISECOND, 0);
    	long sendDataTimePoint = now.getTime().getTime();
    	
		try {
			callerInfo = Profiler.registerInfo("ump.bmp.TaskSchedulingCenter.BusinessCalculateHistoryTimer", false, true);
			
		    if(SwitchMasterSlave.sendDataStatus){
		    	synchronized (LoadBusinessCache.cacheBusinessCalculateHistoryDataMap) {
						
		    		if (LoadBusinessCache.cacheBusinessCalculateHistoryDataMap.size() > 0) {
		    			Collection<String> c = LoadBusinessCache.cacheBusinessCalculateHistoryDataMap.values();
						Iterator<String> it = c.iterator();
						for (; it.hasNext();) {
						    String sendData = it.next().toString() + Long.toString(sendDataTimePoint);
						    threadPoolManagerBCHT.execute(sendDataByMQ(sendData));
						}
			    	}
				}
		    }
		   
		} catch (Exception e) {
		    SwitchMasterSlave.scanDBStatus = false;
		    Profiler.functionError(callerInfo);
		    LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "BusinessCalculateHistory Timer ERROR at :" + ToolBox.fomartTime(sendDataTimePoint),e);
		}finally {
			Profiler.registerInfoEnd(callerInfo);
		}
    }

    
    /**
     * 调用MQ接口发送数据
     */
    private Runnable sendDataByMQ(final String sendData) {
    	return new Runnable() {
    		public void run() {
    			try {
    				if (sendData!=null) {
    					SwitchMasterSlave.MQManager.sendDataToMQ(BusinessAnalysisUtil.Business_CalculateHistory_Queue,sendData);
    					
    					if(LOGGER.isInfoEnabled()) 
    						LOGGER.info(CommonUtil.makeInfoHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME, "sendDataByMQ") + "BusinessCalculateHistory : " + sendData );
    				}
    			} catch (Exception e) {
    				LOGGER.error(CommonUtil.makeErrorHead(CommonUtil.MODULE_BUSINESSANALYSISSCHEDULE, CLASS_NAME) + "SendData ERROR: " + sendData, e);
    			}
    		}
    	};
    }

    
}
