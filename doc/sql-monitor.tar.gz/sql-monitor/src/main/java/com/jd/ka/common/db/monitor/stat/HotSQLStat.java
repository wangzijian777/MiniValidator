package com.jd.ka.common.db.monitor.stat;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;



/**
 * Hot SQL统计，统计热点SQL的总执行次数、平均执行时间、最大执行时间
 * @author qiulong
 *
 */
class HotSQLStat implements SQLStat {
	private int maxsize = 10;
	private final LinkedHashMap<String, SQLStatData> sqlStatMap;
	private ReentrantReadWriteLock rwlock = new ReentrantReadWriteLock();
	 
	 HotSQLStat() {
		 //LRU Cache
		 sqlStatMap = new LinkedHashMap<String, SQLStatData>(16, 0.75f, false) {
			private static final long serialVersionUID = 3773682863759526671L;
			@Override protected boolean removeEldestEntry(Entry<String, SQLStatData> eldest) {
				return size() > maxsize;
			}
		 };
	 }

	@Override
	public void doStat(SQLStatBean sqlStatBean) {
		SQLStatData sqlStatData = getSQLStatData(sqlStatBean.getId());
		 if(sqlStatData == null) {
			 rwlock.writeLock().lock();
			 try {
				 if(sqlStatData == null) {
					 sqlStatData = new SQLStatDataImpl(sqlStatBean);
					 sqlStatMap.put(sqlStatBean.getId(), sqlStatData);
				 }
			 } finally {
				 rwlock.writeLock().unlock();
			 }
		 }
		SQLStatDataImpl sqlStatDataImpl = (SQLStatDataImpl) sqlStatData;
		statException(sqlStatDataImpl, sqlStatBean);
		statExeCount(sqlStatDataImpl, sqlStatBean);
		statExeCountTime(sqlStatDataImpl, sqlStatBean);
		statMaxExeTime(sqlStatDataImpl, sqlStatBean);
	}

	@Override
	public Object collect() {
		rwlock.readLock().lock();
		try {
			List<SQLStatData> data = new ArrayList<SQLStatData>();
			Set<Entry<String, SQLStatData>> entries = sqlStatMap.entrySet();
			for (Entry<String, SQLStatData> entry : entries) {
				data.add(entry.getValue());
			}
			return data;
		} finally {
			rwlock.readLock().unlock();
		}
	}

	@Override
	public StatType getStatType() {
		return StatType.HOT;
	}
	
	@Override
	public void reset() {
		rwlock.writeLock().lock();
		try {
			sqlStatMap.clear();
		} finally {
			rwlock.writeLock().unlock();
		}
	}
	
	private SQLStatData getSQLStatData(String id) {
		rwlock.readLock().lock();
		try {
			return sqlStatMap.get(id);
		} finally {
			rwlock.readLock().unlock();
		}
	}
	
	private void statException(SQLStatDataImpl sqlStatData, SQLStatBean sqlStatBean) {
		if(sqlStatBean.hasException()) {
			sqlStatData.addExceptionCount();
		}
	}
	
	private void statExeCount(SQLStatDataImpl sqlStatData, SQLStatBean sqlStatBean) {
		sqlStatData.addExeCount();
	}
	
	private void statExeCountTime(SQLStatDataImpl sqlStatData, SQLStatBean sqlStatBean) {
		sqlStatData.addExeCountTime(sqlStatBean.getElapsedTime());
	}
	
	private void statMaxExeTime(SQLStatDataImpl sqlStatData, SQLStatBean sqlStatBean) {
		sqlStatData.setMaxTime(sqlStatBean.getElapsedTime());
	}

}
