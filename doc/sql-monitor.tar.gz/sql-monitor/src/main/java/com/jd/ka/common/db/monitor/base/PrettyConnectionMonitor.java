package com.jd.ka.common.db.monitor.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.jd.ka.common.db.pretty.DebugLevel;
import com.jd.ka.common.db.pretty.StatementFactory;

/**
 * 
 * @author qiulong
 *
 */
class PrettyConnectionMonitor extends ConnectionMonitor {
	private final Connection connection;
	private SqlMonitorable monitor;
	
	static {
		StatementFactory.setDefaultDebug(DebugLevel.ON);
	}

	public PrettyConnectionMonitor(Connection connection, SqlMonitorable monitor) {
		super(connection, monitor);
		this.connection = connection;
		this.monitor = monitor;
	}

	@Override
	public PreparedStatement prepareStatement(String sql) throws SQLException {
		return new PrettyPreparedStatement(sql, StatementFactory.getStatement(connection, sql), monitor);
	}
	
	private class PrettyPreparedStatement extends PreparedStatementMonitor {
		private final PreparedStatement state;

		public PrettyPreparedStatement(String sql, PreparedStatement state, SqlMonitorable monitor) {
			super(sql, state, monitor);
			this.state = state;
		}

		@Override
		protected String getSql() {
			return state.toString();
		}
		
	}

}
