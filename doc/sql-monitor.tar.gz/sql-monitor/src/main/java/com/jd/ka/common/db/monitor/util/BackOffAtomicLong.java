package com.jd.ka.common.db.monitor.util;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.LockSupport;

/**
 * 用于CAS的回避竞争控制，reference: <a>http://arxiv.org/pdf/1305.5800v1.pdf</a>
 * @author qiulong
 *
 */
public class BackOffAtomicLong {
	private final AtomicLong value;

	public BackOffAtomicLong() {
		this(0L);
	}

	public BackOffAtomicLong(long initalValue) {
		value = new AtomicLong(initalValue);
	}

	public long get() {
		return value.get();
	}

	public final long getAndIncrement() {
		for (;;) {
			long current = get();
			long next = current + 1;
			if (compareAndSet(current, next))
				return current;
		}
	}

	public final long getAndDecrement() {
		for (;;) {
			long current = get();
			long next = current - 1;
			if (compareAndSet(current, next))
				return current;
		}
	}

	public long incrementAndGet() {
		for (;;) {
			long current = get();
			long next = current + 1;
			if (compareAndSet(current, next))
				return next;
		}
	}

	public long decrementAndGet() {
		for (;;) {
			long current = get();
			long next = current - 1;
			if (compareAndSet(current, next))
				return next;
		}
	}

	public final long getAndAdd(long delta) {
		for (;;) {
			long current = get();
			long next = current + delta;
			if (compareAndSet(current, next))
				return current;
		}
	}
	
	public final long addAndGet(long delta) {
        for (;;) {
            long current = get();
            long next = current + delta;
            if (compareAndSet(current, next))
                return next;
        }
    }

	public void set(final long l) {
		value.set(l);
	}

	public final long getAndSet(long newValue) {
		for (;;) {
			long current = get();
			if (compareAndSet(current, newValue))
				return current;
		}
	}

	public final boolean compareAndSet(final long current, final long next) {
		if (value.compareAndSet(current, next)) {
			return true;
		} else {
			//如果失败，不直接进入循环，等待1纳秒
			LockSupport.parkNanos(1L);
			return false;
		}
	}

}
