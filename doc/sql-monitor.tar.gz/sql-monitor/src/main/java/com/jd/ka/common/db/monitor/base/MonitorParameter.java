/*
	File: MonitorParam.java
	Date			Author		Changes
	2015年4月3日		qiulong		Create
 */
package com.jd.ka.common.db.monitor.base;

import com.jd.ka.common.db.monitor.SQLMonitor.MonitorParam;

/**
 * @author qiulong
 *
 */
class MonitorParameter implements MonitorParam {
	private final MonitorParamBuilder builder;
	
	private MonitorParameter(final MonitorParamBuilder builder) {
		this.builder = builder;
	}

	@Override
	public String getSQL() {
		return builder.sql;
	}

	@Override
	public long getSTTime() {
		return builder.st;
	}

	@Override
	public long getEDTime() {
		return builder.et;
	}

	@Override
	public boolean hasException() {
		return builder.hasException;
	}
	
	@Override
	public String getClassName() {
		return builder.className;
	}

	@Override
	public String getMethodName() {
		return builder.methodName;
	}
	
	@Override
	public long getElapsedTime() {
		return getEDTime() - getSTTime();
	}
	
	public static MonitorParamBuilder newBuilder() {
		return new MonitorParamBuilder();
	}
	
	static class MonitorParamBuilder {
		private long st;
		private long et;
		private boolean hasException;
		private String sql;
		private String className;
		private String methodName;
		
		public MonitorParamBuilder setSTTime(long st) {
			this.st = st;
			return this;
		}
		
		public MonitorParamBuilder setEDTime(long et) {
			this.et = et;
			return this;
		}
		
		public MonitorParamBuilder setHasException(boolean hasException) {
			this.hasException = hasException;
			return this;
		}

		public MonitorParamBuilder setSql(String sql) {
			this.sql = sql;
			return this;
		}

		public MonitorParamBuilder setClassName(String className) {
			this.className = className;
			return this;
		}

		public MonitorParamBuilder setMethodName(String methodName) {
			this.methodName = methodName;
			return this;
		}

		public MonitorParam build() {
			return new MonitorParameter(this);
		}
	}

}
