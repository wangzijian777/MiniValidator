/*
	File: UMPAlarm.java
	Date			Author		Changes
	2015年4月2日		qiulong		Create
 */
package com.jd.ka.common.db.monitor;

import com.jd.ump.profiler.proxy.Profiler;

/**
 * SQL性能监控-UMP报警
 * @author qiulong
 *
 */
public class UMPAlarm implements SQLMonitor {
	private String umpKey;
	private long threshold = 1000;
	
	public UMPAlarm(String umpKey) {
		if(umpKey == null || umpKey.isEmpty()) {
			throw new RuntimeException("UMP Key cannot be null");
		}
		this.umpKey = umpKey;
	}

	/**
	 * 设置一个SQL执行耗时的报警阀值，默认为1s。也就是，当SQL执行时长超过1s时就触发报警。
	 * @param threshold
	 */
	public void setThreshold(long threshold) {
		this.threshold = threshold;
	}
	
	protected long getThreshold() {
		return threshold;
	}

	@Override
	public void monitoring(MonitorParam param) {
		if(param.hasException()) {
			Profiler.businessAlarm(umpKey, System.currentTimeMillis(), "SQL["+ param.getClassName() + "#" + param.getMethodName() + "]执行发生异常");
		} else {
			if(param.getElapsedTime() > getThreshold()) {
				Profiler.businessAlarm(umpKey, System.currentTimeMillis(), "SQL["+ param.getClassName() + "#" + param.getMethodName() + "]执行" + param.getElapsedTime()  + "ms超过报警值" + getThreshold() + "ms");
			}
		}
	}

}
