package com.jd.ka.common.db.monitor.stat;

/**
 * 慢查询统计
 * @author qiulong
 *
 */
class SlowLogStat implements SQLStat {

	@Override
	public void doStat(SQLStatBean sqlStatBean) {

	}

	@Override
	public Object collect() {
		return null;
	}

	@Override
	public StatType getStatType() {
		return StatType.SLOWLOG;
	}

	@Override
	public void reset() {
		
	}

}
