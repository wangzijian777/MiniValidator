/*
	File: SqlMonitorDataSource.java
	Date			Author		Changes
	2015年4月3日		qiulong		Create
 */
package com.jd.ka.common.db.monitor.base;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;

import javax.sql.DataSource;

import com.jd.ka.common.db.monitor.Configuration;

/**
 * 用于SQL执行监控的包装类
 * @author qiulong
 *
 */
public class SqlMonitorDataSource implements DataSource {
	private final DataSource dataSource;
	private final SqlMonitorable monitor;
	private final Configuration conf;
	
	public SqlMonitorDataSource(DataSource dataSource, Configuration configuration) {
		this.dataSource = dataSource;
		this.conf = configuration;
		this.monitor = new SqlMonitorableImpl(configuration);
	}

	public PrintWriter getLogWriter() throws SQLException {
		return dataSource.getLogWriter();
	}

	public void setLogWriter(PrintWriter out) throws SQLException {
		dataSource.setLogWriter(out);
	}

	public void setLoginTimeout(int seconds) throws SQLException {
		dataSource.setLoginTimeout(seconds);
	}

	public int getLoginTimeout() throws SQLException {
		return dataSource.getLoginTimeout();
	}

	public Logger getParentLogger() throws SQLFeatureNotSupportedException {
		throw new UnsupportedOperationException();
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		return dataSource.unwrap(iface);
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return dataSource.isWrapperFor(iface);
	}

	public Connection getConnection() throws SQLException {
		if(isDebug()) {
			return new PrettyConnectionMonitor(dataSource.getConnection(), monitor);
		}
		return new ConnectionMonitor(dataSource.getConnection(), monitor);
	}

	public Connection getConnection(String username, String password) throws SQLException {
		if(isDebug()) {
			return new PrettyConnectionMonitor(dataSource.getConnection(username, password), monitor);
		}
		return new ConnectionMonitor(dataSource.getConnection(username, password), monitor);
	}
	
	private boolean isDebug() {
		return conf.isDebug();
	}
	
}
