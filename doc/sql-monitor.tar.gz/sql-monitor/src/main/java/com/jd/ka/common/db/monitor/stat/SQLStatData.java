package com.jd.ka.common.db.monitor.stat;

/**
 * 统计数据
 * @author qiulong
 *
 */
public interface SQLStatData {
	
	/**
	 * 获取SQL MD5后的id
	 * @return
	 */
	String getId();
	
	/**
	 * 获取执行的SQL语句
	 * @return
	 */
	String getSQL();
	
	/**
	 * 执行平均时间
	 * @return
	 */
	long exeAvgTime();
	
	/**
	 * 执行总次数
	 * @return
	 */
	int exeCount();
	
	/**
	 * 执行最大时间
	 * @return
	 */
	long exeMaxTime();
	
	/**
	 * 执行发生异常次数
	 * @return
	 */
	int exceptionCount();
	
}
