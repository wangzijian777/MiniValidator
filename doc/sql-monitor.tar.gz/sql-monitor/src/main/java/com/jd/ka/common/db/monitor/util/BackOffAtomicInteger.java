package com.jd.ka.common.db.monitor.util;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.LockSupport;

/**
 * 用于CAS的回避竞争控制，reference: <a>http://arxiv.org/pdf/1305.5800v1.pdf</a>
 * @author qiulong
 *
 */
public class BackOffAtomicInteger {
	private final AtomicInteger value;

	public BackOffAtomicInteger() {
		this(0);
	}

	public BackOffAtomicInteger(int initalValue) {
		value = new AtomicInteger(initalValue);
	}
	
	public int get() {
		return value.get();
	}

	public final int getAndIncrement() {
		for (;;) {
			int current = get();
			int next = current + 1;
			if (compareAndSet(current, next))
				return current;
		}
	}

	public final int getAndDecrement() {
		for (;;) {
			int current = get();
			int next = current - 1;
			if (compareAndSet(current, next))
				return current;
		}
	}

	public final int incrementAndGet() {
		for (;;) {
			int current = get();
			int next = current + 1;
			if (compareAndSet(current, next))
				return next;
		}
	}

	public final int decrementAndGet() {
		for (;;) {
			int current = get();
			int next = current - 1;
			if (compareAndSet(current, next))
				return next;
		}
	}

	public final int getAndAdd(int delta) {
		for (;;) {
			int current = get();
			int next = current + delta;
			if (compareAndSet(current, next))
				return current;
		}
	}
	
	public final int addAndGet(int delta) {
        for (;;) {
        	int current = get();
        	int next = current + delta;
            if (compareAndSet(current, next))
                return next;
        }
    }

	public void set(final int l) {
		value.set(l);
	}

	public final int getAndSet(int newValue) {
		for (;;) {
			int current = get();
			if (compareAndSet(current, newValue))
				return current;
		}
	}

	public final boolean compareAndSet(final int current, final int next) {
		if (value.compareAndSet(current, next)) {
			return true;
		} else {
			//如果失败，不直接进入循环，等待1纳秒
			LockSupport.parkNanos(1L);
			return false;
		}
	}
}
