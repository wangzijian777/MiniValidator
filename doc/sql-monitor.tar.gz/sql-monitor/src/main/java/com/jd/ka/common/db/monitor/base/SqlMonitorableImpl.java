package com.jd.ka.common.db.monitor.base;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor.DiscardPolicy;
import java.util.concurrent.TimeUnit;

import com.jd.ka.common.db.monitor.Configuration;
import com.jd.ka.common.db.monitor.SQLMonitor;
import com.jd.ka.common.db.monitor.SQLMonitor.MonitorParam;
import com.jd.ka.common.db.monitor.base.MonitorParameter.MonitorParamBuilder;
import com.jd.ka.common.db.monitor.stat.SQLStatMonitor;

/**
 * 
 * @author qiulong
 *
 */
class SqlMonitorableImpl implements SqlMonitorable {
	private final Configuration conf;
	private String PACKAGENAME = Configuration.class.getPackage().getName();
	private ThreadPoolExecutor threadPoolExecutor;
	private SQLMonitor statMonitor;

	public SqlMonitorableImpl(final Configuration conf) {
		this.conf = conf;
		this.threadPoolExecutor = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, 
				new LinkedBlockingQueue<Runnable>(1024), new DiscardPolicy());
		this.statMonitor = new SQLStatMonitor(conf);
	}

	@Override
	public void monitoring(MonitorParamBuilder builder) {
		StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
		StackTraceElement STE = null;
		String pack = conf.getPack();
		if(pack != null && !pack.isEmpty()) {
			for (StackTraceElement frame : stackTrace) {
				String className = frame.getClassName();
				if(!className.startsWith(PACKAGENAME) && className.startsWith(pack)) {
					STE = frame;
					break;
				}
			}
		}
		if(STE != null) {
			builder.setClassName(STE.getClassName()).setMethodName(STE.getMethodName());
		}
		monitorDispatch(conf.getMonitor(), builder.build());
	}
	
	protected void monitorDispatch(final SQLMonitor monitor, final MonitorParam param) {
		threadPoolExecutor.execute(new Runnable() {
			@Override public void run() {
				statMonitor.monitoring(param);
			}
		});
	}
}
