package com.jd.ka.common.db.monitor.stat;


/**
 * 慢查询Top SQL统计
 * @author qiulong
 *
 */
class TopSQLStat implements SQLStat {

	@Override
	public void doStat(SQLStatBean sqlStatBean) {

	}

	@Override
	public Object collect() {
		return null;
	}

	@Override
	public StatType getStatType() {
		return StatType.TOP;
	}

	@Override
	public void reset() {
		
	}

}
