/*
	File: SQLPerfMonitor.java
	Date			Author		Changes
	2015年4月3日		qiulong		Create
 */
package com.jd.ka.common.db.monitor.base;

import com.jd.ka.common.db.monitor.base.MonitorParameter.MonitorParamBuilder;


/**
 * @author qiulong
 *
 */
interface SqlMonitorable {
	void monitoring(MonitorParamBuilder builder);
}
