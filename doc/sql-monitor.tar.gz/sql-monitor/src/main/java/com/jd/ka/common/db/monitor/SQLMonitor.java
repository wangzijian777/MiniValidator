/*
	File: SQLMonitor.java
	Date			Author		Changes
	2015年4月2日		qiulong		Create
 */
package com.jd.ka.common.db.monitor;

/**
 * SQL性能监控<em>同步</em>处理接口，用户可实现此类自定义监控/报警方式（如：邮件、短消息等）
 * @author qiulong
 *
 */
public interface SQLMonitor {
	/**
	 * 监控SQL执行
	 * @param param 收集的监控参数
	 */
	void monitoring(MonitorParam param);
	
	/**
	 * 监控参数
	 * @author qiulong
	 *
	 */
	public interface MonitorParam {
		/**
		 * 获取执行的SQL
		 * @return
		 */
		String getSQL();
		
		/**
		 * 获取SQL执行开始时间
		 * @return
		 */
		long getSTTime();
		
		/**
		 *  获取SQL执行结束时间
		 * @return
		 */
		long getEDTime();
		
		/**
		 * 获取SQL执行消耗的时间
		 * @return
		 */
		long getElapsedTime();
		
		/**
		 * SQL执行是否发生异常
		 * @return true 有异常，false 没有异常
		 */
		boolean hasException();
		
		/**
		 * 获取调用的类名，比如dao层某个类<br/>
		 * Notice: 获取该参数需要设置{@linkplain Configuration#setPack(String)}，否则为Null
		 * @return
		 */
		String getClassName();
		
		/**
		 * 获取调用的方法名称，比如dao层某类中某个方法<br/>
		 * Notice: 获取该参数需要设置{@linkplain Configuration#setPack(String)}，否则为Null
		 * @return
		 */
		String getMethodName();
		
	}
	
}
