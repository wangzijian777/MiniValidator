package com.jd.ka.common.db.monitor.stat;

import com.jd.ka.common.db.monitor.Configuration;
import com.jd.ka.common.db.monitor.SQLMonitor.MonitorParam;
import com.jd.ka.common.db.monitor.util.MD5Util;

/**
 * 
 * @author qiulong
 *
 */
class SQLStatBeanImpl implements SQLStatBean {
	private final Configuration conf;
	private final MonitorParam param;
	private final String id;

	public SQLStatBeanImpl(Configuration conf, MonitorParam param) {
		this.conf = conf;
		this.param = param;
		this.id = MD5Util.md5Hex(param.getSQL());
	}
	@Override
	public String getSQL() {
		return param.getSQL();
	}

	@Override
	public long getSTTime() {
		return param.getSTTime();
	}

	@Override
	public long getEDTime() {
		return param.getEDTime();
	}

	@Override
	public long getElapsedTime() {
		return param.getElapsedTime();
	}

	@Override
	public boolean hasException() {
		return param.hasException();
	}

	@Override
	public String getClassName() {
		return param.getClassName();
	}

	@Override
	public String getMethodName() {
		return param.getMethodName();
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public Configuration getConfiguration() {
		return conf;
	}

}
