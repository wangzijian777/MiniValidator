/*
	File: Configuration.java
	Date			Author		Changes
	2015年4月2日		qiulong		Create
 */
package com.jd.ka.common.db.monitor;


/**
 * @author qiulong
 *
 */
public class Configuration {
	private SQLMonitor monitor;
	private String pack;
	private boolean debug;
	
	/**
	 * 后去自定义监控处理
	 * @return
	 */
	public SQLMonitor getMonitor() {
		return monitor;
	}

	/**
	 * 自定义监控处理
	 * @param alarm
	 */
	public void setMonitor(SQLMonitor monitor) {
		this.monitor = monitor;
	}

	/**
	 * 获取监控SQL包路径，可用于获取调用栈相关信息
	 * @return
	 */
	public String getPack() {
		return pack;
	}

	/**
	 * 设置监控SQL包路径，可用于获取调用栈相关信息
	 * @return
	 */
	public void setPack(String pack) {
		this.pack = pack;
	}

	/**
	 * 是否启用了debug模式
	 * @return
	 */
	public boolean isDebug() {
		return debug;
	}

	/**
	 * 设置debug=true模式后，{@linkplain SQLMonitor.MonitorParam#getSQL()}SQL语句中的占位符'?'将被实际参数替换。
	 * @param debug
	 */
	public void setDebug(boolean debug) {
		this.debug = debug;
	}

}
