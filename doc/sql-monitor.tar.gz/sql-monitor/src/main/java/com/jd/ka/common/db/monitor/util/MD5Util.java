package com.jd.ka.common.db.monitor.util;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 
 * @author qiulong
 *
 */
public class MD5Util {

	public static String md5Hex(String data) {
		return Hex.encodeHexString(md5(data));
	}
	
	public static byte[] md5(String data) {
		return md5(getBytesUtf8(data));
	}

	private static byte[] md5(byte[] data) {
		try {
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			return md5.digest(data);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage());
		}
	}
	
	 private static byte[] getBytesUtf8(String data) {
		 if(data == null) {
			 return null;
		 }
        return data.getBytes(Charset.forName("UTF-8"));
    }

}
