/*
	File: CallableStatementWrapper.java
	Date			Author		Changes
	2015年4月3日		qiulong		Create
 */
package com.jd.ka.common.db.monitor.base;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;

/**
 * @author qiulong
 *
 */
abstract class CallableStatementWrapper extends StatementMonitor implements CallableStatement {
	private final CallableStatement state;
	
	public CallableStatementWrapper(final CallableStatement state, final SqlMonitorable monitor) {
		super(state, monitor);
		this.state = state;
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		return state.unwrap(iface);
	}

	public ResultSet executeQuery(String sql) throws SQLException {
		return state.executeQuery(sql);
	}

	public ResultSet executeQuery() throws SQLException {
		return state.executeQuery();
	}

	public void registerOutParameter(int parameterIndex, int sqlType)
			throws SQLException {
		state.registerOutParameter(parameterIndex, sqlType);
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return state.isWrapperFor(iface);
	}

	public int executeUpdate(String sql) throws SQLException {
		return state.executeUpdate(sql);
	}

	public int executeUpdate() throws SQLException {
		return state.executeUpdate();
	}

	public void setNull(int parameterIndex, int sqlType) throws SQLException {
		state.setNull(parameterIndex, sqlType);
	}

	public void close() throws SQLException {
		state.close();
	}

	public void registerOutParameter(int parameterIndex, int sqlType, int scale)
			throws SQLException {
		state.registerOutParameter(parameterIndex, sqlType, scale);
	}

	public int getMaxFieldSize() throws SQLException {
		return state.getMaxFieldSize();
	}

	public void setBoolean(int parameterIndex, boolean x) throws SQLException {
		state.setBoolean(parameterIndex, x);
	}

	public void setByte(int parameterIndex, byte x) throws SQLException {
		state.setByte(parameterIndex, x);
	}

	public void setMaxFieldSize(int max) throws SQLException {
		state.setMaxFieldSize(max);
	}

	public boolean wasNull() throws SQLException {
		return state.wasNull();
	}

	public void setShort(int parameterIndex, short x) throws SQLException {
		state.setShort(parameterIndex, x);
	}

	public String getString(int parameterIndex) throws SQLException {
		return state.getString(parameterIndex);
	}

	public int getMaxRows() throws SQLException {
		return state.getMaxRows();
	}

	public void setInt(int parameterIndex, int x) throws SQLException {
		state.setInt(parameterIndex, x);
	}

	public void setMaxRows(int max) throws SQLException {
		state.setMaxRows(max);
	}

	public void setLong(int parameterIndex, long x) throws SQLException {
		state.setLong(parameterIndex, x);
	}

	public boolean getBoolean(int parameterIndex) throws SQLException {
		return state.getBoolean(parameterIndex);
	}

	public void setEscapeProcessing(boolean enable) throws SQLException {
		state.setEscapeProcessing(enable);
	}

	public void setFloat(int parameterIndex, float x) throws SQLException {
		state.setFloat(parameterIndex, x);
	}

	public byte getByte(int parameterIndex) throws SQLException {
		return state.getByte(parameterIndex);
	}

	public void setDouble(int parameterIndex, double x) throws SQLException {
		state.setDouble(parameterIndex, x);
	}

	public int getQueryTimeout() throws SQLException {
		return state.getQueryTimeout();
	}

	public short getShort(int parameterIndex) throws SQLException {
		return state.getShort(parameterIndex);
	}

	public void setQueryTimeout(int seconds) throws SQLException {
		state.setQueryTimeout(seconds);
	}

	public void setBigDecimal(int parameterIndex, BigDecimal x)
			throws SQLException {
		state.setBigDecimal(parameterIndex, x);
	}

	public int getInt(int parameterIndex) throws SQLException {
		return state.getInt(parameterIndex);
	}

	public void setString(int parameterIndex, String x) throws SQLException {
		state.setString(parameterIndex, x);
	}

	public long getLong(int parameterIndex) throws SQLException {
		return state.getLong(parameterIndex);
	}

	public void setBytes(int parameterIndex, byte[] x) throws SQLException {
		state.setBytes(parameterIndex, x);
	}

	public float getFloat(int parameterIndex) throws SQLException {
		return state.getFloat(parameterIndex);
	}

	public void cancel() throws SQLException {
		state.cancel();
	}

	public SQLWarning getWarnings() throws SQLException {
		return state.getWarnings();
	}

	public double getDouble(int parameterIndex) throws SQLException {
		return state.getDouble(parameterIndex);
	}

	public void setDate(int parameterIndex, Date x) throws SQLException {
		state.setDate(parameterIndex, x);
	}

	@Deprecated
	public BigDecimal getBigDecimal(int parameterIndex, int scale)
			throws SQLException {
		return state.getBigDecimal(parameterIndex, scale);
	}

	public void setTime(int parameterIndex, Time x) throws SQLException {
		state.setTime(parameterIndex, x);
	}

	public void clearWarnings() throws SQLException {
		state.clearWarnings();
	}

	public void setCursorName(String name) throws SQLException {
		state.setCursorName(name);
	}

	public void setTimestamp(int parameterIndex, Timestamp x)
			throws SQLException {
		state.setTimestamp(parameterIndex, x);
	}

	public byte[] getBytes(int parameterIndex) throws SQLException {
		return state.getBytes(parameterIndex);
	}

	public void setAsciiStream(int parameterIndex, InputStream x, int length)
			throws SQLException {
		state.setAsciiStream(parameterIndex, x, length);
	}

	public Date getDate(int parameterIndex) throws SQLException {
		return state.getDate(parameterIndex);
	}

	public boolean execute(String sql) throws SQLException {
		return state.execute(sql);
	}

	public Time getTime(int parameterIndex) throws SQLException {
		return state.getTime(parameterIndex);
	}

	@Deprecated
	public void setUnicodeStream(int parameterIndex, InputStream x, int length)
			throws SQLException {
		state.setUnicodeStream(parameterIndex, x, length);
	}

	public Timestamp getTimestamp(int parameterIndex) throws SQLException {
		return state.getTimestamp(parameterIndex);
	}

	public Object getObject(int parameterIndex) throws SQLException {
		return state.getObject(parameterIndex);
	}

	public ResultSet getResultSet() throws SQLException {
		return state.getResultSet();
	}

	public void setBinaryStream(int parameterIndex, InputStream x, int length)
			throws SQLException {
		state.setBinaryStream(parameterIndex, x, length);
	}

	public int getUpdateCount() throws SQLException {
		return state.getUpdateCount();
	}

	public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
		return state.getBigDecimal(parameterIndex);
	}

	public boolean getMoreResults() throws SQLException {
		return state.getMoreResults();
	}

	public void clearParameters() throws SQLException {
		state.clearParameters();
	}

	public Object getObject(int parameterIndex, Map<String, Class<?>> map)
			throws SQLException {
		return state.getObject(parameterIndex, map);
	}

	public void setObject(int parameterIndex, Object x, int targetSqlType)
			throws SQLException {
		state.setObject(parameterIndex, x, targetSqlType);
	}

	public void setFetchDirection(int direction) throws SQLException {
		state.setFetchDirection(direction);
	}

	public Ref getRef(int parameterIndex) throws SQLException {
		return state.getRef(parameterIndex);
	}

	public int getFetchDirection() throws SQLException {
		return state.getFetchDirection();
	}

	public void setObject(int parameterIndex, Object x) throws SQLException {
		state.setObject(parameterIndex, x);
	}

	public Blob getBlob(int parameterIndex) throws SQLException {
		return state.getBlob(parameterIndex);
	}

	public void setFetchSize(int rows) throws SQLException {
		state.setFetchSize(rows);
	}

	public Clob getClob(int parameterIndex) throws SQLException {
		return state.getClob(parameterIndex);
	}

	public int getFetchSize() throws SQLException {
		return state.getFetchSize();
	}

	public int getResultSetConcurrency() throws SQLException {
		return state.getResultSetConcurrency();
	}

	public Array getArray(int parameterIndex) throws SQLException {
		return state.getArray(parameterIndex);
	}

	public boolean execute() throws SQLException {
		return state.execute();
	}

	public int getResultSetType() throws SQLException {
		return state.getResultSetType();
	}

	public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
		return state.getDate(parameterIndex, cal);
	}

	public void addBatch(String sql) throws SQLException {
		state.addBatch(sql);
	}

	public void clearBatch() throws SQLException {
		state.clearBatch();
	}

	public void addBatch() throws SQLException {
		state.addBatch();
	}

	public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
		return state.getTime(parameterIndex, cal);
	}

	public int[] executeBatch() throws SQLException {
		return state.executeBatch();
	}

	public void setCharacterStream(int parameterIndex, Reader reader, int length)
			throws SQLException {
		state.setCharacterStream(parameterIndex, reader, length);
	}

	public Timestamp getTimestamp(int parameterIndex, Calendar cal)
			throws SQLException {
		return state.getTimestamp(parameterIndex, cal);
	}

	public void setRef(int parameterIndex, Ref x) throws SQLException {
		state.setRef(parameterIndex, x);
	}

	public void registerOutParameter(int parameterIndex, int sqlType,
			String typeName) throws SQLException {
		state.registerOutParameter(parameterIndex, sqlType, typeName);
	}

	public void setBlob(int parameterIndex, Blob x) throws SQLException {
		state.setBlob(parameterIndex, x);
	}

	public void setClob(int parameterIndex, Clob x) throws SQLException {
		state.setClob(parameterIndex, x);
	}

	public Connection getConnection() throws SQLException {
		return state.getConnection();
	}

	public void setArray(int parameterIndex, Array x) throws SQLException {
		state.setArray(parameterIndex, x);
	}

	public void registerOutParameter(String parameterName, int sqlType)
			throws SQLException {
		state.registerOutParameter(parameterName, sqlType);
	}

	public ResultSetMetaData getMetaData() throws SQLException {
		return state.getMetaData();
	}

	public boolean getMoreResults(int current) throws SQLException {
		return state.getMoreResults(current);
	}

	public void setDate(int parameterIndex, Date x, Calendar cal)
			throws SQLException {
		state.setDate(parameterIndex, x, cal);
	}

	public void registerOutParameter(String parameterName, int sqlType,
			int scale) throws SQLException {
		state.registerOutParameter(parameterName, sqlType, scale);
	}

	public ResultSet getGeneratedKeys() throws SQLException {
		return state.getGeneratedKeys();
	}

	public void setTime(int parameterIndex, Time x, Calendar cal)
			throws SQLException {
		state.setTime(parameterIndex, x, cal);
	}

	public int executeUpdate(String sql, int autoGeneratedKeys)
			throws SQLException {
		return state.executeUpdate(sql, autoGeneratedKeys);
	}

	public void registerOutParameter(String parameterName, int sqlType,
			String typeName) throws SQLException {
		state.registerOutParameter(parameterName, sqlType, typeName);
	}

	public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
			throws SQLException {
		state.setTimestamp(parameterIndex, x, cal);
	}

	public void setNull(int parameterIndex, int sqlType, String typeName)
			throws SQLException {
		state.setNull(parameterIndex, sqlType, typeName);
	}

	public int executeUpdate(String sql, int[] columnIndexes)
			throws SQLException {
		return state.executeUpdate(sql, columnIndexes);
	}

	public URL getURL(int parameterIndex) throws SQLException {
		return state.getURL(parameterIndex);
	}

	public void setURL(String parameterName, URL val) throws SQLException {
		state.setURL(parameterName, val);
	}

	public void setURL(int parameterIndex, URL x) throws SQLException {
		state.setURL(parameterIndex, x);
	}

	public void setNull(String parameterName, int sqlType) throws SQLException {
		state.setNull(parameterName, sqlType);
	}

	public int executeUpdate(String sql, String[] columnNames)
			throws SQLException {
		return state.executeUpdate(sql, columnNames);
	}

	public ParameterMetaData getParameterMetaData() throws SQLException {
		return state.getParameterMetaData();
	}

	public void setBoolean(String parameterName, boolean x) throws SQLException {
		state.setBoolean(parameterName, x);
	}

	public void setRowId(int parameterIndex, RowId x) throws SQLException {
		state.setRowId(parameterIndex, x);
	}

	public void setByte(String parameterName, byte x) throws SQLException {
		state.setByte(parameterName, x);
	}

	public void setNString(int parameterIndex, String value)
			throws SQLException {
		state.setNString(parameterIndex, value);
	}

	public void setShort(String parameterName, short x) throws SQLException {
		state.setShort(parameterName, x);
	}

	public boolean execute(String sql, int autoGeneratedKeys)
			throws SQLException {
		return state.execute(sql, autoGeneratedKeys);
	}

	public void setNCharacterStream(int parameterIndex, Reader value,
			long length) throws SQLException {
		state.setNCharacterStream(parameterIndex, value, length);
	}

	public void setInt(String parameterName, int x) throws SQLException {
		state.setInt(parameterName, x);
	}

	public void setLong(String parameterName, long x) throws SQLException {
		state.setLong(parameterName, x);
	}

	public void setNClob(int parameterIndex, NClob value) throws SQLException {
		state.setNClob(parameterIndex, value);
	}

	public void setFloat(String parameterName, float x) throws SQLException {
		state.setFloat(parameterName, x);
	}

	public void setClob(int parameterIndex, Reader reader, long length)
			throws SQLException {
		state.setClob(parameterIndex, reader, length);
	}

	public void setDouble(String parameterName, double x) throws SQLException {
		state.setDouble(parameterName, x);
	}

	public boolean execute(String sql, int[] columnIndexes) throws SQLException {
		return state.execute(sql, columnIndexes);
	}

	public void setBigDecimal(String parameterName, BigDecimal x)
			throws SQLException {
		state.setBigDecimal(parameterName, x);
	}

	public void setBlob(int parameterIndex, InputStream inputStream, long length)
			throws SQLException {
		state.setBlob(parameterIndex, inputStream, length);
	}

	public void setString(String parameterName, String x) throws SQLException {
		state.setString(parameterName, x);
	}

	public void setBytes(String parameterName, byte[] x) throws SQLException {
		state.setBytes(parameterName, x);
	}

	public void setNClob(int parameterIndex, Reader reader, long length)
			throws SQLException {
		state.setNClob(parameterIndex, reader, length);
	}

	public boolean execute(String sql, String[] columnNames)
			throws SQLException {
		return state.execute(sql, columnNames);
	}

	public void setDate(String parameterName, Date x) throws SQLException {
		state.setDate(parameterName, x);
	}

	public void setTime(String parameterName, Time x) throws SQLException {
		state.setTime(parameterName, x);
	}

	public void setSQLXML(int parameterIndex, SQLXML xmlObject)
			throws SQLException {
		state.setSQLXML(parameterIndex, xmlObject);
	}

	public void setTimestamp(String parameterName, Timestamp x)
			throws SQLException {
		state.setTimestamp(parameterName, x);
	}

	public void setObject(int parameterIndex, Object x, int targetSqlType,
			int scaleOrLength) throws SQLException {
		state.setObject(parameterIndex, x, targetSqlType, scaleOrLength);
	}

	public int getResultSetHoldability() throws SQLException {
		return state.getResultSetHoldability();
	}

	public void setAsciiStream(String parameterName, InputStream x, int length)
			throws SQLException {
		state.setAsciiStream(parameterName, x, length);
	}

	public boolean isClosed() throws SQLException {
		return state.isClosed();
	}

	public void setPoolable(boolean poolable) throws SQLException {
		state.setPoolable(poolable);
	}

	public void setBinaryStream(String parameterName, InputStream x, int length)
			throws SQLException {
		state.setBinaryStream(parameterName, x, length);
	}

	public boolean isPoolable() throws SQLException {
		return state.isPoolable();
	}

	public void setObject(String parameterName, Object x, int targetSqlType,
			int scale) throws SQLException {
		state.setObject(parameterName, x, targetSqlType, scale);
	}

	public void closeOnCompletion() throws SQLException {
		throw new UnsupportedOperationException();
	}

	public void setAsciiStream(int parameterIndex, InputStream x, long length)
			throws SQLException {
		state.setAsciiStream(parameterIndex, x, length);
	}

	public boolean isCloseOnCompletion() throws SQLException {
		throw new UnsupportedOperationException();
	}

	public void setBinaryStream(int parameterIndex, InputStream x, long length)
			throws SQLException {
		state.setBinaryStream(parameterIndex, x, length);
	}

	public void setObject(String parameterName, Object x, int targetSqlType)
			throws SQLException {
		state.setObject(parameterName, x, targetSqlType);
	}

	public void setCharacterStream(int parameterIndex, Reader reader,
			long length) throws SQLException {
		state.setCharacterStream(parameterIndex, reader, length);
	}

	public void setObject(String parameterName, Object x) throws SQLException {
		state.setObject(parameterName, x);
	}

	public void setAsciiStream(int parameterIndex, InputStream x)
			throws SQLException {
		state.setAsciiStream(parameterIndex, x);
	}

	public void setBinaryStream(int parameterIndex, InputStream x)
			throws SQLException {
		state.setBinaryStream(parameterIndex, x);
	}

	public void setCharacterStream(String parameterName, Reader reader,
			int length) throws SQLException {
		state.setCharacterStream(parameterName, reader, length);
	}

	public void setCharacterStream(int parameterIndex, Reader reader)
			throws SQLException {
		state.setCharacterStream(parameterIndex, reader);
	}

	public void setDate(String parameterName, Date x, Calendar cal)
			throws SQLException {
		state.setDate(parameterName, x, cal);
	}

	public void setNCharacterStream(int parameterIndex, Reader value)
			throws SQLException {
		state.setNCharacterStream(parameterIndex, value);
	}

	public void setTime(String parameterName, Time x, Calendar cal)
			throws SQLException {
		state.setTime(parameterName, x, cal);
	}

	public void setClob(int parameterIndex, Reader reader) throws SQLException {
		state.setClob(parameterIndex, reader);
	}

	public void setTimestamp(String parameterName, Timestamp x, Calendar cal)
			throws SQLException {
		state.setTimestamp(parameterName, x, cal);
	}

	public void setNull(String parameterName, int sqlType, String typeName)
			throws SQLException {
		state.setNull(parameterName, sqlType, typeName);
	}

	public void setBlob(int parameterIndex, InputStream inputStream)
			throws SQLException {
		state.setBlob(parameterIndex, inputStream);
	}

	public void setNClob(int parameterIndex, Reader reader) throws SQLException {
		state.setNClob(parameterIndex, reader);
	}

	public String getString(String parameterName) throws SQLException {
		return state.getString(parameterName);
	}

	public boolean getBoolean(String parameterName) throws SQLException {
		return state.getBoolean(parameterName);
	}

	public byte getByte(String parameterName) throws SQLException {
		return state.getByte(parameterName);
	}

	public short getShort(String parameterName) throws SQLException {
		return state.getShort(parameterName);
	}

	public int getInt(String parameterName) throws SQLException {
		return state.getInt(parameterName);
	}

	public long getLong(String parameterName) throws SQLException {
		return state.getLong(parameterName);
	}

	public float getFloat(String parameterName) throws SQLException {
		return state.getFloat(parameterName);
	}

	public double getDouble(String parameterName) throws SQLException {
		return state.getDouble(parameterName);
	}

	public byte[] getBytes(String parameterName) throws SQLException {
		return state.getBytes(parameterName);
	}

	public Date getDate(String parameterName) throws SQLException {
		return state.getDate(parameterName);
	}

	public Time getTime(String parameterName) throws SQLException {
		return state.getTime(parameterName);
	}

	public Timestamp getTimestamp(String parameterName) throws SQLException {
		return state.getTimestamp(parameterName);
	}

	public Object getObject(String parameterName) throws SQLException {
		return state.getObject(parameterName);
	}

	public BigDecimal getBigDecimal(String parameterName) throws SQLException {
		return state.getBigDecimal(parameterName);
	}

	public Object getObject(String parameterName, Map<String, Class<?>> map)
			throws SQLException {
		return state.getObject(parameterName, map);
	}

	public Ref getRef(String parameterName) throws SQLException {
		return state.getRef(parameterName);
	}

	public Blob getBlob(String parameterName) throws SQLException {
		return state.getBlob(parameterName);
	}

	public Clob getClob(String parameterName) throws SQLException {
		return state.getClob(parameterName);
	}

	public Array getArray(String parameterName) throws SQLException {
		return state.getArray(parameterName);
	}

	public Date getDate(String parameterName, Calendar cal) throws SQLException {
		return state.getDate(parameterName, cal);
	}

	public Time getTime(String parameterName, Calendar cal) throws SQLException {
		return state.getTime(parameterName, cal);
	}

	public Timestamp getTimestamp(String parameterName, Calendar cal)
			throws SQLException {
		return state.getTimestamp(parameterName, cal);
	}

	public URL getURL(String parameterName) throws SQLException {
		return state.getURL(parameterName);
	}

	public RowId getRowId(int parameterIndex) throws SQLException {
		return state.getRowId(parameterIndex);
	}

	public RowId getRowId(String parameterName) throws SQLException {
		return state.getRowId(parameterName);
	}

	public void setRowId(String parameterName, RowId x) throws SQLException {
		state.setRowId(parameterName, x);
	}

	public void setNString(String parameterName, String value)
			throws SQLException {
		state.setNString(parameterName, value);
	}

	public void setNCharacterStream(String parameterName, Reader value,
			long length) throws SQLException {
		state.setNCharacterStream(parameterName, value, length);
	}

	public void setNClob(String parameterName, NClob value) throws SQLException {
		state.setNClob(parameterName, value);
	}

	public void setClob(String parameterName, Reader reader, long length)
			throws SQLException {
		state.setClob(parameterName, reader, length);
	}

	public void setBlob(String parameterName, InputStream inputStream,
			long length) throws SQLException {
		state.setBlob(parameterName, inputStream, length);
	}

	public void setNClob(String parameterName, Reader reader, long length)
			throws SQLException {
		state.setNClob(parameterName, reader, length);
	}

	public NClob getNClob(int parameterIndex) throws SQLException {
		return state.getNClob(parameterIndex);
	}

	public NClob getNClob(String parameterName) throws SQLException {
		return state.getNClob(parameterName);
	}

	public void setSQLXML(String parameterName, SQLXML xmlObject)
			throws SQLException {
		state.setSQLXML(parameterName, xmlObject);
	}

	public SQLXML getSQLXML(int parameterIndex) throws SQLException {
		return state.getSQLXML(parameterIndex);
	}

	public SQLXML getSQLXML(String parameterName) throws SQLException {
		return state.getSQLXML(parameterName);
	}

	public String getNString(int parameterIndex) throws SQLException {
		return state.getNString(parameterIndex);
	}

	public String getNString(String parameterName) throws SQLException {
		return state.getNString(parameterName);
	}

	public Reader getNCharacterStream(int parameterIndex) throws SQLException {
		return state.getNCharacterStream(parameterIndex);
	}

	public Reader getNCharacterStream(String parameterName) throws SQLException {
		return state.getNCharacterStream(parameterName);
	}

	public Reader getCharacterStream(int parameterIndex) throws SQLException {
		return state.getCharacterStream(parameterIndex);
	}

	public Reader getCharacterStream(String parameterName) throws SQLException {
		return state.getCharacterStream(parameterName);
	}

	public void setBlob(String parameterName, Blob x) throws SQLException {
		state.setBlob(parameterName, x);
	}

	public void setClob(String parameterName, Clob x) throws SQLException {
		state.setClob(parameterName, x);
	}

	public void setAsciiStream(String parameterName, InputStream x, long length)
			throws SQLException {
		state.setAsciiStream(parameterName, x, length);
	}

	public void setBinaryStream(String parameterName, InputStream x, long length)
			throws SQLException {
		state.setBinaryStream(parameterName, x, length);
	}

	public void setCharacterStream(String parameterName, Reader reader,
			long length) throws SQLException {
		state.setCharacterStream(parameterName, reader, length);
	}

	public void setAsciiStream(String parameterName, InputStream x)
			throws SQLException {
		state.setAsciiStream(parameterName, x);
	}

	public void setBinaryStream(String parameterName, InputStream x)
			throws SQLException {
		state.setBinaryStream(parameterName, x);
	}

	public void setCharacterStream(String parameterName, Reader reader)
			throws SQLException {
		state.setCharacterStream(parameterName, reader);
	}

	public void setNCharacterStream(String parameterName, Reader value)
			throws SQLException {
		state.setNCharacterStream(parameterName, value);
	}

	public void setClob(String parameterName, Reader reader)
			throws SQLException {
		state.setClob(parameterName, reader);
	}

	public void setBlob(String parameterName, InputStream inputStream)
			throws SQLException {
		state.setBlob(parameterName, inputStream);
	}

	public void setNClob(String parameterName, Reader reader)
			throws SQLException {
		state.setNClob(parameterName, reader);
	}

	public <T> T getObject(int parameterIndex, Class<T> type)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public <T> T getObject(String parameterName, Class<T> type)
			throws SQLException {
		throw new UnsupportedOperationException();
	}


}
