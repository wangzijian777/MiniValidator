/*
	File: PreparedStatementWrapper.java
	Date			Author		Changes
	2015年4月3日		qiulong		Create
 */
package com.jd.ka.common.db.monitor.base;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

/**
 * @author qiulong
 *
 */
abstract class PreparedStatementWrapper extends StatementMonitor implements PreparedStatement {
	private final PreparedStatement state;

	public PreparedStatementWrapper(final PreparedStatement state, final SqlMonitorable monitor) {
		super(state, monitor);
		this.state = state;
	}

	public <T> T unwrap(Class<T> iface) throws SQLException {
		return state.unwrap(iface);
	}

	public ResultSet executeQuery(String sql) throws SQLException {
		return state.executeQuery(sql);
	}

	public ResultSet executeQuery() throws SQLException {
		return state.executeQuery();
	}

	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		return state.isWrapperFor(iface);
	}

	public int executeUpdate(String sql) throws SQLException {
		return state.executeUpdate(sql);
	}

	public int executeUpdate() throws SQLException {
		return state.executeUpdate();
	}

	public void setNull(int parameterIndex, int sqlType) throws SQLException {
		state.setNull(parameterIndex, sqlType);
	}

	public void close() throws SQLException {
		state.close();
	}

	public int getMaxFieldSize() throws SQLException {
		return state.getMaxFieldSize();
	}

	public void setBoolean(int parameterIndex, boolean x) throws SQLException {
		state.setBoolean(parameterIndex, x);
	}

	public void setByte(int parameterIndex, byte x) throws SQLException {
		state.setByte(parameterIndex, x);
	}

	public void setMaxFieldSize(int max) throws SQLException {
		state.setMaxFieldSize(max);
	}

	public void setShort(int parameterIndex, short x) throws SQLException {
		state.setShort(parameterIndex, x);
	}

	public int getMaxRows() throws SQLException {
		return state.getMaxRows();
	}

	public void setInt(int parameterIndex, int x) throws SQLException {
		state.setInt(parameterIndex, x);
	}

	public void setMaxRows(int max) throws SQLException {
		state.setMaxRows(max);
	}

	public void setLong(int parameterIndex, long x) throws SQLException {
		state.setLong(parameterIndex, x);
	}

	public void setEscapeProcessing(boolean enable) throws SQLException {
		state.setEscapeProcessing(enable);
	}

	public void setFloat(int parameterIndex, float x) throws SQLException {
		state.setFloat(parameterIndex, x);
	}

	public void setDouble(int parameterIndex, double x) throws SQLException {
		state.setDouble(parameterIndex, x);
	}

	public int getQueryTimeout() throws SQLException {
		return state.getQueryTimeout();
	}

	public void setQueryTimeout(int seconds) throws SQLException {
		state.setQueryTimeout(seconds);
	}

	public void setBigDecimal(int parameterIndex, BigDecimal x)
			throws SQLException {
		state.setBigDecimal(parameterIndex, x);
	}

	public void setString(int parameterIndex, String x) throws SQLException {
		state.setString(parameterIndex, x);
	}

	public void setBytes(int parameterIndex, byte[] x) throws SQLException {
		state.setBytes(parameterIndex, x);
	}

	public void cancel() throws SQLException {
		state.cancel();
	}

	public SQLWarning getWarnings() throws SQLException {
		return state.getWarnings();
	}

	public void setDate(int parameterIndex, Date x) throws SQLException {
		state.setDate(parameterIndex, x);
	}

	public void setTime(int parameterIndex, Time x) throws SQLException {
		state.setTime(parameterIndex, x);
	}

	public void clearWarnings() throws SQLException {
		state.clearWarnings();
	}

	public void setCursorName(String name) throws SQLException {
		state.setCursorName(name);
	}

	public void setTimestamp(int parameterIndex, Timestamp x)
			throws SQLException {
		state.setTimestamp(parameterIndex, x);
	}

	public void setAsciiStream(int parameterIndex, InputStream x, int length)
			throws SQLException {
		state.setAsciiStream(parameterIndex, x, length);
	}

	public boolean execute(String sql) throws SQLException {
		return state.execute(sql);
	}

	@Deprecated
	public void setUnicodeStream(int parameterIndex, InputStream x, int length)
			throws SQLException {
		state.setUnicodeStream(parameterIndex, x, length);
	}

	public ResultSet getResultSet() throws SQLException {
		return state.getResultSet();
	}

	public void setBinaryStream(int parameterIndex, InputStream x, int length)
			throws SQLException {
		state.setBinaryStream(parameterIndex, x, length);
	}

	public int getUpdateCount() throws SQLException {
		return state.getUpdateCount();
	}

	public boolean getMoreResults() throws SQLException {
		return state.getMoreResults();
	}

	public void clearParameters() throws SQLException {
		state.clearParameters();
	}

	public void setObject(int parameterIndex, Object x, int targetSqlType)
			throws SQLException {
		state.setObject(parameterIndex, x, targetSqlType);
	}

	public void setFetchDirection(int direction) throws SQLException {
		state.setFetchDirection(direction);
	}

	public int getFetchDirection() throws SQLException {
		return state.getFetchDirection();
	}

	public void setObject(int parameterIndex, Object x) throws SQLException {
		state.setObject(parameterIndex, x);
	}

	public void setFetchSize(int rows) throws SQLException {
		state.setFetchSize(rows);
	}

	public int getFetchSize() throws SQLException {
		return state.getFetchSize();
	}

	public int getResultSetConcurrency() throws SQLException {
		return state.getResultSetConcurrency();
	}

	public boolean execute() throws SQLException {
		return state.execute();
	}

	public int getResultSetType() throws SQLException {
		return state.getResultSetType();
	}

	public void addBatch(String sql) throws SQLException {
		state.addBatch(sql);
	}

	public void clearBatch() throws SQLException {
		state.clearBatch();
	}

	public void addBatch() throws SQLException {
		state.addBatch();
	}

	public int[] executeBatch() throws SQLException {
		return state.executeBatch();
	}

	public void setCharacterStream(int parameterIndex, Reader reader, int length)
			throws SQLException {
		state.setCharacterStream(parameterIndex, reader, length);
	}

	public void setRef(int parameterIndex, Ref x) throws SQLException {
		state.setRef(parameterIndex, x);
	}

	public void setBlob(int parameterIndex, Blob x) throws SQLException {
		state.setBlob(parameterIndex, x);
	}

	public void setClob(int parameterIndex, Clob x) throws SQLException {
		state.setClob(parameterIndex, x);
	}

	public Connection getConnection() throws SQLException {
		return state.getConnection();
	}

	public void setArray(int parameterIndex, Array x) throws SQLException {
		state.setArray(parameterIndex, x);
	}

	public ResultSetMetaData getMetaData() throws SQLException {
		return state.getMetaData();
	}

	public boolean getMoreResults(int current) throws SQLException {
		return state.getMoreResults(current);
	}

	public void setDate(int parameterIndex, Date x, Calendar cal)
			throws SQLException {
		state.setDate(parameterIndex, x, cal);
	}

	public ResultSet getGeneratedKeys() throws SQLException {
		return state.getGeneratedKeys();
	}

	public void setTime(int parameterIndex, Time x, Calendar cal)
			throws SQLException {
		state.setTime(parameterIndex, x, cal);
	}

	public int executeUpdate(String sql, int autoGeneratedKeys)
			throws SQLException {
		return state.executeUpdate(sql, autoGeneratedKeys);
	}

	public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
			throws SQLException {
		state.setTimestamp(parameterIndex, x, cal);
	}

	public void setNull(int parameterIndex, int sqlType, String typeName)
			throws SQLException {
		state.setNull(parameterIndex, sqlType, typeName);
	}

	public int executeUpdate(String sql, int[] columnIndexes)
			throws SQLException {
		return state.executeUpdate(sql, columnIndexes);
	}

	public void setURL(int parameterIndex, URL x) throws SQLException {
		state.setURL(parameterIndex, x);
	}

	public int executeUpdate(String sql, String[] columnNames)
			throws SQLException {
		return state.executeUpdate(sql, columnNames);
	}

	public ParameterMetaData getParameterMetaData() throws SQLException {
		return state.getParameterMetaData();
	}

	public void setRowId(int parameterIndex, RowId x) throws SQLException {
		state.setRowId(parameterIndex, x);
	}

	public void setNString(int parameterIndex, String value)
			throws SQLException {
		state.setNString(parameterIndex, value);
	}

	public boolean execute(String sql, int autoGeneratedKeys)
			throws SQLException {
		return state.execute(sql, autoGeneratedKeys);
	}

	public void setNCharacterStream(int parameterIndex, Reader value,
			long length) throws SQLException {
		state.setNCharacterStream(parameterIndex, value, length);
	}

	public void setNClob(int parameterIndex, NClob value) throws SQLException {
		state.setNClob(parameterIndex, value);
	}

	public void setClob(int parameterIndex, Reader reader, long length)
			throws SQLException {
		state.setClob(parameterIndex, reader, length);
	}

	public boolean execute(String sql, int[] columnIndexes) throws SQLException {
		return state.execute(sql, columnIndexes);
	}

	public void setBlob(int parameterIndex, InputStream inputStream, long length)
			throws SQLException {
		state.setBlob(parameterIndex, inputStream, length);
	}

	public void setNClob(int parameterIndex, Reader reader, long length)
			throws SQLException {
		state.setNClob(parameterIndex, reader, length);
	}

	public boolean execute(String sql, String[] columnNames)
			throws SQLException {
		return state.execute(sql, columnNames);
	}

	public void setSQLXML(int parameterIndex, SQLXML xmlObject)
			throws SQLException {
		state.setSQLXML(parameterIndex, xmlObject);
	}

	public void setObject(int parameterIndex, Object x, int targetSqlType,
			int scaleOrLength) throws SQLException {
		state.setObject(parameterIndex, x, targetSqlType, scaleOrLength);
	}

	public int getResultSetHoldability() throws SQLException {
		return state.getResultSetHoldability();
	}

	public boolean isClosed() throws SQLException {
		return state.isClosed();
	}

	public void setPoolable(boolean poolable) throws SQLException {
		state.setPoolable(poolable);
	}

	public boolean isPoolable() throws SQLException {
		return state.isPoolable();
	}

	public void closeOnCompletion() throws SQLException {
		throw new UnsupportedOperationException();
	}

	public void setAsciiStream(int parameterIndex, InputStream x, long length)
			throws SQLException {
		state.setAsciiStream(parameterIndex, x, length);
	}

	public boolean isCloseOnCompletion() throws SQLException {
		throw new UnsupportedOperationException();
	}

	public void setBinaryStream(int parameterIndex, InputStream x, long length)
			throws SQLException {
		state.setBinaryStream(parameterIndex, x, length);
	}

	public void setCharacterStream(int parameterIndex, Reader reader,
			long length) throws SQLException {
		state.setCharacterStream(parameterIndex, reader, length);
	}

	public void setAsciiStream(int parameterIndex, InputStream x)
			throws SQLException {
		state.setAsciiStream(parameterIndex, x);
	}

	public void setBinaryStream(int parameterIndex, InputStream x)
			throws SQLException {
		state.setBinaryStream(parameterIndex, x);
	}

	public void setCharacterStream(int parameterIndex, Reader reader)
			throws SQLException {
		state.setCharacterStream(parameterIndex, reader);
	}

	public void setNCharacterStream(int parameterIndex, Reader value)
			throws SQLException {
		state.setNCharacterStream(parameterIndex, value);
	}

	public void setClob(int parameterIndex, Reader reader) throws SQLException {
		state.setClob(parameterIndex, reader);
	}

	public void setBlob(int parameterIndex, InputStream inputStream)
			throws SQLException {
		state.setBlob(parameterIndex, inputStream);
	}

	public void setNClob(int parameterIndex, Reader reader) throws SQLException {
		state.setNClob(parameterIndex, reader);
	}
	

}
