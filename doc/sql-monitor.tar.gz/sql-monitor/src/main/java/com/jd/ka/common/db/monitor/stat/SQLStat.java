package com.jd.ka.common.db.monitor.stat;



interface SQLStat extends Restable {
	void doStat(SQLStatBean sqlStatBean);
	
	Object collect();
	
	StatType getStatType();
	
	enum StatType {
		HOT, TOP, SLOWLOG
	}
}
