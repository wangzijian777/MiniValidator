package com.jd.ka.common.db.monitor.stat;

/**
 * 数据可重置接口
 * @author qiulong
 *
 */
interface Restable {
	void reset();
}
