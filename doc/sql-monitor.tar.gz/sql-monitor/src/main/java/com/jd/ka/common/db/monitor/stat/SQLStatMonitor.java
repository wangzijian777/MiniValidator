package com.jd.ka.common.db.monitor.stat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jd.ka.common.db.monitor.Configuration;
import com.jd.ka.common.db.monitor.SQLMonitor;

/**
 * SQL监控统计
 * @author qiulong
 *
 */
public class SQLStatMonitor implements SQLMonitor, SQLStat {
	private SQLMonitor targetMonitor;
	private Configuration conf;
	private List<SQLStat> sqlStats = new ArrayList<SQLStat>();
	
	public SQLStatMonitor(Configuration conf) {
		targetMonitor = conf.getMonitor();
		this.conf = conf;
		init(conf);
		SQLStatService.init(this);
	}

	@Override
	public void monitoring(MonitorParam param) {
		try {
			doStat(new SQLStatBeanImpl(conf, param));
		} finally {
			targetMonitor.monitoring(param);
		}
	}
	
	@Override
	public void doStat(SQLStatBean sqlStatBean) {
		for (SQLStat sqlStat : sqlStats) {
			sqlStat.doStat(sqlStatBean);
		}
	}

	@Override
	public Object collect() {
		Map<String, Object> basket = new HashMap<String, Object>();
		for (SQLStat sqlStat : sqlStats) {
			basket.put(sqlStat.getStatType().toString(), sqlStat.collect());
		}
		return basket;
	}

	@Override
	public StatType getStatType() {
		throw new UnsupportedOperationException();
	}
	
	@Override
	public void reset() {
		for (SQLStat sqlStat : sqlStats) {
			sqlStat.reset();
		}
	}
	
	private void init(Configuration conf) {
		sqlStats.add(new TopSQLStat());
		sqlStats.add(new HotSQLStat());
		sqlStats.add(new SlowLogStat());
	}

}
