package com.jd.ka.common.db.monitor.stat;

import com.jd.ka.common.db.monitor.util.BackOffAtomicInteger;
import com.jd.ka.common.db.monitor.util.BackOffAtomicLong;

/**
 * 
 * @author qiulong
 *
 */
class SQLStatDataImpl implements SQLStatData {
	private String id;
	private String sql;
	private BackOffAtomicInteger exeCount = new BackOffAtomicInteger();
	private BackOffAtomicInteger exceptionCount = new BackOffAtomicInteger();
	private BackOffAtomicLong exeCountTime = new BackOffAtomicLong();
	private BackOffAtomicLong maxTime = new BackOffAtomicLong();
	
	SQLStatDataImpl(SQLStatBean sqlStatBean) {
		//没有直接使用SQLStatBean指针是因为防止SQLStatBean实例也被缓存，导致不能被垃圾回收
		this.id = sqlStatBean.getId();
		this.sql = sqlStatBean.getSQL();
	} 

	@Override
	public String getId() {
		return id;
	}

	@Override
	public String getSQL() {
		return sql;
	}

	@Override
	public long exeAvgTime() {
		//不是百分百的准确，因为执行此语句时exeCount和exeCountTime可能增长不一致
		return exeCountTime.get() / exeCount.get();
	}

	@Override
	public int exeCount() {
		return exeCount.get();
	}

	@Override
	public long exeMaxTime() {
		return maxTime.get();
	}

	@Override
	public int exceptionCount() {
		return exceptionCount.get();
	}
	
	public void addExeCount() {
		exeCount.incrementAndGet();
	}
	
	public void addExceptionCount() {
		exceptionCount.incrementAndGet();
	}
	
	public void addExeCountTime(long delta) {
		exeCountTime.addAndGet(delta);
	}
	
	public void setMaxTime(long time) {
		for (;;) {
            long max = maxTime.get();
            if (time > max) {
                if (maxTime.compareAndSet(max, time)) {
                    break;
                } else {
                    continue;
                }
            } else {
                break;
            }
        }
	}

	@Override
	public String toString() {
		return "[id=" + id + ", sql=" + sql + ", exeCount="
				+ exeCount.get() + ", exceptionCount=" + exceptionCount.get()
				+ ", avgTime=" + exeAvgTime() + ", maxTime=" + maxTime.get()
				+ "]";
	}
	
}
