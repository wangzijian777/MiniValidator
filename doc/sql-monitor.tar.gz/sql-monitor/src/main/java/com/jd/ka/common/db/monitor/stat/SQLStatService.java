package com.jd.ka.common.db.monitor.stat;

import java.util.Map;

/**
 * 
 * @author qiulong
 *
 */
public class SQLStatService {
	
	private static SQLStatService instance;
	private static volatile boolean inited = false;
	private final SQLStat sqlStat;
	
	public SQLStatService(SQLStat sqlStat) {
		this.sqlStat = sqlStat;
	}

	public synchronized static void init(SQLStat sqlStat) {
		if(instance == null) {
			instance = new SQLStatService(sqlStat);
			inited = true;
		}
	}
	
	public static SQLStatService getInstance() {
		if(!inited) {
			throw new IllegalStateException();
		}
		return instance;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> collectData() {
		Map<String, Object> data = (Map<String, Object>)sqlStat.collect();
		return data;
	}
	
	public void reset() {
		sqlStat.reset();
	}
}
