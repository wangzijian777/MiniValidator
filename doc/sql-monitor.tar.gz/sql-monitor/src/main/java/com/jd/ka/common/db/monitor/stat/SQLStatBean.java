package com.jd.ka.common.db.monitor.stat;

import com.jd.ka.common.db.monitor.Configuration;
import com.jd.ka.common.db.monitor.SQLMonitor.MonitorParam;

/**
 * 
 * @author qiulong
 *
 */
public interface SQLStatBean extends MonitorParam {

	String getId();
	
	Configuration getConfiguration();
	
}
