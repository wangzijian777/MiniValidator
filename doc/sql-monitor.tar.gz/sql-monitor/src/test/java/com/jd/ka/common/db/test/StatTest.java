package com.jd.ka.common.db.test;

import java.util.Map;
import java.util.concurrent.Phaser;

import org.junit.Test;

import com.jd.ka.common.db.monitor.stat.SQLStatService;

/**
 * 统计测试
 * @author qiulong
 *
 */
public class StatTest extends IbatisTest {
	
	@Test
	public void test_stat() {
		this.test_Delete();
		this.test_Insert();
		this.test_Query();
		Map<String, Object> collectData = SQLStatService.getInstance().collectData();
		System.out.println(collectData);
	}
	
	@Test
	public void teat_multiThread_stat() {
		int threadCount = 20;
		final Phaser phaser = new Phaser(threadCount);
		Thread[] threads = new Thread[threadCount];
		for (int i = 0; i < threadCount; i++) {
			threads[i] = new Thread(new Runnable() {
				@Override public void run() {
					//设置线程集合点
					phaser.arriveAndAwaitAdvance();
					int i = 100;
					while(i-- > 0) {
						StatTest.this.test_update();
						StatTest.this.test_Query();
					}
				}
			});
		}
		for (int i = 0; i < threadCount; i++) {
			threads[i].start();
		}
		//等待所有线程执行完成
		for (int i = 0; i < threadCount; i++) {
			try {
				threads[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(SQLStatService.getInstance().collectData());
	}

}
