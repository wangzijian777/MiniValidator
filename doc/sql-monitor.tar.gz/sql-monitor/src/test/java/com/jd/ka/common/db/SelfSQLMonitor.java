package com.jd.ka.common.db;

import com.jd.ka.common.db.monitor.SQLMonitor;

public class SelfSQLMonitor implements SQLMonitor {

	@Override
	public void monitoring(MonitorParam param) {
		StringBuilder sb = new StringBuilder("**********************\n");
		sb.append("SQL=" + param.getSQL());
		sb.append("\n");
		sb.append("ElapsedTime=" + param.getElapsedTime() + "ms");
		sb.append("\n");
		sb.append("method=" + param.getClassName() + "#" + param.getMethodName());
		sb.append("\n");
		sb.append("hasException=" + param.hasException());
		sb.append("\n**********************\n");
		System.out.println(sb);
	}

}
