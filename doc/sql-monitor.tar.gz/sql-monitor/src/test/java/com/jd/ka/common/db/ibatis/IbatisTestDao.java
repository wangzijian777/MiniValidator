package com.jd.ka.common.db.ibatis;

import java.util.HashMap;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

public class IbatisTestDao extends SqlMapClientTemplate {
	private static final String NAMESPACE = "IbatisTestDao.";

	public int query() {
		Object rs = this.queryForObject(NAMESPACE+"query", 1);
		return rs == null ? -1 : (Integer) rs;
	}
	
	public boolean update() {
		HashMap hashMap = new HashMap();
		hashMap.put("name", "test");
		hashMap.put("id", 1);
		return this.update(NAMESPACE+"update", hashMap) > 0;
	}
	
	public void exception() {
		this.queryForObject(NAMESPACE+"exception", 1);
	}
	
	public boolean insert() {
		HashMap hashMap = new HashMap();
		hashMap.put("name", "test");
		hashMap.put("id", 1);
		return this.update(NAMESPACE+"insert", hashMap) > 0;
	}
	
	public boolean delete() {
		return this.delete(NAMESPACE+"delete", 1) > 0;
	}
	
}
