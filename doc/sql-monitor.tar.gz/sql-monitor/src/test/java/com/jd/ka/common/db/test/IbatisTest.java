package com.jd.ka.common.db.test;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.ka.common.db.ibatis.IbatisTestDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring-config.xml", "classpath:ibatis/spring-ibatis.xml"}) 
public class IbatisTest {
	@Autowired
	private IbatisTestDao ibatisTestDao;
	
	@Test
	public void test_Delete() {
		ibatisTestDao.delete();
	}
	
	@Test
	public void test_Insert() {
		Assert.assertTrue(ibatisTestDao.insert());
	}

	@Test
	public void test_Query() {
		Assert.assertEquals(1, ibatisTestDao.query());
	}
	
	@Test
	public void test_update() {
		Assert.assertTrue(ibatisTestDao.update());
	}
	
	@Test(expected=DataAccessException.class)
	public void test_exception() {
		ibatisTestDao.exception();
	}

}
