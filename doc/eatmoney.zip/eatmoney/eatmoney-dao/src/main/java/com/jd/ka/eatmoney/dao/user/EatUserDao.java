
/**
 * Copyright(c) 2013-  www.jd.com
 *
 */
 package com.jd.ka.eatmoney.dao.user;

import java.util.List;
import com.jd.ka.eatmoney.domain.user.EatUser;
import java.util.Map;
/**
 * @author zhangshibin
 * @since 2015-1-19
 * 用户 Dao接口类
 */
public interface EatUserDao {
    
    
    
    	/**
     * 添加并返回设置id的EatUser对象
     * 
     * @param eatUser
     * @return
     */
    public int addEatUser(EatUser eatUser);
    
	/**
     * 更新EatUser
     * 
     * @param eatUser
     */
    public void updateEatUser(EatUser eatUser);
    
    
    

    /**
     * 根据主键删除EatUser
     * 
     * @param id
     */
    public void deleteEatUser(Integer id);


	/**
     * 根据主键获取EatUser
     * 
     * @param id
     * @return
     */	
    public EatUser getEatUserById(Integer id);
    

    
	
    /**
     * 取得所有EatUser
     * 
     * @return
     */
    public List<EatUser> getAll();
    
	/**
     * 根据example取得EatUser列表
     * 
     * @param  eatUser
     * @return
     */
    public List<EatUser> getListByExample(EatUser eatUser);
    
	/**
     * 分页取得EatUser列表
     * 
     * @param paramMap
     * @return
     */
    public List<EatUser> getEatUserByPage(Map<String,Object> paramMap);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param paramMap
     * @return
     */
    public int count(Map<String,Object> paramMap);

    public List<EatUser> getEatUserListByGroupId(Integer groupId);
}
