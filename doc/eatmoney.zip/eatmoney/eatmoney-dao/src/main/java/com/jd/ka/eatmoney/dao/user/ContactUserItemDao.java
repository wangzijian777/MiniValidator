
/**
 * Copyright(c) 2013-  www.jd.com
 *
 */
 package com.jd.ka.eatmoney.dao.user;

import java.util.List;
import com.jd.ka.eatmoney.domain.user.ContactUserItem;
import java.util.Map;
/**
 * @author zhangshibin
 * @since 2015-1-19
 * 联系人信息 Dao接口类
 */
public interface ContactUserItemDao {
    
    
    
    	/**
     * 添加并返回设置id的ContactUserItem对象
     * 
     * @param contactUserItem
     * @return
     */
    public int addContactUserItem(ContactUserItem contactUserItem);
    
	/**
     * 更新ContactUserItem
     * 
     * @param contactUserItem
     */
    public void updateContactUserItem(ContactUserItem contactUserItem);
    
    
    

    /**
     * 根据主键删除ContactUserItem
     * 
     * @param id
     */
    public void deleteContactUserItem(Integer id);


	/**
     * 根据主键获取ContactUserItem
     * 
     * @param id
     * @return
     */	
    public ContactUserItem getContactUserItemById(Integer id);
    

    
	
    /**
     * 取得所有ContactUserItem
     * 
     * @return
     */
    public List<ContactUserItem> getAll();
    
	/**
     * 根据example取得ContactUserItem列表
     * 
     * @param  contactUserItem
     * @return
     */
    public List<ContactUserItem> getListByExample(ContactUserItem contactUserItem);
    
    	/**
     * 根据example取得唯一的ContactUserItem
     * 
     * @param contactUserItem
     * @return
     */
    public ContactUserItem getUnique(ContactUserItem contactUserItem);
    

    


	/**
     * 分页取得ContactUserItem列表
     * 
     * @param paramMap
     * @return
     */
    public List<ContactUserItem> getContactUserItemByPage(Map<String,Object> paramMap);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param paramMap
     * @return
     */
    public int count(Map<String,Object> paramMap);

}
