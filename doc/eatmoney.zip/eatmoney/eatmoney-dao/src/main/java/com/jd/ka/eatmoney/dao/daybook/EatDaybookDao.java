
/**
 * Copyright(c) 2013-  www.jd.com
 *
 */
 package com.jd.ka.eatmoney.dao.daybook;

import java.util.List;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import java.util.Map;
/**
 * @author zhangshibin
 * @since 2015-1-19
 * 吃饭记账记录 Dao接口类
 */
public interface EatDaybookDao {
    
    
    
    	/**
     * 添加并返回设置id的EatDaybook对象
     * 
     * @param eatDaybook
     * @return
     */
    public int addEatDaybook(EatDaybook eatDaybook);
    
	/**
     * 更新EatDaybook
     * 
     * @param eatDaybook
     */
    public void updateEatDaybook(EatDaybook eatDaybook);
    
    
    

    /**
     * 根据主键删除EatDaybook
     * 
     * @param id
     */
    public void deleteEatDaybook(Integer id);


	/**
     * 根据主键获取EatDaybook
     * 
     * @param id
     * @return
     */	
    public EatDaybook getEatDaybookById(Integer id);
    

    
	
    /**
     * 取得所有EatDaybook
     * 
     * @return
     */
    public List<EatDaybook> getAll();
    
	/**
     * 根据example取得EatDaybook列表
     * 
     * @param  eatDaybook
     * @return
     */
    public List<EatDaybook> getListByExample(EatDaybook eatDaybook);
    
    	/**
     * 根据example取得唯一的EatDaybook
     * 
     * @param eatDaybook
     * @return
     */
    public EatDaybook getUnique(EatDaybook eatDaybook);
    

    


	/**
     * 分页取得EatDaybook列表
     * 
     * @param paramMap
     * @return
     */
    public List<EatDaybook> getEatDaybookByPage(Map<String,Object> paramMap);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param paramMap
     * @return
     */
    public int count(Map<String,Object> paramMap);

}
