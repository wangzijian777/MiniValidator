
/**
 * Copyright(c) 2013-  www.jd.com
 *
 */
 package com.jd.ka.eatmoney.dao.daybook;

import java.math.BigDecimal;
import java.util.List;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;
import org.apache.ibatis.annotations.Param;

import java.util.Map;
/**
 * @author zhangshibin
 * @since 2015-1-19
 * EatDaybookItem Dao接口类
 */
public interface EatDaybookItemDao {
    
    
    
    	/**
     * 添加并返回设置id的EatDaybookItem对象
     * 
     * @param eatDaybookItem
     * @return
     */
    public int addEatDaybookItem(EatDaybookItem eatDaybookItem);
    
	/**
     * 更新EatDaybookItem
     * 
     * @param eatDaybookItem
     */
    public void updateEatDaybookItem(EatDaybookItem eatDaybookItem);
    
    
    

    /**
     * 根据主键删除EatDaybookItem
     * 
     * @param id
     */
    public void deleteEatDaybookItem(Integer id);


    /**
     * 根据daybookId删除EatDaybookItem
     *
     * @param daybookId
     */
    public int deleteByDaybookId(Integer daybookId);


	/**
     * 根据主键获取EatDaybookItem
     * 
     * @param id
     * @return
     */	
    public EatDaybookItem getEatDaybookItemById(Integer id);
    

    
	
    /**
     * 取得所有EatDaybookItem
     * 
     * @return
     */
    public List<EatDaybookItem> getAll();
    
	/**
     * 根据example取得EatDaybookItem列表
     * 
     * @param  eatDaybookItem
     * @return
     */
    public List<EatDaybookItem> getListByExample(EatDaybookItem eatDaybookItem);



	/**
     * 分页取得EatDaybookItem列表
     * 
     * @param paramMap
     * @return
     */
    public List<EatDaybookItem> getEatDaybookItemByPage(Map<String,Object> paramMap);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param paramMap
     * @return
     */
    public int count(Map<String,Object> paramMap);


    /**
     * 查询总额
     * @param paramMap
     * @return
     */
    public BigDecimal sumPayMoney(Map<String,Object> paramMap);

    /**
     * 执行结算
     * @param settlementId
     * @param daybookId
     */
    public void doSettlement(@Param("settlementId")Integer settlementId, @Param("daybookId")Integer daybookId);
}
