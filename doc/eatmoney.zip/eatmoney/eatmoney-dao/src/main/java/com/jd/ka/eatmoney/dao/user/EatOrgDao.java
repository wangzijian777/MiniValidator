
/**
 * Copyright(c) 2013-  www.jd.com
 *
 */
 package com.jd.ka.eatmoney.dao.user;

import java.util.List;
import com.jd.ka.eatmoney.domain.user.EatOrg;
import java.util.Map;
/**
 * @author zhangshibin
 * @since 2015-2-7
 * EatOrg Dao接口类
 */
public interface EatOrgDao {
    
    
    
    	/**
     * 添加并返回设置id的EatOrg对象
     * 
     * @param eatOrg
     * @return
     */
    public int addEatOrg(EatOrg eatOrg);
    
	/**
     * 更新EatOrg
     * 
     * @param eatOrg
     */
    public void updateEatOrg(EatOrg eatOrg);
    
    
    

    /**
     * 根据主键删除EatOrg
     * 
     * @param id
     */
    public void deleteEatOrg(Integer id);


	/**
     * 根据主键获取EatOrg
     * 
     * @param id
     * @return
     */	
    public EatOrg getEatOrgById(Integer id);
    

    
	
    /**
     * 取得所有EatOrg
     * 
     * @return
     */
    public List<EatOrg> getAll();
    
	/**
     * 根据example取得EatOrg列表
     * 
     * @param  eatOrg
     * @return
     */
    public List<EatOrg> getListByExample(EatOrg eatOrg);
    
    	/**
     * 根据example取得唯一的EatOrg
     * 
     * @param eatOrg
     * @return
     */
    public EatOrg getUnique(EatOrg eatOrg);
    

    


	/**
     * 分页取得EatOrg列表
     * 
     * @param paramMap
     * @return
     */
    public List<EatOrg> getEatOrgByPage(Map<String,Object> paramMap);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param paramMap
     * @return
     */
    public int count(Map<String,Object> paramMap);

}
