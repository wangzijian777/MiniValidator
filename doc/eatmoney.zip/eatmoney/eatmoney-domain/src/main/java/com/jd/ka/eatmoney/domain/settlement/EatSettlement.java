package com.jd.ka.eatmoney.domain.settlement;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 吃饭结算信息 Domain 类
 */
public class EatSettlement  implements Serializable {
	
  private static final long serialVersionUID = 6275056511664226249L;
	
	/**  id  */
	private Integer id; 
	/**  操作人id  */
	private Integer submitUserId; 
	/**  操作人账号  */
	private String submitErpAcct; 
	/**  总金额  */
	private java.math.BigDecimal totalMoney; 
	/**  记账id  */
	private String daybookIds; 
	/**  状态  */
	private Integer status; 
	/**  详细json  */
	private String detailJson; 
	/**  创建时间  */
	private java.util.Date gmtCreate; 
	/**  修改时间  */
	private java.util.Date gmtModify;

    /**
     * 公共金额
     */
    private BigDecimal publicMoney;


  	public void setId(Integer id) {
  	  this.id=id;
  	}
  
  	public Integer getId() {
  	  return this.id;
  	}
	
	  	

  	public void setSubmitUserId(Integer submitUserId) {
  	  this.submitUserId=submitUserId;
  	}
  
  	public Integer getSubmitUserId() {
  	  return this.submitUserId;
  	}
	
	  	

  	public void setSubmitErpAcct(String submitErpAcct) {
  	  this.submitErpAcct=submitErpAcct;
  	}
  
  	public String getSubmitErpAcct() {
  	  return this.submitErpAcct;
  	}
	
	  	

  	public void setTotalMoney(java.math.BigDecimal totalMoney) {
  	  this.totalMoney=totalMoney;
  	}
  
  	public java.math.BigDecimal getTotalMoney() {
  	  return this.totalMoney;
  	}
	
	  	

  	public void setDaybookIds(String daybookIds) {
  	  this.daybookIds=daybookIds;
  	}
  
  	public String getDaybookIds() {
  	  return this.daybookIds;
  	}
	
	  	

  	public void setStatus(Integer status) {
  	  this.status=status;
  	}
  
  	public Integer getStatus() {
  	  return this.status;
  	}
	
	  	

  	public void setDetailJson(String detailJson) {
  	  this.detailJson=detailJson;
  	}
  
  	public String getDetailJson() {
  	  return this.detailJson;
  	}
	
	  	

  	public void setGmtCreate(java.util.Date gmtCreate) {
  	  this.gmtCreate=gmtCreate;
  	}
  
  	public java.util.Date getGmtCreate() {
  	  return this.gmtCreate;
  	}
	
	  	

  	public void setGmtModify(java.util.Date gmtModify) {
  	  this.gmtModify=gmtModify;
  	}
  
  	public java.util.Date getGmtModify() {
  	  return this.gmtModify;
  	}

    public void setPublicMoney(BigDecimal publicMoney) {
        this.publicMoney = publicMoney;
    }

    public BigDecimal getPublicMoney() {
        return publicMoney;
    }
}
