package com.jd.ka.eatmoney.domain.daybook;

import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 吃饭记账记录 Domain 类
 */
public class EatDaybook  implements Serializable {
	
  private static final long serialVersionUID = -7726417210141741204L;
	
	/**  id  */
	private Integer id; 
	/**  录入人id  */
	private Integer inputUserId; 
	/**  录入人erp账号  */
	private String inputErpAccount; 
	/**  付款人账号  */
	private String payErpAccount; 
	/**  报账人  */
	private String submitErpAccount; 
	/**  total_money  */
	private java.math.BigDecimal totalMoney; 

	/**  吃饭日期  */
    @DateTimeFormat( pattern = "yyyy-MM-dd" )
    private java.util.Date eatDate;
	/**  备注  */
	private String remark;

    /**  记账json  */
    private String bookJson;


    /**  支付类型  */
	private Integer payType; 
	/**  状态  */
	private Integer status; 
	/**  结算id  */
	private Integer settlementId; 
	/**  创建时间  */
	private java.util.Date gmtCreate; 
	/**  修改时间  */
	private java.util.Date gmtModify; 


    private BigDecimal payMoney;


  	public void setId(Integer id) {
  	  this.id=id;
  	}
  
  	public Integer getId() {
  	  return this.id;
  	}
	
	  	

  	public void setInputUserId(Integer inputUserId) {
  	  this.inputUserId=inputUserId;
  	}
  
  	public Integer getInputUserId() {
  	  return this.inputUserId;
  	}
	
	  	

  	public void setInputErpAccount(String inputErpAccount) {
  	  this.inputErpAccount=inputErpAccount;
  	}
  
  	public String getInputErpAccount() {
  	  return this.inputErpAccount;
  	}
	
	  	

  	public void setPayErpAccount(String payErpAccount) {
  	  this.payErpAccount=payErpAccount;
  	}
  
  	public String getPayErpAccount() {
  	  return this.payErpAccount;
  	}
	
	  	

  	public void setSubmitErpAccount(String submitErpAccount) {
  	  this.submitErpAccount=submitErpAccount;
  	}
  
  	public String getSubmitErpAccount() {
  	  return this.submitErpAccount;
  	}
	
	  	

  	public void setTotalMoney(java.math.BigDecimal totalMoney) {
  	  this.totalMoney=totalMoney;
  	}
  
  	public java.math.BigDecimal getTotalMoney() {
  	  return this.totalMoney;
  	}
	
	  	

  	public void setEatDate(java.util.Date eatDate) {
  	  this.eatDate=eatDate;
  	}
  
  	public java.util.Date getEatDate() {
  	  return this.eatDate;
  	}
	
	  	

  	public void setRemark(String remark) {
  	  this.remark=remark;
  	}
  
  	public String getRemark() {
  	  return this.remark;
  	}
	
	  	

  	public void setPayType(Integer payType) {
  	  this.payType=payType;
  	}
  
  	public Integer getPayType() {
  	  return this.payType;
  	}
	
	  	

  	public void setStatus(Integer status) {
  	  this.status=status;
  	}
  
  	public Integer getStatus() {
  	  return this.status;
  	}
	
	  	

  	public void setSettlementId(Integer settlementId) {
  	  this.settlementId=settlementId;
  	}
  
  	public Integer getSettlementId() {
  	  return this.settlementId;
  	}
	
	  	

  	public void setGmtCreate(java.util.Date gmtCreate) {
  	  this.gmtCreate=gmtCreate;
  	}
  
  	public java.util.Date getGmtCreate() {
  	  return this.gmtCreate;
  	}
	
	  	

  	public void setGmtModify(java.util.Date gmtModify) {
  	  this.gmtModify=gmtModify;
  	}
  
  	public java.util.Date getGmtModify() {
  	  return this.gmtModify;
  	}

    public BigDecimal getPayMoney() {
        return payMoney;
    }

    public void setPayMoney(BigDecimal payMoney) {
        this.payMoney = payMoney;
    }

    public String getBookJson() {
        return bookJson;
    }

    public void setBookJson(String bookJson) {
        this.bookJson = bookJson;
    }

}
