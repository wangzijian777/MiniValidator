package com.jd.ka.eatmoney.domain.settlement;

import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;
import com.jd.ka.eatmoney.enumtype.PaymentType;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by zhangshibin on 2015/1/26.
 */
public class DaybookDetailExport implements  Comparable<DaybookDetailExport>{

    public Date eatDate;
    public String eatDateStr;
    public List<EatDaybookItem> daybookItemList=new ArrayList<EatDaybookItem>();
    public Integer id;
    public Integer payType;
    public String payErpAccount;
    public String payUserName;
    public String inputErpAccount;
    public String inputUserName;
    public String payName;

    /**
     * 总金额
     */
    public BigDecimal totalMoney;

    /**实际付款金额*/
    public BigDecimal realPayMoney;


    public Date getEatDate() {
        return eatDate;
    }

    public void setEatDate(Date eatDate) {
        this.eatDate = eatDate;
    }

    public String getEatDateStr() {
        return eatDateStr;
    }

    public void setEatDateStr(String eatDateStr) {
        this.eatDateStr = eatDateStr;
    }

    public List<EatDaybookItem> getDaybookItemList() {
        return daybookItemList;
    }

    public void setDaybookItemList(List<EatDaybookItem> daybookItemList) {
        this.daybookItemList = daybookItemList;
    }


    public String getUserNames(){
        StringBuilder sb=new StringBuilder();
        Iterator<EatDaybookItem> iterator=daybookItemList.iterator();
        while(iterator.hasNext()){
            sb.append(iterator.next().getUserName());
            if(iterator.hasNext()){
                sb.append(",");
            }else{
                break;
            }
        }
        return sb.toString();
    }


    public int getSize(){
        return daybookItemList.size();
    }


    public BigDecimal getTotalMoney(){
        if(totalMoney==null){
            BigDecimal tempTotalMoney=new BigDecimal(0);
            if(daybookItemList!=null) {
                for (EatDaybookItem eatDaybookItem : daybookItemList) {
                    tempTotalMoney = tempTotalMoney.add(eatDaybookItem.getPayMoney());
                }
            }
            totalMoney=tempTotalMoney;
        }
        return totalMoney;
    }

    public void addDaybookItem(EatDaybookItem eatDaybookItem){
        totalMoney=null; //需要从新计算总额
        daybookItemList.add(eatDaybookItem);
    }



    @Override
    public int compareTo(DaybookDetailExport o) {
        return this.eatDate.compareTo(o.getEatDate());
    }

    public Integer getPayType() {
        return payType;
    }

    public void setPayType(Integer payType) {
        this.payType = payType;
    }

    public String getPayErpAccount() {
        return payErpAccount;
    }

    public void setPayErpAccount(String payErpAccount) {
        this.payErpAccount = payErpAccount;
    }

    public String getPayUserName() {
        return payUserName;
    }

    public void setPayUserName(String payUserName) {
        this.payUserName = payUserName;
    }

    public String getInputErpAccount() {
        return inputErpAccount;
    }

    public void setInputErpAccount(String inputErpAccount) {
        this.inputErpAccount = inputErpAccount;
    }

    public String getInputUserName() {
        return inputUserName;
    }

    public void setInputUserName(String inputUserName) {
        this.inputUserName = inputUserName;
    }

    public String getPayName() {
        if(payName==null){
            if(payType== PaymentType.ONE_PAY.getType()){
                payName="单人付款";
            }else{
                payName="各付各的";
            }
        }
        return payName;
    }

    public void setPayName(String payName) {
        this.payName = payName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getRealPayMoney() {
        return realPayMoney;
    }

    public void setRealPayMoney(BigDecimal realPayMoney) {
        this.realPayMoney = realPayMoney;
    }

    /**
     * 分析本报账总记录有没有充公金额
     * @return
     */
    public boolean hasPublicMoney() {
        BigDecimal tempTotalMoney=this.getTotalMoney();
        /**
         * 如果总额和实付金额不一致 且
         *  为单人报账情况
         */
        if((daybookItemList.size()==1 || payType==PaymentType.ONE_PAY.getType()) &&
                tempTotalMoney.compareTo(realPayMoney)!=0 ){
            return true;
        }
        return false;
    }

    public BigDecimal getPublicMoney() {
        return this.getTotalMoney().subtract(this.realPayMoney);
    }
}
