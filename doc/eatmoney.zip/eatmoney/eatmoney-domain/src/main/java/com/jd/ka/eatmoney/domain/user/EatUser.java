package com.jd.ka.eatmoney.domain.user;

import java.io.Serializable;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 用户 Domain 类
 */
public class EatUser  implements Serializable {
	
  private static final long serialVersionUID = 1107726145228065518L;
	
	/**  id  */
	private Integer id; 
	/**  erp账号  */
	private String erpAccount; 
	/**  登陆密码  */
	private String password; 
	/**  用户名字  */
	private String userName; 
	/**  性别  */
	private Integer gender; 
	/**  年龄  */
	private Integer age; 
	/**  头像  */
	private String headLogo; 
	/**  用户状态  */
	private Integer userStatus; 
	/**  用户类型  */
	private Integer userType; 
	/**  签名  */
	private String slogan; 
	/**  org_id  */
	private Integer orgId; 
	/**  创建时间  */
	private java.util.Date gmtCreate; 
	/**  更新时间  */
	private java.util.Date gmtUpdate; 
	/**  我的报账人  */
	private String submitErpAcct; 

  	public void setId(Integer id) {
  	  this.id=id;
  	}
  
  	public Integer getId() {
  	  return this.id;
  	}
	
	  	

  	public void setErpAccount(String erpAccount) {
  	  this.erpAccount=erpAccount;
  	}
  
  	public String getErpAccount() {
  	  return this.erpAccount;
  	}
	
	  	

  	public void setPassword(String password) {
  	  this.password=password;
  	}
  
  	public String getPassword() {
  	  return this.password;
  	}
	
	  	

  	public void setUserName(String userName) {
  	  this.userName=userName;
  	}
  
  	public String getUserName() {
  	  return this.userName;
  	}
	
	  	

  	public void setGender(Integer gender) {
  	  this.gender=gender;
  	}
  
  	public Integer getGender() {
  	  return this.gender;
  	}
	
	  	

  	public void setAge(Integer age) {
  	  this.age=age;
  	}
  
  	public Integer getAge() {
  	  return this.age;
  	}
	
	  	

  	public void setHeadLogo(String headLogo) {
  	  this.headLogo=headLogo;
  	}
  
  	public String getHeadLogo() {
  	  return this.headLogo;
  	}
	
	  	

  	public void setUserStatus(Integer userStatus) {
  	  this.userStatus=userStatus;
  	}
  
  	public Integer getUserStatus() {
  	  return this.userStatus;
  	}
	
	  	

  	public void setUserType(Integer userType) {
  	  this.userType=userType;
  	}
  
  	public Integer getUserType() {
  	  return this.userType;
  	}
	
	  	

  	public void setSlogan(String slogan) {
  	  this.slogan=slogan;
  	}
  
  	public String getSlogan() {
  	  return this.slogan;
  	}
	
	  	

  	public void setOrgId(Integer orgId) {
  	  this.orgId=orgId;
  	}
  
  	public Integer getOrgId() {
  	  return this.orgId;
  	}
	
	  	

  	public void setGmtCreate(java.util.Date gmtCreate) {
  	  this.gmtCreate=gmtCreate;
  	}
  
  	public java.util.Date getGmtCreate() {
  	  return this.gmtCreate;
  	}
	
	  	

  	public void setGmtUpdate(java.util.Date gmtUpdate) {
  	  this.gmtUpdate=gmtUpdate;
  	}
  
  	public java.util.Date getGmtUpdate() {
  	  return this.gmtUpdate;
  	}
	
	  	

  	public void setSubmitErpAcct(String submitErpAcct) {
  	  this.submitErpAcct=submitErpAcct;
  	}
  
  	public String getSubmitErpAcct() {
  	  return this.submitErpAcct;
  	}
	
	  	

}
