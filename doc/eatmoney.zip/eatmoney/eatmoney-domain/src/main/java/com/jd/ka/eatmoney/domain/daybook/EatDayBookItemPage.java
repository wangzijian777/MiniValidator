package com.jd.ka.eatmoney.domain.daybook;

import java.math.BigDecimal;

/**
 * 从页面上传过来的数据，用于json转换
 * Created by zhangshibin on 2015/1/20.
 */
public class EatDayBookItemPage {

    private Integer uid;
    private String userName;
    private String erpAccount;
    private BigDecimal payMoney;

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getErpAccount() {
        return erpAccount;
    }

    public void setErpAccount(String erpAccount) {
        this.erpAccount = erpAccount;
    }

    public BigDecimal getPayMoney() {
        return payMoney;
    }

    public void setPayMoney(BigDecimal payMoney) {
        this.payMoney = payMoney;
    }
}
