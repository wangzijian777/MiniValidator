package com.jd.ka.eatmoney.domain.settlement;

import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Created by zhangshibin on 2015/1/26.
 */
public class DaybookExport implements  Comparable<DaybookExport>{

    public Date eatDate;
    public String eateDateStr;
    public List<EatDaybookItem> daybookItemList=new ArrayList<EatDaybookItem>();


    public Date getEatDate() {
        return eatDate;
    }

    public void setEatDate(Date eatDate) {
        this.eatDate = eatDate;
    }

    public String getEateDateStr() {
        return eateDateStr;
    }

    public void setEateDateStr(String eateDateStr) {
        this.eateDateStr = eateDateStr;
    }

    public List<EatDaybookItem> getDaybookItemList() {
        return daybookItemList;
    }

    public void setDaybookItemList(List<EatDaybookItem> daybookItemList) {
        this.daybookItemList = daybookItemList;
    }


    public String getUserNames(){
        StringBuilder sb=new StringBuilder();
        Iterator<EatDaybookItem> iterator=daybookItemList.iterator();
        while(iterator.hasNext()){
            sb.append(iterator.next().getUserName());
            if(iterator.hasNext()){
                sb.append(",");
            }else{
                break;
            }
        }
        return sb.toString();
    }


    public int getSize(){
        return daybookItemList.size();
    }


    public BigDecimal getTotalMoney(){
        BigDecimal totalMoney=new BigDecimal(0);
        for(EatDaybookItem eatDaybookItem:daybookItemList){
            totalMoney= totalMoney.add(eatDaybookItem.getPayMoney());
        }
        return totalMoney;
    }

    public void addDaybookItem(EatDaybookItem eatDaybookItem){
        daybookItemList.add(eatDaybookItem);
    }



    @Override
    public int compareTo(DaybookExport o) {
        return this.eatDate.compareTo(o.getEatDate());
    }
}
