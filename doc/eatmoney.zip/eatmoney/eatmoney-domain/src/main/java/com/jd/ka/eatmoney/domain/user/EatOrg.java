package com.jd.ka.eatmoney.domain.user;

import java.io.Serializable;

/**
 * @author zhangshibin
 * @since 2015-2-7
 * EatOrg Domain 类
 */
public class EatOrg  implements Serializable {
	
  private static final long serialVersionUID = -6577518112319196990L;
	
	/**  id  */
	private Integer id; 
	/**  机构名称  */
	private String name; 
	/**  父机构号  */
	private Integer parentId; 
	/**  创建人  */
	private String creator; 
	/**  状态  */
	private Integer state; 
	/**  创建时间  */
	private java.util.Date created; 
	/**  修改时间  */
	private java.util.Date modified; 

  	public void setId(Integer id) {
  	  this.id=id;
  	}
  
  	public Integer getId() {
  	  return this.id;
  	}
	
	  	

  	public void setName(String name) {
  	  this.name=name;
  	}
  
  	public String getName() {
  	  return this.name;
  	}
	
	  	

  	public void setParentId(Integer parentId) {
  	  this.parentId=parentId;
  	}
  
  	public Integer getParentId() {
  	  return this.parentId;
  	}
	
	  	

  	public void setCreator(String creator) {
  	  this.creator=creator;
  	}
  
  	public String getCreator() {
  	  return this.creator;
  	}
	
	  	

  	public void setState(Integer state) {
  	  this.state=state;
  	}
  
  	public Integer getState() {
  	  return this.state;
  	}
	
	  	

  	public void setCreated(java.util.Date created) {
  	  this.created=created;
  	}
  
  	public java.util.Date getCreated() {
  	  return this.created;
  	}
	
	  	

  	public void setModified(java.util.Date modified) {
  	  this.modified=modified;
  	}
  
  	public java.util.Date getModified() {
  	  return this.modified;
  	}
	
	  	

}
