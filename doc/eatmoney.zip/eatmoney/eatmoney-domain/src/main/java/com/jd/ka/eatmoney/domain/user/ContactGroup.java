package com.jd.ka.eatmoney.domain.user;

import java.io.Serializable;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 联系人分组 Domain 类
 */
public class ContactGroup  implements Serializable {
	
  private static final long serialVersionUID = -3293193748019341044L;
	
	/**  id  */
	private Integer id; 
	/**  拥有者id  */
	private Integer ownerId; 
	/**  拥有者erp  */
	private String ownerErp;
	/**  名称  */
	private String groupName; 
	/**  备注  */
	private String remark; 
	/**  创建时间  */
	private java.util.Date gmtCreate; 
	/**  修改时间  */
	private java.util.Date gmtModify; 
	/**  父groupid  */
	private Integer parentId;

    /**
     * 1.私有组，2.公共组
     */
    private Integer groupType;


    public void setId(Integer id) {
  	  this.id=id;
  	}
  
  	public Integer getId() {
  	  return this.id;
  	}
	
	  	

  	public void setOwnerId(Integer ownerId) {
  	  this.ownerId=ownerId;
  	}
  
  	public Integer getOwnerId() {
  	  return this.ownerId;
  	}
	
	  	

  	public void setOwnerErp(String ownerErp) {
  	  this.ownerErp=ownerErp;
  	}
  
  	public String getOwnerErp() {
  	  return this.ownerErp;
  	}
	
	  	

  	public void setGroupName(String groupName) {
  	  this.groupName=groupName;
  	}
  
  	public String getGroupName() {
  	  return this.groupName;
  	}
	
	  	

  	public void setRemark(String remark) {
  	  this.remark=remark;
  	}
  
  	public String getRemark() {
  	  return this.remark;
  	}
	
	  	

  	public void setGmtCreate(java.util.Date gmtCreate) {
  	  this.gmtCreate=gmtCreate;
  	}
  
  	public java.util.Date getGmtCreate() {
  	  return this.gmtCreate;
  	}
	
	  	

  	public void setGmtModify(java.util.Date gmtModify) {
  	  this.gmtModify=gmtModify;
  	}
  
  	public java.util.Date getGmtModify() {
  	  return this.gmtModify;
  	}
	
	  	

  	public void setParentId(Integer parentId) {
  	  this.parentId=parentId;
  	}
  
  	public Integer getParentId() {
  	  return this.parentId;
  	}

    public Integer getGroupType() {
        return groupType;
    }

    public void setGroupType(Integer groupType) {
        this.groupType = groupType;
    }
}
