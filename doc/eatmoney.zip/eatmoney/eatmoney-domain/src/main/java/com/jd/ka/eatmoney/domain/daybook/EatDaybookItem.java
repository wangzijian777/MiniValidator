package com.jd.ka.eatmoney.domain.daybook;

import java.io.Serializable;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * EatDaybookItem Domain 类
 */
public class EatDaybookItem  implements Serializable {
	
  private static final long serialVersionUID = 7990957716058806150L;
	
	/**  id  */
	private Integer id; 
	/**  流水账id  */
	private Integer daybookId; 
	/**  发生人id  */
	private Integer userId;
	/**  发生人账号  */
	private String erpAccount;

    /**  录入人账号  */
    private String inputErpAccount;
    /**  pay_erp_account  */
	private String payErpAccount; 
	/**  报账人  */
	private String submitErpAccount; 
	/**  付款金额，默认15  */
	private java.math.BigDecimal payMoney; 
	/**  吃饭日期  */
	private java.util.Date eatDate; 
	/**  支付类型  */
	private Integer payType; 
	/**  状态  */
	private Integer status; 
	/**  gmt_create  */
	private java.util.Date gmtCreate; 
	/**  gmt_modify  */
	private java.util.Date gmtModify; 
	/**  remark  */
	private String remark; 
	/**  结算id  */
	private Integer settlementId;

    /**  发生人name */
    private String userName;
    private String payUserName;

  	public void setId(Integer id) {
  	  this.id=id;
  	}
  
  	public Integer getId() {
  	  return this.id;
  	}
	
	  	

  	public void setDaybookId(Integer daybookId) {
  	  this.daybookId=daybookId;
  	}
  
  	public Integer getDaybookId() {
  	  return this.daybookId;
  	}
	
	  	

  	public void setUserId(Integer userId) {
  	  this.userId=userId;
  	}
  
  	public Integer getUserId() {
  	  return this.userId;
  	}
	
	  	

  	public void setErpAccount(String erpAccount) {
  	  this.erpAccount=erpAccount;
  	}
  
  	public String getErpAccount() {
  	  return this.erpAccount;
  	}
	
	  	

  	public void setPayErpAccount(String payErpAccount) {
  	  this.payErpAccount=payErpAccount;
  	}
  
  	public String getPayErpAccount() {
  	  return this.payErpAccount;
  	}
	
	  	

  	public void setSubmitErpAccount(String submitErpAccount) {
  	  this.submitErpAccount=submitErpAccount;
  	}
  
  	public String getSubmitErpAccount() {
  	  return this.submitErpAccount;
  	}
	
	  	

  	public void setPayMoney(java.math.BigDecimal payMoney) {
  	  this.payMoney=payMoney;
  	}
  
  	public java.math.BigDecimal getPayMoney() {
  	  return this.payMoney;
  	}
	
	  	

  	public void setEatDate(java.util.Date eatDate) {
  	  this.eatDate=eatDate;
  	}
  
  	public java.util.Date getEatDate() {
  	  return this.eatDate;
  	}
	
	  	

  	public void setPayType(Integer payType) {
  	  this.payType=payType;
  	}
  
  	public Integer getPayType() {
  	  return this.payType;
  	}
	
	  	

  	public void setStatus(Integer status) {
  	  this.status=status;
  	}
  
  	public Integer getStatus() {
  	  return this.status;
  	}
	
	  	

  	public void setGmtCreate(java.util.Date gmtCreate) {
  	  this.gmtCreate=gmtCreate;
  	}
  
  	public java.util.Date getGmtCreate() {
  	  return this.gmtCreate;
  	}
	
	  	

  	public void setGmtModify(java.util.Date gmtModify) {
  	  this.gmtModify=gmtModify;
  	}
  
  	public java.util.Date getGmtModify() {
  	  return this.gmtModify;
  	}
	
	  	

  	public void setRemark(String remark) {
  	  this.remark=remark;
  	}
  
  	public String getRemark() {
  	  return this.remark;
  	}
	
	  	

  	public void setSettlementId(Integer settlementId) {
  	  this.settlementId=settlementId;
  	}
  
  	public Integer getSettlementId() {
  	  return this.settlementId;
  	}

    public String getInputErpAccount() {
        return inputErpAccount;
    }

    public void setInputErpAccount(String inputErpAccount) {
        this.inputErpAccount = inputErpAccount;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPayUserName() {
        return payUserName;
    }

    public void setPayUserName(String payUserName) {
        this.payUserName = payUserName;
    }
}
