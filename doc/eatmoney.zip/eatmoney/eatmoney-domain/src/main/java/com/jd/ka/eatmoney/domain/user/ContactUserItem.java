package com.jd.ka.eatmoney.domain.user;

import java.io.Serializable;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 联系人信息 Domain 类
 */
public class ContactUserItem  implements Serializable {
	
  private static final long serialVersionUID = 3100478913459276017L;
	
	/**  id  */
	private Integer id; 
	/**  owner_id  */
	private Integer ownerId; 
	/**  owner_erp  */
	private String ownerErp; 
	/**  friend_id  */
	private Integer friendId; 
	/**  friend_erp  */
	private String friendErp; 
	/**  gmt_create  */
	private java.util.Date gmtCreate; 
	/**  状态  */
	private Integer status; 
	/**  分组id  */
	private Integer groupId; 
	/**  别名  */
	private String aliasName; 

  	public void setId(Integer id) {
  	  this.id=id;
  	}
  
  	public Integer getId() {
  	  return this.id;
  	}
	
	  	

  	public void setOwnerId(Integer ownerId) {
  	  this.ownerId=ownerId;
  	}
  
  	public Integer getOwnerId() {
  	  return this.ownerId;
  	}
	
	  	

  	public void setOwnerErp(String ownerErp) {
  	  this.ownerErp=ownerErp;
  	}
  
  	public String getOwnerErp() {
  	  return this.ownerErp;
  	}
	
	  	

  	public void setFriendId(Integer friendId) {
  	  this.friendId=friendId;
  	}
  
  	public Integer getFriendId() {
  	  return this.friendId;
  	}
	
	  	

  	public void setFriendErp(String friendErp) {
  	  this.friendErp=friendErp;
  	}
  
  	public String getFriendErp() {
  	  return this.friendErp;
  	}
	
	  	

  	public void setGmtCreate(java.util.Date gmtCreate) {
  	  this.gmtCreate=gmtCreate;
  	}
  
  	public java.util.Date getGmtCreate() {
  	  return this.gmtCreate;
  	}
	
	  	

  	public void setStatus(Integer status) {
  	  this.status=status;
  	}
  
  	public Integer getStatus() {
  	  return this.status;
  	}
	
	  	

  	public void setGroupId(Integer groupId) {
  	  this.groupId=groupId;
  	}
  
  	public Integer getGroupId() {
  	  return this.groupId;
  	}
	
	  	

  	public void setAliasName(String aliasName) {
  	  this.aliasName=aliasName;
  	}
  
  	public String getAliasName() {
  	  return this.aliasName;
  	}
	
	  	

}
