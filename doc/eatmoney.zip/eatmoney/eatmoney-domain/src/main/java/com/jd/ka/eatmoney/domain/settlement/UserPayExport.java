package com.jd.ka.eatmoney.domain.settlement;

import java.math.BigDecimal;

/**
 * Created by zhangshibin on 2015/1/27.
 */
public class UserPayExport {


    private String erpAccount;
    private String userName;
    private BigDecimal payTotalMoney;
    private BigDecimal publicMoney;

    public String getErpAccount() {
        return erpAccount;
    }

    public void setErpAccount(String erpAccount) {
        this.erpAccount = erpAccount;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public BigDecimal getPayTotalMoney() {
        return payTotalMoney;
    }

    public void setPayTotalMoney(BigDecimal payTotalMoney) {
        this.payTotalMoney = payTotalMoney;
    }


    public void addPayMoney(BigDecimal payMoney) {
        if(payMoney==null){
            return;
        }
        if(payTotalMoney==null){
            payTotalMoney=new BigDecimal(0);
        }
        payTotalMoney=payTotalMoney.add(payMoney);
    }

    /**
     * 减去充公金额
     * @param pMoney
     */
    public void subPublicMoney(BigDecimal pMoney) {
        payTotalMoney=payTotalMoney.subtract(pMoney);
        if(publicMoney==null){
            publicMoney=new BigDecimal(0);
        }
        publicMoney.add(pMoney);
    }
}
