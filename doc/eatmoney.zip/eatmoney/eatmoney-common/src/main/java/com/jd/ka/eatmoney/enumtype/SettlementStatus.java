package com.jd.ka.eatmoney.enumtype;

/**
 * Created by david on 2015/1/25.
 */
public enum SettlementStatus {



    SETTLED (1, "已结算"),
    CLEARED(2, "结清"),
    ROLLBACK(3, "回滚"),
    DELETED(4, "删除");

    private final int type;
    private final String typeName;

    private SettlementStatus(int type, String typeName) {
        this.type = type;
        this.typeName = typeName;
    }

    public static SettlementStatus getType(int type) {
        for (SettlementStatus t : values()) {
            if (type == t.getType()) {
                return t;
            }
        }
        return null;
    }

    public int getType() {
        return this.type;
    }

    public String getTypeName() {
        return this.typeName;
    }
}
