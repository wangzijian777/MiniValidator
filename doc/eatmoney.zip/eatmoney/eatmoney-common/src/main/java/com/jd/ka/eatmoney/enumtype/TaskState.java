package com.jd.ka.eatmoney.enumtype;

public enum TaskState {
	
	UNPROCESS(0, "未处理"),
	PROCCESSED(1, "已处理");
	
	private final int type;
	private final String typeName;

	private TaskState(int type, String typeName) {
		this.type = type;
		this.typeName = typeName;
	}

	public static TaskState getType(int type) {
		for (TaskState t : values()) {
			if (type == t.getType()) {
				return t;
			}
		}
		return null;
	}

	public int getType() {
		return this.type;
	}

	public String getTypeName() {
		return this.typeName;
	}
}
