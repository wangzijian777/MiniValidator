package com.jd.ka.eatmoney.enumtype;

/**
 * Created by david on 2015/1/25.
 */
public enum  DaybookStatus {



    UN_SETTLED (1, "未结算"),
    SETTLED(2, "已结算"),
    DELETED(3, "删除");

    private final int type;
    private final String typeName;

    private DaybookStatus(int type, String typeName) {
        this.type = type;
        this.typeName = typeName;
    }

    public static DaybookStatus getType(int type) {
        for (DaybookStatus t : values()) {
            if (type == t.getType()) {
                return t;
            }
        }
        return null;
    }

    public int getType() {
        return this.type;
    }

    public String getTypeName() {
        return this.typeName;
    }
}
