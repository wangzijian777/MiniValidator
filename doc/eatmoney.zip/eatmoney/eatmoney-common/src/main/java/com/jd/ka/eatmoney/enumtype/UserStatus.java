package com.jd.ka.eatmoney.enumtype;

/**
 * Created by zhangshibin on 2015/1/19.
 */
public enum UserStatus {
    NORMAL(1, "正常"),
    FORBIDDEN(2, "禁用"),
    DELETED(3, "已删除");

    private final int type;
    private final String typeName;

    private UserStatus(int type, String typeName) {
        this.type = type;
        this.typeName = typeName;
    }

    public static UserStatus getType(int type) {
        for (UserStatus t : values()) {
            if (type == t.getType()) {
                return t;
            }
        }
        return null;
    }

    public int getType() {
        return this.type;
    }

    public String getTypeName() {
        return this.typeName;
    }
}
