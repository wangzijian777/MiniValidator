package com.jd.ka.eatmoney.enumtype;

/**
 * Created by zhangshibin on 2015/1/19.
 */
public enum UserType {
    ADMIN(1, "管理员"),
    REPORTER(2, "报账员"),
    NORMAL(3, "普通用户");

    private final int type;
    private final String typeName;

    private UserType(int type, String typeName) {
        this.type = type;
        this.typeName = typeName;
    }

    public static UserType getType(int type) {
        for (UserType t : values()) {
            if (type == t.getType()) {
                return t;
            }
        }
        return null;
    }

    public int getType() {
        return this.type;
    }

    public String getTypeName() {
        return this.typeName;
    }
}
