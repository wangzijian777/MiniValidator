package com.jd.ka.eatmoney.manager.user.impl;

import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.user.ContactUserItem;
import com.jd.ka.eatmoney.dao.user.ContactUserItemDao;
import com.jd.ka.eatmoney.manager.user.ContactUserItemManager;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 联系人信息Manager实现类
 */
 @Component("contactUserItemManager")
public class ContactUserItemManagerImpl implements ContactUserItemManager {

	@Resource(name="contactUserItemDao")
	private ContactUserItemDao contactUserItemDao;


  public ContactUserItem addContactUserItem(ContactUserItem contactUserItem) {
		int i=contactUserItemDao.addContactUserItem(contactUserItem);
		return contactUserItem;
    }
    
    public void updateContactUserItem(ContactUserItem contactUserItem) {
		contactUserItemDao.updateContactUserItem(contactUserItem);
    }
    

    
    public void deleteContactUserItem(Integer id) {
		contactUserItemDao.deleteContactUserItem(id);
    }


    public ContactUserItem getContactUserItemById(Integer id) {
		return contactUserItemDao.getContactUserItemById(id);
    }
    
   

   
    
    public List<ContactUserItem> getAll() {
    	return contactUserItemDao.getAll();
    }
    	
    public List<ContactUserItem> getListByExample(ContactUserItem contactUserItem) {
		return contactUserItemDao.getListByExample(contactUserItem);
    }

        public ContactUserItem getUnique(ContactUserItem contactUserItem) {
		return contactUserItemDao.getUnique(contactUserItem);
    }

    
    

    
    public List<ContactUserItem> getContactUserItemByPage(PageQuery pageQuery) {
		return contactUserItemDao.getContactUserItemByPage( pageQuery.getParams());
    }
    	
    public int count(PageQuery pageQuery) {
		return contactUserItemDao.count( pageQuery.getParams());
    }

    /******* getter and setter ***/
    
	public ContactUserItemDao getContactUserItemDao() {
		return contactUserItemDao;
	}

	public void setContactUserItemDao(ContactUserItemDao contactUserItemDao) {
		this.contactUserItemDao = contactUserItemDao;
	}
}
