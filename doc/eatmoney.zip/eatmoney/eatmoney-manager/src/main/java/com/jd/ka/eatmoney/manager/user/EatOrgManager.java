/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.manager.user.EatOrgManager.java
 */
 package com.jd.ka.eatmoney.manager.user;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.user.EatOrg;

/**
 * @author zhangshibin
 * @since 2015-2-7
 * EatOrgManager接口类
 */
public interface EatOrgManager {
 
   /**
     * 添加并返回设置id的EatOrg对象
     * 
     * @param eatOrg
     * @return
     */
    public EatOrg addEatOrg(EatOrg eatOrg);
    
	/**
     * 更新EatOrg
     * 
     * @param eatOrg
     */
    public void updateEatOrg(EatOrg eatOrg);
    
    

	 /**
     * 根据主键删除EatOrg
     * 
     * @param id
     */
    public void deleteEatOrg(Integer id);

    	/**
     * 根据主键获取EatOrg
     * 
     * @param id
     * @return
     */	
    public EatOrg getEatOrgById(Integer id);

    


       
    /**
     * 取得所有EatOrg
     * 
     * @return
     */
    public List<EatOrg> getAll();
    
	/**
     * 根据example取得EatOrg列表
     * 
     * @param  eatOrg
     * @return
     */
    public List<EatOrg> getListByExample(EatOrg eatOrg);
    
        
	/**
     * 根据example取得唯一的EatOrg
     * 
     * @param eatOrg
     * @return
     */
    public EatOrg getUnique(EatOrg eatOrg);
    

    

	/**
     * 分页取得EatOrg列表
     * 
     * @param pageQuery
     * @return
     */
    public List<EatOrg> getEatOrgByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);

}
