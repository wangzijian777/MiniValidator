package com.jd.ka.eatmoney.manager.daybook.impl;

import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.enumtype.DaybookStatus;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;
import com.jd.ka.eatmoney.dao.daybook.EatDaybookItemDao;
import com.jd.ka.eatmoney.manager.daybook.EatDaybookItemManager;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * EatDaybookItemManager实现类
 */
 @Component("eatDaybookItemManager")
public class EatDaybookItemManagerImpl implements EatDaybookItemManager {

	@Resource(name="eatDaybookItemDao")
	private EatDaybookItemDao eatDaybookItemDao;


  public EatDaybookItem addEatDaybookItem(EatDaybookItem eatDaybookItem) {
		int i=eatDaybookItemDao.addEatDaybookItem(eatDaybookItem);
		return eatDaybookItem;
    }
    
    public void updateEatDaybookItem(EatDaybookItem eatDaybookItem) {
		eatDaybookItemDao.updateEatDaybookItem(eatDaybookItem);
    }
    

    
    public void deleteEatDaybookItem(Integer id) {
        EatDaybookItem eatDaybookItem=new EatDaybookItem();
        eatDaybookItem.setId(id);
        eatDaybookItem.setStatus(DaybookStatus.DELETED.getType());
        eatDaybookItem.setGmtModify(new Date());
        eatDaybookItemDao.updateEatDaybookItem(eatDaybookItem);
    //    eatDaybookItemDao.deleteEatDaybookItem(id);
    }


    /**
     * 根据daybookId删除EatDaybookItem
     *
     * @param daybookId
     */
    public int deleteByDaybookId(Integer daybookId) {
        return eatDaybookItemDao.deleteByDaybookId(daybookId);
    }

    public EatDaybookItem getEatDaybookItemById(Integer id) {
		return eatDaybookItemDao.getEatDaybookItemById(id);
    }
    
   

   
    
    public List<EatDaybookItem> getAll() {
    	return eatDaybookItemDao.getAll();
    }
    	
    public List<EatDaybookItem> getListByExample(EatDaybookItem eatDaybookItem) {

		return eatDaybookItemDao.getListByExample(eatDaybookItem);
    }

   public EatDaybookItem getUnique(EatDaybookItem eatDaybookItem) {
        List<EatDaybookItem> list=this.getListByExample(eatDaybookItem);
       if(CollectionUtils.isNotEmpty(list)){
           return  list.get(0);
       }
       return null;
    }

    
    

    
    public List<EatDaybookItem> getEatDaybookItemByPage(PageQuery pageQuery) {
		return eatDaybookItemDao.getEatDaybookItemByPage( pageQuery.getParams());
    }
    	
    public int count(PageQuery pageQuery) {
		return eatDaybookItemDao.count( pageQuery.getParams());
    }


    /**
     * 执行结算
     *
     * @param settlementId
     * @param eatDaybook
     */
    public void doSettlement(Integer settlementId, EatDaybook eatDaybook) {
        eatDaybookItemDao.doSettlement(settlementId,eatDaybook.getId());
    }

    /**
     * 查询总额
     * @param paramMap
     * @return
     */
    public BigDecimal sumPayMoney(Map<String,Object> paramMap){
        return eatDaybookItemDao.sumPayMoney(paramMap);
    }




    /******* getter and setter ***/
    
	public EatDaybookItemDao getEatDaybookItemDao() {
		return eatDaybookItemDao;
	}

	public void setEatDaybookItemDao(EatDaybookItemDao eatDaybookItemDao) {
		this.eatDaybookItemDao = eatDaybookItemDao;
	}
}
