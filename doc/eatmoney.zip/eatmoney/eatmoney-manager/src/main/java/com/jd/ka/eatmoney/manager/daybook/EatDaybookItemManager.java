/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.manager.daybook.EatDaybookItemManager.java
 */
 package com.jd.ka.eatmoney.manager.daybook;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * EatDaybookItemManager接口类
 */
public interface EatDaybookItemManager {
 
   /**
     * 添加并返回设置id的EatDaybookItem对象
     * 
     * @param eatDaybookItem
     * @return
     */
    public EatDaybookItem addEatDaybookItem(EatDaybookItem eatDaybookItem);
    
	/**
     * 更新EatDaybookItem
     * 
     * @param eatDaybookItem
     */
    public void updateEatDaybookItem(EatDaybookItem eatDaybookItem);
    
    

	 /**
     * 根据主键删除EatDaybookItem
     * 
     * @param id
     */
    public void deleteEatDaybookItem(Integer id);

    /**
     * 根据daybookId删除EatDaybookItem
     *
     * @param daybookId
     */
    public int deleteByDaybookId(Integer daybookId);

    	/**
     * 根据主键获取EatDaybookItem
     * 
     * @param id
     * @return
     */	
    public EatDaybookItem getEatDaybookItemById(Integer id);

    


       
    /**
     * 取得所有EatDaybookItem
     * 
     * @return
     */
    public List<EatDaybookItem> getAll();
    
	/**
     * 根据example取得EatDaybookItem列表
     * 
     * @param  eatDaybookItem
     * @return
     */
    public List<EatDaybookItem> getListByExample(EatDaybookItem eatDaybookItem);
    
        
	/**
     * 根据example取得唯一的EatDaybookItem
     * 
     * @param eatDaybookItem
     * @return
     */
    public EatDaybookItem getUnique(EatDaybookItem eatDaybookItem);
    

    

	/**
     * 分页取得EatDaybookItem列表
     * 
     * @param pageQuery
     * @return
     */
    public List<EatDaybookItem> getEatDaybookItemByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);


    /**
     * 执行结算
     * @param settlementId
     * @param eatDaybook
     */
    public void doSettlement(Integer settlementId, EatDaybook eatDaybook);



    /**
     * 查询总额
     * @param paramMap
     * @return
     */
    public BigDecimal sumPayMoney(Map<String,Object> paramMap);

}
