/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.manager.settlement.EatSettlementManager.java
 */
 package com.jd.ka.eatmoney.manager.settlement;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.settlement.EatSettlement;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 吃饭结算信息Manager接口类
 */
public interface EatSettlementManager {
 
   /**
     * 添加并返回设置id的EatSettlement对象
     * 
     * @param eatSettlement
     * @return
     */
    public EatSettlement addEatSettlement(EatSettlement eatSettlement);
    
	/**
     * 更新EatSettlement
     * 
     * @param eatSettlement
     */
    public void updateEatSettlement(EatSettlement eatSettlement);
    
    

	 /**
     * 根据主键删除EatSettlement
     * 
     * @param id
     */
    public void deleteEatSettlement(Integer id);

    	/**
     * 根据主键获取EatSettlement
     * 
     * @param id
     * @return
     */	
    public EatSettlement getEatSettlementById(Integer id);

    


       
    /**
     * 取得所有EatSettlement
     * 
     * @return
     */
    public List<EatSettlement> getAll();
    
	/**
     * 根据example取得EatSettlement列表
     * 
     * @param  eatSettlement
     * @return
     */
    public List<EatSettlement> getListByExample(EatSettlement eatSettlement);
    
        
	/**
     * 根据example取得唯一的EatSettlement
     * 
     * @param eatSettlement
     * @return
     */
    public EatSettlement getUnique(EatSettlement eatSettlement);
    

    

	/**
     * 分页取得EatSettlement列表
     * 
     * @param pageQuery
     * @return
     */
    public List<EatSettlement> getEatSettlementByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);

}
