/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.manager.user.EatUserManager.java
 */
 package com.jd.ka.eatmoney.manager.user;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.user.EatUser;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 用户Manager接口类
 */
public interface EatUserManager {
 
   /**
     * 添加并返回设置id的EatUser对象
     * 
     * @param eatUser
     * @return
     */
    public EatUser addEatUser(EatUser eatUser);
    
	/**
     * 更新EatUser
     * 
     * @param eatUser
     */
    public void updateEatUser(EatUser eatUser);
    
    

	 /**
     * 根据主键删除EatUser
     * 
     * @param id
     */
    public void deleteEatUser(Integer id);

    	/**
     * 根据主键获取EatUser
     * 
     * @param id
     * @return
     */	
    public EatUser getEatUserById(Integer id);

    


       
    /**
     * 取得所有EatUser
     * 
     * @return
     */
    public List<EatUser> getAll();
    
	/**
     * 根据example取得EatUser列表
     * 
     * @param  eatUser
     * @return
     */
    public List<EatUser> getListByExample(EatUser eatUser);
    
        
	/**
     * 根据example取得唯一的EatUser
     * 
     * @param eatUser
     * @return
     */
    public EatUser getUnique(EatUser eatUser);



    public EatUser getUserByErpAcct(String pin);

    /**
     * 分页取得EatUser列表
     * 
     * @param pageQuery
     * @return
     */
    public List<EatUser> getEatUserByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);



    public List<EatUser> getEatUserListByGroupId(Integer groupId);
}
