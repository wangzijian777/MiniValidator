package com.jd.ka.eatmoney.manager.user.impl;

import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.user.ContactGroup;
import com.jd.ka.eatmoney.dao.user.ContactGroupDao;
import com.jd.ka.eatmoney.manager.user.ContactGroupManager;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 联系人分组Manager实现类
 */
 @Component("contactGroupManager")
public class ContactGroupManagerImpl implements ContactGroupManager {

	@Resource(name="contactGroupDao")
	private ContactGroupDao contactGroupDao;


  public ContactGroup addContactGroup(ContactGroup contactGroup) {
		int i=contactGroupDao.addContactGroup(contactGroup);
		return contactGroup;
    }
    
    public void updateContactGroup(ContactGroup contactGroup) {
		contactGroupDao.updateContactGroup(contactGroup);
    }
    

    
    public void deleteContactGroup(Integer id) {
		contactGroupDao.deleteContactGroup(id);
    }


    public ContactGroup getContactGroupById(Integer id) {
		return contactGroupDao.getContactGroupById(id);
    }
    
   

   
    
    public List<ContactGroup> getAll() {
    	return contactGroupDao.getAll();
    }
    	
    public List<ContactGroup> getListByExample(ContactGroup contactGroup) {
		return contactGroupDao.getListByExample(contactGroup);
    }

        public ContactGroup getUnique(ContactGroup contactGroup) {
		return contactGroupDao.getUnique(contactGroup);
    }

    
    

    
    public List<ContactGroup> getContactGroupByPage(PageQuery pageQuery) {
		return contactGroupDao.getContactGroupByPage( pageQuery.getParams());
    }


    public int count(PageQuery pageQuery) {
		return contactGroupDao.count( pageQuery.getParams());
    }


    public List<ContactGroup> getListByExampleAndPublic(ContactGroup contactGroupQuery) {
        return contactGroupDao.getListByExampleAndPublic(contactGroupQuery);
    }

    /******* getter and setter ***/
    
	public ContactGroupDao getContactGroupDao() {
		return contactGroupDao;
	}

	public void setContactGroupDao(ContactGroupDao contactGroupDao) {
		this.contactGroupDao = contactGroupDao;
	}
}
