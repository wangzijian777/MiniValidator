/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.manager.user.ContactUserItemManager.java
 */
 package com.jd.ka.eatmoney.manager.user;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.user.ContactUserItem;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 联系人信息Manager接口类
 */
public interface ContactUserItemManager {
 
   /**
     * 添加并返回设置id的ContactUserItem对象
     * 
     * @param contactUserItem
     * @return
     */
    public ContactUserItem addContactUserItem(ContactUserItem contactUserItem);
    
	/**
     * 更新ContactUserItem
     * 
     * @param contactUserItem
     */
    public void updateContactUserItem(ContactUserItem contactUserItem);
    
    

	 /**
     * 根据主键删除ContactUserItem
     * 
     * @param id
     */
    public void deleteContactUserItem(Integer id);

    	/**
     * 根据主键获取ContactUserItem
     * 
     * @param id
     * @return
     */	
    public ContactUserItem getContactUserItemById(Integer id);

    


       
    /**
     * 取得所有ContactUserItem
     * 
     * @return
     */
    public List<ContactUserItem> getAll();
    
	/**
     * 根据example取得ContactUserItem列表
     * 
     * @param  contactUserItem
     * @return
     */
    public List<ContactUserItem> getListByExample(ContactUserItem contactUserItem);
    
        
	/**
     * 根据example取得唯一的ContactUserItem
     * 
     * @param contactUserItem
     * @return
     */
    public ContactUserItem getUnique(ContactUserItem contactUserItem);
    

    

	/**
     * 分页取得ContactUserItem列表
     * 
     * @param pageQuery
     * @return
     */
    public List<ContactUserItem> getContactUserItemByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);

}
