package com.jd.ka.eatmoney.manager.user.impl;

import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.dao.user.EatUserDao;
import com.jd.ka.eatmoney.manager.user.EatUserManager;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 用户Manager实现类
 */
 @Component("eatUserManager")
public class EatUserManagerImpl implements EatUserManager {

	@Resource(name="eatUserDao")
	private EatUserDao eatUserDao;


  public EatUser addEatUser(EatUser eatUser) {
		int i=eatUserDao.addEatUser(eatUser);
		return eatUser;
    }
    
    public void updateEatUser(EatUser eatUser) {
		eatUserDao.updateEatUser(eatUser);
    }
    

    
    public void deleteEatUser(Integer id) {
		eatUserDao.deleteEatUser(id);
    }


    public EatUser getEatUserById(Integer id) {
		return eatUserDao.getEatUserById(id);
    }
    
   

   
    
    public List<EatUser> getAll() {
    	return eatUserDao.getAll();
    }
    	
    public List<EatUser> getListByExample(EatUser eatUser) {
		return eatUserDao.getListByExample(eatUser);
    }


    public EatUser getUnique(EatUser eatUser) {
	    List<EatUser> list=this.getListByExample(eatUser);
        if(list==null || list.isEmpty()){
            return null;
        }
        return list.get(0);
    }


    public EatUser getUserByErpAcct(String pin) {
        EatUser eatUserQuery=new EatUser();
        eatUserQuery.setErpAccount(pin);
        EatUser eatUser=this.getUnique(eatUserQuery);
        return  eatUser;
    }

    
    public List<EatUser> getEatUserByPage(PageQuery pageQuery) {
		return eatUserDao.getEatUserByPage( pageQuery.getParams());
    }
    	
    public int count(PageQuery pageQuery) {
		return eatUserDao.count( pageQuery.getParams());
    }


    public List<EatUser> getEatUserListByGroupId(Integer groupId) {
        return eatUserDao.getEatUserListByGroupId(groupId);
    }

    /******* getter and setter ***/
    
	public EatUserDao getEatUserDao() {
		return eatUserDao;
	}

	public void setEatUserDao(EatUserDao eatUserDao) {
		this.eatUserDao = eatUserDao;
	}
}
