package com.jd.ka.eatmoney.manager.user.impl;

import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.user.EatOrg;
import com.jd.ka.eatmoney.dao.user.EatOrgDao;
import com.jd.ka.eatmoney.manager.user.EatOrgManager;

/**
 * @author zhangshibin
 * @since 2015-2-7
 * EatOrgManager实现类
 */
 @Component("eatOrgManager")
public class EatOrgManagerImpl implements EatOrgManager {

	@Resource(name="eatOrgDao")
	private EatOrgDao eatOrgDao;


  public EatOrg addEatOrg(EatOrg eatOrg) {
		int i=eatOrgDao.addEatOrg(eatOrg);
		return eatOrg;
    }
    
    public void updateEatOrg(EatOrg eatOrg) {
		eatOrgDao.updateEatOrg(eatOrg);
    }
    

    
    public void deleteEatOrg(Integer id) {
		eatOrgDao.deleteEatOrg(id);
    }


    public EatOrg getEatOrgById(Integer id) {
		return eatOrgDao.getEatOrgById(id);
    }
    
   

   
    
    public List<EatOrg> getAll() {
    	return eatOrgDao.getAll();
    }
    	
    public List<EatOrg> getListByExample(EatOrg eatOrg) {
		return eatOrgDao.getListByExample(eatOrg);
    }

        public EatOrg getUnique(EatOrg eatOrg) {
		return eatOrgDao.getUnique(eatOrg);
    }

    
    

    
    public List<EatOrg> getEatOrgByPage(PageQuery pageQuery) {
		return eatOrgDao.getEatOrgByPage( pageQuery.getParams());
    }
    	
    public int count(PageQuery pageQuery) {
		return eatOrgDao.count( pageQuery.getParams());
    }

    /******* getter and setter ***/
    
	public EatOrgDao getEatOrgDao() {
		return eatOrgDao;
	}

	public void setEatOrgDao(EatOrgDao eatOrgDao) {
		this.eatOrgDao = eatOrgDao;
	}
}
