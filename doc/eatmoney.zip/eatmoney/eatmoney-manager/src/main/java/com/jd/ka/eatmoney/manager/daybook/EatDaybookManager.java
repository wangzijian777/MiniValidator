/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.manager.daybook.EatDaybookManager.java
 */
 package com.jd.ka.eatmoney.manager.daybook;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.daybook.EatDayBookItemPage;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.domain.settlement.EatSettlement;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 吃饭记账记录Manager接口类
 */
public interface EatDaybookManager {
 
   /**
     * 添加并返回设置id的EatDaybook对象
     * 
     * @param eatDaybook
     * @param list
    * @return
     */
    public EatDaybook addEatDaybook(EatDaybook eatDaybook, List<EatDayBookItemPage> list);
    
	/**
     * 更新EatDaybook
     * 
     * @param eatDaybook
     */
    public void updateEatDaybook(EatDaybook eatDaybook);
    
    

	 /**
     * 根据主键删除EatDaybook
     * 
     * @param id
     */
    public void deleteEatDaybook(Integer id);

    	/**
     * 根据主键获取EatDaybook
     * 
     * @param id
     * @return
     */	
    public EatDaybook getEatDaybookById(Integer id);

    


       
    /**
     * 取得所有EatDaybook
     * 
     * @return
     */
    public List<EatDaybook> getAll();
    
	/**
     * 根据example取得EatDaybook列表
     * 
     * @param  eatDaybook
     * @return
     */
    public List<EatDaybook> getListByExample(EatDaybook eatDaybook);
    
        
	/**
     * 根据example取得唯一的EatDaybook
     * 
     * @param eatDaybook
     * @return
     */
    public EatDaybook getUnique(EatDaybook eatDaybook);
    

    

	/**
     * 分页取得EatDaybook列表
     * 
     * @param pageQuery
     * @return
     */
    public List<EatDaybook> getEatDaybookByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);

    /**
     * 执行结算操作！
     * @param eatSettlement
     * @param eatDaybookList
     */
    public java.math.BigDecimal doSettlement(EatSettlement eatSettlement, List<EatDaybook> eatDaybookList);
}
