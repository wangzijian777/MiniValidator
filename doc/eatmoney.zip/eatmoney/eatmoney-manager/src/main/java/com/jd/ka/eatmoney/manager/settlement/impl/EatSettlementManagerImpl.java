package com.jd.ka.eatmoney.manager.settlement.impl;

import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.settlement.EatSettlement;
import com.jd.ka.eatmoney.dao.settlement.EatSettlementDao;
import com.jd.ka.eatmoney.manager.settlement.EatSettlementManager;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 吃饭结算信息Manager实现类
 */
 @Component("eatSettlementManager")
public class EatSettlementManagerImpl implements EatSettlementManager {

	@Resource(name="eatSettlementDao")
	private EatSettlementDao eatSettlementDao;


  public EatSettlement addEatSettlement(EatSettlement eatSettlement) {
		int i=eatSettlementDao.addEatSettlement(eatSettlement);
		return eatSettlement;
    }
    
    public void updateEatSettlement(EatSettlement eatSettlement) {
		eatSettlementDao.updateEatSettlement(eatSettlement);
    }
    

    
    public void deleteEatSettlement(Integer id) {
		eatSettlementDao.deleteEatSettlement(id);
    }


    public EatSettlement getEatSettlementById(Integer id) {
		return eatSettlementDao.getEatSettlementById(id);
    }
    
   

   
    
    public List<EatSettlement> getAll() {
    	return eatSettlementDao.getAll();
    }
    	
    public List<EatSettlement> getListByExample(EatSettlement eatSettlement) {
		return eatSettlementDao.getListByExample(eatSettlement);
    }

        public EatSettlement getUnique(EatSettlement eatSettlement) {
		return eatSettlementDao.getUnique(eatSettlement);
    }

    
    

    
    public List<EatSettlement> getEatSettlementByPage(PageQuery pageQuery) {
		return eatSettlementDao.getEatSettlementByPage( pageQuery.getParams());
    }
    	
    public int count(PageQuery pageQuery) {
		return eatSettlementDao.count( pageQuery.getParams());
    }

    /******* getter and setter ***/
    
	public EatSettlementDao getEatSettlementDao() {
		return eatSettlementDao;
	}

	public void setEatSettlementDao(EatSettlementDao eatSettlementDao) {
		this.eatSettlementDao = eatSettlementDao;
	}
}
