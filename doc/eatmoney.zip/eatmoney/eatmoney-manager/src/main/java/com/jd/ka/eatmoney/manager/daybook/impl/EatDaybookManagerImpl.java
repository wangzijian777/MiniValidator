package com.jd.ka.eatmoney.manager.daybook.impl;

import com.jd.ka.eatmoney.domain.daybook.EatDayBookItemPage;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;
import com.jd.ka.eatmoney.domain.settlement.EatSettlement;
import com.jd.ka.eatmoney.enumtype.DaybookStatus;
import com.jd.ka.eatmoney.enumtype.PaymentType;
import com.jd.ka.eatmoney.manager.daybook.EatDaybookItemManager;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.dao.daybook.EatDaybookDao;
import com.jd.ka.eatmoney.manager.daybook.EatDaybookManager;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * 吃饭记账记录Manager实现类
 */
 @Component("eatDaybookManager")
public class EatDaybookManagerImpl implements EatDaybookManager {

	@Resource(name="eatDaybookDao")
	private EatDaybookDao eatDaybookDao;

    @Resource(name="eatDaybookItemManager")
    private EatDaybookItemManager eatDaybookItemManager;



   @Transactional(propagation= Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
  public EatDaybook addEatDaybook(EatDaybook eatDaybook, List<EatDayBookItemPage> list) {
		int i=eatDaybookDao.addEatDaybook(eatDaybook);
        this.addEatDaybookItem(eatDaybook,list);
		return eatDaybook;
    }

    /**
     * 增加明细账目
     * @param eatDaybook
     * @param list
     */
    private void addEatDaybookItem(EatDaybook eatDaybook, List<EatDayBookItemPage> list) {
        for(EatDayBookItemPage itemPage:list){
            EatDaybookItem eatDaybookItem=new EatDaybookItem();
            eatDaybookItem.setEatDate(eatDaybook.getEatDate());
            eatDaybookItem.setErpAccount(itemPage.getErpAccount());
            eatDaybookItem.setDaybookId(eatDaybook.getId());
            eatDaybookItem.setGmtCreate(new Date());
            //如果是各付各
            if(eatDaybook.getPayType()== PaymentType.SELF_PAY.getType()){
                eatDaybookItem.setPayErpAccount(eatDaybookItem.getErpAccount());//由本人支付
            }else{
                eatDaybookItem.setPayErpAccount(eatDaybook.getPayErpAccount());
            }
            eatDaybookItem.setPayMoney(itemPage.getPayMoney());
            eatDaybookItem.setStatus(1);
            eatDaybookItem.setInputErpAccount(eatDaybook.getInputErpAccount());
            eatDaybookItem.setUserId(itemPage.getUid());
            eatDaybookItem.setPayType(eatDaybook.getPayType());
            eatDaybookItem.setSubmitErpAccount(eatDaybook.getSubmitErpAccount());
            eatDaybookItemManager.addEatDaybookItem(eatDaybookItem);
        }
    }


    public void updateEatDaybook(EatDaybook eatDaybook) {
		eatDaybookDao.updateEatDaybook(eatDaybook);
    }
    

    
    public void deleteEatDaybook(Integer id) {
        EatDaybook eatDaybook=new EatDaybook();
        eatDaybook.setId(id);
        eatDaybook.setStatus(DaybookStatus.DELETED.getType());
        eatDaybook.setGmtModify(new Date());
        eatDaybookDao.updateEatDaybook(eatDaybook);
      //  eatDaybookDao.deleteEatDaybook(id);
    }


    public EatDaybook getEatDaybookById(Integer id) {
		return eatDaybookDao.getEatDaybookById(id);
    }
    
   

   
    
    public List<EatDaybook> getAll() {
    	return eatDaybookDao.getAll();
    }
    	
    public List<EatDaybook> getListByExample(EatDaybook eatDaybook) {
		return eatDaybookDao.getListByExample(eatDaybook);
    }

        public EatDaybook getUnique(EatDaybook eatDaybook) {
		return eatDaybookDao.getUnique(eatDaybook);
    }

    
    

    
    public List<EatDaybook> getEatDaybookByPage(PageQuery pageQuery) {
		return eatDaybookDao.getEatDaybookByPage( pageQuery.getParams());
    }
    	
    public int count(PageQuery pageQuery) {
		return eatDaybookDao.count( pageQuery.getParams());
    }


    /**
     * 执行结算操作！
     *  @param eatSettlement
     * @param eatDaybookList
     */
    public BigDecimal doSettlement(EatSettlement eatSettlement, List<EatDaybook> eatDaybookList) {
        for(EatDaybook eatDaybook:eatDaybookList){
            //单条更新为已经结算
           this.doSettlementEateDaybook(eatSettlement.getId(), eatDaybook.getId());
           eatDaybookItemManager.doSettlement(eatSettlement.getId(),eatDaybook);
        }
        Map<String, Object> paramMap=new HashMap<String, Object>();
        paramMap.put("settlementId",eatSettlement.getId());
        paramMap.put("status",DaybookStatus.SETTLED.getType());
        BigDecimal    totalMoney=eatDaybookItemManager.sumPayMoney(paramMap);
        return totalMoney;
    }


    /**
     * 执行单条记账记录的结算（修改状态为已经结算）
     * @param settlementId
     * @param daybookId
     */
    private void doSettlementEateDaybook(Integer settlementId, Integer daybookId) {
        EatDaybook eatDaybook=new EatDaybook();
        eatDaybook.setGmtModify(new Date());
        eatDaybook.setSettlementId(settlementId);
        eatDaybook.setId(daybookId);
        eatDaybook.setStatus(DaybookStatus.SETTLED.getType()); //状态为已经结算
        eatDaybookDao.updateEatDaybook(eatDaybook);
    }


    /******* getter and setter ***/
    
	public EatDaybookDao getEatDaybookDao() {
		return eatDaybookDao;
	}

	public void setEatDaybookDao(EatDaybookDao eatDaybookDao) {
		this.eatDaybookDao = eatDaybookDao;
	}
}
