package com.jd.ka.eatmoney.web.util;

import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.enumtype.UserType;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

/**
 * Created by zhangshibin on 2015/1/27.
 */
public class AuthAndViewUtils {

    public static String getViewByUser(String view,EatUser eatUser){
        if(eatUser==null || eatUser.getUserType()==null){
            return view;
        }
        UserType userType=UserType.getType(eatUser.getUserType());
        if(userType==UserType.REPORTER){
            return view+"Reporter";
        }else if(userType==UserType.NORMAL){
            return view+"User";
        }
        return view;
    }



    public static String getViewByUser(String view){
        RequestAttributes requestAttributes= RequestContextHolder.getRequestAttributes();
        EatUser eatUser= (EatUser) requestAttributes.
                getAttribute(CommonConstant.REQUEST_USER_KEY,RequestAttributes.SCOPE_REQUEST);
        return getViewByUser(view,eatUser);
    }

}
