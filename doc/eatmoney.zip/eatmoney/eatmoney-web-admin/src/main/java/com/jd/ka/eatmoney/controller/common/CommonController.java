package com.jd.ka.eatmoney.controller.common;

import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.ka.eatmoney.domain.user.EatOrg;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.enumtype.UserStatus;
import com.jd.ka.eatmoney.enumtype.UserType;
import com.jd.ka.eatmoney.service.user.EatOrgService;
import com.jd.ka.eatmoney.service.user.EatUserService;
import com.jd.ka.eatmoney.web.base.BaseController;
import com.jd.passport.utils.JdLoginUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by zhangshibin on 2015/1/19.
 */
@Controller
@RequestMapping("/public")
public class CommonController extends BaseController{


    @Resource(name="eatUserService")
    private EatUserService eatUserService;

    @Resource(name="eatOrgService")
    private EatOrgService eatOrgService;

    /**
     * 注册页面
     * @return
     */
    @RequestMapping(value="/reg", method = {RequestMethod.GET, RequestMethod.POST})
    public String reg(HttpServletRequest request, ModelMap context){

        EatUser eatUserQuery=new EatUser();
        eatUserQuery.setUserStatus(UserStatus.NORMAL.getType());
        eatUserQuery.setUserType(UserType.REPORTER.getType());
        CommonResult result=eatUserService.getListByExample(eatUserQuery);

        EatOrg eatOrgQuery=new EatOrg();
        eatOrgQuery.setState(CommonConstant.STD_YN_YES);
        CommonResult result2=eatOrgService.getListByExample(eatOrgQuery);
        result.addDefaultModel("orgList",result2.getDefaultModel());
        context.addAttribute("pin", JdLoginUtils.getPin(request));
        this.toVm(result,context);
        return "/public/reg";
    }



    @RequestMapping(value="/doAddUser", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public Map<String,Object> doAddUser(HttpServletRequest request, EatUser eatUser){
        eatUser.setErpAccount(JdLoginUtils.getPin(request));
        CommonResult<String> result=eatUserService.doAddUser(eatUser);
        return result.getReturnMap();
    }



    public void setEatUserService(EatUserService eatUserService) {
        this.eatUserService = eatUserService;
    }
}
