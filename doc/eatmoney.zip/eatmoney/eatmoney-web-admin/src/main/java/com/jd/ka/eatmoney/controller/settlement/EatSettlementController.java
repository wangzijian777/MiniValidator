/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.controller.settlement.EatSettlementController.java
 */
 package com.jd.ka.eatmoney.controller.settlement;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.domain.settlement.DaybookExport;
import com.jd.ka.eatmoney.domain.settlement.UserPayExport;
import com.jd.ka.eatmoney.utils.ExcelUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.web.base.BaseController;
import com.jd.ka.eatmoney.service.settlement.EatSettlementService;
import com.jd.ka.eatmoney.domain.settlement.EatSettlement;

@Controller
@RequestMapping("/settlement/eatSettlement")
public class EatSettlementController extends BaseController {

//	private final static Log log = LogFactory.getLog(EatSettlementAction.class);
	
	@Resource(name="eatSettlementService")
	private EatSettlementService eatSettlementService;


	@RequestMapping(value="manage",method={RequestMethod.GET,RequestMethod.POST})
	public String manage(){
		return "settlement/eatSettlement/manage";
	}

	
	@RequestMapping(value="add",method={RequestMethod.GET,RequestMethod.POST})
    public String add() {
		return "settlement/eatSettlement/add";
    }
    
	
	@RequestMapping(value="doAdd",method={RequestMethod.GET,RequestMethod.POST})
	 public @ResponseBody Map<String,Object> doAdd(EatSettlement eatSettlement, ModelMap context) {
	    		CommonResult<EatSettlement> result =eatSettlementService.addEatSettlement(eatSettlement);
				return result.getReturnMap();
	    }
	 
	 

		@RequestMapping(value="update",method={RequestMethod.GET,RequestMethod.POST})
	    public String update(EatSettlement eatSettlement, ModelMap context) {
			CommonResult<EatSettlement> result = eatSettlementService.getEatSettlementById(eatSettlement.getId());
			this.toVm(result, context);
			return "settlement/eatSettlement/update";
	    }
	    
		
		@RequestMapping(value="doUpdate",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody Map<String,Object> doUpdate(EatSettlement eatSettlement, ModelMap context) {
			CommonResult<EatSettlement> result = eatSettlementService.updateEatSettlement(eatSettlement);
			return result.getReturnMap();
	    }
	    

		@RequestMapping(value="view",method={RequestMethod.GET,RequestMethod.POST})
		public String view(EatSettlement eatSettlement, ModelMap context) {
			CommonResult<EatSettlement> result = eatSettlementService.getEatSettlementById(eatSettlement.getId());
			this.toVm(result, context);
			return "settlement/eatSettlement/view";
	    }
	   
		
		@RequestMapping(value="doDelete",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody  Map<String,Object>  doDelete(EatSettlement eatSettlement) {
			CommonResult<EatSettlement> result =eatSettlementService.deleteEatSettlement(eatSettlement.getId());
			return result.getReturnMap();
	    }
	    
		@RequestMapping(value="list",method={RequestMethod.GET,RequestMethod.POST})
	    public String list(HttpServletRequest request, ModelMap context) {
			PageQuery pageQuery=new PageQuery(request,20);
			CommonResult<List<EatSettlement>> result = eatSettlementService.getEatSettlementByPage(pageQuery);
			this.toVm(result, context);
			return "settlement/eatSettlement/list";
	    }


        @RequestMapping(value="export",method={RequestMethod.GET,RequestMethod.POST})
        public void export(EatSettlement eatSettlement, ModelMap context,
                           HttpServletRequest request,HttpServletResponse response) {
            CommonResult<List<DaybookExport>> result = eatSettlementService.export(eatSettlement.getId());
            ExcelUtil.getInstance().exportData(result.getDefaultModel(),result.getReturnMap(),
                    CommonConstant.EXPORT_SETTLEMENT,request,response);
        }


    @RequestMapping(value="exportPaySettlement",method={RequestMethod.GET,RequestMethod.POST})
    public void exportPaySettlement(EatSettlement eatSettlement, ModelMap context,
                       HttpServletRequest request,HttpServletResponse response) {
        CommonResult<List<UserPayExport>> result = eatSettlementService.exportPaymentSettlement(eatSettlement.getId());
        ExcelUtil.getInstance().exportData(result.getDefaultModel(),result.getReturnMap(),
                CommonConstant.EXPORT_PAY_SETTLEMENT,request,response);
    }


}
