package com.jd.ka.eatmoney.controller.admin;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.enumtype.UserType;
import com.jd.ka.eatmoney.web.base.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jd.common.web.cookie.CookieUtils;
import com.jd.passport.utils.JdLoginUtils;


/**
 * 管理主页
 * @author david
 *
 */
@Controller
@RequestMapping("/admin")
public class AdminController extends BaseController {
	
	@Resource(name="cookieUtils")
	private CookieUtils cookieUtils;

	@RequestMapping("/main")
	public String main(HttpServletRequest request, ModelMap context){
		context.addAttribute("pin", JdLoginUtils.getPin(request));
        EatUser eatUser=this.getEatUser();
        UserType uType=UserType.getType(eatUser.getUserType());
        context.addAttribute("eatUser",eatUser);
        if(uType==UserType.ADMIN){
            return "admin/main/admin";
        }else if(uType==UserType.REPORTER){
            return "admin/main/reporter";
        }
		return "admin/main/user";
	}
	
	
	@RequestMapping(value="logout",method = {RequestMethod.GET,RequestMethod.POST})
	public String logout(HttpServletRequest request, HttpServletResponse response){
		cookieUtils.invalidate(request, response);
		return "redirect:/";
	}


	public CookieUtils getCookieUtils() {
		return cookieUtils;
	}


	public void setCookieUtils(CookieUtils cookieUtils) {
		this.cookieUtils = cookieUtils;
	}
	
	
}
