/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.controller.user.ContactUserItemController.java
 */
 package com.jd.ka.eatmoney.controller.user;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.passport.utils.JdLoginUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.web.base.BaseController;
import com.jd.ka.eatmoney.service.user.ContactUserItemService;
import com.jd.ka.eatmoney.domain.user.ContactUserItem;

@Controller
@RequestMapping("/user/contactUserItem")
public class ContactUserItemController extends BaseController {

//	private final static Log log = LogFactory.getLog(ContactUserItemAction.class);
	
	@Resource(name="contactUserItemService")
	private ContactUserItemService contactUserItemService;


	@RequestMapping(value="manage",method={RequestMethod.GET,RequestMethod.POST})
	public String manage(@RequestParam("groupId")Integer groupId, ModelMap context){
        context.addAttribute("groupId",groupId);
		return "user/contactUserItem/manage";
	}

	
	@RequestMapping(value="add",method={RequestMethod.GET,RequestMethod.POST})
    public String add() {
		return "user/contactUserItem/add";
    }
    
	
	@RequestMapping(value="doAdd",method={RequestMethod.GET,RequestMethod.POST})
	 public @ResponseBody Map<String,Object> doAdd(ContactUserItem contactUserItem, ModelMap context) {
	    		CommonResult<ContactUserItem> result =contactUserItemService.addContactUserItem(contactUserItem);
				return result.getReturnMap();
	    }
	 
	 

		@RequestMapping(value="update",method={RequestMethod.GET,RequestMethod.POST})
	    public String update(ContactUserItem contactUserItem, ModelMap context) {
			CommonResult<ContactUserItem> result = contactUserItemService.getContactUserItemById(contactUserItem.getId());
			this.toVm(result, context);
			return "user/contactUserItem/update";
	    }
	    
		
		@RequestMapping(value="doUpdate",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody Map<String,Object> doUpdate(ContactUserItem contactUserItem, ModelMap context) {
			CommonResult<ContactUserItem> result = contactUserItemService.updateContactUserItem(contactUserItem);
			return result.getReturnMap();
	    }
	    

		@RequestMapping(value="view",method={RequestMethod.GET,RequestMethod.POST})
		public String view(ContactUserItem contactUserItem, ModelMap context) {
			CommonResult<ContactUserItem> result = contactUserItemService.getContactUserItemById(contactUserItem.getId());
			this.toVm(result, context);
			return "user/contactUserItem/view";
	    }
	   
		
		@RequestMapping(value="doDelete",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody  Map<String,Object>  doDelete(ContactUserItem contactUserItem) {
			CommonResult<ContactUserItem> result =contactUserItemService.deleteContactUserItem(contactUserItem.getId());
			return result.getReturnMap();
	    }
	    
		@RequestMapping(value="list",method={RequestMethod.GET,RequestMethod.POST})
	    public String list(HttpServletRequest request, ModelMap context) {
			PageQuery pageQuery=new PageQuery(request,20);
            String pin=JdLoginUtils.getPin(request);
            pageQuery.addQueryParam("ownerErp",pin);
            pageQuery.addQueryParam("status", CommonConstant.STD_YN_YES);
			CommonResult<List<ContactUserItem>> result = contactUserItemService.getContactUserItemByPage(pageQuery);
			this.toVm(result, context);
			return "user/contactUserItem/list";
	    }

    @RequestMapping(value="doConfigUser",method={RequestMethod.GET,RequestMethod.POST})
    public @ResponseBody  Map<String,Object>  doConfigUser(HttpServletRequest request,@RequestParam("groupId")Integer groupId,@RequestParam("userList") String userList) {
        String pin=JdLoginUtils.getPin(request);
        CommonResult<String> result =contactUserItemService.doConfigUser(groupId,userList,pin);
        return result.getReturnMap();
    }




}
