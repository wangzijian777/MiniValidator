package com.jd.ka.eatmoney.web.interceptor;

import com.jd.ka.eatmoney.constant.CacheConstant;
import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.ka.eatmoney.dao.redis.JdRedisUtils;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.enumtype.UserStatus;
import com.jd.ka.eatmoney.service.user.EatUserService;
import com.jd.passport.utils.JdLoginUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by zhangshibin on 2015/1/19.
 */
public class RegisterInterceptor  implements HandlerInterceptor {

    @Resource(name="eatUserService")
    private EatUserService eatUserService;
    @Resource(name="jdRedisUtils")
    private JdRedisUtils jdRedisUtils;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String pin=JdLoginUtils.getPin(request);
        String userCacheKey= CacheConstant.getUserCacheKey(pin);

        EatUser eatUserCached=jdRedisUtils.getObject(userCacheKey,EatUser.class);
        if(eatUserCached!=null){
            RequestAttributes requestAttributes=RequestContextHolder.getRequestAttributes();
            requestAttributes.setAttribute(CommonConstant.REQUEST_USER_KEY,eatUserCached,RequestAttributes.SCOPE_REQUEST);
            return true;
        }

        EatUser eatUserQuery=new EatUser();
        eatUserQuery.setErpAccount(pin);
        EatUser eatUser=eatUserService.getUnique(eatUserQuery);
        if(eatUser!=null){
            if(eatUser.getUserStatus()== UserStatus.NORMAL.getType()){
                jdRedisUtils.setObjectByExpire(userCacheKey,eatUser,CacheConstant.USER_CACHE_EXPIRE);
                RequestAttributes requestAttributes=RequestContextHolder.getRequestAttributes();
                requestAttributes.setAttribute(CommonConstant.REQUEST_USER_KEY,eatUser,RequestAttributes.SCOPE_REQUEST);
                return true;
            }
        }

        if("XMLHttpRequest".equalsIgnoreCase(request.getHeader("X-Requested-With"))){
            response.setContentType("text/html;charset=utf-8");
            response.getWriter().write("{success:false, message:\"你还没有注册\"}");
        }else{
            response.sendRedirect("/public/reg");
        }
        return false;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }


    public void setEatUserService(EatUserService eatUserService) {
        this.eatUserService = eatUserService;
    }
}
