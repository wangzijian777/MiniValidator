/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.controller.daybook.EatDaybookController.java
 */
 package com.jd.ka.eatmoney.controller.daybook;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.alibaba.fastjson.JSON;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.service.user.EatUserService;
import com.jd.ka.eatmoney.web.util.AuthAndViewUtils;
import com.jd.passport.utils.JdLoginUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.web.base.BaseController;
import com.jd.ka.eatmoney.service.daybook.EatDaybookService;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;

@Controller
@RequestMapping("/daybook/eatDaybook")
public class EatDaybookController extends BaseController {

//	private final static Log log = LogFactory.getLog(EatDaybookAction.class);
	
	@Resource(name="eatDaybookService")
	private EatDaybookService eatDaybookService;

    @Resource(name="eatUserService")
    private EatUserService eatUserService;

	@RequestMapping(value="manage",method={RequestMethod.GET,RequestMethod.POST})
	public String manage(HttpServletRequest request, ModelMap context){
        EatUser eatUser=this.getEatUser(request);
        context.addAttribute("eatUser",eatUser);
        return "daybook/eatDaybook/"+AuthAndViewUtils.getViewByUser("manage",eatUser);
	}



    @RequestMapping(value="add",method={RequestMethod.GET,RequestMethod.POST})
    public String add(HttpServletRequest request, ModelMap context) {
        String pin= JdLoginUtils.getPin(request);
        context.addAttribute("pin",pin);
        EatUser eatUser=this.getEatUser(request);
        context.addAttribute("eatUser",eatUser);
		return "daybook/eatDaybook/add";
    }

    @RequestMapping(value="reportMyself",method={RequestMethod.GET,RequestMethod.POST})
    public String reportMyself(HttpServletRequest request, ModelMap context) {
        String pin= JdLoginUtils.getPin(request);
        context.addAttribute("pin",pin);
        EatUser eatUser=eatUserService.getUserByErpAcct(pin);
        context.addAttribute("eatUser",eatUser);
        String chooseUserList="";
        Map<String,Object> userMap=new HashMap<String, Object>();
        userMap.put("uid",eatUser.getId());
        userMap.put("userName",eatUser.getUserName());
        userMap.put("erpAccount",eatUser.getErpAccount());
        userMap.put("payMoney",15);


        SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
        String currentDay=dateFormat.format(new Date());
        context.addAttribute("currentDay",currentDay);
        context.addAttribute("userJson", JSON.toJSON(userMap));
        return "daybook/eatDaybook/reportMyself";
    }

	
	@RequestMapping(value="doAdd",method={RequestMethod.GET,RequestMethod.POST})
	 public @ResponseBody Map<String,Object> doAdd(HttpServletRequest request,EatDaybook eatDaybook, ModelMap context) {
                eatDaybook.setInputErpAccount(JdLoginUtils.getPin(request));
	    		CommonResult<EatDaybook> result =eatDaybookService.addEatDaybook(eatDaybook);
				return result.getReturnMap();
	    }
	 
	 

		@RequestMapping(value="update",method={RequestMethod.GET,RequestMethod.POST})
	    public String update(EatDaybook eatDaybook, ModelMap context) {
			CommonResult<EatDaybook> result = eatDaybookService.getEatDaybookById(eatDaybook.getId());
			this.toVm(result, context);
			return "daybook/eatDaybook/update";
	    }
	    
		
		@RequestMapping(value="doUpdate",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody Map<String,Object> doUpdate(EatDaybook eatDaybook, ModelMap context) {
			CommonResult<EatDaybook> result = eatDaybookService.updateEatDaybook(eatDaybook);
			return result.getReturnMap();
	    }
	    

		@RequestMapping(value="view",method={RequestMethod.GET,RequestMethod.POST})
		public String view(EatDaybook eatDaybook, ModelMap context) {
			CommonResult<EatDaybook> result = eatDaybookService.getEatDaybookById(eatDaybook.getId());
			this.toVm(result, context);
			return "daybook/eatDaybook/view";
	    }
	   
		
		@RequestMapping(value="doDelete",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody  Map<String,Object>  doDelete(EatDaybook eatDaybook) {
			CommonResult<EatDaybook> result =eatDaybookService.deleteEatDaybook(eatDaybook.getId());
			return result.getReturnMap();
	    }
	    
		@RequestMapping(value="list",method={RequestMethod.GET,RequestMethod.POST})
	    public String list(HttpServletRequest request, ModelMap context) {
			int pageSize=this.getPageSize(request,20,200);
            PageQuery pageQuery=new PageQuery(request,pageSize);
			CommonResult<List<EatDaybook>> result = eatDaybookService.getEatDaybookByPage(pageQuery);
			this.toVm(result, context);
			return "daybook/eatDaybook/"+ AuthAndViewUtils.getViewByUser("list");
	    }


        @RequestMapping(value="settlement",method={RequestMethod.GET,RequestMethod.POST})
        public String settlement(HttpServletRequest request, ModelMap context) {
            PageQuery pageQuery=new PageQuery(request,100000);
            pageQuery.setTotalCount(100000);
            EatUser eatUser=this.getEatUser(request);
            CommonResult<String> result = eatDaybookService.settlement(pageQuery, eatUser);
            this.toVm(result,context);
            return "daybook/eatDaybook/settlement";
        }



        @RequestMapping(value="doSettlement",method={RequestMethod.GET,RequestMethod.POST})
        @ResponseBody
        public Map<String, Object> doSettlement(HttpServletRequest request, ModelMap context) {
            PageQuery pageQuery=new PageQuery(request,100000);
            pageQuery.setTotalCount(100000);

            EatUser eatUser=this.getEatUser(request);
            CommonResult<String> result = eatDaybookService.doSettlement(pageQuery,eatUser);
            return result.getReturnMap();
        }
}
