/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.controller.user.EatOrgController.java
 */
 package com.jd.ka.eatmoney.controller.user;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.passport.utils.JdLoginUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.web.base.BaseController;
import com.jd.ka.eatmoney.service.user.EatOrgService;
import com.jd.ka.eatmoney.domain.user.EatOrg;

@Controller
@RequestMapping("/user/eatOrg")
public class EatOrgController extends BaseController {

//	private final static Log log = LogFactory.getLog(EatOrgAction.class);
	
	@Resource(name="eatOrgService")
	private EatOrgService eatOrgService;


	@RequestMapping(value="manage",method={RequestMethod.GET,RequestMethod.POST})
	public String manage(){
		return "user/eatOrg/manage";
	}

	
	@RequestMapping(value="add",method={RequestMethod.GET,RequestMethod.POST})
    public String add(ModelMap context) {
        EatOrg eatOrgQuery=new EatOrg();
        eatOrgQuery.setState(CommonConstant.STD_YN_YES);
        CommonResult result=eatOrgService.getListByExample(eatOrgQuery);
        this.toVm(result,context);
		return "user/eatOrg/add";
    }


    @RequestMapping(value="getOrgList",method={RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public Map getOrgList(ModelMap context) {
        EatOrg eatOrgQuery=new EatOrg();
        eatOrgQuery.setState(CommonConstant.STD_YN_YES);
        CommonResult result=eatOrgService.getListByExample(eatOrgQuery);
       return result.getReturnMap();
    }
	
	@RequestMapping(value="doAdd",method={RequestMethod.GET,RequestMethod.POST})
	 public @ResponseBody Map<String,Object> doAdd(EatOrg eatOrg, HttpServletRequest request,ModelMap context) {
                eatOrg.setCreator(JdLoginUtils.getPin(request));
	    		CommonResult<EatOrg> result =eatOrgService.addEatOrg(eatOrg);
				return result.getReturnMap();
	    }
	 
	 

		@RequestMapping(value="update",method={RequestMethod.GET,RequestMethod.POST})
	    public String update(EatOrg eatOrg, ModelMap context) {
			CommonResult<EatOrg> result = eatOrgService.getEatOrgById(eatOrg.getId());
			this.toVm(result, context);
			return "user/eatOrg/update";
	    }
	    
		
		@RequestMapping(value="doUpdate",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody Map<String,Object> doUpdate(EatOrg eatOrg, ModelMap context) {
			CommonResult<EatOrg> result = eatOrgService.updateEatOrg(eatOrg);
			return result.getReturnMap();
	    }
	    

		@RequestMapping(value="view",method={RequestMethod.GET,RequestMethod.POST})
		public String view(EatOrg eatOrg, ModelMap context) {
			CommonResult<EatOrg> result = eatOrgService.getEatOrgById(eatOrg.getId());
			this.toVm(result, context);
			return "user/eatOrg/view";
	    }
	   
		
		@RequestMapping(value="doDelete",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody  Map<String,Object>  doDelete(EatOrg eatOrg) {
			CommonResult<EatOrg> result =eatOrgService.deleteEatOrg(eatOrg.getId());
			return result.getReturnMap();
	    }
	    
		@RequestMapping(value="list",method={RequestMethod.GET,RequestMethod.POST})
	    public String list(HttpServletRequest request, ModelMap context) {
			PageQuery pageQuery=new PageQuery(request,20);
			CommonResult<List<EatOrg>> result = eatOrgService.getEatOrgByPage(pageQuery);
			this.toVm(result, context);
			return "user/eatOrg/list";
	    }


}
