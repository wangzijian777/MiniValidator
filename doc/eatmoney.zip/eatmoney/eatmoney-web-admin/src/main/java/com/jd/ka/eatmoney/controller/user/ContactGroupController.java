/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.controller.user.ContactGroupController.java
 */
 package com.jd.ka.eatmoney.controller.user;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.service.user.EatUserService;
import com.jd.passport.utils.JdLoginUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.web.base.BaseController;
import com.jd.ka.eatmoney.service.user.ContactGroupService;
import com.jd.ka.eatmoney.domain.user.ContactGroup;

@Controller
@RequestMapping("/user/contactGroup")
public class ContactGroupController extends BaseController {

//	private final static Log log = LogFactory.getLog(ContactGroupAction.class);
	
	@Resource(name="contactGroupService")
	private ContactGroupService contactGroupService;

    @Resource(name="eatUserService")
    private EatUserService eatUserService;

	@RequestMapping(value="manage",method={RequestMethod.GET,RequestMethod.POST})
	public String manage(){
		return "user/contactGroup/manage";
	}

	
	@RequestMapping(value="add",method={RequestMethod.GET,RequestMethod.POST})
    public String add() {
		return "user/contactGroup/add";
    }
    
	
	@RequestMapping(value="doAdd",method={RequestMethod.GET,RequestMethod.POST})
	 public @ResponseBody Map<String,Object> doAdd(HttpServletRequest request,ContactGroup contactGroup, ModelMap context) {
                String pin= JdLoginUtils.getPin(request);
                context.addAttribute("pin",pin);
                EatUser eatUser=eatUserService.getUserByErpAcct(pin);
                contactGroup.setOwnerId(eatUser.getId());
                contactGroup.setOwnerErp(pin);

	    		CommonResult<ContactGroup> result =contactGroupService.addContactGroup(contactGroup);
				return result.getReturnMap();
	    }
	 
	 

		@RequestMapping(value="update",method={RequestMethod.GET,RequestMethod.POST})
	    public String update(ContactGroup contactGroup, ModelMap context) {
			CommonResult<ContactGroup> result = contactGroupService.getContactGroupById(contactGroup.getId());
			this.toVm(result, context);
			return "user/contactGroup/update";
	    }
	    
		
		@RequestMapping(value="doUpdate",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody Map<String,Object> doUpdate(ContactGroup contactGroup, ModelMap context) {
			CommonResult<ContactGroup> result = contactGroupService.updateContactGroup(contactGroup);
			return result.getReturnMap();
	    }
	    

		@RequestMapping(value="view",method={RequestMethod.GET,RequestMethod.POST})
		public String view(ContactGroup contactGroup, ModelMap context) {
			CommonResult<ContactGroup> result = contactGroupService.getContactGroupById(contactGroup.getId());
			this.toVm(result, context);
			return "user/contactGroup/view";
	    }
	   
		
		@RequestMapping(value="doDelete",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody  Map<String,Object>  doDelete(ContactGroup contactGroup) {
			CommonResult<ContactGroup> result =contactGroupService.deleteContactGroup(contactGroup.getId());
			return result.getReturnMap();
	    }
	    
		@RequestMapping(value="list",method={RequestMethod.GET,RequestMethod.POST})
	    public String list(HttpServletRequest request, ModelMap context) {
			PageQuery pageQuery=new PageQuery(request,20);
            String pin=JdLoginUtils.getPin(request);
            pageQuery.addQueryParam("ownerErp",pin);
			CommonResult<List<ContactGroup>> result = contactGroupService.getContactGroupByPage(pageQuery);
			this.toVm(result, context);
			return "user/contactGroup/list";
	    }

        @RequestMapping(value="searchGroup",method={RequestMethod.GET,RequestMethod.POST})
        public String searchGroup(HttpServletRequest request, ModelMap context){
            String pin= JdLoginUtils.getPin(request);
            context.addAttribute("pin",pin);
            ContactGroup contactGroupQuery = new ContactGroup();
            contactGroupQuery.setOwnerErp(pin);
            CommonResult<List<ContactGroup>> result= contactGroupService.getListByExampleAndPublic(contactGroupQuery);
            this.toVm(result,context);
            return "user/contactGroup/searchGroup";
        }




}
