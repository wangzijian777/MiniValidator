/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.controller.user.EatUserController.java
 */
 package com.jd.ka.eatmoney.controller.user;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.ka.eatmoney.domain.user.EatOrg;
import com.jd.ka.eatmoney.service.user.EatOrgService;
import com.jd.passport.utils.JdLoginUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.web.base.BaseController;
import com.jd.ka.eatmoney.service.user.EatUserService;
import com.jd.ka.eatmoney.domain.user.EatUser;

@Controller
@RequestMapping("/user/eatUser")
public class EatUserController extends BaseController {

//	private final static Log log = LogFactory.getLog(EatUserAction.class);
	
	@Resource(name="eatUserService")
	private EatUserService eatUserService;

    @Resource(name="eatOrgService")
    private EatOrgService eatOrgService;

	@RequestMapping(value="manage",method={RequestMethod.GET,RequestMethod.POST})
	public String manage(ModelMap context){
        List<EatOrg> orgList=eatOrgService.getOrgList();
        context.addAttribute("orgList",orgList);
		return "user/eatUser/manage";
	}

	
	@RequestMapping(value="add",method={RequestMethod.GET,RequestMethod.POST})
    public String add(ModelMap context) {
        List<EatOrg> orgList=eatOrgService.getOrgList();
        context.addAttribute("orgList",orgList);
		return "user/eatUser/add";
    }
    
	
	@RequestMapping(value="doAdd",method={RequestMethod.GET,RequestMethod.POST})
	 public @ResponseBody Map<String,Object> doAdd(EatUser eatUser, ModelMap context) {
	    		CommonResult<EatUser> result =eatUserService.addEatUser(eatUser);
				return result.getReturnMap();
	    }
	 
	 

		@RequestMapping(value="update",method={RequestMethod.GET,RequestMethod.POST})
	    public String update(EatUser eatUser, ModelMap context) {
			CommonResult<EatUser> result = eatUserService.getEatUserById(eatUser.getId());
            List<EatOrg> orgList=eatOrgService.getOrgList();
            context.addAttribute("orgList",orgList);
			this.toVm(result, context);
			return "user/eatUser/update";
	    }


        @RequestMapping(value="modifyInfo",method={RequestMethod.GET,RequestMethod.POST})
        public String modifyInfo(HttpServletRequest request,ModelMap context) {
            String erp= JdLoginUtils.getPin(request);
            EatUser eatUser = eatUserService.getUserByErpAcct(erp);
            List<EatOrg> orgList=eatOrgService.getOrgList();
            context.addAttribute("orgList",orgList);
            context.addAttribute("eatUser",eatUser);
            return "user/eatUser/modifyInfo";
        }

		@RequestMapping(value="doUpdate",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody Map<String,Object> doUpdate(EatUser eatUser, ModelMap context) {
			CommonResult<EatUser> result = eatUserService.updateEatUser(eatUser);
			return result.getReturnMap();
	    }




		@RequestMapping(value="view",method={RequestMethod.GET,RequestMethod.POST})
		public String view(EatUser eatUser, ModelMap context) {
			CommonResult<EatUser> result = eatUserService.getEatUserById(eatUser.getId());
            List<EatOrg> orgList=eatOrgService.getOrgList();
            context.addAttribute("orgList",orgList);
			this.toVm(result, context);
			return "user/eatUser/view";
	    }
	   
		
		@RequestMapping(value="doDelete",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody  Map<String,Object>  doDelete(EatUser eatUser) {
			CommonResult<EatUser> result =eatUserService.deleteEatUser(eatUser.getId());
			return result.getReturnMap();
	    }
	    
		@RequestMapping(value="list",method={RequestMethod.GET,RequestMethod.POST})
	    public String list(HttpServletRequest request, ModelMap context) {
            int pageSize=getPageSize(request,20,100);
            PageQuery pageQuery=new PageQuery(request,pageSize);
			CommonResult<List<EatUser>> result = eatUserService.getEatUserByPage(pageQuery);
			this.toVm(result, context);
			return "user/eatUser/list";
	    }


    @RequestMapping(value="searchMain",method={RequestMethod.GET,RequestMethod.POST})
    public String searchMain(ModelMap context){
        List<EatOrg> orgList=eatOrgService.getOrgList();
        context.addAttribute("orgList",orgList);
        return "user/eatUser/searchMain";
    }


    @RequestMapping(value="searchList",method={RequestMethod.GET,RequestMethod.POST})
    public String searchList(HttpServletRequest request, ModelMap context) {
        int pageSize=getPageSize(request,20,100);
        PageQuery pageQuery=new PageQuery(request,pageSize);
        CommonResult<List<EatUser>> result = eatUserService.getEatUserByPage(pageQuery);
        this.toVm(result, context);
        return "user/eatUser/searchList";
    }



    @RequestMapping(value="listByGroupId",method={RequestMethod.GET,RequestMethod.POST})
    public String listByGroupId(@RequestParam("groupId")Integer groupId,HttpServletRequest request, ModelMap context) {
        CommonResult<List<EatUser>> result = eatUserService.getEatUserListByGroupId(groupId);
        result.addModel("groupId",groupId);
        this.toVm(result, context);
        return "user/eatUser/listByGroupId";
    }

}
