package com.jd.ka.eatmoney.web.base;

import javax.servlet.http.HttpServletRequest;

import com.jd.ka.eatmoney.constant.CacheConstant;
import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.ka.eatmoney.domain.user.EatUser;
import org.apache.commons.lang.StringUtils;
import org.springframework.ui.ModelMap;

import com.jd.ka.eatmoney.common.CommonResult;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

public class BaseController {

	
	public void toVm(CommonResult result,ModelMap context){
		this.toVm(result, context, null);
	}
	
	
	public void toVm(CommonResult result,ModelMap context,HttpServletRequest request){
		context.putAll(result.getReturnMap());
	}
	
	
	public int getPageSize(HttpServletRequest request,int defaultPageSize,int max) {
		String pageSizeStr=request.getParameter("pageSize");
    	int pageSize=defaultPageSize;
    	if(StringUtils.isNumeric(pageSizeStr)){
    		try{
    			pageSize=Integer.valueOf(pageSizeStr);
    		}catch (Exception e) {
			}
    		//不能超过最大值
    		pageSize=pageSize>max?max:pageSize;
    	}
		return pageSize;
	}


    public EatUser getEatUser(HttpServletRequest request){
        return (EatUser) request.getAttribute(CommonConstant.REQUEST_USER_KEY);
    }


    public EatUser getEatUser(){
        RequestAttributes requestAttributes= RequestContextHolder.getRequestAttributes();
        return (EatUser) requestAttributes.getAttribute(CommonConstant.REQUEST_USER_KEY,RequestAttributes.SCOPE_REQUEST);
    }

}
