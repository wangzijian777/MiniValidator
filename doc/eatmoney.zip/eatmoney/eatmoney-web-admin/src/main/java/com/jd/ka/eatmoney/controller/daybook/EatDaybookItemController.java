/**
 * Copyright(c) 2004-2015 www.jd.com
 * com.jd.ka.eatmoney.controller.daybook.EatDaybookItemController.java
 */
 package com.jd.ka.eatmoney.controller.daybook;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.web.util.AuthAndViewUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.web.base.BaseController;
import com.jd.ka.eatmoney.service.daybook.EatDaybookItemService;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;

@Controller
@RequestMapping("/daybook/eatDaybookItem")
public class EatDaybookItemController extends BaseController {

//	private final static Log log = LogFactory.getLog(EatDaybookItemAction.class);
	
	@Resource(name="eatDaybookItemService")
	private EatDaybookItemService eatDaybookItemService;


	@RequestMapping(value="manage",method={RequestMethod.GET,RequestMethod.POST})
	public String manage(HttpServletRequest request, ModelMap context){
        EatUser eatUser=this.getEatUser(request);
        context.addAttribute("eatUser",eatUser);
        return "daybook/eatDaybookItem/"+AuthAndViewUtils.getViewByUser("manage",eatUser);
	}



    @RequestMapping(value="add",method={RequestMethod.GET,RequestMethod.POST})
    public String add() {
		return "daybook/eatDaybookItem/add";
    }
    
	
	@RequestMapping(value="doAdd",method={RequestMethod.GET,RequestMethod.POST})
	 public @ResponseBody Map<String,Object> doAdd(EatDaybookItem eatDaybookItem, ModelMap context) {
	    		CommonResult<EatDaybookItem> result =eatDaybookItemService.addEatDaybookItem(eatDaybookItem);
				return result.getReturnMap();
	    }
	 
	 

		@RequestMapping(value="update",method={RequestMethod.GET,RequestMethod.POST})
	    public String update(EatDaybookItem eatDaybookItem, ModelMap context) {
			CommonResult<EatDaybookItem> result = eatDaybookItemService.getEatDaybookItemById(eatDaybookItem.getId());
			this.toVm(result, context);
			return "daybook/eatDaybookItem/update";
	    }
	    
		
		@RequestMapping(value="doUpdate",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody Map<String,Object> doUpdate(EatDaybookItem eatDaybookItem, ModelMap context) {
			CommonResult<EatDaybookItem> result = eatDaybookItemService.updateEatDaybookItem(eatDaybookItem);
			return result.getReturnMap();
	    }
	    

		@RequestMapping(value="view",method={RequestMethod.GET,RequestMethod.POST})
		public String view(EatDaybookItem eatDaybookItem, ModelMap context) {
			CommonResult<EatDaybookItem> result = eatDaybookItemService.getEatDaybookItemById(eatDaybookItem.getId());
			this.toVm(result, context);
			return "daybook/eatDaybookItem/view";
	    }
	   
		
		@RequestMapping(value="doDelete",method={RequestMethod.GET,RequestMethod.POST})
	    public @ResponseBody  Map<String,Object>  doDelete(EatDaybookItem eatDaybookItem) {
			CommonResult<EatDaybookItem> result =eatDaybookItemService.deleteEatDaybookItem(eatDaybookItem.getId());
			return result.getReturnMap();
	    }
	    
		@RequestMapping(value="list",method={RequestMethod.GET,RequestMethod.POST})
	    public String list(HttpServletRequest request, ModelMap context) {
			PageQuery pageQuery=new PageQuery(request,20);
			CommonResult<List<EatDaybookItem>> result = eatDaybookItemService.getEatDaybookItemByPage(pageQuery);
			this.toVm(result, context);
			return "daybook/eatDaybookItem/"+ AuthAndViewUtils.getViewByUser("list");
	    }






}
