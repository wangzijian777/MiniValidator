/**
 util类
*/
(function($,w){
	w.gUtils = w.gUtils || {};
	var utils = w.gUtils;
 
	$.extend(utils,{
			 /** 渲染简单模板
			  * @param template 模板
			  * @param data 数据
			  * */
		 fRenderTemplate:function(template,data){
			var content='';
			if(data instanceof Array){
				for(var i=0;i<data.length;i++){
					content+=this.fRenderTemplate(template,data[i]);
				}
			}else{
				var t=template;
				for(var attr in data){
					var value=data[attr];
					if(value==null){
						value='';
					}
					t=t.replace(new RegExp("@{"+attr+"}","gm"),value);
				}
				content+=t;
			}
			return content;
		 },
		/**
		 *    弹出确认框 操作成功刷新列表，操作失败提示消息      
		 **/
		fConfirmAndRefreshList:function(config) {	
			gDialog.fConfirm(config.title, config.info, function(rs) {
                if(!rs){
                    return;
                }
	            jQuery.ajax({
	    			url: config.url,
	    			type:'post',
	    			dataType: "json",
	    			data: config.param,
	    			success: function(data, ts) {
						gDialog.fClose();
						if(data['success']) {
								if(data['message']!=null & data['message']!=''){
									message_box.show(data['message'],'success');
								}
								queryList();			
						 }else{
							var sMessage=data['message'];
							if(sMessage==null){
								sMessage='处理异常，请联系管理员！';
							}
							gDialog.fAlert(sMessage);
						 }
					}
				});
			});
		},
		/**
		 * 
		 * @param param 表单参数
		 * @param validateSet 验证规则
		 * @param url URL
		 * @param successHandler 操作成功处理
		 * @param errorHandler 操作失败处理
		 */
		fSubmitForm: function(param, validateSet, url, successHandler, errorHandler) {
			if (form.validate(validateSet)) {
				$.ajax({
					url: url,
					type:'post',
					dataType: "json",
					data: param,
					success: function(data, ts) {
						gUtils.fProcessResult(data, successHandler, errorHandler);
					},
					beforeSend: function() {
						//$('.btn_submit').attr('disabled', true);
					}
				});
			}
		},
		fProcessResult: function(data, successHandler, errorHandler) {
			if (data) {
				if (data['success'] && data['success'] == true) {
					successHandler.call(this,data);
				} else {
					if (errorHandler) {
						errorHandler.call(this,data);
					} else {
						var sMessage=data['message'];
				 		if(sMessage==null){
							sMessage='处理异常，请联系管理员！';
						}
				 		gDialog.fAlert(sMessage);
					}
					//$('.btn_submit').attr('disabled', false);
				}
			}
		},
		fGetIFrame: function(url,id, param) {
			var jFrame=$("#"+id);
			if(jFrame.length<1){
				jFrame=$('iframe[name='+id+']');
			}
			if(jFrame.length>0){
				jFrame.attr("src",url)
			}
		},
		/** 获取主内容*/
		fGetBody: function(url, param,loadingMsg) {
			this.fGetHtml(url,'main_content' ,param,loadingMsg);
		},
		fGetHtml: function(url, id, param,loadingMsg) {
			var jContainer=$("#"+id);
			var timeFlag=(new Date()).getTime();
			jContainer.data('timeFlag',timeFlag);
			$.ajax({
				url:  url,
				dataType: "html",
				type:'post',
				data: param,
				success: function(data, textStatus) {
					var newTimeFlag=jContainer.data('timeFlag');
					if(timeFlag<newTimeFlag){
						//console.log('已经被新的内容更新，丢弃');
						return ;
					}
					jContainer.html(data);
				},
				beforeSend: function() {
					if(loadingMsg!=null &&loadingMsg!=false){
						gUtils.fLoading(id,loadingMsg);
					}
				}
			});
		},
		fLoading: function(id,loadingMsg){
			if(loadingMsg==true){
				loadingMsg='页面加载中，请稍候...';
			}
			$("#"+id).html('<div id="loading" class="data_loading">'+loadingMsg+'</div>');
		},
		fPageSize:function(methodName,dom,event){
			var $this=$(dom);
			var value=$this.val();
			value=value.replace(/[^\d]/g,'');
			$this.val(value);
			//解决浏览器之间的差异问题 
			var keyCode=event.keyCode ? event.keyCode:(event.which?event.which:event.charCode);
			if(keyCode!=13){ 
				return ;
			} 
			if(isNaN(value)){
				return;
			}
			var pageFun=eval(methodName);
			if(pageFun!=null){
				pageFun(1,value);
			}
			
		},
		fPostForm:function(url,param,target){
			target=target?target:'_blank';
			var _jForm = $("<form></form>",{ 
                            'id':'tempForm', 
                            'method':'post', 
                            'action':url, 
                            'target':target, 
                            'style':'display:none' 
                            }).appendTo($("body")); 


    		for(var attr in param){
    			var value=param[attr];
    			if(value!=null&&value!=''){
    				_jForm.append($("<input>",{'type':'hidden','name':attr,'value':value})); 
    			}
    		}
			
    		//触发提交事件 
            _jForm.trigger("submit"); 
            //表单删除 
          	 _jForm.remove(); 
		},
		/**
		 * 更新导航
		 * 
		 * @param id
		 * @param text
		 * @param url
		 */
		fUpdateNav : function(flag, id, text, url) {
			if (id == null) return;
			
			if (text!=null&&text!='') {
				var template='';
				var datas={'menuId':id,'menuName':text,'menuUrl':url};
				if(url==null||url==''){
					template='<li id="@{menuId}"><a href="javascript:;">@{menuName}</a> <span class="divider">/</span></li>';
				}else{
					template='<li id="@{menuId}"><a href="javascript:;" onclick="gUtils.fGotoNavLink(\'@{menuUrl}\',\'@{menuId}\')">@{menuName}</a> <span class="divider">/</span></li>';
				}
				var content=this.fRenderTemplate(template,datas);
				if(flag){
					$('#crumbs').html(content);
				}else{
					$('#crumbs').append(content);
				}
			}else{
				$('#' + id).remove();
			}
		},
		fUpdateNavFrame : function(flag, id, text, url,frameId) {
			if (id == null) return;
			if (text!=null&&text!='') {
				var template='';
				var datas={'menuId':id,'menuName':text,'menuUrl':url,'frameId':frameId};
				if(url==null||url==''){
					template='<li id="@{menuId}"><a href="javascript:;">@{menuName}</a> <span class="divider">/</span></li>';
				}else{
					template='<li id="@{menuId}"><a href="javascript:;" onclick="gUtils.fGotoNavLinkFrame(\'@{menuUrl}\',\'@{menuId}\',\'@{frameId}\')">@{menuName}</a> <span class="divider">/</span></li>';
				}
				var content=this.fRenderTemplate(template,datas);
				if(flag){
					$('#crumbs').html(content);
				}else{
					$('#crumbs').append(content);
				}
			}else{
				$('#' + id).remove();
			}
		},
		/**
		 * 跳转到指定页面，同时删除该导航后面的选项
		 */
		fGotoNavLink : function(url,id){
			var next=$("#"+id).next();
			if(next.length>0){
				$(next).remove();
			}
			this.fGetBody(url);
		},
		fGotoNavLinkFrame : function(url,id,frameId){
			var next=$("#"+id).next();
			if(next.length>0){
				$(next).remove();
			}
			if(url.indexOf('?')!=-1){
				url=url+'&t='+(new Date().getTime());
			}else{
				url=url+'?t='+(new Date().getTime());
			}
			this.fGetIFrame(url,frameId);
		}

	});
})(jQuery,window);




 /**
  * This tiny script just helps us demonstrate
  * what the various example callbacks are doing
  */
 window.message_box = (function($) {
     "use strict";


	 var alertTemplate='<div id="message_box_info_@{randomId}" class="alert @{alertStyle}" style="display:none;width:550px;position:fixed;'+
		 'left:50%;margin-left:-270px;z-index:10000;" role="alert"><button type="button" class="close">&times;</button> @{alertInfo}'+
		 '@{alertMessage}</div>';

    var that={};
	 var alertArray=new Array();

	 that.show = function(text,type,time) {

     	 var alertClass='';
		 var alertInfo='';
     	 if(type=='info'){
     		alertClass='alert-info';
			 alertInfo='<strong><i class="fa fa-info-circle"></i>提醒：</strong>';
     	 }else if(type=='success'){
     		alertClass='alert-success';
			 alertInfo='<strong><i class="fa fa fa-check-circle"></i>成功！</strong>';
     	 }else if(type=='error'){
     		 alertClass='alert-error';
			 alertInfo='<strong><i class="fa fa-times-circle"></i>错误：</strong>';
		 }else if(type=='danger'){
			 alertClass='alert-error';
			 alertInfo='<strong><i class="fa fa-minus-circle"></i>危险：</strong>';
		 }else{
			 alertClass='';
			 alertInfo='<strong><i class="fa fa-exclamation-triangle"></i>警告：</strong>';
		 }
		var maxTop=that.getMaxTopOfAlert();
		 var data={'alertStyle':alertClass ,'alertInfo':alertInfo, 'randomId':new Date().getTime(),'alertMessage':text,'alertTop':maxTop};
		 var html=gUtils.fRenderTemplate(alertTemplate,data);
		 var elem=$(html).appendTo('body');
		 elem.css('top',maxTop+5);
         elem.fadeIn();
		 alertArray.push(elem);
         if(time==null || isNaN(time)){
         	time=4000;
         }

         setTimeout(function() {
			 that.removeAlert(elem);
         }, time);

		 elem.find('button.close').click(function(){
			 that.removeAlert(elem);
		 });
     };

     that.removeAlert = function(elem) {
		var idx=that.getIndexOfAlert(elem);
		 if(idx!=null && idx!=-1){
			 alertArray.splice(idx,1);
		 }
		 elem.remove();
     };
	 that.getIndexOfAlert=function (alert) {
		 for (var i = 0; i < alertArray.length; i++){
			 if (alert === alertArray[i]) return i;
		 }
		 return -1;
	 };

	 that.getMaxTopOfAlert=function(){
		 if(alertArray==null||alertArray.length==0){
			 return 25;
		 }
		 var alert=alertArray[alertArray.length-1];
		 return alert.innerHeight()+alert.position().top;
	 }

     that.info=function(text,time){
         that.show(text,"info",time);
     };

     that.error=function(text,time){
         that.show(text,"error",time);
     };
	 that.danger=function(text,time){
		 that.show(text,"danger",time);
	 };
     that.warning=function(text,time){
         that.show(text,"waring",time);
     };

     that.success=function(text,time){
         that.show(text,"success",time);
     };

     return that;
 }(jQuery));



(function($) {

    $.fn.lazyClick = function(callback,time) {
       var _this=this;
       var jthis=$(this);
        var lazyTime=1000;
        if(time!=null && time>0){
            lazyTime=time;
        }
        jthis.bind('click',function(){
            var lastTime=jthis.data('lastClick');
            var nowTime=new Date().getTime();
            if(lastTime!=null){
                if(nowTime-lastTime<lazyTime){
                    return;
                }
            }
            jthis.data('lastClick',nowTime);
            callback.apply(_this);
        });
    };

})(jQuery);