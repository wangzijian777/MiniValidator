/*
*
* */



 (function(){
    var bs = {
        init : function(){
            var that = this;
            that.dom();
        },
        dom : function(){
            //左边导航
            var oAccordion = $(".u-sider-accordion")
            ,oTit = oAccordion.find(".u-sider-accordion-tit");
            oTit.click(function(){
                var oPar = $(this).parent();
                oPar.find("ul").toggle().end().find(".panel-tool a").toggleClass("accordion-expand");
                oPar.siblings().find("ul").hide().end().find(".panel-tool a").addClass("accordion-expand");
            })

        },
        resetIframeHeight :function (obj){
         var cwin=obj;
         if (document.getElementById){
             if (cwin && !window.opera){
                 if (cwin.contentDocument && cwin.contentDocument.body.offsetHeight){
                     //alert("cwin.contentDocument.body.offsetHeight="+cwin.contentDocument.body.offsetHeight);
                     cwin.height = cwin.contentDocument.body.offsetHeight;
                 }else if(cwin.Document && cwin.Document.body.scrollHeight){
                     cwin.height = cwin.Document.body.scrollHeight;
                     //alert("cwin.Document.body.scrollHeight="+cwin.Document.body.scrollHeight);
                 }
             }
         }
     }
    };

    window.bs = bs;
})();

$(function(){
    bs.init();
});
