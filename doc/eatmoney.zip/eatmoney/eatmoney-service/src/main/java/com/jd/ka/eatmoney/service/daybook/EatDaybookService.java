package com.jd.ka.eatmoney.service.daybook;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.domain.user.EatUser;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * jshow 吃饭记账记录service 接口
 *
 */
public interface EatDaybookService {
   
    /**
     * 添加并返回设置id的EatDaybook对象
     * 
     * @param eatDaybook
     * @return
     */
    public CommonResult<EatDaybook> addEatDaybook(EatDaybook eatDaybook);
    
	/**
     * 更新EatDaybook
     * 
     * @param eatDaybook
     */
    public CommonResult<EatDaybook> updateEatDaybook(EatDaybook eatDaybook);
    

    

	 /**
     * 根据主键删除EatDaybook
     * 
     * @param id
     */
    public CommonResult<EatDaybook> deleteEatDaybook(Integer id);

	/**
     * 根据主键获取EatDaybook
     * 
     * @param id
     * @return
     */	
    public CommonResult<EatDaybook> getEatDaybookById(Integer id);

     

    /**
     * 取得所有EatDaybook
     * 
     * @return
     */
    public CommonResult<List<EatDaybook>> getAll();
    
	/**
     * 根据example取得EatDaybook列表
     * 
     * @param  eatDaybook
     * @return
     */
    public CommonResult<List<EatDaybook>> getListByExample(EatDaybook eatDaybook);
    
	/**
     * 根据example取得唯一的EatDaybook
     * 
     * @param eatDaybook
     * @return
     */
    public CommonResult<EatDaybook> getUnique(EatDaybook eatDaybook);
    
    


    

	/**
     * 分页取得EatDaybook列表
     * 
     * @param pageQuery
     * @return
     */
    public CommonResult<List<EatDaybook>> getEatDaybookByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);


    /**
     * 结算确认页
     * @param pageQuery
     * @param eatUser
     * @return
     */
    public CommonResult<String> settlement(PageQuery pageQuery, EatUser eatUser);



    /**
     * 执行结算
     * @param pageQuery
     * @param eatUser
     * @return
     */
    public  CommonResult<String> doSettlement(PageQuery pageQuery, EatUser eatUser);

}
