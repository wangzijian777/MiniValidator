package com.jd.ka.eatmoney.service.user.impl;



import javax.annotation.Resource;
import java.util.List;
import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.jd.ka.eatmoney.constant.CommonConstant;
import com.jd.ka.eatmoney.domain.user.ContactGroup;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.manager.user.ContactGroupManager;
import com.jd.ka.eatmoney.manager.user.EatUserManager;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.apache.log4j.Logger;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.user.ContactUserItem;
import com.jd.ka.eatmoney.manager.user.ContactUserItemManager;
import com.jd.ka.eatmoney.service.user.ContactUserItemService;


/**
 * @author zhangshibin
 * @since 2015-1-19
 *<p>  联系人信息service实现</p>
 *
 */
@Service("contactUserItemService")
public class ContactUserItemServiceImpl implements ContactUserItemService {

	private static final Logger logger = Logger.getLogger(ContactUserItemServiceImpl.class);
	
	@Resource(name="contactUserItemManager")
	private ContactUserItemManager contactUserItemManager;

    @Resource(name="contactGroupManager")
    private ContactGroupManager contactGroupManager;
    @Resource(name="eatUserManager")
    private EatUserManager eatUserManager;


    public CommonResult<ContactUserItem> addContactUserItem(ContactUserItem contactUserItem) {
		CommonResult<ContactUserItem> result = new CommonResult<ContactUserItem>();
		try {
			
				contactUserItem.setGmtCreate(new Date());
			 
			result.addDefaultModel(contactUserItemManager.addContactUserItem(contactUserItem));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("添加 联系人信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<ContactUserItem> updateContactUserItem(ContactUserItem contactUserItem) {
		CommonResult<ContactUserItem> result = new CommonResult<ContactUserItem>();
		try {
			
			contactUserItemManager.updateContactUserItem(contactUserItem);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("更新 联系人信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
   

	public CommonResult<ContactUserItem> deleteContactUserItem(Integer id) {
		CommonResult<ContactUserItem> result = new CommonResult<ContactUserItem>();
		try {
			contactUserItemManager.deleteContactUserItem(id);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("删除 联系人信息失败", e);
			result.setSuccess(false);
		}
		return result;
    }


    	public CommonResult<ContactUserItem> getContactUserItemById(Integer id) {
		CommonResult<ContactUserItem> result = new CommonResult<ContactUserItem>();
		try {
			result.addDefaultModel("contactUserItem", contactUserItemManager.getContactUserItemById(id));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据主键获取 联系人信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	

        
	
	public CommonResult<List<ContactUserItem>> getAll() {
		CommonResult<List<ContactUserItem>> result = new CommonResult<List<ContactUserItem>>();
		try {
			List<ContactUserItem> list = contactUserItemManager.getAll();
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得所有 联系人信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<List<ContactUserItem>> getListByExample(ContactUserItem contactUserItem) {
		CommonResult<List<ContactUserItem>> result = new CommonResult<List<ContactUserItem>>();
		try {
			List<ContactUserItem> list = contactUserItemManager.getListByExample(contactUserItem);
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得 联系人信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	public CommonResult<ContactUserItem> getUnique(ContactUserItem contactUserItem) {
		CommonResult<ContactUserItem> result = new CommonResult<ContactUserItem>();
		try {
			result.addDefaultModel(contactUserItemManager.getUnique(contactUserItem));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据example获取唯一 联系人信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	



	
	public CommonResult<List<ContactUserItem>> getContactUserItemByPage(PageQuery pageQuery) {
		CommonResult<List<ContactUserItem>> result = new CommonResult<List<ContactUserItem>>();
		try {
			int totalCount = this.count(pageQuery);
			if (totalCount > 0) {
				pageQuery.setTotalCount(totalCount);
				List<ContactUserItem> list = contactUserItemManager.getContactUserItemByPage(pageQuery);
				result.addDefaultModel("list", list);
				result.addModel("pageQuery", pageQuery);
			}
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("分页获取 联系人信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public int count(PageQuery pageQuery) {
		return contactUserItemManager.count(pageQuery);
	}


    /**
     * 小组添加用户
     *
     * @param groupId
     * @param userList
     * @param pin
     * @return
     */
    public CommonResult<String> doConfigUser(Integer groupId, String userList, String pin) {
        CommonResult<String> result = new CommonResult<String>();
        if(groupId==null || StringUtils.isEmpty(pin)){
            result.setSuccess(false);
            result.setMessage("参数有误！");
            return result;
        }

        try {

            ContactGroup contactGroup=contactGroupManager.getContactGroupById(groupId);
            List<EatUser> eatUserList=JSON.parseArray(userList, EatUser.class);
            if(contactGroup==null || eatUserList.isEmpty()){
                result.setSuccess(false);
                result.setMessage("参数有误！");
                return result;
            }

            EatUser owner=eatUserManager.getUserByErpAcct(pin);
            int count=0;
            for(EatUser eatUser:eatUserList){
                EatUser dbEatUser=eatUserManager.getUserByErpAcct(eatUser.getErpAccount());

                ContactUserItem itemQuery=new ContactUserItem();
                itemQuery.setGroupId(groupId);
                itemQuery.setFriendErp(eatUser.getErpAccount());
                ContactUserItem dbContactUserItem=contactUserItemManager.getUnique(itemQuery);
                if(dbContactUserItem!=null){
                    continue;
                }
                ContactUserItem contactUserItem=new ContactUserItem();
                contactUserItem.setOwnerId(owner.getId());
                contactUserItem.setOwnerErp(pin);
                contactUserItem.setFriendId(dbEatUser.getId());
                contactUserItem.setFriendErp(dbEatUser.getErpAccount());
                contactUserItem.setGmtCreate(new Date());
                contactUserItem.setAliasName(dbEatUser.getUserName());
                contactUserItem.setStatus(CommonConstant.STD_YN_YES);
                contactUserItem.setGroupId(groupId);
                contactUserItemManager.addContactUserItem(contactUserItem);
                count++;
            }
            result.setMessage("添加成功"+count+"个用户！");
            result.setSuccess(true);
        } catch (Exception e) {
            logger.error("配置小组成员失败", e);
            result.setMessage("配置小组成员失败:"+e.getMessage());
            result.setSuccess(false);
        }
        return result;
    }

    /******* getter and setter ***/
	public ContactUserItemManager getContactUserItemManager() {
		return contactUserItemManager;
	}

	public void setContactUserItemManager(ContactUserItemManager contactUserItemManager) {
		this.contactUserItemManager = contactUserItemManager;
	}

}
