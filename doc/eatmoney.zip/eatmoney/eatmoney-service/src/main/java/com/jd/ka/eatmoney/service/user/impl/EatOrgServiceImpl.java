package com.jd.ka.eatmoney.service.user.impl;



import javax.annotation.Resource;
import java.util.List;
import java.util.Date;

import com.jd.ka.eatmoney.constant.CommonConstant;
import org.springframework.stereotype.Service;
import org.apache.log4j.Logger;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.user.EatOrg;
import com.jd.ka.eatmoney.manager.user.EatOrgManager;
import com.jd.ka.eatmoney.service.user.EatOrgService;


/**
 * @author zhangshibin
 * @since 2015-2-7
 *<p>  EatOrgservice实现</p>
 *
 */
@Service("eatOrgService")
public class EatOrgServiceImpl implements EatOrgService {

	private static final Logger logger = Logger.getLogger(EatOrgServiceImpl.class);
	
	@Resource(name="eatOrgManager")
	private EatOrgManager eatOrgManager;
    
    public CommonResult<EatOrg> addEatOrg(EatOrg eatOrg) {
		CommonResult<EatOrg> result = new CommonResult<EatOrg>();
		try {
			eatOrg.setCreated(new Date());
			result.addDefaultModel(eatOrgManager.addEatOrg(eatOrg));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("添加 EatOrg失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<EatOrg> updateEatOrg(EatOrg eatOrg) {
		CommonResult<EatOrg> result = new CommonResult<EatOrg>();
		try {
			
				eatOrg.setModified(new Date());
			 
			eatOrgManager.updateEatOrg(eatOrg);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("更新 EatOrg失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
   

	public CommonResult<EatOrg> deleteEatOrg(Integer id) {
		CommonResult<EatOrg> result = new CommonResult<EatOrg>();
		try {
			eatOrgManager.deleteEatOrg(id);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("删除 EatOrg失败", e);
			result.setSuccess(false);
		}
		return result;
    }


    	public CommonResult<EatOrg> getEatOrgById(Integer id) {
		CommonResult<EatOrg> result = new CommonResult<EatOrg>();
		try {
			result.addDefaultModel("eatOrg", eatOrgManager.getEatOrgById(id));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据主键获取 EatOrg失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	

        
	
	public CommonResult<List<EatOrg>> getAll() {
		CommonResult<List<EatOrg>> result = new CommonResult<List<EatOrg>>();
		try {
			List<EatOrg> list = eatOrgManager.getAll();
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得所有 EatOrg失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<List<EatOrg>> getListByExample(EatOrg eatOrg) {
		CommonResult<List<EatOrg>> result = new CommonResult<List<EatOrg>>();
		try {
			List<EatOrg> list = eatOrgManager.getListByExample(eatOrg);
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得 EatOrg失败", e);
			result.setSuccess(false);
		}
		return result;
	}


    /**
     * 获取所有有效的机构列表
     *
     * @return
     */
    public List<EatOrg> getOrgList() {
        EatOrg eatOrg=new EatOrg();
        eatOrg.setState(CommonConstant.STD_YN_YES);
        List<EatOrg> list = eatOrgManager.getListByExample(eatOrg);
        return  list;
    }

    public CommonResult<EatOrg> getUnique(EatOrg eatOrg) {
		CommonResult<EatOrg> result = new CommonResult<EatOrg>();
		try {
			result.addDefaultModel(eatOrgManager.getUnique(eatOrg));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据example获取唯一 EatOrg失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	



	
	public CommonResult<List<EatOrg>> getEatOrgByPage(PageQuery pageQuery) {
		CommonResult<List<EatOrg>> result = new CommonResult<List<EatOrg>>();
		try {
			int totalCount = this.count(pageQuery);
			if (totalCount > 0) {
				pageQuery.setTotalCount(totalCount);
				List<EatOrg> list = eatOrgManager.getEatOrgByPage(pageQuery);
				result.addDefaultModel("list", list);
				result.addModel("pageQuery", pageQuery);
			}
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("分页获取 EatOrg失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public int count(PageQuery pageQuery) {
		return eatOrgManager.count(pageQuery);
	}


	/******* getter and setter ***/
	public EatOrgManager getEatOrgManager() {
		return eatOrgManager;
	}

	public void setEatOrgManager(EatOrgManager eatOrgManager) {
		this.eatOrgManager = eatOrgManager;
	}

}
