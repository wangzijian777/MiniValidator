package com.jd.ka.eatmoney.service.user;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.user.EatOrg;

/**
 * @author zhangshibin
 * @since 2015-2-7
 * jshow EatOrgservice 接口
 *
 */
public interface EatOrgService {
   
    /**
     * 添加并返回设置id的EatOrg对象
     * 
     * @param eatOrg
     * @return
     */
    public CommonResult<EatOrg> addEatOrg(EatOrg eatOrg);
    
	/**
     * 更新EatOrg
     * 
     * @param eatOrg
     */
    public CommonResult<EatOrg> updateEatOrg(EatOrg eatOrg);
    

    

	 /**
     * 根据主键删除EatOrg
     * 
     * @param id
     */
    public CommonResult<EatOrg> deleteEatOrg(Integer id);

	/**
     * 根据主键获取EatOrg
     * 
     * @param id
     * @return
     */	
    public CommonResult<EatOrg> getEatOrgById(Integer id);

     

    /**
     * 取得所有EatOrg
     * 
     * @return
     */
    public CommonResult<List<EatOrg>> getAll();
    
	/**
     * 根据example取得EatOrg列表
     * 
     * @param  eatOrg
     * @return
     */
    public CommonResult<List<EatOrg>> getListByExample(EatOrg eatOrg);


    /**
     * 获取所有有效的机构列表
     *
     * @return
     */
    public List<EatOrg> getOrgList();

    /**
     * 根据example取得唯一的EatOrg
     * 
     * @param eatOrg
     * @return
     */
    public CommonResult<EatOrg> getUnique(EatOrg eatOrg);
    
    


    

	/**
     * 分页取得EatOrg列表
     * 
     * @param pageQuery
     * @return
     */
    public CommonResult<List<EatOrg>> getEatOrgByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);
	
	
}
