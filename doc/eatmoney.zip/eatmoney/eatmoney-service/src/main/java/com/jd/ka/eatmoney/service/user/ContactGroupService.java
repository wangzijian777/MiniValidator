package com.jd.ka.eatmoney.service.user;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.user.ContactGroup;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * jshow 联系人分组service 接口
 *
 */
public interface ContactGroupService {
   
    /**
     * 添加并返回设置id的ContactGroup对象
     * 
     * @param contactGroup
     * @return
     */
    public CommonResult<ContactGroup> addContactGroup(ContactGroup contactGroup);
    
	/**
     * 更新ContactGroup
     * 
     * @param contactGroup
     */
    public CommonResult<ContactGroup> updateContactGroup(ContactGroup contactGroup);
    

    

	 /**
     * 根据主键删除ContactGroup
     * 
     * @param id
     */
    public CommonResult<ContactGroup> deleteContactGroup(Integer id);

	/**
     * 根据主键获取ContactGroup
     * 
     * @param id
     * @return
     */	
    public CommonResult<ContactGroup> getContactGroupById(Integer id);

     

    /**
     * 取得所有ContactGroup
     * 
     * @return
     */
    public CommonResult<List<ContactGroup>> getAll();
    
	/**
     * 根据example取得ContactGroup列表
     * 
     * @param  contactGroup
     * @return
     */
    public CommonResult<List<ContactGroup>> getListByExample(ContactGroup contactGroup);
    
	/**
     * 根据example取得唯一的ContactGroup
     * 
     * @param contactGroup
     * @return
     */
    public CommonResult<ContactGroup> getUnique(ContactGroup contactGroup);
    
    


    

	/**
     * 分页取得ContactGroup列表
     * 
     * @param pageQuery
     * @return
     */
    public CommonResult<List<ContactGroup>> getContactGroupByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);


    public CommonResult<List<ContactGroup>> getListByExampleAndPublic(ContactGroup contactGroupQuery);
}
