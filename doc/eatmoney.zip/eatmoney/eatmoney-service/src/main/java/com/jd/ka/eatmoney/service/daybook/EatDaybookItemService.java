package com.jd.ka.eatmoney.service.daybook;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * jshow EatDaybookItemservice 接口
 *
 */
public interface EatDaybookItemService {
   
    /**
     * 添加并返回设置id的EatDaybookItem对象
     * 
     * @param eatDaybookItem
     * @return
     */
    public CommonResult<EatDaybookItem> addEatDaybookItem(EatDaybookItem eatDaybookItem);
    
	/**
     * 更新EatDaybookItem
     * 
     * @param eatDaybookItem
     */
    public CommonResult<EatDaybookItem> updateEatDaybookItem(EatDaybookItem eatDaybookItem);
    

    

	 /**
     * 根据主键删除EatDaybookItem
     * 
     * @param id
     */
    public CommonResult<EatDaybookItem> deleteEatDaybookItem(Integer id);

	/**
     * 根据主键获取EatDaybookItem
     * 
     * @param id
     * @return
     */	
    public CommonResult<EatDaybookItem> getEatDaybookItemById(Integer id);

     

    /**
     * 取得所有EatDaybookItem
     * 
     * @return
     */
    public CommonResult<List<EatDaybookItem>> getAll();
    
	/**
     * 根据example取得EatDaybookItem列表
     * 
     * @param  eatDaybookItem
     * @return
     */
    public CommonResult<List<EatDaybookItem>> getListByExample(EatDaybookItem eatDaybookItem);
    
	/**
     * 根据example取得唯一的EatDaybookItem
     * 
     * @param eatDaybookItem
     * @return
     */
    public CommonResult<EatDaybookItem> getUnique(EatDaybookItem eatDaybookItem);
    
    


    

	/**
     * 分页取得EatDaybookItem列表
     * 
     * @param pageQuery
     * @return
     */
    public CommonResult<List<EatDaybookItem>> getEatDaybookItemByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);
	
	
}
