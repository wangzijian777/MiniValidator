package com.jd.ka.eatmoney.service.settlement;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.domain.settlement.DaybookExport;
import com.jd.ka.eatmoney.domain.settlement.EatSettlement;
import com.jd.ka.eatmoney.domain.settlement.UserPayExport;
import com.jd.ka.eatmoney.domain.user.EatUser;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * jshow 吃饭结算信息service 接口
 *
 */
public interface EatSettlementService {
   
    /**
     * 添加并返回设置id的EatSettlement对象
     * 
     * @param eatSettlement
     * @return
     */
    public CommonResult<EatSettlement> addEatSettlement(EatSettlement eatSettlement);
    
	/**
     * 更新EatSettlement
     * 
     * @param eatSettlement
     */
    public CommonResult<EatSettlement> updateEatSettlement(EatSettlement eatSettlement);
    

    

	 /**
     * 根据主键删除EatSettlement
     * 
     * @param id
     */
    public CommonResult<EatSettlement> deleteEatSettlement(Integer id);

	/**
     * 根据主键获取EatSettlement
     * 
     * @param id
     * @return
     */	
    public CommonResult<EatSettlement> getEatSettlementById(Integer id);

     

    /**
     * 取得所有EatSettlement
     * 
     * @return
     */
    public CommonResult<List<EatSettlement>> getAll();
    
	/**
     * 根据example取得EatSettlement列表
     * 
     * @param  eatSettlement
     * @return
     */
    public CommonResult<List<EatSettlement>> getListByExample(EatSettlement eatSettlement);
    
	/**
     * 根据example取得唯一的EatSettlement
     * 
     * @param eatSettlement
     * @return
     */
    public CommonResult<EatSettlement> getUnique(EatSettlement eatSettlement);
    
    


    

	/**
     * 分页取得EatSettlement列表
     * 
     * @param pageQuery
     * @return
     */
    public CommonResult<List<EatSettlement>> getEatSettlementByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);


    /**
     * 执行结算处理
     * @param eatDaybookList
     * @param eatUser
     * @return
     */
    public CommonResult<String> doSettlement(List<EatDaybook> eatDaybookList, EatUser eatUser);


    /**
     * 导出数据
     * @param id
     * @return
     */
    public CommonResult<List<DaybookExport>> export(Integer id);

    /**
     * 导出结算明细
     * @param id
     * @return
     */
    public CommonResult<List<UserPayExport>> exportPaymentSettlement(Integer id);
}
