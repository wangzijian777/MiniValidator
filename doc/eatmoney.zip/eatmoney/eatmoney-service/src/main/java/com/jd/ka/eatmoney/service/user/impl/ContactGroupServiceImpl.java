package com.jd.ka.eatmoney.service.user.impl;



import javax.annotation.Resource;
import java.util.List;
import java.util.Date;
import org.springframework.stereotype.Service;
import org.apache.log4j.Logger;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.user.ContactGroup;
import com.jd.ka.eatmoney.manager.user.ContactGroupManager;
import com.jd.ka.eatmoney.service.user.ContactGroupService;


/**
 * @author zhangshibin
 * @since 2015-1-19
 *<p>  联系人分组service实现</p>
 *
 */
@Service("contactGroupService")
public class ContactGroupServiceImpl implements ContactGroupService {

	private static final Logger logger = Logger.getLogger(ContactGroupServiceImpl.class);
	
	@Resource(name="contactGroupManager")
	private ContactGroupManager contactGroupManager;
    
    public CommonResult<ContactGroup> addContactGroup(ContactGroup contactGroup) {
		CommonResult<ContactGroup> result = new CommonResult<ContactGroup>();
		try {
			
				contactGroup.setGmtCreate(new Date());
			 
			result.addDefaultModel(contactGroupManager.addContactGroup(contactGroup));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("添加 联系人分组失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<ContactGroup> updateContactGroup(ContactGroup contactGroup) {
		CommonResult<ContactGroup> result = new CommonResult<ContactGroup>();
		try {
			
				contactGroup.setGmtModify(new Date());
			 
			contactGroupManager.updateContactGroup(contactGroup);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("更新 联系人分组失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
   

	public CommonResult<ContactGroup> deleteContactGroup(Integer id) {
		CommonResult<ContactGroup> result = new CommonResult<ContactGroup>();
		try {
			contactGroupManager.deleteContactGroup(id);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("删除 联系人分组失败", e);
			result.setSuccess(false);
		}
		return result;
    }


    	public CommonResult<ContactGroup> getContactGroupById(Integer id) {
		CommonResult<ContactGroup> result = new CommonResult<ContactGroup>();
		try {
			result.addDefaultModel("contactGroup", contactGroupManager.getContactGroupById(id));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据主键获取 联系人分组失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	

        
	
	public CommonResult<List<ContactGroup>> getAll() {
		CommonResult<List<ContactGroup>> result = new CommonResult<List<ContactGroup>>();
		try {
			List<ContactGroup> list = contactGroupManager.getAll();
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得所有 联系人分组失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<List<ContactGroup>> getListByExample(ContactGroup contactGroup) {
		CommonResult<List<ContactGroup>> result = new CommonResult<List<ContactGroup>>();
		try {
			List<ContactGroup> list = contactGroupManager.getListByExample(contactGroup);
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得 联系人分组失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	public CommonResult<ContactGroup> getUnique(ContactGroup contactGroup) {
		CommonResult<ContactGroup> result = new CommonResult<ContactGroup>();
		try {
			result.addDefaultModel(contactGroupManager.getUnique(contactGroup));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据example获取唯一 联系人分组失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	



	
	public CommonResult<List<ContactGroup>> getContactGroupByPage(PageQuery pageQuery) {
		CommonResult<List<ContactGroup>> result = new CommonResult<List<ContactGroup>>();
		try {
			int totalCount = this.count(pageQuery);
			if (totalCount > 0) {
				pageQuery.setTotalCount(totalCount);
				List<ContactGroup> list = contactGroupManager.getContactGroupByPage(pageQuery);
				result.addDefaultModel("list", list);
				result.addModel("pageQuery", pageQuery);
			}
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("分页获取 联系人分组失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public int count(PageQuery pageQuery) {
		return contactGroupManager.count(pageQuery);
	}



    public CommonResult<List<ContactGroup>> getListByExampleAndPublic(ContactGroup contactGroupQuery) {
        CommonResult<List<ContactGroup>> result = new CommonResult<List<ContactGroup>>();
        try {
            List<ContactGroup> list = contactGroupManager.getListByExampleAndPublic(contactGroupQuery);
            result.addDefaultModel("list", list);
            result.setSuccess(true);
        } catch (Exception e) {
            logger.error("取得 联系人分组失败", e);
            result.setSuccess(false);
        }
        return result;
    }

	/******* getter and setter ***/
	public ContactGroupManager getContactGroupManager() {
		return contactGroupManager;
	}

	public void setContactGroupManager(ContactGroupManager contactGroupManager) {
		this.contactGroupManager = contactGroupManager;
	}

}
