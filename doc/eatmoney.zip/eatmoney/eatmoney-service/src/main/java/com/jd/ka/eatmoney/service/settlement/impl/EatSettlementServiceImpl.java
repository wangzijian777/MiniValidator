package com.jd.ka.eatmoney.service.settlement.impl;



import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;
import com.jd.ka.eatmoney.domain.settlement.DaybookDetailExport;
import com.jd.ka.eatmoney.domain.settlement.DaybookExport;
import com.jd.ka.eatmoney.domain.settlement.UserPayExport;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.enumtype.DaybookStatus;
import com.jd.ka.eatmoney.enumtype.PaymentType;
import com.jd.ka.eatmoney.enumtype.SettlementStatus;
import com.jd.ka.eatmoney.manager.daybook.EatDaybookManager;
import com.jd.ka.eatmoney.manager.daybook.EatDaybookItemManager;
import com.jd.ka.eatmoney.manager.user.EatUserManager;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.apache.log4j.Logger;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.settlement.EatSettlement;
import com.jd.ka.eatmoney.manager.settlement.EatSettlementManager;
import com.jd.ka.eatmoney.service.settlement.EatSettlementService;


/**
 * @author zhangshibin
 * @since 2015-1-19
 *<p>  吃饭结算信息service实现</p>
 *
 */
@Service("eatSettlementService")
public class EatSettlementServiceImpl implements EatSettlementService {

	private static final Logger logger = Logger.getLogger(EatSettlementServiceImpl.class);
	
	@Resource(name="eatSettlementManager")
	private EatSettlementManager eatSettlementManager;
    @Resource(name="eatDaybookManager")
    private EatDaybookManager eatDaybookManager;

    @Resource(name="eatDaybookItemManager")
    private EatDaybookItemManager eatDaybookItemManager;
    @Resource(name="eatUserManager")
    private EatUserManager eatUserManager;




    public CommonResult<EatSettlement> addEatSettlement(EatSettlement eatSettlement) {
		CommonResult<EatSettlement> result = new CommonResult<EatSettlement>();
		try {
			
				eatSettlement.setGmtCreate(new Date());
			 
			result.addDefaultModel(eatSettlementManager.addEatSettlement(eatSettlement));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("添加 吃饭结算信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<EatSettlement> updateEatSettlement(EatSettlement eatSettlement) {
		CommonResult<EatSettlement> result = new CommonResult<EatSettlement>();
		try {
			
				eatSettlement.setGmtModify(new Date());
			 
			eatSettlementManager.updateEatSettlement(eatSettlement);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("更新 吃饭结算信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
   

	public CommonResult<EatSettlement> deleteEatSettlement(Integer id) {
		CommonResult<EatSettlement> result = new CommonResult<EatSettlement>();
		try {
			eatSettlementManager.deleteEatSettlement(id);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("删除 吃饭结算信息失败", e);
			result.setSuccess(false);
		}
		return result;
    }


    	public CommonResult<EatSettlement> getEatSettlementById(Integer id) {
		CommonResult<EatSettlement> result = new CommonResult<EatSettlement>();
		try {
			result.addDefaultModel("eatSettlement", eatSettlementManager.getEatSettlementById(id));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据主键获取 吃饭结算信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	

        
	
	public CommonResult<List<EatSettlement>> getAll() {
		CommonResult<List<EatSettlement>> result = new CommonResult<List<EatSettlement>>();
		try {
			List<EatSettlement> list = eatSettlementManager.getAll();
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得所有 吃饭结算信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<List<EatSettlement>> getListByExample(EatSettlement eatSettlement) {
		CommonResult<List<EatSettlement>> result = new CommonResult<List<EatSettlement>>();
		try {
			List<EatSettlement> list = eatSettlementManager.getListByExample(eatSettlement);
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得 吃饭结算信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	public CommonResult<EatSettlement> getUnique(EatSettlement eatSettlement) {
		CommonResult<EatSettlement> result = new CommonResult<EatSettlement>();
		try {
			result.addDefaultModel(eatSettlementManager.getUnique(eatSettlement));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据example获取唯一 吃饭结算信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	



	
	public CommonResult<List<EatSettlement>> getEatSettlementByPage(PageQuery pageQuery) {
		CommonResult<List<EatSettlement>> result = new CommonResult<List<EatSettlement>>();
		try {
			int totalCount = this.count(pageQuery);
			if (totalCount > 0) {
				pageQuery.setTotalCount(totalCount);
				List<EatSettlement> list = eatSettlementManager.getEatSettlementByPage(pageQuery);
				result.addDefaultModel("list", list);
				result.addModel("pageQuery", pageQuery);
			}
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("分页获取 吃饭结算信息失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public int count(PageQuery pageQuery) {
		return eatSettlementManager.count(pageQuery);
	}


    /**
     * 执行结算处理
     *
     * @param eatDaybookList
     * @param eatUser
     * @return
     */
    public CommonResult<String> doSettlement(List<EatDaybook> eatDaybookList, EatUser eatUser) {
        CommonResult<String> result = new CommonResult<String>();
        try {
            BigDecimal totalMoney = this.getTotalMoney(eatDaybookList);
            EatSettlement eatSettlement = new EatSettlement();
            eatSettlement.setSubmitErpAcct(eatUser.getErpAccount());
            eatSettlement.setGmtCreate(new Date());
            eatSettlement.setSubmitUserId(eatUser.getId());
            eatSettlement.setStatus(SettlementStatus.SETTLED.getType()); //已结算
            eatSettlement.setTotalMoney(totalMoney);
      //      eatSettlement.setDaybookIds(this.getDaybookIds(eatDaybookList));
            eatSettlement.setPublicMoney(this.getPublicMoney(eatDaybookList));
            eatSettlementManager.addEatSettlement(eatSettlement);

            //从新将总额进行赋值，防止和详情里面的总额不一致
            totalMoney=eatDaybookManager.doSettlement(eatSettlement, eatDaybookList);
            eatSettlement.setTotalMoney(totalMoney);
            eatSettlementManager.updateEatSettlement(eatSettlement);

            result.setMessage("结算成功");
            result.setSuccess(true);
        }catch (Exception e){
            logger.error("执行结算失败", e);
            result.setSuccess(false);
            result.setMessage("执行结算失败，原因是："+e.getMessage());
        }
        return result;
    }

    /**
     * 计算充公总金额
     * @param eatDaybookList
     * @return
     */
    private BigDecimal getPublicMoney(List<EatDaybook> eatDaybookList) {
        BigDecimal publicMoney=new BigDecimal(0);
        for (EatDaybook eatDaybook:eatDaybookList){
            //如果为空，表示两个值相等，为老数据
            if(eatDaybook.getPayMoney()!=null && eatDaybook.getPayMoney().compareTo(BigDecimal.ZERO)>0){
                //公共金额=标准总额-实付金额
                publicMoney=publicMoney.add(eatDaybook.getTotalMoney().subtract(eatDaybook.getPayMoney()));
            }
        }
        return publicMoney;
    }


    private BigDecimal getTotalMoney(List<EatDaybook> eatDaybookList) {
        BigDecimal totalMoney=new BigDecimal(0);
        for (EatDaybook eatDaybook:eatDaybookList){
            totalMoney=totalMoney.add(eatDaybook.getTotalMoney());
        }
        return totalMoney;
    }


    private String getDaybookIds(List<EatDaybook> eatDaybookList) {
        List<Integer> ids=new ArrayList<Integer>(eatDaybookList.size());
        for (int i=0;i<eatDaybookList.size();i++){
            ids.add(eatDaybookList.get(i).getId());
        }
        return StringUtils.join(ids, ",");
    }


    /**
     * 导出数据
     *
     * @param id
     * @return
     */
    public CommonResult<List<DaybookExport>> export(Integer id) {
        CommonResult<List<DaybookExport>> result = new CommonResult<List<DaybookExport>>();
        EatSettlement eatSettlement=eatSettlementManager.getEatSettlementById(id);
        if(eatSettlement==null){
            result.setSuccess(false);
            result.setMessage("数据为空！");
            return result;
        }
        result.addModel("eatSettlement",eatSettlement);
        EatDaybookItem eatDaybookItemQuery=new EatDaybookItem();
        eatDaybookItemQuery.setStatus(DaybookStatus.SETTLED.getType());
        eatDaybookItemQuery.setSettlementId(id);
        List<EatDaybookItem> itemList=eatDaybookItemManager.getListByExample(eatDaybookItemQuery);
        makeDaybookExportList(eatSettlement,itemList,result);
        return result;
    }

    /**
     * 生成导出数据列表
     * @param eatSettlement
     * @param itemList
     * @param result
     */
    private void makeDaybookExportList(EatSettlement eatSettlement, List<EatDaybookItem> itemList, CommonResult<List<DaybookExport>> result) {
        Map<String,DaybookExport> daybookExportMap=new HashMap<String, DaybookExport>();
        Map<String,String> userNameMap=new HashMap<String, String>();

        BigDecimal totalMoney=new BigDecimal(0);
        for(EatDaybookItem eatDaybookItem:itemList){
            String eatDateStr= DateFormatUtils.format(eatDaybookItem.getEatDate(),"yyyy-MM-dd");
            DaybookExport daybookExport=daybookExportMap.get(eatDateStr);
            if(daybookExport==null){
                daybookExport=new DaybookExport();
                daybookExport.setEatDate(eatDaybookItem.getEatDate());
                daybookExport.setEateDateStr(eatDateStr);
                daybookExportMap.put(eatDateStr,daybookExport);
            }
            eatDaybookItem.setUserName(getUserName(eatDaybookItem.getErpAccount(),userNameMap));
            eatDaybookItem.setPayUserName(getUserName(eatDaybookItem.getPayErpAccount(), userNameMap));

            totalMoney=totalMoney.add(eatDaybookItem.getPayMoney());
            daybookExport.addDaybookItem(eatDaybookItem);
        }
        List<DaybookExport> list= new ArrayList<DaybookExport>(daybookExportMap.values());
        Collections.sort(list); //降序排列
        result.addDefaultModel("list",list);
        result.addModel("totalMoney",totalMoney);
        result.addModel("totalCnt",itemList.size());
        result.setSuccess(true);
    }

    public String getUserName(String erpAccount,Map<String,String> userMap){
        String userName=userMap.get(erpAccount);
        if(userName!=null){
            return userName;
        }
        EatUser eatUser=eatUserManager.getUserByErpAcct(erpAccount);
        if(eatUser==null){
            userName=erpAccount;
        }else {
            userName=eatUser.getUserName();
        }
        userMap.put(erpAccount,userName);
        return userName;
    }


    /**
     * 导出结算明细
     *
     * @param id
     * @return
     */
    public CommonResult<List<UserPayExport>> exportPaymentSettlement(Integer id) {
        CommonResult<List<UserPayExport>> result = new CommonResult<List<UserPayExport>>();
        EatSettlement eatSettlement=eatSettlementManager.getEatSettlementById(id);
        if(eatSettlement==null){
            result.setSuccess(false);
            result.setMessage("数据为空！");
            return result;
        }
        result.addModel("eatSettlement",eatSettlement);
        EatDaybookItem eatDaybookItemQuery=new EatDaybookItem();
        eatDaybookItemQuery.setStatus(DaybookStatus.SETTLED.getType());
        eatDaybookItemQuery.setSettlementId(id);
        List<EatDaybookItem> itemList=eatDaybookItemManager.getListByExample(eatDaybookItemQuery);
        makeUserPayExportList(eatSettlement, itemList, result);
        return result;
    }


    /**
     * 生成导出数据列表（详细明细，内部用）
     * @param eatSettlement
     * @param itemList
     * @param result
     */
    private void makeUserPayExportList(EatSettlement eatSettlement, List<EatDaybookItem> itemList, CommonResult<List<UserPayExport>> result) {
        Map<String,UserPayExport> userPayExportMap=new LinkedHashMap<String, UserPayExport>(); //每个人的应收明细
        Map<Integer,DaybookDetailExport> daybookDetailExportMap=new LinkedHashMap<Integer, DaybookDetailExport>();


        Map<String,String> userNameMap=new HashMap<String, String>();

        BigDecimal totalMoney=new BigDecimal(0);
        for(EatDaybookItem eatDaybookItem:itemList){
            eatDaybookItem.setUserName(getUserName(eatDaybookItem.getErpAccount(), userNameMap));
            eatDaybookItem.setPayUserName(getUserName(eatDaybookItem.getPayErpAccount(), userNameMap));

            //step1 获取每次报账人录入数据
            DaybookDetailExport daybookDetailExport=daybookDetailExportMap.get(eatDaybookItem.getDaybookId());
            if(daybookDetailExport==null){
                daybookDetailExport = this.getDaybookDetailExport(daybookDetailExportMap, userNameMap, eatDaybookItem);
            }
            daybookDetailExport.addDaybookItem(eatDaybookItem);



            //step2 计算每个付款人的应收总额
            UserPayExport userPayExport=userPayExportMap.get(eatDaybookItem.getPayErpAccount());
            if(userPayExport==null){
                userPayExport=new UserPayExport();
                userPayExport.setErpAccount(eatDaybookItem.getPayErpAccount());
                userPayExport.setUserName(eatDaybookItem.getPayUserName());
                userPayExportMap.put(eatDaybookItem.getPayErpAccount(),userPayExport);
            }
            //单人的总金额累加
            userPayExport.addPayMoney(eatDaybookItem.getPayMoney());

            //全部的总额
            totalMoney=totalMoney.add(eatDaybookItem.getPayMoney());
        }
        List<UserPayExport> list= new ArrayList<UserPayExport>(userPayExportMap.values());
        List<DaybookDetailExport> daybookList= new ArrayList<DaybookDetailExport>(daybookDetailExportMap.values());

        //需要将充公的金额从每个人的金额中减去，之前算每个人的应收总额是从item里面取的，没有减去充公额度
        BigDecimal totalPublicMoney=BigDecimal.ZERO;
        for(DaybookDetailExport subPublicDayBook:daybookList){
            if(subPublicDayBook.hasPublicMoney()){
                UserPayExport userPayExport=   userPayExportMap.get(subPublicDayBook.getPayErpAccount());
                BigDecimal publicMoney=subPublicDayBook.getPublicMoney();
                userPayExport.subPublicMoney(publicMoney);
                totalPublicMoney= totalPublicMoney.add(publicMoney);
            }
        }


        Collections.sort(daybookList);
        result.addDefaultModel("list",list);
        result.addModel("daybookList",daybookList);
        result.addModel("totalMoney",totalMoney);
        result.addModel("totalPublicMoney",totalPublicMoney);
        result.addModel("totalCnt",list.size());
        result.setSuccess(true);
    }


    /**
     * 获取导出明细数据
     * @param daybookDetailExportMap
     * @param userNameMap
     * @param eatDaybookItem
     * @return
     */
    private DaybookDetailExport getDaybookDetailExport(Map<Integer, DaybookDetailExport> daybookDetailExportMap, Map<String, String> userNameMap, EatDaybookItem eatDaybookItem) {
        DaybookDetailExport daybookDetailExport;EatDaybook eatDaybook=eatDaybookManager.getEatDaybookById(eatDaybookItem.getDaybookId());
        daybookDetailExport=new DaybookDetailExport();
        daybookDetailExport.setPayType(eatDaybook.getPayType());
        daybookDetailExport.setPayErpAccount(eatDaybook.getPayErpAccount());
        if(eatDaybook.getPayType()!= PaymentType.SELF_PAY.getType()){
            daybookDetailExport.setPayUserName(eatDaybookItem.getPayUserName());
        }else{
            daybookDetailExport.setPayUserName("每人各自付款");
        }
        daybookDetailExport.setInputErpAccount(eatDaybook.getInputErpAccount());
        daybookDetailExport.setInputUserName(getUserName(eatDaybook.getInputErpAccount(), userNameMap));
        daybookDetailExport.setId(eatDaybook.getId());
        String eatDateStr= DateFormatUtils.format(eatDaybook.getEatDate(),"yyyy-MM-dd");
        daybookDetailExport.setEatDate(eatDaybook.getEatDate());
        daybookDetailExport.setEatDateStr(eatDateStr);
        if(eatDaybook.getPayMoney()!=null && eatDaybook.getPayMoney().compareTo(BigDecimal.ZERO)>0){
            daybookDetailExport.setRealPayMoney(eatDaybook.getPayMoney());
        }else{
            daybookDetailExport.setRealPayMoney(eatDaybook.getTotalMoney());
        }
        daybookDetailExportMap.put(eatDaybook.getId(),daybookDetailExport);
        return daybookDetailExport;
    }

    /******* getter and setter ***/
	public EatSettlementManager getEatSettlementManager() {
		return eatSettlementManager;
	}

	public void setEatSettlementManager(EatSettlementManager eatSettlementManager) {
		this.eatSettlementManager = eatSettlementManager;
	}

}
