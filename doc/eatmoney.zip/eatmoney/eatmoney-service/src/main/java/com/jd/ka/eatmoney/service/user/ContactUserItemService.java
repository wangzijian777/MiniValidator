package com.jd.ka.eatmoney.service.user;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.user.ContactUserItem;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * jshow 联系人信息service 接口
 *
 */
public interface ContactUserItemService {
   
    /**
     * 添加并返回设置id的ContactUserItem对象
     * 
     * @param contactUserItem
     * @return
     */
    public CommonResult<ContactUserItem> addContactUserItem(ContactUserItem contactUserItem);
    
	/**
     * 更新ContactUserItem
     * 
     * @param contactUserItem
     */
    public CommonResult<ContactUserItem> updateContactUserItem(ContactUserItem contactUserItem);
    

    

	 /**
     * 根据主键删除ContactUserItem
     * 
     * @param id
     */
    public CommonResult<ContactUserItem> deleteContactUserItem(Integer id);

	/**
     * 根据主键获取ContactUserItem
     * 
     * @param id
     * @return
     */	
    public CommonResult<ContactUserItem> getContactUserItemById(Integer id);

     

    /**
     * 取得所有ContactUserItem
     * 
     * @return
     */
    public CommonResult<List<ContactUserItem>> getAll();
    
	/**
     * 根据example取得ContactUserItem列表
     * 
     * @param  contactUserItem
     * @return
     */
    public CommonResult<List<ContactUserItem>> getListByExample(ContactUserItem contactUserItem);
    
	/**
     * 根据example取得唯一的ContactUserItem
     * 
     * @param contactUserItem
     * @return
     */
    public CommonResult<ContactUserItem> getUnique(ContactUserItem contactUserItem);
    
    


    

	/**
     * 分页取得ContactUserItem列表
     * 
     * @param pageQuery
     * @return
     */
    public CommonResult<List<ContactUserItem>> getContactUserItemByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);


    /**
     * 小组添加用户
     * @param groupId
     * @param userList
     * @param pin
     * @return
     */
   public CommonResult<String> doConfigUser(Integer groupId, String userList, String pin);
}
