package com.jd.ka.eatmoney.service.daybook.impl;



import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.jd.common.util.DateFormatUtils;
import com.jd.ka.eatmoney.domain.daybook.EatDayBookItemPage;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.enumtype.DaybookStatus;
import com.jd.ka.eatmoney.enumtype.PaymentType;
import com.jd.ka.eatmoney.manager.daybook.EatDaybookItemManager;
import com.jd.ka.eatmoney.service.settlement.EatSettlementService;
import com.jd.ka.eatmoney.service.user.EatUserService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.apache.log4j.Logger;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.daybook.EatDaybook;
import com.jd.ka.eatmoney.manager.daybook.EatDaybookManager;
import com.jd.ka.eatmoney.service.daybook.EatDaybookService;


/**
 * @author zhangshibin
 * @since 2015-1-19
 *<p>  吃饭记账记录service实现</p>
 *
 */
@Service("eatDaybookService")
public class EatDaybookServiceImpl implements EatDaybookService {

	private static final Logger logger = Logger.getLogger(EatDaybookServiceImpl.class);
	
	@Resource(name="eatDaybookManager")
	private EatDaybookManager eatDaybookManager;

    @Resource(name="eatUserService")
    private EatUserService eatUserService;

    @Resource(name="eatDaybookItemManager")
    private EatDaybookItemManager eatDaybookItemManager;

    @Resource(name="eatSettlementService")
    private EatSettlementService eatSettlementService;


    public CommonResult<EatDaybook> addEatDaybook(EatDaybook eatDaybook) {
		CommonResult<EatDaybook> result = new CommonResult<EatDaybook>();
		try {
            EatUser eatUser=eatUserService.getUserByErpAcct(eatDaybook.getInputErpAccount());
            eatDaybook.setInputUserId(eatUser.getId());
			eatDaybook.setGmtCreate(new Date());
            eatDaybook.setStatus(DaybookStatus.UN_SETTLED.getType());

            if(eatDaybook.getTotalMoney()==null || eatDaybook.getPayMoney()==null){
                result.setMessage("金额有误！");
                result.setSuccess(false);
                return result;
            }
            if(eatDaybook.getPayMoney().compareTo(eatDaybook.getTotalMoney())>0){
                result.setMessage("付款金额不能大于 标准额度："+eatDaybook.getTotalMoney());
                result.setSuccess(false);
                return result;
            }

          if(eatDaybook.getPayMoney().compareTo(BigDecimal.ZERO)<=0){
              result.setMessage("付款金额不能大于小于等于0");
              result.setSuccess(false);
              return result;
          }


            List<EatDayBookItemPage> list=JSON.parseArray(eatDaybook.getBookJson(),EatDayBookItemPage.class);
            if(CollectionUtils.isEmpty(list)){
                result.setMessage("加班人员为空，请选择！");
                result.setSuccess(false);
                return result;
            }


            //如果为各自付款(且人数大于1)，付款金额必须和总额相等
            if(eatDaybook.getPayType()== PaymentType.SELF_PAY.getType() && list.size()>1){
                if(eatDaybook.getTotalMoney().compareTo(eatDaybook.getPayMoney())!=0){
                    result.setMessage("各自付款情况下，实际付款必须和标准金额相等，否则无法分摊！");
                    result.setSuccess(false);
                    return result;
                }
            }



                //总金额为15的倍数
            eatDaybook.setTotalMoney(new BigDecimal(15*list.size()));
            if(!this.checkEatDayBookItem(eatDaybook,list,result)){
                return result;
            }


            eatDaybookManager.addEatDaybook(eatDaybook,list);


            result.setMessage("新增成功！");
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("添加 吃饭记账记录失败", e);
			result.setSuccess(false);
		}
		return result;
	}


    /**
     * 检查吃饭记录是否存在异常
     * @param eatDaybook
     * @param list
     * @param result
     */
    private boolean checkEatDayBookItem(EatDaybook eatDaybook, List<EatDayBookItemPage> list, CommonResult<EatDaybook> result) {
        EatDaybookItem eatDaybookItemQuery=new EatDaybookItem();
        eatDaybookItemQuery.setEatDate(eatDaybook.getEatDate());
        List<EatDaybookItem> inList=new ArrayList<EatDaybookItem>();
        for(EatDayBookItemPage bookItemPage:list){
            eatDaybookItemQuery.setErpAccount(bookItemPage.getErpAccount());
            List<EatDaybookItem> itemDBs=eatDaybookItemManager.getListByExample(eatDaybookItemQuery);
            if(CollectionUtils.isEmpty(itemDBs)){
                continue;
            }
            for(EatDaybookItem itemDB:itemDBs){
                DaybookStatus daybookStatus=DaybookStatus.getType(itemDB.getStatus());
                if(daybookStatus!=DaybookStatus.DELETED ){
                    inList.add(itemDB);
                    break;
                }
            }
        }

        if(inList.isEmpty()){
            return true;
        }

        StringBuilder sb=new StringBuilder();
        for(EatDaybookItem item:inList){
            sb.append("账号："+item.getErpAccount()+"在"+ DateFormatUtils.format(eatDaybook.getEatDate(), "yyyy-MM-dd")
                    +"加班，已经被"+item.getPayErpAccount()+" 付款, 由"+item.getInputErpAccount()+"录入，请找相关人员核实！<br/>");
        }
        result.setMessage(sb.toString());
        result.setSuccess(false);
        return false;
    }




    public CommonResult<EatDaybook> updateEatDaybook(EatDaybook eatDaybook) {
		CommonResult<EatDaybook> result = new CommonResult<EatDaybook>();
		try {
			
				eatDaybook.setGmtModify(new Date());
			 
			eatDaybookManager.updateEatDaybook(eatDaybook);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("更新 吃饭记账记录失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
   

	public CommonResult<EatDaybook> deleteEatDaybook(Integer id) {
		CommonResult<EatDaybook> result = new CommonResult<EatDaybook>();
		try {
			eatDaybookManager.deleteEatDaybook(id);
            eatDaybookItemManager.deleteByDaybookId(id);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("删除 吃饭记账记录失败", e);
			result.setSuccess(false);
		}
		return result;
    }


    	public CommonResult<EatDaybook> getEatDaybookById(Integer id) {
		CommonResult<EatDaybook> result = new CommonResult<EatDaybook>();
		try {
			result.addDefaultModel("eatDaybook", eatDaybookManager.getEatDaybookById(id));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据主键获取 吃饭记账记录失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	

        
	
	public CommonResult<List<EatDaybook>> getAll() {
		CommonResult<List<EatDaybook>> result = new CommonResult<List<EatDaybook>>();
		try {
			List<EatDaybook> list = eatDaybookManager.getAll();
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得所有 吃饭记账记录失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<List<EatDaybook>> getListByExample(EatDaybook eatDaybook) {
		CommonResult<List<EatDaybook>> result = new CommonResult<List<EatDaybook>>();
		try {
			List<EatDaybook> list = eatDaybookManager.getListByExample(eatDaybook);
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得 吃饭记账记录失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	public CommonResult<EatDaybook> getUnique(EatDaybook eatDaybook) {
		CommonResult<EatDaybook> result = new CommonResult<EatDaybook>();
		try {
			result.addDefaultModel(eatDaybookManager.getUnique(eatDaybook));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据example获取唯一 吃饭记账记录失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	



	
	public CommonResult<List<EatDaybook>> getEatDaybookByPage(PageQuery pageQuery) {
		CommonResult<List<EatDaybook>> result = new CommonResult<List<EatDaybook>>();
		try {
			int totalCount = this.count(pageQuery);
			if (totalCount > 0) {
				pageQuery.setTotalCount(totalCount);
				List<EatDaybook> list = eatDaybookManager.getEatDaybookByPage(pageQuery);
				result.addDefaultModel("list", list);
				result.addModel("pageQuery", pageQuery);
			}
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("分页获取 吃饭记账记录失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public int count(PageQuery pageQuery) {
		return eatDaybookManager.count(pageQuery);
	}


    /**
     * 结算确认页
     *
     * @param pageQuery
     * @param eatUser
     * @return
     */
    public CommonResult<String> settlement(PageQuery pageQuery, EatUser eatUser) {
        CommonResult<String> result = new CommonResult<String>();
        //设置报账人为本人
        pageQuery.addQueryParam("submitErpAccount",eatUser.getErpAccount());
        pageQuery.addQueryParam("status",DaybookStatus.UN_SETTLED.getType());
        List<EatDaybook> eatDaybookList=eatDaybookManager.getEatDaybookByPage(pageQuery);
        if(CollectionUtils.isEmpty(eatDaybookList)){
            result.setMessage("没有数据需要结算！");
            result.setSuccess(false);
        }else{
            //倒序排列
            EatDaybook newEatDaybook=eatDaybookList.get(0);
            EatDaybook oldEatDaybook=eatDaybookList.get(eatDaybookList.size()-1);
            result.addModel("newEatDaybook",newEatDaybook);
            result.addModel("oldEatDaybook",oldEatDaybook);
            result.addModel("listSize",eatDaybookList.size());
            result.setSuccess(true);
        }
        return result;
    }



    /**
     * 执行结算
     *
     * @param pageQuery
     * @param eatUser
     * @return
     */
    public CommonResult<String> doSettlement(PageQuery pageQuery, EatUser eatUser) {
        //设置报账人为本人
        pageQuery.addQueryParam("submitErpAccount",eatUser.getErpAccount());
        pageQuery.addQueryParam("status",DaybookStatus.UN_SETTLED.getType());
        List<EatDaybook> eatDaybookList= eatDaybookManager.getEatDaybookByPage(pageQuery);
         CommonResult<String> result= eatSettlementService.doSettlement(eatDaybookList,eatUser);
        return result;
    }


    /******* getter and setter ***/
	public EatDaybookManager getEatDaybookManager() {
		return eatDaybookManager;
	}

	public void setEatDaybookManager(EatDaybookManager eatDaybookManager) {
		this.eatDaybookManager = eatDaybookManager;
	}

    public void setEatUserService(EatUserService eatUserService) {
        this.eatUserService = eatUserService;
    }
}
