package com.jd.ka.eatmoney.service.user.impl;



import javax.annotation.Resource;
import java.util.List;
import java.util.Date;

import com.jd.ka.eatmoney.constant.CacheConstant;
import com.jd.ka.eatmoney.dao.redis.JdRedisUtils;
import com.jd.ka.eatmoney.enumtype.UserStatus;
import com.jd.passport.utils.JdLoginUtils;
import org.springframework.stereotype.Service;
import org.apache.log4j.Logger;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.user.EatUser;
import com.jd.ka.eatmoney.manager.user.EatUserManager;
import com.jd.ka.eatmoney.service.user.EatUserService;


/**
 * @author zhangshibin
 * @since 2015-1-19
 *<p>  用户service实现</p>
 *
 */
@Service("eatUserService")
public class EatUserServiceImpl implements EatUserService {

	private static final Logger logger = Logger.getLogger(EatUserServiceImpl.class);
	
	@Resource(name="eatUserManager")
	private EatUserManager eatUserManager;
    @Resource(name="jdRedisUtils")
    private JdRedisUtils jdRedisUtils;


    public CommonResult<EatUser> addEatUser(EatUser eatUser) {
		CommonResult<EatUser> result = new CommonResult<EatUser>();
		try {
		    eatUser.setGmtCreate(new Date());
			result.addDefaultModel(eatUserManager.addEatUser(eatUser));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("添加 用户失败", e);
			result.setSuccess(false);
		}
		return result;
	}


    /**
     * 用户注册
     *
     * @param eatUser
     */
    public CommonResult<String> doAddUser(EatUser eatUser) {
        CommonResult<String> result = new CommonResult<String>();
        try {
            EatUser eatUserQuery=new EatUser();
            eatUserQuery.setErpAccount(eatUser.getErpAccount());
            EatUser eatUserOld=this.getUnique(eatUserQuery);
            if(eatUserOld!=null){
                if(eatUserOld.getUserStatus()==UserStatus.FORBIDDEN.getType()){
                    result.setMessage("你的账号已经被禁用，请联系管理员");
                    result.setSuccess(false);
                    return result;
                }

                if(eatUserOld.getUserStatus()==UserStatus.NORMAL.getType()){
                    result.setMessage("你的账号已经注册过了，无需注册！");
                    result.setSuccess(false);
                    return result;
                }

                //删掉从来
                if(eatUserOld.getUserStatus()==UserStatus.DELETED.getType()){
                    eatUserManager.deleteEatUser(eatUserOld.getId());
                }
            }
            eatUser.setUserStatus(UserStatus.NORMAL.getType());
            eatUser.setGmtCreate(new Date());
            eatUserManager.addEatUser(eatUser);
            result.setSuccess(true);
        } catch (Exception e) {
            logger.error("添加 用户失败", e);
            result.setSuccess(false);
        }
        return result;
    }


    public EatUser getUserByErpAcct(String pin) {
        EatUser eatUserQuery=new EatUser();
        eatUserQuery.setErpAccount(pin);
        EatUser eatUser=this.getUnique(eatUserQuery);
        return  eatUser;
    }


    public CommonResult<EatUser> updateEatUser(EatUser eatUser) {
		CommonResult<EatUser> result = new CommonResult<EatUser>();
		try {
			eatUserManager.updateEatUser(eatUser);
            eatUser=eatUserManager.getEatUserById(eatUser.getId());
            jdRedisUtils.deleteByKey(CacheConstant.getUserCacheKey(eatUser.getErpAccount()));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("更新 用户失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
   

	public CommonResult<EatUser> deleteEatUser(Integer id) {
		CommonResult<EatUser> result = new CommonResult<EatUser>();
		try {
			eatUserManager.deleteEatUser(id);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("删除 用户失败", e);
			result.setSuccess(false);
		}
		return result;
    }


    	public CommonResult<EatUser> getEatUserById(Integer id) {
		CommonResult<EatUser> result = new CommonResult<EatUser>();
		try {
			result.addDefaultModel("eatUser", eatUserManager.getEatUserById(id));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据主键获取 用户失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	

        
	
	public CommonResult<List<EatUser>> getAll() {
		CommonResult<List<EatUser>> result = new CommonResult<List<EatUser>>();
		try {
			List<EatUser> list = eatUserManager.getAll();
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得所有 用户失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<List<EatUser>> getListByExample(EatUser eatUser) {
		CommonResult<List<EatUser>> result = new CommonResult<List<EatUser>>();
		try {
			List<EatUser> list = eatUserManager.getListByExample(eatUser);
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得 用户失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	public EatUser getUnique(EatUser eatUser) {
			return eatUserManager.getUnique(eatUser);
	}

	



	
	public CommonResult<List<EatUser>> getEatUserByPage(PageQuery pageQuery) {
		CommonResult<List<EatUser>> result = new CommonResult<List<EatUser>>();
		try {
			int totalCount = this.count(pageQuery);
			if (totalCount > 0) {
				pageQuery.setTotalCount(totalCount);
				List<EatUser> list = eatUserManager.getEatUserByPage(pageQuery);
				result.addDefaultModel("list", list);
				result.addModel("pageQuery", pageQuery);
			}
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("分页获取 用户失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public int count(PageQuery pageQuery) {
		return eatUserManager.count(pageQuery);
	}


    /**
     * 根据groupId查询用户列表
     *
     * @param groupId
     * @return
     */
    public CommonResult<List<EatUser>> getEatUserListByGroupId(Integer groupId) {
        CommonResult<List<EatUser>> result = new CommonResult<List<EatUser>>();
        try {
            List<EatUser> list = eatUserManager.getEatUserListByGroupId(groupId);
            result.addDefaultModel("list", list);
            result.setSuccess(true);
        } catch (Exception e) {
            logger.error("根据组id查询用户失败", e);
            result.setSuccess(false);
        }
        return result;
    }

    /******* getter and setter ***/
	public EatUserManager getEatUserManager() {
		return eatUserManager;
	}

	public void setEatUserManager(EatUserManager eatUserManager) {
		this.eatUserManager = eatUserManager;
	}

}
