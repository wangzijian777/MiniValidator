package com.jd.ka.eatmoney.service.daybook.impl;



import javax.annotation.Resource;
import java.util.List;
import java.util.Date;
import org.springframework.stereotype.Service;
import org.apache.log4j.Logger;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.daybook.EatDaybookItem;
import com.jd.ka.eatmoney.manager.daybook.EatDaybookItemManager;
import com.jd.ka.eatmoney.service.daybook.EatDaybookItemService;


/**
 * @author zhangshibin
 * @since 2015-1-19
 *<p>  EatDaybookItemservice实现</p>
 *
 */
@Service("eatDaybookItemService")
public class EatDaybookItemServiceImpl implements EatDaybookItemService {

	private static final Logger logger = Logger.getLogger(EatDaybookItemServiceImpl.class);
	
	@Resource(name="eatDaybookItemManager")
	private EatDaybookItemManager eatDaybookItemManager;

    public CommonResult<EatDaybookItem> addEatDaybookItem(EatDaybookItem eatDaybookItem) {
		CommonResult<EatDaybookItem> result = new CommonResult<EatDaybookItem>();
		try {
			
		eatDaybookItem.setGmtCreate(new Date());
			 
			result.addDefaultModel(eatDaybookItemManager.addEatDaybookItem(eatDaybookItem));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("添加 EatDaybookItem失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<EatDaybookItem> updateEatDaybookItem(EatDaybookItem eatDaybookItem) {
		CommonResult<EatDaybookItem> result = new CommonResult<EatDaybookItem>();
		try {
			
				eatDaybookItem.setGmtModify(new Date());
			 
			eatDaybookItemManager.updateEatDaybookItem(eatDaybookItem);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("更新 EatDaybookItem失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
   

	public CommonResult<EatDaybookItem> deleteEatDaybookItem(Integer id) {
		CommonResult<EatDaybookItem> result = new CommonResult<EatDaybookItem>();
		try {
			eatDaybookItemManager.deleteEatDaybookItem(id);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("删除 EatDaybookItem失败", e);
			result.setSuccess(false);
		}
		return result;
    }


    	public CommonResult<EatDaybookItem> getEatDaybookItemById(Integer id) {
		CommonResult<EatDaybookItem> result = new CommonResult<EatDaybookItem>();
		try {
			result.addDefaultModel("eatDaybookItem", eatDaybookItemManager.getEatDaybookItemById(id));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据主键获取 EatDaybookItem失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	

        
	
	public CommonResult<List<EatDaybookItem>> getAll() {
		CommonResult<List<EatDaybookItem>> result = new CommonResult<List<EatDaybookItem>>();
		try {
			List<EatDaybookItem> list = eatDaybookItemManager.getAll();
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得所有 EatDaybookItem失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public CommonResult<List<EatDaybookItem>> getListByExample(EatDaybookItem eatDaybookItem) {
		CommonResult<List<EatDaybookItem>> result = new CommonResult<List<EatDaybookItem>>();
		try {
			List<EatDaybookItem> list = eatDaybookItemManager.getListByExample(eatDaybookItem);
			result.addDefaultModel("list", list);
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("取得 EatDaybookItem失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	public CommonResult<EatDaybookItem> getUnique(EatDaybookItem eatDaybookItem) {
		CommonResult<EatDaybookItem> result = new CommonResult<EatDaybookItem>();
		try {
			result.addDefaultModel(eatDaybookItemManager.getUnique(eatDaybookItem));
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("根据example获取唯一 EatDaybookItem失败", e);
			result.setSuccess(false);
		}
		return result;
	}

	



	
	public CommonResult<List<EatDaybookItem>> getEatDaybookItemByPage(PageQuery pageQuery) {
		CommonResult<List<EatDaybookItem>> result = new CommonResult<List<EatDaybookItem>>();
		try {
			int totalCount = this.count(pageQuery);
			if (totalCount > 0) {
				pageQuery.setTotalCount(totalCount);
				List<EatDaybookItem> list = eatDaybookItemManager.getEatDaybookItemByPage(pageQuery);
				result.addDefaultModel("list", list);
				result.addModel("pageQuery", pageQuery);
			}
			result.setSuccess(true);
		} catch (Exception e) {
			logger.error("分页获取 EatDaybookItem失败", e);
			result.setSuccess(false);
		}
		return result;
	}
	
	public int count(PageQuery pageQuery) {
		return eatDaybookItemManager.count(pageQuery);
	}


	/******* getter and setter ***/
	public EatDaybookItemManager getEatDaybookItemManager() {
		return eatDaybookItemManager;
	}

	public void setEatDaybookItemManager(EatDaybookItemManager eatDaybookItemManager) {
		this.eatDaybookItemManager = eatDaybookItemManager;
	}

}
