package com.jd.ka.eatmoney.service.user;

import java.util.List;
import com.jd.ka.eatmoney.common.PageQuery;
import com.jd.ka.eatmoney.common.CommonResult;
import com.jd.ka.eatmoney.domain.user.EatUser;

/**
 * @author zhangshibin
 * @since 2015-1-19
 * jshow 用户service 接口
 *
 */
public interface EatUserService {
   
    /**
     * 添加并返回设置id的EatUser对象
     * 
     * @param eatUser
     * @return
     */
    public CommonResult<EatUser> addEatUser(EatUser eatUser);
    
	/**
     * 更新EatUser
     * 
     * @param eatUser
     */
    public CommonResult<EatUser> updateEatUser(EatUser eatUser);
    

    

	 /**
     * 根据主键删除EatUser
     * 
     * @param id
     */
    public CommonResult<EatUser> deleteEatUser(Integer id);

	/**
     * 根据主键获取EatUser
     * 
     * @param id
     * @return
     */	
    public CommonResult<EatUser> getEatUserById(Integer id);

     

    /**
     * 取得所有EatUser
     * 
     * @return
     */
    public CommonResult<List<EatUser>> getAll();
    
	/**
     * 根据example取得EatUser列表
     * 
     * @param  eatUser
     * @return
     */
    public CommonResult<List<EatUser>> getListByExample(EatUser eatUser);
    
	/**
     * 根据example取得唯一的EatUser
     * 
     * @param eatUser
     * @return
     */
    public EatUser getUnique(EatUser eatUser);
    
    


    

	/**
     * 分页取得EatUser列表
     * 
     * @param pageQuery
     * @return
     */
    public CommonResult<List<EatUser>> getEatUserByPage(PageQuery pageQuery);
	
	/**
     * 根据查询条件返回数量
     * 
     * @param pageQuery
     * @return
     */
    public int count(PageQuery pageQuery);


    /**
     * 用户注册
     * @param eatUser
     */
    public CommonResult<String> doAddUser(EatUser eatUser);


    public EatUser getUserByErpAcct(String pin);

    /**
     * 根据groupId查询用户列表
     * @param groupId
     * @return
     */
    public CommonResult<List<EatUser>> getEatUserListByGroupId(Integer groupId);
}
