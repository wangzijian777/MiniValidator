package com.jd.ka.thor.common.encoding;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * @author qiulong
 *
 */
public class GzipEncoder extends AbstractEncoder {

    @Override
    protected InputStream getDecodingInputStream(InputStream input) {
        try {
            return new GZIPInputStream(input);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected OutputStream getEncodingOutputStream(OutputStream output) {
        try {
            return new GZIPOutputStream(output);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
