package com.jd.ka.thor.common.settings;


/**
 * @author qiulong
 *
 */
public interface Settings {
    
    Integer getInteger(String key, Integer defaultValue);
    
    String get(String key);
    
    String get(String key, String defaultValue);
    
    Double getDouble(String key, Double defaultValue);
    
    Long getLong(String key, Long defaultValue);
    
    Boolean getBoolean(String key, boolean defaultValue);
}
