package com.jd.ka.thor.common.settings;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import com.google.common.collect.Maps;

/**
 * @author qiulong
 *
 */
public class PropSettings implements Settings {

    private ImmutableSettings settings;

    public PropSettings(Properties prop) {
        Set<Entry<Object, Object>> set = prop.entrySet();
        Map<String, String> settingsMap = Maps.newHashMap();
        for (Entry<Object, Object> entry : set) {
            settingsMap.put(String.valueOf(entry.getKey()), String.valueOf(entry.getValue()));
        }
        this.settings = new ImmutableSettings(settingsMap);
    }

    @Override
    public Integer getInteger(String key, Integer defaultValue) {
        return settings.getInteger(key, defaultValue);
    }

    @Override
    public String get(String key) {
        return settings.get(key);
    }

    @Override
    public String get(String key, String defaultValue) {
        return settings.get(key, defaultValue);
    }

    @Override
    public Double getDouble(String key, Double defaultValue) {
        return settings.getDouble(key, defaultValue);
    }

    @Override
    public Long getLong(String key, Long defaultValue) {
        return settings.getLong(key, defaultValue);
    }

    @Override
    public Boolean getBoolean(String key, boolean defaultValue) {
        return settings.getBoolean(key, defaultValue);
    }

}
