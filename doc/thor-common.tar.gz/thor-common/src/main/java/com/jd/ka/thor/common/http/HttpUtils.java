package com.jd.ka.thor.common.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author qiulong
 *
 */
public class HttpUtils {
	private static final String UTF8_ENCODING = "UTF-8";
	
	public static String doPost(URL url, String params) throws IOException {
	    return doPost(url, params, null);
	}
	public static String doPost(URL url, String params, Map<String, String> header) throws IOException {
		HttpURLConnection conn = null;
		InputStream is = null;
		PrintStream ps = null;
		try {
			conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
			setHeader(header, conn);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setConnectTimeout(10000);
			conn.setReadTimeout(10000);
			conn.connect();
			ps = new PrintStream(conn.getOutputStream(), false, UTF8_ENCODING);
			if(params != null) {
			    ps.print(params);
			    ps.flush();
			}
			if(conn.getResponseCode() != 200) {
				throw new IOException("Request failed, error code:" + conn.getResponseCode());
			}
			is = conn.getInputStream();
			return getString(is);
		} finally {
			if(is != null) {
				try {
					is.close();
				} catch(Exception ignore) {}
			}
			if(ps != null) {
				try {
					ps.close();
				} catch(Exception ignore) {}
			}
			if(conn != null) {
				try {
					conn.disconnect();
				} catch(Exception ignore) {}
			}
		}
	}
	
	private static String getString(InputStream is) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(is, Charset.forName(UTF8_ENCODING)));
        StringBuilder sb = new StringBuilder();
        String line = null;
        while((line = br.readLine()) != null) {
            sb.append(line);
        }
        return sb.toString();
    }
	
	private static void setHeader(Map<String, String> header, HttpURLConnection conn) {
	    if(header == null) {
	        return;
	    }
	    Set<Entry<String, String>> set = header.entrySet();
	    for (Entry<String, String> entry : set) {
            conn.setRequestProperty(entry.getKey(), entry.getValue());
        }
	}
}
