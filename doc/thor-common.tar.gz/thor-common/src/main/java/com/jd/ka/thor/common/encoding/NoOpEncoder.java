package com.jd.ka.thor.common.encoding;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author qiulong
 *
 */
public class NoOpEncoder extends AbstractEncoder {

    @Override
    protected InputStream getDecodingInputStream(InputStream input) {
        return input;
    }

    @Override
    protected OutputStream getEncodingOutputStream(OutputStream output) {
        return output;
    }

}
