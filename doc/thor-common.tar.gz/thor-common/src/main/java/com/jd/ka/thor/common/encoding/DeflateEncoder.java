package com.jd.ka.thor.common.encoding;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

/**
 * @author qiulong
 *
 */
public class DeflateEncoder extends AbstractEncoder {

    @Override
    protected InputStream getDecodingInputStream(InputStream input) {
        return new InflaterInputStream(input);
    }

    @Override
    protected OutputStream getEncodingOutputStream(OutputStream output) {
        return new DeflaterOutputStream(output);
    }

}
