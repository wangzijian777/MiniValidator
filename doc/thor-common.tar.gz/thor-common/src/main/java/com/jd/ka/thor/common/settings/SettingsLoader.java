package com.jd.ka.thor.common.settings;

import java.io.IOException;


/**
 * @author qiulong
 *
 */
public interface SettingsLoader {
    Settings load(String fileName) throws IOException;
}
