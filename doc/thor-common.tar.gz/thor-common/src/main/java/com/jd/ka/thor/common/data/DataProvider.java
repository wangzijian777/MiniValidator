package com.jd.ka.thor.common.data;


/**
 * @author qiulong
 *
 */
public interface DataProvider<T> {
    T provide();
}
