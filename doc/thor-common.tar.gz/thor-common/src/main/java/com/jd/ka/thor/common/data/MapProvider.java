package com.jd.ka.thor.common.data;

import java.util.Map;


/**
 * @author qiulong
 *
 */
public interface MapProvider<K, V> extends DataProvider<Map<K, V>> {
}
