package com.jd.ka.thor.common;

import java.lang.reflect.Type;

import com.jd.ka.thor.common.data.GsonProvider;


/**
 * @author qiulong
 *
 */
public final class Json {
    private static GsonProvider provider = new GsonProvider();
    
    public static final String toJson(Object src) {
        return provider.provide().toJson(src);
    }
    
    public static final <T> T fromJson(String json, Type typeOfT) {
        return provider.provide().fromJson(json, typeOfT);
    }
    
    public static final <T> T fromJson(String json, Class<T> classOfT) {
        return provider.provide().fromJson(json, classOfT);
    }
}
