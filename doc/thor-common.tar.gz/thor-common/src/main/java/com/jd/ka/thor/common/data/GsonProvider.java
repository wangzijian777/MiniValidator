package com.jd.ka.thor.common.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;



/**
 * @author qiulong
 *
 */
public class GsonProvider implements DataProvider<Gson> {

    @Override
    public Gson provide() {
        return new GsonBuilder().create();
    }

}
