package com.jd.ka.thor.common;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.Enumeration;

import com.google.common.collect.ImmutableList;

/**
 * @author qiulong
 *
 */
public final class Network {

    public static Collection<String> getLocalAddresses() {
        try {
            InetAddress local = InetAddress.getLocalHost();
//            InetAddress localIPAddress = getLocalIPAddress();
            return ImmutableList.of(local.getHostName(), local.getHostAddress(), "localhost", "127.0.0.1");
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static InetAddress getLocalIPAddress() {
        try {
            Enumeration<?> netInterfaces = NetworkInterface.getNetworkInterfaces();
            InetAddress inetAddress = null;
            while (netInterfaces.hasMoreElements()) {
                NetworkInterface ni = (NetworkInterface) netInterfaces.nextElement();
                Enumeration<?> e2 = ni.getInetAddresses();
                while (e2.hasMoreElements()) {
                    inetAddress = (InetAddress) e2.nextElement();
                    if (!inetAddress.isLoopbackAddress() && !inetAddress.getHostAddress().contains(":")) {
                        return inetAddress;
                    }
                }
            }
            return InetAddress.getLocalHost();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
