package com.jd.ka.thor.common.settings;

import java.util.Map;

/**
 * @author qiulong
 *
 */
public class ImmutableSettings implements Settings {

    private final Map<String, String> setting;

    public ImmutableSettings(Map<String, String> setting) {
        this.setting = setting;
    }

    @Override
    public Integer getInteger(String key, Integer defaultValue) {
        String sValue = get(key);
        if (sValue == null) {
            return defaultValue;
        }
        return Integer.valueOf(sValue);
    }

    @Override
    public String get(String key) {
        return setting.get(key);
    }
    
    @Override
    public String get(String key, String defaultValue) {
        String sValue = get(key);
        if (sValue == null) {
            return defaultValue;
        }
        return sValue;
    }

    @Override
    public Double getDouble(String key, Double defaultValue) {
        String sValue = get(key);
        if (sValue == null) {
            return defaultValue;
        }
        return Double.valueOf(sValue);
    }

    @Override
    public Long getLong(String key, Long defaultValue) {
        String sValue = get(key);
        if (sValue == null) {
            return defaultValue;
        }
        return Long.valueOf(sValue);
    }
    
    @Override
    public Boolean getBoolean(String key, boolean defaultValue) {
        String sValue = get(key);
        if (sValue == null) {
            return defaultValue;
        }
        return Boolean.valueOf(sValue);
    }

}
