package com.jd.ka.thor.common.settings;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author qiulong
 *
 */
public class PropSettingsLoader implements SettingsLoader {

    @Override
    public Settings load(String fileName) throws IOException {
        InputStream in = null;
        try {
            Properties prop = new Properties();
            in = getClass().getResourceAsStream(fileName);
            if (in != null) {
                prop.load(in);
            }
            return new PropSettings(prop);
        } finally {
            if (in != null) {
                in.close();
            }
        }
    }

}
