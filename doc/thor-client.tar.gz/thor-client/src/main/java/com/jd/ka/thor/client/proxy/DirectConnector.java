package com.jd.ka.thor.client.proxy;

import org.littleshoot.proxy.ChainedProxyAdapter;


/**
 * TODO direct connection implements
 * @author qiulong
 *
 */
public class DirectConnector extends ChainedProxyAdapter {

}
