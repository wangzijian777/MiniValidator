package com.jd.ka.thor.client.proxy.saf;

import com.google.common.collect.ImmutableMap.Builder;
import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.remote.MockTransfer;
import com.jd.ka.thor.client.remote.Protocol;

/**
 * @author qiulong
 *
 */
public class SAFTransfer extends MockTransfer {

    private String interfaceName;
    private String method;
    private String group;
    private String version;
    private String params;

    public SAFTransfer(ThorConfig config) {
        super(config);
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getMethod() {
        return method;
    }

    public SAFTransfer setMethod(String method) {
        this.method = method;
        return this;
    }

    public String getGroup() {
        return group;
    }

    public SAFTransfer setGroup(String group) {
        this.group = group;
        return this;
    }

    public String getVersion() {
        return version;
    }

    public SAFTransfer setVersion(String version) {
        this.version = version;
        return this;
    }

    public String getParams() {
        return params;
    }

    public SAFTransfer setParams(String params) {
        this.params = params;
        return this;
    }

    @Override
    protected Protocol getProtocol() {
        return Protocol.SAF;
    }

    @Override
    protected void prepareMockParameter(Builder<String, String> builder) {
        builder.put("interfaceName", getInterfaceName()).put("method", getMethod()).put("group", getGroup())
                .put("version", getVersion()).put("params", getParams());
    }

}
