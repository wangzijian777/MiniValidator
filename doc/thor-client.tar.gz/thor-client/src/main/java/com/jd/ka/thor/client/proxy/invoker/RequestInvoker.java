package com.jd.ka.thor.client.proxy.invoker;

import io.netty.handler.codec.http.FullHttpResponse;

import java.io.IOException;

import com.google.common.base.Optional;
import com.jd.ka.thor.client.proxy.message.HttpRequestMessage;


/**
 * @author qiulong
 *
 */
public interface RequestInvoker extends Ordered {
    
    boolean support(HttpRequestMessage request);
    
    Optional<? extends FullHttpResponse> invoke(HttpRequestMessage request) throws IOException;
    
}
