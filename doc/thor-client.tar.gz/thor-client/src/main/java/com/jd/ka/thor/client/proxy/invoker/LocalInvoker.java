package com.jd.ka.thor.client.proxy.invoker;

import static com.google.common.base.Charsets.UTF_8;
import static com.google.common.net.HttpHeaders.CONTENT_TYPE;
import static com.google.common.net.MediaType.JSON_UTF_8;
import static com.google.common.net.MediaType.PLAIN_TEXT_UTF_8;
import static io.netty.buffer.Unpooled.wrappedBuffer;
import static io.netty.handler.codec.http.HttpResponseStatus.OK;
import static io.netty.handler.codec.http.HttpVersion.HTTP_1_1;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpResponse;

import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;

import com.google.common.base.Optional;
import com.google.common.net.MediaType;
import com.google.gson.internal.Primitives;
import com.jd.ka.thor.client.proxy.message.HttpRequestMessage;
import com.jd.ka.thor.client.spring.ApplicationContextHolder;
import com.jd.ka.thor.common.Json;
import com.jd.ka.thor.common.encoding.B64Code;

/**
 * @author qiulong
 *
 */
public class LocalInvoker implements RequestInvoker {

    private static final String THOR_HEADER = "X-Thor";
    private static final String THOR_HEADER_CALL = "CALL";

    @Override
    public boolean support(HttpRequestMessage request) {
        String header = request.getHeader(THOR_HEADER);
        return THOR_HEADER_CALL.equalsIgnoreCase(header);
    }

    @Override
    public Optional<? extends FullHttpResponse> invoke(HttpRequestMessage request) throws IOException {
        String data = extractBodyToString(request);
        Optional<? extends ReturnInfo> respData = doInvoke(data);
        return prepareResponse(respData);
    }

    @Override
    public int order() {
        return 0;
    }

    protected Optional<? extends ReturnInfo> doInvoke(String data) throws InvokeException {
        LocalInvokerEntry entry = Json.fromJson(data, LocalInvokerEntry.class);
        String beanName = entry.getBeanName();
        String methodName = entry.getMethodName();
        String[] paramType = entry.getParamType();
        String[] params = entry.getParams();
        Object bean = ApplicationContextHolder.getBean(beanName);
        Method method = findMethod(bean.getClass(), methodName, paramType);
        try {
            Object obj = method.invoke(bean, prepareArgs(method, params));
            return Optional.fromNullable(returnTo(obj));
        } catch (Exception e) {
            throw new InvokeException(e);
        }
    }

    protected Method findMethod(Class<?> clazz, String methodName, String[] sParamTypes) {
        if (sParamTypes != null && sParamTypes.length > 0) {
            Class<?>[] paramTypes = new Class<?>[sParamTypes.length];
            for (int i = 0; i < sParamTypes.length; i++) {
                String sParamType = sParamTypes[i];
                try {
                    paramTypes[i] = Class.forName(sParamType);
                } catch (ClassNotFoundException e) {
                    throw new IllegalArgumentException(String.format("Class [%] not found", sParamType));
                }
            }
            try {
                return clazz.getMethod(methodName, paramTypes);
            } catch (NoSuchMethodException e) {
                throw new IllegalArgumentException(String.format("Method [%] not found", methodName));
            }
        } else {
            Method[] methods = clazz.getMethods();
            for (Method method : methods) {
                if (method.getName().equals(methodName)) {
                    return method;
                }
            }
        }
        throw new IllegalArgumentException(String.format("Method [%] not found", methodName));
    }

    protected Object[] prepareArgs(Method method, String[] params) {
        if (params == null) {
            params = new String[0];
        }
        Type[] parameterTypes = method.getGenericParameterTypes();
        if (parameterTypes.length != params.length) {
            throw new IllegalArgumentException(String.format(
                    "Method [%s] parameters do not match [expect: %d, actual: %d]", method.getName(),
                    parameterTypes.length, params.length));
        }
        Object[] args = new Object[parameterTypes.length];
        for (int i = 0; i < parameterTypes.length; i++) {
            args[i] = Json.fromJson(params[i], parameterTypes[i]);
        }
        return args;
    }

    protected Optional<? extends FullHttpResponse> prepareResponse(Optional<? extends ReturnInfo> resp) {
        FullHttpResponse response = null;
        if (resp.isPresent()) {
            ReturnInfo returnInfo = resp.get();
            MediaType mediaType = returnInfo.getMediaType();
            String data = returnInfo.getData();
            byte[] bytes = B64Code.encode(data).getBytes(UTF_8);
            response = new DefaultFullHttpResponse(HTTP_1_1, OK, wrappedBuffer(bytes));
            response.headers().add(CONTENT_TYPE, mediaType);
        } else {
            response = new DefaultFullHttpResponse(HTTP_1_1, OK);
        }
        return Optional.of(response);
    }

    protected ReturnInfo returnTo(Object obj) {
        if(obj == null) {
            return null;
        }
        if (obj instanceof String) {
            return new ReturnInfo(PLAIN_TEXT_UTF_8, (String) obj);
        }
        if(Primitives.isPrimitive(obj.getClass())) {
            return new ReturnInfo(PLAIN_TEXT_UTF_8, String.valueOf(obj));
        }
        return new ReturnInfo(JSON_UTF_8, Json.toJson(obj));
    }

    private String extractBodyToString(HttpRequestMessage request) throws IOException {
        return B64Code.decode(request.getBodyAsText().read(), UTF_8.name());
    }

    public static class LocalInvokerEntry {

        private String beanName;
        private String methodName;
        private String[] params;
        private String[] paramType;

        public String getBeanName() {
            return beanName;
        }

        public String getMethodName() {
            return methodName;
        }

        public String[] getParams() {
            return params;
        }

        public String[] getParamType() {
            return paramType;
        }

    }

    public static class ReturnInfo {

        private MediaType mediaType;
        private String data;

        private ReturnInfo(MediaType mediaType, String data) {
            this.mediaType = mediaType;
            this.data = data;
        }

        public MediaType getMediaType() {
            return mediaType;
        }

        public String getData() {
            return data;
        }

    }

}
