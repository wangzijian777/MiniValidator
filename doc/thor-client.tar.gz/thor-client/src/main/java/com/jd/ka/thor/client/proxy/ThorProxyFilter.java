package com.jd.ka.thor.client.proxy;

import static io.netty.handler.codec.http.HttpResponseStatus.INTERNAL_SERVER_ERROR;
import static io.netty.handler.codec.http.HttpVersion.HTTP_1_1;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpContent;
import io.netty.handler.codec.http.HttpMessage;
import io.netty.handler.codec.http.HttpObject;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponse;

import java.io.IOException;
import java.util.List;

import org.littleshoot.proxy.HttpFiltersAdapter;
import org.littleshoot.proxy.impl.ProxyUtils;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.proxy.invoker.DummyInvoker;
import com.jd.ka.thor.client.proxy.invoker.LocalInvoker;
import com.jd.ka.thor.client.proxy.invoker.OrderedSort;
import com.jd.ka.thor.client.proxy.invoker.RemoteMockInvoker;
import com.jd.ka.thor.client.proxy.invoker.RequestInvoker;
import com.jd.ka.thor.client.proxy.message.NettyRequestAdapter;

/**
 * @author qiulong
 *
 */
public class ThorProxyFilter extends HttpFiltersAdapter {

    private final NettyRequestAdapter request;
    private final ThorConfig config;
    private List<RequestInvoker> invokers;

    public ThorProxyFilter(ThorConfig config, HttpRequest originalRequest) {
        super(originalRequest);
        this.config = config;
        this.request = NettyRequestAdapter.wrap(originalRequest);
        initDispatcher();
    }

    @Override
    public HttpResponse requestPre(HttpObject httpObject) {
        try {
            HttpResponse response = null;
            if (httpObject instanceof HttpRequest) {
                request.copyHeaders((HttpMessage) httpObject);
            }

            if (httpObject instanceof HttpContent) {
                request.append((HttpContent) httpObject);
            }

            // Check is last chunk of a transfer
            if (ProxyUtils.isLastChunk(httpObject)) {
                response = dispatchRequest().orNull();
            }

            return response;
        } catch (IOException e) {
            return createErrorResponse(e);
        }
    }

    private Optional<? extends FullHttpResponse> dispatchRequest() throws IOException {
        for (RequestInvoker invoker : invokers) {
            if (invoker.support(request)) {
                return invoker.invoke(request);
            }
        }
        throw new UnsupportedOperationException(String.format("%s can not found", RequestInvoker.class));
    }

    private HttpResponse createErrorResponse(IOException e) {
        return new DefaultFullHttpResponse(HTTP_1_1, INTERNAL_SERVER_ERROR);
    }
    
    private void initDispatcher() {
        invokers = Lists.newArrayList(
                new LocalInvoker(),
                new DummyInvoker(),
                new RemoteMockInvoker(config)
        );
        OrderedSort.sort(invokers);
    }

}
