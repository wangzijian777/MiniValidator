package com.jd.ka.thor.client.config;

import java.io.IOException;

import com.jd.ka.thor.common.settings.PropSettingsLoader;
import com.jd.ka.thor.common.settings.Settings;


/**
 * @author qiulong
 *
 */
public class ThorConfigLoader {
    private static final String PROP_FILE_NAME = "/thor.properties";
    private static Settings settings;
    
    public static Settings load() {
        if(settings != null) {
            return settings;
        }
        try {
            return settings = new PropSettingsLoader().load(PROP_FILE_NAME);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
}
