package com.jd.ka.thor.client.remote;

import com.jd.ka.thor.common.data.MapProvider;

/**
 * @author qiulong
 *
 */
public interface Transfer<T> extends MapProvider<String, String> {

    T invoke() throws RemoteInvokerException;

    String getOperation();

}
