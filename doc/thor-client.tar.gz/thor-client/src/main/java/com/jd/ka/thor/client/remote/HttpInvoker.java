package com.jd.ka.thor.client.remote;

import java.io.IOException;

import com.jd.ka.thor.common.encoding.B64Code;
import com.jd.ka.thor.common.http.HttpUtils;
import com.jd.ka.thor.common.http.QueryStringUtil;


/**
 * @author qiulong
 *
 */
public class HttpInvoker implements RemoteInvoker {
    
    HttpInvoker() {};

    @Override
    public <Response, Return> Return invoke(Transfer<Return> transfer, ResponseHandler<Response, Return> handler) throws RemoteInvokerException {
        if (!(transfer instanceof HttpTransfer)) {
            throw new UnsupportedOperationException(Transfer.class + " must be an instance of " + HttpTransfer.class);
        }
        HttpTransfer httpTranser = (HttpTransfer) transfer;
        try {
            String query = QueryStringUtil.query(transfer.provide());
            query = B64Code.encode(query);
            @SuppressWarnings("unchecked")
            Response resp = (Response)HttpUtils.doPost(httpTranser.getURL(), query);
            return handler.handle(resp);
        } catch (IOException e) {
            throw new RemoteInvokerException(e);
        }
    }

}
