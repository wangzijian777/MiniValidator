package com.jd.ka.thor.client.proxy.invoker;

import io.netty.handler.codec.http.FullHttpResponse;

import java.io.IOException;
import java.net.URI;
import java.util.Collection;

import com.google.common.base.Optional;
import com.jd.ka.thor.client.proxy.message.HttpRequestMessage;
import com.jd.ka.thor.common.Network;


/**
 * @author qiulong
 *
 */
public class DummyInvoker implements RequestInvoker {
    
    private static final Collection<String> localAddresses = Network.getLocalAddresses();

    @Override
    public int order() {
        return 1;
    }

    @Override
    public boolean support(HttpRequestMessage request) {
        URI uri = request.getUri();
        return uri.getHost() == null || localAddresses.contains(uri.getHost());
    }

    @Override
    public Optional<? extends FullHttpResponse> invoke(HttpRequestMessage request) throws IOException {
        return Optional.absent();
    }

}
