package com.jd.ka.thor.client.remote;

/**
 * @author qiulong
 *
 */
public final class RemoteInvokerFactory {
    private static RemoteInvoker invoker = new HttpInvoker();

    public static RemoteInvoker create() {
        return invoker;
    }

}
