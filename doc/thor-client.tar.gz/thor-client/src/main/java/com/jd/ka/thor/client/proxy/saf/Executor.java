package com.jd.ka.thor.client.proxy.saf;

/**
 * @author qiulong
 *
 */
public interface Executor {

    void execute(SAFContext context);
}
