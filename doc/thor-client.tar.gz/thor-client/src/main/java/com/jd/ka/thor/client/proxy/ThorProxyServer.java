package com.jd.ka.thor.client.proxy;

import io.netty.handler.codec.http.HttpRequest;

import java.net.InetSocketAddress;

import org.littleshoot.proxy.HttpFilters;
import org.littleshoot.proxy.HttpFiltersSourceAdapter;
import org.littleshoot.proxy.HttpProxyServer;
import org.littleshoot.proxy.HttpProxyServerBootstrap;
import org.littleshoot.proxy.extras.SelfSignedMitmManager;
import org.littleshoot.proxy.impl.DefaultHttpProxyServer;

import com.jd.ka.commons.logging.Logger;
import com.jd.ka.commons.logging.LoggerFactory;
import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.proxy.ssl.SSLOverrider;
import com.jd.ka.thor.client.remote.RemoteInvokerException;

/**
 * @author qiulong
 *
 */
public class ThorProxyServer implements ProxyServer {

    private static final Logger logger = LoggerFactory.getLogger(ProxyServer.class, "proxy-server");
    private final ProxyOverrider proxyOverrider = new ProxyOverrider();
    private final SSLOverrider sslOverrider = new SSLOverrider();
    private boolean running;
    private HttpProxyServer httpProxyServer;
    private ThorConfig config;

    @Override
    public void start(final ThorConfig config) {
        this.config = config;
        InetSocketAddress address = new InetSocketAddress(config.getProxyHost(), config.getProxyPort());
        logger.info("Thor proxy server is binding to {}", address);
        HttpProxyServerBootstrap proxyServerBootstrap = DefaultHttpProxyServer.bootstrap()
                .withIdleConnectionTimeout(config.getProxyTimeoutSeconds()).withAddress(address);
        if (config.isSslEnabled()) {
            proxyServerBootstrap.withManInTheMiddle(new SelfSignedMitmManager());
        } else {
            proxyServerBootstrap.withChainProxyManager(proxyOverrider);
        }
        proxyServerBootstrap.withFiltersSource(new HttpFiltersSourceAdapter() {

            @Override
            public int getMaximumRequestBufferSizeInBytes() {
                return config.getRequestBufferSize();
            }

            @Override
            public HttpFilters filterRequest(HttpRequest originalRequest) {
                ThorProxyFilter filter = new ThorProxyFilter(config, originalRequest);
                return new PredicatedHttpFilters(filter, originalRequest);
            }
        });

        this.httpProxyServer = proxyServerBootstrap.start();
        this.running = true;
        overrideProxySettings();
        overrideSSLSettings();
        logger.info("Thor proxy server start success at address: {}", address);
        registSelf();
    }

    @Override
    public void stop() {
        if (!this.running) {
            logger.info("Thor proxy server already shutdown");
            return;
        }
        restoreOriginalProxySettings();
        restoreOriginalSSLSettings();

        httpProxyServer.stop();
        this.running = false;
        logger.info("Thor proxy server stop success");
        unregistSelf();
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    private void overrideSSLSettings() {
        if (config.isSslEnabled()) {
            sslOverrider.activate();
        }
    }

    private void restoreOriginalSSLSettings() {
        sslOverrider.deactivate();
    }

    private void overrideProxySettings() {
        proxyOverrider.activate(config.getProxyHost(), config.getProxyPort(), config.getIgnoreHosts());
    }

    private void restoreOriginalProxySettings() {
        proxyOverrider.deactivateAll();
    }

    private void registSelf() {
        RegistTransfer transfer = new RegistTransfer(config) {
            @Override public String getOperation() {
                return "regist";
            }
        };
        logger.info("Begin regist Proxy Server: {}", transfer);
        try {
            transfer.invoke();
        } catch (RemoteInvokerException e) {
            if (config.debug()) {
                logger.error("Regist Proxy Server failed: {}", transfer);
            } else {
                throw new IllegalStateException(String.format("Regist Proxy Server failed: %s", transfer));
            }
        }
    }

    private void unregistSelf() {
        RegistTransfer transfer = new RegistTransfer(config) {
            @Override public String getOperation() {
                return "unregist";
            }
        };
        logger.info("Begin unregist Proxy Server: {}", transfer);
        try {
            transfer.invoke();
        } catch (RemoteInvokerException e) {
            logger.error("Unregist Proxy Server failed: {}", transfer);
        }
    }

}
