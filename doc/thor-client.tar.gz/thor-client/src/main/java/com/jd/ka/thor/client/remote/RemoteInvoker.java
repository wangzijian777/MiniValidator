package com.jd.ka.thor.client.remote;

/**
 * @author qiulong
 *
 */
public interface RemoteInvoker {

    <Response, Return> Return invoke(Transfer<Return> bean, ResponseHandler<Response, Return> handler) throws RemoteInvokerException;

    public interface ResponseHandler<Response, Return> {

        Return handle(Response response);
    }
}
