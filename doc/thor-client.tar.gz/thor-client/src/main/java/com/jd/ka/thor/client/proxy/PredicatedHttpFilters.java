package com.jd.ka.thor.client.proxy;

import static com.google.common.base.Predicates.not;
import static io.netty.handler.codec.http.HttpMethod.CONNECT;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpObject;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponse;

import org.littleshoot.proxy.HttpFilters;
import org.littleshoot.proxy.HttpFiltersAdapter;

import com.google.common.base.Predicate;


/**
 * @author qiulong
 *
 */
public class PredicatedHttpFilters extends HttpFiltersAdapter {
    
    private static final Predicate<HttpRequest> NOT_CONNECT = not(httpMethodPredicate(CONNECT));
    private final HttpFilters delegate;
    
    public PredicatedHttpFilters(HttpFilters delegate, HttpRequest originalRequest) {
        super(originalRequest);
        this.delegate = delegate;
    }
    
    public static Predicate<HttpRequest> httpMethodPredicate(final HttpMethod method) {
        return new Predicate<HttpRequest>() {
            @Override
            public boolean apply(HttpRequest input) {
                return method.equals(input.getMethod());
            }
        };
    }

    @Override
    public HttpResponse requestPre(HttpObject httpObject) {
        if (NOT_CONNECT.apply(originalRequest)) {
            return delegate.requestPre(httpObject);
        } else {
            return null;
        }
    }

    @Override
    public HttpResponse requestPost(HttpObject httpObject) {
        if (NOT_CONNECT.apply(originalRequest)) {
            return delegate.requestPost(httpObject);
        } else {
            return null;
        }
    }

    @Override
    public HttpObject responsePre(HttpObject httpObject) {
        if (NOT_CONNECT.apply(originalRequest)) {
            return delegate.responsePre(httpObject);
        } else {
            return httpObject;
        }
    }

    @Override
    public HttpObject responsePost(HttpObject httpObject) {
        if (NOT_CONNECT.apply(originalRequest)) {
            return delegate.responsePost(httpObject);
        } else {
            return httpObject;
        }
    }
    
    

}
