package com.jd.ka.thor.client;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.web.context.support.WebApplicationContextUtils;

import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.config.ThorConfigLoader;
import com.jd.ka.thor.client.proxy.ProxyServerBootstrap;
import com.jd.ka.thor.client.spring.ApplicationContextHolder;

/**
 * @author qiulong
 *
 */
public class ThorListener implements ServletContextListener {

    private ProxyServerBootstrap bootstrap = new ProxyServerBootstrap();

    @Override
    public void contextInitialized(ServletContextEvent context) {
        ThorConfig config = new ThorConfig(ThorConfigLoader.load());
        bootstrap.start(config);
        ApplicationContextHolder.init(WebApplicationContextUtils.getWebApplicationContext(context.getServletContext()));
    }

    @Override
    public void contextDestroyed(ServletContextEvent context) {
        bootstrap.stop();
    }

}
