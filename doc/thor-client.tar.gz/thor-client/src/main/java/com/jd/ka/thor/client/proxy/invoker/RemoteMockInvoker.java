package com.jd.ka.thor.client.proxy.invoker;

import static com.google.common.base.Charsets.UTF_8;
import static com.jd.ka.thor.common.Json.toJson;
import static io.netty.buffer.Unpooled.wrappedBuffer;
import static io.netty.handler.codec.http.HttpResponseStatus.NOT_FOUND;
import static io.netty.handler.codec.http.HttpResponseStatus.OK;
import static io.netty.handler.codec.http.HttpVersion.HTTP_1_1;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpResponse;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.util.Map;

import com.google.common.base.Charsets;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.io.ByteSource;
import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.proxy.message.HttpRequestMessage;
import com.jd.ka.thor.client.remote.MockResult;
import com.jd.ka.thor.client.remote.MockTransfer;
import com.jd.ka.thor.client.remote.Protocol;
import com.jd.ka.thor.common.Json;
import com.jd.ka.thor.common.http.QueryStringUtil;

/**
 * @author qiulong
 *
 */
public class RemoteMockInvoker implements RequestInvoker {

    private final ThorConfig config;

    public RemoteMockInvoker(ThorConfig config) {
        this.config = config;
    }

    @Override
    public int order() {
        return 2;
    }

    @Override
    public boolean support(HttpRequestMessage request) {
        return true;
    }

    @Override
    public Optional<? extends FullHttpResponse> invoke(HttpRequestMessage request) throws IOException {
        FullHttpResponse response = null;
        HttpMockTransfer bean = new HttpMockTransfer(config);
        bean.setBody(request.getBodyAsBinary());
        bean.setHeader(request.getHeaders());
        bean.setUri(request.getUri());
        bean.setMethod(request.getMethod());
        MockResult rs = bean.invoke();
        if (rs.isValid()) {
            if (rs.isSuccess()) {
                String json = rs.getResult();
                HttpEntry httpEntry = Json.fromJson(json, HttpEntry.class);
                String body = httpEntry.getBody();
                if (body != null && !body.isEmpty()) {
                    response = new DefaultFullHttpResponse(HTTP_1_1, OK, wrappedBuffer(body.getBytes(UTF_8)));
                } else {
                    response = new DefaultFullHttpResponse(HTTP_1_1, OK);
                }
            } else {
                response = new DefaultFullHttpResponse(HTTP_1_1, NOT_FOUND,
                        wrappedBuffer("mock service failed".getBytes()));
            }
        }
        return Optional.of(response);
    }

    public static class HttpEntry {

        private Map<String, String> header;
        private String body;

        public Map<String, String> getHeader() {
            return header;
        }

        public void setHeader(Map<String, String> header) {
            this.header = header;
        }

        public String getBody() {
            return body;
        }

        public void setBody(String body) {
            this.body = body;
        }

    }

    public static class HttpMockTransfer extends MockTransfer {

        private Map<String, String> header;
        private ByteSource body;
        private URI uri;
        private String method;

        public HttpMockTransfer(ThorConfig config) {
            super(config);
        }

        public void setHeader(Map<String, String> header) {
            this.header = header;
        }

        public void setBody(ByteSource body) {
            this.body = body;
        }

        public void setUri(URI uri) {
            this.uri = uri;
        }

        public void setMethod(String method) {
            this.method = method;
        }

        @Override
        protected Protocol getProtocol() {
            return Protocol.HTTP;
        }

        @Override
        protected void prepareMockParameter(Builder<String, String> builder) {
            try {
                URL url = new URL(uri.getScheme(), uri.getHost(), uri.getPort(), uri.getPath());
                builder.put("uri", url.toString());
                builder.put("method", method);
                builder.put("header", toJson(header));
                builder.put("urlParams", toJson(QueryStringUtil.parse(uri.getQuery())));
                builder.put("body", Unpooled.wrappedBuffer(body.read()).toString(Charsets.UTF_8));
            } catch (IOException e) {
                throw new IllegalArgumentException(e);
            }
        }
    }

}
