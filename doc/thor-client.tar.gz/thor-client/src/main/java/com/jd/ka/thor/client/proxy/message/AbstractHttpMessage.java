package com.jd.ka.thor.client.proxy.message;

import static com.google.common.base.Charsets.UTF_8;
import static com.google.common.net.HttpHeaders.*;
import static com.google.common.net.MediaType.OCTET_STREAM;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.google.common.base.Strings;
import com.google.common.io.ByteSource;
import com.google.common.io.CharSource;
import com.google.common.net.MediaType;

/**
 * @author qiulong
 *
 */
public abstract class AbstractHttpMessage implements HttpMessage {

    public static final String DEFAULT_CONTENT_TYPE = OCTET_STREAM.toString();
    public static final String DEFAULT_CHARSET = UTF_8.toString();
    public static final String DEFAULT_ENCODING = "none";

    @Override
    public final ByteSource getBodyAsBinary() {
        return new ByteSource() {
            @Override  public InputStream openStream() throws IOException {
                return getBodyAsStream();
            }
        };
    }

    @Override
    public final CharSource getBodyAsText() {
        return new CharSource() {
            @Override public Reader openStream() throws IOException {
                return getBodyAsReader();
            }
        };
    }

    @Override
    public String getCharset() {
        String header = getHeader(CONTENT_TYPE);
        if (Strings.isNullOrEmpty(header)) {
            return DEFAULT_CHARSET;
        } else {
            return MediaType.parse(header).charset().or(UTF_8).toString();
        }
    }

    @Override
    public String getEncoding() {
        String header = getHeader(CONTENT_ENCODING);
        return Strings.isNullOrEmpty(header) ? DEFAULT_ENCODING : header;
    }

    @Override
    public String getContentType() {
        String header = getHeader(CONTENT_TYPE);
        if (Strings.isNullOrEmpty(header)) {
            return DEFAULT_CONTENT_TYPE;
        } else {
            return MediaType.parse(header).withoutParameters().toString();
        }
    }

    @Override
    public String getHeader(String name) {
        return getHeaders().get(name);
    }

    protected abstract InputStream getBodyAsStream() throws IOException;

    protected Reader getBodyAsReader() throws IOException {
        return new InputStreamReader(getBodyAsBinary().openStream(), getCharset());
    }

}
