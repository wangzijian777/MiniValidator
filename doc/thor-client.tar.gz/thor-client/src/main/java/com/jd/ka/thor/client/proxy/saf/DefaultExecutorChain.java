package com.jd.ka.thor.client.proxy.saf;


/**
 * @author qiulong
 *
 */
public class DefaultExecutorChain extends ExecutorChain {

    public DefaultExecutorChain() {
        this.add(new RemoteExecutor()).add(new VCRExecutor());
    }

    @Override
    public void execute(SAFContext context) {
        this.chain(context);
    }

}
