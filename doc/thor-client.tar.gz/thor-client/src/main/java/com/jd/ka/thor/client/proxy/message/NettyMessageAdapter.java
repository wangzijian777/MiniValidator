package com.jd.ka.thor.client.proxy.message;

import static io.netty.buffer.Unpooled.copiedBuffer;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.CompositeByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.http.HttpContent;
import io.netty.handler.codec.http.HttpMessage;
import io.netty.handler.codec.http.HttpVersion;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;

/**
 * @author qiulong
 *
 */
public abstract class NettyMessageAdapter<T extends HttpMessage> extends AbstractHttpMessage {

    protected final T delegate;
    protected final CompositeByteBuf body = Unpooled.compositeBuffer();
    protected final Multimap<String, String> headers = LinkedHashMultimap.create();

    protected NettyMessageAdapter(T delegate) {
        this.delegate = delegate;
        copyHeaders(delegate);
    }

    public void append(HttpContent chunk) throws IOException {
        body.addComponent(copiedBuffer(chunk.content()));
        body.writerIndex(body.writerIndex() + chunk.content().readableBytes());
    }

    public void copyHeaders(HttpMessage httpMessage) {
        for (String name : httpMessage.headers().names()) {
            for (String value : httpMessage.headers().getAll(name)) {
                if (!headers.containsEntry(name, value)) {
                    headers.put(name, value);
                }
            }
        }
    }

    @Override
    public Map<String, String> getHeaders() {
        ImmutableMap.Builder<String, String> builder = ImmutableMap.builder();
        for (String name : headers.keySet()) {
            builder.put(name, getHeader(name));
        }
        return builder.build();
    }

    @Override
    public boolean hasBody() {
        return body.capacity() > 0;
    }
    
    public abstract HttpVersion getProtocolVersion();

    @Override
    protected InputStream getBodyAsStream() throws IOException {
        return new ByteBufInputStream(Unpooled.copiedBuffer(body));
    }

}
