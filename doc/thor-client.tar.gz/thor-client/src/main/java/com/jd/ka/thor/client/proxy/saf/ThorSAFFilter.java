package com.jd.ka.thor.client.proxy.saf;

import com.jd.service.rpc.Filter;
import com.jd.service.rpc.Invocation;
import com.jd.service.rpc.Invoker;
import com.jd.service.rpc.Result;
import com.jd.service.rpc.RpcException;

/**
 * 
 * @author qiulong
 *
 */
public class ThorSAFFilter implements Filter {

    private Executor executor;

    public ThorSAFFilter() {
        executor = new DefaultExecutorChain();
    }

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        SAFContext context = new SAFContext(invoker, invocation);
        executor.execute(context);
        return context.getInvokeResult();
    }

}
