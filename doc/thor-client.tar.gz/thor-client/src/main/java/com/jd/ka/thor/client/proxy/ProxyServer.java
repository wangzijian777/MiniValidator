package com.jd.ka.thor.client.proxy;

import com.jd.ka.thor.client.config.ThorConfig;

/**
 * @author qiulong
 *
 */
public interface ProxyServer {

    void start(ThorConfig config);

    void stop();
    
    boolean isRunning();
}
