package com.jd.ka.thor.client.remote;

import static com.google.common.base.Charsets.UTF_8;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.remote.RemoteInvoker.ResponseHandler;
import com.jd.ka.thor.common.Json;
import com.jd.ka.thor.common.encoding.B64Code;

/**
 * @author qiulong
 *
 */
public abstract class HttpTransfer implements Transfer<MockResult> {

    public static final String URL_SEPARATOR = "/";

    protected final ThorConfig config;

    private static ResponseHandler<String, MockResult> handler = new ResponseHandler<String, MockResult>() {
        @Override  public MockResult handle(String response) {
            if (response != null && !response.isEmpty()) {
                try {
                    response = B64Code.decode(response, UTF_8.name());
                    return Json.fromJson(response, MockResult.class);
                } catch (UnsupportedEncodingException ignore) {}
            }
            return null;
        }
    };

    protected HttpTransfer(ThorConfig config) {
        this.config = config;
    }
    
    @Override
    public final Map<String, String> provide() {
        ImmutableMap.Builder<String, String> builder = new ImmutableMap.Builder<String, String>().put("app", config.getAppName());
        prepareParameter(builder);
        return builder.build();
    }
    
    @Override
    public final MockResult invoke() throws RemoteInvokerException {
        RemoteInvoker invoker = RemoteInvokerFactory.create();
        return invoker.invoke(this, handler);
    }

    public URL getURL() {
        String operation = getOperation();
        if (operation == null) {
            throw new IllegalArgumentException("operation cannot be null");
        }
        if (!operation.startsWith(URL_SEPARATOR)) {
            operation = URL_SEPARATOR + operation;
        }
        try {
            return new URL("http", config.getServerHost(), config.getServerPort(), operation);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException(String.format("malformed url path: %s", operation));
        }
    }

    protected abstract void prepareParameter(ImmutableMap.Builder<String, String> builder);

}
