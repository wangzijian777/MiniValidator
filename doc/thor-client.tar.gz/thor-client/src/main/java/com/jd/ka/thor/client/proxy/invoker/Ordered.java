package com.jd.ka.thor.client.proxy.invoker;


/**
 * @author qiulong
 *
 */
public interface Ordered {

    int order();
    
}
