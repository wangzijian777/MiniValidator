package com.jd.ka.thor.client.proxy.message;


/**
 * @author qiulong
 *
 */
public interface HttpResponseMessage extends HttpMessage {
    
    /**
     * @return the HTTP status code of the response.
     */
    int getStatus();
    
}
