package com.jd.ka.thor.client.proxy.saf;

/**
 * @author qiulong
 *
 */
public abstract class ExecutorChain implements Executor {

    private Executor next;

    protected final void chain(SAFContext context) {
        if (this.next != null) {
            next.execute(context);
        }
    }
    
    public void setNext(Executor next) {
        this.next = next;
    }

    public Executor add(Executor next) {
        setNext(next);
        return next;
    }

    public ExecutorChain add(ExecutorChain next) {
        setNext(next);
        return next;
    }

}
