package com.jd.ka.thor.client.proxy.invoker;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;


/**
 * @author qiulong
 *
 */
public final class OrderedSort {
    
    public static void sort(List<? extends Ordered> ordered) {
        Collections.sort(ordered, new Comparator<Ordered>() {
            @Override public int compare(Ordered o1, Ordered o2) {
                return o1.order() > o2.order() ? 1 : -1;
            }
        });
    }
    
}
