package com.jd.ka.thor.client.remote;


/**
 * @author qiulong
 *
 */
public enum Protocol {
    HTTP {
        @Override public String code() {
            return "HTTP";
        }
    },
    SAF {
        @Override  public String code() {
            return "SAF";
        }
        
    },
    WEBSERVICE {
        @Override public String code() {
            return "WS";
        }
    }
    ;
    
    public abstract String code();
}
