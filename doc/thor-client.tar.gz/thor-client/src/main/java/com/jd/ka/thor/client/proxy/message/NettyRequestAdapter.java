package com.jd.ka.thor.client.proxy.message;

import io.netty.handler.codec.http.HttpObject;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpVersion;

import java.net.URI;
import java.net.URISyntaxException;

import com.google.common.base.Joiner;


/**
 * @author qiulong
 *
 */
public class NettyRequestAdapter extends NettyMessageAdapter<HttpRequest> implements HttpRequestMessage {
    public static NettyRequestAdapter wrap(HttpObject message) {
        if (message instanceof HttpRequest) {
            return new NettyRequestAdapter((HttpRequest) message);
        } else {
            throw new IllegalArgumentException(String.format("%s is not an instance of %s", message.getClass().getName(), HttpRequest.class.getName()));
        }
    }
    
    NettyRequestAdapter( HttpRequest delegate ) {
        super(delegate);
    }
    
    @Override
    public URI getUri() {
        String uri = this.delegate.getUri();
        try {
            return new URI(uri);
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(String.format("Invalid uri %s", uri));
        }
    }

    @Override
    public String getMethod() {
        return this.delegate.getMethod().name();
    }

    @Override
    public String getHeader(String name) {
        return Joiner.on(", ").join(headers.get(name));
    }

    @Override
    public HttpVersion getProtocolVersion() {
        return this.delegate.getProtocolVersion();
    }

}
