package com.jd.ka.thor.client.proxy.saf;




/**
 * @author qiulong
 *
 */
public class VCRExecutor extends ExecutorChain {
    
    @Override
    public void execute(SAFContext context) {
        chain(context);
    }

}
