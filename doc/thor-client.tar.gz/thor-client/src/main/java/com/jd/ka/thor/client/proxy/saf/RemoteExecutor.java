package com.jd.ka.thor.client.proxy.saf;

import java.lang.reflect.Type;

import com.jd.ka.commons.logging.Logger;
import com.jd.ka.commons.logging.LoggerFactory;
import com.jd.ka.thor.client.remote.MockResult;
import com.jd.ka.thor.client.remote.RemoteInvokerException;
import com.jd.ka.thor.common.Json;
import com.jd.service.rpc.Result;
import com.jd.service.rpc.RpcResult;

/**
 * @author qiulong
 *
 */
public class RemoteExecutor extends ExecutorChain {

    private static final Logger logger = LoggerFactory.getLogger(RemoteExecutor.class, "SAF");    

    @Override
    public void execute(SAFContext context) {
        SAFTransfer bean = new SAFTransfer(context.getThorConfig());
        bean.setGroup(context.getGroup());
        bean.setInterfaceName(context.getInterface());
        bean.setMethod(context.getMethodName());
        bean.setVersion(context.getVersion());
        bean.setParams(Json.toJson(context.getArguments()));
        Result result = null;
        try {
            MockResult mockResult = bean.invoke();
            if (mockResult.isValid() && mockResult.isSuccess()) {
                Type returnType = context.getMethod().getGenericReturnType();
                Object resultObj = Json.fromJson(mockResult.getResult(), returnType);
                if (resultObj != null) {
                    result = new RpcResult(resultObj);
                }
            }
        } catch (RemoteInvokerException e) {
            logger.error("An exception occurred while remote invocation: [interface={}, method={}]", context.getInterface(), context.getMethodName());
        }
        // direct invocation if no result return from Thor server
        if (result == null) {
            result = context.getInvoker().invoke(context.getInvocation());
        }
        context.setInvokeResult(result);

        chain(context);
    }

}
