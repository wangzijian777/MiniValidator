package com.jd.ka.thor.client.remote;

import com.google.common.collect.ImmutableMap.Builder;
import com.jd.ka.thor.client.config.ThorConfig;


/**
 * @author qiulong
 *
 */
public abstract class MockTransfer extends HttpTransfer {

    protected MockTransfer(ThorConfig config) {
        super(config);
    }

    @Override
    public String getOperation() {
        return "mock";
    }
    
    @Override
    protected final void prepareParameter(Builder<String, String> builder) {
        prepareMockParameter(builder);
        builder.put("protocol", getProtocol().code());
    }
    
    protected abstract Protocol getProtocol();
    
    protected abstract void prepareMockParameter(Builder<String, String> builder);
    
}
