package com.jd.ka.thor.client.proxy.saf;

import java.lang.reflect.Method;

import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.config.ThorConfigLoader;
import com.jd.service.common.URL;
import com.jd.service.common.utils.ReflectUtils;
import com.jd.service.rpc.Invocation;
import com.jd.service.rpc.Invoker;
import com.jd.service.rpc.Result;

/**
 * SAF服务调用的上下文环境
 * 
 * @author qiulong
 *
 */
public class SAFContext {

    private final Invoker<?> invoker;
    private final Invocation invocation;
    private Result result;
    private static ThorConfig config;

    public SAFContext(Invoker<?> invoker, Invocation invocation) {
        this.invoker = invoker;
        this.invocation = invocation;
    }

    /**
     * 获取SAF中配置的应用名称
     * 
     * @return 应用名称
     */
    public String getApplicationName() {
        return getUrl().getParameter("application");
    }

    /**
     * 获取真实的Invoker对象
     * 
     * @return Invoker对象
     */
    public Invoker<?> getInvoker() {
        return invoker;
    }

    /**
     * 获取真实的Invocation对象
     * 
     * @return Invocation对象
     */
    public Invocation getInvocation() {
        return invocation;
    }

    /**
     * 获取接口的版本号
     * 
     * @return 版本号
     */
    public String getVersion() {
        return getUrl().getParameter("version");
    }

    /**
     * 获取接口的组
     * 
     * @return
     */
    public String getGroup() {
        return getUrl().getParameter("group");
    }

    /**
     * 获取调用的方法名称
     * 
     * @return 方法名称
     */
    public String getMethodName() {
        return invocation.getMethodName();
    }

    public Method getMethod() {
        try {
            return ReflectUtils.findMethodByMethodSignature(getInvoker().getInterface(), getMethodName(), null);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * 获取接口名称
     * 
     * @return 接口名称
     */
    public String getInterface() {
        return invoker.getInterface().getName();
    }

    /**
     * 获取执行的结果
     * 
     * @return
     */
    public Result getInvokeResult() {
        return result;
    }

    /**
     * 设置执行结果
     * 
     * @param result
     */
    public void setInvokeResult(Result result) {
        this.result = result;
    }

    public ThorConfig getThorConfig() {
        if (config == null) {
            config = new ThorConfig(ThorConfigLoader.load());
        }
        return config;
    }

    public Object[] getArguments() {
        return getInvocation().getArguments();
    }

    private URL getUrl() {
        return getInvoker().getUrl();
    }

}
