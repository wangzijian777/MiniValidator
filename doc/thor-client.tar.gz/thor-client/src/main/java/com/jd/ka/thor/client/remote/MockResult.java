package com.jd.ka.thor.client.remote;

import java.io.Serializable;

/**
 * @author qiulong
 *
 */
public class MockResult implements Serializable {

    private static final long serialVersionUID = -9023531167587399845L;
    private boolean valid;
    private String result;
    private boolean success;

    public boolean isValid() {
        return valid;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getResult() {
        return result;
    }

}
