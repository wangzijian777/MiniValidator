package com.jd.ka.thor.client.proxy.message;

import java.util.Map;

import com.google.common.io.ByteSource;
import com.google.common.io.CharSource;

/**
 * @author qiulong
 *
 */
public interface HttpMessage {

    /**
     * @return all HTTP headers attached to this message.
     */
    Map<String, String> getHeaders();
    
    /**
     * @param name an HTTP header name.
     * @return the comma-separated values for all HTTP headers with the specified name or `null` if there are no headers
     * with that name.
     */
    String getHeader(String name);

    /**
     * Returns the message body as a string.
     *
     * @return the message body as a string.
     * @throws IllegalStateException if the message does not have a body.
     */
    CharSource getBodyAsText();

    /**
     * Returns the decoded message body. If the implementation stores the
     * message body in an encoded form (e.g. gzipped) then it <em>must</em> be
     * decoded before being returned by this method
     *
     * @return the message body as binary data.
     * @throws IllegalStateException if the message does not have a body.
     */
    ByteSource getBodyAsBinary();

    /**
     * @return the charset of the message if it is text.
     */
    String getCharset();

    /**
     * @return the content encoding of the message, e.g. _gzip_, _deflate_ or  _none_.
     */
    String getEncoding();

    /**
     * @return the MIME content type of the message not including any charset.
     */
    String getContentType();
    
    /**
     * @return `true` if the message currently contains a body, `false` otherwise.
     */
    boolean hasBody();

}
