package com.jd.ka.thor.client.spring;

import org.springframework.context.ApplicationContext;


/**
 * @author qiulong
 *
 */
public class ApplicationContextHolder {
    
    private static ApplicationContext context;
    
    public static void init(ApplicationContext context) {
        ApplicationContextHolder.context = context; 
    }
    
    public static <T> T getBean(String beanName, Class<T> clazz) {
        T bean = context.getBean(beanName, clazz);
        if (bean == null) {
            throw new UnsupportedOperationException(String.format("bean [%s] not found", beanName));
        }
        return bean;
    }
    
    public static Object getBean(String beanName) {
        Object bean = context.getBean(beanName);
        if(bean == null) {
            throw new UnsupportedOperationException(String.format("bean [%s] not found", beanName));
        }
        return bean;
    }
}
