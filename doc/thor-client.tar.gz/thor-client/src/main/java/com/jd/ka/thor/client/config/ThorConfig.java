package com.jd.ka.thor.client.config;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collection;

import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSet.Builder;
import com.jd.ka.thor.common.Network;
import com.jd.ka.thor.common.settings.Settings;

/**
 * @author qiulong
 *
 */
public final class ThorConfig {

    public static final String THOR_APP_NAME = "thor.app.name";
    public static final String THOR_DEBUG = "thor.debug";
    public static final String THOR_PROXY_HOST = "thor.proxy.host";
    public static final String THOR_PROXY_PORT = "thor.proxy.port";
    public static final String THOR_PROXY_IGNOREHOSTS = "thor.proxy.ignoreHosts";
    public static final String THOR_PROXY_TIMEOUT = "thor.proxy.timeout";
    public static final String THOR_PROXY_BUFFERSIZE = "thor.proxy.buffersize";
    public static final String THOR_SERVER_HOST = "thor.server.host";
    public static final String THOR_SERVER_PORT = "thor.server.port";

    private static final String DEFAULT_PROXY_HOST = "0.0.0.0";
    private static final int DEFAULT_PROXY_PORT = 9000;
    private static final int DEFAULT_PROXY_TIMEOUT = 5;
    private static final int DEFAULT_PROXY_BUFFERSIZE = 8388608; // 8M
    public static final int DEFAULT_SERVER_PORT = 80;
    public static final String DEFAULT_SERVER_HOST = "thor.ka.jd.com";
    private final Settings settings;

    public ThorConfig(Settings settings) {
        if (settings == null) {
            throw new IllegalArgumentException("Settings cannot be null");
        }
        this.settings = settings;
    }

    public int getProxyPort() {
        return settings.getInteger(THOR_PROXY_PORT, DEFAULT_PROXY_PORT);
    }

    public int getServerPort() {
        return settings.getInteger(THOR_SERVER_PORT, DEFAULT_SERVER_PORT);
    }

    public String getServerHost() {
        return settings.get(THOR_SERVER_HOST, DEFAULT_SERVER_HOST);
    }

    public boolean isSslEnabled() {
        // TODO future support
        return false;
    }

    public int getProxyTimeoutSeconds() {
        return settings.getInteger(THOR_PROXY_TIMEOUT, DEFAULT_PROXY_TIMEOUT);
    }

    public int getRequestBufferSize() {
        return settings.getInteger(THOR_PROXY_BUFFERSIZE, DEFAULT_PROXY_BUFFERSIZE);
    }

    public Collection<String> getIgnoreHosts() {
        String ignoreHosts = settings.get(THOR_PROXY_IGNOREHOSTS);
        Builder<String> builder = new ImmutableSet.Builder<String>().addAll(Network.getLocalAddresses());
        if (ignoreHosts != null) {
            builder.addAll(Splitter.on(',').split(ignoreHosts));
        }
        return builder.build();
    }

    public InetAddress getProxyHost() {
        String proxyHost = settings.get(THOR_PROXY_HOST, DEFAULT_PROXY_HOST);
        try {
            return InetAddress.getByName(proxyHost);
        } catch (UnknownHostException e) {
            throw new IllegalArgumentException(String.format("Unable to resolve host %s", proxyHost), e);
        }
    }

    public String getAppName() {
        String appName = settings.get(THOR_APP_NAME);
        if (appName == null || appName.isEmpty()) {
            throw new IllegalArgumentException(String.format("[%s] cannot be null or empty", THOR_APP_NAME));
        }
        return appName;
    }
    
    public boolean debug() {
        return settings.getBoolean(THOR_DEBUG, false);
    }

}
