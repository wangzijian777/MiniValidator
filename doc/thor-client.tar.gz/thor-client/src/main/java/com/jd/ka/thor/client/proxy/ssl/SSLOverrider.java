package com.jd.ka.thor.client.proxy.ssl;

import java.security.Security;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

/**
 * @author qiulong
 *
 */
public class SSLOverrider {

    public static final String SSL_SOCKET_FACTORY_PROVIDER = "ssl.SocketFactory.provider";
    public static final HostnameVerifier ALLOW_ALL_HOSTNAME_VERIFIER = new HostnameVerifier() {
        @Override public boolean verify(String s, SSLSession sslSession) {
            return true;
        }
    };
    private boolean isActive;
    private String originalSocketFactoryProvider;
    private HostnameVerifier originalHostnameVerifier;

    public void activate() {
        if (!isActive) {
            originalSocketFactoryProvider = Security.getProperty(SSL_SOCKET_FACTORY_PROVIDER);
            originalHostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier();
            Security.setProperty(SSL_SOCKET_FACTORY_PROVIDER, DummyJVMSSLSocketFactory.class.getName());
            HttpsURLConnection.setDefaultHostnameVerifier(ALLOW_ALL_HOSTNAME_VERIFIER);
        }
        isActive = true;
    }

    public void deactivate() {
        if (isActive) {
            Security.setProperty(SSL_SOCKET_FACTORY_PROVIDER,
                    originalSocketFactoryProvider != null ? originalSocketFactoryProvider : "");
            HttpsURLConnection.setDefaultHostnameVerifier(originalHostnameVerifier);
        }
        isActive = false;
    }
}
