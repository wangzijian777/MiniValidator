package com.jd.ka.thor.client.proxy;

import com.jd.ka.thor.client.config.ThorConfig;

/**
 * @author qiulong
 *
 */
public class ProxyServerBootstrap {

    private ProxyServer proxyServer = new ThorProxyServer();

    public void start(ThorConfig config) {
        if (!proxyServer.isRunning()) {
            proxyServer.start(config);
        }
    }

    public void stop() {
        if (proxyServer.isRunning()) {
            proxyServer.stop();
        }
    }
    
}
