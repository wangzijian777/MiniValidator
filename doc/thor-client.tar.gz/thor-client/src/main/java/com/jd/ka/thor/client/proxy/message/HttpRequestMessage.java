package com.jd.ka.thor.client.proxy.message;

import java.net.URI;


/**
 * @author qiulong
 *
 */
public interface HttpRequestMessage extends HttpMessage {
    
    /**
     * @return the target URI of the request.
     */
    URI getUri();
    
    /**
     * @return return the HTTP request Method
     */
    String getMethod();

}
