package com.jd.ka.thor.client.remote;

import java.io.IOException;

/**
 * @author qiulong
 *
 */
public class RemoteInvokerException extends IOException {

    private static final long serialVersionUID = -1837243279418192407L;

    public RemoteInvokerException() {
        super();
    }

    public RemoteInvokerException(String message, Throwable cause) {
        super(message, cause);
    }

    public RemoteInvokerException(String message) {
        super(message);
    }

    public RemoteInvokerException(Throwable cause) {
        super(cause);
    }

}
