package com.jd.ka.thor.client.proxy;

import static org.littleshoot.proxy.ChainedProxyAdapter.FALLBACK_TO_DIRECT_CONNECTION;
import io.netty.handler.codec.http.HttpRequest;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.util.Collection;
import java.util.Map;
import java.util.Queue;

import org.littleshoot.proxy.ChainedProxy;
import org.littleshoot.proxy.ChainedProxyAdapter;
import org.littleshoot.proxy.ChainedProxyManager;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

/**
 * @author qiulong
 *
 */
public class ProxyOverrider implements ChainedProxyManager {

    private final Map<String, InetSocketAddress> originalProxies = Maps.newLinkedHashMap();
    private final Collection<String> originalNonProxyHosts = Sets.newHashSet();

    /**
     * Activates a proxy override for the given URI scheme.
     */
    public void activate(InetAddress host, int port, Collection<String> nonProxyHosts) {
        for (String scheme : new String[] { "http", "https" }) {
            String currentProxyHost = System.getProperty(scheme + ".proxyHost");
            String currentProxyPort = System.getProperty(scheme + ".proxyPort");
            if (currentProxyHost != null) {
                originalProxies.put(scheme, new InetSocketAddress(currentProxyHost, Integer.parseInt(currentProxyPort)));
            }
            System.setProperty(scheme + ".proxyHost", new InetSocketAddress(host, port).getAddress().getHostAddress());
            System.setProperty(scheme + ".proxyPort", Integer.toString(port));
        }

        String currentNonProxyHosts = System.getProperty("http.nonProxyHosts");
        if (currentNonProxyHosts == null) {
            originalNonProxyHosts.clear();
        } else {
            for (String nonProxyHost : Splitter.on('|').split(currentNonProxyHosts)) {
                originalNonProxyHosts.add(nonProxyHost);
            }
        }
        System.setProperty("http.nonProxyHosts", Joiner.on('|').join(nonProxyHosts));
    }

    /**
     * Deactivates all proxy overrides restoring the pre-existing proxy settings
     * if any.
     */
    public void deactivateAll() {
        for (String scheme : new String[] { "http", "https" }) {
            InetSocketAddress originalProxy = originalProxies.remove(scheme);
            if (originalProxy != null) {
                System.setProperty(scheme + ".proxyHost", originalProxy.getHostName());
                System.setProperty(scheme + ".proxyPort", Integer.toString(originalProxy.getPort()));
            } else {
                System.clearProperty(scheme + ".proxyHost");
                System.clearProperty(scheme + ".proxyPort");
            }
        }

        if (originalNonProxyHosts.isEmpty()) {
            System.clearProperty("http.nonProxyHosts");
        } else {
            System.setProperty("http.nonProxyHosts", Joiner.on('|').join(originalNonProxyHosts));
        }
        originalNonProxyHosts.clear();
    }

    @Override
    public void lookupChainedProxies(HttpRequest request, Queue<ChainedProxy> chainedProxies) {
        final InetSocketAddress originalProxy = originalProxies.get(URI.create(request.getUri()).getScheme());
        if (originalProxy != null) {
            ChainedProxy chainProxy = new ChainedProxyAdapter() {
                @Override public InetSocketAddress getChainedProxyAddress() {
                    return originalProxy;
                }
            };
            chainedProxies.add(chainProxy);
        }
        // use direct connection
        chainedProxies.add(FALLBACK_TO_DIRECT_CONNECTION);
    }

}
