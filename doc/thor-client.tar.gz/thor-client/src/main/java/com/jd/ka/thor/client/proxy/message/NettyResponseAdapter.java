package com.jd.ka.thor.client.proxy.message;

import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpObject;
import io.netty.handler.codec.http.HttpResponse;
import io.netty.handler.codec.http.HttpVersion;

/**
 * @author qiulong
 *
 */
public class NettyResponseAdapter extends NettyMessageAdapter<HttpResponse> implements HttpResponseMessage {

    public static NettyResponseAdapter wrap(HttpObject message) {
        if (message instanceof HttpResponse) {
            return new NettyResponseAdapter((HttpResponse) message);
        } else {
            throw new IllegalArgumentException(String.format("%s is not an instance of %s", message.getClass()
                    .getName(), FullHttpResponse.class.getName()));
        }
    }

    NettyResponseAdapter(HttpResponse delegate) {
        super(delegate);
    }

    @Override
    public int getStatus() {
        return delegate.getStatus().code();
    }

    @Override
    public HttpVersion getProtocolVersion() {
        return delegate.getProtocolVersion();
    }

}
