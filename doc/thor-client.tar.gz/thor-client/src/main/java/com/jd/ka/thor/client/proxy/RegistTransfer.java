package com.jd.ka.thor.client.proxy;

import com.google.common.collect.ImmutableMap.Builder;
import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.remote.HttpTransfer;
import com.jd.ka.thor.common.Network;

/**
 * @author qiulong
 *
 */
public abstract class RegistTransfer extends HttpTransfer {

    protected RegistTransfer(ThorConfig config) {
        super(config);
    }

    public String getIp() {
        return Network.getLocalIPAddress().getHostAddress();
    }

    public int getPort() {
        return config.getProxyPort();
    }
    
    @Override
    protected void prepareParameter(Builder<String, String> builder) {
        builder.put("ip", getIp()).put("port", String.valueOf(getPort()));
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("[ip=").append(getIp()).append(", port=").append(getPort()).append("]");
        return builder.toString();
    }

}
