package com.jd.ka.thor.client.saf;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.catagory.pbim.pbia.dubbo.model.bigfield.ProductBigField;
import com.jd.catagory.pbim.pbia.dubbo.service.ProductService;

/**
 * @author qiulong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath:spring-config.xml" })
public class TestProductService {

    @Autowired
    private ProductService productService;

    @Test
    public void test_queryBigField() {
        ArrayList<String> list = new ArrayList<String>();
        list.add("wareQD");
        list.add("propCode");
        list.add("wdis");
        ProductBigField queryBigField = productService.queryBigField("107702", list);
        Assert.assertNotNull(queryBigField);
    }

}
