package com.jd.ka.thor.client.ws;

import java.io.IOException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author qiulong
 *
 */
public class WSClient {

    private static final QName SERVICE_NAME = new QName("http://ws.client.thor.ka.jd.com/", "HelloWorld");
    private static final QName PORT_NAME = new QName("http://ws.client.thor.ka.jd.com/", "HelloWorldPort");

    @BeforeClass
    public static void before() {
        WSServer.start();
    }

    @AfterClass
    public static void after() {
        WSServer.stop();
    }

    @Test
    public void test() throws IOException {
        String endpointAddress = String.format("http://%s:%d/helloWorld", WSServer.host, WSServer.port);
        Service service = Service.create(new URL(endpointAddress), SERVICE_NAME);
        HelloWorld hw = service.getPort(PORT_NAME, HelloWorld.class);
        String sayHi = hw.sayHi("Jack");
        System.out.println(sayHi);
    }

}
