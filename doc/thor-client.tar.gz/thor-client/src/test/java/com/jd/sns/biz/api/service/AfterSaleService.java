package com.jd.sns.biz.api.service;


/**
 * @author qiulong
 *
 */
public interface AfterSaleService {
    String test(String test);
}
