package com.jd.ka.thor.client.ws;

import javax.jws.WebParam;
import javax.jws.WebService;


/**
 * @author qiulong
 *
 */
@WebService
public interface HelloWorld {
    String sayHi(@WebParam(name="text") String text);
}
