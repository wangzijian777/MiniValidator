package com.jd.ka.thor.client.ws;

import java.util.concurrent.CountDownLatch;

import javax.xml.ws.Endpoint;

import com.jd.ka.thor.common.Network;

/**
 * @author qiulong
 *
 */
public class WSServer {
    public static int port = 8888;
    public static String host = Network.getLocalIPAddress().getHostAddress();
    
    private static CountDownLatch latch = new CountDownLatch(1);

    public static void start() {
        System.out.println("Starting Server");
        HelloWorld implementor = new HelloWorldImpl();
        String address = String.format("http://%s:%d/helloWorld", host, port);
        Endpoint.publish(address, implementor);
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override public void run() {
                try {
                    latch.await();
                } catch (InterruptedException ignore) {
                }
            }
        });
    }
    
    public static void stop() {
        latch.countDown();
    }

}
