package com.jd.ka.thor.client;

import java.io.IOException;
import java.net.URL;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.jd.ka.thor.common.Network;
import com.jd.ka.thor.common.http.HttpUtils;


/**
 * @author qiulong
 *
 */
public class RemoteMockTest extends ProxyServerBootstrapTest {
    private MockThorServer mockThorServer;
    private int port = 9001;
    
    @Before
    public void startMockServer() {
        mockThorServer = new MockThorServer(port, "/mock");
        mockThorServer.start();
    }
    
    @After
    public void stopMockServer() {
        mockThorServer.stop();
    }

    @Test
    public void test_withProxy() throws IOException {
        String rs = HttpUtils.doPost(new URL("http://www.baidu.com"), null);
        System.out.println(rs);
    }
    
    @Test
    public void test_withoutProxy() throws IOException {
        String rs = HttpUtils.doPost(new URL("http://localhost:" + port + "/mock"), null);
        System.out.println(rs);
    }
    
    @Test
    public void test_remoteCallLocal() throws IOException {
        String hostAddress = Network.getLocalIPAddress().getHostAddress();
        String rs = HttpUtils.doPost(new URL("http://" + hostAddress + ":" + port + "/mock"), null);
        System.out.println(rs);
    }

}
