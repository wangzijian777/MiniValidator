package com.jd.ka.thor.client.saf;

import java.io.IOException;
import java.net.URL;
import java.util.Map;

import org.junit.Test;

import com.google.common.collect.Maps;
import com.jd.ka.thor.client.BaseLocalCall;
import com.jd.ka.thor.common.Network;
import com.jd.ka.thor.common.encoding.B64Code;
import com.jd.ka.thor.common.http.HttpUtils;


/**
 * @author qiulong
 *
 */
public class CallSAFTest extends BaseLocalCall {

    @Test
    public void test_call_saf() throws IOException {
        String hostAddress = Network.getLocalIPAddress().getHostAddress();
        Map<String, String> header = Maps.newHashMap();
        header.put("X-Thor", "call");
        String body = "{\"beanName\":\"safTest\",\"methodName\":\"test\",\"params\":[\"test\"]}";
        body = B64Code.encode(body);
        String rs = HttpUtils.doPost(new URL("http://" + hostAddress + ":9000"), body, header);
        rs = B64Code.decode(rs, "UTF-8");
        System.out.println(rs);
    }

}
