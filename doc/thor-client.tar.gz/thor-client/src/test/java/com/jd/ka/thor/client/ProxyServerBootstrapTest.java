package com.jd.ka.thor.client;

import java.util.concurrent.CountDownLatch;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.jd.ka.thor.client.config.ThorConfig;
import com.jd.ka.thor.client.config.ThorConfigLoader;
import com.jd.ka.thor.client.proxy.ProxyServerBootstrap;


public class ProxyServerBootstrapTest {
    private CountDownLatch latch = new CountDownLatch(1);
    
    @Before
    public void startProxy() {
        final ProxyServerBootstrap bootstrap = new ProxyServerBootstrap();
        ThorConfig config = new ThorConfig(ThorConfigLoader.load());
        bootstrap.start(config);
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override public void run() {
                try {
                    latch.await();
                    bootstrap.stop();
                } catch (InterruptedException ignore) {}
            }
        });
    }
    
    @After
    public void stopProxy() {
        latch.countDown();
    }
    
    @Test
    public void test_startProxy() {
        try {
            Thread.sleep(30000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
}
