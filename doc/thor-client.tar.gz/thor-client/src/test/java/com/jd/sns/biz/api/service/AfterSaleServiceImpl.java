package com.jd.sns.biz.api.service;


/**
 * @author qiulong
 *
 */
public class AfterSaleServiceImpl implements AfterSaleService {

    @Override
    public String test(String arg) {
        return "hello " + arg;
    }

}
