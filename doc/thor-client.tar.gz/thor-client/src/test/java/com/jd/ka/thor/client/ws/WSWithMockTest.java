package com.jd.ka.thor.client.ws;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.jd.ka.thor.client.RemoteMockTest;


/**
 * @author qiulong
 *
 */
public class WSWithMockTest extends RemoteMockTest {
    
    @BeforeClass
    public static void start() {
        WSClient.before();
    }
    
    @AfterClass
    public static void stop() {
        WSClient.after();
    }

    @Test
    public void test() throws IOException {
        new WSClient().test();
    }

}
