package com.jd.ka.thor.client.saf;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.ka.thor.client.RemoteMockTest;
import com.jd.primitive.client.address.bean.AreaListBeanVO;
import com.jd.primitive.client.address.result.GetAreaListResultVO;
import com.jd.primitive.client.address.service.AreaService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath:spring-config.xml" })
public class TestAreaService extends RemoteMockTest {

    @Autowired
    private AreaService areaService;

    /**
     * 获取地址接口挡板测试
     */
    @Test
    public void test_getProvinces() {
        GetAreaListResultVO provinces = areaService.getProvinces();
        Assert.assertNotNull(provinces);
    }

    @Test
    public void test_getCitys() {
        GetAreaListResultVO citys = areaService.getCitys(22);
        List<AreaListBeanVO> areaList = citys.getAreaList();
        Assert.assertNotNull(areaList);
        for (AreaListBeanVO areaListBeanVO : areaList) {
            Assert.assertNotNull(areaListBeanVO);
        }
    }

    @Test
    public void test_getTowns() {
        GetAreaListResultVO citys = areaService.getTowns(1960);
        List<AreaListBeanVO> areaList = citys.getAreaList();
        Assert.assertNotNull(areaList);
        for (AreaListBeanVO areaListBeanVO : areaList) {
            Assert.assertNotNull(areaListBeanVO);
        }
    }

}
