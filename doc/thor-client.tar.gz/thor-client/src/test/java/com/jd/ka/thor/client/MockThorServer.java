package com.jd.ka.thor.client;

import static com.google.common.base.Charsets.UTF_8;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.base64.Base64;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * @author qiulong
 *
 */
public class MockThorServer implements HttpHandler {

    private HttpServer httpServer;

    public MockThorServer(int port) {
        this(port, "/");
    }

    public MockThorServer(int port, String context) {
        try {
            httpServer = HttpServer.create(new InetSocketAddress(port), 0);
            httpServer.createContext(context, this);
        } catch (IOException e) {}
    }

    public void start() {
        httpServer.start();
    }

    public void stop() {
        httpServer.stop(0);
    }

    public void createContext(String path, HttpHandler handler) {
        this.httpServer.createContext(path, handler);
    }

    @Override
    public void handle(HttpExchange args) {
        handleByDefault(args);
    }

    private void handleByDefault(HttpExchange args) {
        InputStream in = null;
        boolean success = false;
        try {
            in = args.getRequestBody();
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int len = -1;
                while ((len = in.read(buffer)) > -1) {
                    out.write(buffer, 0, len);
                }
                success = true;
                String str = Base64.decode(Unpooled.wrappedBuffer(out.toByteArray())).toString(UTF_8);
                System.out.println("=============== server print ================");
                System.out.println("server print: " + str);
                System.out.println("=========================================");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {}
            }
        }

        if (success) {
            OutputStream out = null;
            byte[] outMessage = "success".getBytes();
            try {
                args.sendResponseHeaders(200, outMessage.length);
                out = args.getResponseBody();
                out.write(outMessage);
                out.flush();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException e) {}
                }
            }
        }
    }

}
