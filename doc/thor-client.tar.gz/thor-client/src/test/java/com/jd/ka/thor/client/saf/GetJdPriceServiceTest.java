package com.jd.ka.thor.client.saf;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.ka.price.soa.sdk.service.GetJdPriceService;
import com.jd.ka.price.soa.sdk.vo.request.QRTPriceReqVO;
import com.jd.ka.price.soa.sdk.vo.response.QRTPriceRespVO;

/**
 * @author qiulong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath:spring-config.xml" })
public class GetJdPriceServiceTest {

    @Autowired
    private GetJdPriceService priceService;

    @Test
    public void test_getJdPrice() {
        QRTPriceReqVO req = new QRTPriceReqVO();
        req.setPin("vxp_test");
        req.setSkuId(107702L);
        QRTPriceRespVO model = priceService.getJdPrice(req).getModel();
        Assert.assertNotNull(model);
    }

}
