package com.jd.ka.thor.client.ws;

import javax.jws.WebService;


/**
 * @author qiulong
 *
 */
@WebService(endpointInterface = "com.jd.ka.thor.client.ws.HelloWorld", serviceName = "HelloWorld", portName="HelloWorldPort")
public class HelloWorldImpl implements HelloWorld {

    @Override
    public String sayHi(String text) {
        System.out.println("sayHi called");
        return "Hello " + text;
    }

}
