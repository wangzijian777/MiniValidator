package com.jd.ka.thor.client.http;

import java.io.IOException;
import java.net.URL;

import org.junit.Test;

import com.jd.ka.thor.client.ProxyServerBootstrapTest;
import com.jd.ka.thor.common.http.HttpUtils;


/**
 * @author qiulong
 *
 */
public class HttpProxyTest extends ProxyServerBootstrapTest {

    @Test
    public void test_proxy() throws IOException {
        String rs = HttpUtils.doPost(new URL("http://www.baidu.com"), null);
        System.out.println(rs);
    }
    
    @Test
    public void test_local() throws IOException {
        String rs = HttpUtils.doPost(new URL("http://localhost:9000"), null);
        System.out.println(rs);
    }
    
}
