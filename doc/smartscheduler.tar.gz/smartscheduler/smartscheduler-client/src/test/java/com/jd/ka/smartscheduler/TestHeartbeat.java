package com.jd.ka.smartscheduler;

import java.util.HashMap;

import com.jd.ka.smartscheduler.courier.heartbeat.Heartbeat;
import com.jd.ka.smartscheduler.courier.heartbeat.HeartbeatListener;
import com.jd.ka.smartscheduler.courier.heartbeat.HttpHeartbeatHandler;

/**
 * 心跳测试
 * @author qiulong
 *
 */
public class TestHeartbeat extends BaseTestCase {
	
	public TestHeartbeat() {
		super(false);
	}

	public void testHeartbeat() {
		final Heartbeat heartbeat = new Heartbeat(new HttpHeartbeatHandler(new String[]{"http://localhost:8080/smartscheduler-web"}), 5);
		heartbeat.start(new HeartbeatListener() {
			@Override
			public void onSuccess() {
				System.out.println("heart beat success");
			}

			@Override
			public void onFailure() {
				System.out.println("heart beat failure");
			}
		});
		try {
			Thread.sleep(10000000L);
		} catch (InterruptedException e) {
			e.printStackTrace();
		};
	}
	
	@Override
	protected void prepareRequestParams(HashMap<String, Object> requestParams) {
	}

}
