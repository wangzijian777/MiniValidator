package com.jd.ka.smartscheduler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import junit.framework.Assert;

import com.jd.ka.smartscheduler.common.utils.GZIPUtil;
import com.jd.ka.smartscheduler.executor.JobShardingExecutor;
import com.jd.ka.smartscheduler.executor.ModShardStrategy;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;

/**
 * 
 * @author qiulong
 *
 */
public class TestJobShardingExecutor extends BaseTestCase {
	
	public void testJobShardingExecutor() throws IOException {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		Client.execute(new JobShardingExecutorCase(), this.getParameter(), os);
		try {
			Thread.sleep(5000L);
		} catch (InterruptedException e) {}
		byte[] ungizp = GZIPUtil.ungizp(os.toByteArray());
		System.out.println(new String(ungizp));
	}
	
	@Override
	protected void prepareRequestParams(HashMap<String, Object> requestParams) {
		requestParams.put("threadNum", "4");
		requestParams.put("divisor", "3");
		requestParams.put("mod", "0");
		requestParams.put("limit", "10");
		requestParams.put("distributed", "true");
	}

	private class JobShardingExecutorCase implements JobShardingExecutor<Long> {
		private List<Long> simulateDatas = new ArrayList<Long>();
		private int lastIndex = 0;
		
		public JobShardingExecutorCase() {
			for(long i=0; i<100; i++) {
				simulateDatas.add(i);
			}
		}
		
		@Override
		public List<Long> shard(Job job, ModShardStrategy shardStrategy) {
			int divisor = shardStrategy.divisor();
			int[] mod = shardStrategy.mod();
			int limit = shardStrategy.limit();
			
			Assert.assertEquals(divisor, 3);
			Assert.assertEquals(mod, 0);
			Assert.assertEquals(limit, 10);
			
			List<Long> list = new ArrayList<Long>();
			int index = 0;
			int size = simulateDatas.size();
			for (int i=lastIndex; i<size; lastIndex = ++i) {
				//每次取limit数量的数据
				if(index > limit) {
					break;
				}
				Long data = simulateDatas.get(i);
				index ++;
				if(data % divisor == mod[0]) {
					list.add(data);
				}
			}
			return list;
		}

		@Override
		public int execute(Job job, Reporter reporter, Iterator<Long> shards) {
			String name = Thread.currentThread().getName();
			int size = 0;
			while(shards.hasNext()) {
				System.out.println(name + " id = " + shards.next());
				size ++;
			}
			return size;
		}
		
	}

}
