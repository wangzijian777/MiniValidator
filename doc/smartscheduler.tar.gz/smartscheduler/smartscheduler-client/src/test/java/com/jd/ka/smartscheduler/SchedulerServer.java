package com.jd.ka.smartscheduler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * 
 * @author qiulong
 *
 */
public class SchedulerServer implements HttpHandler {
	private HttpServer httpServer;

	public interface RequestHandler {
		void handle(HttpExchange args);
	}
	
	public SchedulerServer(int port) {
		this(port, "/");
	}
	
	public SchedulerServer(int port, String context) {
		try {
			httpServer = HttpServer.create(new InetSocketAddress(port), 0);
			httpServer.createContext(context, this);
		} catch (IOException e) {
		}
	}

	public void start() {
		httpServer.start();
	}

	public void stop() {
		httpServer.stop(0);
	}
	
	public void createContext(String path, HttpHandler handler) {
		this.httpServer.createContext(path, handler);
	}

	@Override
	public void handle(HttpExchange args) {
		handleByDefault(args);
	}

	private void handleByDefault(HttpExchange args) {
		InputStream in = null;
		boolean success = false;
		try {
			in = args.getRequestBody();
			try {
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				byte[] buffer = new byte[1024];
				int len = -1;
				while ((len = in.read(buffer)) > -1) {
					out.write(buffer, 0, len);
				}
				success = true;
				System.out.println("server print: "
						+ new String(out.toByteArray()));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
				}
			}
		}

		if (success) {
			OutputStream out = null;
			byte[] outMessage = "success".getBytes();
			try {
				args.sendResponseHeaders(200, outMessage.length);
				out = args.getResponseBody();
				out.write(outMessage);
				out.flush();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (out != null) {
					try {
						out.close();
					} catch (IOException e) {
					}
				}
			}
		}
	}

}
