package com.jd.ka.smartscheduler;

import java.util.HashMap;

import junit.framework.TestCase;

import com.jd.ka.smartscheduler.common.utils.MessageFormat;
import com.jd.ka.smartscheduler.data.Parameter;

/**
 * 
 * @author qiulong
 *
 */
public abstract class BaseTestCase extends TestCase {
	private SchedulerServer server;
	private int serverPort = 8088;
	private boolean useDefaultServer;

	public BaseTestCase() {
		this(true);
	}
	
	public BaseTestCase(boolean useDefaultServer) {
		super();
		this.useDefaultServer = useDefaultServer;
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		if(useDefaultServer) {
			initServer();
		}
	}
	
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		if(useDefaultServer) {
			this.server.stop();
		}
	}
	
	protected abstract void prepareRequestParams(HashMap<String, Object> requestParams);
	
	protected Parameter getParameter() {
		return new Parameter(initData());
	}
	
	private HashMap<String, Object> initData() {
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("id", "testjob");
		data.put("url", MessageFormat.format("http://localhost:{}/{}", serverPort, "report"));
		data.put("token", "123");
		data.put("serialnum", String.valueOf(System.currentTimeMillis()));
		data.put("nodeName", "node-1");
		prepareRequestParams(data);
		return data;
	}
	
	private void initServer() {
		this.server = new SchedulerServer(8088, "report");
		this.server.start();
	}
	
}
