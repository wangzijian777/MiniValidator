package com.jd.ka.smartscheduler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.executor.JobShardingExecutor;
import com.jd.ka.smartscheduler.executor.ModShardStrategy;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

/**
 * 
 * @author qiulong
 *
 */
public class TestConnectWithServer extends TestCase {
	private JobShardingExecutor<Long> executor = new JobShardingExecutorCase();
	private SchedulerServer server;
	
	public void testConnectToServer() {
		try {
			Thread.sleep(100000000L);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		this.server = new SchedulerServer(8088);
		this.server.createContext("/smartscheduler-client-test/test", new HttpHandlerCase());
		this.server.start();
	}

	private class HttpHandlerCase implements HttpHandler {

		@Override
		public void handle(HttpExchange args) {
			InputStream in = args.getRequestBody();
			OutputStream out = args.getResponseBody();
			PrintWriter writer = null;
			try {
				Headers requestHeaders = args.getRequestHeaders();
				Map<String, String> parameterMap = getParameterMap(in);
				writer = new PrintWriter(new OutputStreamWriter(out));
	            writer.println("GET / HTTP/1.1");
	            writer.println("Host: " + requestHeaders.get("Host"));
	            writer.println("Accept: */*");
	            writer.println("User-Agent: Java"); // Be honest.
	            writer.println(""); // Important, else the server will expect that there's more into the request.
	            Parameter parameter = new Parameter();
	            parameter.putAll(parameterMap);
				Client.execute(executor, parameter, out);
				writer.flush();
			} catch(Exception e) {
				e.printStackTrace();
			} finally {
				if(writer != null) {
					writer.close();
				}
			}
		}
		
		private Map<String, String> getParameterMap(InputStream in) {
			Map<String, String> parameters = new HashMap<String, String>();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			try {
				byte[] buffer = new byte[1024];
				int len = -1;
				while ((len = in.read(buffer)) > -1) {
					out.write(buffer, 0, len);
				}
				String str = new String(out.toByteArray());
				if(str != null) {
					String[] split = str.split("&");
					for (String p : split) {
						String[] keyValue = p.split("=", 2);
						parameters.put(keyValue[0], keyValue[1]);
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if(in != null) {
					try {
						in.close();
					} catch (IOException e) {}
				}
				if(out != null) {
					try {
						out.close();
					} catch (IOException e) {}
				}
			}
			return parameters;
		}
	}
	
	private class JobShardingExecutorCase implements JobShardingExecutor<Long> {

		@Override
		public List<Long> shard(Job job, ModShardStrategy shardStrategy) {
			return null;
		}

		@Override
		public int execute(Job job, Reporter reporter, Iterator<Long> shards) {
			return 0;
		}
		
		
	}

}
