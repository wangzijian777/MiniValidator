/**
 * 
 */
package com.jd.ka.smartscheduler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import junit.framework.Assert;

import com.jd.ka.smartscheduler.common.utils.GZIPUtil;
import com.jd.ka.smartscheduler.executor.JobShardingExecutor;
import com.jd.ka.smartscheduler.executor.ModShardStrategy;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;

/**
 * 服务存活测试
 * @author qiulong
 *
 */
public class TestAliveTestFilter extends BaseTestCase {

	public void testAliveTestFilter() {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		Client.execute(new JobShardingExecutor<Void>() {
			@Override
			public List<Void> shard(Job job, ModShardStrategy shardStrategy) {
				return null;
			}

			@Override
			public int execute(Job job, Reporter reporter, Iterator<Void> shards) {
				return 0;
			}
		}, getParameter(), os);
		try {
			Assert.assertTrue(new String(GZIPUtil.ungizp(os.toByteArray())).indexOf("\"status\":\"12\"") > -1);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void prepareRequestParams(HashMap<String, Object> requestParams) {
		requestParams.put("ping", "true");
	}

}
