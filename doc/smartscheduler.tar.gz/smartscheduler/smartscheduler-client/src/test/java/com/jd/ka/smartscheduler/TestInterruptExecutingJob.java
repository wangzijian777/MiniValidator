package com.jd.ka.smartscheduler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.jd.ka.smartscheduler.common.utils.GZIPUtil;
import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.executor.JobShardingExecutor;
import com.jd.ka.smartscheduler.executor.ModShardStrategy;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;

/**
 * 测试中断执行中的任务
 * @author qiulong
 *
 */
public class TestInterruptExecutingJob extends BaseTestCase {

	public void testInterrupt() {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		JobShardingExecutorCase jobShardingExecutorCase = new JobShardingExecutorCase();
		Client.execute(jobShardingExecutorCase, this.getParameter(), os);
		try {
			Thread.sleep(400L);
		} catch (InterruptedException e) {}
		Parameter parameter = this.getParameter();
		parameter.put("interrupt", "true");
		Client.execute(jobShardingExecutorCase, parameter, os);
		try {
			Thread.sleep(3000L);
		} catch (InterruptedException e) {}
		try {
			byte[] ungizp = GZIPUtil.ungizp(os.toByteArray());
			System.out.println(ungizp.length);
			System.out.println(new String(ungizp));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void prepareRequestParams(HashMap<String, Object> requestParams) {
		requestParams.put("threadNum", "4");
		requestParams.put("limit", "5");
	}
	
	
	private class JobShardingExecutorCase implements JobShardingExecutor<Long> {
		private List<Long> simulateDatas = new ArrayList<Long>();
		private int lastIndex = 0;
		
		public JobShardingExecutorCase() {
			for(long i=0; i<100; i++) {
				simulateDatas.add(i);
			}
		}
		
		@Override
		public List<Long> shard(Job job, ModShardStrategy shardStrategy) {
			int divisor = shardStrategy.divisor();
			int mod[] = shardStrategy.mod();
			int limit = shardStrategy.limit();
			
			List<Long> list = new ArrayList<Long>();
			int index = 0;
			int size = simulateDatas.size();
			for (int i=lastIndex; i<size; lastIndex = ++i) {
				//每次取limit数量的数据
				if(index > limit) {
					break;
				}
				Long data = simulateDatas.get(i);
				index ++;
				if(data % divisor == mod[0]) {
					list.add(data);
				}
			}
			return list;
		}

		@Override
		public int execute(Job job, Reporter reporter, Iterator<Long> shards) {
			String name = Thread.currentThread().getName();
			int i = 0;
			while(shards.hasNext()) {
				System.out.println(name + " id = " + shards.next());
				i ++;
				try {
					Thread.sleep(200L);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return i;
		}
		
	}
	
}
