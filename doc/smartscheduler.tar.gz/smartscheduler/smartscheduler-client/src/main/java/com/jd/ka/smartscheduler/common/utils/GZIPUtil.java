package com.jd.ka.smartscheduler.common.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Used for compress data by gzip
 * @author qiulong
 *
 */
public final class GZIPUtil {

	public static byte[] readCompressedByteArray(DataInput in) throws IOException {
		int length = in.readInt();
		if (length == -1)
			return null;
		byte[] buffer = new byte[length];
		in.readFully(buffer);
		GZIPInputStream gzi = new GZIPInputStream(new ByteArrayInputStream(
				buffer, 0, buffer.length));
		byte[] outbuf = new byte[length];
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		int len = -1;
		while ((len = gzi.read(outbuf, 0, outbuf.length)) != -1) {
			bos.write(outbuf, 0, len);
		}
		byte[] decompressed = bos.toByteArray();
		bos.close();
		gzi.close();
		return decompressed;
	}

	public static int writeCompressedByteArray(DataOutput out, byte[] bytes)
			throws IOException {
		if (bytes != null) {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			GZIPOutputStream gzout = new GZIPOutputStream(bos);
			gzout.write(bytes, 0, bytes.length);
			gzout.close();
			byte[] buffer = bos.toByteArray();
			int len = buffer.length;
			out.writeInt(len);
			out.write(buffer, 0, len);
			return ((bytes.length != 0) ? (100 * buffer.length) / bytes.length
					: 0);
		} else {
			out.writeInt(-1);
			return -1;
		}
	}

	public static String readCompressedString(DataInput in) throws IOException {
		byte[] bytes = readCompressedByteArray(in);
		if (bytes == null)
			return null;
		return new String(bytes, "UTF-8");
	}

	public static int writeCompressedString(DataOutput out, String s)
			throws IOException {
		return writeCompressedByteArray(out, (s != null) ? s.getBytes("UTF-8")
				: null);
	}

	public static byte[] gzip(byte[] bytes) throws IOException {
		ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
		GZIPOutputStream gzippedOut = new GZIPOutputStream(bytesOut);
		gzippedOut.write(bytes, 0, bytes.length);
		gzippedOut.close();
		return bytesOut.toByteArray();
	}

	public static byte[] ungizp(byte[] bytes) throws IOException {
		byte[] buffer = new byte[1024];
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ByteArrayInputStream bytesIn = new ByteArrayInputStream(bytes);
		GZIPInputStream gzin = new GZIPInputStream(bytesIn);
		int len = -1;
		while ((len = gzin.read(buffer)) > -1) {
			bos.write(buffer, 0, len);
		}
		gzin.close();
		bos.close();
		return bos.toByteArray();
	}
}
