package com.jd.ka.smartscheduler.executor;

import java.util.Iterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;

import com.jd.ka.smartscheduler.common.utils.collection.DataIterator;
import com.jd.ka.smartscheduler.common.utils.collection.ListDataIterator;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;

/**
 * 单节点多线程执行任务
 * @author qiulong
 *
 * @param <T>
 */
public class JobLocalShardingExecutorProxy<T> extends AbstractExecutorProxy<T> {
	private static final String THREAD_NAME = "local-sharding-executor-";
	
	private ExecutorService threadPool;
	private CountDownLatch threadLatch;
	private volatile boolean isShutdown;
	
	public JobLocalShardingExecutorProxy(JobShardingExecutor<T> targetExecutor) {
		super(targetExecutor);
	}

	@Override
	public int execute(Job job, Reporter reporter, Iterator<T> shards) {
		return this.getTargetExecutor().execute(job, reporter, shards);
	}

	@Override
	public void innerInterrupt() {
		isShutdown = true;
		threadPool.shutdown();
	}
	
	@Override
	protected void innerDoExecute(JobContext jobContext) {
		final int threadNum = jobContext.threadNum();
		final ModShardStrategy shardStrategy = jobContext.getShardStrategy();
		final Job job = jobContext.getJob();
		this.threadLatch = new CountDownLatch(threadNum);
		this.threadPool = new JobThreadPoolExecutor(threadNum, threadNum, 0L, TimeUnit.MILLISECONDS, 
				new SynchronousQueue<Runnable>(true), 
				this.getThreadFactory(THREAD_NAME + job.getId() + "-"));
		
		for (int i = 0; i < threadNum; i++) {
			this.threadPool.execute(new LocalMutiThreadExceutor(job, new LocalModShardStrategy(threadNum, i, shardStrategy.limit())));
		}
		
		//await all thread execute complete.
		try {
			threadLatch.await();
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}
	
	/**
	 * 按线程分片
	 * @author qiulong
	 *
	 */
	private class LocalModShardStrategy implements ModShardStrategy {
		private int divisor;
		private int[] mod;
		private int limit;
		
		LocalModShardStrategy(int divisor, int mod, int limit) {
			this.divisor = divisor;
			this.mod = new int[] {mod};
			this.limit = limit;
		}
		
		@Override
		public int divisor() {
			return this.divisor;
		}

		@Override
		public int[] mod() {
			return this.mod;
		}

		@Override
		public int limit() {
			return this.limit;
		}
		
	}
	
	private class LocalMutiThreadExceutor implements Runnable, Interruptable {
		private final Job job;
		private ModShardStrategy strategy;
		private volatile DataIterator<T> shards;
		
		public LocalMutiThreadExceutor(Job job, ModShardStrategy strategy) {
			this.job = job;
			this.strategy = strategy;
		}

		@Override
		public void run() {
			try {
				boolean hasLimit = strategy.limit() > 0;
				shards = new ListDataIterator<T>(shard(job, strategy));
				while(!isShutdown) {
					int size = shards.size();
					if(size > 0) {
						addSuccessCount(execute(job, getReporter(), shards));
						if(!hasLimit) {
							break;
						}
						shards = new ListDataIterator<T>(shard(job, strategy));
					} else {
						break;
					}
				}
			} finally {
				threadLatch.countDown();
			}
		}


		@Override
		public void interrupt() {
			//清空所有还未执行的数据
			if(shards != null) {
				shards.clear();
			}
		}
		
	}

}
