package com.jd.ka.smartscheduler.courier;

import java.util.ArrayList;
import java.util.List;

import com.jd.ka.smartscheduler.data.ACK;

/**
 * ACK信息缓存
 * @author qiulong
 *
 */
public class ACKCache {
	
	private List<ACK> cache = new ArrayList<ACK>();
	
	/**
	 * 向缓存中增加{@link ACK}
	 * @param acks
	 */
	public synchronized void add(ACK...acks) {
		for (ACK ack : acks) {
			cache.add(ack);
		}
	}
	
	/**
	 * 获取所有被缓存的{@link ACK}
	 * @return {@link ACK}列表
	 */
	public synchronized ACK[] getAll() {
		return cache.toArray(new ACK[cache.size()]);
	}
	
	/**
	 * 获取并清除所有被缓存的{@link ACK}
	 * @return {@link ACK}列表
	 */
	public synchronized ACK[] getAllAndClear() {
		ACK[] acks = cache.toArray(new ACK[cache.size()]);
		cache.clear();
		return acks;
	}
	
	/**
	 * 缓存的数据总量
	 * @return
	 */
	public synchronized int size() {
		return cache.size();
	}
}
