package com.jd.ka.smartscheduler.data;

import java.util.List;
import java.util.Map;


/**
 * 数据转换
 * 
 * @author qiulong
 * 
 */
public interface DataProvider {

	String getJsonString(JsonStringProvider... providers);
	
	List<Map<String, Object>> getMap(MapProvider... providers);

}
