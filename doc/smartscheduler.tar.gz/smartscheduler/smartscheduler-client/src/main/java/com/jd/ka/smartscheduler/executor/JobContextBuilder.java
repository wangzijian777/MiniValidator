package com.jd.ka.smartscheduler.executor;

import java.io.OutputStream;

import com.jd.ka.smartscheduler.data.Parameter;

/**
 * {@link JobContext}构建器
 * @author qiulong
 *
 */
public abstract class JobContextBuilder {
	
	public static JobContextBuilder newBuilder(ExecutionContext context, Parameter params) {
		return new DefaultJobContext.DefaultJobContextBuilder(context, params);
	}
	
	public abstract JobContext build();
	
	public abstract JobContextBuilder set(String key, String value);
	
	public abstract JobContextBuilder outputStream(OutputStream os);
	
}
