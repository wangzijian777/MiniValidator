package com.jd.ka.smartscheduler;

import java.io.OutputStream;

import com.jd.ka.smartscheduler.chain.BeforeAndAfterChain;
import com.jd.ka.smartscheduler.chain.impl.AliveAndBusyReply;
import com.jd.ka.smartscheduler.chain.impl.InterruptJob;
import com.jd.ka.smartscheduler.chain.impl.JobHeartbeat;
import com.jd.ka.smartscheduler.chain.impl.SecurityChecker;
import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.executor.ExecutionContext;
import com.jd.ka.smartscheduler.executor.JobExecutionContext;
import com.jd.ka.smartscheduler.executor.JobShardingExecutor;


/**
 * 客户端程序调用入口
 * @author qiulong
 *
 */
public class Client {
	private static final ExecutionContext context;
	
	static {
		//chain
		BeforeAndAfterChain chain = new SecurityChecker();
		AliveAndBusyReply aliveReply = new AliveAndBusyReply();
		InterruptJob suspendJob = new InterruptJob();
		JobHeartbeat jobHeartbeat = new JobHeartbeat();
		
		chain.setNextChain(aliveReply);
		aliveReply.setNextChain(suspendJob);
		suspendJob.setNextChain(jobHeartbeat);
		
		context = new JobExecutionContext(chain);
	}
	
	/**
	 * 执行指定任务
	 * @param executor 具体的任务执行实现类
	 * @param requestParameter 请求参数
	 * @param os 同步输出任务开始状态
	 */
	static public <T> void execute(JobShardingExecutor<T> executor, Parameter requestParameter, OutputStream os) {
		context.execute(executor, requestParameter, os);
	}
	
}
