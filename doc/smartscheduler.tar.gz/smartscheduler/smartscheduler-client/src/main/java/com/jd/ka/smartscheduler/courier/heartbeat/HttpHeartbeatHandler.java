package com.jd.ka.smartscheduler.courier.heartbeat;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


/**
 * 基于http的心跳检测
 * @author qiulong
 *
 */
public class HttpHeartbeatHandler implements HeartbeatHandler {
	private static final String PING = "ping";
	private static final String PONG = "pong";
	private static final String HB_URL_PATH = "hb";
	
	/**
	 * ping的地址
	 */
	private final String[] urls;
	/**
	 * ping超时时间
	 */
	private int timeout = 3000;
	/**
	 * 重试次数
	 */
	private int replycount = 2;
	
	public HttpHeartbeatHandler(String[] urls) {
		this(urls, 0, 0);
	}
	
	public HttpHeartbeatHandler(String[] urls, int timeout, int replycount) {
		this.urls = new String[urls.length];
		for (int i = 0; i < urls.length; i++) {
			String u = urls[i];
			if(u.lastIndexOf("/") == u.length()-1) {
				u += HB_URL_PATH;
			} else {
				u += ("/" + HB_URL_PATH);
			}
			this.urls[i] = u;
		}
		if(timeout > 0) {
			this.timeout = timeout;
		}
		if(replycount > 0) {
			this.replycount = replycount;
		}
	}

	@Override
	public void handle(HeartbeatListener listener) {
		final String[] urls = this.urls;
		int i = 0;
		int reply = 0;
		for(;;) {
			try {
				if(ping(urls[i])) {
					listener.onSuccess();
					break;
				}
			} catch (IOException e) {
				//如果所有URL都不通，则进行重试
				if(i+1 == urls.length) {
					i = 0;
					reply ++;
				} else {
					//如果服务不通，则更换下一个地址
					i ++;
				}
				if(reply == replycount) {
					listener.onFailure();
					break;
				}
			}
		}
	}
	
	private boolean ping(String url) throws IOException {
		try {
			HttpURLConnection conn =null;
			DataOutputStream out = null;
			BufferedReader in = null;
			try {
				conn = (HttpURLConnection)(new URL(url).openConnection());
				conn.setRequestMethod("POST");
				conn.setConnectTimeout(timeout);
				conn.setRequestProperty("Content-Type", "text/plain");
				conn.setUseCaches(false);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.connect();
				out = new DataOutputStream(conn.getOutputStream());
				out.writeBytes(PING);
				out.flush();
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				return PONG.equals(in.readLine());
			} finally {
				try {
					if(out != null) {
						out.close();
					}
					if(in != null) {
						in.close();
					}
				} catch(IOException ignore) {}
			}
		} catch (MalformedURLException e) {
			throw new IllegalArgumentException("Invalid url format ["+ url +"]", e);
		}
	}
	
}
