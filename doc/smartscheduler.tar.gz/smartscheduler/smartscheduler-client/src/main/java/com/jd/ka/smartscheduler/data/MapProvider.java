package com.jd.ka.smartscheduler.data;

import java.util.Map;

/**
 * 
 * @author qiulong
 *
 */
public interface MapProvider {
	Map<String, Object> toMap();
}
