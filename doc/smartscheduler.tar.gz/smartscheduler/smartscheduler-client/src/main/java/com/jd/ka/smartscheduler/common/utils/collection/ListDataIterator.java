package com.jd.ka.smartscheduler.common.utils.collection;

import java.util.Collections;
import java.util.List;

/**
 * List数据遍历器。在多线程环境中遍历的同时可清除List中数据（ThreadSafe）
 * @author qiulong
 *
 * @param <E>
 */
public class ListDataIterator<E> implements DataIterator<E> {

	private final List<E> datas;
	private int size;
	private int cursor;
	private int lastRet = -1;
	
	public ListDataIterator(List<E> datas) {
		if(datas == null) {
			datas = Collections.emptyList();
		}
		this.datas = datas;
		this.size = datas.size();
	}

	@Override
	public  synchronized boolean hasNext() {
		return size > 0 && cursor < size;
	}

	/**
	 * 获取下一个元素。当在调用{@link #hasNext()}后，在多线程环境中依然可能返回元素为null。
	 * @return E 集合中某个元素
	 */
	@Override
	public synchronized E next() {
		lastRet = cursor;
		if(size > 0) {
			return datas.get(cursor ++);
		}
		return null;
	}

	@Override
	public synchronized void remove() {
		if (lastRet < 0) {
            throw new IllegalStateException();
		}
		this.datas.remove(lastRet);
		if (lastRet < cursor) {
            cursor --;
		}
        lastRet = -1;
        if(size > 0) {
        	size -= 1;
        }
	}

	@Override
	public synchronized int size() {
		return this.size;
	}

	@Override
	public synchronized void clear() {
		size = 0;
		cursor = 0;
		lastRet = -1;
		datas.clear();
	}

}
