package com.jd.ka.smartscheduler.exception;

/**
 * 向远程服务器写数据异常
 * @author qiulong
 *
 */
public class WriteData2RemoteException extends Exception {
	private static final long serialVersionUID = 1L;

	public WriteData2RemoteException() {
		super();
	}

	public WriteData2RemoteException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public WriteData2RemoteException(String message, Throwable cause) {
		super(message, cause);
	}

	public WriteData2RemoteException(String message) {
		super(message);
	}

	public WriteData2RemoteException(Throwable cause) {
		super(cause);
	}
	
}
