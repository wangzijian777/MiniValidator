package com.jd.ka.smartscheduler.courier.heartbeat;

/**
 * 心跳服务接口
 * @author qiulong
 *
 */
public interface HeartbeatHandler {
	void handle(HeartbeatListener listener);
}
