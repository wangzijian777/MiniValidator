package com.jd.ka.smartscheduler.executor;

import java.io.IOException;
import java.io.OutputStream;

import com.jd.ka.smartscheduler.URLParameter;
import com.jd.ka.smartscheduler.common.gson.Gson;
import com.jd.ka.smartscheduler.courier.ACKCourier;
import com.jd.ka.smartscheduler.courier.ACKCourierImpl;
import com.jd.ka.smartscheduler.courier.DataSender;
import com.jd.ka.smartscheduler.courier.HttpDataSender;
import com.jd.ka.smartscheduler.data.ACK;
import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.job.JobBuilder;

/**
 * 
 * @author qiulong
 * 
 */
public class DefaultJobContext implements JobContext {
	private final static int[] EMPTY_MOD = new int[0];
	private final Job job;
	private final ExecutionContext context;
	private final int threadNum;
	private final String[] callbackUrl;
	private final String token;
	private final Parameter params;
	private final int nodeId;
	private final String serialNum;
	private final boolean distributed;
	private final ModShardStrategy shardStrategy;
	private final ACKCourier ackCourier;
	private OutputStream os;

	public DefaultJobContext(DefaultJobContextBuilder builder) {
		Parameter params = this.params = builder.params;
		this.job = JobBuilder.newBuilder(params).build();
		this.context = builder.context;
		this.threadNum = params.getInt(URLParameter.COMMON.THREADNUM, false);
		this.callbackUrl = params.get(URLParameter.COMMON.URL, true).split(URLParameter.COMMON.URL_SEPARATOR);
		this.token = params.get(URLParameter.COMMON.TOKEN, true);
		this.nodeId = params.getInt(URLParameter.COMMON.NODEID, true);
		this.serialNum = params.get(URLParameter.JOB.SERIALNUM, "");
		this.distributed = params.getBoolean(URLParameter.COMMON.DISTRIBUTED, false);
		this.os = builder.os;
		this.shardStrategy = buildModShardStrategy(params);
		this.ackCourier = buildACKCourier(params);
	}

	@Override
	public Job getJob() {
		return this.job;
	}

	@Override
	public ModShardStrategy getShardStrategy() {
		return this.shardStrategy;
	}

	@Override
	public int threadNum() {
		return this.threadNum == 0 ? 1 : this.threadNum;
	}

	@Override
	public String[] callbackUrl() {
		return this.callbackUrl;
	}

	@Override
	public String getToken() {
		return this.token;
	}

	@Override
	public ExecutionContext getExecutorContext() {
		return this.context;
	}
	
	@Override
	public Parameter getParameter() {
		return this.params;
	}
	
	@Override
	public boolean distributed() {
		return this.distributed;
	}
	
	@Override
	public int getNodeId() {
		return this.nodeId;
	}
	
	@Override
	public String getSerialNum() {
		return this.serialNum;
	}
	
	@Override
	public void callbackSync(ACK... acks) {
		try {
			OutputStream os = this.os;
			if(os != null) {
				this.ackCourier.callback(os, acks);
				return;
			}
		} catch (IOException e) {
			this.os = null;
			//同步回传失败则采用异步方式
			callbackAsync(acks);
		}
	}
	
	@Override
	public void callbackAsync(ACK... acks) {
		this.ackCourier.callback(this.callbackUrl(), acks);
	}
	
	private ModShardStrategy buildModShardStrategy(final Parameter params) {
		return new ModShardStrategy() {

			@Override
			public int divisor() {
				return params.getInt(DIVISOR, false);
			}

			@Override
			public int[] mod() {
				String mod = params.get(MOD, "");
				if(!mod.isEmpty()) {
					return new Gson().fromJson(mod, int[].class);
				}
				return EMPTY_MOD;
			}

			@Override
			public int limit() {
				return params.getInt(LIMIT, false);
			}
			
		};
	}
	
	private ACKCourier buildACKCourier(Parameter parameter) {
		DataSender dataSender = new HttpDataSender(
				parameter.getInt(URLParameter.CONNECT.CONNECTTIMEOUT, false), 
				parameter.getInt(URLParameter.CONNECT.READTIMEOUT, false), 
				parameter.getInt(URLParameter.CONNECT.RETRYCOUNT, false),
				parameter.getLong(URLParameter.CONNECT.RETRYINTERVAL, false));
		return new ACKCourierImpl(dataSender);
	}

	static class DefaultJobContextBuilder extends JobContextBuilder {
		private final Parameter params;
		private final ExecutionContext context;
		private OutputStream os;

		public DefaultJobContextBuilder(ExecutionContext context, Parameter params) {
			this.context = context;
			this.params = params;
		}

		@Override
		public JobContext build() {
			return new DefaultJobContext(this);
		}

		@Override
		public JobContextBuilder set(String key, String value) {
			this.params.put(key, value);
			return this;
		}

		@Override
		public JobContextBuilder outputStream(OutputStream os) {
			this.os = os;
			return this;
		}
		
	}

}
