/**
 * 
 */
package com.jd.ka.smartscheduler.chain;

import com.jd.ka.smartscheduler.executor.JobContext;

/**
 * 任务开始之前执行
 * @author qiulong
 *
 */
public abstract class BeforeAndAfterChain {
	
	private BeforeAndAfterChain nextChain;
	
	public void setNextChain(BeforeAndAfterChain nextChain) {
		this.nextChain = nextChain;
	}

	public boolean before(JobContext jobContext) {
		if(innerBefore(jobContext)) {
			if(this.nextChain != null) {
				return nextChain.before(jobContext);
			}
			return true;
		}
		return false;
	}
	
	public boolean after(JobContext jobContext) {
		if(innerAfter(jobContext)) {
			if(this.nextChain != null) {
				return this.nextChain.after(jobContext);
			}
			return true;
		}
		return false;
	}
	
	protected  abstract boolean innerBefore(JobContext jobContext);
	
	protected  abstract boolean innerAfter(JobContext jobContext);
}
