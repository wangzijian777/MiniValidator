package com.jd.ka.smartscheduler;

/**
 * URL参数名称
 * @author qiulong
 *
 */
public interface URLParameter {
	
	public interface JOB {
		public static final String ID = "id";
		public static final String SERIALNUM = "serialnum";
	}
	
	public interface COMMON {
		/**
		 * url分割符
		 */
		public final static String URL_SEPARATOR = ",";
		/**
		 * 分配的线程总数
		 */
		public final static String THREADNUM = "threadNum";
		/**
		 * 回调地址，多个地址','分割
		 */
		public final static String URL = "url";
		/**
		 * 授权码
		 */
		public final static String TOKEN = "token";
		/**
		 * 节点名称
		 */
		public static final String NODEID = "nodeId";
		/**
		 * 中断任务
		 */
		public static final String INTERRUPT = "interrupt";
		/**
		 * 服务存活检测
		 */
		public static final String PING = "ping";
		/**
		 * 是否分布式执行
		 */
		public static final String DISTRIBUTED = "distributed";
	}
	
	public interface CONNECT {
		/**
		 * 连接超时
		 */
		public final static String CONNECTTIMEOUT = "connTimeout";
		/**
		 * 等待响应超时
		 */
		public final static String READTIMEOUT = "readTimeout";
		/**
		 * 重试次数
		 */
		public final static String RETRYCOUNT = "retrycount";
		/**
		 * 重试间隔时间
		 */
		public final static String RETRYINTERVAL = "retryInterval";
	}
	
	/**
	 * 心跳配置参数
	 * @author qiulong
	 *
	 */
	public interface HEARTBEAT {
		public final static String PERIOD = "hb_period";
	}
	
}
