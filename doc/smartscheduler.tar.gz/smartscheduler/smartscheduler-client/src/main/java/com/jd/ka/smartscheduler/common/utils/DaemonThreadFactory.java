package com.jd.ka.smartscheduler.common.utils;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 
 * @author qiulong
 *
 */
public class DaemonThreadFactory implements ThreadFactory {
	private String prefix;
	private ThreadGroup group;
	private AtomicInteger threadNumber = new AtomicInteger(0);
	
	public DaemonThreadFactory(String prefix) {
		this.prefix = prefix;
		SecurityManager securityManager = System.getSecurityManager();
		this.group = (securityManager != null) ? securityManager.getThreadGroup() : Thread.currentThread().getThreadGroup();
	}

	@Override
	public Thread newThread(Runnable r) {
		Thread thread = new Thread(group, r, prefix + threadNumber.getAndIncrement(), 0);
		if (!thread.isDaemon()) {
			thread.setDaemon(true);
		}
		if (thread.getPriority() != Thread.NORM_PRIORITY) {
			thread.setPriority(Thread.NORM_PRIORITY);
		}
		return thread;
	}

}
