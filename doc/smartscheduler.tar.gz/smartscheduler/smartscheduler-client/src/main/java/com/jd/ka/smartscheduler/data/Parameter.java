package com.jd.ka.smartscheduler.data;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 入参
 * @author qiulong
 *
 */
public class Parameter implements Map<String, String> {

	private final Map<String, String> parameter = new HashMap<String, String>();
	
	public Parameter() {}

	public Parameter(Map<String, Object> parameterMap) {
		for(Iterator<String> iter = parameterMap.keySet().iterator(); iter.hasNext();) {
			String key = iter.next();
			put(key, convert2String(parameterMap.get(key)));
		}
	}

	public static Parameter newParameter(Map<String, String[]> parameterMap) {
		Parameter parameter = new Parameter();
		for(Iterator<String> iter = parameterMap.keySet().iterator(); iter.hasNext();) {
			String key = iter.next();
			parameter.put(key, parameter.convert2String(parameterMap.get(key)));
		}
		return parameter;
	}
	
	@Override
	public int size() {
		return parameter.size();
	}

	@Override
	public boolean isEmpty() {
		return parameter.isEmpty();
	}

	@Override
	public boolean containsKey(Object key) {
		return parameter.containsKey(key);
	}

	@Override
	public boolean containsValue(Object value) {
		return parameter.containsValue(value);
	}

	@Override
	public String get(Object key) {
		return parameter.get(key);
	}
	
	public boolean getBoolean(Object key, boolean notNull) {
		String val = get(key);
		if(notNull) {
			checkNull(key, val);
		}
		if(isBlank(val)) {
			return false;
		}
		return Boolean.valueOf(val);
	}
	
	public int getInt(Object key, boolean notNull) {
		String val = get(key);
		if(notNull) {
			checkNull(key, val);
		}
		if(isBlank(val)) {
			return 0;
		}
		return Integer.valueOf(val);
	}
	
	public long getLong(Object key, boolean notNull) {
		String val = get(key);
		if(notNull) {
			checkNull(key, val);
		}
		if(isBlank(val)) {
			return 0L;
		}
		return Long.valueOf(val);
	}
	
	public String get(Object key, boolean notNull) {
		String val = parameter.get(key);
		if(notNull) {
			checkNull(key, val);
		}
		return val;
	}
	
	public String get(Object key, String defaultVal) {
		String val = parameter.get(key);
		if(val == null || val.isEmpty()) {
			return defaultVal;
		}
		return val;
	}

	@Override
	public String put(String key, String value) {
		return parameter.put(key, value);
	}

	@Override
	public String remove(Object key) {
		return parameter.remove(key);
	}

	@Override
	public void putAll(Map<? extends String, ? extends String> m) {
		parameter.putAll(m);
	}

	@Override
	public void clear() {
		parameter.clear();
	}

	@Override
	public Set<String> keySet() {
		return parameter.keySet();
	}

	@Override
	public Collection<String> values() {
		return parameter.values();
	}

	@Override
	public Set<Entry<String, String>> entrySet() {
		return parameter.entrySet();
	}
	
	private String convert2String(Object obj) {
		if(obj instanceof String) {
			return (String) obj;
		}
		if(obj instanceof String[]) {
			return ((String[])obj)[0];
		}
		return obj.toString();
	}
	
	private void checkNull(Object key, String val) {
		if((val == null || val.isEmpty())) {
			throw new IllegalArgumentException("Parameter [" + key + "] cannot be null or empty");
		}
	}
	
	public static boolean isBlank(String val) {
		return val == null || val.isEmpty();
	}

}
