package com.jd.ka.smartscheduler.courier.heartbeat;

/**
 * 
 * @author qiulong
 *
 */
public interface HeartbeatListener {
	void onSuccess();
	
	void onFailure();
}
