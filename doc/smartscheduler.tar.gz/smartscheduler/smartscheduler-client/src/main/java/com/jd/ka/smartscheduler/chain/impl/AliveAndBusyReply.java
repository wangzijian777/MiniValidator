/**
 * 
 */
package com.jd.ka.smartscheduler.chain.impl;

import java.util.concurrent.ConcurrentHashMap;

import com.jd.ka.smartscheduler.URLParameter;
import com.jd.ka.smartscheduler.chain.BeforeAndAfterChain;
import com.jd.ka.smartscheduler.common.gson.Gson;
import com.jd.ka.smartscheduler.data.ACK;
import com.jd.ka.smartscheduler.data.ACK.ACKBuilder;
import com.jd.ka.smartscheduler.executor.JobContext;
import com.jd.ka.smartscheduler.executor.ModShardStrategy;
import com.jd.ka.smartscheduler.job.Job;

/**
 * @author qiulong
 *
 */
public class AliveAndBusyReply extends BeforeAndAfterChain {
	private final ConcurrentHashMap<Integer, JobContext> BUSYING = new ConcurrentHashMap<Integer, JobContext>();

	@Override
	protected boolean innerBefore(JobContext jobContext) {
		boolean ping = jobContext.getParameter().getBoolean(
				URLParameter.COMMON.PING, false);
		if (ping) {
			ACK busyACK = jobNotComplete(jobContext);
			if(busyACK != null) {
				jobContext.callbackSync(busyACK);
			} else {
				jobContext.callbackSync(ACK.newBuilder(jobContext).alive());
			}
			return false;
		}
		Job job = jobContext.getJob();
		BUSYING.put(job.getId(), jobContext);
		return true;
	}

	@Override
	protected boolean innerAfter(JobContext jobContext) {
		BUSYING.remove(jobContext.getJob().getId());
		return true;
	}

	private ACK jobNotComplete(JobContext jobContext) {
		int jobId = jobContext.getJob().getId();
		JobContext existContext = null;
		if ((existContext = BUSYING.get(jobId)) != null) {
			ACKBuilder builder = ACK.newBuilder(jobContext);
			ModShardStrategy shardStrategy = existContext.getShardStrategy();
			builder.message(new Gson().toJson(shardStrategy.mod()));
			return builder.busy();
		}
		return null;
	}

}
