package com.jd.ka.smartscheduler.courier;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import com.jd.ka.smartscheduler.common.gson.Gson;
import com.jd.ka.smartscheduler.data.ACK;
import com.jd.ka.smartscheduler.exception.ConnectFailedException;
import com.jd.ka.smartscheduler.exception.WriteData2RemoteException;

/**
 * 负责发送ACK信息
 * @author qiulong
 * 
 */
public class ACKCourierImpl implements ACKCourier {
	private static final String REPORT_URL_PATH = "report";
	private DataSender dataSender;

	public ACKCourierImpl(DataSender dataSender) {
		this.dataSender = dataSender;
	}

	@Override
	public void callback(String[] urls, ACK... acks) {
		if(acks.length == 0) {
			return;
		}
		send(urls, acks);
	}

	@Override
	public void callback(OutputStream os, ACK... acks) throws IOException {
		if(acks.length == 0) {
			return;
		}
		byte[] data = getByteArray(acks);
		os.write(data);
		os.flush();
	}
	
	//Send ACK
	private boolean send(String[] urls, ACK... acks) {
		byte[] data = getByteArray(acks);
		boolean success = false;
		for (int i = 0; i < urls.length; i++) {
			try {
				dataSender.send(getCompleteURL(urls[i]), data);
				success = true;
				break;
			} catch (Exception e) {
				//If ConnectFailedException or WriteData2RemoteException happened, we will change another URL to try again.
				//Otherwise, give up send data
				if(e instanceof ConnectFailedException || e instanceof WriteData2RemoteException) {
					continue;
				}
				break;
			}
		}
		return success;
	}
	
	/**
	 * 获取完整的回传路径
	 * @param url
	 * @return
	 */
	private String getCompleteURL(String url) {
		if(url.lastIndexOf("/") == url.length()-1) {
			url += REPORT_URL_PATH;
		} else {
			url += ("/" + REPORT_URL_PATH);
		}
		return url;
	}
	
	private byte[] getByteArray(ACK...acks) {
		String json = new Gson().toJson(acks);
		try {
			return json.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}
}
