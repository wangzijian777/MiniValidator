package com.jd.ka.smartscheduler.courier;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.jd.ka.smartscheduler.exception.ConnectFailedException;
import com.jd.ka.smartscheduler.exception.WriteData2RemoteException;

/**
 * 
 * @author qiulong
 *
 */
public class HttpDataSender implements DataSender {
	private int connectTimeout = 5000;
	private int readTimeout = 5000;
	private int retrycount = 2;
	private long retryInterval = 3000;

	public HttpDataSender() {
	}

	public HttpDataSender(int connectTimeout, int readTimeout, int retrycount, long retryInterval) {
		if(connectTimeout > 0) {
			this.connectTimeout = connectTimeout;
		}
		if(readTimeout > 0) {
			this.readTimeout = readTimeout;
		}
		if(retrycount > 0) {
			this.retrycount = retrycount;
		}
		if(retryInterval > 0) {
			this.retryInterval = retryInterval;
		}
	}

	@Override
	public String send(String url, byte[] data) throws Exception {
		final StringBuilder response = new StringBuilder();
		this.send(url, data, new ResponseCallback() {
			@Override
			public void callback(InputStream is) throws IOException {
				BufferedReader br = new BufferedReader(new InputStreamReader(is));
				try {
					String line = null;
					while ((line = br.readLine()) != null) {
						response.append(line);
					}
				} finally {
					if (br != null) {
						br.close();
					}
				}
			}
		});
		return response.toString();
	}

	@Override
	public void send(String url, byte[] data, ResponseCallback callback)
			throws Exception {
		HttpURLConnection conn = null;
		int retry = 0;
		boolean connected = false;
		while (true) {
			try {
				conn = getHttpURLConnection(getURL(url));
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "text/plain;charset=utf-8");
				conn.setUseCaches(false);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setConnectTimeout(connectTimeout);
				conn.setReadTimeout(readTimeout);
				conn.connect();
				connected = true;
				break;
			} catch (ConnectException e) {
				try {
					Thread.sleep(retryInterval);
				} catch (InterruptedException ie) {
				}
				// Retry connect when connect exception happened
				retry++;
				if (retry > retrycount) {
					break;
				}
			}
		}
		if (!connected) {
			throw new ConnectFailedException("Connect failed");
		}
		try {
			DataOutputStream dos = null;
			InputStream is = null;
			try {
				dos = new DataOutputStream(conn.getOutputStream());
				try {
					dos.write(data);
					dos.flush();
				} catch(InterruptedIOException e) {
					//Write data exception.
					throw new WriteData2RemoteException(e);
				}
				is = conn.getInputStream();
				callback.callback(is);
			} catch (InterruptedIOException e) {
				/*
				 * Ignore wait response timeout exception. If you want deal with
				 * this exception, you can catch it in ResponseCallback#callback(InputStream) method.
				 * then do what you want to do.
				 */
			} finally {
				if (dos != null) {
					try {
						dos.close();
					} catch (IOException e) {
					}
				}
				if (is != null) {
					try {
						is.close();
					} catch (IOException e) {
					}
				}
			}
		} finally {
			if (conn != null) {
				conn.disconnect();
			}
		}
	}

	private URL getURL(String url) throws MalformedURLException {
		return new URL(url);
	}

	private HttpURLConnection getHttpURLConnection(URL url) throws IOException {
		return (HttpURLConnection) url.openConnection();
	}

}
