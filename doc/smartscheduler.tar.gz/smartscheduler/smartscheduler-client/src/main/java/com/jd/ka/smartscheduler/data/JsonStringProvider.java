package com.jd.ka.smartscheduler.data;

/**
 * 
 * @author qiulong
 *
 */
public interface JsonStringProvider {

	String toJson();
	
}
