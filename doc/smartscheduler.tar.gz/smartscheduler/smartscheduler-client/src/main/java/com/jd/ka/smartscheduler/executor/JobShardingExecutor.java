package com.jd.ka.smartscheduler.executor;

import java.util.Iterator;
import java.util.List;

import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;

/**
 * <strong>Notice: 实现类必须是线程安全的</strong>
 * 拆分数据并多节点、多/单线程的执行
 * @author qiulong
 *
 */
public interface JobShardingExecutor<T> {
	/**
	 * 数据取模分片，分片后的数据，会根据服务端配置的线程数进行多线程并行执行
	 * <p>当{@link ModShardStrategy#limit()}大于0时（也就是每次执行的数据量有限制时），
	 * 一批数据执行完后，程序会自动的调用此方法获取下一批次数据进行执行。
	 * <p>当{@link ModShardStrategy#limit()}等于0时，表示一批次执行所有数据。
	 * @param job 当前所执行的任务
	 * @param shardStrategy 分片策略
	 * @return 分片后的数据主键，或能定位唯一一条数据的条件集合
	 */
	List<T> shard(Job job, ModShardStrategy shardStrategy);
	
	/**
	 * 执行某项作业<br>
	 * @param job Job信息
	 * @param reporter 执行状态汇报
	 * @param shards 分片数据的主键，或能定位唯一一条数据的条件集合
	 * @return 执行成功的数据量
	 */
	int execute(Job job, Reporter reporter, Iterator<T> shards);
}
