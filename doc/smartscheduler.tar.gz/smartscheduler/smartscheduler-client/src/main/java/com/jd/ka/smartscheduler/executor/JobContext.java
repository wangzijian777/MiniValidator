package com.jd.ka.smartscheduler.executor;

import com.jd.ka.smartscheduler.data.ACK;
import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.job.Job;



/**
 * 执行作业所依赖的环境
 * @author qiulong
 *
 */
public interface JobContext {
	/**
	 * 获取Job
	 * @return 当前执行的{@link Job}实例
	 */
	Job getJob();
	
	/**
	 * 获取分片策略
	 * @return {@link ModShardStrategy}实例
	 */
	ModShardStrategy getShardStrategy();
	
	/**
	 * 并行执行的线程数
	 * @return 服务端分配的线程数量
	 */
	int threadNum();
	
	/**
	 * 回去回调地址
	 * @return 回调地址，多个地址','分割
	 */
	String[] callbackUrl();
	
	/**
	 * 获取授权码
	 * @return
	 */
	String getToken();
	
	/**
	 * 获取执行环境
	 * @return {@link ExecutionContext}实例
	 */
	ExecutionContext getExecutorContext();
	
	/**
	 * 获取原始参数
	 * @return
	 */
	Parameter getParameter();
	
	/**
	 * 获取当前节点ID
	 * @return
	 */
	int getNodeId();
	
	/**
	 * 是否分布式执行任务
	 * @return
	 */
	boolean distributed();
	
	/**
	 * 获取流水号<br>
	 * 流水号用于和服务端请求做匹配,当一段时间内有很多Job请求时，可以用流水号和具体哪次Job请求匹配
	 * @return
	 */
	String getSerialNum();
	
	/**
	 * 异步回传ACK
	 * @param acks
	 */
	void callbackAsync(ACK... acks);
	
	/**
	 * 同步回传
	 * @param acks
	 */
	void callbackSync(ACK... acks);
	
}
