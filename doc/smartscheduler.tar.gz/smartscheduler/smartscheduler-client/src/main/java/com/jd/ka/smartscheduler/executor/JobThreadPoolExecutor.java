package com.jd.ka.smartscheduler.executor;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 可中断的任务处理线程池
 * @author qiulong
 *
 */
public class JobThreadPoolExecutor extends ThreadPoolExecutor implements Interruptable {
	private final HashSet<Interruptable> interruptables = new HashSet<Interruptable>();
	private ReentrantLock lock = new ReentrantLock();

	public JobThreadPoolExecutor(int corePoolSize, int maximumPoolSize,
			long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
	}

	public JobThreadPoolExecutor(int corePoolSize, int maximumPoolSize,
			long keepAliveTime, TimeUnit unit,
			BlockingQueue<Runnable> workQueue, RejectedExecutionHandler handler) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, handler);
	}

	public JobThreadPoolExecutor(int corePoolSize, int maximumPoolSize,
			long keepAliveTime, TimeUnit unit,
			BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory,
			RejectedExecutionHandler handler) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue,
				threadFactory, handler);
	}

	public JobThreadPoolExecutor(int corePoolSize, int maximumPoolSize,
			long keepAliveTime, TimeUnit unit,
			BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue,
				threadFactory);
	}

	@Override
	public void execute(Runnable command) {
		if(this.isShutdown()) {
			return;
		}
		if(!(command instanceof Interruptable)) {
			throw new IllegalArgumentException("Runnable is not an instance of [" + Interruptable.class + "]");
		}
		super.execute(command);
	}
	
	@Override
	public void shutdown() {
		interrupt();
	}

	@Override
	public List<Runnable> shutdownNow() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void interrupt() {
		//中断当前正在执行的任务
		lock.lock();
		try {
			for (Iterator<Interruptable> iter = interruptables.iterator(); iter.hasNext(); ) {
				Interruptable next = iter.next();
				if(next != null) {
					next.interrupt();
					iter.remove();
				}
			}
		} finally {
			lock.unlock();
		}
		if(!this.isShutdown()) {
			super.shutdown();
		}
	}

	@Override
	protected void beforeExecute(Thread t, Runnable r) {
		lock.lock();
		try {
			interruptables.add((Interruptable) r);
		} finally {
			lock.unlock();
		}
		super.beforeExecute(t, r);
	}

	@Override
	protected void afterExecute(Runnable r, Throwable t) {
		lock.lock();
		try {
			interruptables.remove((Interruptable) r);
		} finally {
			lock.unlock();
		}
		super.afterExecute(r, t);
	}

	@Override
	public Future<?> submit(Runnable task) {
		throw new UnsupportedOperationException();
	}

	@Override
	public <T> Future<T> submit(Runnable task, T result) {
		throw new UnsupportedOperationException();
	}

	@Override
	public <T> Future<T> submit(Callable<T> task) {
		throw new UnsupportedOperationException();
	}

	@Override
	public <T> T invokeAny(Collection<? extends Callable<T>> tasks)
			throws InterruptedException, ExecutionException {
		throw new UnsupportedOperationException();
	}

	@Override
	public <T> T invokeAny(Collection<? extends Callable<T>> tasks,
			long timeout, TimeUnit unit) throws InterruptedException,
			ExecutionException, TimeoutException {
		throw new UnsupportedOperationException();
	}

	@Override
	public <T> List<Future<T>> invokeAll(Collection<? extends Callable<T>> tasks)
			throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public <T> List<Future<T>> invokeAll(
			Collection<? extends Callable<T>> tasks, long timeout, TimeUnit unit)
			throws InterruptedException {
		throw new UnsupportedOperationException();
	}

}
