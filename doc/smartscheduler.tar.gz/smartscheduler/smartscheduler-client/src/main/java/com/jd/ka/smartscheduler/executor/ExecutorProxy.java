package com.jd.ka.smartscheduler.executor;

/**
 * 
 * @author qiulong
 *
 */
public interface ExecutorProxy extends Interruptable {

	void doExecute(final JobContext jobContext, AfterExecuteCallback callback);
	
	/**
	 * 任务执行完成后的回调
	 * @author qiulong
	 *
	 */
	public interface AfterExecuteCallback {

		void complete(JobContext jobContext);
		
	}
	
}
