package com.jd.ka.smartscheduler.job;

import com.jd.ka.smartscheduler.URLParameter;
import com.jd.ka.smartscheduler.data.Parameter;


/**
 * 
 * @author qiulong
 *
 */
public class DefaultJob implements Job {
	private int id;
	
	
	DefaultJob(DefaultJobBuilder builder) {
		this.id = builder.param.getInt(URLParameter.JOB.ID, true);
	}

	@Override
	public int getId() {
		return id;
	}
	
	/**
	 * Job构建器
	 * @author qiulong
	 *
	 */
	public static class DefaultJobBuilder extends JobBuilder {
		private Parameter param;
		
		DefaultJobBuilder(Parameter param) {
			this.param = param;
		}

		@Override
		public JobBuilder set(String key, String value) {
			param.put(key, value);
			return this;
		}
		
		@Override
		protected void checkParameter() {
			if(this.param == null) {
				throw new NullPointerException("Parameter not found");
			}
		}

		@Override
		protected Job innerBuild() {
			return new DefaultJob(this);
		}

	}

}
