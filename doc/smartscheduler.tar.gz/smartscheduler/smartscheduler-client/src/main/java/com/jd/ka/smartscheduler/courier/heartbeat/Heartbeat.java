package com.jd.ka.smartscheduler.courier.heartbeat;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.jd.ka.smartscheduler.common.utils.DaemonThreadFactory;

/**
 * 心跳服务
 * @author qiulong
 *
 */
public class Heartbeat {
	private final ScheduledExecutorService schedule;
	private final HeartbeatHandler handler;
	private int period = 5;
	private volatile boolean running;
	
	public Heartbeat(HeartbeatHandler handler, int period) {
		this.handler = handler;
		this.schedule = Executors.newSingleThreadScheduledExecutor(new DaemonThreadFactory("heartbeat-"));
		if(period > 0) {
			this.period = period;
		}
	}
	
	public void start(final HeartbeatListener listener) {
		running = true;
		schedule.scheduleWithFixedDelay(new Runnable() {

			@Override
			public void run() {
				if(running) {
					handler.handle(listener);
				}
			}
			
		}, this.period, this.period, TimeUnit.SECONDS);
	}

	public void stop() {
		if(running) {
			running = false;
			schedule.shutdownNow();
		}
	}
	
}
