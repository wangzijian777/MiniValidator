package com.jd.ka.smartscheduler.job;

import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.job.DefaultJob.DefaultJobBuilder;


/**
 * Job构建器
 * @author qiulong
 *
 */
public abstract class JobBuilder {
	
	/**
	 * 创建一个Job构建器
	 * @param param 传入的属性列表
	 * @return {@link JobBuilder}实例
	 */
	public static JobBuilder newBuilder(Parameter param) {
		return new DefaultJobBuilder(param);
	}
	
	/**
	 * 创建一个Job实例
	 * @return Job实例
	 */
	public Job build() {
		checkParameter();
		return this.innerBuild();
	}
	
	/**
	 * 设置参数
	 * @param key 键
	 * @param value 值
	 * @return
	 */
	public abstract JobBuilder set(String key, String value);
	
	/**
	 * 内部Job实例构建器
	 * @return
	 */
	protected abstract Job innerBuild();
	
	/**
	 * 参数校验
	 */
	protected abstract void checkParameter();
}
