package com.jd.ka.smartscheduler.executor;

import java.io.OutputStream;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadFactory;

import com.jd.ka.smartscheduler.chain.BeforeAndAfterChain;
import com.jd.ka.smartscheduler.common.utils.DaemonThreadFactory;
import com.jd.ka.smartscheduler.data.ACK;
import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.executor.ExecutorProxy.AfterExecuteCallback;
import com.jd.ka.smartscheduler.job.Job;

/**
 * 执行Job的中控环境，负责{@link JobContext}的创建和Job的执行。
 * 
 * @author qiulong
 *
 */
public class JobExecutionContext implements ExecutionContext {
	private ThreadFactory threadFactory = new DaemonThreadFactory("executor-launcher-");
	private BeforeAndAfterChain chain;
	private ConcurrentHashMap<Integer, Interruptable> suspendableContext = new ConcurrentHashMap<Integer, Interruptable>();

	public JobExecutionContext(BeforeAndAfterChain chain) {
		this.chain = chain;
	}

	@Override
	public <T> void execute(JobShardingExecutor<T> executor, Parameter params, OutputStream os) {
		JobContext jobContext = jobContextBuild(params, os).build();
		ExecutorProxy executorProxy = createExecutorProxy(jobContext, executor);
		startWithAsync(executorProxy, jobContext);
	}

	@Override
	public boolean beforeExecute(JobContext jobContext) {
		return this.chain.before(jobContext);
	}

	@Override
	public boolean afterExecute(JobContext jobContext) {
		removeFromSuspendableContext(jobContext.getJob());
		return this.chain.after(jobContext);
	}
	
	@Override
	public void interrupt(Job job) {
		Interruptable suspendable = suspendableContext.get(job.getId());
		if(suspendable != null) {
			suspendable.interrupt();
		}
	}
	
	private JobContextBuilder jobContextBuild(Parameter params, OutputStream os) {
		return JobContextBuilder.newBuilder(this, params).outputStream(os);
	}

	private <T> ExecutorProxy createExecutorProxy(JobContext jobContext, JobShardingExecutor<T> executor) {
		if(jobContext.distributed()) {
			return new JobShardingExecutorProxy<T>(executor);
		}
		return new JobLocalShardingExecutorProxy<T>(executor);
	}
	
	private void addToSuspendableContext(Job job, Interruptable suspendable) {
		suspendableContext.put(job.getId(), suspendable);
	}
	
	private void removeFromSuspendableContext(Job job) {
		suspendableContext.remove(job.getId());
	}

	private void startWithAsync(ExecutorProxy executorProxy, JobContext jobContext) {
		if(beforeExecute(jobContext)) {
			addToSuspendableContext(jobContext.getJob(), executorProxy);
			threadFactory.newThread(new AsyncExecutor(executorProxy, jobContext)).start();
			jobContext.callbackSync(ACK.newBuilder(jobContext).begin());
		}
	}

	// 异步执行
	private class AsyncExecutor implements Runnable {
		private ExecutorProxy executorProxy;
		private JobContext jobContext;

		public AsyncExecutor(ExecutorProxy executorProxy, JobContext jobContext) {
			this.executorProxy = executorProxy;
			this.jobContext = jobContext;
		}

		@Override
		public void run() {
			executorProxy.doExecute(jobContext, new AfterExecuteCallback() {
				@Override
				public void complete(JobContext jobContext) {
					afterExecute(jobContext);
				}
			});
		}
	}

}
