package com.jd.ka.smartscheduler.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.jd.ka.smartscheduler.URLParameter;
import com.jd.ka.smartscheduler.common.gson.Gson;
import com.jd.ka.smartscheduler.common.utils.MessageFormat;
import com.jd.ka.smartscheduler.executor.JobContext;

/**
 * 应答调度服务器信息
 * 
 * @author qiulong
 * 
 */
public class ACK implements Serializable, MapProvider, JsonStringProvider {
	private static final long serialVersionUID = -5643548244802506738L;
	public static final String SERIALNUM = URLParameter.JOB.SERIALNUM;
	public static final String JOBID = URLParameter.JOB.ID;
	public static final String NODEID = URLParameter.COMMON.NODEID;
	public static final String TIMESTAMP = "timestamp";
	public static final String STATUS = "status";
	public static final String MESSAGE = "message";
	
	/**
	 * 流水号
	 */
	protected String serialNum;

	/**
	 * Job id
	 */
	protected int jobId;

	/**
	 * 执行状态
	 */
	protected ACKStatus status;

	/**
	 * 返回的信息
	 */
	protected String message;

	/**
	 * 创建时间（单位：秒）
	 */
	protected long timestamp = System.currentTimeMillis() / 1000;
	
	/**
	 * 当前节点名称
	 */
	protected int nodeId;

	/**
	 * Job执行状态
	 * 
	 * @author qiulong
	 * 
	 */
	public enum ACKStatus {
		/*任务执行状态*/
		/**
		 * 开始执行
		 */
		BEGIN,
		/**
		 * 执行完成
		 */
		DONE,
		/**
		 * 调度失败
		 */
		FAILURE,
		/**
		 * 执行中断
		 */
		INTERRUPT,
		
		/*其它状态*/
		/**
		 * 节点繁忙
		 */
		BUSY,
		/**
		 * 存活状态
		 */
		ALIVE,
		;

	}
	
	protected ACK() {}

	public int getJobId() {
		return jobId;
	}

	public ACKStatus getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public String getSerialNum() {
		return serialNum;
	}

	public int getNodeId() {
		return nodeId;
	}

	@Override
	public Map<String, Object> toMap() {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(SERIALNUM, this.getSerialNum());
		map.put(JOBID, this.getJobId());
		map.put(TIMESTAMP, this.getTimestamp());
		map.put(STATUS, this.getStatus().toString());
		map.put(MESSAGE, this.getMessage());
		map.put(NODEID, this.getNodeId());
		return map;
	}

	@Override
	public String toJson() {
		return new Gson().toJson(this);
	}

	public static ACKBuilder newBuilder(JobContext jobContext) {
		return new ACKBuilder(jobContext);
	}
	
	public static class ACKBuilder {
		private final JobContext jobContext;
		private String message = "";
		private ACKBuilder(JobContext jobContext) {
			this.jobContext = jobContext;
		}
		
		public ACKBuilder message(String messagePattern, Object...args) {
			this.message = MessageFormat.format(messagePattern, args);
			return this;
		}
		
		public ACK begin() {
			return build(ACKStatus.BEGIN);
		}
		
		public ACK done() {
			return build(ACKStatus.DONE);
		}
		
		public ACK failure() {
			return build(ACKStatus.FAILURE);
		}
		
		public ACK interrupt() {
			return build(ACKStatus.INTERRUPT);
		}
		
		public ACK busy() {
			return build(ACKStatus.BUSY);
		}
		
		public ACK alive() {
			return build(ACKStatus.ALIVE);
		}
		
		public ACK build(ACKStatus status) {
			ACK ack = new ACK();
			ack.jobId = this.jobContext.getJob().getId();
			ack.serialNum = this.jobContext.getSerialNum();
			ack.nodeId = this.jobContext.getNodeId();
			ack.status = status;
			ack.message = this.message;
			return ack;
		}
	}
	
}
