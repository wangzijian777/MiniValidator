package com.jd.ka.smartscheduler.executor;

/**
 * 可中断的任务
 * @author qiulong
 *
 */
public interface Interruptable {
	/**
	 * 中断任务
	 */
	void interrupt();
}
