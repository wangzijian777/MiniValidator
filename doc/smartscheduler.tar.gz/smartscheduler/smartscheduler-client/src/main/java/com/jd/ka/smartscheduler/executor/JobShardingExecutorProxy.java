package com.jd.ka.smartscheduler.executor;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.jd.ka.smartscheduler.common.utils.collection.DataIterator;
import com.jd.ka.smartscheduler.common.utils.collection.ListDataIterator;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;

/**
 * 多节点多线程执行任务
 * @author qiulong
 *
 * @param <T>
 */
public class JobShardingExecutorProxy<T> extends AbstractExecutorProxy<T> {
	private static final String THREAD_NAME = "multi-sharding-executor-";
	
	private AtomicInteger executingThread = new AtomicInteger(0);
	private ExecutorService threadPool;
	private volatile boolean isShutdown = false;
	
	public JobShardingExecutorProxy(JobShardingExecutor<T> executor) {
		super(executor);
	}

	@Override
	protected void innerDoExecute(JobContext jobContext) {
		Job job = jobContext.getJob();
		//Create thread pool
		int threadNum = jobContext.threadNum();
		this.threadPool = new JobThreadPoolExecutor(threadNum, threadNum, 0L, TimeUnit.MILLISECONDS, 
				new SynchronousQueue<Runnable>(true), 
				this.getThreadFactory(THREAD_NAME + job.getId() + "-"),
				new RetryPolicy());
		
		ModShardStrategy shardStrategy = jobContext.getShardStrategy();
		boolean hasLimit = shardStrategy.limit() > 0;
		List<T> shards = this.shard(job, shardStrategy);
		while(!isShutdown) {
			if(shards.size() > 0) {
				parallelExecute(jobContext, shards);
				if(!hasLimit) {
					break;
				}
				shards = this.shard(job, shardStrategy);
			} else {
				break;
			}
		}
		spinWait4Complete(jobContext);
	}

	@Override
	public void innerInterrupt() {
		isShutdown = true;
		threadPool.shutdown();
	}

	@Override
	public int execute(final Job job, final Reporter reporter, final Iterator<T> shards) {
		executingThread.incrementAndGet();
		this.threadPool.execute(new MutiThreadExceutor(job, reporter, (DataIterator<T>)shards));
		return 0;
	}
	
	private void parallelExecute(final JobContext jobContext, final List<T> shards) {
		int threadNum = jobContext.threadNum();
		final Job job = jobContext.getJob();
		int size = shards.size();
		if(threadNum < 2 || size <= threadNum) {
			//single thread
			this.execute(job, getReporter(), new ListDataIterator<T>(shards));
		} else {
			//multiple thread, unbalanced allocate.
			int avg = size / threadNum;
			int startIndex = 0;
			int endIndex = 0;
			int left = size - threadNum * avg;
			for (int i = 1; i <= threadNum; i++) {
				endIndex = i * avg > size ? size :  i * avg;
				if(i == threadNum) {
					endIndex += left;
				}
				this.execute(job, getReporter(), new ListDataIterator<T>(shards.subList(startIndex, endIndex)));
				startIndex = endIndex;
			}
		}
	}
	
	//自旋等待所有任务完成
	private void spinWait4Complete(JobContext jobContext) {
		for(;;) {
			if(isShutdown || executingThread.get() == 0) {
				break;
			}
			try {
				Thread.sleep(100L);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}
	
	private class MutiThreadExceutor implements Runnable, Interruptable {
		private final Job job;
		private final Reporter reporter;
		private final DataIterator<T> shards;
		
		public MutiThreadExceutor(final Job job, final Reporter reporter, final DataIterator<T> shards) {
			this.job = job;
			this.reporter = reporter;
			this.shards = shards;
		}

		@Override
		public void interrupt() {
			//清空所有还未执行的数据
			if(shards != null) {
				shards.clear();
			}
		}

		@Override
		public void run() {
			try {
				if(!isShutdown) {
					addSuccessCount(getTargetExecutor().execute(job, reporter, shards));
				}
			} finally {
				executingThread.decrementAndGet();
			}
		}
		
	}
	
	/**
	 * 线程池饱和时不断重试，重新提交任务
	 * @author qiulong
	 *
	 */
	private class RetryPolicy implements RejectedExecutionHandler {

		@Override
		public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
			try {
				Thread.sleep(100L);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			}
			executor.submit(r);
		}
		
	}

}
