package com.jd.ka.smartscheduler.executor;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import com.jd.ka.smartscheduler.common.utils.DaemonThreadFactory;
import com.jd.ka.smartscheduler.data.ACK;
import com.jd.ka.smartscheduler.data.ACK.ACKBuilder;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;

/**
 * 
 * @author qiulong
 *
 */
public abstract class AbstractExecutorProxy<T> implements JobShardingExecutor<T>, ExecutorProxy {
	private final JobShardingExecutor<T> targetExecutor;
	private ThreadFactory threadFactory;
	//提取的总数据量
	private AtomicInteger dataCount = new AtomicInteger(0);
	//执行成功的数据量
	private AtomicInteger successCount = new AtomicInteger(0);
	private Reporter reporter;
	private boolean isInterrupt;

	public AbstractExecutorProxy(JobShardingExecutor<T> targetExecutor) {
		this.targetExecutor = targetExecutor;
	}
	
	@Override
	public void interrupt() {
		isInterrupt = true;
		innerInterrupt();
	}

	@Override
	public void doExecute(JobContext jobContext, AfterExecuteCallback callback) {
		try {
			innerDoExecute(jobContext);
		} finally {
			callback.complete(jobContext);
			ACKBuilder ackBuilder = ACK.newBuilder(jobContext);
			if(isInterrupt) {
				jobContext.callbackAsync(ackBuilder.interrupt());
			} else {
				jobContext.callbackAsync(ackBuilder.message("{\"count\":{},\"success\":{}}", dataCount.get(), successCount.get()).done());
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> shard(Job job, ModShardStrategy shardStrategy) {
		List<T> shards = targetExecutor.shard(job, shardStrategy);
		if(shards == null) {
			shards = Collections.EMPTY_LIST;
		}
		dataCount.addAndGet(shards.size());
		return shards;
	}

	protected ThreadFactory getThreadFactory(String threadName) {
		if(threadFactory == null) {
			this.threadFactory = new DaemonThreadFactory(threadName);
		}
		return threadFactory;
	}
	
	protected  JobShardingExecutor<T> getTargetExecutor() {
		return targetExecutor;
	}
	
	protected Reporter getReporter() {
		return this.reporter;
	}
	
	protected void addSuccessCount(int count) {
		successCount.addAndGet(count);
	}
	
	abstract protected void innerDoExecute(JobContext jobContext);
	abstract protected void innerInterrupt();

}
