package com.jd.ka.smartscheduler.executor;

import java.io.OutputStream;

import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.job.Job;

/**
 * 执行过程中的上下文环境(ThreadSafe)<br>
 * @author qiulong
 *
 */
public interface ExecutionContext {
	
	/**
	 * 执行指定任务
	 * @param executor Job执行器{@link JobShardingExecutor}
	 * @param params 调度服务器传入的参数
	 * @param os 输出流
	 */
	<T> void execute(JobShardingExecutor<T> executor, Parameter params, OutputStream os);
	
	/**
	 * Job开始执行之前调用
	 * @param jobContext
	 * @return
	 */
	boolean beforeExecute(JobContext jobContext);
	
	/**
	 * Job结束执行之后调用
	 * @param jobContext
	 * @return
	 */
	boolean afterExecute(JobContext jobContext);
	
	/**
	 * 中断任务
	 * @param job
	 */
	void interrupt(Job job);
	
}
