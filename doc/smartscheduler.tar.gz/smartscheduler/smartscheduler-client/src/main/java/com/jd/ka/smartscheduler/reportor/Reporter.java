package com.jd.ka.smartscheduler.reportor;



/**
 * We will put something useful here in a few days
 * @author qiulong
 */
public interface Reporter {
	
}
