package com.jd.ka.smartscheduler.common.utils.collection;

import java.util.Iterator;

/**
 * 
 * @author qiulong
 *
 * @param <E>
 */
public interface DataIterator<E> extends Iterator<E> {
	
	/**
	 * 返回集合中元素总数
	 * @return
	 */
	int size();
	
	/**
	 * 清空集合中元素
	 */
	void clear();
	
}
