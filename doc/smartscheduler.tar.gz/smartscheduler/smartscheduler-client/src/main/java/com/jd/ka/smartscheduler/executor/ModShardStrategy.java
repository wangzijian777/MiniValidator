package com.jd.ka.smartscheduler.executor;

/**
 * 取模分片策略
 * @author qiulong
 *
 */
public interface ModShardStrategy {
	public static final String MOD = "mod";
	public static final String LIMIT = "limit";
	public static final String DIVISOR = "divisor";
	
	/**
	 * 取模因子
	 * @return
	 */
	int divisor();
	
	/**
	 * 匹配的取模值
	 * @return
	 */
	 int[] mod();
	
	/**
	 * 每次执行的数据量限制
	 * @return
	 */
	int limit();
}
