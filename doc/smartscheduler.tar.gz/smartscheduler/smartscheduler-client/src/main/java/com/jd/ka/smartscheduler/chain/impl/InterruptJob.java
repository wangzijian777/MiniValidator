package com.jd.ka.smartscheduler.chain.impl;

import com.jd.ka.smartscheduler.URLParameter;
import com.jd.ka.smartscheduler.chain.BeforeAndAfterChain;
import com.jd.ka.smartscheduler.executor.JobContext;

/**
 * 控制中断一个任务
 * @author qiulong
 *
 */
public class InterruptJob extends BeforeAndAfterChain {
	
	@Override
	protected boolean innerBefore(JobContext jobContext) {
		boolean interrupt = jobContext.getParameter().getBoolean(URLParameter.COMMON.INTERRUPT, false);
		if(interrupt) {
			jobContext.getExecutorContext().interrupt(jobContext.getJob());
			return false;
		}
		return true;
	}

	@Override
	protected boolean innerAfter(JobContext jobContext) {
		return true;
	}

}
