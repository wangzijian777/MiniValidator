package com.jd.ka.smartscheduler.courier;

import java.io.IOException;
import java.io.OutputStream;

import com.jd.ka.smartscheduler.data.ACK;

/**
 * ACK信息发送器
 * @author qiulong
 *
 */
public interface ACKCourier {
	
	/**
	 * 回调调度服务器
	 * @param urls 调度服务器地址列表
	 * @param acks 回传的数据列表
	 */
	void callback(String[] urls, ACK... acks);
	
	/**
	 * 响应调度服务器
	 * @param os 输出流
	 * @param acks 回传的数据列表
	 * @throws IOException
	 */
	void callback(OutputStream os, ACK... acks) throws IOException;
}
