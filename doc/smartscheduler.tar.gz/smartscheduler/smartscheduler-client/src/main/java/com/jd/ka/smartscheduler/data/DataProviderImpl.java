package com.jd.ka.smartscheduler.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author qiulong
 *
 */
public class DataProviderImpl implements DataProvider {

	@Override
	public String getJsonString(JsonStringProvider... providers) {
		StringBuilder sb =  new StringBuilder("[");
		int len = providers.length;
		for (int i = 0; i < len; i++) {
			if(providers[i] == null) {continue;}
			sb.append(providers[i].toJson());
			if(i + 1 < len) {
				sb.append(",");
			}
		}
		sb.append("]");
		return sb.toString();
	}

	@Override
	public List<Map<String, Object>> getMap(MapProvider... providers) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		for (MapProvider provider : providers) {
			list.add(provider.toMap());
		}
		return list;
	}


}
