package com.jd.ka.smartscheduler.exception;

/**
 * 建立连接失败异常
 * @author qiulong
 *
 */
public class ConnectFailedException extends Exception {
	private static final long serialVersionUID = 1L;

	public ConnectFailedException() {
		super();
	}

	public ConnectFailedException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public ConnectFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	public ConnectFailedException(String message) {
		super(message);
	}

	public ConnectFailedException(Throwable cause) {
		super(cause);
	}

}
