package com.jd.ka.smartscheduler.chain.impl;

import java.util.concurrent.ConcurrentHashMap;

import com.jd.ka.smartscheduler.URLParameter;
import com.jd.ka.smartscheduler.chain.BeforeAndAfterChain;
import com.jd.ka.smartscheduler.courier.heartbeat.Heartbeat;
import com.jd.ka.smartscheduler.courier.heartbeat.HeartbeatListener;
import com.jd.ka.smartscheduler.courier.heartbeat.HttpHeartbeatHandler;
import com.jd.ka.smartscheduler.data.Parameter;
import com.jd.ka.smartscheduler.executor.JobContext;
import com.jd.ka.smartscheduler.job.Job;

/**
 * 
 * @author qiulong
 *
 */
public class JobHeartbeat extends BeforeAndAfterChain {
	private ConcurrentHashMap<Integer, Heartbeat> heartbeats = new ConcurrentHashMap<Integer, Heartbeat>();

	@Override
	protected boolean innerBefore(final JobContext jobContext) {
		Parameter param = jobContext.getParameter();
		final Job job = jobContext.getJob();
		final Heartbeat heartbeat = new Heartbeat(new HttpHeartbeatHandler(
				jobContext.callbackUrl()), param.getInt(
				URLParameter.HEARTBEAT.PERIOD, false));
		heartbeats.putIfAbsent(job.getId(), heartbeat);
		heartbeat.start(new HeartbeatListener() {
			@Override
			public void onSuccess() {
				// Do nothing...
			}

			@Override
			public void onFailure() {
				// 中断任务
				jobContext.getExecutorContext().interrupt(job);
				// 停止心跳
				heartbeat.stop();
				heartbeats.remove(job.getId());
			}
		});
		return true;
	}

	@Override
	protected boolean innerAfter(JobContext jobContext) {
		// 移除并停止心跳
		Heartbeat hb = heartbeats.remove(jobContext.getJob().getId());
		if(hb != null) {
			hb.stop();
		}
		return true;
	}

}
