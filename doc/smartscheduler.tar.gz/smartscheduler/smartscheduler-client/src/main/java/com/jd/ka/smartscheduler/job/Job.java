package com.jd.ka.smartscheduler.job;

/**
 * Job基本信息提供接口
 * @author qiulong
 *
 */
public interface Job {
	/**
	 * 获取Job编号
	 * @return
	 */
	int getId();

}
