package com.jd.ka.smartscheduler.courier;

import java.io.IOException;
import java.io.InputStream;

/**
 * 数据发送器
 * @author qiulong
 * 
 */
public interface DataSender {
	/**
	 * 向指定URL发送数据
	 * @param url 目标URL
	 * @param data 要发送的数据
	 * @return 以字符串形式返回响应结果
	 * @throws Exception
	 */
	String send(String url, byte[] data) throws Exception;

	/**
	 * 向指定URL发送数据，并自行处理响应结果
	 * @param url 目标URL
	 * @param data 要发送的数据
	 * @param callback 自行处理的回调函数
	 * @throws Exception
	 */
	void send(String url, byte[] data, ResponseCallback callback) throws Exception;

	/**
	 * 自行处理响应结果的回调
	 * @author qiulong
	 *
	 */
	public interface ResponseCallback {
		/**
		 * 回调函数
		 * @param is 响应流
		 * @throws IOException
		 */
		void callback(InputStream is) throws IOException;
	}
}
