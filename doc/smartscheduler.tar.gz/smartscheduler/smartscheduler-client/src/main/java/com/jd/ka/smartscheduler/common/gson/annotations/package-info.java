/**
 * This package provides annotations that can be used with {@link com.jd.ka.smartscheduler.common.gson.Gson}.
 * 
 * @author Inderjeet Singh, Joel Leitch
 */
package com.jd.ka.smartscheduler.common.gson.annotations;