/**
 * 
 */
package com.jd.ka.smartscheduler.chain.impl;

import com.jd.ka.smartscheduler.chain.BeforeAndAfterChain;
import com.jd.ka.smartscheduler.data.ACK;
import com.jd.ka.smartscheduler.executor.JobContext;

/**
 * @author qiulong
 *
 */
public class SecurityChecker extends BeforeAndAfterChain {

	@Override
	protected boolean innerBefore(JobContext jobContext) {
		//TODO token check
		if(jobContext.getToken().isEmpty()) {
			jobContext.callbackSync(ACK.newBuilder(jobContext).message("Authorization failed").failure());
			return false;
		}
		return true;
	}

	@Override
	protected boolean innerAfter(JobContext jobContext) {
		return true;
	}

}
