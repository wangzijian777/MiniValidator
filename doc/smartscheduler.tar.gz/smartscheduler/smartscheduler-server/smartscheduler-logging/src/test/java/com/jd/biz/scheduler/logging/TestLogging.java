package com.jd.biz.scheduler.logging;

import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.logging.jdk.JDKLoggerFactory;
import com.jd.ka.smartscheduler.logging.log4j.Log4jLoggerFactory;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * 
 * @author qiulong
 *
 */
public class TestLogging extends TestCase {
	/**
	 * Create the test case
	 *
	 * @param testName
	 *            name of the test case
	 */
	public TestLogging(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(TestLogging.class);
	}

	public void testJdkLoggerFactory() {
		LoggerFactory.setDefaultLoggerFactory(new JDKLoggerFactory());
		testLogger();
	}
	
	public void testLog4jLoggerFactory() {
		LoggerFactory.setDefaultLoggerFactory(new Log4jLoggerFactory());
		testLogger();
	}
	
	public void testLogger() {
		Logger logger = LoggerFactory.getLogger(getClass(), "prefix-1");
		logger.setLevel("debug");
		logger.debug("debug {}", "log");
		logger.info("info {}", "log");
		logger.error("error {}", "log");
	}
}
