/**
 * 
 */
package com.jd.ka.smartscheduler.logging;

/**
 * @author qiulong
 *
 */
public abstract class AbstractLogger implements Logger {
	private final String prefix;
	
	public AbstractLogger(String prefix) {
		super();
		this.prefix = prefix;
	}

	@Override
	public void trace(String msg, Object... params) {
		if(isTraceEnabled()) {
			internalTrace(LoggerMessageFormat.format(prefix, msg, params));
		}
	}
	
	@Override
	public void trace(String msg, Throwable cause, Object... params) {
		if(isTraceEnabled()) {
			internalTrace(LoggerMessageFormat.format(prefix, msg, params), cause);
		}
	}

	@Override
	public void debug(String msg, Object... params) {
		if(isDebugEnabled()) {
			internalDebug(LoggerMessageFormat.format(prefix, msg, params));
		}
	}

	@Override
	public void debug(String msg, Throwable cause, Object... params) {
		if(isDebugEnabled()) {
			internalDebug(LoggerMessageFormat.format(prefix, msg, params), cause);
		}
	}

	@Override
	public void info(String msg, Object... params) {
		if(isInfoEnabled()) {
			internalInfo(LoggerMessageFormat.format(prefix, msg, params));
		}
	}

	@Override
	public void info(String msg, Throwable cause, Object... params) {
		if(isInfoEnabled()) {
			internalInfo(LoggerMessageFormat.format(prefix, msg, params), cause);
		}
	}

	@Override
	public void warn(String msg, Object... params) {
		if(isWarnEnabled()) {
			internalWarn(LoggerMessageFormat.format(prefix, msg, params));
		}
	}

	@Override
	public void warn(String msg, Throwable cause, Object... params) {
		if(isWarnEnabled()) {
			internalWarn(LoggerMessageFormat.format(prefix, msg, params, cause));
		}
	}

	@Override
	public void error(String msg, Object... params) {
		if(isErrorEnabled()) {
			internalError(LoggerMessageFormat.format(prefix, msg, params));
		}
	}

	@Override
	public void error(String msg, Throwable cause, Object... params) {
		if(isErrorEnabled()) {
			internalError(LoggerMessageFormat.format(prefix, msg, params, cause));
		}
	}
	
	 protected abstract void internalTrace(String msg);
	 protected abstract void internalTrace(String msg, Throwable cause);
	 protected abstract void internalDebug(String msg);
	 protected abstract void internalDebug(String msg, Throwable cause);
	 protected abstract void internalInfo(String msg);
	 protected abstract void internalInfo(String msg, Throwable cause);
	 protected abstract void internalWarn(String msg);
	 protected abstract void internalWarn(String msg, Throwable cause);
	 protected abstract void internalError(String msg);
	 protected abstract void internalError(String msg, Throwable cause);

}
