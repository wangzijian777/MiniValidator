package com.jd.ka.smartscheduler.logging.slf4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.spi.LocationAwareLogger;

import com.jd.ka.smartscheduler.logging.AbstractLogger;

public class Slf4jLogger extends AbstractLogger {
	private Logger logger;
	private final LocationAwareLogger lALogger;
	private final String FQCN = AbstractLogger.class.getName();

	public Slf4jLogger(String prefix, String name) {
		super(prefix);
		this.logger = LoggerFactory.getLogger(name);
		if (logger instanceof LocationAwareLogger) {
            lALogger = (LocationAwareLogger) logger;
        } else {
            lALogger = null;
        }
	}

	@Override
	public void setLevel(String level) {
	}

	@Override
	public String getLevel() {
		return null;
	}

	@Override
	public boolean isTraceEnabled() {
		return logger.isTraceEnabled();
	}

	@Override
	public boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}

	@Override
	public boolean isInfoEnabled() {
		return logger.isInfoEnabled();
	}

	@Override
	public boolean isWarnEnabled() {
		return logger.isWarnEnabled();
	}

	@Override
	public boolean isErrorEnabled() {
		return logger.isErrorEnabled();
	}

	@Override
	protected void internalTrace(String msg) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.TRACE_INT, msg, null, null);
		} else {
			logger.trace(msg);
		}
	}

	@Override
	protected void internalTrace(String msg, Throwable cause) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.TRACE_INT, msg, null, cause);
		} else {
			logger.trace(msg);
		}
	}

	@Override
	protected void internalDebug(String msg) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.DEBUG_INT, msg, null, null);
		} else {
			logger.debug(msg);
		}
	}

	@Override
	protected void internalDebug(String msg, Throwable cause) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.DEBUG_INT, msg, null, cause);
		} else {
			logger.debug(msg);
		}
	}

	@Override
	protected void internalInfo(String msg) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.INFO_INT, msg, null, null);
		} else {
			logger.info(msg);
		}
	}

	@Override
	protected void internalInfo(String msg, Throwable cause) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.INFO_INT, msg, null, cause);
		} else {
			logger.info(msg);
		}
	}

	@Override
	protected void internalWarn(String msg) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.WARN_INT, msg, null, null);
		} else {
			logger.warn(msg);
		}
	}

	@Override
	protected void internalWarn(String msg, Throwable cause) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.WARN_INT, msg, null, cause);
		} else {
			logger.warn(msg);
		}
	}

	@Override
	protected void internalError(String msg) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.ERROR_INT, msg, null, null);
		} else {
			logger.error(msg);
		}
	}

	@Override
	protected void internalError(String msg, Throwable cause) {
		if(lALogger != null) {
			lALogger.log(null, FQCN, LocationAwareLogger.ERROR_INT, msg, null, cause);
		} else {
			logger.error(msg);
		}
	}

}
