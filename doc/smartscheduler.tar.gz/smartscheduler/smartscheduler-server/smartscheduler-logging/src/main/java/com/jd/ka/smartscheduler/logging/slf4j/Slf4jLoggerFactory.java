/**
 * 
 */
package com.jd.ka.smartscheduler.logging.slf4j;

import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;

/**
 * @author qiulong
 *
 */
public class Slf4jLoggerFactory extends LoggerFactory {

	@Override
	protected Logger newInstance(String prefix, String name) {
		return new Slf4jLogger(prefix, name);
	}

}
