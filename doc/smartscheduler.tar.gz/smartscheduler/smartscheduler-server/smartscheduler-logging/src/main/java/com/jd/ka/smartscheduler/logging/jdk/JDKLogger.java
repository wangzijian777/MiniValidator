/**
 * 
 */
package com.jd.ka.smartscheduler.logging.jdk;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.jd.ka.smartscheduler.logging.AbstractLogger;

/**
 * @author qiulong
 *
 */
public class JDKLogger extends AbstractLogger {

	private final Logger logger;

	public JDKLogger(String prefix, Logger logger) {
		super(prefix);
		this.logger = logger;
	}

	@Override
	public void setLevel(String level) {
		if (level == null) {
			logger.setLevel(null);
		} else if ("error".equalsIgnoreCase(level)) {
			logger.setLevel(Level.SEVERE);
		} else if ("warn".equalsIgnoreCase(level)) {
			logger.setLevel(Level.WARNING);
		} else if ("info".equalsIgnoreCase(level)) {
			logger.setLevel(Level.INFO);
		} else if ("debug".equalsIgnoreCase(level)) {
			logger.setLevel(Level.FINE);
		} else if ("trace".equalsIgnoreCase(level)) {
			logger.setLevel(Level.FINE);
		}
	}

	@Override
	public String getLevel() {
		if (logger.getLevel() == null) {
            return null;
        }
        return logger.getLevel().toString();
	}

	@Override
	public boolean isTraceEnabled() {
		return logger.isLoggable(Level.FINEST);
	}

	@Override
	public boolean isDebugEnabled() {
		 return logger.isLoggable(Level.FINE);
	}

	@Override
	public boolean isInfoEnabled() {
		return logger.isLoggable(Level.INFO);
	}

	@Override
	public boolean isWarnEnabled() {
		return logger.isLoggable(Level.WARNING);
	}

	@Override
	public boolean isErrorEnabled() {
		return logger.isLoggable(Level.SEVERE);
	}

	@Override
	protected void internalTrace(String msg) {
		logger.log(new JDKLogRecord(Level.FINEST, msg));
	}

	@Override
	protected void internalTrace(String msg, Throwable cause) {
		logger.log(new JDKLogRecord(Level.FINEST, msg).thrown(cause));
	}

	@Override
	protected void internalDebug(String msg) {
		logger.log(new JDKLogRecord(Level.FINE, msg));
	}

	@Override
	protected void internalDebug(String msg, Throwable cause) {
		logger.log(new JDKLogRecord(Level.FINE, msg).thrown(cause));
	}

	@Override
	protected void internalInfo(String msg) {
		logger.log(new JDKLogRecord(Level.INFO, msg));
	}

	@Override
	protected void internalInfo(String msg, Throwable cause) {
		logger.log(new JDKLogRecord(Level.INFO, msg).thrown(cause));
	}

	@Override
	protected void internalWarn(String msg) {
		logger.log(new JDKLogRecord(Level.WARNING, msg));
	}

	@Override
	protected void internalWarn(String msg, Throwable cause) {
		logger.log(new JDKLogRecord(Level.WARNING, msg).thrown(cause));
	}

	@Override
	protected void internalError(String msg) {
		logger.log(new JDKLogRecord(Level.SEVERE, msg));
	}

	@Override
	protected void internalError(String msg, Throwable cause) {
		logger.log(new JDKLogRecord(Level.SEVERE, msg).thrown(cause));
	}

}
