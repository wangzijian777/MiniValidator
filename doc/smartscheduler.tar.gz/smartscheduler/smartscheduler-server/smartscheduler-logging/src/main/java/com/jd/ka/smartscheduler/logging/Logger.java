/**
 * 
 */
package com.jd.ka.smartscheduler.logging;

/**
 * @author qiulong
 *
 */
public interface Logger {

	void setLevel(String level);

	String getLevel();

	boolean isTraceEnabled();

	boolean isDebugEnabled();

	boolean isInfoEnabled();

	boolean isWarnEnabled();

	boolean isErrorEnabled();

	void trace(String msg, Object... params);

	void trace(String msg, Throwable cause, Object... params);

	void debug(String msg, Object... params);

	void debug(String msg, Throwable cause, Object... params);

	void info(String msg, Object... params);

	void info(String msg, Throwable cause, Object... params);

	void warn(String msg, Object... params);

	void warn(String msg, Throwable cause, Object... params);

	void error(String msg, Object... params);

	void error(String msg, Throwable cause, Object... params);
}
