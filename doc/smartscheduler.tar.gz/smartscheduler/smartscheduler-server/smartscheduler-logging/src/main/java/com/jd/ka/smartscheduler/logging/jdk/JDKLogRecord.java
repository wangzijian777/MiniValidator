package com.jd.ka.smartscheduler.logging.jdk;

import java.util.logging.Level;
import java.util.logging.LogRecord;

import com.jd.ka.smartscheduler.logging.AbstractLogger;

/**
 * 
 * @author qiulong
 *
 */
public class JDKLogRecord extends LogRecord {
	private static final long serialVersionUID = 656241736388373446L;

	private static final String FQCN = AbstractLogger.class.getName();
	private String sourceClassName;
	private String sourceMethodName;
	private transient boolean needToInferCaller;

	public JDKLogRecord(Level level, String msg) {
		super(level, msg);
		needToInferCaller = true;
	}

	public String getSourceClassName() {
		if (needToInferCaller) {
			inferCaller();
		}
		return sourceClassName;
	}

	public void setSourceClassName(String sourceClassName) {
		this.sourceClassName = sourceClassName;
		needToInferCaller = false;
	}

	public String getSourceMethodName() {
		if (needToInferCaller) {
			inferCaller();
		}
		return sourceMethodName;
	}

	public void setSourceMethodName(String sourceMethodName) {
		this.sourceMethodName = sourceMethodName;
		needToInferCaller = false;
	}
	
	public JDKLogRecord thrown(Throwable thrown) {
        this.setThrown(thrown);
        return this;
    }

	private void inferCaller() {
		needToInferCaller = false;
		Throwable throwable = new Throwable();

		boolean lookingForLogger = true;
		for (final StackTraceElement frame : throwable.getStackTrace()) {
			String cname = frame.getClassName();
			boolean isLoggerImpl = isLoggerImplFrame(cname);
			if (lookingForLogger) {
				if (isLoggerImpl) {
					lookingForLogger = false;
				}
			} else {
				if (!isLoggerImpl) {
					if (!cname.startsWith("java.lang.reflect.") && !cname.startsWith("sun.reflect.")) {
						setSourceClassName(cname);
						setSourceMethodName(frame.getMethodName());
						return;
					}
				}
			}
		}
	}

	private boolean isLoggerImplFrame(String cname) {
		return cname.equals(FQCN);
	}
}
