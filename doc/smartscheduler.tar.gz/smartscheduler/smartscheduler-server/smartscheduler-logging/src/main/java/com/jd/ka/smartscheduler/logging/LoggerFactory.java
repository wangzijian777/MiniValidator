/**
 * 
 */
package com.jd.ka.smartscheduler.logging;

import java.util.concurrent.ConcurrentHashMap;

import com.jd.ka.smartscheduler.logging.jdk.JDKLoggerFactory;
import com.jd.ka.smartscheduler.logging.log4j.Log4jLoggerFactory;
import com.jd.ka.smartscheduler.logging.slf4j.Slf4jLoggerFactory;

/**
 * @author qiulong
 *
 */
public abstract class LoggerFactory {
	private static final String SPACE = " ";
	private static final String[] EMPTY = null;
	private static ConcurrentHashMap<String, Logger> loggers = new ConcurrentHashMap<String, Logger>();
	private static LoggerFactory defaultFactory = new JDKLoggerFactory();

	static {
		try {
			Class<?> loggerClazz = Class.forName("org.apache.log4j.Logger");
			loggerClazz.getMethod("setLevel",
					Class.forName("org.apache.log4j.Level"));
			defaultFactory = new Log4jLoggerFactory();
		} catch (Throwable e) {
			try {
				Class.forName("org.slf4j.Logger");
				defaultFactory = new Slf4jLoggerFactory();
			} catch (Throwable e1) {
			}
		}
	}

	public static void setDefaultLoggerFactory(LoggerFactory defaultFactory) {
		if (defaultFactory == null) {
			throw new NullPointerException(
					"LoggerFactory instance cannot be Null");
		}
		LoggerFactory.defaultFactory = defaultFactory;
	}

	public static Logger getLogger(String name) {
		return getLogger(name.intern(), EMPTY);
	}

	public static Logger getLogger(String name, String... prefixes) {
		Logger logger = loggers.get(name);
		if (logger == null) {
			String prefix = null;
			if (prefixes != null && prefixes.length > 0) {
				StringBuilder sb = new StringBuilder();
				for (String prefixX : prefixes) {
					if (prefixX != null) {
						if (prefixX.equals(SPACE)) {
							sb.append(" ");
						} else {
							sb.append("[").append(prefixX).append("]");
						}
					}
				}
				if (sb.length() > 0) {
					sb.append(" ");
					prefix = sb.toString();
				}
			}
			if (prefix != null) {
				logger = defaultFactory.newInstance(prefix.intern(), name);
			} else {
				logger = defaultFactory.newInstance(null, name);
			}
			Logger exist = loggers.putIfAbsent(name, logger);
			if (exist != null) {
				logger = exist;
			}
		}
		return logger;
	}

	public static Logger getLogger(Class<?> clazz) {
		return getLogger(clazz.getName());
	}

	public static Logger getLogger(Class<?> clazz, String... prefixs) {
		return getLogger(clazz.getName(), prefixs);
	}

	abstract protected Logger newInstance(String prefix, String name);

}
