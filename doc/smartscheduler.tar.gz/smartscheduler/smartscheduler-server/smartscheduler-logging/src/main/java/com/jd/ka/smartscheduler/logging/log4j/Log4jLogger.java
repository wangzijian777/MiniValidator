package com.jd.ka.smartscheduler.logging.log4j;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.jd.ka.smartscheduler.logging.AbstractLogger;

/**
 * 
 * @author qiulong
 *
 */
public class Log4jLogger extends AbstractLogger {
	private final Logger logger;
	private final String FQCN = AbstractLogger.class.getName();

	public Log4jLogger(String prefix, String name) {
		super(prefix);
		this.logger = Logger.getLogger(name);
	}

	@Override
	public void setLevel(String level) {
		if (level == null) {
			logger.setLevel(null);
		} else if ("error".equalsIgnoreCase(level)) {
			logger.setLevel(Level.ERROR);
		} else if ("warn".equalsIgnoreCase(level)) {
			logger.setLevel(Level.WARN);
		} else if ("info".equalsIgnoreCase(level)) {
			logger.setLevel(Level.INFO);
		} else if ("debug".equalsIgnoreCase(level)) {
			logger.setLevel(Level.DEBUG);
		} else if ("trace".equalsIgnoreCase(level)) {
			logger.setLevel(Level.TRACE);
		}
	}

	@Override
	public String getLevel() {
		if (logger.getLevel() == null) {
            return null;
        }
        return logger.getLevel().toString();
	}

	@Override
	public boolean isTraceEnabled() {
		return logger.isTraceEnabled();
	}

	@Override
	public boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}

	@Override
	public boolean isInfoEnabled() {
		return logger.isInfoEnabled();
	}

	@Override
	public boolean isWarnEnabled() {
		return logger.isEnabledFor(Level.WARN);
	}

	@Override
	public boolean isErrorEnabled() {
		return logger.isEnabledFor(Level.ERROR);
	}

	@Override
	protected void internalTrace(String msg) {
		logger.log(FQCN, Level.TRACE, msg, null);
	}

	@Override
	protected void internalTrace(String msg, Throwable cause) {
		logger.log(FQCN, Level.TRACE, msg, cause);
	}

	@Override
	protected void internalDebug(String msg) {
		logger.log(FQCN, Level.DEBUG, msg, null);
	}

	@Override
	protected void internalDebug(String msg, Throwable cause) {
		logger.log(FQCN, Level.DEBUG, msg, cause);
	}

	@Override
	protected void internalInfo(String msg) {
		logger.log(FQCN, Level.INFO, msg, null);
	}

	@Override
	protected void internalInfo(String msg, Throwable cause) {
		logger.log(FQCN, Level.INFO, msg, cause);
	}

	@Override
	protected void internalWarn(String msg) {
		logger.log(FQCN, Level.WARN, msg, null);
	}

	@Override
	protected void internalWarn(String msg, Throwable cause) {
		logger.log(FQCN, Level.WARN, msg, cause);
	}

	@Override
	protected void internalError(String msg) {
		logger.log(FQCN, Level.ERROR, msg, null);
	}

	@Override
	protected void internalError(String msg, Throwable cause) {
		logger.log(FQCN, Level.ERROR, msg, cause);
	}

}
