/**
 * 
 */
package com.jd.ka.smartscheduler.logging.log4j;

import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;

/**
 * @author qiulong
 *
 */
public class Log4jLoggerFactory extends LoggerFactory {

	@Override
	protected Logger newInstance(String prefix, String name) {
		return new Log4jLogger(prefix, name);
	}

}
