/**
 * 
 */
package com.jd.ka.smartscheduler.logging.jdk;

import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;

/**
 * @author qiulong
 *
 */
public class JDKLoggerFactory extends LoggerFactory {
	
	@Override
	protected Logger newInstance(String prefix, String name) {
		final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(name);
        return new JDKLogger(prefix, logger);
	}

}
