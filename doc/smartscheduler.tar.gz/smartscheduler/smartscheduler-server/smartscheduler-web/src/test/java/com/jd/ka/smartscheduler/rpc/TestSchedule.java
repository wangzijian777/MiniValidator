package com.jd.ka.smartscheduler.rpc;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.ka.smartscheduler.core.builder.TaskBuilder;
import com.jd.ka.smartscheduler.server.context.SmartSchedulerContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({ "classpath:spring-config-test.xml" })
public class TestSchedule {
	@Autowired
	private SmartSchedulerContext context;

	@Test
	public void testAddTask() {
		testRemoveTask();
		context.getSmartScheduler().addTask(
				TaskBuilder.newAdvancedTaskBuilder("test", "test")
						.setCronExpression("0 0/1 * * * ?").build());

		try {
			Thread.sleep(100000000L);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testRemoveTask() {
		context.getSmartScheduler().removeTask(
				TaskBuilder.newAdvancedTaskBuilder("test", "test").build());
	}

}
