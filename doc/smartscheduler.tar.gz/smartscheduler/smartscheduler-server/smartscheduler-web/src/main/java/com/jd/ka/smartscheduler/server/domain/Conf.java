package com.jd.ka.smartscheduler.server.domain;

/**
 * 配置项
 * @author qiulong
 *
 */
public class Conf {
	/**
	 * 全局配置
	 */
	public static final int GLOBAL  =1;

	/**
	 * 配置项分类
	 */
	private int classify;
	
	/**
	 * 配置项名称
	 */
	private String name;
	
	/**
	 * 配置项值
	 */
	private String value;

	public int getClassify() {
		return classify;
	}

	public void setClassify(int classify) {
		this.classify = classify;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public String getString() {
		return value;
	}
	
	public int getInt() {
		return Integer.valueOf(value);
	}
	
	public boolean getBoolean() {
		return Boolean.valueOf(value);
	}
	
	public long getLong() {
		return Long.valueOf(value);
	}
	
}
