package com.jd.ka.smartscheduler.server.rpc.listener;

import java.util.List;

import org.springframework.stereotype.Component;

import com.jd.ka.smartscheduler.core.event.Event;

/**
 * Task调度事件监听
 * @author qiulong
 *
 */
@Component
public class TaskScheduleEventListener extends AbstractTaskEventListener<TaskScheduled> {

	@Override
	public Event matchEvent() {
		return Event.TaskExecuted;
	}

	@Override
	protected void innerFireEvent(List<TaskScheduled> taskEventList, TaskUniqueIdentifier tui) {
		for (TaskScheduled taskScheduled : taskEventList) {
			taskScheduled.wasScheduled(tui);
		}
	}

	@Override
	protected Class<TaskScheduled> matchClass() {
		return TaskScheduled.class;
	}
	
}
