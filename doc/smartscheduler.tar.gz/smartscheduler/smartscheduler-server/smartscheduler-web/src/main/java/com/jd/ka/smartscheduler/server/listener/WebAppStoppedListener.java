package com.jd.ka.smartscheduler.server.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStoppedEvent;
import org.springframework.stereotype.Component;

import com.jd.ka.smartscheduler.server.context.SmartSchedulerContext;

@Component
public class WebAppStoppedListener implements ApplicationListener<ContextStoppedEvent> {

	@Autowired
	private SmartSchedulerContext smartSchedulerContext;
	
	@Override
	public void onApplicationEvent(ContextStoppedEvent event) {
		try {
			smartSchedulerContext.stop();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
