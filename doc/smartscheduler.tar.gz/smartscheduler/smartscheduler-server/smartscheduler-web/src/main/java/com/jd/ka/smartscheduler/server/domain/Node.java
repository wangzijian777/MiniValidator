package com.jd.ka.smartscheduler.server.domain;

import java.util.Date;

/**
 * 执行任务的节点描述
 * @author qiulong
 *
 */
public class Node {
	public static final int WAITTING =0;
	public static final int RUNNING = 1;
	public static final int FAILURE = 2;
	public static final int INTERRUPT = 3;
	
	public static final int STATUS_DISABLE = 0;
	public static final int STATUS_ENABLE = 1;
	
	/**
	 * 节点id
	 */
	private int id;
	
	/**
	 * 任务id
	 */
	private int taskId;
	
	/**
	 * 访问节点的URL
	 */
	private String url;
	/**
	 * 节点可用状态（0：不可用，1：可用）
	 */
	private int status;
	
	/**
	 * 节点运行状态（0：等待执行，1：执行中）
	 */
	private int runningStatus;
	
	private String message;
	
	/**
	 * 节点开始执行时间
	 */
	private Date startTime;
	
	/**
	 * 节点结束执行时间
	 * @return
	 */
	private Date endTime;
	
	public int getId() {
		return id;
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public String getUrl() {
		return url;
	}

	public int getStatus() {
		return status;
	}

	public int getRunningStatus() {
		return runningStatus;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public void setRunningStatus(int runningStatus) {
		this.runningStatus = runningStatus;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Node other = (Node) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Node [id=" + id + ", taskId=" + taskId + ", url=" + url
				+ ", status=" + status + ", runningStatus=" + runningStatus
				+ ", message=" + message + ", startTime=" + startTime
				+ ", endTime=" + endTime + "]";
	}

}
