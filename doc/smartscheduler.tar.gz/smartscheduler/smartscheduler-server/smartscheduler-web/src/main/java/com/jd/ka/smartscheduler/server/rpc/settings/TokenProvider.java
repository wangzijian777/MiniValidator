package com.jd.ka.smartscheduler.server.rpc.settings;

import java.util.Map;


/**
 * 
 * @author qiulong
 *
 */
public interface TokenProvider {
	Map<String, String> getToken();
}
