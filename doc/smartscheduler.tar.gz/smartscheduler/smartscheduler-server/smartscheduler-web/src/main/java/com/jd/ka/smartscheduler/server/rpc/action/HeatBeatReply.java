package com.jd.ka.smartscheduler.server.rpc.action;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 客户端心跳应答
 * 
 * @author qiulong
 *
 */
@Controller
@RequestMapping("/hb")
public class HeatBeatReply {
	private static final String PING = "ping";
	private static final String PONG = "pong";

	@RequestMapping
	@ResponseBody
	public String handle(@RequestBody String ping) {
		if(PING.equals(ping)) {
			return PONG;
		}
		return null;
	}

}
