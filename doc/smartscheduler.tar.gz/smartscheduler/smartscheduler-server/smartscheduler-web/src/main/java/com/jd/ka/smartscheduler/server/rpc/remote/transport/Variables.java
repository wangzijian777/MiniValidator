package com.jd.ka.smartscheduler.server.rpc.remote.transport;




/**
 * 请求参数
 * @author qiulong
 *
 */
public interface Variables<K, V> {
	void add(K key, V value);
	
	boolean contain(K key);
	
	V get(K key);
	
	boolean hasNext();
	
	K nextKey();
}
