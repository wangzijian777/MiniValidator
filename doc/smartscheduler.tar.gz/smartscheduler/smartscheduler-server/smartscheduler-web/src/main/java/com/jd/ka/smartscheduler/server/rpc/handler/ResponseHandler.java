package com.jd.ka.smartscheduler.server.rpc.handler;

import com.jd.ka.smartscheduler.server.rpc.remote.transport.Response;

/**
 * 调用节点后的响应处理
 * @author qiulong
 *
 */
public interface ResponseHandler<T> {

	/**
	 * 处理相应结果
	 * @param response
	 */
	void handle(Response<T> response);
	
}
