package com.jd.ka.smartscheduler.server.rpc.schedule;

import java.util.ArrayList;
import java.util.List;

import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode.Status;

/**
 * 任务调用链
 * 
 * @author qiulong
 *
 */
public abstract class ScheduleChain {
	private ScheduleChain next;

	protected ScheduleChain next() {
		return this.next;
	}

	public void setNext(ScheduleChain next) {
		this.next = next;
	}

	public boolean run(Task task, List<RemoteNode> nodes) {
		if(innerRun(task, nodes)) {
			if(this.next != null) {
				return next.run(task, nodes);
			}
			return true;
		}
		return false;
	}
	
	protected abstract boolean innerRun(Task task, List<RemoteNode> nodes);

	/**
	 * 提取指定状态的节点
	 * @param status 指定状态
	 * @param nodes 所有节点
	 * @return
	 */
	protected List<RemoteNode> extractNodes(Status status, List<RemoteNode> nodes) {
		List<RemoteNode> list = new ArrayList<RemoteNode>();
		for (RemoteNode node : nodes) {
			if(node.getStatus() == status) {
				list.add(node);
			}
		}
		return list;
	}
	
}
