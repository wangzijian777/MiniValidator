package com.jd.ka.smartscheduler.server.rpc.schedule;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall.ExecuteException;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Request;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Response;
import com.jd.ka.smartscheduler.server.rpc.shards.Shards;

/**
 * 节点存活和繁忙检测
 * 
 * @author qiulong
 *
 */
public class NodeCheck extends ScheduleChain {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Request<ACK[]> request;

	@Override
	protected boolean innerRun(Task task, List<RemoteNode> nodes) {
		// 检查每个节点状态
		for (RemoteNode node : nodes) {
			checkNode(task, node);
		}
		return true;
	}

	private void checkNode(Task task, RemoteNode node) {
		try {
			Response<ACK[]> response = NodeCall.use(request).callNode(node).withTask(task).ping().actionGet();
			ACK[] acks = response.getResponse();
			for (ACK ack : acks) {
				switch(ack.getStatus()) {
				case BUSY: {
					node.nodeBusy();
					String msg = ack.getMessage();
					if(msg != null && !msg.isEmpty()) {
						Shards shards = new Shards();
						shards.add(new Gson().fromJson(msg, int[].class));
						node.setPreviousShards(shards);
						if(logger.isDebugEnabled()) {
							logger.debug("Node [{}] is busy with task [{}] and shards [{}] now.", node.url(), task.getName(), shards);
						}
					}
					break;
				}
				case ALIVE: {
					node.nodeAlive();
					break;
				}
				default:
					break;
				}
			}
		} catch (ExecuteException e) {
			logger.error("Exception happend when check node [{}] alive", node.url());
		}
	}

}
