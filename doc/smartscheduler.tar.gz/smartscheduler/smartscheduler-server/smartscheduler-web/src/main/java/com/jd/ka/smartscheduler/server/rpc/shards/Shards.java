package com.jd.ka.smartscheduler.server.rpc.shards;

import java.util.LinkedList;

import com.google.common.primitives.Ints;
import com.google.gson.Gson;

/**
 * 
 * @author qiulong
 *
 */
public class Shards {
	private LinkedList<Integer> shards = new LinkedList<Integer>();
	
	public void add(int mod) {
		shards.add(mod);
	}
	
	public void add(int[] shards) {
		if(shards != null && shards.length > 0) {
			for (int i : shards) {
				add(i);
			}
		}
	}
	
	public void addByOtherShards(Shards other) {
		if(other != null) {
			shards.addAll(other.shards);
		}
	}
	
	public void remove(int shard) {
		shards.remove(shard);
	}
	
	public void remove(int[] shards) {
		if(shards != null && shards.length > 0) {
			for (int i : shards) {
				remove(i);
			}
		}
	}
	
	public int getAndRemove() {
		return shards.removeFirst();
	}
	
	public void removeByOtherShards(Shards other) {
		if(other != null) {
			shards.removeAll(other.shards);
		}
	}
	
	public boolean contain(int shard) {
		return shards.contains(shard);
	}
	
	public boolean isEmpty() {
		return shards.isEmpty();
	}
	
	public int[] toArray() {
		return Ints.toArray(shards);
	}
	
	@Override
	public String toString() {
		return new Gson().toJson(toArray());
	}
	
}
