package com.jd.ka.smartscheduler.server.rpc.listener;

/**
 * 任务执行失败接口
 * @author qiulong
 *
 */
public interface TaskResumed {
	
	void wasResumed(TaskUniqueIdentifier tui);

}
