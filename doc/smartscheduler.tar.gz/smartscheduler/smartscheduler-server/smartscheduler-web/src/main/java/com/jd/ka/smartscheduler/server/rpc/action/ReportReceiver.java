package com.jd.ka.smartscheduler.server.rpc.action;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.jd.ka.smartscheduler.server.rpc.handler.ResponseHandler;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Response;

/**
 * 汇报信息接收器
 * 
 * @author qiulong
 *
 */
@Controller
@RequestMapping("/report")
public class ReportReceiver {
	private static final String SUCCESS = "success";
	private static final String FAILURE = "failure";
	@Autowired
	private ResponseHandler<ACK[]> responseHandler;

	@RequestMapping
	@ResponseBody
	public String handle(Reader reader) throws IOException {
		BufferedReader br = null;
		try {
			br = new BufferedReader(reader);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while((line=br.readLine()) != null) {
				sb.append(line);
			}
			if (sb.length() > 0) {
				final ACK[] acks = new Gson().fromJson(sb.toString(), ACK[].class);
				responseHandler.handle(new Response<ACK[]>() {
					@Override
					public ACK[] getResponse() {
						return acks;
					}
				});
				return SUCCESS;
			}
			return FAILURE;
		} finally {
			if(br != null) {
				br.close();
			}
		}
	}

}
