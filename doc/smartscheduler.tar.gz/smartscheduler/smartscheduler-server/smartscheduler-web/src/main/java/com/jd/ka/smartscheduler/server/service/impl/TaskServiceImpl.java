package com.jd.ka.smartscheduler.server.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.ka.smartscheduler.core.SmartScheduler;
import com.jd.ka.smartscheduler.core.builder.AdvancedTaskBuilder;
import com.jd.ka.smartscheduler.core.builder.SimpleTaskBuilder;
import com.jd.ka.smartscheduler.core.builder.TaskBuilder;
import com.jd.ka.smartscheduler.core.task.TimeUnit;
import com.jd.ka.smartscheduler.server.context.SmartSchedulerContext;
import com.jd.ka.smartscheduler.server.dao.TaskDao;
import com.jd.ka.smartscheduler.server.domain.Node;
import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.domain.Task.Status;
import com.jd.ka.smartscheduler.server.service.NodeService;
import com.jd.ka.smartscheduler.server.service.TaskService;

/**
 * 
 * @author qiulong
 *
 */
@Service
public class TaskServiceImpl implements TaskService {
	@Autowired
	private NodeService nodeService;
	@Autowired
	private TaskDao taskDao;
	@Autowired
	private SmartSchedulerContext smartSchedulerContext;

	@Override
	public Task getTask(String name, String group) {
		Task task = taskDao.getTask(name, group);
		if (task == null) {
			return null;
		}
		List<Node> nodes = nodeService.getNodesByTaskId(task.getId());
		task.setNodes(nodes);
		return task;
	}
	
	@Override
	public Task getTask(int taskId) {
		Task task = taskDao.getTask(taskId);
		if (task == null) {
			return null;
		}
		List<Node> nodes = nodeService.getNodesByTaskId(task.getId());
		task.setNodes(nodes);
		return task;
	}

	@Override
	public List<Task> queryTaskByApp(String appName) {
		return taskDao.queryTaskByApp(appName);
	}

	@Override
	public List<Task> queryAllTask(int pageSize, int pageIndex) {
		//TODO
		return null;
	}

	@Override
	public boolean addTask(final Task task) {
		if (taskDao.insertTask(task)) {
			TaskBuilder builder = createTaskBuilder(task);
			return getSmartScheduler().addTask(builder.build());
		}
		return false;
	}

	@Override
	public boolean updateTask(Task task) {
		if(taskDao.updateTask(task)) {
			TaskBuilder builder = createTaskBuilder(task);
			return getSmartScheduler().updateTask(builder.build());
		}
		return false;
	}

	@Override
	public boolean changeStatus(int taskId, Status status) {
		return taskDao.updateTaskStatus(taskId, status.getCode());
	}

	@Override
	public boolean setTaskFireTime(int taskId, Date currentFireTime,
			Date nextFireTime) {
		return taskDao.updateFireTime(taskId, currentFireTime, nextFireTime);
	}

	@Override
	public boolean deleteTask(int taskId) {
		Task task = taskDao.getTask(taskId);
		if(task != null && taskDao.deleteTask(taskId)) {
			TaskBuilder builder = createTaskBuilder(task);
			return getSmartScheduler().removeTask(builder.build());
		}
		return false;
	}
	
	private SmartScheduler getSmartScheduler() {
		return smartSchedulerContext.getSmartScheduler();
	}
	
	private TaskBuilder createTaskBuilder(Task task) {
		TaskBuilder builder;
		if (task.getType() == Task.Type.SIMPLE) {
			SimpleTaskBuilder stb = TaskBuilder.newSimpleTaskBuilder(task.getName(), task.getGroup());
			stb.setIntervalTime(task.getInterval(), TimeUnit.SECONDS);
			int repeat = task.getRepeat();
			if (repeat == 0) {
				stb.repeatForever();
			} else {
				stb.setRepeatCount(repeat);
			}
			builder = stb;
		} else {
			AdvancedTaskBuilder atb = TaskBuilder.newAdvancedTaskBuilder(task.getName(), task.getGroup()).setCronExpression(task.getCron());
			builder = atb;
		}
		builder.startAt(task.getStartTime()).endAt(task.getEndTime()).setDescription(task.getDescription());
		return builder;
	}

}
