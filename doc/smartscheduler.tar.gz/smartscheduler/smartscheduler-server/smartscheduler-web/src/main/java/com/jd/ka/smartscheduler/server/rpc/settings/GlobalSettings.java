package com.jd.ka.smartscheduler.server.rpc.settings;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jd.ka.smartscheduler.server.domain.Conf;
import com.jd.ka.smartscheduler.server.service.ConfService;

/**
 * 
 * @author qiulong
 *
 */
@Component
public class GlobalSettings implements Settings {
	@Autowired
	private ConfService confService;

	private TokenProvider tokenProvider = new TokenProvider() {

		@Override
		public Map<String, String> getToken() {
			//TODO 
			return null;
		}
	};

	// FIXME ??? Use cache?
	@Override
	public Map<String, String> settings() {
		Map<String, String> map = new HashMap<String, String>();
		prepareToken(map);
		List<Conf> confs = confService.queryConf(Conf.GLOBAL);
		for (Conf conf : confs) {
			map.put(conf.getName(), conf.getString());
		}
		return map;
	}

	private void prepareToken(Map<String, String> map) {
		map.put("token", "123");
//		map.putAll(tokenProvider.getToken());
	}
}
