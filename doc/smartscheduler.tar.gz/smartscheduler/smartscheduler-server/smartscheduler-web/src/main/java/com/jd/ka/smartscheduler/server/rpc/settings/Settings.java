package com.jd.ka.smartscheduler.server.rpc.settings;

import java.util.Map;

/**
 * 
 * @author qiulong
 *
 */
public interface Settings {
	Map<String, String> settings();
}
