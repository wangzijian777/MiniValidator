package com.jd.ka.smartscheduler.server.rpc.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK.ACKStatus;
import com.jd.ka.smartscheduler.server.service.NodeService;

/**
 * 
 * @author qiulong
 *
 */
@Component
public class TaskInterruptHandler extends AbstractACKHandler {
	@Autowired
	private NodeService nodeService;
	
	@Override
	protected void innerHandle(ACK ack) {
		nodeService.setRunning(ack.getNodeId());
	}

	@Override
	protected ACKStatus match() {
		return ACKStatus.INTERRUPT;
	}

}
