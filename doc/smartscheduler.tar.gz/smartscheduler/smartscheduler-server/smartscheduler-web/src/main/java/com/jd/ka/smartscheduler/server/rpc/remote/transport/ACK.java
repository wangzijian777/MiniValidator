package com.jd.ka.smartscheduler.server.rpc.remote.transport;



public class ACK {
	/**
	 * 流水号
	 */
	protected String serialNum;

	/**
	 * Job id
	 */
	protected int jobId;

	/**
	 * 执行状态
	 */
	protected ACKStatus status;

	/**
	 * 返回的信息
	 */
	protected String message;

	/**
	 * 创建时间（单位：秒）
	 */
	protected long timestamp;

	/**
	 * 当前节点名称
	 */
	protected int nodeId;
	
	public enum ACKStatus {
		/*任务执行状态*/
		/**
		 * 开始执行
		 */
		BEGIN,
		/**
		 * 执行完成
		 */
		DONE,
		/**
		 * 调度失败
		 */
		FAILURE,
		/**
		 * 执行中断
		 */
		INTERRUPT,
		
		/*其它状态*/
		/**
		 * 节点繁忙
		 */
		BUSY,
		/**
		 * 存活状态
		 */
		ALIVE,
		;
	}

	public String getSerialNum() {
		return serialNum;
	}

	public int getJobId() {
		return jobId;
	}

	public ACKStatus getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public int getNodeId() {
		return nodeId;
	}

	@Override
	public String toString() {
		return "ACK [serialNum=" + serialNum + ", jobId=" + jobId + ", status="
				+ status + ", message=" + message + ", timestamp=" + timestamp
				+ ", nodeId=" + nodeId + "]";
	}

}
