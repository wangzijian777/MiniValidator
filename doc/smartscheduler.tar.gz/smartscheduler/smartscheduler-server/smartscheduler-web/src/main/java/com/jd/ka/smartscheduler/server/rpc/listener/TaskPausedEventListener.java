package com.jd.ka.smartscheduler.server.rpc.listener;

import java.util.List;

import org.springframework.stereotype.Component;

import com.jd.ka.smartscheduler.core.event.Event;

/**
 * 任务挂起事件监听
 * @author qiulong
 *
 */
@Component
public class TaskPausedEventListener extends AbstractTaskEventListener<TaskPaused> {

	@Override
	public Event matchEvent() {
		return Event.TaskPaused;
	}
	
	@Override
	protected Class<TaskPaused> matchClass() {
		return TaskPaused.class;
	}

	@Override
	protected void innerFireEvent(List<TaskPaused> taskEventList,
			TaskUniqueIdentifier tui) {
		for (TaskPaused taskPaused : taskEventList) {
			taskPaused.wasPaused(tui);
		}
	}

}
