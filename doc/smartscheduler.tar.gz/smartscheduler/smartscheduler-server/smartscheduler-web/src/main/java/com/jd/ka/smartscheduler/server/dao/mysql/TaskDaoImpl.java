package com.jd.ka.smartscheduler.server.dao.mysql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.jd.ka.smartscheduler.server.dao.TaskDao;
import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.domain.Task.Status;
import com.jd.ka.smartscheduler.server.domain.Task.Type;

/**
 * 
 * @author qiulong
 *
 */
@Repository
public class TaskDaoImpl extends JdbcTemplate implements ResultSetExtractor<List<Task>>, TaskDao {

	@Override
	public List<Task> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		List<Task> list = new ArrayList<Task>();
		while (rs.next()) {
			Task task = new Task();
			task.setId(rs.getInt("ID"));
			task.setName(rs.getString("TASK_NAME"));
			task.setGroup(rs.getString("TASK_GROUP"));
			task.setApp(rs.getString("APP"));
			task.setStatus(Status.parse(rs.getInt("TASK_STATUS")));
			task.setDescription(rs.getString("DESCRIPTION"));
			task.setType(Type.parse(rs.getInt("TYPE")));
			task.setLimit(rs.getInt("LIMITNUM"));
			task.setShardsNum(rs.getInt("SHARDSNUM"));
			task.setDistributed(rs.getInt("DISTRIBUTED") > 0);
			task.setThreadnum(rs.getInt("THREADNUM"));
			task.setRepeat(rs.getInt("REPEAT"));
			task.setInterval(rs.getInt("INTERVAL"));
			task.setCron(rs.getString("CRON"));
			task.setStartTime(rs.getTimestamp("START_TIME"));
			task.setEndTime(rs.getTimestamp("END_TIME"));
			task.setPreFireTime(rs.getTime("CURRFIRE_TIME"));
			task.setNextFireTime(rs.getTime("NEXTFIRE_TIME"));
			list.add(task);
		}
		return list;
	}

	@Override
	public Task getTask(String name, String group) {
		List<Task> tasks = this.query(
				"SELECT * FROM SS_TASK WHERE TASK_NAME=? AND TASK_GROUP=?",
				this, name, group);
		if (tasks.size() > 0) {
			return tasks.get(0);
		}
		return null;
	}

	@Override
	public boolean updateTask(Task task) {
		return this.update(
				"UPDATE SS_TASK SET TASK_NAME=?,TASK_GROUP=?,APP=?,TASK_STATUS=?,DESCRIPTION=?,TYPE=?,LIMITNUM=?,SHARDSNUM=?,DISTRIBUTED=?,THREADNUM=?,REPEAT=?,INTERVAL=?,CRON=?,START_TIME=?,END_TIME=?,CURRFIRE_TIME=?,NEXTFIRE_TIME=?,MENDER=?,UPD_TIME=now() WHERE ID =? ",
				task.getName(), task.getGroup(), task.getApp(), 
				task.getStatus(), task.getDescription(), task.getType().getCode(),
				task.getLimit(), task.getShardsNum(), (task.isDistributed() ? 1: 0), 
				task.getThreadnum(), task.getRepeat(), task.getInterval(), 
				task.getCron(), task.getStartTime(),task.getEndTime(), 
				task.getPreFireTime(), task.getNextFireTime(), 1, task.getId()) > 0;
	}

	@Override
	public boolean updateTaskStatus(int taskId, int status) {
		return this.update(
				"UPDATE SS_TASK SET TASK_STATUS=? WHERE ID=?", 
				status, taskId) > 0;
	}

	@Override
	public boolean updateFireTime(int taskId, Date currentFireTime,
			Date nextFireTime) {
		return this.update(
				"UPDATE SS_TASK SET CURRFIRE_TIME=?,NEXTFIRE_TIME=? WHERE ID=?", 
				currentFireTime, nextFireTime, taskId) > 0;
	}

	@Override
	public boolean insertTask(Task task) {
		return this.update(
				"INSERT INTO SS_TASK(TASK_NAME,TASK_GROUP,APP,TASK_STATUS,DESCRIPTION,TYPE,LIMITNUM,SHARDSNUM,DISTRIBUTED,THREADNUM,REPEAT,INTERVAL,CRON,START_TIME,END_TIME,CURRFIRE_TIME,NEXTFIRE_TIME,CREATOR,CREATE_TIME) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,now())",
				task.getName(), task.getGroup(), task.getApp(), 
				task.getStatus(), task.getDescription(), task.getType().getCode(),
				task.getLimit(), task.getShardsNum(), (task.isDistributed() ? 1: 0), 
				task.getThreadnum(), task.getRepeat(), task.getInterval(), 
				task.getCron(), task.getStartTime(),task.getEndTime(), 
				task.getPreFireTime(), task.getNextFireTime(), 1) > 0;
	}

	@Override
	public List<Task> queryTaskByApp(String app) {
		List<Task> tasks = this.query(
				"SELECT * FROM SS_TASK WHERE APP=?",
				this, app);
		return tasks;
	}

	@Override
	public boolean deleteTask(int taskId) {
		return this.update("DELETE FROM SS_TASK WHERE ID=?", taskId) > 0;
	}

	@Override
	public Task getTask(int taskId) {
		List<Task> tasks = this.query(
				"SELECT * FROM SS_TASK WHERE ID=?",
				this, taskId);
		if (tasks.size() > 0) {
			return tasks.get(0);
		}
		return null;
	}
}
