package com.jd.ka.smartscheduler.server.rpc.schedule;

import com.jd.ka.smartscheduler.server.domain.Task;

/**
 *
 * @author qiulong
 * 
 */
public class UnwantedTask extends DummyTask {

	public UnwantedTask(Task task) {
		super(task);
	}
}
