package com.jd.ka.smartscheduler.server.rpc.remote.transport;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.server.rpc.settings.Settings;

/**
 * 发送请求并返回ACK信息
 * 
 * @author qiulong
 *
 */
@Component
public class Request2ACKResponse implements Request<ACK[]> {
	private Logger logger = LoggerFactory.getLogger(getClass());
	private Object[] empty = new Object[0];
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private Settings settings;

	@Override
	public Response<ACK[]> doRequest(String url,
			Variables<String, Object> variables) throws RequestException {
		prepareGlobalSettings(variables);
		try {
			MultiValueMap<String, String> map = convertVariables2MultiValueMap(variables);
			if (logger.isDebugEnabled()) {
				String var = new Gson().toJson(map);
				logger.debug("Send request to [{}] with parameter [{}]", url, var);
			}
			final String json = restTemplate.postForObject(url, map, String.class, empty);
			return new Response<ACK[]>() {
				@Override
				public ACK[] getResponse() {
					if (StringUtils.isEmpty(json)) {
						return new ACK[0];
					}
					Gson gson = new Gson();
					return gson.fromJson(json, ACK[].class);
				}
			};
		} catch (Exception e) {
			logger.error("Exception happened when send request to [{}], Exception: {}", url, e.getMessage());
			throw new RequestException(e);
		}
	}

	private MultiValueMap<String, String> convertVariables2MultiValueMap(
			Variables<String, Object> variables) {
		MultiValueMap<String, String> varMap = new LinkedMultiValueMap<String, String>();
		while (variables.hasNext()) {
			String key = variables.nextKey();
			varMap.add(key, (String) variables.get(key));
		}
		return varMap;
	}

	private void prepareGlobalSettings(Variables<String, Object> urlVariables) {
		Map<String, String> map = settings.settings();
		if (map == null || map.isEmpty()) {
			return;
		}
		Set<String> keySet = map.keySet();
		for (Iterator<String> iter = keySet.iterator(); iter.hasNext();) {
			String key = iter.next();
			if (!urlVariables.contain(key)) {
				urlVariables.add(key, map.get(key));
			}
		}
	}

}
