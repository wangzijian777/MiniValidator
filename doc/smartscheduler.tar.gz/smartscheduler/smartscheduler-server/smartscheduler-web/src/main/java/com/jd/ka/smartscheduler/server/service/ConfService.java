package com.jd.ka.smartscheduler.server.service;

import java.util.List;

import com.jd.ka.smartscheduler.server.domain.Conf;

/**
 * 配置项相关操作
 * @author qiulong
 *
 */
public interface ConfService {

	/**
	 * 添加一个配置项
	 * @param conf
	 * @return
	 */
	boolean addConf(Conf conf);
	
	/**
	 * 删除一个配置项
	 * @param conf
	 * @return
	 */
	boolean deleteConf(Conf conf);
	
	/**
	 * 修改一个配置项
	 * @param conf
	 * @return
	 */
	boolean updateConf(Conf conf);
	
	/**
	 * 获取一个配置项
	 * @param classify 配置分类
	 * @param name 配置名称
	 * @return
	 */
	Conf getConf(int classify, String name);
	
	/**
	 * 根据配置分类查询所有配置
	 * @param classify 配置分类
	 * @return
	 */
	List<Conf> queryConf(int classify);

}
