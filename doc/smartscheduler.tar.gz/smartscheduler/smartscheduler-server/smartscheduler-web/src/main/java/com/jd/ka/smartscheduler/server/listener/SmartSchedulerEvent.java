package com.jd.ka.smartscheduler.server.listener;

import org.springframework.context.ApplicationEvent;

import com.jd.ka.smartscheduler.server.context.SmartSchedulerContext;

/**
 * SmartScheduler启动事件
 * @author qiulong
 *
 */
public class SmartSchedulerEvent extends ApplicationEvent {
	private static final long serialVersionUID = 1L;
	
	public SmartSchedulerEvent(Object source) {
		super(source);
		if(!(source instanceof SmartSchedulerContext)) {
			throw new IllegalArgumentException("Source must be instance of [" + SmartSchedulerContext.class + "]");
		}
	}
	
	public SmartSchedulerContext getSmartSchedulerContext() {
		return (SmartSchedulerContext)this.getSource();
	}

}
