package com.jd.ka.smartscheduler.server.rpc.remote.transport;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 采用Map存储的请求参数
 * @author qiulong
 *
 */
public class MapVariables  implements Variables<String, Object> {
	private Map<String, String> variables = new HashMap<String, String>();
	private Iterator<String> iterator;

	@Override
	public void add(String key, Object value) {
		if(value != null) {
			variables.put(key, String.valueOf(value));
		}
	}

	@Override
	public boolean contain(String key) {
		return variables.containsKey(key);
	}

	@Override
	public boolean hasNext() {
		if(iterator == null) {
			iterator = variables.keySet().iterator();
		}
		return iterator.hasNext();
	}

	@Override
	public String nextKey() {
		return iterator.next();
	}

	@Override
	public String get(String key) {
		return variables.get(key);
	}
}
