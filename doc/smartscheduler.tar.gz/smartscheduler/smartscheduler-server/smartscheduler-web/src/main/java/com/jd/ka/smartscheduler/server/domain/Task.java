package com.jd.ka.smartscheduler.server.domain;

import java.util.Collections;
import java.util.Date;
import java.util.List;


/**
 * 
 * @author qiulong
 *
 */
public class Task {
	
	public enum Status {
		INVALID(0), VALID(1);
		private int code;
		Status(int code) {
			this.code = code;
		}
		
		public static Status parse(int code) {
			switch(code) {
				case 0: return INVALID;
				case 1: return VALID;
			}
			throw new IllegalArgumentException(String.valueOf(code));
		}
		public int getCode() {
			return code;
		}
	}
	
	public enum Type {
		SIMPLE(0), ADVANCED(1);
		private int code;
		Type(int code) {
			this.code = code;
		}
		
		public static Type parse(int code) {
			switch(code) {
				case 0: return SIMPLE;
				case 1: return ADVANCED;
			}
			throw new IllegalArgumentException(String.valueOf(code));
		}
		public int getCode() {
			return code;
		}
	}
	
	/**
	 * 任务id
	 */
	private int id;
	/**
	 * 任务名称
	 */
	private String name;
	/**
	 * 任务所属组
	 */
	private String group;
	/**
	 * 任务所属应用
	 */
	private String app;
	/**
	 * 任务状态（0：停止，1：正常）
	 */
	private Status status = Status.INVALID;
	/**
	 * 任务描述
	 */
	private String description;
	/**
	 * 任务类型（0：普通任务，1：高级任务）
	 */
	private Type type;
	/**
	 * 每批次提取的数据量
	 */
	private int limit;
	/**
	 * 是否分布式执行任务（true：是，false：否）
	 */
	private boolean distributed;
	/**
	 * 执行任务的并行线程数量
	 */
	private int threadnum;
	/**
	 * 任务重复次数
	 */
	private int repeat;
	/**
	 * 任务间隔时间（单位：秒）
	 */
	private int interval;
	/**
	 * cron表达式（用于定义高级任务）
	 */
	private String cron;
	/**
	 * 任务开始时间（null表示立即开始）
	 */
	private Date startTime;
	/**
	 * 任务结束时间（null表示永久循环）
	 */
	private Date endTime;
	
	/**
	 * 上次触发时间
	 */
	private Date preFireTime;
	
	/**
	 * 下次触发时间
	 */
	private Date nextFireTime;

	/**
	 * 设置的分片数量
	 */
	private int shardsNum;

	/**
	 * 为任务分配的所有节点
	 */
	private List<Node> nodes;
	
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getGroup() {
		return group;
	}

	public String getApp() {
		return app;
	}

	public Status getStatus() {
		return status;
	}

	public String getDescription() {
		return description;
	}

	public Type getType() {
		return type;
	}

	public int getLimit() {
		return limit;
	}

	public boolean isDistributed() {
		return distributed;
	}

	public int getThreadnum() {
		return threadnum;
	}

	public int getRepeat() {
		return repeat;
	}

	public int getInterval() {
		return interval;
	}

	public String getCron() {
		return cron;
	}

	public Date getStartTime() {
		return startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public List<Node> getNodes() {
		if (nodes == null) {
			return Collections.emptyList();
		}
		return nodes;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public void setApp(String app) {
		this.app = app;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public void setDistributed(boolean distributed) {
		this.distributed = distributed;
	}

	public void setThreadnum(int threadnum) {
		this.threadnum = threadnum;
	}

	public void setRepeat(int repeat) {
		this.repeat = repeat;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	public void setCron(String cron) {
		this.cron = cron;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public void setNodes(List<Node> nodes) {
		this.nodes = nodes;
	}

	public int getShardsNum() {
		return shardsNum;
	}

	public void setShardsNum(int shardsNum) {
		this.shardsNum = shardsNum;
	}

	public Date getPreFireTime() {
		return preFireTime;
	}

	public void setPreFireTime(Date preFireTime) {
		this.preFireTime = preFireTime;
	}

	public Date getNextFireTime() {
		return nextFireTime;
	}

	public void setNextFireTime(Date nextFireTime) {
		this.nextFireTime = nextFireTime;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", name=" + name + ", group=" + group
				+ ", app=" + app + ", status=" + status + ", description="
				+ description + ", type=" + type + ", limit=" + limit
				+ ", distributed=" + distributed + ", threadnum=" + threadnum
				+ ", repeat=" + repeat + ", interval=" + interval + ", cron="
				+ cron + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", preFireTime=" + preFireTime + ", nextFireTime="
				+ nextFireTime + ", shardsNum=" + shardsNum + ", nodes="
				+ nodes + "]";
	}

}
