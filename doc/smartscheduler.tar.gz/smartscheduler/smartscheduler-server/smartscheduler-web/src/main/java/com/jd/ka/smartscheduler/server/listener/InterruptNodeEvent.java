package com.jd.ka.smartscheduler.server.listener;

import org.springframework.context.ApplicationEvent;

import com.jd.ka.smartscheduler.server.domain.Node;

/**
 * 中断节点运行事件
 * @author qiulong
 *
 */
public class InterruptNodeEvent extends ApplicationEvent {
	private static final long serialVersionUID = 1L;
	
	public InterruptNodeEvent(Object source) {
		super(source);
		if(!(source instanceof Node)) {
			throw new IllegalArgumentException("Source must be instance of [" + Node.class + "]");
		}
	}

	public Node getNode() {
		return (Node) this.getSource();
	}

}
