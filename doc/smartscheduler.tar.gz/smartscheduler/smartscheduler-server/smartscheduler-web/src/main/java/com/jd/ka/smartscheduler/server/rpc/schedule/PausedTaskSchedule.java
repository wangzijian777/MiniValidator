package com.jd.ka.smartscheduler.server.rpc.schedule;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.rpc.handler.ResponseHandler;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode.Status;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall.ExecuteException;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Request;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Response;

/**
 * 把当前正在执行任务的节点中断
 * @author qiulong
 *
 */
public class PausedTaskSchedule extends ScheduleChain {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Request<ACK[]> request;
	@Autowired
	private ResponseHandler<ACK[]> responseHandler;

	@Override
	protected boolean innerRun(Task task, List<RemoteNode> nodes) {
		if(!(task instanceof UnwantedTask)) {
			return true;
		}
		task = ((UnwantedTask) task).getActualTask();
		callRemoteNode(task, extractNodes(Status.BUSY, nodes));
		return false;
	}
	
	private void callRemoteNode(Task task, List<RemoteNode> busyNodes) {
		for (RemoteNode node : busyNodes) {
			try {
				Response<ACK[]> response = NodeCall.use(request).callNode(node).withTask(task).interrupt().execute().actionGet();
				responseHandler.handle(response);
			} catch (ExecuteException e) {
				logger.error("Interrupt task [{}] failed on node [{}]", task.getName(), node.url());
			}
		}
	}

}
