package com.jd.ka.smartscheduler.server.rpc.remote.node;

import com.jd.ka.smartscheduler.server.domain.Node;
import com.jd.ka.smartscheduler.server.rpc.shards.Shards;

/**
 * 
 * @author qiulong
 *
 */
public class RemoteNode {
	public enum Status {
		ALIVE, DIED, BUSY
	}
	
	private Node node;
	
	//默认为died
	private Status nodeStatus = Status.DIED;
	//上次执行任务时持有的分片
	private Shards previousShards;
	//本次执行任务分配的分片
	private Shards currentShards;
	
	private RemoteNode() {}
	
	public Status getStatus() {
		return nodeStatus;
	}
	
	public RemoteNode nodeDied() {
		this.nodeStatus = Status.DIED;
		return this;
	}
	
	public RemoteNode nodeAlive() {
		this.nodeStatus = Status.ALIVE;
		return this;
	}
	
	public RemoteNode nodeBusy() {
		this.nodeStatus = Status.BUSY;
		return this;
	}
	
	public RemoteNode setPreviousShards(Shards previousShards) {
		this.previousShards = previousShards;
		return this;
	}
	
	public RemoteNode setCurrentShards(Shards currentShards) {
		this.currentShards = currentShards;
		return this;
	}
	
	public String url() {
		return node.getUrl();
	}
	
	public int nodeId() {
		return node.getId();
	}
	
	public Shards previousShards() {
		return this.previousShards;
	}
	
	public Shards currentShards() {
		return this.currentShards;
	}
	
	public static RemoteNode create(Node node) {
		RemoteNode rn = new RemoteNode();
		rn.node = node;
		return rn;
	}

}
