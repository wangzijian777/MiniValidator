package com.jd.ka.smartscheduler.server.rpc.handler;

import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;

/**
 * ACK响应信息处理
 * @author qiulong
 *
 */
public interface ACKHandler {

	void handle(ACK ack);
	
}
