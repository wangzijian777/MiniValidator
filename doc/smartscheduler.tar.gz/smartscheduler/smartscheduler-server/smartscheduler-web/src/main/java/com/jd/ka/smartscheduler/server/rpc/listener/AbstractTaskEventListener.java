package com.jd.ka.smartscheduler.server.rpc.listener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactoryUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.core.OrderComparator;

import com.jd.ka.smartscheduler.core.event.TaskEvent;
import com.jd.ka.smartscheduler.core.listener.TaskEventListener;
import com.jd.ka.smartscheduler.server.listener.SmartSchedulerEvent;

/**
 * 
 * @author qiulong
 *
 * @param <T>
 */
public abstract class AbstractTaskEventListener<T> implements TaskEventListener, ApplicationContextAware, ApplicationListener<SmartSchedulerEvent> {

	private List<T> taskEventList;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		Map<String, T> matchingBeans = BeanFactoryUtils
				.beansOfTypeIncludingAncestors(applicationContext,
						matchClass(), true, false);
		if (!matchingBeans.isEmpty()) {
			this.taskEventList = new ArrayList<T>(matchingBeans.values());
			OrderComparator.sort(this.taskEventList);
		}
	}
	
	@Override
	public void onApplicationEvent(SmartSchedulerEvent event) {
		event.getSmartSchedulerContext().getSmartScheduler().addTaskEventListener(this);
	}
	
	@Override
	public void fireEvent(TaskEvent taskEvent) {
		TaskUniqueIdentifier tui = TaskUniqueIdentifier.create(taskEvent);
		innerFireEvent(taskEventList, tui);
	}

	protected abstract void innerFireEvent(List<T> taskEventList, TaskUniqueIdentifier tui);
	
	protected abstract Class<T> matchClass();
	
}
