package com.jd.ka.smartscheduler.server.rpc.listener;

/**
 * 任务被执行接口
 * @author qiulong
 *
 */
public interface TaskScheduled {
	void wasScheduled(TaskUniqueIdentifier tui);
}
