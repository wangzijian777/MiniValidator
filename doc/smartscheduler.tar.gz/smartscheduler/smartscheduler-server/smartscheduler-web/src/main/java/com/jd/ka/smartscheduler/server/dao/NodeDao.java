package com.jd.ka.smartscheduler.server.dao;

import java.util.List;

import com.jd.ka.smartscheduler.server.domain.Node;

/**
 * 
 * @author qiulong
 *
 */
public interface NodeDao {

	/**
	 * 查询为任务分配的执行节点
	 * @param taskId 任务id
	 * @return
	 */
	List<Node> getNodesByTaskId(int taskId);
	
	/**
	 * 更新节点
	 * @param node
	 * @return
	 */
	boolean updateNode(Node node);
	
	/**
	 * 获取指定节点
	 * @param nodeId 节点id
	 * @return
	 */
	Node getNode(int nodeId);
	
	/**
	 * 插入一个节点
	 * @param node
	 * @return
	 */
	boolean insertNode(Node node);
	
}
