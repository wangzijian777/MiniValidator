package com.jd.ka.smartscheduler.server.rpc.listener;

import java.util.List;

import com.jd.ka.smartscheduler.core.event.Event;

/**
 * 任务恢复事件监听
 * @author qiulong
 *
 */
public class TaskResumedEventListener extends AbstractTaskEventListener<TaskResumed> {

	@Override
	public Event matchEvent() {
		return Event.TaskResumed;
	}

	@Override
	protected void innerFireEvent(List<TaskResumed> taskEventList, TaskUniqueIdentifier tui) {
		for (TaskResumed taskResumed : taskEventList) {
			taskResumed.wasResumed(tui);
		}
	}

	@Override
	protected Class<TaskResumed> matchClass() {
		return TaskResumed.class;
	}

}
