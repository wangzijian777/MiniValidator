package com.jd.ka.smartscheduler.server.rpc.schedule;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;

import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.rpc.handler.ResponseHandler;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode.Status;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall.ExecuteException;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Request;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Response;

/**
 * 单节点执行任务处理
 * @author qiulong
 *
 */
public class SingleNodeSchedule extends ScheduleChain {
	private Logger logger = LoggerFactory.getLogger(getClass());
	private Random random = new Random();
	
	@Autowired
	private Request<ACK[]> request;
	@Autowired
	private ResponseHandler<ACK[]> responseHandler;

	@Override
	protected boolean innerRun(Task task, List<RemoteNode> nodes) {
		if(task.isDistributed()) {
			//进行下一个链调用
			return true;
		}
		singleNodeHandle(task, nodes);
		return false;
	}
	
	private void singleNodeHandle(Task task, List<RemoteNode> nodes) {
		//繁忙节点集合
		List<RemoteNode> busyNodes = extractNodes(Status.BUSY, nodes);
		//空闲节点集合
		List<RemoteNode> freeNodes = extractNodes(Status.ALIVE, nodes);
		if(busyNodes.isEmpty()) {
			if( !freeNodes.isEmpty() ) {
				if(!executeTask(task, freeNodes)) {
					logger.error("Task [{}] execute failed", task.getName());
					//TODO do something
				}
			} else {
				logger.warn("No nodes are available to run task [{}]", task.getName());
				//TODO do something
			}
		} else {
			if(logger.isWarnEnabled()) {
				StringBuilder sb = new StringBuilder();
				for(RemoteNode node : busyNodes) {
					sb.append(node.url());
					sb.append(" ");
				}
				logger.warn("Task [{}] not complete on node [{}]. so, give up it", task.getName(), sb.toString());
			}
		}
	}
	
	/**
	 * 随机选择一个节点
	 * @param freeNodes
	 * @return
	 */
	private RemoteNode selectSingleNode(List<RemoteNode> freeNodes) {
		int size = freeNodes.size();
		if(size == 1) {
			return freeNodes.get(0);
		}
		if(size > 1) {
			return freeNodes.get(random.nextInt(size));
		}
		throw new IllegalStateException("unallowed state");
	}
	
	/**
	 * 调用节点执行任务，当调用节点失败时，切换为其它可用节点
	 * @param task
	 * @param freeNodes
	 * @return
	 */
	private boolean executeTask(Task task, List<RemoteNode> freeNodes) {
		RemoteNode node = selectSingleNode(freeNodes);
		try {
			logger.debug("Execute task [{}] on node [{}]", task.getName(), node.url());
			Response<ACK[]> response = NodeCall.use(request).callNode(node).withTask(task).execute().actionGet();
			responseHandler.handle(response);
			return true;
		} catch (ExecuteException e) {
			logger.warn("Task[{}] execute failed on node [{}]. The reason is [{}]", task.getName(), node.url(), e.getMessage());
			freeNodes.remove(node);
			if(freeNodes.isEmpty()) {
				logger.warn("Task[{}] execute failed on node [{}], no nodes are available.", task.getName(), node.url());
				return false;
			} else {
				return executeTask(task, freeNodes);
			}
		}
	}
	
}
