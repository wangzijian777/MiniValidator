package com.jd.ka.smartscheduler.server.rpc.handler;

import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK.ACKStatus;

/**
 * 
 * @author qiulong
 *
 */
public abstract class AbstractACKHandler implements ACKHandler {

	@Override
	public void handle(ACK ack) {
		if(ack.getStatus() == match()) {
			innerHandle(ack);
		}
	}
	
	protected abstract void innerHandle(ACK ack);
	
	/**
	 * 匹配需要处理的ACK
	 * @return
	 */
	protected abstract ACKStatus match();

}
