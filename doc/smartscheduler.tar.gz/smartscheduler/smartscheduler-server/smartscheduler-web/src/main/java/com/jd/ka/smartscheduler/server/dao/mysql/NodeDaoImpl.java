package com.jd.ka.smartscheduler.server.dao.mysql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.jd.ka.smartscheduler.server.dao.NodeDao;
import com.jd.ka.smartscheduler.server.domain.Node;

/**
 * 
 * @author qiulong
 *
 */
@Repository
public class NodeDaoImpl extends JdbcTemplate implements ResultSetExtractor<List<Node>>, NodeDao {

	@Override
	public List<Node> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		List<Node> list = new ArrayList<Node>();
		while (rs.next()) {
			Node node = new Node();
			node.setId(rs.getInt("ID"));
			node.setTaskId(rs.getInt("TASK_ID"));
			node.setRunningStatus(rs.getInt("RUNNING_STATUS"));
			node.setStatus(rs.getInt("NODE_STATUS"));
			node.setUrl(rs.getString("URL"));
			node.setMessage(rs.getString("MESSAGE"));
			node.setStartTime(rs.getTimestamp("START_TIME"));
			node.setEndTime(rs.getTimestamp("END_TIME"));
			list.add(node);
		}
		return list;
	}
	
	@Override
	public List<Node> getNodesByTaskId(int taskId) {
		return this.query("SELECT * FROM SS_NODE WHERE TASK_ID=?", this, taskId);
	}

	@Override
	public boolean updateNode(Node node) {
		return this.update("UPDATE SS_NODE SET URL=?,NODE_STATUS=?,RUNNING_STATUS=?,MESSAGE=?,START_TIME=?,END_TIME=? WHERE ID=?",
				node.getUrl(), node.getStatus(),
				node.getRunningStatus(), node.getMessage(), node.getStartTime(), node.getEndTime(), node.getId()) > 0;
	}

	@Override
	public Node getNode(int nodeId) {
		List<Node> nodes = this.query("SELECT * FROM SS_NODE  WHERE ID=?", this, nodeId);
		if (nodes.size() > 0) {
			return nodes.get(0);
		}
		return null;
	}

	@Override
	public boolean insertNode(Node node) {
		return this.update("INSERT INTO SS_NODE (TASK_ID,URL,NODE_STATUS,RUNNING_STATUS,MESSAGE) VALUES (?,?,?,?,?)",
				node.getTaskId(), node.getUrl(), node.getStatus(), node.getRunningStatus(), node.getMessage()) > 0;
	}

}
