package com.jd.ka.smartscheduler.server.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import com.jd.ka.smartscheduler.server.dao.NodeDao;
import com.jd.ka.smartscheduler.server.domain.Node;
import com.jd.ka.smartscheduler.server.listener.InterruptNodeEvent;
import com.jd.ka.smartscheduler.server.service.NodeService;

/**
 * 
 * @author qiulong
 *
 */
@Service
public class NodeServiceImpl implements NodeService, ApplicationContextAware {
	private ApplicationContext applicationContext;
	
	@Autowired
	private NodeDao nodeDao;

	@Override
	public List<Node> getNodesByTaskId(int taskId) {
		return nodeDao.getNodesByTaskId(taskId);
	}

	@Override
	public boolean setRunning(int nodeId) {
		Node node = getNode(nodeId);
		if(node != null) {
			node.setRunningStatus(Node.RUNNING);
			node.setStartTime(new Date());
			node.setEndTime(null);
			node.setMessage(null);
			return nodeDao.updateNode(node);
		}
		return false;
	}

	@Override
	public boolean setWaitting(int nodeId) {
		Node node = getNode(nodeId);
		if(node != null) {
			node.setRunningStatus(Node.WAITTING);
			node.setEndTime(new Date());
			return nodeDao.updateNode(node);
		}
		return false;
	}

	@Override
	public boolean setFailure(int nodeId, String message) {
		Node node = getNode(nodeId);
		if(node != null) {
			node.setRunningStatus(Node.FAILURE);
			node.setMessage(message);
			node.setEndTime(new Date());
			return nodeDao.updateNode(node);
		}
		return false;
	}

	@Override
	public Node getNode(int nodeId) {
		return nodeDao.getNode(nodeId);
	}

	@Override
	public boolean setInterrupt(int nodeId) {
		Node node = getNode(nodeId);
		if(node != null) {
			node.setRunningStatus(Node.INTERRUPT);
			node.setEndTime(new Date());
			return nodeDao.updateNode(node);
		}
		return false;
	}

	@Override
	public boolean disableNode(int nodeId) {
		Node node = getNode(nodeId);
		if(node != null && node.getStatus() == Node.STATUS_ENABLE) {
			node.setStatus(Node.STATUS_DISABLE);
			if(upateNode(node) && node.getRunningStatus() == Node.RUNNING) {
				//如果节点运行中，则中断运行
				applicationContext.publishEvent(new InterruptNodeEvent(node));
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean enableNode(int nodeId) {
		Node node = getNode(nodeId);
		if(node != null && node.getStatus() == Node.STATUS_DISABLE) {
			node.setStatus(Node.STATUS_ENABLE);
			return upateNode(node);
		}
		return false;
	}

	@Override
	public boolean upateNode(Node node) {
		return nodeDao.updateNode(node);
	}
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext = applicationContext;
	}

}
