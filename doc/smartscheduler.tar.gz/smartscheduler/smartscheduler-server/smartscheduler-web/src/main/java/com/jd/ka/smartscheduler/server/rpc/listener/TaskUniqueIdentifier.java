package com.jd.ka.smartscheduler.server.rpc.listener;

import java.util.Date;

import com.jd.ka.smartscheduler.core.event.TaskEvent;

/**
 *标识一个 唯一的task
 * @author qiulong
 *
 */
public class TaskUniqueIdentifier {
	private TaskEvent taskEvent;

	private TaskUniqueIdentifier() {
	}

	public String getName() {
		return taskEvent.getName();
	}

	public String getGroup() {
		return taskEvent.getGroup();
	}
	
	/**
	 * 获取当前触发时间
	 * @return
	 */
	public Date getCurrentFireTime() {
		return taskEvent.getCurrentFireTime();
	}
	
	/**
	 * 下一次触发时间
	 * @return
	 */
	public Date getNextFireTime() {
		return taskEvent.getNextFireTime();
	}

	public static TaskUniqueIdentifier create(TaskEvent taskEvent) {
		TaskUniqueIdentifier tui = new TaskUniqueIdentifier();
		tui.taskEvent = taskEvent;
		return tui;
	}

}
