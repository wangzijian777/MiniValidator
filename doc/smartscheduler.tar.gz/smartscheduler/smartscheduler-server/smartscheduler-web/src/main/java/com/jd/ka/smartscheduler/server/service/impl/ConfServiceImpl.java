package com.jd.ka.smartscheduler.server.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jd.ka.smartscheduler.server.dao.ConfDao;
import com.jd.ka.smartscheduler.server.domain.Conf;
import com.jd.ka.smartscheduler.server.service.ConfService;

/**
 * 
 * @author qiulong
 *
 */
@Service
public class ConfServiceImpl implements ConfService {
	@Autowired
	private ConfDao confDao;

	@Override
	public boolean addConf(Conf conf) {
		return confDao.insertConf(conf);
	}

	@Override
	public boolean deleteConf(Conf conf) {
		if(conf.getClassify() > 0 && !StringUtils.isEmpty(conf.getName())) {
			return confDao.deleteConf(conf.getClassify(), conf.getName());
		}
		return confDao.deleteConf(conf.getClassify());
	}

	@Override
	public boolean updateConf(Conf conf) {
		return confDao.updateConf(conf);
	}

	@Override
	public Conf getConf(int classify, String name) {
		return confDao.getConf(classify, name);
	}

	@Override
	public List<Conf> queryConf(int classify) {
		return confDao.queryConf(classify);
	}

}
