package com.jd.ka.smartscheduler.server.domain;

import java.util.Date;

/**
 * 节点状态描述
 * @author qiulong
 *
 */
public class NodeStatus {
	/**
	 * 表示某个节点的状态
	 */
	private Node node;
	
	/**
	 * 执行任务开始时间
	 */
	private Date startTime;
	
	/**
	 * 执行任务结束时间
	 */
	private Date endTime;
	
	/**
	 * 执行任务平均时长（单位：秒）
	 */
	private long avgTime;
	
	/**
	 * 执行任务最大时长（单位：秒）
	 */
	private long maxTime;
	
	/**
	 * 提取数据量（指上次的执行）
	 */
	private int fetchData;
	/**
	 * 执行成功数据量（指上次的执行）
	 */
	private int successData;
	
	/**
	 * 执行任务的序列号，用于匹配节点是否有延迟。如果小于{@link Task#getSeqnum()}，则表示有延迟。
	 */
	private long seqnum;

	public Node getNode() {
		return node;
	}

	public Date getStartTime() {
		return startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public long getAvgTime() {
		return avgTime;
	}

	public long getMaxTime() {
		return maxTime;
	}

	public int getFetchData() {
		return fetchData;
	}

	public int getSuccessData() {
		return successData;
	}

	public long getSeqnum() {
		return seqnum;
	}

	@Override
	public String toString() {
		return "NodeStatus [node=" + node + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", avgTime=" + avgTime
				+ ", maxTime=" + maxTime + ", fetchData=" + fetchData
				+ ", successData=" + successData + ", seqnum=" + seqnum + "]";
	}
	
}
