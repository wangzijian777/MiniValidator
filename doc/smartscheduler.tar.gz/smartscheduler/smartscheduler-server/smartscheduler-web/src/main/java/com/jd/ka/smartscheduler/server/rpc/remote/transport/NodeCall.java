package com.jd.ka.smartscheduler.server.rpc.remote.transport;

import java.util.Iterator;
import java.util.Map;

import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode;

/**
 * 向远程节点发送请求
 * @author qiulong
 *
 */
public class NodeCall<T> {
	private RemoteNode node;
	private Task task;
	private Variables<String, Object> requestVariables = new MapVariables();
	private Request<T> request;
	private Response<T> response;

	public static <ResponseData> NodeCall<ResponseData> use(Request<ResponseData> request) {
		NodeCall<ResponseData> call = new NodeCall<ResponseData>();
		call.request = request;
		return call;
	}
	
	public NodeCall<T> callNode(RemoteNode node) {
		this.node = node;
		return this;
	}
	
	public NodeCall<T> withTask(Task task) {
		this.task = task;
		return this;
	}
	
	public NodeCall<T> withVariable(Map<String, Object> var) {
		for(Iterator<String> iter = var.keySet().iterator(); iter.hasNext();) {
			String key = iter.next();
			requestVariables.add(key, var.get(key));
		}
		return this;
	}
	
	public NodeCall<T> ping() throws ExecuteException {
		this.requestVariables.add("ping", "true");
		return execute();
	}
	
	public NodeCall<T> interrupt() throws ExecuteException {
		this.requestVariables.add("interrupt", "true");
		return execute();
	}
	
	/**
	 * 执行请求
	 */
	public NodeCall<T> execute() throws ExecuteException {
		if(node == null) {
			throw new IllegalArgumentException("You must be call callNode(RemoteNode node) method at first.");
		}
		if(task == null) {
			throw new IllegalArgumentException("You must be call withTask(Task task) method at first.");
		}
		prepareVariable();
		//发送请求
		try {
			this.response = request.doRequest(this.node.url(), requestVariables);
		} catch (RequestException e) {
			throw new ExecuteException(e);
		}
		return this;
	}
	
	/**
	 * 获取响应结果
	 */
	public Response<T> actionGet() {
		return this.response;
	}
	
	private void prepareVariable() {
		Task task = this.task;
		requestVariables.add("id", task.getId());
		requestVariables.add("nodeId", node.nodeId());
		requestVariables.add("distributed", task.isDistributed());
		requestVariables.add("threadNum", task.getThreadnum());
		requestVariables.add("limit", task.getLimit());
	}
	
	public static class ExecuteException extends Exception {
		private static final long serialVersionUID = 1L;

		public ExecuteException() {
			super();
		}

		public ExecuteException(String message, Throwable cause,
				boolean enableSuppression, boolean writableStackTrace) {
			super(message, cause, enableSuppression, writableStackTrace);
		}

		public ExecuteException(String message, Throwable cause) {
			super(message, cause);
		}

		public ExecuteException(String message) {
			super(message);
		}

		public ExecuteException(Throwable cause) {
			super(cause);
		}
		
	}
	
}