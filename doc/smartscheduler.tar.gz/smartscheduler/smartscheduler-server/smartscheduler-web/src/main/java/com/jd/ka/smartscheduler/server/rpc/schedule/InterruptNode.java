package com.jd.ka.smartscheduler.server.rpc.schedule;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.rpc.handler.ResponseHandler;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Request;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Response;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall.ExecuteException;

/**
 * 中断某个在运行任务的节点
 * @author qiulong
 *
 */
public class InterruptNode extends ScheduleChain {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Request<ACK[]> request;
	@Autowired
	private ResponseHandler<ACK[]> responseHandler;

	@Override
	public boolean innerRun(Task task, List<RemoteNode> nodes) {
		if(!(task instanceof TaskForInterruptNode)) {
			return true;
		}
		RemoteNode node = nodes.get(0);
		try {
			Response<ACK[]> response = NodeCall.use(request).callNode(node).withTask(task).interrupt().execute().actionGet();
			responseHandler.handle(response);
		} catch (ExecuteException e) {
			logger.error("Interrupt task [{}] failed on node [{}]", task.getName(), node.url());
		}
		return false;
	}

}
