package com.jd.ka.smartscheduler.server.rpc.remote.transport;



/**
 * 
 * @author qiulong
 *
 */
public interface Request<T> {
	Response<T> doRequest(String url,  Variables<String, Object> variables) throws RequestException;
}
