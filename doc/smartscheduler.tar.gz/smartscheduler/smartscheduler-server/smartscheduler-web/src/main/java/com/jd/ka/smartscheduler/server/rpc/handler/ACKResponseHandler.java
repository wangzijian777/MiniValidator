package com.jd.ka.smartscheduler.server.rpc.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactoryUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.OrderComparator;
import org.springframework.stereotype.Component;

import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Response;

/**
 * ACK响应信息处理
 * 
 * @author qiulong
 *
 */
@Component
public class ACKResponseHandler implements ResponseHandler<ACK[]>, ApplicationContextAware {
	private List<ACKHandler> ackHandlerList;

	@Override
	public void handle(Response<ACK[]> response) {
		ACK[] acks = response.getResponse();
		if(acks == null || acks.length == 0) {
			return;
		}
		for (ACK ack : acks) {
			for (ACKHandler ackHandler : ackHandlerList) {
				ackHandler.handle(ack);
			}
		}
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		Map<String, ACKHandler> matchingBeans = BeanFactoryUtils.beansOfTypeIncludingAncestors(applicationContext, ACKHandler.class, true, false);
		if (!matchingBeans.isEmpty()) {
			this.ackHandlerList = new ArrayList<ACKHandler>(matchingBeans.values());
			OrderComparator.sort(this.ackHandlerList);
		}
	}

}
