package com.jd.ka.smartscheduler.server.rpc.schedule;

import com.jd.ka.smartscheduler.server.domain.Task;

/**
 * 虚拟的task，不能从中获取实际task数据，只能从{@link #getActualTask()}中获取
 * @author qiulong
 * FIXME unsatisfied!
 */
public abstract class DummyTask extends Task {
	private Task task;

	public DummyTask(Task task) {
		this.task = task;
	}

	public Task getActualTask() {
		return task;
	}
	
}
