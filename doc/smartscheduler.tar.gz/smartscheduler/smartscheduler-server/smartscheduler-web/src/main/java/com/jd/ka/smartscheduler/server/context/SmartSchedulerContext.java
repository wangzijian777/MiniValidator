package com.jd.ka.smartscheduler.server.context;

import static com.jd.ka.smartscheduler.core.builder.SmartSchedulerBuilder.newBuilder;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import com.jd.ka.smartscheduler.core.SmartScheduler;
import com.jd.ka.smartscheduler.core.env.Settings;
import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;

/**
 * @author qiulong
 *
 */
public class SmartSchedulerContext {
	private Logger logger = LoggerFactory.getLogger(getClass());
	private SmartScheduler smartScheduler;
	
	//configuration property
	private String propFilePath;
	private Map<String, String> conf;
	//Datasource
	private DataSource dataSource;
	
	public void setPropFilePath(String path) {
		this.propFilePath = path;
	}

	public void setConf(Map<String, String> conf) {
		this.conf = conf;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public boolean isStarted() {
		return smartScheduler != null && smartScheduler.isStarted();
	}

	public void init() throws Exception {
		Settings settings = Settings.newSettings();
		loadConfFromProperties(settings);
		loadConfFromMap(settings);
		loadDataSource(settings);
		this.smartScheduler = newBuilder(settings).build();
		logger.info("SmartSchedulerContext initialize success");
	}
	
	/**
	 * 开启调度服务
	 * @throws Exception
	 */
	public synchronized void start() throws Exception {
		this.smartScheduler.start();
		logger.info("SmartSchedulerContext start success");
	}
	
	/**
	 * 停止调度服务
	 * @throws Exception
	 */
	public synchronized void stop() throws Exception {
		if(this.smartScheduler !=null && !this.smartScheduler.isShutdown()) {
			this.smartScheduler.stop();
		}
		logger.info("SmartSchedulerContext stop success");
	}
	
	/**
	 * 获取{@link SmartScheduler}实例
	 * @return
	 */
	public SmartScheduler getSmartScheduler() {
		return smartScheduler;
	}

	//从properties文件加载配置
	private void loadConfFromProperties(Settings settings) throws IOException {
		if(this.propFilePath != null && !this.propFilePath.isEmpty()) {
			logger.info("Load properties file from 【{}】", propFilePath);
			ResourceLoader resLoader = new DefaultResourceLoader();
			Resource resource = resLoader.getResource(propFilePath);
			Properties prop = new Properties();
			prop.load(resource.getInputStream());
			settings.set(prop);
		}
	}
	
	//从程序中设置加载配置
	private void loadConfFromMap(Settings settings) {
		if(this.conf != null) {
			Set<String> keySet = this.conf.keySet();
			for (String key : keySet) {
				settings.set(key, this.conf.get(key));
			}
		}
	}
	
	//加载数据源
	private void loadDataSource(Settings settings) {
		if(this.dataSource != null) {
			settings.setDataSource(this.dataSource);
		}
	}

}
