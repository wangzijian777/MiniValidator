package com.jd.ka.smartscheduler.server.dao.mysql;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.jd.ka.smartscheduler.server.dao.ConfDao;
import com.jd.ka.smartscheduler.server.domain.Conf;

/**
 * 
 * @author qiulong
 *
 */
@Repository
public class ConfDaoImpl extends JdbcTemplate implements ResultSetExtractor<List<Conf>>, ConfDao {

	@Override
	public List<Conf> extractData(ResultSet rs) throws SQLException, DataAccessException {
		List<Conf> list = new ArrayList<Conf>();
		while(rs.next()) {
			Conf conf = new Conf();
			conf.setClassify(rs.getInt("CLASSIFY"));
			conf.setName(rs.getString("CONF_NAME"));
			conf.setValue(rs.getString("CONF_VALUE"));
			list.add(conf);
		}
		return list;
	}

	
	@Override
	public Conf getConf(int classify, String name) {
		List<Conf> rs = this.query("SELECT * FROM SS_CONF WHERE CLASSIFY=? AND CONF_NAME=?", this, classify, name);
		if(rs.size() > 0) {
			return rs.get(0);
		}
		return null;
	}

	@Override
	public boolean updateConf(Conf conf) {
		return this.update("UPDATE SS_CONF SET CONF_VALUE=? WHERE CLASSIFY=? AND CONF_NAME=?", conf.getString(), conf.getClassify(), conf.getName()) > 0;
	}

	@Override
	public boolean deleteConf(int classify, String name) {
		return this.update("DELETE FROM SS_CONF WHERE CLASSIFY=? AND CONF_NAME=?", classify, name) > 0;
	}

	@Override
	public boolean deleteConf(int classify) {
		return this.update("DELETE FROM SS_CONF WHERE CLASSIFY=?", classify) > 0;
	}

	@Override
	public List<Conf> queryConf(int classify) {
		return this.query("SELECT * FROM SS_CONF WHERE CLASSIFY=?", this, classify);
	}

	@Override
	public boolean insertConf(Conf conf) {
		return this.update("INSERT INTO SS_CONF (CLASSIFY,CONF_NAME,CONF_VALUE) VALUES (?,?,?)", conf.getClassify(), conf.getName(), conf.getString()) > 0;
	}

}
