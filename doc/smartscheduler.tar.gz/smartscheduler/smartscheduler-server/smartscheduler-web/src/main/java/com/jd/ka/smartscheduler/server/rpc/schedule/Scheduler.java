package com.jd.ka.smartscheduler.server.rpc.schedule;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.jd.ka.smartscheduler.core.builder.TaskBuilder;
import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.server.context.SmartSchedulerContext;
import com.jd.ka.smartscheduler.server.domain.Node;
import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.domain.Task.Status;
import com.jd.ka.smartscheduler.server.listener.InterruptNodeEvent;
import com.jd.ka.smartscheduler.server.rpc.listener.TaskPaused;
import com.jd.ka.smartscheduler.server.rpc.listener.TaskScheduled;
import com.jd.ka.smartscheduler.server.rpc.listener.TaskUniqueIdentifier;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode;
import com.jd.ka.smartscheduler.server.service.TaskService;

/**
 * 负责任务的总调配
 * @author qiulong
 *
 */
@Component
public class Scheduler implements TaskScheduled, TaskPaused, ApplicationListener<InterruptNodeEvent> {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private TaskService taskService;
	@Autowired
	private SmartSchedulerContext smartSchedulerContext;
	
	/**
	 * 调度链的头部
	 */
	@Autowired
	private ScheduleChain headScheduleChain;
	
	@Override
	public void wasScheduled(TaskUniqueIdentifier tui) {
		Task task = queryTask(tui);
		if(task == null || task.getStatus() == Status.INVALID) {
			return;
		}
		setTaskFireTime(task, tui.getCurrentFireTime(), tui.getNextFireTime());
		scheduleTask(task);
	}
	
	/**
	 * 任务被暂停，停止所有在运行任务的节点
	 * @param tui
	 */
	@Override
	public void wasPaused(TaskUniqueIdentifier tui) {
		Task task = queryTask(tui);
		if(task == null) {
			return;
		}
		scheduleTask(new UnwantedTask(task));
	}
	
	/**
	 * 执行任务调度
	 * @param task
	 */
	private void scheduleTask(Task task) {
		List<RemoteNode> usableNodes = getUsableNodes(task);
		//如果没有节点可用，则结束调度
		if(usableNodes.isEmpty()) {
			logger.error("No available node to use", task.getName());
			return;
		}
		headScheduleChain.run(task, usableNodes);
	}

	/**
	 * 根据任务获取可调度的节点
	 * @param tui
	 * @return
	 */
	private List<RemoteNode> getUsableNodes(Task task) {
		List<RemoteNode> remoteNodes = new ArrayList<RemoteNode>();
		List<Node> nodes = task.getNodes();
		if(nodes != null) {
			for (Node node : nodes) {
				//排除已经被停止的节点
				if(node.getStatus() == 1) {
					remoteNodes.add(RemoteNode.create(node));
				}
			}
		}
		return remoteNodes;
	}
	
	/**
	 * 查询task明细
	 * @param tui
	 * @return
	 */
	private Task queryTask(TaskUniqueIdentifier tui) {
		 Task task = taskService.getTask(tui.getName(), tui.getGroup());
		 if(task == null) {
				logger.error("Task [] cannot be found! Drop the task trigger", tui.getName());
				smartSchedulerContext.getSmartScheduler().removeTask(TaskBuilder.newSimpleTaskBuilder(tui.getName(), tui.getGroup()).build());
				return null;
		}
		 return task;
	}
	
	private void setTaskFireTime(Task task, Date currentFireTime, Date nextFireTime) {
		taskService.setTaskFireTime(task.getId(), currentFireTime, nextFireTime);
	}

	@Override
	public void onApplicationEvent(InterruptNodeEvent event) {
		Node node = event.getNode();
		Task task = taskService.getTask(node.getTaskId());
		if(task == null || node == null) {
			return;
		}
		List<RemoteNode> remoteNodes = new ArrayList<RemoteNode>();
		remoteNodes.add(RemoteNode.create(node));
		headScheduleChain.run(new TaskForInterruptNode(task), remoteNodes);
	}
	
}
