package com.jd.ka.smartscheduler.server.rpc.remote.transport;

/**
 * 
 * @author qiulong
 *
 * @param <T>
 */
public interface Response<T> {
	T getResponse();
}
