package com.jd.ka.smartscheduler.server.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.server.context.SmartSchedulerContext;

/**
 * 
 * @author qiulong
 *
 */
@Component
public class WebAppStartedListener implements ApplicationListener<ContextRefreshedEvent> {
	@Autowired
	private SmartSchedulerContext smartSchedulerContext;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		try {
			if(!smartSchedulerContext.isStarted()) {
				smartSchedulerContext.init();
				event.getApplicationContext().publishEvent(new SmartSchedulerEvent(smartSchedulerContext));
				LoggerFactory.getLogger(getClass()).info("SmartSchedulerContext Created");
				smartSchedulerContext.start();
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
