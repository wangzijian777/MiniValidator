package com.jd.ka.smartscheduler.server.dao;

import java.util.List;

import com.jd.ka.smartscheduler.server.domain.Conf;

/**
 * 
 * @author qiulong
 *
 */
public interface ConfDao {
	
	/**
	 * 插入一个新的配置项
	 * @param conf
	 * @return
	 */
	boolean insertConf(Conf conf);

	/**
	 * 获取一个配置项
	 * @param classify
	 * @param name
	 * @return
	 */
	Conf getConf(int classify, String name);
	
	/**
	 * 修改一个配置项目
	 * @param conf
	 * @return
	 */
	boolean updateConf(Conf conf);
	
	/**
	 * 删除一个配置项
	 * @param classify
	 * @param name
	 * @return
	 */
	boolean deleteConf(int classify, String name);
	
	/**
	 * 删除分类下所有配置
	 * @param classify
	 * @return
	 */
	boolean deleteConf(int classify);
	
	/**
	 * 查询分类下所有配置项
	 * @param classify
	 * @return
	 */
	List<Conf> queryConf(int classify);
	
}
