package com.jd.ka.smartscheduler.server.service;

import java.util.Date;
import java.util.List;

import com.jd.ka.smartscheduler.server.domain.Task;

/**
 * 对Task的相关操作接口
 * @author qiulong
 *
 */
public interface TaskService {
	
	/**
	 * 根据任务id获取任务
	 * @param taskId
	 * @return
	 */
	Task getTask(int taskId);
	
	/**
	 * 获取指定的任务明细
	 * @param name 任务名称
	 * @param group 任务所属组
	 * @return 某项任务
	 */
	Task getTask(String name, String group);
	
	/**
	 * 查询应用下的任务列表
	 * @param appName 应用名称 
	 * @return 任务列表
	 */
	List<Task> queryTaskByApp(String appName);
	
	/**
	 * 分页查询所有任务
	 * @param pageSize 每页显示条数
	 * @param pageIndex 页码
	 * @return 任务列表
	 */
	List<Task> queryAllTask(int pageSize, int pageIndex);
	
	/**
	 * 新增任务
	 * @param task
	 * @return
	 */
	boolean addTask(Task task);
	
	/**
	 * 更新任务
	 * @param task
	 * @return
	 */
	boolean updateTask(Task task);
	
	/**
	 * 改变任务状态（停用/启用）
	 * @param taskId 任务id
	 * @param status 操作状态
	 * @return
	 */
	boolean changeStatus(int taskId, Task.Status status);
	
	/**
	 * 设置任务触发时间
	 * @param taskId
	 * @param currentFireTime 本次触发时间
	 * @param nextFireTime 下次触发时间
	 * @return
	 */
	boolean setTaskFireTime(int taskId, Date currentFireTime, Date nextFireTime);

	/**
	 * 删除指定任务
	 * @param taskId
	 * @return
	 */
	boolean deleteTask(int taskId);
}
