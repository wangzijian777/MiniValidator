package com.jd.ka.smartscheduler.server.dao;

import java.util.Date;
import java.util.List;

import com.jd.ka.smartscheduler.server.domain.Task;

/**
 * 
 * @author qiulong
 *
 */
public interface TaskDao {
	/**
	 * 获取指定的任务明细
	 * @param name 任务名称
	 * @param group 任务所属组
	 * @return 某项任务
	 */
	Task getTask(String name, String group);
	
	/**
	 * 根据任务id获取任务
	 * @param taskId
	 * @return
	 */
	Task getTask(int taskId);
	
	/**
	 * 新增一个任务
	 * @param task
	 * @return
	 */
	boolean insertTask(Task task);
	
	/**
	 * 更新指定的任务
	 * @param task
	 * @return
	 */
	boolean updateTask(Task task);
	
	/**
	 * 改变任务状态
	 * @param taskId 任务id
	 * @param status 状态编号
	 * @return
	 */
	boolean updateTaskStatus(int taskId, int status);
	
	/**
	 * 更新任务触发时间
	 * @param taskId 任务id
	 * @param preFireTime 本次触发时间
	 * @param nextFireTime 下次触发时间
	 * @return
	 */
	boolean updateFireTime(int taskId, Date currentFireTime, Date nextFireTime);
	
	/**
	 * 通过应用名称查询任务列表
	 * @param app 应用名称
	 * @return
	 */
	List<Task> queryTaskByApp(String app);
	
	/**
	 * 删除指定任务
	 * @param taskId
	 * @return
	 */
	boolean deleteTask(int taskId);
}
