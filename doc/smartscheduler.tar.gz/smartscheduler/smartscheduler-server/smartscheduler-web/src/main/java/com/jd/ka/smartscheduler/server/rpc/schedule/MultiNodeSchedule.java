package com.jd.ka.smartscheduler.server.rpc.schedule;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.server.domain.Task;
import com.jd.ka.smartscheduler.server.rpc.handler.ResponseHandler;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode;
import com.jd.ka.smartscheduler.server.rpc.remote.node.RemoteNode.Status;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.ACK;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.NodeCall.ExecuteException;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Request;
import com.jd.ka.smartscheduler.server.rpc.remote.transport.Response;
import com.jd.ka.smartscheduler.server.rpc.shards.Shards;

/**
 * 多节点执行任务处理
 * @author qiulong
 *
 */
public class MultiNodeSchedule extends ScheduleChain {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Request<ACK[]> request;
	@Autowired
	private ResponseHandler<ACK[]> responseHandler;

	@Override
	public boolean innerRun(Task task, List<RemoteNode> nodes) {
		if(!task.isDistributed()) {
			return true;
		}
		//根据设置的分片数量创建分片
		Shards newShards = createTaskShards(task);
		//排除已被繁忙节点占用的分片
		removeOccupiedShard(newShards, extractNodes(Status.BUSY, nodes));
		//为空闲的存活节点分配剩下的分片
		List<RemoteNode> aliveNodes = extractNodes(Status.ALIVE, nodes);
		allocateShards(newShards, aliveNodes);
		//移除没有分片的节点
		removeNoShardsNode(aliveNodes);
		//调用远程节点
		callRemoteNode(task, aliveNodes);
		return false;
	}
	
	private void callRemoteNode(Task task, List<RemoteNode> aliveNodes) {
		for (RemoteNode node : aliveNodes) {
			if(logger.isDebugEnabled()) {
				logger.debug("Execute task [{}] on node [{}]", task.getName(), node.url());
			}
			try {
				Response<ACK[]> response = prepareCall(task, node).execute().actionGet();
				responseHandler.handle(response);
			} catch (ExecuteException e) {
				logger.error("Execute task [{}] failed on node [{}], reason:{}", task.getName(), node.url(), e.getMessage());
			}
		}
	}
	
	/**
	 * 调用前的参数准备
	 * @param task
	 * @param node
	 * @return
	 */
	private NodeCall<ACK[]> prepareCall(Task task, RemoteNode node) {
		HashMap<String, Object> var = new HashMap<String, Object>();
		var.put("mod", node.currentShards());
		var.put("divisor", task.getShardsNum());
		return NodeCall.use(request).callNode(node).withTask(task).withVariable(var);
	}
	
	/**
	 * 创建新分片
	 * @param task
	 * @return
	 */
	private Shards createTaskShards(Task task) {
		int shardsNum = task.getShardsNum();
		Shards newShards = new Shards();
		for (int i = 0; i < shardsNum; i++) {
			newShards.add(i);
		}
		return newShards;
	}

	/**
	 * 为节点分配分片
	 * @param noOccupiedShards 未被占用的分片
	 * @param aliveNodes 存活的空闲节点
	 */
	private void allocateShards(Shards noOccupiedShards, List<RemoteNode> aliveNodes) {
		out:
		while(!noOccupiedShards.isEmpty()) {
			for (RemoteNode node : aliveNodes) {
				if(noOccupiedShards.isEmpty()) {
					break out;
				}
				Shards nodeShards = node.currentShards();
				if(nodeShards == null) {
					nodeShards = new Shards();
					node.setCurrentShards(nodeShards);
				}
				nodeShards.add(noOccupiedShards.getAndRemove());
			}
		}
	}
	
	/**
	 * 移除节点已占用的分片
	 */
	private void removeOccupiedShard(Shards newShards, List<RemoteNode> busyNodes) {
		for (RemoteNode node : busyNodes) {
			newShards.removeByOtherShards(node.previousShards());
		}
	}
	
	/**
	 * 移除没有分片的节点
	 * @param aliveNodes
	 */
	private void removeNoShardsNode(List<RemoteNode> aliveNodes) {
		for(Iterator<RemoteNode> iter = aliveNodes.iterator(); iter.hasNext(); ) {
			RemoteNode node = iter.next();
			Shards currentShards = node.currentShards();
			if(currentShards == null || currentShards.isEmpty()) {
				iter.remove();
			}
		}
	}
	
}
