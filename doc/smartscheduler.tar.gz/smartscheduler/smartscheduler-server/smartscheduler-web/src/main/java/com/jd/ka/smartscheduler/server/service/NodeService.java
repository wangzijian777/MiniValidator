package com.jd.ka.smartscheduler.server.service;

import java.util.List;

import com.jd.ka.smartscheduler.server.domain.Node;

/**
 * 对节点的相关操作
 * @author qiulong
 *
 */
public interface NodeService {

	/**
	 * 查询task所有节点
	 * @param taskId 任务ID
	 * @return
	 */
	List<Node> getNodesByTaskId(int taskId);
	
	/**
	 * 获取指定节点信息
	 * @param nodeId 节点id
	 * @return
	 */
	Node getNode(int nodeId);
	
	/**
	 * 设置节点为运行状态
	 * @param nodeId 节点id
	 * @return
	 */
	boolean setRunning(int nodeId);
	
	/**
	 * 设置节点为等待运行任务状态
	 * @param nodeId 节点id
	 * @return
	 */
	boolean setWaitting(int nodeId);
	
	/**
	 * 设置节点调度失败
	 * @param nodeId 节点id
	 * @param message 返回的失败信息
	 * @return
	 */
	boolean setFailure(int nodeId, String message);
	
	/**
	 * 设置节点为中断状态
	 * @param nodeId 节点id
	 * @return
	 */
	boolean setInterrupt(int nodeId);
	
	/**
	 * 废弃节点
	 * @param nodeId
	 * @return
	 */
	boolean disableNode(int nodeId);
	
	/**
	 * 启用节点
	 * @param nodeId
	 * @return
	 */
	boolean enableNode(int nodeId);
	
	/**
	 * 更新某个节点信息
	 * @param node
	 * @return
	 */
	boolean upateNode(Node node);
	
}
