package com.jd.ka.smartscheduler.core;

import com.jd.ka.smartscheduler.core.builder.TaskBuilder;
import com.jd.ka.smartscheduler.core.env.Settings;
import com.jd.ka.smartscheduler.core.task.Task;
import com.jd.ka.smartscheduler.core.task.TimeUnit;

/**
 * 任务控制测试
 * @author qiulong
 *
 */
public class TestTaskOperator extends BaseTest {

	public TestTaskOperator() {
		super(10000L);
	}

	/**
	 * 测试添加普通任务
	 */
	public void testAddSimpleTask() {
		Task task = TaskBuilder.newSimpleTaskBuilder("test", "group-1")
				.setIntervalTime(1L, TimeUnit.SECONDS)
				.build();
		assertTrue(this.getScheduler().addTask(task));
	}
	
	/**
	 * 测试添加高级任务
	 */
	public void testAddAdvancedTask() {
		Task task = TaskBuilder.newAdvancedTaskBuilder("ad-test", "group-2")
				.setCronExpression("0/2 * * * * ?")
				.build();
		assertTrue(this.getScheduler().addTask(task));
	}
	
	/**
	 * 测试删除任务
	 */
	public void testRemoveTask() {
		this.testAddAdvancedTask();
		try {
			Thread.sleep(4000L);
		} catch (InterruptedException e) {	}
		Task task = TaskBuilder.newSimpleTaskBuilder("ad-test", "group-2").build();
		assertTrue(this.getScheduler().removeTask(task));
	}
	
	/**
	 * 测试更新任务
	 */
	public void testUpdaeTask() {
		this.testAddAdvancedTask();
		try {
			Thread.sleep(4000L);
		} catch (InterruptedException e) {	}
		Task task = TaskBuilder.newAdvancedTaskBuilder("ad-test", "group-2")
				.setCronExpression("0/1 * * * * ?")
				.build();
		assertTrue(this.getScheduler().updateTask(task));
	}
	
	/**
	 * 测试暂停任务
	 */
	public void testPause() {
		this.testAddAdvancedTask();
		try {
			Thread.sleep(2000L);
		} catch (InterruptedException e) {	}
		assertTrue(this.getScheduler().pause(TaskBuilder.newSimpleTaskBuilder("ad-test", "group-2").build()));
	}
	
	/**
	 * 测试恢复任务
	 */
	public void testResume() {
		testPause();
		try {
			Thread.sleep(2000L);
		} catch (InterruptedException e) {	}
		assertTrue(this.getScheduler().resume(TaskBuilder.newSimpleTaskBuilder("ad-test", "group-2").build()));
	}
	
	/**
	 * 测试立即触发任务
	 */
	public void testTrigger() {
		Task task = TaskBuilder.newAdvancedTaskBuilder("ad-test", "group-2")
				.setCronExpression("0 0/5 * * * ?")
				.build();
		assertTrue(this.getScheduler().addTask(task));
		try {
			Thread.sleep(1000L);
		} catch (InterruptedException e) {	}
		assertTrue(this.getScheduler().trigger(task));
	}
	
	
	@Override
	protected void prepareSettings(Settings settings) {
		
	}
	
	
	
}
