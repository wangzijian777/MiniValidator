package com.jd.ka.smartscheduler.core;

import java.util.Date;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.jd.ka.smartscheduler.core.builder.TaskBuilder;
import com.jd.ka.smartscheduler.core.env.Settings;
import com.jd.ka.smartscheduler.core.task.Task;
import com.jd.ka.smartscheduler.core.task.TimeUnit;

/**
 * 
 * @author qiulong
 *
 */
public class TestSmartScheduler extends BaseTest {
	
	public TestSmartScheduler() {
		super(15000L);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(TestSmartScheduler.class);
	}

	public void testRunTask() {
		Task task = TaskBuilder.newSimpleTaskBuilder("test", "group-1")
				.setIntervalTime(1L, TimeUnit.SECONDS)
				.setRepeatCount(5)
//				.repeatForever()
				.startAt(new Date(System.currentTimeMillis() + 3000L))
				.build();
		this.getScheduler().addTask(task);
	}

	@Override
	protected void prepareSettings(Settings settings) {
		
	}
}
