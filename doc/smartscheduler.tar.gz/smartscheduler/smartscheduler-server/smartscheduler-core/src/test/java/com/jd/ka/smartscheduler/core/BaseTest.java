package com.jd.ka.smartscheduler.core;

import java.util.concurrent.CountDownLatch;

import junit.framework.TestCase;

import com.jd.ka.smartscheduler.core.SmartScheduler;
import com.jd.ka.smartscheduler.core.builder.SmartSchedulerBuilder;
import com.jd.ka.smartscheduler.core.env.Settings;
import com.jd.ka.smartscheduler.core.event.Event;
import com.jd.ka.smartscheduler.core.event.TaskEvent;
import com.jd.ka.smartscheduler.core.listener.TaskEventListener;
import com.jd.ka.smartscheduler.logging.LoggerFactory;
import com.jd.ka.smartscheduler.logging.jdk.JDKLoggerFactory;

/**
 * 
 * @author qiulong
 *
 */
public abstract class BaseTest extends TestCase {
	private SmartScheduler scheduler;
	private CountDownLatch latch = new CountDownLatch(1);
	private long delay;
	
	public BaseTest(long delay) {
		this.delay = delay;
	}

	@Override
	protected void setUp() throws Exception {
		LoggerFactory.setDefaultLoggerFactory(new JDKLoggerFactory());
		Settings settings = Settings.newSettings();
		prepareSettings(settings);
		this.scheduler = SmartSchedulerBuilder.newBuilder(settings).build();
		this.scheduler.start();
		this.getScheduler().addTaskEventListener(new TaskEventListener() {
			@Override
			public void fireEvent(TaskEvent taskEvent) {
				System.out.println("name=" + taskEvent.getName() + ",group=" + taskEvent.getGroup());
			}

			@Override
			public Event matchEvent() {
				return Event.TaskExecuted;
			}
		});
	}
	
	@Override
	protected void tearDown() throws Exception {
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				try {
					Thread.sleep(delay);
					countDown();
					latch.await();
					scheduler.stop();
				} catch (InterruptedException e) {
				}
			}
		});
	}
	
	protected SmartScheduler getScheduler() {
		return this.scheduler;
	}
	
	protected void countDown() {
		latch.countDown();
	}
	
	abstract protected void prepareSettings(Settings settings);

}
