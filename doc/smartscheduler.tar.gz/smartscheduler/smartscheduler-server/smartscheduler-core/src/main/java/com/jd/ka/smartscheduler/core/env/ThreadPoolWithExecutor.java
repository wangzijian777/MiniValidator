package com.jd.ka.smartscheduler.core.env;

import org.quartz.SchedulerConfigException;
import org.quartz.spi.ThreadPool;

/**
 * 采用{@link java.util.concurrent.ThreadPoolExecutor}实现的<code>ThreadPool</code>
 * TODO
 * @author qiulong
 *
 */
public class ThreadPoolWithExecutor implements ThreadPool {

	@Override
	public boolean runInThread(Runnable runnable) {
		return false;
	}

	@Override
	public int blockForAvailableThreads() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void initialize() throws SchedulerConfigException {
		// TODO Auto-generated method stub

	}

	@Override
	public void shutdown(boolean waitForJobsToComplete) {
		// TODO Auto-generated method stub

	}

	@Override
	public int getPoolSize() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setInstanceId(String schedInstId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setInstanceName(String schedName) {
		// TODO Auto-generated method stub

	}

}
