/**
 * 
 */
package com.jd.ka.smartscheduler.core.task;


/**
 * 任务的一系列操作
 * @author qiulong
 *
 */
public interface TaskOperator {
	/**
	 * 新增任务
	 * @param task
	 * @return
	 */
	boolean addTask(Task task);
	
	/**
	 * 删除任务
	 * @param task
	 * @return
	 */
	boolean removeTask(Task task);
	
	/**
	 * 更新任务
	 * @param task
	 * @return
	 */
	boolean updateTask(Task task);
	
	/**
	 * 触发任务
	 * @param task
	 * @return
	 */
	boolean trigger(Task task);
	
	/**
	 * 暂停任务
	 * @param task
	 * @return
	 */
	boolean pause(Task task);
	
	/**
	 * 恢复任务
	 * @param task
	 * @return
	 */
	boolean resume(Task task);
}
