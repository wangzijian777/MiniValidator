/**
 * 
 */
package com.jd.ka.smartscheduler.core.env;

import java.util.Properties;

import javax.sql.DataSource;

/**
 * @author qiulong
 *
 */
public abstract class Settings {
	
	abstract public Settings setDataSource(DataSource ds);
	
	abstract public Settings setSchedulerName(String name);
	
	abstract public Settings set(Object key, Object value);
	
	abstract public Settings set(Properties prop);
	
	abstract public Settings threadCount(int threadCount);
	
	abstract public Settings clustered();
	
	abstract public SettingsGetter settingGetter();
	
	public static Settings newSettings() {
		return new ImmutableSettings();
	}
}
