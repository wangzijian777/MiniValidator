package com.jd.ka.smartscheduler.core.env;

import java.util.Properties;
import java.util.Set;

import javax.sql.DataSource;

/**
 * 
 * @author qiulong
 *
 */
public class ImmutableSettings extends Settings {
	private DataSource ds;
	private boolean isClustered;
	private String schedulerName = "SmartScheduler";
	private Properties prop = new Properties();
	
	{
		//default setting
		set("org.quartz.scheduler.instanceName", schedulerName);
		set("org.quartz.scheduler.instanceId", "AUTO");
		//Thread pool setting
		set("org.quartz.scheduler.threadName", "-SmartSchedulerThread");
		set("org.quartz.threadPool.class", "org.quartz.simpl.SimpleThreadPool");
		int threadCount = Runtime.getRuntime().availableProcessors()  << 1;
		set("org.quartz.threadPool.threadCount",  String.valueOf(threadCount));
	}
	
	ImmutableSettings() {}
	
	@Override
	public Settings setDataSource(DataSource ds) {
		if(ds != null) {
			set("org.quartz.jobStore.dataSource", "DS");
			set("org.quartz.jobStore.class", "org.quartz.impl.jdbcjobstore.JobStoreTX");
			set("org.quartz.dataSource.DS.connectionProvider.class", "com.jd.ka.smartscheduler.core.env.DBConnectionProvider");
		}
		this.ds = ds;
		return this;
	}

	@Override
	public Settings setSchedulerName(String name) {
		this.schedulerName = name;
		set("org.quartz.scheduler.instanceName", name);
		return this;
	}
	
	@Override
	public Settings set(Object key, Object value) {
		prop.put(key, value);
		return this;
	}

	@Override
	public SettingsGetter settingGetter() {
		return new ImmutableSettingsGetter();
	}
	
	@Override
	public Settings threadCount(int threadCount) {
		set("org.quartz.threadPool.threadCount",  String.valueOf(threadCount));
		return this;
	}
	
	@Override
	public Settings clustered() {
		this.isClustered = true;
		set("org.quartz.jobStore.isClustered",  "true");
		return this;
	}
	
	@Override
	public Settings set(Properties prop) {
		if(prop == null) {
			return this;
		}
		Set<Object> keySet = prop.keySet();
		for (Object key : keySet) {
			set(key, prop.get(key));
		}
		return this;
	}
	
	private class ImmutableSettingsGetter implements SettingsGetter {

		@Override
		public Properties getProperties() {
			return ImmutableSettings.this.prop;
		}

		@Override
		public String getSchedulerName() {
			return ImmutableSettings.this.schedulerName;
		}

		@Override
		public DataSource getDataSource() {
			return ImmutableSettings.this.ds;
		}

		@Override
		public boolean isClustered() {
			return ImmutableSettings.this.isClustered;
		}
		
	}

}
