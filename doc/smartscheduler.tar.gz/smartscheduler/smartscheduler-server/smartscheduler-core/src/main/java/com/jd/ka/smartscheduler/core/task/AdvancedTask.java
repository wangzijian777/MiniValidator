package com.jd.ka.smartscheduler.core.task;

import java.util.TimeZone;

/**
 * 高级任务
 * @author qiulong
 *
 */
public interface AdvancedTask extends Task {
	/**
	 * Cron表达式
	 * @return
	 */
	String cronExpression();
	
	/**
	 * 获取指定的时区
	 * @return
	 */
	TimeZone timeZone();
}
