package com.jd.ka.smartscheduler.core.listener;

import com.jd.ka.smartscheduler.core.event.TaskEvent;

/**
 * 
 * @author qiulong
 *
 */
public interface TaskScheduleListener {

	/**
	 * 任务被调度
	 * @param taskEvent
	 */
	void taskExecuted(TaskEvent taskEvent);
	
	/**
	 * 任务调度失败
	 * @param taskEvent
	 */
	void taskVetoed(TaskEvent taskEvent);
	
	/**
	 * 任务被挂起
	 * @param taskEvent
	 */
	void taskPaused(TaskEvent taskEvent);
	
	/**
	 * 任务被恢复
	 * @param taskEvent
	 */
	void taskResumed(TaskEvent taskEvent);
}
