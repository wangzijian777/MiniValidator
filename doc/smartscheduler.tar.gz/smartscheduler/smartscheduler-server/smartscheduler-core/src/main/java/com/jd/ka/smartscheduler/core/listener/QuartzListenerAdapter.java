package com.jd.ka.smartscheduler.core.listener;

import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.JobListener;
import org.quartz.SchedulerException;
import org.quartz.SchedulerListener;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.quartz.utils.Key;

import com.jd.ka.smartscheduler.core.builder.TaskEventBuilder;

/**
 * Quartz的事件适配
 * 
 * @author qiulong
 *
 */
public class QuartzListenerAdapter implements SchedulerListener, JobListener {
	private final String NAME = QuartzListenerAdapter.class.getName();
	private final TaskScheduleListener target;

	public QuartzListenerAdapter(TaskScheduleListener target) {
		this.target = target;
	}

	@Override
	public void jobScheduled(Trigger trigger) {

	}

	@Override
	public void jobUnscheduled(TriggerKey triggerKey) {

	}

	@Override
	public void triggerFinalized(Trigger trigger) {

	}

	@Override
	public void triggerPaused(TriggerKey triggerKey) {
		target.taskPaused(newTaskEventBuilder(triggerKey).build());
	}

	@Override
	public void triggersPaused(String triggerGroup) {

	}

	@Override
	public void triggerResumed(TriggerKey triggerKey) {
		target.taskResumed(newTaskEventBuilder(triggerKey).build());
	}

	@Override
	public void triggersResumed(String triggerGroup) {

	}

	@Override
	public void jobAdded(JobDetail jobDetail) {

	}

	@Override
	public void jobDeleted(JobKey jobKey) {

	}

	@Override
	public void jobPaused(JobKey jobKey) {
		target.taskPaused(newTaskEventBuilder(jobKey).build());
	}

	@Override
	public void jobsPaused(String jobGroup) {

	}

	@Override
	public void jobResumed(JobKey jobKey) {
		target.taskResumed(newTaskEventBuilder(jobKey).build());
	}

	@Override
	public void jobsResumed(String jobGroup) {

	}

	@Override
	public void schedulerError(String msg, SchedulerException cause) {

	}

	@Override
	public void schedulerInStandbyMode() {

	}

	@Override
	public void schedulerStarted() {

	}

	@Override
	public void schedulerStarting() {

	}

	@Override
	public void schedulerShutdown() {

	}

	@Override
	public void schedulerShuttingdown() {

	}

	@Override
	public void schedulingDataCleared() {

	}

	@Override
	public String getName() {
		return NAME;
	}

	@Override
	public void jobToBeExecuted(JobExecutionContext context) {
		TaskEventBuilder builder = newTaskEventBuilder(
				context.getJobDetail().getKey()).setNextFireTime(
				context.getNextFireTime()).setCurrentFireTime(
				context.getFireTime());
		target.taskExecuted(builder.build());
	}

	@Override
	public void jobExecutionVetoed(JobExecutionContext context) {
		TaskEventBuilder builder = newTaskEventBuilder(
				context.getJobDetail().getKey()).setNextFireTime(
				context.getNextFireTime()).setCurrentFireTime(
				context.getFireTime());
		target.taskVetoed(builder.build());
	}

	@Override
	public void jobWasExecuted(JobExecutionContext context,
			JobExecutionException jobException) {

	}

	private <T> TaskEventBuilder newTaskEventBuilder(Key<T> key) {
		return TaskEventBuilder.newBuilder(key);
	}

}
