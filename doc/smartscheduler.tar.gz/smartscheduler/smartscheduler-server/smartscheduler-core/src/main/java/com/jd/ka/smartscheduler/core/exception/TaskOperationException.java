/**
 * 
 */
package com.jd.ka.smartscheduler.core.exception;

/**
 * @author qiulong
 *
 */
public class TaskOperationException extends UnsightException {
	private static final long serialVersionUID = 1L;

	public TaskOperationException() {
		super();
	}

	public TaskOperationException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public TaskOperationException(String message, Throwable cause) {
		super(message, cause);
	}

	public TaskOperationException(String message) {
		super(message);
	}

	public TaskOperationException(Throwable cause) {
		super(cause);
	}

}
