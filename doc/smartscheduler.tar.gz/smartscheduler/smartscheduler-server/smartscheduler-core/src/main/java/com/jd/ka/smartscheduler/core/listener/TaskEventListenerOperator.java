/**
 * 
 */
package com.jd.ka.smartscheduler.core.listener;


/**
 * 添加/删除{@link TaskEventListener}操作
 * @author qiulong
 *
 */
public interface TaskEventListenerOperator {
	/**
	 * 添加{@link TaskEventListener}监听
	 * @param listener
	 */
	void addTaskEventListener(TaskEventListener listener);
	
	/**
	 * 删除{@link TaskEventListener}监听
	 * @param listener
	 */
	void removeTaskEventListener(TaskEventListener listener);
}
