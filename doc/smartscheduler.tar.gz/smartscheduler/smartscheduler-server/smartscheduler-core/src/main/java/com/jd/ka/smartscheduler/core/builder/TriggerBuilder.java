package com.jd.ka.smartscheduler.core.builder;

import org.quartz.CronScheduleBuilder;
import org.quartz.ScheduleBuilder;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;

import com.jd.ka.smartscheduler.core.task.AdvancedTask;
import com.jd.ka.smartscheduler.core.task.SimpleTask;
import com.jd.ka.smartscheduler.core.task.Task;

/**
 * 通过{@link com.jd.ka.smartscheduler.core.task.Task}构建{@link org.quartz.Trigger} 
 * @author qiulong
 *
 */
public class TriggerBuilder {
	private Task task;
	
	public static TriggerBuilder newBuilder(Task task) {
		TriggerBuilder builder = new TriggerBuilder();
		builder.task = task;
		return builder;
	}
	
	@SuppressWarnings("unchecked")
	public Trigger build() {
		org.quartz.TriggerBuilder<Trigger> triggerBuilder = org.quartz.TriggerBuilder.newTrigger();
		triggerBuilder.withIdentity(task.getName(), task.getGroup());
		//如果没有设置开始时间，默认为立即执行
		if(task.startTime() != null) {
			triggerBuilder.startAt(task.startTime());
		} else {
			triggerBuilder.startNow();
		}
		if(task.endTime() != null) {
			triggerBuilder.endAt(task.endTime());
		}
		//Schedule builder
		ScheduleBuilder<Trigger> scheduleBuilder = null;
		if(task instanceof SimpleTask) {
			scheduleBuilder = scheduleBuilder((SimpleTask) task);
		}
		if(task instanceof AdvancedTask) {
			scheduleBuilder = scheduleBuilder((AdvancedTask) task);
		}
		
		if(scheduleBuilder == null) {
			throw new NullPointerException("ScheduleBuilder cannot be null");
		}
		
		triggerBuilder.withSchedule(scheduleBuilder);
		return triggerBuilder.build();
	}
	
	@SuppressWarnings("rawtypes")
	private ScheduleBuilder scheduleBuilder(SimpleTask task) {
		SimpleScheduleBuilder simpleSchedule = SimpleScheduleBuilder.simpleSchedule();
		if(task.repeatForever()) {
			simpleSchedule.repeatForever();
		} else 	if(task.repeatCount() > 1) {
			simpleSchedule.withRepeatCount(task.repeatCount() - 1);
		}
		switch(task.timeUnit()) {
			case MILLISECONDS: {
				simpleSchedule.withIntervalInMilliseconds(task.intervalTime());
				break;
			}
			case SECONDS: {
				simpleSchedule.withIntervalInSeconds((int) task.intervalTime());
				break;
			}
			case MINUTES: {
				simpleSchedule.withIntervalInMinutes((int) task.intervalTime());
				break;
			}
			case HOURS: {
				simpleSchedule.withIntervalInHours((int) task.intervalTime());
				break;
			}
		}
		
		return simpleSchedule;
	}
	
	@SuppressWarnings("rawtypes")
	private ScheduleBuilder scheduleBuilder(AdvancedTask task) {
		CronScheduleBuilder cronSchedule = CronScheduleBuilder.cronSchedule(task.cronExpression());
		if(task.timeZone() != null) {
			cronSchedule.inTimeZone(task.timeZone());
		}
		return cronSchedule;
	}
	
}
