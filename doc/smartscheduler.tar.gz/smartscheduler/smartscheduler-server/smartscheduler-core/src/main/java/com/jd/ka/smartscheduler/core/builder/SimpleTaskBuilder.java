package com.jd.ka.smartscheduler.core.builder;

import java.util.Date;

import com.jd.ka.smartscheduler.core.task.SimpleTask;
import com.jd.ka.smartscheduler.core.task.Task;
import com.jd.ka.smartscheduler.core.task.TimeUnit;

/**
 * 简单任务构建
 * 
 * @author qiulong
 *
 */
public class SimpleTaskBuilder extends TaskBuilder {
	private boolean repeatForever;
	private int repeatCount;
	private long intervalTime;
	private TimeUnit timeUnit;

	@Override
	public Task build() {
		return new SimpleTaskImpl();
	}

	/**
	 * 不断重复执行，设置此值会忽略{@link #setRepeatCount(int)}
	 * @return
	 */
	public SimpleTaskBuilder repeatForever() {
		this.repeatForever = true;
		return this;
	}

	/**
	 * 设置重复次数
	 * @param repeatCount
	 * @return
	 */
	public SimpleTaskBuilder setRepeatCount(int repeatCount) {
		this.repeatCount = repeatCount;
		return this;
	}

	/**
	 * 设置执行间隔时间
	 * @param intervalTime
	 * @param timeUnit
	 * @return
	 */
	public SimpleTaskBuilder setIntervalTime(long intervalTime, TimeUnit timeUnit) {
		this.intervalTime = intervalTime;
		this.timeUnit = timeUnit;
		return this;
	}

	private class SimpleTaskImpl implements SimpleTask {

		@Override
		public String getName() {
			return name;
		}

		@Override
		public String getGroup() {
			return group;
		}

		@Override
		public String getDescription() {
			return description;
		}

		@Override
		public boolean shouldDurability() {
			return durability;
		}

		@Override
		public boolean shouldRecovery() {
			return recovery;
		}

		@Override
		public Date startTime() {
			return startTime;
		}

		@Override
		public Date endTime() {
			return endTime;
		}

		@Override
		public boolean repeatForever() {
			return repeatForever;
		}

		@Override
		public int repeatCount() {
			return repeatCount;
		}

		@Override
		public long intervalTime() {
			return intervalTime;
		}

		@Override
		public TimeUnit timeUnit() {
			return timeUnit;
		}

		@Override
		public String toString() {
			return "SimpleTaskImpl [getName()=" + getName() + ", getGroup()="
					+ getGroup() + ", getDescription()=" + getDescription()
					+ ", shouldDurability()=" + shouldDurability()
					+ ", shouldRecovery()=" + shouldRecovery()
					+ ", startTime()=" + startTime() + ", endTime()="
					+ endTime() + ", repeatForever()=" + repeatForever()
					+ ", repeatCount()=" + repeatCount() + ", intervalTime()="
					+ intervalTime() + ", timeUnit()=" + timeUnit() + "]";
		}

	}

}
