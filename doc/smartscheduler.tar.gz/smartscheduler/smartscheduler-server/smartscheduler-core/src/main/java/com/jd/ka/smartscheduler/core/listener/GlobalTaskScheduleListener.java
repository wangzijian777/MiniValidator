package com.jd.ka.smartscheduler.core.listener;

import com.jd.ka.smartscheduler.core.event.Event;
import com.jd.ka.smartscheduler.core.event.TaskEvent;
import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;

/**
 * 
 * @author qiulong
 *
 */
public class GlobalTaskScheduleListener implements TaskScheduleListener {
	private Logger logger = LoggerFactory.getLogger(getClass(), "SmartScheduler-core");
	private final TaskEventListenerManager listenerManager;

	/**
	 * @param listenerManager
	 */
	public GlobalTaskScheduleListener(TaskEventListenerManager listenerManager) {
		this.listenerManager = listenerManager;
	}

	@Override
	public void taskExecuted(TaskEvent taskEvent) {
		pushEvent(Event.TaskExecuted, taskEvent);
	}

	@Override
	public void taskVetoed(TaskEvent taskEvent) {
		pushEvent(Event.TaskVetoed, taskEvent);
	}

	@Override
	public void taskPaused(TaskEvent taskEvent) {
		pushEvent(Event.TaskPaused, taskEvent);
	}

	@Override
	public void taskResumed(TaskEvent taskEvent) {
		pushEvent(Event.TaskResumed, taskEvent);
	}

	private void pushEvent(Event event, TaskEvent taskEvent) {
		logger.debug("Push task [name={}, group={}] event [{}]", taskEvent.getName(), taskEvent.getGroup(), event);
		listenerManager.pushEvent(event, taskEvent);
	}
}
