/**
 * 
 */
package com.jd.ka.smartscheduler.core.task;

import java.util.Date;


/**
 * @author qiulong
 *
 */
public interface Task {
	/**
	 * 任务名称，对应{@link org.quartz.JobKey#getName()}和{@link org.quartz.TriggerKey#getName()},
	 * <strong>必须是唯一的</strong>
	 * @return
	 */
	String getName();
	
	/**
	 * 任务所属的组，对应{@link org.quartz.JobKey#getGroup()}和{@link org.quartz.TriggerKey#getGroup()}
	 * @return
	 */
	String getGroup();
	
	/**
	 * 获取Job的描述信息
	 * @return
	 */
	String getDescription();

	/**
	 * 是否持久化Job
	 * @return true 是，false 否
	 */
	boolean shouldDurability();
	
	/**
	 * “故障恢复”或“故障转移”发生时，是否重新执行任务
	 * @return true 是，false 否
	 */
	boolean shouldRecovery();
	
	/**
	 * 开始时间
	 * @return
	 */
	Date startTime();
	
	/**
	 * 结束时间
	 * @return
	 */
	Date endTime();
	
}
