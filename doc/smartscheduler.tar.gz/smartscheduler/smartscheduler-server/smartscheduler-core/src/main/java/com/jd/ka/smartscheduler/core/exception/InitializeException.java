/**
 * 
 */
package com.jd.ka.smartscheduler.core.exception;

/**
 * @author qiulong
 *
 */
public class InitializeException extends UnsightException {
	private static final long serialVersionUID = 1L;

	public InitializeException() {
		super();
	}

	public InitializeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InitializeException(String message, Throwable cause) {
		super(message, cause);
	}

	public InitializeException(String message) {
		super(message);
	}

	public InitializeException(Throwable cause) {
		super(cause);
	}

}
