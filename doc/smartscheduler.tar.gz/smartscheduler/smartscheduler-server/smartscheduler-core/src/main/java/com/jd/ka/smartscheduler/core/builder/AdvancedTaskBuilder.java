package com.jd.ka.smartscheduler.core.builder;

import java.util.Date;
import java.util.TimeZone;

import com.jd.ka.smartscheduler.core.task.AdvancedTask;
import com.jd.ka.smartscheduler.core.task.Task;

/**
 * 高级任务构建
 * @author qiulong
 *
 */
public class AdvancedTaskBuilder extends TaskBuilder {
	private String cronExpression;
	private TimeZone timeZone;
	
	public AdvancedTaskBuilder setCronExpression(String cronExpression) {
		this.cronExpression = cronExpression;
		return this;
	}
	
	public AdvancedTaskBuilder setTimeZone(TimeZone timeZone) {
		this.timeZone = timeZone;
		return this;
	}

	@Override
	public Task build() {
		return new AdvancedTaskImpl();
	}
	
	private class AdvancedTaskImpl implements AdvancedTask {

		@Override
		public String getName() {
			return name;
		}

		@Override
		public String getGroup() {
			return group;
		}

		@Override
		public String getDescription() {
			return description;
		}

		@Override
		public boolean shouldDurability() {
			return durability;
		}

		@Override
		public boolean shouldRecovery() {
			return recovery;
		}

		@Override
		public Date startTime() {
			return startTime;
		}

		@Override
		public Date endTime() {
			return endTime;
		}

		@Override
		public String cronExpression() {
			return cronExpression;
		}

		@Override
		public TimeZone timeZone() {
			return timeZone;
		}

		@Override
		public String toString() {
			return "AdvancedTaskImpl [getName()=" + getName() + ", getGroup()="
					+ getGroup() + ", getDescription()=" + getDescription()
					+ ", shouldDurability()=" + shouldDurability()
					+ ", shouldRecovery()=" + shouldRecovery()
					+ ", startTime()=" + startTime() + ", endTime()="
					+ endTime() + ", cronExpression()=" + cronExpression()
					+ ", timeZone()=" + timeZone() + "]";
		}
		
	}

}
