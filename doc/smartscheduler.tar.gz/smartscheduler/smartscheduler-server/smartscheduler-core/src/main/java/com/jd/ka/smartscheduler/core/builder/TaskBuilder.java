/**
 * 
 */
package com.jd.ka.smartscheduler.core.builder;

import java.util.Date;

import com.jd.ka.smartscheduler.core.task.Task;

/**
 * 任务构建器
 * 
 * @author qiulong
 * 
 */
public abstract class TaskBuilder {
	protected String name;
	protected String group;
	protected String description;
	protected boolean durability;
	protected boolean recovery;
	protected Date startTime;
	protected Date endTime;

	/**
	 * 创建一个简单任务构建器实例
	 * 
	 * @param name
	 *            任务名称
	 * @param group
	 *            所属组
	 * @return
	 */
	public static SimpleTaskBuilder newSimpleTaskBuilder(String name,
			String group) {
		SimpleTaskBuilder builder = new SimpleTaskBuilder();
		builder.name = name;
		builder.group = group;
		return builder;
	}

	/**
	 * 创建一个高级任务构建器实例
	 * 
	 * @param name
	 *            任务名称
	 * @param group
	 *            所属组
	 * @return
	 */
	public static AdvancedTaskBuilder newAdvancedTaskBuilder(String name,
			String group) {
		AdvancedTaskBuilder builder = new AdvancedTaskBuilder();
		builder.name = name;
		builder.group = group;
		return builder;
	}

	public TaskBuilder requireRecovery() {
		this.recovery = true;
		return this;
	}

	public TaskBuilder setDescription(String description) {
		this.description = description;
		return this;
	}

	public TaskBuilder startAt(Date startTime) {
		this.startTime = startTime;
		return this;
	}

	public TaskBuilder endAt(Date endTime) {
		this.endTime = endTime;
		return this;
	}

	abstract public Task build();

}
