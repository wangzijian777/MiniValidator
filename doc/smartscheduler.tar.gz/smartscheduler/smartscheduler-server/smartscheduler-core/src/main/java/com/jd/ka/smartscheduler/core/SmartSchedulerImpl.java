/**
 * 
 */
package com.jd.ka.smartscheduler.core;

import javax.sql.DataSource;

import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;

import com.jd.ka.smartscheduler.core.builder.JobDetailBuilder;
import com.jd.ka.smartscheduler.core.builder.TriggerBuilder;
import com.jd.ka.smartscheduler.core.env.DataSourceHolder;
import com.jd.ka.smartscheduler.core.env.SettingsGetter;
import com.jd.ka.smartscheduler.core.exception.InitializeException;
import com.jd.ka.smartscheduler.core.exception.StartException;
import com.jd.ka.smartscheduler.core.exception.StopException;
import com.jd.ka.smartscheduler.core.exception.TaskOperationException;
import com.jd.ka.smartscheduler.core.listener.GlobalTaskScheduleListener;
import com.jd.ka.smartscheduler.core.listener.QuartzListenerAdapter;
import com.jd.ka.smartscheduler.core.listener.TaskEventListener;
import com.jd.ka.smartscheduler.core.listener.TaskEventListenerManager;
import com.jd.ka.smartscheduler.core.listener.TaskEventListenerManagerImpl;
import com.jd.ka.smartscheduler.core.task.Task;
import com.jd.ka.smartscheduler.logging.Logger;
import com.jd.ka.smartscheduler.logging.LoggerFactory;

/**
 * @author qiulong
 *
 */
public class SmartSchedulerImpl implements SmartScheduler {
	private Logger logger = LoggerFactory.getLogger(getClass(), "SmartScheduler-core");
	private Scheduler scheduler;
	private TaskEventListenerManager listenerManager;
	
	public SmartSchedulerImpl(SettingsGetter getter) {
		initDB(getter);
		initScheduler(getter);
	}

	@Override
	public void addTaskEventListener(TaskEventListener listener) {
		this.listenerManager.addTaskEventListener(listener);
	}

	@Override
	public void removeTaskEventListener(TaskEventListener listener) {
		this.listenerManager.removeTaskEventListener(listener);
	}

	@Override
	public boolean addTask(Task task) {
		try {
			logger.debug("Add task [{}]", task);
			JobDetail jobDetail = JobDetailBuilder.newBuilder(task).build();
			if(this.checkExists(jobDetail.getKey())) {
				throw new TaskOperationException("Task [" + task.getName() +"," + task.getGroup() +"] already exist");
			}
			Trigger trigger = TriggerBuilder.newBuilder(task).build();
			this.scheduler.scheduleJob(jobDetail, trigger);
			return true;
		} catch (SchedulerException e) {
			logger.error("Add task [{}, {}] failed", e, task.getName(), task.getGroup());
			return false;
		}
	}

	@Override
	public boolean removeTask(Task task) {
		try {
			logger.debug("Remove task [{}]", task);
			this.scheduler.unscheduleJob(TriggerKey.triggerKey(task.getName(), task.getGroup()));
			return true;
		} catch (SchedulerException e) {
			logger.error("Delete task [{}, {}] failed", e, task.getName(), task.getGroup());
			return false;
		}
	}

	@Override
	public boolean updateTask(Task task) {
		try {
			logger.debug("Update task [{}]", task);
			JobDetail jobDetail = JobDetailBuilder.newBuilder(task).build();
			Trigger trigger = this.scheduler.getTrigger(TriggerKey.triggerKey(task.getName(), task.getGroup()));
			this.scheduler.deleteJob(JobKey.jobKey(task.getName(), task.getGroup()));
			this.scheduler.scheduleJob(jobDetail, trigger);
			return true;
		} catch (SchedulerException e) {
			logger.error("Update task [{}, {}] failed", e, task.getName(), task.getGroup());
			return false;
		}
	}
	
	@Override
	public boolean trigger(Task task) {
		try {
			logger.debug("Trigger task [{}]", task);
			this.scheduler.triggerJob(JobKey.jobKey(task.getName(), task.getGroup()));
			return true;
		} catch (SchedulerException e) {
			logger.error("Trigger task [{}, {}] failed", e, task.getName(), task.getGroup());
			return false;
		}
	}
	
	@Override
	public boolean pause(Task task) {
		try {
			logger.debug("Pause task [{}]", task);
			this.scheduler.pauseTrigger(TriggerKey.triggerKey(task.getName(), task.getGroup()));
			return true;
		} catch (SchedulerException e) {
			logger.error("Pause task [{}, {}] failed", e, task.getName(), task.getGroup());
		}
		return false;
	}
	
	@Override
	public boolean resume(Task task) {
		try {
			logger.debug("Resume task [{}]", task);
			this.scheduler.resumeTrigger(TriggerKey.triggerKey(task.getName(), task.getGroup()));
			return true;
		} catch (SchedulerException e) {
			logger.error("Resume task [{}, {}] failed", e, task.getName(), task.getGroup());
		}
		return false;
	}
	
	@Override
	public void start() {
		try {
			logger.trace("Ready to start SmartScheduler");
			this.scheduler.start();
			Thread.sleep(3000L);
			logger.info("SmartScheduler started success");
		} catch (SchedulerException e) {
			throw new StartException("SmartScheduler start failed", e);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	@Override
	public void stop() {
		try {
			this.scheduler.shutdown();
			logger.info("SmartScheduler stopped success");
		} catch (SchedulerException e) {
			throw new StopException("SmartScheduler stop failed", e);
		}
	}
	
	@Override
	public void stopWaitForComplete() {
		try {
			this.scheduler.shutdown(true);
			logger.info("SmartScheduler stop  wait for jobs complete  success");
		} catch (SchedulerException e) {
			throw new StopException("SmartScheduler stop failed", e);
		}
	}
	
	@Override
	public boolean isShutdown() {
		try {
			return this.scheduler.isShutdown();
		} catch (SchedulerException e) {
			logger.error("Call [isShutdown()] method error", e);
			return false;
		}
	}

	@Override
	public boolean isStarted() {
		try {
			return this.scheduler.isStarted();
		} catch (SchedulerException e) {
			logger.error("Call [isStarted()] method error", e);
			return false;
		}
	}
	
	protected boolean checkExists(JobKey jobKey) {
		try {
			return this.scheduler.checkExists(jobKey);
		} catch (SchedulerException e) {
			logger.error("Call [checkExists(name:{}, group:{})] method error", jobKey.getName(), jobKey.getGroup(), e);
			return false;
		}
	}
	
	protected boolean checkExists(TriggerKey triggerKey) {
		try {
			return this.scheduler.checkExists(triggerKey);
		} catch (SchedulerException e) {
			logger.error("Call [checkExists(name:{}, group:{})] method error", triggerKey.getName(), triggerKey.getGroup(), e);
			return false;
		}
	}
	
	private void initScheduler(SettingsGetter getter) {
		try {
			this.listenerManager = new TaskEventListenerManagerImpl();
			SchedulerFactory schedulerFactory = new StdSchedulerFactory(getter.getProperties());
			this.scheduler = schedulerFactory.getScheduler();
			QuartzListenerAdapter quartzListenerAdapter = new QuartzListenerAdapter(new GlobalTaskScheduleListener(listenerManager));
			this.scheduler.getListenerManager().addSchedulerListener(quartzListenerAdapter);
			this.scheduler.getListenerManager().addJobListener(quartzListenerAdapter);
		} catch (SchedulerException e) {
			throw new InitializeException(e);
		}
	}

	private void initDB(SettingsGetter getter) {
		DataSource dataSource = getter.getDataSource();
		if(dataSource != null) {
			logger.debug("Initialize with specified DataSource");
			DataSourceHolder.init(dataSource);
		} else if(getter.isClustered()) {
			throw new StartException("You must specified a DataSource when used cluster");
		} else {
			logger.warn("Create SmartScheduler without DataSource. We will utilizes RAM as its storage device!");
		}
	}

}
