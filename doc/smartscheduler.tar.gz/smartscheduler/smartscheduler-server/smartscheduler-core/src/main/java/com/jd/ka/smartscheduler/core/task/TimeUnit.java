package com.jd.ka.smartscheduler.core.task;

/**
 * 时间单位
 * @author qiulong
 *
 */
public enum TimeUnit {
	MILLISECONDS, SECONDS, MINUTES, HOURS;
}
