/**
 * 
 */
package com.jd.ka.smartscheduler.core.env;

import java.util.Properties;

import javax.sql.DataSource;

/**
 * @author qiulong
 *
 */
public interface SettingsGetter {
	Properties getProperties();
	String getSchedulerName();
	DataSource getDataSource();
	boolean isClustered();
}
