package com.jd.ka.smartscheduler.core.event;

/**
 * 
 * @author qiulong
 *
 */
public enum Event {
	TaskExecuted, TaskPaused, TaskResumed, TaskVetoed;
}
