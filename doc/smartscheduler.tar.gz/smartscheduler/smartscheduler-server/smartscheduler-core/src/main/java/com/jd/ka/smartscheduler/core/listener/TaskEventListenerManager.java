/**
 * 
 */
package com.jd.ka.smartscheduler.core.listener;

import com.jd.ka.smartscheduler.core.event.Event;
import com.jd.ka.smartscheduler.core.event.TaskEvent;

/**
 * @author qiulong
 *
 */
public interface TaskEventListenerManager extends TaskEventListenerOperator {
	void pushEvent(Event event, TaskEvent taskEvent);
}
