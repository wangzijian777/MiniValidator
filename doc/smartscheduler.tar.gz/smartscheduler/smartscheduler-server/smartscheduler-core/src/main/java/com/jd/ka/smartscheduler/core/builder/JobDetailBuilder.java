package com.jd.ka.smartscheduler.core.builder;

import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.jd.ka.smartscheduler.core.event.TaskEvent;
import com.jd.ka.smartscheduler.core.listener.TaskEventListener;
import com.jd.ka.smartscheduler.core.task.Task;

/**
 * {@link Task}转换成{@link JobDetail}
 * @author qiulong
 * 
 */
public class JobDetailBuilder {
	private Task task;

	public static JobDetailBuilder newBuilder(Task task) {
		JobDetailBuilder builder = new JobDetailBuilder();
		builder.task = task;
		return builder;
	}

	public JobDetail build() {
		return JobBuilder.newJob(EmptyJob.class)
				.requestRecovery(task.shouldRecovery())
				.storeDurably(task.shouldDurability())
				.withIdentity(task.getName(), task.getGroup())
				.withDescription(task.getDescription()).build();
	}

	/**
	 * 空的Job实现，我们通过{@link JobListener}的方式来实现任务的触发监听。
	 * 当监听到有任务触发时，通过传递{@link TaskEvent}来通知{@link TaskEventListener}监听者。
	 * @author qiulong
	 *
	 */
	public static class EmptyJob implements Job {

		@Override
		public void execute(JobExecutionContext context)
				throws JobExecutionException {
			// Do nothing
		}

	}

}
