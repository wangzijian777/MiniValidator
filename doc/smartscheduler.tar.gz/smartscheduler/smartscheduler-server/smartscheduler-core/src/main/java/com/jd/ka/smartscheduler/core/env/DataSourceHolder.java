/**
 * 
 */
package com.jd.ka.smartscheduler.core.env;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

/**
 * @author qiulong
 *
 */
public abstract class DataSourceHolder {
	private static DataSource dataSource;
	
	public static void init(DataSource ds) {
		if(ds == null) {
			throw new NullPointerException("DataSource cannot be Null");
		}
		DataSourceHolder.dataSource = ds;
	}
	
	public static Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}
	
	public static DataSource getDataSource() {
		return dataSource;
	}
}
