/**
 * 
 */
package com.jd.ka.smartscheduler.core;

import com.jd.ka.smartscheduler.core.listener.TaskEventListenerOperator;
import com.jd.ka.smartscheduler.core.task.TaskOperator;

/**
 * 调度服务
 * @author qiulong
 *
 */
public interface SmartScheduler extends TaskEventListenerOperator, TaskOperator {

	/**
	 * 运行调度服务
	 */
	void start();
	
	/**
	 * 立即停止调度服务
	 */
	void stop();
	
	/**
	 * 等待正在执行的任务完成后停止调度服务
	 */
	void stopWaitForComplete();
	
	/**
	 * 是否已停止
	 * @return
	 */
	boolean isShutdown();
	
	/**
	 * 是否已经启动
	 * @return
	 */
	boolean isStarted();
	
}
