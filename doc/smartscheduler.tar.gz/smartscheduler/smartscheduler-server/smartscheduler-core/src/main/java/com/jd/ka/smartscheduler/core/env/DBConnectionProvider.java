/**
 * 
 */
package com.jd.ka.smartscheduler.core.env;

import java.sql.Connection;
import java.sql.SQLException;

import org.quartz.utils.ConnectionProvider;

/**
 * @author qiulong
 *
 */
public class DBConnectionProvider implements ConnectionProvider {

	@Override
	public Connection getConnection() throws SQLException {
		return DataSourceHolder.getConnection();
	}

	@Override
	public void initialize() throws SQLException {
		//Do nothing
	}

	@Override
	public void shutdown() throws SQLException {
		//Do nothing
	}

}
