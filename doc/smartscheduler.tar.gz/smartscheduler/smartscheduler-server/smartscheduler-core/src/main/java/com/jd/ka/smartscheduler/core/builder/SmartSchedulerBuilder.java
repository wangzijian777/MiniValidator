/**
 * 
 */
package com.jd.ka.smartscheduler.core.builder;

import com.jd.ka.smartscheduler.core.SmartScheduler;
import com.jd.ka.smartscheduler.core.SmartSchedulerImpl;
import com.jd.ka.smartscheduler.core.env.Settings;

/**
 * @author qiulong
 *
 */
public class SmartSchedulerBuilder {
	private Settings settings;
	
	public static SmartSchedulerBuilder newBuilder(Settings settings) {
		SmartSchedulerBuilder builder = new SmartSchedulerBuilder();
		builder.settings = settings;
		return builder;
	}
	
	public SmartScheduler build() {
		return new SmartSchedulerImpl(settings.settingGetter());
	}
}
