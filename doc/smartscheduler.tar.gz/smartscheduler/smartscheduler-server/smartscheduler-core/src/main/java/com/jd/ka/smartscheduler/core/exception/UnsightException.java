/**
 * 
 */
package com.jd.ka.smartscheduler.core.exception;

/**
 * @author qiulong
 *
 */
public class UnsightException extends RuntimeException {
	private static final long serialVersionUID = 7768382679650470886L;

	public UnsightException() {
		super();
	}

	public UnsightException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public UnsightException(String message, Throwable cause) {
		super(message, cause);
	}

	public UnsightException(String message) {
		super(message);
	}

	public UnsightException(Throwable cause) {
		super(cause);
	}

}
