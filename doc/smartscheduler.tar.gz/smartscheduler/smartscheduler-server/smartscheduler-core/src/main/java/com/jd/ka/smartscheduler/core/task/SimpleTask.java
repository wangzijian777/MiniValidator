package com.jd.ka.smartscheduler.core.task;

/**
 * 普通任务
 * @author qiulong
 *
 */
public interface SimpleTask extends Task {
	
	/**
	 * 不断重复执行，当为true时，会忽略{@link #repeatForever()}和{@link #repeatCount()}的值
	 * @return
	 */
	boolean repeatForever();
	
	/**
	 * 重复次数，当它大于2时{@link #repeatForever()}默认设置为true
	 * @return
	 */
	int repeatCount();
	
	/**
	 * 间隔时间
	 * @return
	 */
	long intervalTime();
	
	/**
	 * 时间单元
	 * @return
	 */
	TimeUnit timeUnit();
}
