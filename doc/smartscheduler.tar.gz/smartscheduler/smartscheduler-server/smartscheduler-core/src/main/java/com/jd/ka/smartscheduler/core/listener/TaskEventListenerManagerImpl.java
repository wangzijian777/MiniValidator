/**
 * 
 */
package com.jd.ka.smartscheduler.core.listener;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.jd.ka.smartscheduler.core.event.Event;
import com.jd.ka.smartscheduler.core.event.TaskEvent;

/**
 * @author qiulong
 *
 */
public class TaskEventListenerManagerImpl implements TaskEventListenerManager {
	private List<TaskEventListener> listeners = new ArrayList<TaskEventListener>();
	private ReadWriteLock rwLock = new ReentrantReadWriteLock();

	@Override
	public void addTaskEventListener(TaskEventListener listener) {
		Lock writerLock = rwLock.writeLock();
		try {
			writerLock.lock();
			listeners.add(listener);
		} finally {
			writerLock.unlock();
		}
	}

	@Override
	public void removeTaskEventListener(TaskEventListener listener) {
		Lock writerLock = rwLock.writeLock();
		try {
			writerLock.lock();
			listeners.remove(listener);
		} finally {
			writerLock.unlock();
		}
	}

	@Override
	public void pushEvent(Event event, TaskEvent taskEvent) {
		Lock readerLock = rwLock.readLock();
		try {
			readerLock.lock();
			for (TaskEventListener listener : listeners) {
				if(event == listener.matchEvent()) {
					listener.fireEvent(taskEvent);
				}
			}
		} finally {
			readerLock.unlock();
		}
	}

}
