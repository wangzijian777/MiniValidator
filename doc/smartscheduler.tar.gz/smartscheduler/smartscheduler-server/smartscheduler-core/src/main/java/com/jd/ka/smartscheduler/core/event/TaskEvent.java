/**
 * 
 */
package com.jd.ka.smartscheduler.core.event;

import java.util.Date;

/**
 * @author qiulong
 *
 */
public interface TaskEvent {
	
	/**
	 * 任务名称
	 * @return
	 */
	String getName();
	
	/**
	 * 任务所属组
	 * @return
	 */
	String getGroup();
	
	/**
	 * 上次触发时间
	 * @return
	 */
	Date getCurrentFireTime();
	
	/**
	 * 下次触发时间
	 * @return
	 */
	Date getNextFireTime();
}
