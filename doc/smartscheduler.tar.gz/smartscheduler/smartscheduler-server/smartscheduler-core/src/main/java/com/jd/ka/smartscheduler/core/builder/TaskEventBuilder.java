/**
 * 
 */
package com.jd.ka.smartscheduler.core.builder;

import java.util.Date;

import org.quartz.utils.Key;

import com.jd.ka.smartscheduler.core.event.TaskEvent;

/**
 * @author qiulong
 * 
 */
public class TaskEventBuilder {
	private String name;
	private String group;
	/**
	 * 本次触发时间
	 */
	private Date currentFireTime;
	/**
	 * 下次触发时间
	 */
	private Date nextFireTime;

	public static <T> TaskEventBuilder newBuilder(Key<T> key) {
		TaskEventBuilder builder = new TaskEventBuilder();
		builder.name = key.getName();
		builder.group = key.getGroup();
		return builder;
	}
	
	public TaskEventBuilder setCurrentFireTime(Date date) {
		currentFireTime = date;
		return this;
	}
	
	public TaskEventBuilder setNextFireTime(Date date) {
		nextFireTime = date;
		return this;
	}

	public TaskEvent build() {
		return new TaskEvent() {

			@Override
			public String getName() {
				return name;
			}

			@Override
			public String getGroup() {
				return group;
			}

			@Override
			public Date getCurrentFireTime() {
				return currentFireTime;
			}

			@Override
			public Date getNextFireTime() {
				return nextFireTime;
			}
		};
	}
}
