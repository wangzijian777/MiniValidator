/**
 * 
 */
package com.jd.ka.smartscheduler.core.listener;

import com.jd.ka.smartscheduler.core.event.Event;
import com.jd.ka.smartscheduler.core.event.TaskEvent;

/**
 * @author qiulong
 *
 */
public interface TaskEventListener {
	void fireEvent(TaskEvent taskEvent);
	
	Event matchEvent();
}
