package com.jd.ka.smartscheduler.client.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.jd.ka.smartscheduler.executor.JobShardingExecutor;
import com.jd.ka.smartscheduler.executor.ModShardStrategy;
import com.jd.ka.smartscheduler.job.Job;
import com.jd.ka.smartscheduler.reportor.Reporter;

/**
 * 
 * @author qiulong
 *
 */
public class JobShardingExecutorCase implements JobShardingExecutor<Long> {
	private List<Long> simulateDatas = new ArrayList<Long>();
	private int lastIndex = 0;

	public JobShardingExecutorCase() {
		for (long i = 0; i < 100; i++) {
			simulateDatas.add(i);
		}
	}

	@Override
	public List<Long> shard(Job job, ModShardStrategy shardStrategy) {
		int divisor = shardStrategy.divisor();
		int[] mod = shardStrategy.mod();
		int limit = shardStrategy.limit();

		List<Long> list = new ArrayList<Long>();
		int index = 0;
		int size = simulateDatas.size();
		for (int i = lastIndex; i < size; lastIndex = ++i) {
			// 每次取limit数量的数据
			if (index > limit) {
				break;
			}
			Long data = simulateDatas.get(i);
			index++;
			if (in((data % divisor), mod)) {
				list.add(data);
			}
		}
		return list;
	}
	
	private boolean in(long i, int[] mods) {
		for (int j : mods) {
			if(j == i) {
				return true;
			}
		}
		return false;
	}

	@Override
	public int execute(Job job, Reporter reporter, Iterator<Long> shards) {
		String name = Thread.currentThread().getName();
		int i = 0;
		while (shards.hasNext()) {
			System.out.println(name + " id = " + shards.next());
			try {
				Thread.sleep(500L);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			i++;
		}
		return i;
	}

}
