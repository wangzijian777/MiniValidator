package com.jd.ka.smartscheduler.client.test.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.jd.ka.smartscheduler.Client;
import com.jd.ka.smartscheduler.client.test.JobShardingExecutorCase;
import com.jd.ka.smartscheduler.data.Parameter;

/**
 * Servlet implementation class ScheduleServlet
 */
@Controller
@RequestMapping("test")
public class ScheduleController {

	@RequestMapping
	public void execute(OutputStream os, @RequestParam Map<String, Object> map) throws IOException {
		Client.execute(new JobShardingExecutorCase(), new Parameter(map), os);
	}

}
