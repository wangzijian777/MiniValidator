package com.jd.hackathon.one.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.jd.hackathon.one.bean.OnePricture;
import com.jd.hackathon.one.util.DateUtils;
import com.mysql.jdbc.Statement;

/**
 * 
 * @Project：one
 * @Package：com.jd.hackathon.one.dao.impl
 * @ClassName: OneprictureDaoImpl
 * @Description: TODO(用一句话描述该文件做什么)
 * @author：wangjingzhao
 * @date 2015-6-26 下午9:05:57
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since: JDK 1.6
 * @Version： V1.0
 * 
 */
@Repository
public class OneprictureDao {
	@Autowired
	protected JdbcTemplate jdbcTemplate;

	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用)
	 * @author wangjingzhao
	 * @createDate 2015-6-26 下午9:17:23
	 * @param @param param
	 * @param @return
	 * @return List<OnePricture>
	 * @throws ParseException
	 * @exception
	 * @throws
	 * @lastModify
	 */
	public List<OnePricture> getOneprictures(OnePricture onePricture) throws ParseException {
		List<OnePricture> onePics = new ArrayList<OnePricture>();
		Map<String, Object> param = new HashMap<String, Object>();
		String sql = "select * from  one_picture where 0=0";
		if (null != onePricture) {
			if (onePricture.getLoveId() != 0) {
				param.put("love_id", onePricture.getLoveId());
			}
			if (onePricture.getPicSpotId() != 0) {
				param.put("pic_spot_id", onePricture.getPicSpotId());
			}
			if (onePricture.getCreateTime() != null) {
				param.put("create_time", onePricture.getCreateTime());
			}
			if (onePricture.getCreateTime() != null) {
				param.put("state", onePricture.getState());
			}
		}
		for (String key : param.keySet()) {
			sql += " and " + key + "=" + param.get(key);
		}
		List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(sql);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (null != resultList) {
			for (Map<String, Object> map : resultList) {
				OnePricture onePic = new OnePricture();
				onePic.setId(MapUtils.getLongValue(map, "id"));
				onePic.setLoveId(MapUtils.getLongValue(map, "love_id"));
				onePic.setPicSpotId(MapUtils.getLongValue(map, "pic_spot_id"));
				onePic.setCreateTime(sdf.parse(MapUtils.getString(map, "create_time")));
				onePic.setCreateTime(sdf.parse(MapUtils.getString(map, "update_time")));
				onePic.setYn(MapUtils.getIntValue(map, "yn"));
				onePic.setTitle(MapUtils.getString(map, "title"));
				onePics.add(onePic);
			}
		}
		return onePics;
	}

	public List<Map<String, Object>> getLoverList(Integer picId) {
		String sql = "SELECT op.id, op.pic_spot_id as picSpotId,opd.pic_name AS picName,pic_description picDes FROM one_picture op INNER JOIN one_picture_detail opd on op.id = opd.pic_id WHERE op.pic_spot_id = "
				+ picId + " AND op.state = 2";
		List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(sql);
		return resultList;
	}

	/**
	 * 
	 * 
	 * @Description 保存
	 * @author wangjingzhao
	 * @createDate 2015-6-27 上午9:55:31
	 * @param @param onePic
	 * @param @return
	 * @return int
	 * @exception
	 * @throws
	 * @lastModify
	 */
	public int inserOnePicture(final OnePricture onePic) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				String sql = "insert into one_picture (pic_spot_id,love_id,create_time,update_time,yn,state,title) " + "values(?,?,?,?,?,?,?)";
				PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				ps.setString(1, onePic.getPicSpotId() + "");
				ps.setString(2, onePic.getLoveId() + "");
				ps.setString(3, DateUtils.formatDatetime(onePic.getCreateTime()) + "");
				ps.setString(4, DateUtils.formatDatetime(onePic.getUpdateTime()) + "");
				ps.setString(5, "0");
				ps.setString(6, onePic.getState() + "");
				ps.setString(7, onePic.getTitle());
				return ps;
			}
		}, keyHolder);
		Integer generatedId = keyHolder.getKey().intValue();
		return generatedId;
	}

	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-28 上午1:14:20
	 * @param @param onePic 
	 * @return void 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	public void updateOnePictureTitle(OnePricture onePic){
		String sql = "update one_picture set title = '" + onePic.getTitle()+"' where id = " + onePic.getId();
		this.jdbcTemplate.execute(sql);
	}
	
	
	public List<Map<String, Object>> getOneViewSpot(long picSpotId){
		String sql = "SELECT * from one_view_spot where view_spot_id =  "+ picSpotId + "";
		List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(sql);
		return resultList;
	}

}
