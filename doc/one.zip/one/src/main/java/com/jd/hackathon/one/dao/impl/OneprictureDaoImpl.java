package com.jd.hackathon.one.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jd.hackathon.one.bean.OnePricture;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.dao.impl 
 * @ClassName: OneprictureDaoImpl 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-26 下午9:05:57
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
public class OneprictureDaoImpl extends DaoBaseImpl{
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-26 下午9:17:23
	 * @param @param param
	 * @param @return 
	 * @return List<OnePricture> 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	public List<OnePricture> getOneprictures(OnePricture onePricture){
		List<OnePricture> onePics = new ArrayList<OnePricture>();
		Map<String, Object> param = new HashMap<String, Object>();
		if(null != onePricture){
			if(onePricture.getLoveId() != 0){}
		}
		
		if(null != param){
			onePics = findByParams(param);
		}
		return onePics;
	}

	
}
