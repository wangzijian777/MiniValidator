package com.jd.hackathon.one.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.jd.hackathon.one.bean.UserBean;
import com.jd.hackathon.one.util.DateUtils;
import com.mysql.jdbc.Statement;


@Repository
public class HappynessDaoImpl{
	@Autowired
	protected JdbcTemplate jdbcTemplate;
	
	
	public void inserSignature(final int userId,final int lid){
		

		String sql = "select first_user_id  from  one_signature where id = ?";
        
		
		final int  firstUserId = this.jdbcTemplate.queryForInt(sql,lid);
		
		
		
		KeyHolder keyHolder = new GeneratedKeyHolder();  
		jdbcTemplate.update(new PreparedStatementCreator() {
		@Override
		public PreparedStatement createPreparedStatement(Connection connection)
				throws SQLException {
		     String sql2 = "";
			if(firstUserId == 0){
				sql2 = "update one_signature set first_user_id = ? , first_sign_time = ? , sign_flag = 1 where id = ? ";
			}else{
				sql2 = "update one_signature set second_user_id = ? , second_sign_time = ? , sign_flag = 2 where id = ? ";
			}
	        PreparedStatement ps = connection.prepareStatement(sql2,Statement.RETURN_GENERATED_KEYS);
	        ps.setString(1, userId+"");
	        ps.setString(2,DateUtils.formatDatetime(new Date()));
	        ps.setString(3, lid+"");
	        return ps;
	      }
	    }, keyHolder);

	}
	
	
	public int collect(final int lid,final int areaId){
		
        String sql = "select count(*)  from  one_signature where yn=0 and lover_id = "+lid+" and area_id =  "+areaId;
        
		
		final int sum = this.jdbcTemplate.queryForInt(sql);
		
		
		KeyHolder keyHolder = new GeneratedKeyHolder();  
		jdbcTemplate.update(new PreparedStatementCreator() {
		@Override
		public PreparedStatement createPreparedStatement(Connection connection)
				throws SQLException {
			if(sum == 0){
		     String sql = " insert into one_signature (lover_id,area_id,sign_flag,creat_time,update_time,yn) " +
	        "values(?,?,?,?,?,?)";
			
	        PreparedStatement ps = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
	        ps.setString(1, lid+"");
	        ps.setString(2,areaId+"");
	        ps.setString(3, 0+"");
	        ps.setString(4, DateUtils.formatDatetime(new Date()));
	        ps.setString(5, DateUtils.formatDatetime(new Date()));
	        ps.setString(6, 0+"");
	        return ps;
			}else{
				    String sql = " update one_signature set yn = 1 where lover_id = ? and area_id= ? " ;
					
			        PreparedStatement ps = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			        ps.setString(1, lid+"");
			        ps.setString(2, areaId+"");

			        return ps;
				
			}
	      }
	    }, keyHolder);
		Integer generatedId = keyHolder.getKey().intValue();				
		return generatedId;

	}
	
	
public void deleteList(final int id){
		
	KeyHolder keyHolder = new GeneratedKeyHolder();  
	jdbcTemplate.update(new PreparedStatementCreator() {
	@Override		
	public PreparedStatement createPreparedStatement(Connection connection)
			throws SQLException {
	     String sql = " update one_signature set yn = 1 where id = ?" ;
		
        PreparedStatement ps = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
        ps.setString(1, id+"");

        return ps;
      }
    }, keyHolder);

	
}
}
