package com.jd.hackathon.one.base.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.hackathon.one.service.LoverService;
import com.jd.hackathon.one.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private LoverService loverService;
	
	@RequestMapping(value = "/logout.json")
	public @ResponseBody Object doLogout(HttpServletRequest req){
		HttpSession session = req.getSession();
		session.removeAttribute("userInfo");
		return new HashMap();
	}
	
	@RequestMapping(value = "/regist.json")
	public @ResponseBody Object regist(HttpServletRequest req){
		Map<String, Object> resultInfo = new HashMap<String, Object>();
		String phone1 = (String) req.getParameter("phone1");
		String password = (String) req.getParameter("password");
		boolean isExist = userService.isExist(phone1, password);
		if(isExist){
			resultInfo.put("result", false);
			return  resultInfo;
		}
		
		int sex = Integer.parseInt(req.getParameter("sex"));
		String phone2 = (String) req.getParameter("phone2");
		System.out.println(phone1 + "----" + password + "----" + sex + "----" + phone2);
		boolean result = userService.registUsers(phone1, phone2, sex, password);
		if(result){
			HttpSession session = req.getSession();
			List<Map<String, Object>> resultList = userService.getUserInfosByPhone(phone1);
			String loverPhone = (String) userService.getLoverByPhone(phone1).get(0).get("phone");
			long lid = Integer.parseInt(resultList.get(0).get("l_id").toString());
			List<Map<String, Object>> loverResult =	loverService.getLoverInfosByLid(lid);
			int score = Integer.parseInt(loverResult.get(0).get("total_score").toString());
			Map<String, Object> map = resultList.get(0);
			map.put("l_phone", loverPhone);
			map.put("score", score);
			session.setAttribute("userInfo", map);
			resultInfo.put("result", true);
			return resultInfo;
		}else{
			resultInfo.put("result", false);
			return resultInfo;
		}
	}
	
	@RequestMapping(value = "/setUsername.json")
	public @ResponseBody Object setUsername(HttpServletRequest req){
		Map<String, Object> map = userService.isLogin(req.getSession());
		String uname = (String) req.getParameter("uname");
		long uid = (Long)map.get("u_id");
		int effectedRow = userService.setUname(uid, uname);
		if(effectedRow > 0){
			map.put("u_name", uname);
			return map;
		}
		return null;
		
		
	}
	
	@RequestMapping(value = "/getSessionUser.json", method = RequestMethod.POST)
	public @ResponseBody Object getSessionUser(HttpServletRequest req){
		Map<String, Object> userInfo = userService.isLogin(req.getSession());
		return userInfo;
	}
	
	@RequestMapping(value = "/isLogin.json", method = RequestMethod.POST)
	public @ResponseBody Object isLogin(HttpServletRequest req){
		HttpSession session = req.getSession();
		Map<String, Object>  userInfo = userService.isLogin(session);
		return userInfo;
	}
	
	@RequestMapping(value = "/doLogin.json")
	public @ResponseBody Object doLogin(HttpServletRequest req){
		String phone = (String) req.getParameter("phone");
		String password = (String) req.getParameter("password");
		if(userService.verifyUser(phone, password)){
			HttpSession session = req.getSession();
			List<Map<String, Object>> resultList = userService.getUserInfosByPhone(phone);
			String loverPhone = (String) userService.getLoverByPhone(phone).get(0).get("phone");
			long lid = Integer.parseInt(resultList.get(0).get("l_id").toString());
			List<Map<String, Object>> loverResult =	loverService.getLoverInfosByLid(lid);
			int score = Integer.parseInt(loverResult.get(0).get("total_score").toString());
			Map<String, Object> map = resultList.get(0);
			map.put("l_phone", loverPhone);
			map.put("score", score);
			
//			String json = JsonUtil.map2Json(map);
			session.setAttribute("userInfo", map);
			System.out.println("验证成功!" + map.toString());
			return map;
		}else{
			System.out.println("验证失败....");
		}
		return null;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

}
