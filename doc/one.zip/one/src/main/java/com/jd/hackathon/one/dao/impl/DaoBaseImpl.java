package com.jd.hackathon.one.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jd.hackathon.one.bean.DTOBaseImpl;
import com.jd.hackathon.one.dao.DaoBase;

/**
 * 公共dao实现类
 * @author yhan
 * 2015-6-26
 * @param <T>
 */

public abstract class DaoBaseImpl<T extends DTOBaseImpl> implements DaoBase<T> {

	@Autowired
	protected SqlSession sqlSession;
	
	@Autowired
	protected JdbcTemplate jdbcTemplate;
	
	protected Logger log = null;

	public DaoBaseImpl() {
		log = LoggerFactory.getLogger(this.getClass());
	}

	protected String ns;
	

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.jd.fce.owls.web.base.dao.DaoBase#add(java.lang.Object)
	 * @Author liuweiyf 2014-10-8 下午3:54:59
	 */
	@Override
	public T add(T t) {
		try {
			sqlSession.insert(ns + ".add", t);
			return t;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.jd.fce.owls.web.base.dao.DaoBase#update(java.lang.Object)
	 * @Author liuweiyf 2014-10-8 下午3:54:59
	 */
	@Override
	public Integer update(T t) {
		try {
			return sqlSession.update(ns + ".update", t);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return -1;
		}
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.jd.fce.owls.web.base.dao.DaoBase#delete(java.lang.Integer)
	 * @Author liuweiyf 2014-10-8 下午3:54:59
	 */
	@Override
	public Integer delete(T t) {
		try {
//			String loginUser = LoginContext.getLoginContext().getPin();
//			t.setUpdateTime(new Date());
//			t.setUpdatePin(loginUser);
			return sqlSession.update(ns + ".delete", t);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return -1;
		}
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.jd.fce.owls.web.base.dao.DaoBase#findById(java.lang.Integer)
	 * @Author liuweiyf 2014-10-8 下午3:54:59
	 */
	@Override
	public T findById(Integer id) {
		return (T)sqlSession.selectOne(ns + ".findById", id);
	}

	@Override
	public List<T> findAll(Map<String, Object> map) {
		return sqlSession.selectList(ns + ".findAll", map);
	}

	@Override
	public Integer findAllCount(Map<String, Object> map) {
		return (Integer) sqlSession.selectOne(ns + ".findAllCount", map);
	}

	@Override
	public List<T> findByParams(Map<String, Object> map) {
		return sqlSession.selectList(ns + ".findByParams", map);
	}

	@Override
	public Integer findByParamsCount(Map<String, Object> map) {
		return (Integer) sqlSession.selectOne(ns + ".findByParamsCount", map);
	}

	@Override
	public Integer batchDelete(List<Integer> ids) {
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("ids", ids);
			return sqlSession.update(ns + ".batchDelete", map);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return -1;
		}
	}

}
