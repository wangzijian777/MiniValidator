package com.jd.hackathon.one.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.jd.hackathon.one.util.JsonUtil;

public class UserService {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private String fields = "{'u_id':'long','phone':'String','sex':'int','u_name':'String','password':'String','l_id':'int','pair_regist':'int','yn':'int','create_time':'String','create_pin':'String','update_time':'String','update_pin':'String','last_login':'String','p_id':'String'}";
	
	
	public boolean registUsers(String phone1, String phone2, int sex1, String password){
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String currentTime = df.format(new Date());; 
		int pair_regist = 0;
		if(phone2 != null || StringUtils.isBlank(phone2)){
			Map<String,Object> m1 = new HashMap<String,Object>();
			Map<String,Object> m2 = new HashMap<String,Object>();
			long lid = initNewLover();
			pair_regist = 1;
			m1.put("pair_regist", pair_regist);
			m2.put("pair_regist", pair_regist);
			m1.put("phone", phone1);
			m2.put("phone", phone2);
			m1.put("yn", 0);
			m2.put("yn", 0);
			m1.put("sex", sex1);
			if(sex1 == 1){
				m1.put("u_name", "帅哥"+phone1);
				m2.put("sex", 2);
				m2.put("u_name", "美女"+phone2);
			}else{
				m1.put("u_name", "美女"+phone1);
				m2.put("sex", 1);
				m2.put("u_name", "帅哥"+phone2);
				
			}
			m1.put("password", password);
			m2.put("password", password);
			m1.put("create_time", currentTime);
			m2.put("create_time", currentTime);
			m1.put("update_time", currentTime);
			m2.put("update_time", currentTime);
			m1.put("l_id", lid);
			m2.put("l_id", lid);
			
		

			String addJson1 = JsonUtil.map2Json(m1);
			String addJson2 = JsonUtil.map2Json(m2);
			System.out.println(addJson1);
			System.out.println(addJson2);
			if(!addUser(addJson1)){
				return false;
			}else if(!addUser(addJson2)){
				return false;
			}
			
		}else{
			Map<String,Object> m1 = new HashMap<String,Object>();
			m1.put("phone", phone1);
			m1.put("sex", sex1);
			if(sex1 == 1){
				m1.put("u_name", "帅哥"+phone1);
			}else{
				m1.put("u_name", "美女"+phone1);
			}
			m1.put("password", password);
			m1.put("l_id", 0);
			m1.put("yn", 0);
			m1.put("create_time", currentTime);
			m1.put("update_time", currentTime);
			m1.put("pair_regist", pair_regist);
			
			String addJson1 = JsonUtil.map2Json(m1);
			if(!addUser(addJson1)){
				return false;
			}
		}
		return true;
	}
	
	public Map<String, Object> isLogin(HttpSession session){
		Map<String, Object> userInfo = (Map<String, Object>) session.getAttribute("userInfo");
		if(userInfo == null || userInfo.isEmpty()){
			return null;
		}else
			return userInfo;
	}
	
	public boolean addUser(String json4User){
		boolean flag = false;
		String insertSql = JsonUtil.convert2InsertSql4User("one_user", json4User, fields);
		int effectedRow = jdbcTemplate.update(insertSql);
		if(effectedRow < 1){
			flag = false;
		}else{
			flag = true;
		}
		return flag;
	}
	
	public long initNewLover(){
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String nowData = df.format(new Date());
		String sql = "insert into one_lover (yn, create_time, update_time ) values (0, '" + nowData + "' , '" + nowData + "')";
		System.out.println(sql);
		int effectRow = jdbcTemplate.update(sql);
		if(effectRow > 0){
			String getLidSql = "select * from one_lover order by l_id desc";
			List<Map<String, Object>> resultList = jdbcTemplate.queryForList(getLidSql);
			Map<String, Object> m = resultList.get(0);
			long lid = Long.parseLong(m.get("l_id").toString());
			return lid;
		}
		return -1;
	}
	
	/**
	 * 通过手机号和密码判断用户是否为注册用户
	 * @param phoneNo 用户手机号码
	 * @param password 用户密码
	 * @return 
	 */
	public boolean verifyUser(String phoneNo, String password){
		String sql = "select * from one_user where phone = '" + phoneNo + "' and password = '" + password + "';";
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		if(resultList.size() != 0){
			return true;
		}
		return false;
	}
	
	public boolean isExist(String phoneNo, String password){
		String sql = "select * from one_user where phone = '" + phoneNo + "';";
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		if(resultList.size() != 0){
			return true;
		}
		return false;
	}
	
	/**
	 * 通过用户uid获取用户所有信息
	 * @param userId
	 * @return 对应用户所有信息
	 */
	public List<Map<String, Object>> getUserInfosByUid(long userId){
		String sql = "select * from one_user where u_id = " + userId;
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		return resultList;
	}
	
	
	/**
	 * 通过用户手机号来获取用户所有信息
	 * @param phoneNo
	 * @return 对应用户所有信息
	 */
	public List<Map<String, Object>> getUserInfosByPhone(String phoneNo){
		String sql = "select * from one_user where phone = '" + phoneNo + "';";
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		return resultList;
	}
	
	/**
	 * 通过用户的手机号获得对应情侣（另一半）的相关信息
	 * @param phone
	 * @return
	 */
	public List<Map<String, Object>> getLoverByPhone(String phone){
		String sql = "select * from one_user where phone = '" + phone + "';";
		List<Map<String, Object>> resultList1 = jdbcTemplate.queryForList(sql);
		Map<String, Object> row =resultList1.get(0);
		long uid = (Long)row.get("u_id");
		long lid = (Integer)row.get("l_id");
		String sqlOnUsers = "select * from one_user where l_id = " + lid + " and u_id != " + uid + ";";
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sqlOnUsers);
		return resultList;
	}
	
	public int getLatestLid(){
		String sql = "select * from one_lover order by l_id desc";
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		int lid = Integer.parseInt((String) resultList.get(0).get("l_id"));
		return lid;
	}
	
	public int setUname(long uid, String uname) {
		String sql = "update  one_user set u_name = '" + uname + "' where u_id = " + uid;
		int effctedRows = jdbcTemplate.update(sql);
		return effctedRows;
	}
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

}
