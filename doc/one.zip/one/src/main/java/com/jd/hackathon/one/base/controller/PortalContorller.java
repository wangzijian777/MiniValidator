/**
 * Copyright(C) 2015 zdd9999@gmail.com All Right Reserved
 */
package com.jd.hackathon.one.base.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *<p></p>
 *@author 周德东<zdd9999@gmail.com>
 *@version 1.0
 *@date 2015-5-21 下午11:20:38
 */
@Controller
public class PortalContorller {
    private static final Logger LOGGER = LoggerFactory.getLogger(PortalContorller.class);
    
    
    /**
     * 应用主入口
     */
    @RequestMapping("/index.do")
    public ModelAndView index(HttpServletRequest req){
        ModelAndView view = new ModelAndView("index");
        return view;
    }
    @RequestMapping("/{moduls}/{view}.do")
    public ModelAndView jump(@PathVariable String moduls,@PathVariable String view){
        LOGGER.info("jump moduls="+moduls+" ,view="+view);
        return new ModelAndView(moduls+"/"+view);
    }
}
