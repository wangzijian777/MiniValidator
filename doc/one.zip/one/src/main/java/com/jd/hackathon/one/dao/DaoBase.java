package com.jd.hackathon.one.dao;

import java.util.List;
import java.util.Map;

import com.jd.hackathon.one.bean.DTOBaseImpl;

/**
 * DAO通用接口
 * @author yhan
 * 2015-6-26
 * @param <T>
 */
public interface DaoBase<T extends DTOBaseImpl> {
	T add(T t);
	Integer update(T t);
	Integer delete(T t);
	T findById(Integer id);
	/*
	List<T> findByCode(String code);
	*/
	List<T> findByParams(Map<String,Object> map);
	Integer findByParamsCount(Map<String,Object> map);
	List<T> findAll(Map<String,Object> map);
	Integer findAllCount(Map<String,Object> map);
	Integer batchDelete(List<Integer> ids) ;
}
