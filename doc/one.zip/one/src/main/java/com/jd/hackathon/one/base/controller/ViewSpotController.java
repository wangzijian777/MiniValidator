/**
 * Copyright(C) 2015 zdd9999@gmail.com All Right Reserved
 */
package com.jd.hackathon.one.base.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.hackathon.one.base.web.servlet.handler.JsonpHandler;
import com.jd.hackathon.one.bean.viewspot.ViewSpot;
import com.jd.hackathon.one.service.ViewSpotService;

/**
 *<p></p>
 *@author 周德东<zdd9999@gmail.com>
 *@version 1.0
 *@date 2015-5-21 下午11:21:44
 */
@Controller
@RequestMapping("/viewspot")
public class ViewSpotController {
    @Autowired
    private JsonpHandler jh;
    @Autowired
    ViewSpotService viewSpotService;
    
    @RequestMapping("/list.jsonp")
    public void list(HttpServletRequest request,
            HttpServletResponse response) {
    	Integer province = NumberUtils.toInt(request.getParameter("province"));
    	Integer city = NumberUtils.toInt(request.getParameter("city"));
    	if(province == null){
    		province = 2;
    	}
    	if(city == null){
    		city = 3;
    	}
    	List<ViewSpot> list = viewSpotService.getViewSpotByArea(province, city, null, null);
    	Map<String, Object> map = new HashMap<String, Object>();
    	map.put("title", list.get(0).getViewSpotName());
    	map.put("preceptList", list);
    	jh.jsonp(request, response, map);
    }
    
    /**
     * @param request
     * @return
     */
    @RequestMapping("signView.do")
    @ResponseBody
    public Map<String, Object> getSignViewSpot(HttpServletRequest request){
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("data",viewSpotService.getSignViewSpot(request));
        return result;
    }
    
}
