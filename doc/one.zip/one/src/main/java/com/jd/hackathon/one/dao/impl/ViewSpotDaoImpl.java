package com.jd.hackathon.one.dao.impl;

import org.springframework.stereotype.Repository;

import com.jd.hackathon.one.bean.viewspot.ViewSpot;

@Repository("viewSpotDaoImpl")
public class ViewSpotDaoImpl extends DaoBaseImpl<ViewSpot>{

	public ViewSpotDaoImpl(){
		ns = "com.jd.hackathon.one.dao.impl.ViewSpotDao";
	}
}
