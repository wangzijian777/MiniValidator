package com.jd.hackathon.one.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.jd.hackathon.one.bean.LoverBean;
import com.jd.hackathon.one.util.JsonUtil;

@Service
public class LoverService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private String fields = "{'l_id':'long','total_score':'int','yn':'int','create_time':'String','create_pin':'String','update_time':'String','update_pin':'String'}";
	
	
	public int addScore(int addScore, int lid){
		String sql = "select * from one_lover where l_id = " + lid;
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		int totalScore = Integer.parseInt(resultList.get(0).get("total_score").toString());
		totalScore += addScore;
		String aupdateSql = "update one_lover set total_score = " + totalScore + " where l_id = "+lid;
		int effctedRows = jdbcTemplate.update(aupdateSql);
		if(effctedRows > 0){
			return totalScore;
		}
		return -1;
	}
	
	public boolean addLover(String json4User){
		boolean flag = false;
		String insertSql = JsonUtil.convert2InsertSql4User("one_lover", json4User, fields);
		int effectedRow = jdbcTemplate.update(insertSql);
		if(effectedRow < 1){
			flag = false;
		}else{
			flag = true;
		}
		return flag;
	}

	/**
	 * 通过情侣关系id来获取关联情侣关系
	 * @param lid
	 * @return
	 */
	public LoverBean getLoverInfoByLid(long lid){
		LoverBean lBean = new LoverBean();
		String sql = "select * from one_lover where l_id = " + lid;
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		try {
			lBean = this.trans2LoverBean(resultList.get(0));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return lBean;
	}

	/**
	 * 通过情侣关系id来获取关联情侣关系
	 * @param lid
	 * @return
	 */
	public List<Map<String, Object>> getLoverInfosByLid(long lid){
		String sql = "select * from one_lover where l_id = " + lid;
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		return resultList;
	}

	/**
	 * 通过用户手机号来获取关联情侣关系
	 * @param phone
	 * @return 如果是单身狗就返回null
	 */
	public LoverBean getLoverInfoByPhone(String phone){
		LoverBean lBean = new LoverBean();
		String sqlOnUser ="select * from one_user where phone = '" + phone + "';";
		List<Map<String, Object>> userList = jdbcTemplate.queryForList(sqlOnUser);
		Map<String, Object> userInfo = userList.get(0);
		String lid = (String) userInfo.get("l_id");
		String sqlOnLover = "select * from one_lover where l_id = " + lid;
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sqlOnLover);
		try {
			lBean = this.trans2LoverBean(resultList.get(1));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return lBean;
	}

	/**
	 * 通过用户手机号来获取关联情侣关系
	 * @param phone
	 * @return 如果是单身狗就返回null
	 */
	public List<Map<String, Object>> getLoverInfosByPhone(String phone){
		String sqlOnUser ="select * from one_user where phone = '" + phone + "';";
		List<Map<String, Object>> userList = jdbcTemplate.queryForList(sqlOnUser);
		Map<String, Object> userInfo = userList.get(0);
		int lid = (Integer) userInfo.get("l_id");
		String sqlOnLover = "select * from one_lover where l_id = " + lid;
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sqlOnLover);
		return resultList;
	}

	/**
	 * 按照积分多少顺序返回情侣信息
	 * @param dataNum
	 * @return
	 */
	public List<Map<String, Object>> getLoverInfoTotalScore(int maxRow){
		String sql = "select * from one_lover order by total_score limit 0," + maxRow;
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		return resultList;
	}
	
	/**
	 * 获取最新的id
	 * @return
	 */
	public int getLatestLid(){
		String sql = "select * from one_lover order by l_id desc";
		List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
		int lid = Integer.parseInt((String) resultList.get(0).get("l_id"));
		return lid;
	}

	/**
	 * 通过查询返回的数据，组装成LoverBean
	 * @param row
	 * @return
	 * @throws ParseException 
	 */
	private LoverBean trans2LoverBean(Map<String, Object> row) throws ParseException{
		LoverBean lBean = new LoverBean();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		lBean.setLid((Long)row.get("l_id"));
		lBean.setTotalScore((Integer)row.get("total_score"));
		lBean.setCreateTime((Date)row.get("create_time"));
		lBean.setUpdateTime((Date)row.get("update_time"));
		lBean.setYn((Integer)row.get("yn"));
		return lBean;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

}
