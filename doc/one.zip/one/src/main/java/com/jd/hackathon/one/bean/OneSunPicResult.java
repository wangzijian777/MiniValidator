package com.jd.hackathon.one.bean;

import java.util.List;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.bean 
 * @ClassName: OneSunPicResult 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-27 下午9:31:00
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
public class OneSunPicResult {

	private OnePricture onePic;
	
	private List<OnePrictureDetail> list;

	private String onePicSpotName ;


	public OnePricture getOnePic() {
		return onePic;
	}

	public void setOnePic(OnePricture onePic) {
		this.onePic = onePic;
	}

	public List<OnePrictureDetail> getList() {
		return list;
	}

	public void setList(List<OnePrictureDetail> list) {
		this.list = list;
	}

	public String getOnePicSpotName() {
		return onePicSpotName;
	}

	public void setOnePicSpotName(String onePicSpotName) {
		this.onePicSpotName = onePicSpotName;
	}
	
	
}
