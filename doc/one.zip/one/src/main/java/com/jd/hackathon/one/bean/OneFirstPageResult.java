package com.jd.hackathon.one.bean;

import java.util.List;
import java.util.Map;

/**
 * 
 * @Project：one
 * @Package：com.jd.hackathon.one.bean
 * @ClassName: OneFirstPageResult
 * @Description: TODO(用一句话描述该文件做什么)
 * @author：wangjingzhao
 * @date 2015-6-27 下午5:25:11
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since: JDK 1.6
 * @Version： V1.0
 * 
 */
public class OneFirstPageResult {

	private int code;

	private String title;

	private List<OneFirstPageDetailResult> preceptList;
	private List<Map<String, Object>> loveList;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<OneFirstPageDetailResult> getPreceptList() {
		return preceptList;
	}

	public void setPreceptList(List<OneFirstPageDetailResult> preceptList) {
		this.preceptList = preceptList;
	}

	public List<Map<String, Object>> getLoveList() {
		return loveList;
	}

	public void setLoveList(List<Map<String, Object>> loveList) {
		this.loveList = loveList;
	}

}
