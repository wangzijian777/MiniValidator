package com.jd.hackathon.one.util;

import java.util.Date;

public class ConstantPool {
	public static Date inDate;
}
