/**
 * Copyright(C) 2004-2015 JD.COM All Right Reserved
 */
package com.jd.hackathon.one.base.web.servlet.handler;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 *<p></p>
 *@author zhoudedong 运营研发部
 *@version 1.0
 *@date 2015-6-26 下午5:57:20
 */
@Component
public class JsonpHandler {
    @Autowired
    private ObjectMapper objectMapper;
    
    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public void jsonp(HttpServletRequest request,
            HttpServletResponse response,Object data) {
        try {
            response.setContentType("text/plain");
            response.setHeader("Pragma", "No-cache");
            response.setHeader("Cache-Control", "no-cache");
            response.setDateHeader("Expires", 0);
            PrintWriter out = response.getWriter();
            String callback = request.getParameter("callback");// 客户端请求参数
            if(StringUtils.isEmpty(callback)){
                callback = "callback";
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("code", 0);
            map.put("data", data);
            out.println(callback + "(" + objectMapper.writeValueAsString(map) + ")");// 返回jsonp格式数据
            out.flush();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
