package com.jd.hackathon.one.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.jd.hackathon.one.dao.impl.LoverShowDao;
@Component
public class WorkCalcService {

	@Autowired
	private LoverShowDao loverShowDao;
	
	
	// @Async(cron = "0/30 * * * * ?")
	//@Scheduled(cron = "0/2 * * * * ?")
	public void service() throws Exception {
		 System.out.println("task loop start");
		 List<Map<String, Object>> list = loverShowDao.getToDo();
		 System.out.println("插入ES...");
	}
}
