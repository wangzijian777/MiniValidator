package com.jd.hackathon.one.bean;

import java.util.Date;

/**
 * 情侣表对应bean
 * @author liuxiangyu
 * @date 2015-6-26 下午4:08:00
 */

public class LoverBean {
	private long lid	;
	private long totalScore	;
	private Date createTime;
	private Date updateTime;
	private int yn;
	public long getLid() {
		return lid;
	}
	public void setLid(long lid) {
		this.lid = lid;
	}
	public long getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(long totalScore) {
		this.totalScore = totalScore;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	@Override
	public String toString() {
		return "LoverBean [lid=" + lid + ", totalScore=" + totalScore
				+ ", createTime=" + createTime + ", updateTime=" + updateTime
				+ ", yn=" + yn + "]";
	}
}
