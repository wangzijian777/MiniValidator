package com.jd.hackathon.one.bean;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.bean 
 * @ClassName: OneFirstPageDetailResult 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-27 下午5:25:51
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
public class OneFirstPageDetailResult {

	private int imgId;
	
	private String imgUrl;
	
	private String subMsg;
	
	private boolean isLove;

	public int getImgId() {
		return imgId;
	}

	public void setImgId(int imgId) {
		this.imgId = imgId;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getSubMsg() {
		return subMsg;
	}

	public void setSubMsg(String subMsg) {
		this.subMsg = subMsg;
	}

	public boolean isLove() {
		return isLove;
	}

	public void setLove(boolean isLove) {
		this.isLove = isLove;
	}
	
	
	
}
