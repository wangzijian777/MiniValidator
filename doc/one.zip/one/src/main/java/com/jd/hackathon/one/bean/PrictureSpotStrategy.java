package com.jd.hackathon.one.bean;

/**
 * 
 * @author wangchongyang
 *
 */
public class PrictureSpotStrategy extends DTOBaseImpl{

	
}
