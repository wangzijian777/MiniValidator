package com.jd.hackathon.one.bean;

import java.util.Date;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.bean 
 * @ClassName: OnePrictureDetail 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-26 下午8:23:38
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
public class OnePrictureDetail {

	
	private long id;
	
	private long onePicId;
	
	private int picSeq;
	
	private String picName;
	
	private String picDescription;
	
	private Date createTime;
	
	private Date updateTime;
	
	private String url;
	
	private int yn;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getOnePicId() {
		return onePicId;
	}

	public void setOnePicId(long onePicId) {
		this.onePicId = onePicId;
	}

	public int getPicSeq() {
		return picSeq;
	}

	public void setPicSeq(int picSeq) {
		this.picSeq = picSeq;
	}

	public String getPicName() {
		return picName;
	}

	public void setPicName(String picName) {
		this.picName = picName;
	}

	public String getPicDescription() {
		return picDescription;
	}

	public void setPicDescription(String picDescription) {
		this.picDescription = picDescription;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public int getYn() {
		return yn;
	}

	public void setYn(int yn) {
		this.yn = yn;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
}
