package com.jd.hackathon.one.base.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jd.hackathon.one.bean.HappyListBean;
import com.jd.hackathon.one.bean.UserBean;
import com.jd.hackathon.one.dao.impl.HappynessDaoImpl;
import com.jd.hackathon.one.service.UserService;

@Controller
@RequestMapping("/detail")
public class DetailController {
	 private static final Logger LOGGER = LoggerFactory.getLogger(DetailController.class);
	  
    @Autowired
    private SqlSession sqlSession;
    @Autowired
    private  HappynessDaoImpl happynessDaoImpl;
    @Autowired
    private UserService userService;
    
    
    private static final String NS = "com.jd.hackathon.one.base.dao.BaseDao";
	
	  @RequestMapping("/loved.do")
	    public @ResponseBody String collect(HttpServletRequest req,String areaId) throws Exception{
		  
		  Map<String, Object> userInfo = userService.isLogin(req.getSession());
		    if(userInfo == null){
		    	return null;
		    }else{
		        
		    	happynessDaoImpl.collect(Integer.valueOf(userInfo.get("l_id").toString()), Integer.valueOf(areaId));
		        return "success";
		    }


	    }
	    
	  
	  @RequestMapping("/showDetail.do")
	    public ModelAndView showDetail(HttpServletRequest req,String id) throws Exception{
	        ModelAndView view = new ModelAndView("layout/empty");
	        //调用查询接口
	        //List<Map<String,Object>> list = sqlSession.selectList(NS+".query");
	        
	        return  view;
	    }
	  
	  @RequestMapping("/happyList.do")
	    public @ResponseBody List<HappyListBean> happyList(HttpServletRequest req) throws Exception{
		  
		  Map<String, Object> userInfo = userService.isLogin(req.getSession());
		    if(userInfo == null){
		    	return null;
		    }else{
		        
		        List<HappyListBean> list = sqlSession.selectList(NS+".getHappyList",userInfo.get("l_id"));
		        return list;
		    }

	    }
	  
	  @RequestMapping("/areaSign.do")
	    public @ResponseBody String areaSign(HttpServletRequest req,String areaId) throws Exception{
		  Map<String, Object> userInfo = userService.isLogin(req.getSession());
		  if(userInfo == null){
			  
			  return null;
		  }else{
			  
			  int uId = Integer.parseInt(String.valueOf(userInfo.get("u_id"))); 

	        happynessDaoImpl.inserSignature(uId, Integer.valueOf(areaId));
	        
	       
	        return "success";
		  }
	    
	    }
	  
	  @RequestMapping("/deleteList.do")
	    public @ResponseBody String deleteList(HttpServletRequest req,String signId) throws Exception{
          
		    if(signId!=null){
	        happynessDaoImpl.deleteList( Integer.valueOf(signId));
		    }
	      
		    return null;
	    }
	  
}
