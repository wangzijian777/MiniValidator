package com.jd.hackathon.one.bean;

import java.util.Date;

/**
 * 公共字段
 * @author yhan
 * 2015-6-26
 */
public abstract class DTOBaseImpl {
	
	/*
	 * ID
	 */
	protected Integer id;
	
	/*
	 * 创建日期
	 */
	protected Date createTime;
	/*
	 * 创建人
	 */
	protected String createPin;
	/*
	 * 修改日期
	 */
	protected Date updateTime;
	/*
	 * 修改人
	 */
	protected String updatePin;
	/*
	 * 删除
	 */
	protected Integer yn;
	/*
	 * 时间戳
	 */
	protected Date ts;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreatePin() {
		return createPin;
	}

	public void setCreatePin(String createPin) {
		this.createPin = createPin;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getUpdatePin() {
		return updatePin;
	}

	public void setUpdatePin(String updatePin) {
		this.updatePin = updatePin;
	}

	public Integer getYn() {
		return yn;
	}

	public void setYn(Integer yn) {
		this.yn = yn;
	}

	public Date getTs() {
		return ts;
	}

	public void setTs(Date ts) {
		this.ts = ts;
	}
}
