package com.jd.hackathon.one.util;

public class JdbcUtil {

}
