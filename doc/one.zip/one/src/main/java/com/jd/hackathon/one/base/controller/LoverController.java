package com.jd.hackathon.one.base.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.hackathon.one.service.LoverService;
import com.jd.hackathon.one.service.UserService;

@Controller
@RequestMapping("/lover")
public class LoverController {
	@Autowired
	private LoverService loverService;
	@Autowired
	private UserService userService;

	@RequestMapping(value = "/getLoverInfo.json", method = RequestMethod.POST)
	public @ResponseBody Object regist(HttpServletRequest req){
		Long lid = Long.parseLong((String)req.getParameter("l_id"));
		List<Map<String, Object>> result = loverService.getLoverInfosByLid(lid);
		Map<String, Object> m = result.get(0);
		
		return m;
	}

}
