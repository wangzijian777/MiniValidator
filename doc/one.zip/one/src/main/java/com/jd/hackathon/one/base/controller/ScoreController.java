/**
 * Copyright(C) 2004-2015 JD.COM All Right Reserved
 */
package com.jd.hackathon.one.base.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.hackathon.one.service.ScoreService;

/**
 *<p></p>
 *@author zhoudedong 运营研发部
 *@version 1.0
 *@date 2015-6-28 上午12:58:58
 */
@Controller
@RequestMapping("/score")
public class ScoreController {
    @Autowired
    private ScoreService scoreService;
    
    @RequestMapping("/topLoverScore.json")
    public @ResponseBody Map<String,Object> topLoverScore(HttpServletRequest request){
        Map<String,Object> result = new HashMap<String,Object>();
        List<Map<String,Object>> list = scoreService.topLoverScore();
        result.put("data", list);
        return result;
    }
}
