/**
 * Copyright(C) 2015 zdd9999@gmail.com All Right Reserved
 */
package com.jd.hackathon.one.base.web.servlet.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

/**
 *<p></p>
 *@author 周德东<zdd9999@gmail.com>
 *@version 1.0
 *@date 2015-1-28 下午1:35:03
 */
public class CustomSimpleMappingExceptionResolver extends SimpleMappingExceptionResolver {
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomSimpleMappingExceptionResolver.class);
    @Override  
    protected ModelAndView doResolveException(HttpServletRequest request,  
            HttpServletResponse response, Object handler, Exception ex) {  
        LOGGER.error(ex.getMessage(),ex);
        if (!(request.getHeader("accept").indexOf("application/json") > -1 )) {  
            return super.doResolveException(request, response, handler, ex);
        } else {// JSON格式返回  
            return getModelAndView("redirect:/static/error/error.js", ex, request);   
        }
    }  
}
