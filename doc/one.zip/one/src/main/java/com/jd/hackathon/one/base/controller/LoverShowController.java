package com.jd.hackathon.one.base.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.hackathon.one.dao.impl.LoverShowDao;

@Controller
@RequestMapping("/loverShow")
public class LoverShowController {

	@Autowired
	private LoverShowDao loverShowDao;

	/**
	 * wanghao
	 * 显示标题
	 * @param file
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/loverShowTitle.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public Map<String,String> loverShowList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return loverShowDao.getLoverShowTile((Integer.parseInt(request.getParameter("id"))));
	}

	/**
	 * wanghao
	 * 显示标题
	 * @param file
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getLoverShowDetail.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public List<Map<String, Object>> getLoverShowDetail(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<Map<String, Object>> list = loverShowDao.getToDo();
		
		return null;
	}

	
}
