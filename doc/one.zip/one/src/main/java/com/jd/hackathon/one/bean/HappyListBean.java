package com.jd.hackathon.one.bean;



/**
 * 用户表对应bean
 * @author liuyang
 * @date 2015-6-26 下午4:08:25
 */


public class HappyListBean {
	
	private long id;
	private long  spotId ;
	private long  loverId;//
	private String name ;
	private String areaName;
	private String title;
	private String picId;
	private String picUrl;
	private int days;
	private int isSigned;
	private boolean isShowed;
	private boolean signed;
	private String picName;
	private int firstUserId;
	private int SecondUserId;
	
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public String getPicName() {
		return picName;
	}
	public void setPicName(String picName) {
		this.picName = picName;
	}
	public int getFirstUserId() {
		return firstUserId;
	}
	public void setFirstUserId(int firstUserId) {
		this.firstUserId = firstUserId;
	}
	public int getSecondUserId() {
		return SecondUserId;
	}
	public void setSecondUserId(int secondUserId) {
		SecondUserId = secondUserId;
	}
	
	

	public boolean isSigned() {
		return signed;
	}
	public void setSigned(boolean signed) {
		this.signed = signed;
	}
	public String getPicId() {
		return picId;
	}
	public void setPicId(String picId) {
		this.picId = picId;
	}
	public long getSpotId() {
		return spotId;
	}
	public void setSpotId(long spotId) {
		this.spotId = spotId;
	}
	public long getLoverId() {
		return loverId;
	}
	public void setLoverId(long loverId) {
		this.loverId = loverId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPicUrl() {
		return picUrl;
	}
	public void setPicUrl(String picUrl) {
		this.picUrl = picUrl;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}

	public int getIsSigned() {
		return isSigned;
	}
	public void setIsSigned(int isSigned) {
		this.isSigned = isSigned;
		if(isSigned == 1){
			this.setSigned(false);
		}else{
			this.setSigned(true);
		}
	}
	public boolean isShowed() {
		return isShowed;
	}
	public void setShowed(boolean isShowed) {
		this.isShowed = isShowed;
	}
	
	
	

	
	
}
