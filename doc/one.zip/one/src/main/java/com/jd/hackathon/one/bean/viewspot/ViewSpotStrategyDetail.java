package com.jd.hackathon.one.bean.viewspot;

import com.jd.hackathon.one.bean.DTOBaseImpl;

/**
 * 景点对应策略详情表
 * @author yhan
 * 2015-6-26
 */
public class ViewSpotStrategyDetail extends DTOBaseImpl{

	private Integer strategyId;
	private String picId;
	private String strategyInfo;
	private Integer level;
	
	public Integer getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}
	
	public String getPicId() {
        return picId;
    }
    public void setPicId(String picId) {
        this.picId = picId;
    }
    public String getStrategyInfo() {
		return strategyInfo;
	}
	public void setStrategyInfo(String strategyInfo) {
		this.strategyInfo = strategyInfo;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
}
