package com.jd.hackathon.one.dao.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.jd.hackathon.one.util.ConstantPool;

@Repository
public class LoverShowDao {
	@Autowired
	protected JdbcTemplate jdbcTemplate;

	/**
	 * wanghao
	 * @param onePricture
	 * @return
	 * @throws ParseException
	 */
	public Map<String,String> getLoverShowTile(int id) throws ParseException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String sql = "select p.title,u.u_name userName,p.update_time ttime, v.area_name areaname from one_picture p left join one_user u on p.love_id=u.l_id left join one_view_spot v on p.pic_spot_id=v.view_spot_id where id=" + id;
		List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(sql);
		
		Map<String,String> map = new HashMap<String,String>();
		map.put("title", (String)resultList.get(0).get("title"));
		map.put("userName", (String)resultList.get(0).get("userName")+"&"+(String)resultList.get(1).get("userName"));
		map.put("_time", df.format(resultList.get(0).get("ttime")));
		map.put("areaname", (String)resultList.get(0).get("areaname"));
		return map;
	}

	/**
	 * wanghao
	 * @param onePricture
	 * @return
	 * @throws ParseException
	 */
	public List<Map<String, Object>> getLoverShowDetail(int id) throws ParseException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String sql = "select p.title,d.pic_name,d.pic_description from one_picture p left join one_picture_detail d on p.id=d.pic_id where p.id=" + id + "  order by pic_seq";
		
		List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(sql);
		
		for(Map<String, Object> _map : resultList){
			for(String key: _map.keySet()){
				if(((String)(_map.get(key))).indexOf("敏感字")>0){
					_map.put(key, "输入信息不符合规则，请联系管理员！");
				}
			}
		}
//		Map<String,String> map = new HashMap<>();
//		map.put("title", (String)resultList.get(0).get("title"));
//		map.put("pic_name", (String)resultList.get(0).get("pic_name"));
//		map.put("pic_description", (String)resultList.get(0).get("pic_description"));
		return resultList;
	}
	

	public List<Map<String, Object>> getToDo() throws ParseException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		
		String sql = "select id,pic_description from one_picture_detail ";
		if(ConstantPool.inDate != null){
			sql += "where create_time >='" + df.format(ConstantPool.inDate)+"'";
		}
		System.out.println(sql);
		List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(sql);
		ConstantPool.inDate = new Date();
		return resultList;
	}
	



}

