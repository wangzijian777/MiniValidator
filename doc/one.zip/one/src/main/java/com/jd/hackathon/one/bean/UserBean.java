package com.jd.hackathon.one.bean;

import java.util.Date;


/**
 * 用户表对应bean
 * @author liuxiangyu
 * @date 2015-6-26 下午4:08:25
 */


public class UserBean {
	private long uid ; //
	private String uname ;
	private String password ;
	private String phone;
	private long lid	;
	private int yn	;
	private Date updateTime	;
	private Date createTime	;
	private int sex	;
	private int pairRegist	;
	private Date lastLogin	;
	private long pid	;
	public long getUid() {
		return uid;
	}
	public void setUid(long uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public long getLid() {
		return lid;
	}
	public void setLid(long lid) {
		this.lid = lid;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public int getPairRegist() {
		return pairRegist;
	}
	public void setPairRegist(int pairRegist) {
		this.pairRegist = pairRegist;
	}
	public Date getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public long getPid() {
		return pid;
	}
	public void setPid(long pid) {
		this.pid = pid;
	}
	@Override
	public String toString() {
		return "UserBean [uid=" + uid + ", uname=" + uname + ", password="
				+ password + ", phone=" + phone + ", lid=" + lid + ", yn=" + yn
				+ ", updateTime=" + updateTime + ", createTime=" + createTime
				+ ", sex=" + sex + ", pairRegist=" + pairRegist
				+ ", lastLogin=" + lastLogin + ", pid=" + pid + "]";
	}
	
}
