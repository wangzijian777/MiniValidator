package com.jd.hackathon.one.bean.viewspot;

import com.jd.hackathon.one.bean.DTOBaseImpl;

/**
 * 景点对应策略
 * @author yhan
 * 2015-6-26
 */
public class ViewSpotStrategy extends DTOBaseImpl{

	private Integer strategyId;
	private Integer viewSpotId;
	private String title;
	private Integer level;
	
	public Integer getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}
	public Integer getViewSpotId() {
		return viewSpotId;
	}
	public void setViewSpotId(Integer viewSpotId) {
		this.viewSpotId = viewSpotId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
}
