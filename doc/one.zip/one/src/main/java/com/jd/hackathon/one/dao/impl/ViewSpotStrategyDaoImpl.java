package com.jd.hackathon.one.dao.impl;

import org.springframework.stereotype.Repository;

import com.jd.hackathon.one.bean.viewspot.ViewSpotStrategy;

@Repository("viewSpotStrategyDaoImpl")
public class ViewSpotStrategyDaoImpl extends DaoBaseImpl<ViewSpotStrategy>{

	public ViewSpotStrategyDaoImpl(){
		ns = "com.jd.hackathon.one.dao.impl.ViewSpotStrategyDao";
	}
	
}
