package com.jd.hackathon.one.base.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.jd.hackathon.one.bean.OneFirstPageDetailResult;
import com.jd.hackathon.one.bean.OneFirstPageResult;
import com.jd.hackathon.one.bean.OnePricture;
import com.jd.hackathon.one.bean.OnePrictureDetail;
import com.jd.hackathon.one.bean.OneSunPicResult;
import com.jd.hackathon.one.bean.UserBean;
import com.jd.hackathon.one.dao.impl.OnePictureDetailDao;
import com.jd.hackathon.one.dao.impl.OneprictureDao;
import com.jd.hackathon.one.service.UserService;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.base.controller 
 * @ClassName: OnePictureController 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-26 下午7:56:58
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
@Controller
@RequestMapping("/onepic")
public class OnePictureController {
	
	@Autowired
	private OneprictureDao oneprictureDao;
	@Autowired
	private OnePictureDetailDao  onePictureDetailDao;
	@Autowired
	private UserService userService;
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-26 下午7:58:01
	 * @param @param request
	 * @param @param response
	 * @param @param model
	 * @param @return
	 * @param @throws Exception 
	 * @return ModelAndView 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	@RequestMapping(value = "/uploadLoveOnePicture.do", method = RequestMethod.POST)
	public String uploadLoveOnePicture(@RequestParam("file") MultipartFile[] file,
			HttpServletRequest request)throws Exception {
		Map<String, Object> userInfo = userService.isLogin(request.getSession());
		Date date = new Date();
		OnePricture onePic = new OnePricture();
		if(StringUtils.isNotEmpty(request.getParameter("loveId"))){
			onePic.setLoveId(Long.parseLong(request.getParameter("loveId")));
		}else{
			Map<String, Object> userMap = userService.isLogin(request.getSession());;
			onePic.setLoveId(Long.parseLong(userMap.get("l_id").toString()));
		}		
		onePic.setPicSpotId(Long.parseLong(request.getParameter("picSpotId")));
		onePic.setYn(0);
		if(userInfo == null){
			onePic.setState(1);
		}else{
			onePic.setState(2);//情侣
		}
		onePic.setCreateTime(date);
		onePic.setUpdateTime(date);
		onePic.setTitle("无");
		int onePicId = oneprictureDao.inserOnePicture(onePic);
		int index = 0 ;
		for(MultipartFile f:file){
			OnePrictureDetail detail = new OnePrictureDetail();
			detail.setOnePicId(onePicId);
			detail.setCreateTime(date);
			detail.setUpdateTime(date);
			detail.setYn(0);
			detail.setPicName("img"+File.separator+f.getOriginalFilename());
			detail.setPicSeq(index);
			detail.setPicDescription(request.getParameter("onePicDetailDesc"));
			onePictureDetailDao.insertOnePrictureDetail(detail);
			String realPath=request.getSession().getServletContext().getRealPath("/img");
			File pathFile=new File(realPath);
			if(!pathFile.exists()){
				pathFile.mkdirs();
			}
			try {
				f.transferTo(new File(realPath+"/"+f.getOriginalFilename()));
			} catch (IllegalStateException e) {
				e.printStackTrace();
			}
			index++;
		}		
		System.out.println("redirect:/sun.html?picSpotId="+onePic.getPicSpotId());
		return "redirect:/sun.html?picSpotId="+onePic.getPicSpotId();
	}
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-26 下午7:58:01
	 * @param @param request
	 * @param @param response
	 * @param @param model
	 * @param @return
	 * @param @throws Exception 
	 * @return ModelAndView 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	@RequestMapping(value = "/uploadOnePicture.do", method = RequestMethod.POST)
	public ModelAndView uploadOnePicture(@RequestParam("file") MultipartFile[] file,
			HttpServletRequest request)throws Exception {
		ModelAndView view = new ModelAndView("layout/empty");
		if(null == file){
			view.addObject("screen_content", "fail");
		}
		Date date = new Date();
		OnePricture onePic = new OnePricture();
		onePic.setLoveId(Long.parseLong("loveId"));
		onePic.setPicSpotId(Long.parseLong("picSpotId"));
		onePic.setYn(0);
		onePic.setState(1);//景区
		onePic.setCreateTime(date);
		onePic.setUpdateTime(date);
		int onePicId = oneprictureDao.inserOnePicture(onePic);
		int index = 0 ;
		for(MultipartFile f:file){
			OnePrictureDetail detail = new OnePrictureDetail();
			detail.setOnePicId(onePicId);
			detail.setCreateTime(date);
			detail.setUpdateTime(date);
			detail.setYn(0);
			detail.setPicName(f.getOriginalFilename());
			detail.setPicSeq(index);
			detail.setPicDescription("");
			
			String realPath="D:/";
			File pathFile=new File(realPath);
			if(!pathFile.exists()){
				pathFile.mkdirs();
			}
			try {
				f.transferTo(new File(realPath+"/"+f.getOriginalFilename()));
			} catch (IllegalStateException e) {
				e.printStackTrace();
			}
			index++;
		}		
		view.addObject("screen_content", "success");
		return view;
	}
	

	
	
	
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-27 上午11:39:06
	 * @param @param request
	 * @param @param response
	 * @param @param model
	 * @param @return
	 * @param @throws Exception 
	 * @return ModelAndView 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	@RequestMapping(value = "/insertOnePic.do", method = { RequestMethod.POST,RequestMethod.GET })
	public ModelAndView insertOnePic(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		ModelAndView view = new ModelAndView("layout/empty");
		OnePricture onePic = new OnePricture();
		if(StringUtils.isNotEmpty(request.getParameter("loveId"))){
			onePic.setLoveId(Long.parseLong(request.getParameter("loveId")));
		}
		if(StringUtils.isNotEmpty(request.getParameter("picSpotId"))){
			onePic.setPicSpotId(Long.parseLong(request.getParameter("picSpotId")));
		}
		onePic.setCreateTime(new Date());
		onePic.setUpdateTime(new Date());
		int dataId = oneprictureDao.inserOnePicture(onePic);
		for(int i = 0 ;i <2;i++){
			OnePrictureDetail detail = new OnePrictureDetail();
			detail.setOnePicId(dataId);
			detail.setPicName(i+"_.jpg");
			detail.setPicSeq(i);
			detail.setCreateTime(new Date());
			detail.setUpdateTime(new Date());
			detail.setPicDescription("");
			onePictureDetailDao.insertOnePrictureDetail(detail);
		}
		view.addObject("screen_content", "success");
		return view;
	}
	
	
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-27 上午11:55:23
	 * @param @param request
	 * @param @param response
	 * @param @param model
	 * @param @return
	 * @param @throws Exception 
	 * @return ModelAndView 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	@RequestMapping(value = "/getOnePicsByLoveId.do", method = { RequestMethod.POST,RequestMethod.GET })
	public ModelAndView getOnePicsByLoveId(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		ModelAndView view = new ModelAndView("layout/detail");
		OnePrictureDetail detail = new OnePrictureDetail();
		detail.setOnePicId(6L);
		List<OnePrictureDetail> list  = onePictureDetailDao.getOnePrictureDetails(detail);
		view.addObject("onePicDetailList",list);
		view.addObject("screen_content", "success");
		return view;
	}
	
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-27 下午6:21:30
	 * @param @param request
	 * @param @param response
	 * @param @param model
	 * @param @return
	 * @param @throws Exception 
	 * @return OneFirstPageResult 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	
	@RequestMapping(value = "/initOneFirstPage.do", method = { RequestMethod.POST,RequestMethod.GET })
	@ResponseBody
	public OneFirstPageResult initOneFirstPage(HttpServletRequest request, HttpServletResponse response,
			Model model) throws Exception {
		OnePricture onePic = new OnePricture();
		if(StringUtils.isNotEmpty(request.getParameter("loveId"))){
			onePic.setLoveId(Long.parseLong(request.getParameter("loveId")));
		}
		if(StringUtils.isNotEmpty(request.getParameter("picSpotId"))){
			onePic.setPicSpotId(Long.parseLong(request.getParameter("picSpotId")));
		}else{
			onePic.setPicSpotId(1L);
		}
		if(StringUtils.isNotEmpty(request.getParameter("state"))){
			onePic.setState(Integer.parseInt(request.getParameter("state")));
		}
		OneFirstPageResult result = new OneFirstPageResult(); 
		List<OneFirstPageDetailResult> preceptList = new ArrayList<OneFirstPageDetailResult>();
		List<OnePricture> list = oneprictureDao.getOneprictures(onePic);
		if(null != list){
			result.setCode(1);
			for(OnePricture firstPic: list){
				result.setTitle(firstPic.getTitle());
				OnePrictureDetail detail = new OnePrictureDetail();
				detail.setOnePicId(firstPic.getId());
				detail.setPicSeq(0);
				List<OnePrictureDetail> details = onePictureDetailDao.getOnePrictureDetails(detail);
				OnePrictureDetail firstPagePic = details.get(0);
				OneFirstPageDetailResult detailResult = new OneFirstPageDetailResult();
				detailResult.setImgId(Integer.valueOf(firstPic.getId()+""));
				detailResult.setImgUrl(request.getContextPath()
						+ File.separator + "upload" + File.separator
						+ firstPagePic.getPicName());
				detailResult.setSubMsg(firstPagePic.getPicDescription());
				preceptList.add(detailResult);
			}
			result.setPreceptList(preceptList);
		}else{
			result.setCode(2);
		}
		return result;
	}
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-27 上午11:38:59
	 * @param @param request
	 * @param @param response
	 * @param @param model
	 * @param @return
	 * @param @throws Exception 
	 * @return ModelAndView 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	@RequestMapping(value = "/getOnePic.do", method = { RequestMethod.POST,RequestMethod.GET })
	@ResponseBody
	public OneSunPicResult getOnePic(HttpServletRequest request, HttpServletResponse response,Model model) throws Exception {
		OnePricture onePic = new OnePricture();
		Map<String, Object> userInfo = userService.isLogin(request.getSession());
		if(null  == userInfo){
			return null;
		}
		if(StringUtils.isNotEmpty(request.getParameter("loveId"))){
			onePic.setLoveId(Long.parseLong(request.getParameter("loveId")));
		}
		if(StringUtils.isNotEmpty(request.getParameter("picSpotId")) && !"null".equals(request.getParameter("picSpotId"))){
			onePic.setPicSpotId(Long.parseLong(request.getParameter("picSpotId")));
		}
		if(StringUtils.isNotEmpty(request.getParameter("id")) && !"null".equals(request.getParameter("id"))){
			onePic.setId(Long.parseLong(request.getParameter("id")));
		}
		
		if(StringUtils.isNotEmpty(request.getParameter("state"))){
			onePic.setState(Integer.parseInt(request.getParameter("state")));
		}
		OneSunPicResult result = new OneSunPicResult(); 
		List<OnePricture> list = oneprictureDao.getOneprictures(onePic);
		if(null != list){
			for(OnePricture firstPic: list){
				List<Map<String, Object>> onePicSpot = oneprictureDao.getOneViewSpot(firstPic.getPicSpotId());
				for (Map<String, Object> map : onePicSpot) {
					result.setOnePicSpotName(map.get("view_spot_name").toString());
				}
				result.setOnePic(firstPic);
				OnePrictureDetail detail = new OnePrictureDetail();
				detail.setOnePicId(firstPic.getId());
				detail.setPicSeq(0);
				List<OnePrictureDetail> details = onePictureDetailDao.getOnePrictureDetails(detail);
				for(OnePrictureDetail child : details){
					child.setUrl(File.separator
							+ child.getPicName());
				}
				result.setList(details);
			}
		}
			return result;
		}
	
	
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-28 上午1:26:40
	 * @param @param request
	 * @param @param response
	 * @param @param model
	 * @param @return
	 * @param @throws Exception 
	 * @return String 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	@RequestMapping(value = "/updateOnePicTitle.do", method = { RequestMethod.POST,RequestMethod.GET })
	public String updateOnePicTitle(HttpServletRequest request, HttpServletResponse response,Model model) throws Exception {
		String id = request.getParameter("id");
		String picSpotId = request.getParameter("picSpotId");
		String title = request.getParameter("title");
		OnePricture onePic = new OnePricture();
		onePic.setId(Long.parseLong(id));
		onePic.setTitle(title);
		onePic.setPicSpotId(Long.parseLong(picSpotId));
		oneprictureDao.updateOnePictureTitle(onePic);
		System.err.println("redirect:/sun.html?id="+id);
		return "redirect:/sun.html?id="+id;
	}
	
}
