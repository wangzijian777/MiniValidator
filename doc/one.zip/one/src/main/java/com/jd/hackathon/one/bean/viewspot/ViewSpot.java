package com.jd.hackathon.one.bean.viewspot;

import com.jd.hackathon.one.bean.DTOBaseImpl;

/**
 * 景点表
 * @author yhan
 * 2015-6-26
 */
public class ViewSpot extends DTOBaseImpl{

	private Integer viewSpotId;
	private String viewSpotName;
	private String viewSpotInfo;
	private String picId;
	private Double longitude;
	private Double latitude;
	private Integer province;
	private Integer city;
	private Integer county;
	private Integer town;
	private String alias;
	private Integer count;
	private Boolean isLove;
	private Integer signFlag;
	private String areaName;
	public Integer getViewSpotId() {
		return viewSpotId;
	}
	public void setViewSpotId(Integer viewSpotId) {
		this.viewSpotId = viewSpotId;
	}
	public String getViewSpotName() {
		return viewSpotName;
	}
	public void setViewSpotName(String viewSpotName) {
		this.viewSpotName = viewSpotName;
	}
	public String getViewSpotInfo() {
		return viewSpotInfo;
	}
	public void setViewSpotInfo(String viewSpotInfo) {
		this.viewSpotInfo = viewSpotInfo;
	}
	public String getPicId() {
		return picId;
	}
	public void setPicId(String picId) {
		this.picId = picId;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public Integer getProvince() {
		return province;
	}
	public void setProvince(Integer province) {
		this.province = province;
	}
	public Integer getCity() {
		return city;
	}
	public void setCity(Integer city) {
		this.city = city;
	}
	public Integer getCounty() {
		return county;
	}
	public void setCounty(Integer county) {
		this.county = county;
	}
	public Integer getTown() {
		return town;
	}
	public void setTown(Integer town) {
		this.town = town;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Boolean getIsLove() {
		return isLove;
	}
	public void setIsLove(Boolean isLove) {
		this.isLove = isLove;
	}
	public Integer getSignFlag() {
		return signFlag;
	}
	public void setSignFlag(Integer signFlag) {
		this.signFlag = signFlag;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	
}
