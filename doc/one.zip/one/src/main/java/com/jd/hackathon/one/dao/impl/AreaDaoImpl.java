package com.jd.hackathon.one.dao.impl;

import com.jd.hackathon.one.bean.viewspot.ViewSpot;

public class AreaDaoImpl extends DaoBaseImpl<ViewSpot>{

	public AreaDaoImpl(){
		ns = "com.jd.hackathon.one.dao.impl.AreaDaoImpl";
	}
	
}
