package com.jd.hackathon.one.dao.impl;

import org.springframework.stereotype.Repository;

import com.jd.hackathon.one.bean.viewspot.ViewSpotStrategyDetail;

@Repository("viewSpotStrategyDetailDaoImpl")
public class ViewSpotStrategyDetailDaoImpl extends DaoBaseImpl<ViewSpotStrategyDetail>{

	public ViewSpotStrategyDetailDaoImpl(){
		ns = "com.jd.hackathon.one.dao.impl.ViewSpotStrategyDetailDao";
	}
	
}
