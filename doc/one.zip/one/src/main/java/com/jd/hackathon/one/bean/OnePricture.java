package com.jd.hackathon.one.bean;

import java.util.Date;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.bean 
 * @ClassName: OnePricture 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-26 下午8:23:27
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
public class OnePricture {

	private long id;
	private long  picSpotId;
	private long  loveId;
	private Date  createTime;
	private Date updateTime;
	private int state;
	private String title;
	private int yn;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getPicSpotId() {
		return picSpotId;
	}
	public void setPicSpotId(long picSpotId) {
		this.picSpotId = picSpotId;
	}
	public long getLoveId() {
		return loveId;
	}
	public void setLoveId(long loveId) {
		this.loveId = loveId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public int getYn() {
		return yn;
	}
	public void setYn(int yn) {
		this.yn = yn;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
