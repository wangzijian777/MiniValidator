package com.jd.hackathon.one.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.jd.hackathon.one.bean.OnePrictureDetail;
import com.jd.hackathon.one.util.DateUtils;
import com.mysql.jdbc.Statement;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.dao.impl 
 * @ClassName: OnePictureDetailImpl 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-26 下午9:06:08
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
@Repository
public class OnePictureDetailDao{

	
	@Autowired
	protected JdbcTemplate jdbcTemplate;
	
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-27 上午11:49:10
	 * @param @param detail
	 * @param @return 
	 * @return List<OnePrictureDetail> 
	 * @throws ParseException 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	public List<OnePrictureDetail> getOnePrictureDetails(OnePrictureDetail detail) throws ParseException{
		List<OnePrictureDetail> onePicDetails = new ArrayList<OnePrictureDetail>();
		Map<String, Object> param = new HashMap<String, Object>();
		String sql = "select * from  one_picture_detail where 0=0";
		if(null != detail){
			if(detail.getOnePicId() != 0){
				param.put("pic_id", detail.getOnePicId());
			}
			if(detail.getCreateTime() != null){
				param.put("create_time", detail.getCreateTime());
			}
		}
		for (String key : param.keySet()) {
			sql += " and " + key + "=" + param.get(key);
		}
		List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(sql);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if(null != resultList){
			for(Map<String,Object> map :resultList){
				OnePrictureDetail onePicDetail = new OnePrictureDetail();
				System.out.println(map.toString());
				onePicDetail.setId(Long.parseLong(map.get("id").toString()));
				onePicDetail.setOnePicId(Long.parseLong(map.get("pic_id").toString()));
				onePicDetail.setPicSeq(Integer.valueOf((map.get("pic_seq").toString())));
				onePicDetail.setPicName(map.get("pic_name").toString());
				onePicDetail.setPicDescription(map.get("pic_description").toString());
				onePicDetail.setCreateTime(sdf.parse(map.get("create_time").toString()));
				onePicDetail.setCreateTime(sdf.parse(map.get("update_time").toString()));
				onePicDetail.setYn(Integer.parseInt((String)map.get("yn").toString()));
				onePicDetails.add(onePicDetail);
			}
		}
		return onePicDetails;		
	}
	
	
	/**
	 * 
	 * 
	 * @Description TODO(这里用一句话描述这个方法的作用) 
	 * @author      wangjingzhao 
	 * @createDate  2015-6-27 上午11:49:07
	 * @param @param detail
	 * @param @return 
	 * @return int 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	public int insertOnePrictureDetail(final OnePrictureDetail detail){
		KeyHolder keyHolder = new GeneratedKeyHolder();  
		jdbcTemplate.update(new PreparedStatementCreator() {
		@Override
		public PreparedStatement createPreparedStatement(Connection connection)
				throws SQLException {
	        String sql = "insert into one_picture_detail (pic_id,pic_seq,pic_name,pic_description,create_time,update_time,yn) " +
	        "values(?,?,?,?,?,?,?)";
	        PreparedStatement ps = connection.prepareStatement(sql,	Statement.RETURN_GENERATED_KEYS);
	        ps.setString(1, detail.getOnePicId()+"");
	        ps.setString(2, detail.getPicSeq()+"");
	        ps.setString(3, detail.getPicName()+"");
	        ps.setString(4, detail.getPicDescription()+"");
	        ps.setString(5, DateUtils.formatDatetime(detail.getCreateTime())+"");
	        ps.setString(6, DateUtils.formatDatetime(detail.getUpdateTime())+"");
	        ps.setString(7, "0");
	        return ps;
	      }
	    }, keyHolder);
	    Integer generatedId = keyHolder.getKey().intValue();				
		return generatedId;
	}
	
}
