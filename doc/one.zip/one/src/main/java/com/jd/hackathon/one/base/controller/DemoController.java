/**
 * Copyright(C) 2015 zdd9999@gmail.com All Right Reserved
 */
package com.jd.hackathon.one.base.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.jd.hackathon.one.base.web.servlet.handler.JsonpHandler;

/**
 *<p></p>
 *@author 周德东<zdd9999@gmail.com>
 *@version 1.0
 *@date 2015-5-21 下午11:21:44
 */
@Controller
@RequestMapping("/one")
public class DemoController {
    private static final Logger LOGGER = LoggerFactory.getLogger(DemoController.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private JsonpHandler jh;

    
    @Autowired
    private SqlSession sqlSession;
    
    /**
     * mybatis的mapping 命名空间
     */
    private static final String NS = "com.jd.hackathon.one.base.dao.BaseDao";
    
    @RequestMapping("/jdbc.json")
    public @ResponseBody Object jdbc(HttpServletRequest req){
        String sql = "SELECT * FROM test LIMIT 0,10";
        LOGGER.info(">>>>>>>>>> demo/jdbc.json.... "+sql);
        return  jdbcTemplate.queryForList(sql);
    }
    
    @RequestMapping("/mybatis.json")
    public @ResponseBody Object mybatis(HttpServletRequest req){
        LOGGER.info(">>>>>>>>>> demo/mybatis.json.... query");
        return  sqlSession.selectList(NS+".query");
    }
    
    @RequestMapping("/vm.do")
    public ModelAndView vm(HttpServletRequest req) throws Exception{
        ModelAndView view = new ModelAndView("layout/empty");
        List<Map<String,Object>> list = sqlSession.selectList(NS+".query");
        view.addObject("screen_content", list);
        return  view;
    }
    

   
 
    @RequestMapping("/showDetail")
    public void addImage(HttpServletRequest request,String path1,String path2) {  
        //转型为MultipartHttpRequest(重点的所在)  
    	System.out.println("cc");
         MultipartHttpServletRequest multipartRequest  =  (MultipartHttpServletRequest) request;  
         //  获得第1张图片（根据前台的name名称得到上传的文件）   
         MultipartFile imgFile1  =  multipartRequest.getFile("imgFile");  
          
         //定义一个数组，用于保存可上传的文件类型  
         List fileTypes = new ArrayList();  
         fileTypes.add("jpg");  
         fileTypes.add("jpeg");  
         fileTypes.add("bmp");  
         fileTypes.add("gif");  
           
         //保存第一张图片  
         if(!(imgFile1.getOriginalFilename() ==null || "".equals(imgFile1.getOriginalFilename()))) {  
/*下面调用的方法，主要是用来检测上传的文件是否属于允许上传的类型范围内，及根据传入的路径名 
*自动创建文件夹和文件名，返回的File文件我们可以用来做其它的使用，如得到保存后的文件名路径等 
*这里我就先不做多的介绍。 
*/  
             File file1 = this.getFile(imgFile1, "user1",new Date().getTime()+"",fileTypes); 
              
         }
         }  

    @RequestMapping("/jsonp.jsonp")
    public void jsonp(HttpServletRequest request,
            HttpServletResponse response) {
        List<Map<String,Object>> list = sqlSession.selectList(NS+".query");
        jh.jsonp(request, response, list);

    }
    

         private File getFile(MultipartFile imgFile,String typeName,String brandName,List fileTypes) {  
             String fileName = imgFile.getOriginalFilename();  
             //获取上传文件类型的扩展名,先得到.的位置，再截取从.的下一个位置到文件的最后，最后得到扩展名  
              String ext = fileName.substring(fileName.lastIndexOf(".")+1,fileName.length());  
              //对扩展名进行小写转换  
              ext = ext.toLowerCase();  
                
              File file = null;  
              if(fileTypes.contains(ext)) {                      //如果扩展名属于允许上传的类型，则创建文件  
                  file = this.creatFolder(typeName, brandName, fileName);  
                  try {  
                     imgFile.transferTo(file);                   //保存上传的文件  
                 } catch (IllegalStateException e) {  
                     e.printStackTrace();  
                 } catch (IOException e) {  
                     e.printStackTrace();  
                 }  
              }  
              return file;  
         } 
         
         private File creatFolder(String typeName,String brandName,String fileName) {  
             File file = null;  

             String url = this.getClass().getClassLoader().getResource("/").getPath();
             System.out.println(url);
             File firstFolder = new File(url+ "../"+typeName);      //一级文件夹  
             if(firstFolder.exists()) {                             //如果一级文件夹存在，则检测二级文件夹  
                 File secondFolder = new File(firstFolder,brandName);  
                 if(secondFolder.exists()) {                        //如果二级文件夹也存在，则创建文件  
                     file = new File(secondFolder,fileName);  
                 }else {                                            //如果二级文件夹不存在，则创建二级文件夹  
                     secondFolder.mkdir();  
                     file = new File(secondFolder,fileName);        //创建完二级文件夹后，再合建文件  
                 }  
             }else {                                                //如果一级不存在，则创建一级文件夹  
                 firstFolder.mkdir();  
                 File secondFolder = new File(firstFolder,brandName);  
                 if(secondFolder.exists()) {                        //如果二级文件夹也存在，则创建文件  
                     file = new File(secondFolder,fileName);  
                 }else {                                            //如果二级文件夹不存在，则创建二级文件夹  
                     secondFolder.mkdir();  
                     file = new File(secondFolder,fileName);  
                 }  
             }  
             return file;  
        }
           
          
    }  
    
    

    
