package com.jd.hackathon.one.base.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.hackathon.one.bean.viewspot.ViewSpot;
import com.jd.hackathon.one.dao.impl.OneprictureDao;
import com.jd.hackathon.one.service.UserService;
import com.jd.hackathon.one.service.ViewSpotService;

/**
 * 
 * @author wangchongyang
 *
 */
@Controller
@RequestMapping("/m")
public class ViewPictureController {

	@Autowired
	public ViewSpotService viewSpotService;
	@Autowired
	private OneprictureDao oneprictureDao;
	@Autowired
	UserService userService;

	/**
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getDetailList.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public Map<String, Object> getDetailList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		Integer picId = NumberUtils.toInt(request.getParameter("picId"));
		// Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> map = viewSpotService.getDetailList(picId);
		map.put("loverList", oneprictureDao.getLoverList(picId));
		return map;
	}

	@RequestMapping(value = "/getViewPsotList.do", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public Map<String, Object> getViewPsotList(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		// Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> login = userService.isLogin(request.getSession());
		List<ViewSpot> vsList = viewSpotService.getViewPsotList();
		if (null != login) {
			Integer lId = MapUtils.getInteger(login, "l_id");
			for (ViewSpot viewSpot : vsList) {
				viewSpot.setIsLove(viewSpotService.getHappyCountByViewIdAndUserId(viewSpot.getViewSpotId(), lId) > 0);
			}
		} 
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("vsList", vsList);
		return map;
	}

	@RequestMapping(value = "/topPicture.json")
	@ResponseBody
	public Map<String, Object> topPicture(HttpServletRequest request) {
		Integer viewSpotId = null;
		String svs = request.getParameter("viewSpotId");
		if (NumberUtils.isDigits(svs)) {
			viewSpotId = NumberUtils.toInt(svs);
		}
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("data", viewSpotService.topPicture(viewSpotId, 10));
		return result;
	}
}
