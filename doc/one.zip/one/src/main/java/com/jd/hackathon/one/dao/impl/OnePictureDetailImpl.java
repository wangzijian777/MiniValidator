package com.jd.hackathon.one.dao.impl;

import java.util.List;
import java.util.Map;

import com.jd.hackathon.one.bean.OnePrictureDetail;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.dao.impl 
 * @ClassName: OnePictureDetailImpl 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-26 下午9:06:08
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
public class OnePictureDetailImpl extends DaoBaseImpl{

	
	public List<OnePrictureDetail> getOnePrictureDetails(Map<String,Object> param){
		return null;
	}
}
