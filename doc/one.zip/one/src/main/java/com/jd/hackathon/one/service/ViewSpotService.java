package com.jd.hackathon.one.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.jd.hackathon.one.bean.HappyListBean;
import com.jd.hackathon.one.bean.viewspot.ViewSpot;
import com.jd.hackathon.one.bean.viewspot.ViewSpotStrategy;
import com.jd.hackathon.one.bean.viewspot.ViewSpotStrategyDetail;
import com.jd.hackathon.one.dao.impl.ViewSpotDaoImpl;
import com.jd.hackathon.one.dao.impl.ViewSpotStrategyDaoImpl;
import com.jd.hackathon.one.dao.impl.ViewSpotStrategyDetailDaoImpl;
import com.jd.hackathon.one.util.JsonUtil;

/**
 * 景点service
 * 
 * @author yhan 2015-6-26
 */
@Service("viewSpotService")
public class ViewSpotService {

	// 经度范围
	private Integer range = 300;

	@Autowired
	public ViewSpotDaoImpl viewSpotDaoImpl;
	@Autowired
	public ViewSpotStrategyDaoImpl viewSpotStrategyDaoImpl;
	@Autowired
	public ViewSpotStrategyDetailDaoImpl viewSpotStrategyDetailDaoImpl;

	@Autowired
	private SqlSession sqlSession;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	UserService userService;

	/**
	 * 判断经纬度和景点是否匹配
	 * 
	 * @param longitude
	 * @param latitude
	 * @param viewSpotId
	 * @return
	 */
	public boolean isMatching(Double longitude, Double latitude, Integer viewSpotId) {

		return true;
	}

	/**
	 * 首页 根据四级地址获取景点列表
	 * 
	 * @param province
	 * @param city
	 * @param county
	 * @param town
	 * @return
	 */
	public List<ViewSpot> getViewSpotByArea(Integer province, Integer city, Integer county, Integer town) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("province", province);
		map.put("city", city);
		map.put("county", county);
		map.put("town", town);
		return getViewSpotByParam(map);
	}

	/**
	 * 首页 根据经纬度查询景点列表
	 * 
	 * @param longitude
	 * @param latitude
	 * @return
	 */
	public List<ViewSpot> getViewSpotByAccuracy(Double longitude, Double latitude) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("longitude", longitude);
		map.put("latitude", latitude);
		return getViewSpotByParam(map);
	}

	/**
	 * 首页 获取景点列表
	 * 
	 * @return
	 */
	public List<ViewSpot> getViewSpotByParam(Map<String, Object> map) {
		return viewSpotDaoImpl.findByParams(map);
	}

	/**
	 * 首页 根据景点id获取攻略
	 * 
	 * @param viewSpotId
	 * @return
	 */
	public List<ViewSpotStrategy> getStrategyByViewSpot(Integer viewSpotId) {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("viewSpotId", 1);
		List<ViewSpotStrategy> findByParams = viewSpotStrategyDaoImpl.findByParams(param);
		return findByParams;
	}

	/**
	 * 首页 根据攻略id获取所有攻略
	 * 
	 * @param strategyId
	 * @return
	 */
	public List<ViewSpotStrategyDetail> getStrategyDetailByStrategy(Integer strategyId) {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("strategyId", 1);
		List<ViewSpotStrategyDetail> findByParams = viewSpotStrategyDetailDaoImpl.findByParams(param);
		return findByParams;
	}

	/**
	 * 获取收藏景点
	 * 
	 * @param request
	 * @return
	 */
	public List<ViewSpot> getSignViewSpot(HttpServletRequest request) {
		String NS = "com.jd.hackathon.one.base.dao.BaseDao";
		List<ViewSpot> list = new ArrayList<ViewSpot>();
		if (request == null) {
			return list;
		}
		Map<String, Object> login = userService.isLogin(request.getSession());
		if (login != null) {
			// 已登录
			Object lId = login.get("l_id");
			if (lId != null && StringUtils.isNotBlank(lId.toString())) {
				List<HappyListBean> happyList = sqlSession.selectList(NS + ".getHappyList", lId);
				for (HappyListBean bean : happyList) {
					Integer spotId = (int) bean.getSpotId();
					ViewSpot viewSpot = viewSpotDaoImpl.findById(spotId);
					viewSpot.setSignFlag(bean.getIsSigned());
					list.add(viewSpot);
				}
			}
		} else {
			// 测试
//			Object lId = 1;
//			if (lId != null && StringUtils.isNotBlank(lId.toString())) {
//				List<HappyListBean> happyList = sqlSession.selectList(NS + ".getHappyList", lId);
//				for (HappyListBean bean : happyList) {
//					Integer spotId = (int) bean.getSpotId();
//					ViewSpot viewSpot = viewSpotDaoImpl.findById(spotId);
//					viewSpot.setSignFlag(bean.getIsSigned());
//					list.add(viewSpot);
//				}
//			}
		}
		return list;
	}

	public Integer getRange() {
		return range;
	}

	public void setRange(Integer range) {
		this.range = range;
	}

	public ViewSpotDaoImpl getViewSpotDaoImpl() {
		return viewSpotDaoImpl;
	}

	public void setViewSpotDaoImpl(ViewSpotDaoImpl viewSpotDaoImpl) {
		this.viewSpotDaoImpl = viewSpotDaoImpl;
	}

	/**
	 * 获取景点的攻略详细
	 * 
	 * @param viewSpotId
	 *            景点id
	 * @return
	 */
	public Map<String, Object> getDetailList(Integer viewSpotId) {
		ViewSpot vs = viewSpotDaoImpl.findById(viewSpotId);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("viewSpotId", viewSpotId);
		List<ViewSpotStrategy> list = viewSpotStrategyDaoImpl.findByParams(map);
		Map<String, Object> result = new HashMap<String, Object>();
		// 景点名称
		result.put("viewSpot", vs);

		List<Map<String, Object>> vssdListMap = new ArrayList<Map<String, Object>>();
		if (!CollectionUtils.isEmpty(list)) {
			for (ViewSpotStrategy vss : list) {
				Map<String, Object> vMap = new HashMap<String, Object>();
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("strategyId", vss.getStrategyId());
				List<ViewSpotStrategyDetail> vssdList = viewSpotStrategyDetailDaoImpl.findByParams(params);

				vMap.put("strategyTitle", vss.getTitle());
				vMap.put("vssdList", vssdList);
				vssdListMap.add(vMap);
			}
		}
		// 景点攻略
		result.put("vssdListMap", vssdListMap);
		int limit = 2;
		// 晒幸福
		List<Map<String, Object>> topPicture = topPicture(viewSpotId, limit);
		result.put("topPicture", topPicture);
		return result;
	}

	public List<ViewSpot> getViewPsotList() {
		List<ViewSpot> vsList = viewSpotDaoImpl.findAll(new HashMap<String, Object>());
		return vsList;
	}

	public Integer getHappyCountByViewIdAndUserId(Integer viewPotId, Integer lid) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("viewPotId", viewPotId);
		map.put("lId", lid);
		String NS = "com.jd.hackathon.one.base.dao.BaseDao";
		Integer count = sqlSession.selectOne(NS + ".getHappyCountByViewIdAndUserId", map);

		return count;

	}

	/***
	 * 一个景点的晒幸福前几条
	 * 
	 * @param viewSpotId
	 * @param limit
	 * @return
	 */
	public List<Map<String, Object>> topPicture(Integer viewSpotId, int limit) {
		Object[] args = new Object[] { limit };
		String sql = "SELECT a.id, a.pic_spot_id,a.love_id, a.create_time ,b.pic_name,b.pic_description  " + " FROM  `one_picture` a "
				+ " INNER JOIN `one_picture_detail` b ON a.id  = b. pic_id " + " WHERE  b.pic_name IS NOT NULL AND b.pic_description IS NOT NULL  ";
		if (viewSpotId != null && viewSpotId > 0) {
			sql += " AND a.pic_spot_id = ? ";
			args = new Object[] { viewSpotId, limit };
		}
		sql += " GROUP BY a.id, a.pic_spot_id,a.love_id " + " ORDER BY a.create_time DESC" + " LIMIT 0,? ";
		return jdbcTemplate.queryForList(sql, args);
	}

}
