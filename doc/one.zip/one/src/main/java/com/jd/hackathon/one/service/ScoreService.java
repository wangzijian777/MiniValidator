/**
 * Copyright(C) 2004-2015 JD.COM All Right Reserved
 */
package com.jd.hackathon.one.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

/**
 *<p></p>
 *@author zhoudedong 运营研发部
 *@version 1.0
 *@date 2015-6-26 下午8:55:45
 */
@Service
public class ScoreService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ScoreService.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;
    /**
     * 添加情侣积分
     * @param lId 情侣id
     * @param score 需要添加的积分多少
     */
   public void plusScore(int lId,int score){
       LOGGER.info("plusScore>> [lId="+lId+",score="+score+"]");
       String sql = "UPDATE  one_lover SET total_score = total_score + ? WHERE l_id = ?";
       try {
           jdbcTemplate.update(sql, score, lId);
       } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
       }
    }
    public List<Map<String, Object>> topLoverScore() {
        String sql = "SELECT (@rownum:=@rownum+1) AS rownum, a.l_id,a.total_score,b.u_name,b.u_name n_u_name," +
        		" (CASE  WHEN b.sex <> c.sex THEN 4  WHEN (b.sex = c.sex AND c.sex = 1) THEN 1" +
        		" WHEN (b.sex = c.sex AND c.sex = 2) THEN 3  ELSE 4 END) sexmen " +
        		" FROM  (SELECT @rownum:=0) r,  `one_lover` a "+
                "INNER JOIN `one_user` b ON a.l_id = b.l_id "+
                "INNER JOIN `one_user` c ON a.l_id = c.l_id AND b.u_id < c.u_id  "+
                "WHERE a.yn = 0  "+
                "ORDER BY a.total_score DESC " +
                "LIMIT 0,10";
        return jdbcTemplate.queryForList(sql);
    }
}
