package com.jd.hackathon.one.util;

import java.util.Random;

/**   
 *    
 * @Project：one  
 * @Package：com.jd.hackathon.one.util 
 * @ClassName: RandomUtil 
 * @Description: TODO(用一句话描述该文件做什么)  
 * @author：wangjingzhao   
 * @date 2015-6-26 下午5:42:07
 * @Copyright: Copyright (c)2015 JD.COM All Right Reserved
 * @since:       JDK 1.6
 * @Version：  V1.0 
 *    
 */
public class RandomUtil {
	
	private static final String base = "abcdefghijklmnopqrstuvwxyz0123456789";  
	
	/**
	 * 
	 * 
	 * @Description 随机数生成
	 * @author      wangjingzhao 
	 * @createDate  2015-6-26 下午5:44:42
	 * @param @param length
	 * @param @return 
	 * @return String 
	 * @exception   
	 * @throws	 
	 * @lastModify
	 */
	public static String getRandom(int length){
		Random random = new Random();     
	    StringBuffer sb = new StringBuffer();     
	    for (int i = 0; i < length; i++) {     
	        int number = random.nextInt(base.length());     
	        sb.append(base.charAt(number));     
	    }     
	    return sb.toString();
	}
}
