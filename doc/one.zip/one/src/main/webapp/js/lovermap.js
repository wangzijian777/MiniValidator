function callSign(){
	var data1 = {};
	var map = new BMap.Map("allmap");
	map.centerAndZoom("北京");
	$.ajax({
		type: 'POST',
		cache:false,
		url: contextPath+"/viewspot/signView.do",
		dataType: 'json',
		data: data1,
		success: function(result, textStatus, jqXHR) {
			var template = $('#viewSpotTpl').html();
            Mustache.parse(template); 
            var html = Mustache.render(template, result);
            $("#allViewSpotWp").append(html);
            
			var data = result.data;
			var flag = false;
			if(data && data.length){
				for(var i = 0; i < data.length; i++){
//					var centerP = new BMap.Point(data[0].longitude, data[0].latitude);
//					map.centerAndZoom(centerP);
					var longitude = data[i].longitude;
					var latitude = data[i].latitude;
					var point = new BMap.Point(longitude, latitude);
					var iconUrl = "";
					if(2 == data[i].signFlag){
						iconUrl = "img/lover.png";
						if(!flag){
							var centerPoint = new BMap.Point(longitude, latitude + 30);
							map.panTo(centerPoint);
							flag = true;
						}
					}else if(1 == data[i].signFlag){
						iconUrl = "img/singler.png";
						if(!flag){
							var centerPoint = new BMap.Point(longitude, latitude + 30);
							map.panTo(centerPoint);
							flag = true;
						}
					}
					if(iconUrl != ""){
						var icon = new BMap.Icon(iconUrl, new BMap.Size(20, 20));//显示图标大小
						marker = new BMap.Marker(point,"hello");// 创建标注
						marker.setIcon(icon);//设置标签的图标为自定义图标
						var content = data[i].viewSpotName;
						marker.setLabel(new BMap.Label(content,{offset:new BMap.Size(15,15)}));
//						infoWindow = new BMap.InfoWindow("<p style='font-size:14px;'>" + content + "</p>");
//						marker.addEventListener("click", function () { this.openInfoWindow(infoWindow); }); // 
						marker.setAnimation(BMAP_ANIMATION_BOUNCE); //跳动的动画
						map.addOverlay(marker);// 将标注添加到地图中
					}
				}
			}
        }
	});
};
$(document).ready(function(){
	callSign();
})

