$(function(){
    $("#silder img").height($(".common-wrapper").height()-98);
    $("#detail").height($(".common-wrapper").height()-98);
    var swiper = new Swiper('.swiper-container', {
        centeredSlides: true,
        autoplayDisableOnInteraction: false,
        loop:true,
        threshold:100
    });

    $("#silder").bind("touchstart",function(event){
        event.preventDefault();
    });

    $("#silder").on("click",".love-icon",function(){
        $(this).toggleClass("loved");
    });

    $("#silder").on("swipeUp",function(event){
        $("#scroll").removeClass("moveUp").addClass("moveDown");
        $("#silder").unbind("touchstart");
        $(".location").hide();
        $(".back").show();
    });

    /*$("#detail").on("swipeDown",function(event){
        event.stopPropagation();
    }).on("swipeUp",function(event){
        event.stopPropagation();
    });*/

    $("#to-top").click(function(){
        $("#scroll").removeClass("moveDown").addClass("moveUp");
        $(".location").show();
        $(".back").hide();
        $("#silder").bind("touchstart",function(event){
            window.event.returnValue = false;
        });
    })
});