package com.jd.hackathon.one.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.hackathon.one.bean.viewspot.ViewSpot;
import com.jd.hackathon.one.bean.viewspot.ViewSpotStrategy;
import com.jd.hackathon.one.bean.viewspot.ViewSpotStrategyDetail;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/applicationContext.xml"})
public class ViewSpotServiceTest {

	@Autowired
	ViewSpotService viewSpotService;
	
	@Test
	public void test() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("viewSpotId", 1);
//		List<ViewSpot> viewSpotByParam = viewSpotService.getViewSpotByParam(map);
//		List<ViewSpotStrategy> strategyByViewSpot = viewSpotService.getStrategyByViewSpot(1);
		List<ViewSpotStrategyDetail> strategyDetailByStrategy = viewSpotService.getStrategyDetailByStrategy(1);
		System.out.println(111);
	}

}
