/**
 * Copyright(C) 2004-2015 JD.COM All Right Reserved
 */
package com.jd.hackathon.one.service;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *<p></p>
 *@author zhoudedong 运营研发部
 *@version 1.0
 *@date 2015-6-26 下午9:01:54
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/applicationContext.xml"})
public class ScoreServiceTest {
    @Autowired
    private ScoreService scoreService;
    @Test
    public void testPlusScore() {
        scoreService.plusScore(1, 100);
    }

}
