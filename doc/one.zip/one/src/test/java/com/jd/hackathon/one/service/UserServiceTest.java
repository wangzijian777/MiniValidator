package com.jd.hackathon.one.service;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/applicationContext.xml"})
public class UserServiceTest {
	
	@Autowired
	private UserService userService;

	@Test
	public void testVerifyUser() {
		
	}

	@Test
	public void testGetUserInfoByUid() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUserInfosByUid() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUserInfoByPhone() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUserInfosByPhone() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetLoverByPhone() {
		String phone = "13188888888";
		List<Map<String, Object>> list ;
		list = userService.getLoverByPhone(phone);
		System.out.println(list.toString());
	}

}
