package com.jd.hackathon.one.service;

import static org.junit.Assert.fail;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.jd.hackathon.one.bean.LoverBean;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/applicationContext*.xml"})
public class LoverServicelTest {
	@Autowired
	private LoverService loverService;
	
	@Test
	public void testEnv(){
		System.out.println("test ok");
	}
	
	@Test
	public void testGetLoverInfoByLid() {
		long lid = 1;
		LoverBean bean = new LoverBean();
		bean = loverService.getLoverInfoByLid(lid);
		System.out.println(bean.toString());
	}

	@Test
	public void testGetLoverInfosByLid() {
		long lid = 1;
		List<Map<String, Object>> list;
		list = loverService.getLoverInfosByLid(lid);
		System.out.println(list.toString());
	}

	@Test
	public void testGetLoverInfoByPhone() {
		
	}

	@Test
	public void testGetLoverInfosByPhone() {
		String phone = "13188888888";
		List<Map<String, Object>> list;
		list = loverService.getLoverInfosByPhone(phone);
		System.out.println(list);
	}

}
