-- ----------------------------
-- Table structure for `BRAND_INFO`
-- ----------------------------
DROP TABLE IF EXISTS o2o_entity_product.`BRAND_INFO`;
CREATE TABLE o2o_entity_product.`BRAND_INFO` (
  `id` bigint(20) NOT NULL COMMENT '自增ID' AUTO_INCREMENT,
  `brand_no` bigint(20) NOT NULL COMMENT '品牌编号',
  `brand_name` VARCHAR(100) NOT NULL COMMENT '品牌名称',
  `brand_zh_name` VARCHAR(200) NOT NULL COMMENT '品牌中文名称',
  `brand_en_name` VARCHAR(100) NOT NULL COMMENT '品牌英文名称',
  `brand_first_char` VARCHAR(10) NOT NULL COMMENT '品牌首字母',
  `brand_logo` VARCHAR(100) NOT NULL COMMENT '品牌LOGO',
  `apply_source` INT(11) COMMENT '申请来源 1:内部员工, 2:POP卖家,4:在线入驻',
  `brand_state` INT(11) NOT NULL COMMENT '品牌状态 -1:删除状态1：待审核:,2：审核通过，3：驳回',  
  `authorize_stat` INT(11) COMMENT '授权状态',   		
  `start_time` DATETIME NOT NULL COMMENT '申请开始时间',   		
  `end_time` DATETIME NOT NULL COMMENT '申请结束时间',   			
  `applicant` VARCHAR(50) COMMENT '申请人账号',   
  `audit_content` VARCHAR(300) COMMENT '审核内容/原因/理由',     	
  `sys_version` int(11) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_pin` varchar(50) NOT NULL,
  `update_pin` varchar(50) DEFAULT NULL,
  `yn` tinyint(4) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_BRANDINFO_BRANDNO` (`brand_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- ----------------------------
-- Table structure for `CATEGORY_INFO`
-- ----------------------------
DROP TABLE IF EXISTS o2o_entity_product.`CATEGORY_INFO`;
CREATE TABLE o2o_entity_product.`CATEGORY_INFO` (
  `id` bigint(20) NOT NULL COMMENT '自增ID' AUTO_INCREMENT,
  `category_id` bigint(20) NOT NULL COMMENT '类目ID',
  `parent_category_id` bigint(20) NOT NULL COMMENT '父类目ID',  
  `category_name` VARCHAR(50) NOT NULL COMMENT '类目名称',  
  `category_level` INT(11) NOT NULL COMMENT '类目级别',  
  `category_state` INT(11) NOT NULL COMMENT '类目状态',  		
  `sort` INT(11) NOT NULL COMMENT '类目排序',  		
  `begin_time` DATETIME NOT NULL COMMENT '开始时间',
  `end_time` DATETIME DEFAULT NULL COMMENT '结束时间',
  `sys_version` int(11) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_pin` varchar(50) NOT NULL,
  `update_pin` varchar(50) DEFAULT NULL,
  `yn` tinyint(4) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_CATEGORYINFO_CATEGORYID` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 		
		

-- ----------------------------
-- Table structure for `SHOP_CATEGORY`
-- ----------------------------
DROP TABLE IF EXISTS o2o_entity_product.`SHOP_CATEGORY`;
CREATE TABLE o2o_entity_product.`SHOP_CATEGORY` (
  `id` bigint(20) NOT NULL COMMENT '自增ID' AUTO_INCREMENT,
  `shop_category_id` bigint(20) NOT NULL COMMENT '店内分类ID',
  `parent_shop_category_id` bigint(20) NOT NULL COMMENT '父店内分类ID',
  `org_code` VARCHAR(50) NOT NULL COMMENT '组织机构编码(商家编号)',  
  `shop_category_name` VARCHAR(50) NOT NULL COMMENT '店内分类名称',  
  `shop_category_level` INT(11) NOT NULL COMMENT '店内分类级别',  	
  `sort` BIGINT(20) NOT NULL COMMENT '店内分类排序',  		
  `home_page_show` INT(11) NOT NULL COMMENT '是否在首页展示 1.展示 0.不展示',
  `sys_version` int(11) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_pin` varchar(50) NOT NULL,
  `update_pin` varchar(50) DEFAULT NULL,
  `yn` tinyint(4) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_SHOPCATEGORY_SHOPCATEGORYID` (`shop_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 		


-- ----------------------------
-- Table structure for `PRODUCT_IMAGES`
-- ----------------------------
DROP TABLE IF EXISTS o2o_entity_product.`PRODUCT_IMAGES`;
CREATE TABLE o2o_entity_product.`PRODUCT_IMAGES` (
  `product_image_id` bigint(20) NOT NULL COMMENT '自增ID' AUTO_INCREMENT,
  `sku_id` bigint(20) NOT NULL COMMENT '商品skuID',
  `major_image_url` VARCHAR(100) NOT NULL COMMENT '主图url',
  `major_image_url1` VARCHAR(100) NOT NULL COMMENT '次图url1',
  `major_image_url2` VARCHAR(100) NOT NULL COMMENT '次图url2',
  `major_image_url3` VARCHAR(100) NOT NULL COMMENT '次图url3',
  `major_image_url4` VARCHAR(100) NOT NULL COMMENT '次图url4',
  `major_image_url5` VARCHAR(100) NOT NULL COMMENT '次图url5',
  `major_image_url6` VARCHAR(100) NOT NULL COMMENT '次图url6',
  `sys_version` int(11) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_pin` varchar(50) NOT NULL,
  `update_pin` varchar(50) DEFAULT NULL,
  `yn` tinyint(4) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 



-- ----------------------------
-- Table structure for `SKU_MAIN`
-- ----------------------------
DROP TABLE IF EXISTS o2o_entity_product.`SKU_MAIN`;
CREATE TABLE o2o_entity_product.`SKU_MAIN` (
  `id` bigint(20) NOT NULL COMMENT '自增ID' AUTO_INCREMENT,
  `sku_id` bigint(20) NOT NULL COMMENT '商品skuID',
  `out_sku_id` bigint(20) COMMENT '外部skuid（店铺填的sku）',
  `org_code` bigint(20) NOT NULL COMMENT '京东到家组织ID（o2o商家编码）',
  `out_vender_id` bigint(20) COMMENT '外部平台商家ID（考虑到接其他平台的商品）',
  `out_id` bigint(20) COMMENT '外平台编号（考虑到接其他平台的商品）',
  `product_image_id` bigint(20) NOT NULL COMMENT '商品图片编号',
  `category_id` bigint(20) NOT NULL COMMENT '类目ID',
  `brand_no` bigint(20) NOT NULL COMMENT '品牌编号',
  `sku_name` VARCHAR(100) NOT NULL COMMENT 'sku名称',
  `slogan` VARCHAR(100) NOT NULL COMMENT '广告词',
  `sku_price` BIGINT(20) NOT NULL COMMENT 'sku价格',
  `sku_market_price` BIGINT(20) NOT NULL COMMENT '市场价',		
  `cost_price` BIGINT(20) NOT NULL COMMENT '成本价',	
  `product_wrap` INT(11) NOT NULL COMMENT '包装',			
  `length` INT(11) NOT NULL COMMENT '(包装)长度 单位:mm',	
  `wide` INT(11) NOT NULL COMMENT '(包装)宽度 单位:mm',	
  `high` INT(11) NOT NULL COMMENT '(包装)高度 单位:mm',	
  `weight` INT(11) NOT NULL COMMENT '重量(公斤)',	  
  `product_location` VARCHAR(100) NOT NULL COMMENT '商品产地',	  
  `producter` VARCHAR(50) NOT NULL COMMENT '生产厂家 (pop无)',	  
  `upc_code` VARCHAR(50) NOT NULL COMMENT 'upc编码',	  		
  `pay_type` INT(11) NOT NULL COMMENT '支付方式-是否先款后货（先预留，界面不显示）  1.先款后货 0.非先款后货  默认0.非先款后货',	  	
  `product_desc_id` VARCHAR(50) NOT NULL COMMENT '商品描述ID(从MongoDB里面取出)',	  
  `shop_category_ids` VARCHAR(200) NOT NULL COMMENT '店内分类列表',	  
  `fixed_up_time` DATETIME NOT NULL COMMENT '定时上架时间',	  
  `fixed_down_time` DATETIME NOT NULL COMMENT '定时上架时间',	  
  `fixed_type` INT(11) NOT NULL COMMENT '上下架类型',	  
  `fixed_status` INT(11) NOT NULL COMMENT '上下架状态',	  
  `sys_version` int(11) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_pin` varchar(50) NOT NULL,
  `update_pin` varchar(50) DEFAULT NULL,
  `yn` tinyint(4) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_SKUMAIN_SKUID (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 


-- ----------------------------
-- Table structure for `SKU_RELATION`
-- ----------------------------
DROP TABLE IF EXISTS o2o_entity_product.`SKU_RELATION`;
CREATE TABLE o2o_entity_product.`SKU_RELATION` (
  `id` bigint(20) NOT NULL COMMENT '自增ID' AUTO_INCREMENT,
  `sku_id` bigint(20) NOT NULL COMMENT '商品skuID',
  `sku_id_main` bigint(20) NOT NULL COMMENT '主skuid',
  `color_name` VARCHAR(50) COMMENT '颜色名称',
  `color_order` INT(11) COMMENT '颜色顺序',
  `size_name` VARCHAR(50) COMMENT '尺码名称',  
  `size_order` INT(11) COMMENT '尺码顺序',  
  `custom` VARCHAR(50) COMMENT '自定义项',  
  `custom_name` VARCHAR(50) COMMENT '自定义项名称',  
  `custom_order` INT(11) COMMENT '自定义项顺序',  	
  `sys_version` int(11) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_pin` varchar(50) NOT NULL,
  `update_pin` varchar(50) DEFAULT NULL,
  `yn` tinyint(4) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_SKURELATION_SKUID (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;





-- ----------------------------
-- Table structure for `SKU_SHOP_CATEGORY`
-- ----------------------------
DROP TABLE IF EXISTS o2o_entity_product.`SKU_SHOP_CATEGORY`;
CREATE TABLE o2o_entity_product.`SKU_SHOP_CATEGORY` (
  `id` bigint(20) NOT NULL COMMENT '自增ID' AUTO_INCREMENT,
  `sku_id` bigint(20) NOT NULL COMMENT '商品skuID',
  `shop_category_id` bigint(20) NOT NULL COMMENT '店内分类列表',	  
  `sys_version` int(11) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  `update_time` datetime DEFAULT NULL,
  `create_pin` varchar(50) NOT NULL,
  `update_pin` varchar(50) DEFAULT NULL,
  `yn` tinyint(4) NOT NULL DEFAULT '0',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_SKURELATION_SKUID (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;